#!/usr/bin/env python3
"""Foto Cast - der Plugin-Teil des Pakets.

Zeigt ein Foto, das man gerade auf dem Handy anschaut, sofort auf dem
Rahmen:

- iPhone: im Teilen-Menü der Fotos-App ein Kurzbefehl, der das Bild an
  http://<rahmen>:8095/upload schickt.
- Android: die Handy-Seite http://<rahmen>:8095/ (Foto wählen) oder die App
  "HTTP Shortcuts" im Teilen-Menü, die dasselbe tut.
- Jeder Browser im WLAN: dieselbe Handy-Seite.

Gezeigt wird in der Szene "phone-photos". Das Plugin holt sie über die
laufende Playlist (Display-Takeover) für ein paar Minuten und gibt den
Bildschirm danach zurück. Mehrere Fotos kurz hintereinander bilden eine
kleine Reihe, die sich abwechselt. Videos laufen einmal ganz durch; was die
Szene nicht abspielen kann (meist HEVC vom iPhone), wandelt ffmpeg vorher in
H.264 um, falls es auf dem Rahmen ist. Was gerade zu sehen sein soll, weiß nur
das Plugin; die Szene fragt jede Sekunde nach.
"""

import io
import json
import os
import re
import secrets
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime
from email.parser import BytesParser
from email.policy import HTTP
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import texts  # noqa: E402

try:
    # Umgeht einen Dynaframe-Fehler, der einen Quick Mix nach einem Takeover
    # gestoppt lassen kann (siehe dort). Ohne die Datei läuft alles weiter.
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None

try:
    from PIL import Image, ImageOps
except ImportError:  # pragma: no cover - dann werden Fotos unverändert gespeichert
    Image = ImageOps = None

try:  # HEIC-Fotos vom iPhone
    import pillow_heif  # type: ignore
    pillow_heif.register_heif_opener()
except Exception:  # pragma: no cover
    pillow_heif = None

plugin = create_plugin()

PLUGIN_ID = "PhonePhotos"
DISPLAY_NAME = "Foto Cast"
SCENE_ID = "phone-photos"           # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen, Zustand und Fotos; bleibt bei Updates
PHOTO_DIR = DATA_DIR / "photos"
# Handy-Seite und Upload. Der erste freie Port gilt; 8095 steht in der Anleitung.
PHONE_PORTS = (8095, 8096, 8097, 8098)
MAX_UPLOAD = 2 * 1024 * 1024 * 1024    # Videos
MAX_PHOTO = 80 * 1024 * 1024
MAX_MULTIPART = 400 * 1024 * 1024      # Formulare werden im Speicher zerlegt
MAX_EDGE = 3840                     # längste Kante auf dem Rahmen
THUMB_EDGE = 360
BATCH_SECONDS = 120                 # so kurz hintereinander: zur Reihe dazu
MAX_BATCH = 50

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        pass
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=1, ensure_ascii=False)
    temp.replace(path)


def local_text(epoch):
    if not epoch:
        return ""
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Einstellungen (alle auf der Plugin-Seite; das Manifest deklariert keine)
# --------------------------------------------------------------------------

SETTINGS = {
    "Language":     {"kind": "choice", "default": "de", "options": list(texts.LANGUAGES)},
    # So lange bleibt ein Foto (eine Reihe) auf dem Rahmen.
    "ShowMinutes":  {"kind": "number", "default": 5, "min": 1, "max": 240},
    # Bei mehreren Fotos: so lange jedes.
    "SlideSeconds": {"kind": "number", "default": 10, "min": 3, "max": 300},
    # contain: ganzes Foto vor unscharfem Hintergrund; cover: bildschirmfüllend beschnitten.
    "Fit":          {"kind": "choice", "default": "contain", "options": ["contain", "cover"]},
    # Absender und Uhrzeit klein unten einblenden.
    "Caption":      {"kind": "bool", "default": True},
    # Einen ausgeschalteten Bildschirm einschalten, wenn ein Foto kommt.
    "WakeScreen":   {"kind": "bool", "default": True},
    # So viele zuletzt gesendete Fotos bleiben auf dem Rahmen (zum erneuten Zeigen).
    "KeepPhotos":   {"kind": "number", "default": 30, "min": 1, "max": 300},
    # Videos sind groß: davon nur so viele.
    "KeepVideos":   {"kind": "number", "default": 10, "min": 1, "max": 100},
    # Wer im WLAN Fotos schicken darf: leer = alle, sonst nur mit diesem Code.
    "Pin":          {"kind": "pin", "default": ""},
    # Jedes Handy erst koppeln: der Rahmen zeigt dafür einen Code, den man auf dem
    # Handy eingibt. Neu ab 0.4.0; bei bestehenden Einstellungen bleibt es aus,
    # damit eingerichtete Kurzbefehle weiterlaufen.
    "Pairing":      {"kind": "bool", "default": True},
}

SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
INDEX_FILE = PHOTO_DIR / "index.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return default
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "number":
        return max(spec["min"], min(spec["max"], as_int(raw, default)))
    if kind == "choice":
        value = str(raw).strip().lower()
        return value if value in spec["options"] else default
    if kind == "pin":
        return re.sub(r"[^0-9A-Za-z]", "", str(raw))[:12]
    return str(raw)[:200]


def settings():
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
    values = {name: coerce(name, stored.get(name)) for name in SETTINGS}
    if stored and "Pairing" not in stored:
        values["Pairing"] = False
    return values


def tr(template, **values):
    """Ein Text in der eingestellten Sprache (siehe texts.py)."""
    return texts.t(settings()["Language"], template, **values)


def save_settings(changes):
    changed = []
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            value = coerce(name, raw)
            if stored.get(name) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, stored)
    return changed


_state_lock = threading.Lock()


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**fields):
    with _state_lock:
        state = read_json(STATE_FILE, {}) or {}
        if all(k in state and state[k] == v for k, v in fields.items()):
            return state  # nichts Neues, also kein Schreiben auf die SD-Karte
        state.update(fields)
        write_json(STATE_FILE, state)
    return state


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "note": ""}


def find_scene():
    """Die installierte Szene. Ihre numerische id braucht ein Playlist-Eintrag."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else
                      tr("Die Szene Foto Cast ist auf der Plugins-Seite ausgeschaltet."))
        return row
    _scene.update(dbId=None, note=tr("Die Szene Foto Cast ist auf diesem Rahmen nicht installiert. "
                                     "Installiere das Paket noch einmal."))
    return None


# --------------------------------------------------------------------------
# Die Takeover-Playlist
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = "Foto Cast (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Wird vom Plugin Foto Cast abgespielt, wenn ein Foto vom Handy kommt. "
                                 "Bleibt ausgeschaltet, damit es nicht im Quick Mix landet. "
                                 "Das Plugin legt sie neu an, wenn sie gelöscht wird.")
TAKEOVER_ITEM_SECONDS = 12 * 3600  # das Plugin beendet die Anzeige lange vorher

_playlists = {"at": 0.0, "takeoverId": None, "note": ""}
_playlist_lock = threading.Lock()


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    """Hat irgendetwas den Bildschirm? Die Playlist wird nur angelegt, solange
    nichts ihn hält: der Rahmen baut den Quick Mix nach einem Takeover neu,
    und eine inzwischen angelegte Playlist ändert, was er wiederherstellt."""
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError:
        return False
    return bool(status.get("active"))


def ensure_takeover_playlist():
    """Ein Takeover spielt eine Playlist, keine einzelne Szene. Also: die
    Szene allein, zwölf Stunden, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists()
                         if p.get("name") in (TAKEOVER_PLAYLIST_NAME, "Phone Photos (takeover)")), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if i.get("dynamicSceneId") == _scene["dbId"]]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if playlist.get("name") and playlist.get("name") != TAKEOVER_PLAYLIST_NAME:
                # Bis 0.1.2 hieß das Plugin Phone Photos; die Playlist bekommt den neuen Namen.
                engine_call("PUT", f"/playlists/{playlist_id}", {"name": TAKEOVER_PLAYLIST_NAME,
                                                                 "description": TAKEOVER_PLAYLIST_DESCRIPTION})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_PLAYLIST_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=TAKEOVER_PLAYLIST_NAME))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    plugin.log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def maintain_playlists(force=False):
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        find_scene()
        if _scene["dbId"] is None:
            _playlists["note"] = _scene["note"]
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc)
            plugin.log(_playlists["note"], level="warning")


# --------------------------------------------------------------------------
# Die Fotos und Videos
# --------------------------------------------------------------------------

class PhotoError(Exception):
    pass


PHOTO_ID = re.compile(r"^[A-Za-z0-9_-]{6,40}$")
_photo_lock = threading.RLock()
FFMPEG = shutil.which("ffmpeg")
FFPROBE = shutil.which("ffprobe")


def photo_index():
    with _photo_lock:
        rows = read_json(INDEX_FILE, [])
    return [r for r in rows if isinstance(r, dict) and PHOTO_ID.match(str(r.get("id", "")))] \
        if isinstance(rows, list) else []


def find_photo(photo_id):
    return next((r for r in photo_index() if r["id"] == photo_id), None)


def update_row(photo_id, **fields):
    with _photo_lock:
        rows = photo_index()
        for row in rows:
            if row["id"] == photo_id:
                row.update(fields)
                write_json(INDEX_FILE, rows)
                return row
    return None


def is_video(row):
    return bool(row) and row.get("kind") == "video"


def is_ready(row):
    return bool(row) and row.get("state", "ready") == "ready"


IMAGE_BRANDS = (b"heic", b"heix", b"hevc", b"heim", b"heis", b"mif1", b"msf1", b"avif", b"avis")


def sniff(data):
    """Format an den ersten Bytes erkennen."""
    head = data[:16]
    if head.startswith(b"\xff\xd8\xff"):
        return "jpeg"
    if head.startswith(b"\x89PNG"):
        return "png"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if head[4:8] == b"ftyp":
        brand = head[8:12]
        if brand in (b"avif", b"avis"):
            return "avif"
        if brand in IMAGE_BRANDS:
            return "heic"
        return "mov" if brand == b"qt  " else "mp4"
    if head[4:8] in (b"moov", b"mdat", b"wide", b"free", b"skip"):
        return "mov"   # ältere QuickTime-Dateien ohne ftyp
    if head.startswith(b"\x1a\x45\xdf\xa3"):
        return "webm"
    return ""


VIDEO_KINDS = {"mp4": ".mp4", "mov": ".mov", "webm": ".webm"}


def prepare(data):
    """Foto drehen wie aufgenommen, verkleinern, als JPEG. (full, thumb, w, h)"""
    kind = sniff(data)
    if not kind or kind in VIDEO_KINDS:
        raise PhotoError(tr("Das ist kein Foto, das der Rahmen lesen kann."))
    if Image is None or (kind in ("heic", "avif") and pillow_heif is None):
        if kind in ("heic", "avif"):
            raise PhotoError(tr("HEIC-Fotos vom iPhone kann der Rahmen nicht lesen. Füge im Kurzbefehl "
                                "„Bild konvertieren“ in JPEG ein oder schick das Foto über die Handy-Seite."))
        if Image is None:
            return data, data, 0, 0, kind
    try:
        image = Image.open(io.BytesIO(data))
        image = ImageOps.exif_transpose(image)
        if image.mode not in ("RGB", "L"):
            background = Image.new("RGB", image.size, (0, 0, 0))
            rgba = image.convert("RGBA")
            background.paste(rgba, mask=rgba.split()[3])
            image = background
        image = image.convert("RGB")
        image.thumbnail((MAX_EDGE, MAX_EDGE), Image.LANCZOS)
        width, height = image.size
        full = io.BytesIO()
        image.save(full, "JPEG", quality=90, optimize=True)
        small = image.copy()
        small.thumbnail((THUMB_EDGE, THUMB_EDGE), Image.LANCZOS)
        thumb = io.BytesIO()
        small.save(thumb, "JPEG", quality=80)
        return full.getvalue(), thumb.getvalue(), width, height, "jpeg"
    except Exception as exc:
        raise PhotoError(tr("Konnte das Foto nicht lesen: {exc}", exc=exc)) from exc


EXTENSIONS = {"jpeg": ".jpg", "png": ".png", "webp": ".webp", "gif": ".gif"}
# .mov als video/mp4: Chromium spielt QuickTime-Dateien mit H.264 so am zuverlässigsten.
TYPES = {".jpg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif",
         ".mp4": "video/mp4", ".mov": "video/mp4", ".webm": "video/webm"}


def new_id():
    return time.strftime("%Y%m%d-%H%M%S-") + secrets.token_hex(3)


def store_photo(data, sender=""):
    full, thumb, width, height, kind = prepare(data)
    photo_id = new_id()
    ext = EXTENSIONS.get(kind, ".jpg")
    PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    (PHOTO_DIR / f"{photo_id}{ext}").write_bytes(full)
    (PHOTO_DIR / f"{photo_id}.thumb{ext}").write_bytes(thumb)
    row = {"id": photo_id, "kind": "photo", "ext": ext, "thumbExt": ext, "w": width, "h": height,
           "at": now(), "from": sender[:40], "bytes": len(full)}
    with _photo_lock:
        rows = photo_index()
        rows.insert(0, row)
        write_json(INDEX_FILE, rows)
    prune_photos()
    plugin.log(f"Foto {photo_id} empfangen ({len(data) // 1024} KB{', von ' + sender if sender else ''}).")
    return row


# ---- Videos ---------------------------------------------------------------

def _boxes(handle, start, end):
    """Die MP4-Kästen zwischen start und end: (typ, inhalt_start, inhalt_ende)."""
    pos = start
    while pos + 8 <= end:
        handle.seek(pos)
        header = handle.read(16)
        if len(header) < 8:
            return
        size, kind = struct.unpack(">I4s", header[:8])
        body = pos + 8
        if size == 1 and len(header) >= 16:
            size = struct.unpack(">Q", header[8:16])[0]
            body = pos + 16
        elif size == 0:
            size = end - pos
        if size < 8:
            return
        yield kind, body, min(pos + size, end)
        pos += size


def probe_mp4(path):
    """Ohne ffprobe: Codec, Dauer und Größe aus dem moov-Kasten lesen."""
    info = {"codec": "", "duration": 0.0, "w": 0, "h": 0}
    try:
        with open(path, "rb") as handle:
            total = os.path.getsize(path)
            for kind, body, end in _boxes(handle, 0, total):
                if kind != b"moov":
                    continue
                for sub, sbody, send in _boxes(handle, body, end):
                    if sub == b"mvhd":
                        handle.seek(sbody)
                        head = handle.read(32)
                        if head[:1] == b"\x01":
                            scale, length = struct.unpack(">IQ", head[20:32])
                        else:
                            scale, length = struct.unpack(">II", head[12:20])
                        if scale:
                            info["duration"] = round(length / scale, 2)
                    elif sub == b"trak":
                        handle.seek(sbody)
                        blob = handle.read(min(send - sbody, 4 * 1024 * 1024))
                        if b"vide" not in blob or info["codec"]:
                            continue
                        for name, codec in ((b"hvc1", "hevc"), (b"hev1", "hevc"), (b"avc1", "h264"),
                                            (b"avc3", "h264"), (b"av01", "av1"), (b"vp09", "vp9")):
                            if name in blob:
                                info["codec"] = codec
                                break
                        tkhd = blob.find(b"tkhd")
                        if tkhd >= 4:
                            version_byte = blob[tkhd + 4]
                            offset = tkhd + 4 + (88 if version_byte == 1 else 76)
                            if offset + 8 <= len(blob):
                                w, h = struct.unpack(">II", blob[offset:offset + 8])
                                info["w"], info["h"] = w >> 16, h >> 16
                break
    except (OSError, struct.error, IndexError):
        pass
    return info


def probe_video(path):
    if FFPROBE:
        try:
            out = subprocess.run(
                [FFPROBE, "-v", "error", "-select_streams", "v:0", "-show_entries",
                 "stream=codec_name,width,height:stream_side_data=rotation:stream_tags=rotate:format=duration",
                 "-of", "json", str(path)], capture_output=True, timeout=30, check=False)
            data = json.loads(out.stdout or b"{}")
            stream = (data.get("streams") or [{}])[0]
            w, h = as_int(stream.get("width")), as_int(stream.get("height"))
            rotation = as_int((stream.get("tags") or {}).get("rotate"))
            for side in stream.get("side_data_list") or []:
                rotation = rotation or as_int(side.get("rotation"))
            if abs(rotation) in (90, 270):
                w, h = h, w
            duration = float((data.get("format") or {}).get("duration") or 0)
            if stream.get("codec_name"):
                return {"codec": stream["codec_name"].lower(), "duration": round(duration, 2), "w": w, "h": h}
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            plugin.log(f"ffprobe ging nicht: {exc}", level="warning")
    return probe_mp4(path)


def player_plays(codec, ext):
    """Spielt DynaFrames Player das, so wie es ist? Umgewandelt wird nur der Rest."""
    return codec in ("h264", "hevc", "vp8", "vp9", "av1", "")


def make_video_thumb(photo_id, path, row):
    """Ein Standbild für die Seiten und als Hintergrund der Szene."""
    target = PHOTO_DIR / f"{photo_id}.thumb.jpg"
    if FFMPEG:
        try:
            at = "1" if row.get("duration", 0) > 2 else "0"
            subprocess.run([FFMPEG, "-v", "error", "-y", "-ss", at, "-i", str(path), "-frames:v", "1",
                            "-vf", f"scale='min({THUMB_EDGE * 2},iw)':-2", str(target)],
                           capture_output=True, timeout=60, check=False)
            if target.exists() and target.stat().st_size > 0:
                return ".jpg"
        except (OSError, subprocess.SubprocessError) as exc:
            plugin.log(f"Kein Standbild für {photo_id}: {exc}", level="warning")
    return ""


def store_video(temp_path, kind, sender=""):
    photo_id = new_id()
    ext = VIDEO_KINDS.get(kind, ".mp4")
    PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    path = PHOTO_DIR / f"{photo_id}{ext}"
    shutil.move(str(temp_path), path)
    info = probe_video(path)
    size = path.stat().st_size
    row = {"id": photo_id, "kind": "video", "ext": ext, "thumbExt": "", "w": info["w"], "h": info["h"],
           "duration": info["duration"], "codec": info["codec"], "at": now(), "from": sender[:40],
           "bytes": size, "state": "ready", "progress": 0, "error": ""}
    row["thumbExt"] = make_video_thumb(photo_id, path, row)
    convert = not player_plays(info["codec"], ext)
    if convert and FFMPEG:
        row["state"] = "converting"
    elif convert:
        row["error"] = tr("Dieses Video ({codec}) kann der Rahmen vielleicht nicht abspielen, und ffmpeg zum "
                          "Umwandeln fehlt.", codec=info["codec"].upper())
    with _photo_lock:
        rows = photo_index()
        rows.insert(0, row)
        write_json(INDEX_FILE, rows)
    prune_photos()
    plugin.log(f"Video {photo_id} empfangen ({size // 1048576} MB, {info['codec'] or '?'}, "
               f"{info['duration']:.0f} s{', von ' + sender if sender else ''}).")
    if row["state"] == "converting":
        _convert_queue.append(photo_id)
        _convert_wake.set()
    return row


_convert_queue = []
_convert_wake = threading.Event()
_converting = {"id": "", "proc": None}


def convert_video(photo_id):
    """In H.264 umwandeln, höchstens 1080p, und danach zeigen."""
    row = find_photo(photo_id)
    if not row or row.get("state") != "converting":
        return
    source = PHOTO_DIR / f"{photo_id}{row['ext']}"
    target = PHOTO_DIR / f"{photo_id}.part.mp4"
    duration = row.get("duration") or 0
    command = [FFMPEG, "-v", "error", "-y", "-i", str(source), "-map", "0:v:0", "-map", "0:a:0?",
               "-vf", "scale='if(gt(iw,ih),min(1920,iw),-2)':'if(gt(iw,ih),-2,min(1920,ih))',format=yuv420p",
               "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-c:a", "aac", "-b:a", "128k",
               "-movflags", "+faststart", "-progress", "pipe:1", "-nostats", str(target)]
    plugin.log(f"Wandle Video {photo_id} ({row.get('codec')}) in H.264 um …")
    started = now()
    try:
        proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        _converting.update(id=photo_id, proc=proc)
        last = 0.0
        for line in proc.stdout:
            if _stop_requested.is_set():
                proc.kill()
                break
            if line.startswith("out_time_us=") or line.startswith("out_time_ms="):
                done = as_int(line.split("=", 1)[1]) / 1e6
                if duration and now() - last > 2:
                    last = now()
                    update_row(photo_id, progress=max(0, min(99, int(done * 100 / duration))))
        proc.wait()
        error = (proc.stderr.read() or "").strip().splitlines()
    except OSError as exc:
        error = [str(exc)]
        proc = None
    finally:
        _converting.update(id="", proc=None)
    if _stop_requested.is_set():
        target.unlink(missing_ok=True)
        return
    if proc is None or proc.returncode != 0 or not target.exists():
        target.unlink(missing_ok=True)
        message = error[-1] if error else "?"
        update_row(photo_id, state="failed", error=tr("Umwandeln fehlgeschlagen: {exc}", exc=message[:200]))
        plugin.log(f"Umwandeln von {photo_id} fehlgeschlagen: {message}", level="warning")
        return
    final = PHOTO_DIR / f"{photo_id}.mp4"
    target.replace(final)
    if source != final:
        source.unlink(missing_ok=True)
    info = probe_video(final)
    update_row(photo_id, state="ready", ext=".mp4", codec="h264", progress=100, bytes=final.stat().st_size,
               w=info["w"] or row.get("w", 0), h=info["h"] or row.get("h", 0),
               duration=info["duration"] or duration)
    plugin.log(f"Video {photo_id} umgewandelt ({now() - started:.0f} s).")
    if find_photo(photo_id):
        show_photos([photo_id], append=True)


def convert_loop():
    # Was beim letzten Mal mitten im Umwandeln war, noch einmal.
    for row in photo_index():
        if row.get("state") == "converting":
            (PHOTO_DIR / f"{row['id']}.part.mp4").unlink(missing_ok=True)
            _convert_queue.append(row["id"])
    while not _stop_requested.is_set():
        if not _convert_queue:
            _convert_wake.wait(5)
            _convert_wake.clear()
            continue
        photo_id = _convert_queue.pop(0)
        try:
            convert_video(photo_id)
        except Exception as exc:  # pragma: no cover - die Schleife muss weiterlaufen
            plugin.log(f"Umwandeln von {photo_id}: {exc}", level="error")
            update_row(photo_id, state="failed", error=str(exc)[:200])


def delete_files(row):
    names = [f"{row['id']}{row.get('ext', '.jpg')}", f"{row['id']}.part.mp4"]
    thumb_ext = row.get("thumbExt", row.get("ext", ".jpg"))
    if thumb_ext:
        names.append(f"{row['id']}.thumb{thumb_ext}")
    for name in names:
        try:
            (PHOTO_DIR / name).unlink()
        except FileNotFoundError:
            pass
        except OSError as exc:
            plugin.log(f"Konnte {name} nicht löschen: {exc}", level="warning")


def prune_photos():
    values = settings()
    with _show_lock:
        showing = set(_show["ids"]) if _show["active"] else set()
    with _video_lock:
        showing |= set(_video["pending"]) | set(_video["playing"])
    with _photo_lock:
        rows = photo_index()
        kept, gone = [], []
        counts = {"photo": 0, "video": 0}
        for row in rows:
            kind = "video" if is_video(row) else "photo"
            limit = values["KeepVideos"] if kind == "video" else values["KeepPhotos"]
            if counts[kind] < limit or row["id"] in showing or row["id"] == _converting["id"]:
                kept.append(row)
                counts[kind] += 1
            else:
                gone.append(row)
        if gone:
            write_json(INDEX_FILE, kept)
    for row in gone:
        if row["id"] in _convert_queue:
            _convert_queue.remove(row["id"])
        delete_files(row)


def delete_photo(photo_id):
    with _photo_lock:
        rows = photo_index()
        row = next((r for r in rows if r["id"] == photo_id), None)
        if row is None:
            return False
        write_json(INDEX_FILE, [r for r in rows if r["id"] != photo_id])
    if photo_id in _convert_queue:
        _convert_queue.remove(photo_id)
    proc = _converting["proc"] if _converting["id"] == photo_id else None
    if proc is not None:
        try:
            proc.kill()
        except OSError:
            pass
    delete_files(row)
    with _show_lock:
        if photo_id in _show["ids"]:
            _show["ids"].remove(photo_id)
            _show["seq"] += 1
            if not _show["ids"]:
                _show["active"] = False
                _show["endedAt"] = now()
    _wake.set()
    return True


def photo_public(row):
    payload = {"id": row["id"], "kind": row.get("kind", "photo"), "w": row.get("w", 0), "h": row.get("h", 0),
               "from": row.get("from", ""), "at": local_text(row.get("at")), "url": f"photo/{row['id']}",
               "thumb": f"thumb/{row['id']}" if row.get("thumbExt", row.get("ext")) else ""}
    if is_video(row):
        payload.update(duration=row.get("duration", 0), state=row.get("state", "ready"),
                       progress=row.get("progress", 0), error=row.get("error", ""))
    return payload


# --------------------------------------------------------------------------
# Was gerade gezeigt werden soll
# --------------------------------------------------------------------------

_show_lock = threading.Lock()
_show = {"active": False, "ids": [], "seq": 0, "focus": "", "until": 0.0, "lastAdd": 0.0, "endedAt": 0.0}


def show_photos(ids, append=False):
    """Fotos und Videos auf den Rahmen. Mit append kommen sie zur laufenden
    Reihe dazu, wenn die gerade erst gekommen ist."""
    rows = [find_photo(i) for i in ids]
    rows = [r for r in rows if is_ready(r)]
    videos = [r["id"] for r in rows if is_video(r)]
    rows = [r for r in rows if not is_video(r)]
    if videos:
        queue_videos(videos)
    if not rows:
        return bool(videos)
    ids = [r["id"] for r in rows]
    minutes = settings()["ShowMinutes"]
    with _show_lock:
        t = now()
        if append and _show["active"] and t - _show["lastAdd"] < BATCH_SECONDS:
            for photo_id in ids:
                if photo_id not in _show["ids"]:
                    _show["ids"].append(photo_id)
            del _show["ids"][:-MAX_BATCH]
        else:
            _show["ids"] = list(ids)[-MAX_BATCH:]
        until = t + minutes * 60
        _show.update(active=True, seq=_show["seq"] + 1, focus=ids[-1], until=max(until, _show["until"]
                     if _show["active"] else 0), lastAdd=t)
    _wake.set()
    return True


def hide_photos(reason="ausgeblendet"):
    with _show_lock:
        was = _show["active"]
        _show.update(active=False, seq=_show["seq"] + 1, endedAt=now())
    if was:
        plugin.log(f"Fotos aus ({reason}).")
    _wake.set()
    return was


# ---- Videos spielt DynaFrame selbst ---------------------------------------
# Der Browser der Szenen startet Videos nur stumm (Qt WebEngine ohne
# Berührung), und ein Video darin hat ihn auf Jans Rahmen einmal zum Absturz
# gebracht. POST /playback/play-now spielt die Datei mit DynaFrames eigenem
# Player, mit Ton, und kehrt danach selbst zur Playlist zurück (2026-10-25).
VIDEO_SETTLE = 3     # so lange auf Videos warten, die gleich hinterherkommen
VIDEO_TAIL = 3       # Sekunden je Video über die Dauer hinaus

_video_lock = threading.Lock()
_video = {"pending": [], "playing": [], "since": 0.0, "endsAt": 0.0, "lastAdd": 0.0, "note": ""}


def queue_videos(ids):
    with _video_lock:
        for photo_id in ids:
            if photo_id not in _video["pending"]:
                _video["pending"].append(photo_id)
        _video["lastAdd"] = now()
    # Videos sind das Neueste: die Fotos machen Platz.
    hide_photos("Video kommt")
    _wake.set()


def videos_on_screen():
    with _video_lock:
        if _video["playing"] and now() < _video["endsAt"]:
            return list(_video["playing"]), _video["endsAt"]
    return [], 0.0


def _video_note(text):
    with _video_lock:
        _video["note"] = text
    if text:
        plugin.log(text, level="warning")
    return False


def decide_videos():
    t = now()
    with _video_lock:
        if not _video["pending"] or t - _video["lastAdd"] < VIDEO_SETTLE:
            return
        if _video["playing"] and t < _video["endsAt"]:
            return
        if _takeover["handle"] is not None:   # erst geben die Fotos den Bildschirm zurück
            return
        ids = list(_video["pending"])
        _video["pending"] = []
    play_videos(ids)


def play_videos(ids):
    rows = [r for r in (find_photo(i) for i in ids) if is_ready(r) and is_video(r)]
    if not rows:
        return False
    if display_is_off():
        if not settings()["WakeScreen"]:
            return _video_note(tr("Der Bildschirm ist aus; das Video wird nicht gezeigt."))
        try:
            engine_call("POST", "/display/power", {"state": "on"}, read_timeout=10)
        except EngineError as exc:
            plugin.log(f"Konnte den Bildschirm nicht einschalten: {exc}", level="warning")
    items = []
    for row in rows:
        path = str(PHOTO_DIR / f"{row['id']}{row.get('ext', '.mp4')}")
        items.append({"type": "file", "path": path, "filePath": path, "mediaType": "video",
                      "title": row.get("from") or DISPLAY_NAME})
    try:
        answer = engine_call("POST", "/playback/play-now", {"items": items}, read_timeout=20) or {}
    except EngineError as exc:
        return _video_note(tr("Konnte das Video nicht abspielen: {exc}", exc=exc))
    if answer.get("success") is False:
        return _video_note(tr("Konnte das Video nicht abspielen: {exc}", exc=answer.get("error") or "?"))
    t = now()
    total = sum((r.get("duration") or 60) + VIDEO_TAIL for r in rows)
    note = ""
    if answer.get("deferredByDisplaySession"):
        note = tr("Etwas anderes hat gerade den Bildschirm; das Video kommt danach.")
        total += 300
    with _video_lock:
        _video.update(playing=[r["id"] for r in rows], since=t, endsAt=t + total, note=note)
    plugin.log(f"DynaFrame spielt {len(rows)} Video(s) ab ({', '.join(r['id'] for r in rows)})"
               + (", nach dem, was gerade den Bildschirm hat." if note else "."))
    return True


def stop_videos():
    """Ausblenden während eines Videos: zurück zur Playlist."""
    with _video_lock:
        playing = bool(_video["playing"]) and now() < _video["endsAt"]
        _video.update(pending=[], playing=[], endsAt=0.0)
    if not playing:
        return False
    try:
        status = engine_call("GET", "/playback/play-now/status", read_timeout=5) or {}
        engine_call("POST", "/playback/return", {"sessionId": status.get("sessionId")}, read_timeout=10)
    except EngineError as exc:
        plugin.log(f"Konnte nicht zur Playlist zurückkehren: {exc}", level="warning")
        return False
    plugin.log("Video ausgeblendet, zurück zur Playlist.")
    return True


def scene_report(body):
    """Die Szene meldet sich beim Start und bei Fehlern."""
    event = str(body.get("event") or "")
    if event == "hello":
        plugin.log(f"Szene {str(body.get('scene'))[:20]} läuft: {str(body.get('href'))[:200]} "
                   f"({str(body.get('agent'))[:200]})")
    elif event == "sceneError":
        plugin.log(f"Fehler in der Szene: {str(body.get('error') or '?')[:500]}", level="warning")


def save_upload(stream, length, first=b""):
    """Den Upload in eine Datei neben den Fotos schreiben (nicht in den Speicher)."""
    PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(dir=PHOTO_DIR, prefix=".incoming-", delete=False)
    try:
        with handle:
            handle.write(first)
            left = length - len(first)
            while left > 0:
                chunk = stream.read(min(left, 1 << 20))
                if not chunk:
                    break
                handle.write(chunk)
                left -= len(chunk)
        return Path(handle.name)
    except Exception:
        Path(handle.name).unlink(missing_ok=True)
        raise


def receive_file(path, sender=""):
    """Eine angekommene Datei: Foto oder Video, speichern und zeigen."""
    try:
        with open(path, "rb") as handle:
            head = handle.read(32)
        kind = sniff(head)
        if kind in VIDEO_KINDS:
            row = store_video(path, kind, sender)
        else:
            if not head:
                raise PhotoError(tr("Es kam kein Foto an."))
            if path.stat().st_size > MAX_PHOTO:
                raise PhotoError(tr("Das Foto ist zu groß (höchstens {mb} MB).", mb=MAX_PHOTO // 1048576))
            row = store_photo(path.read_bytes(), sender)
    finally:
        path.unlink(missing_ok=True)
    show_photos([row["id"]], append=True)
    return row


def receive(data, sender=""):
    """Ein Foto oder Video als Bytes (aus einem Formular)."""
    if not data:
        raise PhotoError(tr("Es kam kein Foto an."))
    PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    handle = tempfile.NamedTemporaryFile(dir=PHOTO_DIR, prefix=".incoming-", delete=False)
    with handle:
        handle.write(data)
    return receive_file(Path(handle.name), sender)


# --------------------------------------------------------------------------
# Den Bildschirm übernehmen und zurückgeben
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "since": None, "limit": 0, "token": 0, "note": "", "retryAt": 0.0, "busy": False}
_stop_requested = threading.Event()
_wake = threading.Event()


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform") or {}
    except EngineError:
        return True  # nicht entscheidbar: der Versuch selbst sagt es dann
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Foto Cast ist auf der Plugins-Seite ausgeschaltet.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Foto Cast auf der Plugins-Seite aus. Schalte es ein, "
                  "sonst kann kein Foto gezeigt werden.")
    return ""


def display_is_off():
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        plugin.log(text)
    return False


def _on_session_state(handle_or_state):
    """Das SDK ruft das mit dem Handle auf, nicht mit dem neuen Zustand."""
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _takeover.update(handle=None, since=None)
        renewing = new_state == "expired"
    plugin.log(f"Der Rahmen hat Foto Cast beendet: {new_state}.")
    if not renewing:
        # Jemand anderes hat den Bildschirm genommen oder ihn zurückgeholt.
        hide_photos(f"Bildschirm {new_state}")
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    _wake.set()


def end_takeover(reason, token=None):
    """Bildschirm zurückgeben. Mehrfach aufrufbar."""
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        _takeover.update(handle=None, since=None)
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:
        plugin.log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", level="warning")
    plugin.log(f"Bildschirm zurückgegeben ({reason}).")
    if reason not in ("gestoppt", "neu") and not _video["pending"]:
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def session_lengths():
    """Etwas länger als die Anzeigedauer; manche Rahmen erlauben nur kürzere."""
    with _show_lock:
        left = _show["until"] - now() if _show["active"] else 0
    wanted = int(max(settings()["ShowMinutes"] * 60, left)) + 60
    return sorted({min(wanted, 4 * 3600), min(wanted, 3600), min(wanted, 300)}, reverse=True)


def show_scene():
    """Die Szene über alles legen. True, wenn der Rahmen den Bildschirm hergegeben hat."""
    if not takeover_supported():
        return _note(tr("Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen."))
    if _scene["dbId"] is None:
        find_scene()
    if _scene["dbId"] is None or _scene["note"]:
        return _note(_scene["note"] or tr("Die Szene Foto Cast wurde nicht gefunden."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("Die Takeover-Playlist ist noch nicht angelegt."))
    wake = settings()["WakeScreen"]
    if not wake and display_is_off():
        hide_photos("Bildschirm aus")
        return _note(tr("Der Bildschirm ist aus; das Foto wird nicht gezeigt."))
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             # Die Szene hat ihre eigene Bildunterschrift.
             "overlay": {"enabled": False}}
    handle, limit, last_error = None, 0, None
    for seconds in session_lengths():
        try:
            _leftover["askedAt"] = time.time()
            handle = plugin.acquire_display_session(
                session_key="photo", state=state, display_name=DISPLAY_NAME,
                max_duration_seconds=seconds, wake_if_off=wake)
            limit = seconds
            break
        except Exception as exc:
            last_error = exc
    if handle is None:
        if last_error is not None:
            return _note(tr("Konnte das Foto nicht anzeigen: {exc}", exc=last_error))
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, since=now(), limit=limit, note="")
    try:
        handle.on_state_change(_on_session_state)
    except Exception:
        pass
    try:
        if not handle.wait_until_active(timeout=15):
            end_takeover("fehlgeschlagen", token)
            return _note(tr("Der Rahmen hat das Foto nicht rechtzeitig angezeigt."))
    except Exception as exc:
        end_takeover("fehlgeschlagen", token)
        return _note(tr("Konnte das Foto nicht anzeigen: {exc}", exc=exc))
    plugin.log("Foto Cast hat den Bildschirm.")
    return True


def decide_takeover():
    """Sollen Fotos zu sehen sein und hat das Plugin den Bildschirm nicht:
    holen. Ist die Zeit um oder wurde ausgeblendet: zurückgeben."""
    t = now()
    with _show_lock:
        active, until = _show["active"], _show["until"]
    if active and t >= until:
        hide_photos("Zeit abgelaufen")
        active = False
    active = active or pairing_active() is not None
    with _takeover_lock:
        handle, since, limit = _takeover["handle"], _takeover["since"], _takeover["limit"]
        retry_at, busy = _takeover["retryAt"], _takeover["busy"]
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        if not active:
            end_takeover("fertig")
        elif since and limit and t - since >= limit - 20:
            end_takeover("neu")   # gleich wieder holen, frisch mit voller Zeit
            _wake.set()
        return
    if not active or t < retry_at or busy:
        return
    with _takeover_lock:
        _takeover["busy"] = True
    try:
        if not show_scene():
            # Nicht bekommen: in 20 Sekunden noch einmal, solange Fotos zu sehen sein sollen.
            with _takeover_lock:
                _takeover["retryAt"] = t + 20
    finally:
        with _takeover_lock:
            _takeover["busy"] = False


# ---- Takeover-Playlist, die nach dem Zurückgeben weiterläuft ---------------
# Lief vor einem Takeover keine Playlist, stellt die Engine dieses "nichts"
# nicht wieder her, und die Takeover-Playlist läuft einfach weiter (Jans
# Rahmen, 2026-10-24). Jeder Durchlauf hält sie dann mit POST /slideshow/stop
# an: nur wenn sie läuft, niemand den Bildschirm hält und das Plugin nicht
# gerade selbst darum gebeten hat.
_leftover = {"askedAt": 0.0, "failed": False}


def stop_leftover_takeover():
    try:
        playlist_id = _playlists["takeoverId"]
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status", read_timeout=5) or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status", read_timeout=5) or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop", read_timeout=10)
    except Exception as exc:  # noqa: BLE001 - darf die Schleife nie aufhalten
        if not _leftover["failed"]:
            plugin.log(f"The takeover playlist kept running and could not be stopped: {exc}", level="warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    plugin.log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def check_playback_resumed():
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log,
                                                    stop_event=_stop_requested)
        if outcome == "not-requested":
            save_state(playbackStalled="")
            return
    elif _stop_requested.wait(12):
        return
    if _stop_requested.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
    except EngineError:
        return
    if status.get("isRunning") or _takeover["handle"] is not None:
        save_state(playbackStalled="")
        return
    message = tr("Der Rahmen ist nach den Fotos nicht zu deiner Playlist zurückgekehrt. Starte sie auf "
                 "der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix "
                 "passiert das nicht.")
    save_state(playbackStalled=message)
    plugin.log(message, level="warning")


# --------------------------------------------------------------------------
# Die Schleife
# --------------------------------------------------------------------------

_loop = {"lastError": ""}


def tick():
    try:
        stop_leftover_takeover()
        maintain_playlists()
        decide_takeover()
        decide_videos()
        _loop["lastError"] = ""
    except Exception as exc:  # pragma: no cover - die Schleife muss weiterlaufen
        _loop["lastError"] = str(exc)
        plugin.log(f"Durchlauf fehlgeschlagen: {exc}", level="error")


def main_loop():
    _stop_requested.wait(1)
    while not _stop_requested.is_set():
        _wake.clear()
        tick()
        busy = _takeover["handle"] is not None or _show["active"]
        _wake.wait(1 if busy else 5)


# --------------------------------------------------------------------------
# Die Seite (auf dem Rahmen und als Handy-Seite) und ihre API
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored_theme = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored_theme, dict):
        return ""
    value = next((str(v) for k, v in stored_theme.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html(phone=False):
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    if phone:
        # Auf dem Handy nur Senden und die letzten Fotos; das Einrichten bleibt auf dem Rahmen.
        return html.replace("<html", '<html data-phone="1"', 1)
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
    "/qrcode.js": ("studio/qrcode.js", "application/javascript; charset=utf-8"),
    "/icon.png": ("icon.png", "image/png"),
}


def lan_address():
    """Die Adresse des Rahmens im WLAN (es wird nichts gesendet)."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("192.0.2.1", 9))
        return probe.getsockname()[0]
    except OSError:
        return ""
    finally:
        probe.close()


def phone_url():
    if phone_server is None:
        return ""
    address = lan_address() or socket.gethostname()
    port = phone_server.server_address[1]
    return f"http://{address}:{port}/"


def scene_payload():
    values = settings()
    with _show_lock:
        show = dict(_show, ids=list(_show["ids"]))
    rows = {r["id"]: r for r in photo_index()}
    photos = [photo_public(rows[i]) for i in show["ids"] if i in rows] if show["active"] else []
    pair = pairing_active()
    return {
        "at": now(), "lang": values["Language"], "showing": bool(photos), "seq": show["seq"],
        "focus": show["focus"], "photos": photos, "slideSeconds": values["SlideSeconds"],
        "fit": values["Fit"], "caption": values["Caption"], "phoneUrl": phone_url(),
        "pair": {"code": pair["code"], "name": pair["name"], "left": max(0, int(pair["expires"] - now()))}
        if pair else None,
    }


def state_payload(phone=False):
    values = settings()
    with _show_lock:
        show = dict(_show, ids=list(_show["ids"]))
    with _takeover_lock:
        on_screen = _takeover["handle"] is not None
        note = _takeover["note"]
    recent = [photo_public(r) for r in photo_index()]
    videos, video_end = videos_on_screen()
    with _video_lock:
        video_note = _video["note"]
    payload = {
        "success": True,
        "version": version(),
        "showing": show["active"] or bool(videos), "onScreen": on_screen or bool(videos),
        "ids": (show["ids"] if show["active"] else []) + videos,
        "remaining": max(0, int((show["until"] if show["active"] else video_end) - now())),
        "recent": recent,
        "phoneUrl": phone_url(),
        "note": note or video_note or _playlists["note"] or _scene["note"],
        "permission": takeover_permission_note() if not phone else "",
        "lastError": _loop["lastError"] or load_state().get("playbackStalled") or "",
        "language": values["Language"],
        "needPin": bool(values["Pin"]) or values["Pairing"],
        "pairing": values["Pairing"],
    }
    if not phone:
        payload["settings"] = values
        payload["theme"] = {"id": theme_id()}
        payload["pillow"] = Image is not None
        payload["heif"] = pillow_heif is not None
        payload["ffmpeg"] = bool(FFMPEG)
        payload["devices"] = [{"id": r.get("id"), "name": r.get("name", ""), "at": local_text(r.get("at")),
                               "last": local_text(r.get("last"))} for r in devices()]
    return payload


def control(body, trusted=False):
    action = str(body.get("action") or "")
    if action == "hide":
        hide_photos("auf der Seite ausgeblendet")
        stop_videos()
        return {"success": True}
    if action == "show":
        ids = body.get("ids") or ([body.get("id")] if body.get("id") else [])
        ids = [str(i) for i in ids if PHOTO_ID.match(str(i))]
        return {"success": show_photos(ids)}
    if action == "last":
        rows = [r for r in photo_index() if is_ready(r)]
        return {"success": bool(rows) and show_photos([rows[0]["id"]])}
    if action == "delete":
        return {"success": delete_photo(str(body.get("id") or ""))}
    if action == "unpair" and trusted:
        return {"success": unpair(str(body.get("id") or ""))}
    if action == "extend":
        with _show_lock:
            if _show["active"]:
                _show["until"] = now() + settings()["ShowMinutes"] * 60
        return {"success": True}
    return {"success": False, "error": "Unbekannt"}


def multipart_files(content_type, body):
    """Alle Dateien aus einem Formular (multipart/form-data)."""
    message = BytesParser(policy=HTTP).parsebytes(
        b"Content-Type: " + content_type.encode("latin-1") + b"\r\n\r\n" + body)
    files = []
    for part in message.iter_parts() if message.is_multipart() else []:
        payload = part.get_payload(decode=True) or b""
        if part.get_filename() is not None or sniff(payload):
            if payload:
                files.append(payload)
    return files


def upload(content_type, length, stream, query):
    """POST /upload: das Bild oder Video als Body, oder ein Formular mit Dateien."""
    sender = re.sub(r"[\x00-\x1f<>&\"]", "", (query.get("from") or [""])[0]).strip()[:40]
    if not sender:
        sender = tr("Handy")
    if length <= 0:
        raise PhotoError(tr("Es kam kein Foto an."))
    if length > MAX_UPLOAD:
        raise PhotoError(tr("Die Datei ist zu groß (höchstens {mb} MB).", mb=MAX_UPLOAD // 1048576))
    if content_type.lower().startswith("multipart/"):
        if length > MAX_MULTIPART:
            raise PhotoError(tr("Die Datei ist zu groß (höchstens {mb} MB).", mb=MAX_MULTIPART // 1048576))
        body = stream.read(length)
        rows = [receive(data, sender) for data in multipart_files(content_type, body)]
    else:
        rows = [receive_file(save_upload(stream, length), sender)]
    if not rows:
        raise PhotoError(tr("Es kam kein Foto an."))
    waiting = [r for r in rows if r.get("state") == "converting"]
    count = len(rows)
    if waiting:
        message = tr("Angekommen. Das Video wird für den Rahmen umgewandelt und erscheint danach.")
    elif count == 1:
        message = tr("Auf dem Rahmen.")
    else:
        message = tr("{count} Fotos auf dem Rahmen.", count=count)
    return {"success": True, "message": message, "ids": [r["id"] for r in rows]}


# ---- Handys koppeln ---------------------------------------------------------
# Ist "Pairing" an, darf nur ein gekoppeltes Handy schicken. Zum Koppeln zeigt
# der Rahmen einen vierstelligen Code, den man auf der Handy-Seite eingibt;
# dafür bekommt das Handy einen eigenen Schlüssel. Den schickt es wie den
# festen Code mit (X-Pin oder ?pin=), auch aus Kurzbefehlen.
DEVICES_FILE = DATA_DIR / "devices.json"
PAIR_SECONDS = 120
PAIR_TRIES = 5
_pair_lock = threading.Lock()
_pair = {"id": "", "code": "", "name": "", "expires": 0.0, "tries": 0, "startedAt": 0.0}


def devices():
    rows = read_json(DEVICES_FILE, [])
    return rows if isinstance(rows, list) else []


def device_for(key):
    if not key:
        return None
    for row in devices():
        if secrets.compare_digest(str(row.get("key", "")), str(key)):
            return row
    return None


def pairing_active():
    with _pair_lock:
        if _pair["id"] and now() >= _pair["expires"]:
            _pair.update(id="", code="")
            _wake.set()
        return dict(_pair) if _pair["id"] else None


def pair_start(body):
    if not settings()["Pairing"]:
        return {"success": False, "error": tr("Koppeln ist auf diesem Rahmen ausgeschaltet.")}
    name = re.sub(r"[\x00-\x1f<>&\"]", "", str(body.get("name") or "")).strip()[:40] or tr("Handy")
    t = now()
    with _pair_lock:
        if _pair["id"] and t - _pair["startedAt"] < 10:
            return {"success": True, "id": _pair["id"], "seconds": int(_pair["expires"] - t)}
        _pair.update(id=secrets.token_hex(8), code=f"{secrets.randbelow(10000):04d}", name=name,
                     expires=t + PAIR_SECONDS, tries=0, startedAt=t)
        answer = {"success": True, "id": _pair["id"], "seconds": PAIR_SECONDS}
    plugin.log(f"Koppeln angefragt von {name}: Code steht auf dem Rahmen.")
    _wake.set()
    return answer


def pair_finish(body):
    given = re.sub(r"\D", "", str(body.get("code") or ""))
    with _pair_lock:
        if not _pair["id"] or now() >= _pair["expires"] or str(body.get("id") or "") != _pair["id"]:
            return {"success": False, "error": tr("Der Code ist abgelaufen. Lass dir einen neuen zeigen.")}
        if not secrets.compare_digest(given, _pair["code"]):
            _pair["tries"] += 1
            if _pair["tries"] >= PAIR_TRIES:
                _pair.update(id="", code="")
                _wake.set()
                return {"success": False, "error": tr("Zu viele falsche Versuche. Lass dir einen neuen Code zeigen.")}
            return {"success": False, "error": tr("Der Code stimmt nicht.")}
        name = _pair["name"]
        _pair.update(id="", code="")
    key = secrets.token_urlsafe(18)
    rows = devices()
    rows.append({"id": secrets.token_hex(4), "key": key, "name": name, "at": now(), "last": now()})
    write_json(DEVICES_FILE, rows[-50:])
    plugin.log(f"{name} ist jetzt mit dem Rahmen gekoppelt.")
    _wake.set()
    return {"success": True, "key": key, "name": name}


def unpair(device_id):
    rows = devices()
    kept = [r for r in rows if r.get("id") != device_id]
    if len(kept) == len(rows):
        return False
    write_json(DEVICES_FILE, kept)
    return True


def pin_ok(query, headers):
    values = settings()
    pin, pairing = values["Pin"], values["Pairing"]
    if not pin and not pairing:
        return True
    given = str((query.get("pin") or [""])[0] or headers.get("X-Pin") or "")
    if pin and secrets.compare_digest(given, pin):
        return True
    if pairing:
        row = device_for(given)
        if row is not None:
            if now() - (row.get("last") or 0) > 3600:   # nicht bei jeder Abfrage auf die SD-Karte
                rows = devices()
                for item in rows:
                    if item.get("id") == row.get("id"):
                        item["last"] = now()
                write_json(DEVICES_FILE, rows)
            return True
    return False


def need_pin(extra=None):
    """Was die Handy-Seite für den 403 braucht."""
    values = settings()
    payload = {"success": False, "needPin": True, "pairing": values["Pairing"], "hasPin": bool(values["Pin"]),
               "language": values["Language"]}
    payload.update(extra or {})
    return payload


def api(method, path, query, body, content_type="", trusted=True, headers=None, phone=False):
    """Gemeinsame Antworten für die Plugin-Seite (127.0.0.1) und die
    Handy-Seite (Port 8095). (status, content_type, bytes) oder None."""
    def js(payload, status=200):
        return status, "application/json; charset=utf-8", json.dumps(payload, ensure_ascii=False).encode("utf-8")

    headers = headers or {}
    allowed = trusted or pin_ok(query, headers)

    if path == "/hide":
        # Für einen zweiten Shortcut: Foto oder Video sofort wieder ausblenden.
        if not allowed:
            text = (tr("Dieses Handy ist nicht mit dem Rahmen gekoppelt. Öffne die Handy-Seite des Rahmens und "
                       "kopple es.") if settings()["Pairing"] else tr("Falscher Code."))
            return 403, "text/plain; charset=utf-8", text.encode("utf-8")
        control({"action": "hide"})
        return 200, "text/plain; charset=utf-8", tr("Ausgeblendet.").encode("utf-8")

    if method == "GET":
        if path in ("/", "/index.html"):
            return 200, "text/html; charset=utf-8", page_html(phone).encode("utf-8")
        asset = STUDIO_FILES.get(path)
        if asset:
            return 200, asset[1], (PLUGIN_DIR / asset[0]).read_bytes()
        if path == "/manifest.webmanifest":
            return 200, "application/manifest+json", json.dumps({
                "name": DISPLAY_NAME, "short_name": "DynaFrame", "start_url": "./", "display": "standalone",
                "background_color": "#0e1116", "theme_color": "#0e1116",
                "icons": [{"src": "icon.png", "sizes": "256x256", "type": "image/png"}]}).encode("utf-8")
        if path == "/api/scene":
            return js(scene_payload())
        if path == "/api/report":
            # Die Szene meldet per GET, das geht über jeden Weg, über den sie auch fragt.
            try:
                data = json.loads((query.get("d") or ["{}"])[0])
            except ValueError:
                data = {}
            if isinstance(data, dict):
                scene_report(data)
            return js({"success": True})
        if path == "/api/state":
            if not allowed:
                return js(need_pin(), 403)
            return js(state_payload(phone=phone))
        match = re.match(r"^/(photo|thumb)/([A-Za-z0-9_-]+)(?:\.\w+)?$", path)
        if match:
            if not allowed:
                return js(need_pin(), 403)
            row = find_photo(match.group(2))
            if row is None:
                return None
            if match.group(1) == "thumb":
                ext = row.get("thumbExt", row.get("ext", ".jpg"))
                if not ext:
                    return None
                name = f"{row['id']}.thumb{ext}"
            else:
                ext = row.get("ext", ".jpg")
                name = f"{row['id']}{ext}"
            target = PHOTO_DIR / name
            if not target.exists():
                return None
            if is_video(row) and match.group(1) == "photo":
                return "FILE", TYPES.get(ext, "video/mp4"), target
            return 200, TYPES.get(ext, "image/jpeg"), target.read_bytes()
        return None

    if method == "POST":
        data = {}
        if body:
            try:
                data = json.loads(body.decode("utf-8", "replace"))
            except ValueError:
                data = {k: v[0] for k, v in parse_qs(body.decode("utf-8", "replace")).items() if v}
        if not isinstance(data, dict):
            data = {}
        if path == "/api/report":
            scene_report(data)
            return js({"success": True})
        if path == "/api/pair/start":
            return js(pair_start(data))
        if path == "/api/pair/finish":
            return js(pair_finish(data))
        if path == "/api/control":
            if not allowed:
                return js(need_pin({"error": tr("Falscher Code.")}), 403)
            return js(control(data, trusted and not phone))
        if path == "/api/settings" and not phone:
            changed = save_settings(data)
            if "KeepPhotos" in changed or "KeepVideos" in changed:
                prune_photos()
            _wake.set()
            return js({"success": True, "changed": changed})
        return None
    return None


class Handler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"
    phone = False

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "private, max-age=86400" if content_type.startswith("image/")
                         else "no-store")
        # Die Szene kommt vom Port der Engine, diese Seite über :8003.
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _send_file(self, path, content_type):
        """Ein Video, mit Range, damit der Player springen und vorladen kann."""
        size = path.stat().st_size
        start, end = 0, size - 1
        match = re.match(r"bytes=(\d*)-(\d*)$", (self.headers.get("Range") or "").strip())
        partial = bool(match) and (match.group(1) or match.group(2))
        if partial:
            if match.group(1):
                start = int(match.group(1))
                end = min(int(match.group(2)), size - 1) if match.group(2) else size - 1
            else:
                start = max(0, size - int(match.group(2)))
            if start >= size or start > end:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{size}")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
        self.send_response(206 if partial else 200)
        self.send_header("Content-Type", content_type)
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(end - start + 1))
        if partial:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.send_header("Cache-Control", "private, max-age=86400")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        if self.command == "HEAD":
            return
        with open(path, "rb") as handle:
            handle.seek(start)
            left = end - start + 1
            try:
                while left > 0:
                    chunk = handle.read(min(left, 256 * 1024))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)
            except (BrokenPipeError, ConnectionResetError):
                self.close_connection = True

    def _body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        if length > 1024 * 1024:
            raise PhotoError(tr("Die Datei ist zu groß (höchstens {mb} MB).", mb=1))
        if length <= 0:
            return b""
        chunks, left = [], length
        while left > 0:
            chunk = self.rfile.read(min(left, 1 << 20))
            if not chunk:
                break
            chunks.append(chunk)
            left -= len(chunk)
        return b"".join(chunks)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Pin")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _route(self, method):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        trusted = not self.phone or self.client_address[0] in ("127.0.0.1", "::1")
        query = parse_qs(parsed.query)
        try:
            if method == "POST" and path in ("/upload", "/api/upload"):
                answer = self._upload(query, trusted)
            else:
                body = self._body() if method == "POST" else b""
                answer = api(method, path, query, body, self.headers.get("Content-Type") or "",
                             trusted, self.headers, self.phone)
            if answer and answer[0] == "FILE":
                self._send_file(answer[2], answer[1])
                return
        except PhotoError as exc:
            self.close_connection = True
            answer = (413, "application/json", json.dumps({"success": False, "error": str(exc)}).encode("utf-8"))
        except OSError as exc:
            answer = (500, "application/json", json.dumps(
                {"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}).encode("utf-8"))
        except Exception as exc:  # pragma: no cover
            answer = (500, "application/json", json.dumps({"success": False, "error": str(exc)}).encode("utf-8"))
        if answer is None:
            answer = (404, "application/json", b'{"success": false, "error": "Nicht gefunden"}')
        self._send(answer[2], answer[1], answer[0])

    def _upload(self, query, trusted):
        # Kurzbefehl-Apps (HTTP Shortcuts, iPhone-Kurzbefehle) zeigen die Antwort
        # als Meldung an: dann nur der Satz, kein JSON.
        plain = ((query.get("format") or [""])[0] == "text"
                 or "shortcuts" in (self.headers.get("User-Agent") or "").lower())

        def js(payload, status=200):
            if plain:
                return status, "text/plain; charset=utf-8", str(payload.get("message") or payload.get("error")
                                                                 or "").encode("utf-8")
            return status, "application/json; charset=utf-8", json.dumps(payload, ensure_ascii=False).encode()
        length = as_int(self.headers.get("Content-Length"), 0)
        if not (trusted or pin_ok(query, self.headers)):
            self.close_connection = True
            return js(need_pin({"error": tr("Dieses Handy ist nicht mit dem Rahmen gekoppelt. Öffne die "
                                            "Handy-Seite des Rahmens und kopple es.")
                                 if settings()["Pairing"] else tr("Falscher Code.")}), 403)
        try:
            return js(upload(self.headers.get("Content-Type") or "", length, self.rfile, query))
        except PhotoError as exc:
            self.close_connection = True
            return js({"success": False, "error": str(exc)}, 400)

    def do_GET(self):
        self._route("GET")

    def do_HEAD(self):
        self._route("GET")

    def do_POST(self):
        self._route("POST")


class PhoneHandler(Handler):
    phone = True


studio_server = None
phone_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    studio_server.daemon_threads = True
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin-Seite unter {url}")
    return url


def start_phone():
    """Die Handy-Seite und der Upload, im ganzen WLAN erreichbar."""
    global phone_server
    for port in PHONE_PORTS:
        try:
            phone_server = ThreadingHTTPServer(("0.0.0.0", port), PhoneHandler)
            break
        except OSError as exc:
            plugin.log(f"Port {port} ist belegt ({exc}).", level="warning")
    if phone_server is None:
        _note(tr("Kein freier Port für die Handy-Seite (8095 bis 8098)."))
        return
    phone_server.daemon_threads = True
    threading.Thread(target=phone_server.serve_forever, name=f"{PLUGIN_ID}-phone", daemon=True).start()
    plugin.log(f"Handy-Seite: {phone_url()}")


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    plugin.log(f"Starte {PLUGIN_ID} {version()}" + ("" if Image else " (ohne Pillow)"))

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("hide", lambda _context=None: control({"action": "hide"}))
    plugin.on_action("last", lambda _context=None: control({"action": "last"}))

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    start_phone()
    threading.Thread(target=main_loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    threading.Thread(target=convert_loop, name=f"{PLUGIN_ID}-convert", daemon=True).start()
    plugin.log(f"ffmpeg: {FFMPEG or 'nicht da'}, HEIC: {'ja' if pillow_heif else 'nein'}")
    try:
        while not _stop_requested.is_set() and getattr(plugin, "is_running", lambda: True)():
            _stop_requested.wait(5)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    with _show_lock:
        _show["active"] = False
    end_takeover("gestoppt")
    _convert_wake.set()
    if _converting["proc"] is not None:
        try:
            _converting["proc"].kill()
        except OSError:
            pass
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    for server in (studio_server, phone_server):
        if server is not None:
            try:
                server.shutdown()
                server.server_close()
            except Exception:
                pass
    plugin.log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
