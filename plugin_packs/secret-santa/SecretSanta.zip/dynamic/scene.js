/* Secret Santa - die Szene.
 *
 * Fragt jede Sekunde api/scene und zeigt je nach Stand:
 *   signup  - wer schon dabei ist (Namensanhänger), großer QR-Code.
 *   drawn   - Countdown zur Bescherung, wie viele ihr Los angesehen und ihr
 *             Geschenk schon haben. Nie, wer wen hat. Direkt nach dem
 *             Auslosen fliegen die Namen in eine Geschenkkiste.
 *   giving  - „Frohe Bescherung!“
 *   reveal  - die Auflösung: je Paar „Wer war der Wichtel von …?“, Trommel-
 *             wirbel, dann der Name. Das Plugin gibt die Schritte erst frei,
 *             wenn sie dran sind, und gibt den Takt vor (auch für den Ton).
 *   done    - alle Paare als Kette.
 * Zum Ausprobieren: ?plugin=<URL der Plugin-Seite>
 */
(function () {
  "use strict";

  const PLUGIN_ID = "SecretSanta";
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const sameOrigin = (location.protocol === "http:" && (location.port === "" || location.port === "80"))
    || (location.protocol === "https:" && (location.port === "" || location.port === "443"));
  const pluginBases = params.get("plugin") ? [params.get("plugin").replace(/\/?$/, "/")] : [...new Set(sameOrigin ? [
    `${location.origin}${advanced}`,
    `${location.protocol}//${location.hostname}:8003${advanced}`
  ] : [
    `${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`,
    `http://${location.hostname || "localhost"}${advanced}`
  ])];
  let baseIndex = 0;

  const TEXT = {
    de: {
      kicker: "Wichteln", join: "Macht mit!", joinLead: "Scannt den Code mit dem Handy: Name, PIN und Wunschliste. Wenn alle dabei sind, lost der Rahmen geheim aus.",
      joinClosed: "Die Anmeldung ist geschlossen.", code: "Code {code}", scan: "Mit dem Handy scannen, keine App nötig",
      corner: "Nochmal nachsehen, wen du beschenkst", empty: "Wer macht als Erstes mit?",
      budget: "Budget <b>{b}</b>", gift: "Bescherung <b>{when}</b>", people: "<b>{n}</b> dabei", drawAt: "Auslosung <b>{when}</b>",
      drawnKicker: "Die Lose sind gezogen", untilGift: "Noch bis zur Bescherung", days: "Tage", day1: "Tag", hours: "Stunden", mins: "Minuten", secs: "Sekunden",
      seen: "<b>{n}</b> von {m} haben ihr Los angesehen", ready: "<b>{n}</b> von {m} Geschenken sind besorgt",
      shTitle: "Die Lose sind gezogen!", shLead: "Jeder schaut jetzt auf sein eigenes Handy, wen er beschenkt. Pssst, nichts verraten!",
      gvKicker: "Es ist so weit", gvTitle: "Frohe Bescherung!", gvLead: "Gleich verrät der Fernseher, wer wessen Wichtel war.", gvLeadNoDraw: "",
      rvKicker: "Die große Auflösung", rvTitle: "Wer war wessen Wichtel?", rvLead: "Trommelwirbel, bitte …",
      step: "{i} von {n}", question: "Wer war der Wichtel von", doneKicker: "Aufgelöst", arrowHint: "Jeder Pfeil zeigt, wen jemand beschenkt hat.", doneTitle: "So wurde gewichtelt",
      unreachable: "Secret Santa antwortet nicht.", login: "Bitte zuerst im Browser beim Rahmen anmelden.", noPhone: "Die Handy-Seite läuft gerade nicht."
    },
    en: {
      kicker: "Secret Santa", join: "Join in!", joinLead: "Scan the code with your phone: name, PIN and wish list. Once everyone is in, the frame draws in secret.",
      joinClosed: "Sign-up is closed.", code: "Code {code}", scan: "Scan with your phone, no app needed",
      corner: "Look again whom you give to", empty: "Who joins first?",
      budget: "Budget <b>{b}</b>", gift: "Gift-giving <b>{when}</b>", people: "<b>{n}</b> in", drawAt: "Draw <b>{when}</b>",
      drawnKicker: "The lots are drawn", untilGift: "Until gift-giving", days: "days", day1: "day", hours: "hours", mins: "minutes", secs: "seconds",
      seen: "<b>{n}</b> of {m} have looked at their lot", ready: "<b>{n}</b> of {m} presents are ready",
      shTitle: "The lots are drawn!", shLead: "Everyone now checks their own phone to see whom they give a present to. Shh, don't tell!",
      gvKicker: "It's time", gvTitle: "Merry gift-giving!", gvLead: "Soon the TV reveals who was whose Secret Santa.", gvLeadNoDraw: "",
      rvKicker: "The big reveal", rvTitle: "Who was whose Secret Santa?", rvLead: "Drum roll, please …",
      step: "{i} of {n}", question: "Who was Secret Santa for", doneKicker: "Revealed", arrowHint: "Each arrow points to the person someone gave a present to.", doneTitle: "This is how it went",
      unreachable: "Secret Santa is not responding.", login: "Please sign in to the frame in the browser first.", noPhone: "The phone page is not running right now."
    },
    es: {
      kicker: "Amigo invisible", join: "¡Apuntaos!", joinLead: "Escanead el código con el móvil: nombre, PIN y lista de deseos. Cuando estéis todos, el marco hace el sorteo en secreto.",
      joinClosed: "La inscripción está cerrada.", code: "Código {code}", scan: "Escanéalo con el móvil, sin app",
      corner: "Vuelve a mirar a quién le regalas", empty: "¿Quién se apunta primero?",
      budget: "Presupuesto <b>{b}</b>", gift: "Entrega <b>{when}</b>", people: "<b>{n}</b> apuntados", drawAt: "Sorteo <b>{when}</b>",
      drawnKicker: "Ya está hecho el sorteo", untilGift: "Hasta la entrega de regalos", days: "días", day1: "día", hours: "horas", mins: "minutos", secs: "segundos",
      seen: "<b>{n}</b> de {m} han mirado su papelito", ready: "<b>{n}</b> de {m} regalos ya están listos",
      shTitle: "¡Ya está hecho el sorteo!", shLead: "Cada uno mira ahora en su propio móvil a quién le hace el regalo. ¡Chis, no lo digáis!",
      gvKicker: "Ha llegado el momento", gvTitle: "¡A abrir los regalos!", gvLead: "Enseguida la tele desvela quién era el amigo invisible de quién.", gvLeadNoDraw: "",
      rvKicker: "La gran revelación", rvTitle: "¿Quién era el amigo invisible de quién?", rvLead: "Redoble de tambor, por favor …",
      step: "{i} de {n}", question: "¿Quién era el amigo invisible de", doneKicker: "Desvelado", arrowHint: "Cada flecha apunta a quien recibió el regalo de cada uno.", doneTitle: "Así fue el amigo invisible",
      unreachable: "Secret Santa no responde.", login: "Inicia sesión primero en el marco desde el navegador.", noPhone: "La página del móvil no está funcionando ahora."
    }
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  let lang = params.get("lang") || "en";
  const tx = (key, values) => {
    let text = (TEXT[lang] || TEXT.en)[key] ?? TEXT.en[key] ?? key;
    for (const [k, v] of Object.entries(values || {})) text = text.split(`{${k}}`).join(v);
    return text;
  };
  const $ = (id) => document.getElementById(id);
  const esc = (text) => String(text ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const when = (epoch) => new Date(epoch * 1000).toLocaleString(LOCALES[lang] || "en-GB", { weekday: "long", day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" });
  const rnd = (a, b) => a + Math.random() * (b - a);
  const hash = (s) => { let h = 7; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) | 0; return Math.abs(h); };

  // ------------------------------------------------------------ Plugin

  async function api(path) {
    let lastError = null;
    for (let i = 0; i < pluginBases.length; i += 1) {
      const base = pluginBases[(baseIndex + i) % pluginBases.length];
      try {
        const response = await fetch(base + path, { cache: "no-store", credentials: "same-origin" });
        if (response.redirected && /login/i.test(response.url)) throw new Error("login");
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const body = await response.json();
        baseIndex = (baseIndex + i) % pluginBases.length;
        return body;
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error("unreachable");
  }
  function report(message) {
    api("api/report?m=" + encodeURIComponent(String(message).slice(0, 180))).catch(() => {});
  }
  addEventListener("error", (e) => report(`${e.message} ${e.filename || ""}:${e.lineno || ""}`));

  // DynaFrame wartet, bis die Szene meldet, dass sie steht.
  let readySent = false;
  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 8000);

  function showNote(text) {
    $("note").textContent = text || "";
    $("note").hidden = !text;
    if (text) ready();
  }

  // ------------------------------------------------------------ Größe, Schnee

  function layout() {
    const w = innerWidth, h = innerHeight;
    document.documentElement.style.setProperty("--u", `${Math.min(w, h * 1.6) / 160}px`);
    document.body.classList.toggle("portrait", h > w * 1.05);
    const c = $("snow");
    c.width = w; c.height = h;
  }
  addEventListener("resize", layout);

  const flakes = [];
  let snowOn = true;
  function snowFrame() {
    const c = $("snow");
    const ctx = c.getContext("2d");
    ctx.clearRect(0, 0, c.width, c.height);
    if (snowOn) {
      while (flakes.length < Math.min(110, (c.width * c.height) / 18000)) {
        flakes.push({ x: Math.random() * c.width, y: Math.random() * c.height, r: rnd(1, 3.6), s: rnd(.3, 1.1), w: rnd(0, 6.28) });
      }
      ctx.fillStyle = getComputedStyle(document.body).getPropertyValue("--snow") || "#fff";
      for (const f of flakes) {
        f.y += f.s * (c.height / 900);
        f.w += 0.01;
        f.x += Math.sin(f.w) * 0.35;
        if (f.y > c.height + 5) { f.y = -5; f.x = Math.random() * c.width; }
        ctx.globalAlpha = 0.35 + f.r / 6;
        ctx.beginPath();
        ctx.arc(f.x, f.y, f.r, 0, 6.283);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }
    setTimeout(() => requestAnimationFrame(snowFrame), 33);
  }

  function confetti(n = 90) {
    const box = $("confetti");
    const colors = ["#f2c45a", "#d4363a", "#2f8f6b", "#ffffff", "#e9a6a6"];
    for (let i = 0; i < n; i += 1) {
      const p = document.createElement("i");
      p.style.left = `${rnd(0, 100)}vw`;
      p.style.background = colors[i % colors.length];
      p.style.setProperty("--dx", `${rnd(-20, 20)}vw`);
      p.style.setProperty("--rot", `${rnd(-720, 720)}deg`);
      p.style.animationDuration = `${rnd(2.6, 4.6)}s`;
      p.style.animationDelay = `${rnd(0, .5)}s`;
      box.appendChild(p);
      setTimeout(() => p.remove(), 5600);
    }
  }

  // ------------------------------------------------------------ QR-Code

  const qrDone = {};
  function drawQr(id, url) {
    if (!url || qrDone[id] === url || typeof qrcode !== "function") return;
    qrDone[id] = url;
    const qr = qrcode(0, "M");
    qr.addData(url);
    qr.make();
    $(id).innerHTML = qr.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
  }
  const joinUrl = () => (state && state.url ? `${state.url}?c=${state.code}` : "");

  // ------------------------------------------------------------ Zustand

  let state = null;
  let offset = 0;                 // Uhr des Plugins minus Uhr der Szene
  let view = "";
  const serverNow = () => Date.now() / 1000 + offset;

  function setView(id) {
    if (view === id) return;
    view = id;
    for (const v of ["signup", "drawn", "shuffle", "giving", "reveal", "done"]) $(v).hidden = v !== id;
    ready();
  }

  function chips(target, items) {
    $(target).innerHTML = items.filter(Boolean).map((html) => `<span class="chip">${html}</span>`).join("");
  }

  // ---- Anmeldung
  const tagSeen = new Set();
  function renderSignup() {
    setView("signup");
    $("suKicker").textContent = tx("kicker");
    $("suTitle").textContent = state.title;
    $("suLead").textContent = state.signupOpen ? tx("joinLead") : tx("joinClosed");
    chips("suChips", [state.budget && tx("budget", { b: esc(state.budget) }), state.gift && tx("gift", { when: esc(when(state.gift)) }),
      state.drawAt && tx("drawAt", { when: esc(when(state.drawAt)) })]);
    const box = $("suTags");
    const names = state.names;
    if (box.dataset.key !== names.join("|")) {
      box.dataset.key = names.join("|");
      if (!names.length) {
        box.innerHTML = `<span class="lead">${esc(tx("empty"))}</span>`;
      } else {
        const first = tagSeen.size === 0;
        box.innerHTML = names.map((n) => {
          const r = (hash(n) % 9) - 4;
          const fresh = !first && !tagSeen.has(n);
          return `<span class="tag${fresh ? " pop" : ""}" style="--r:${r}deg">${esc(n)}</span>`;
        }).join("");
        names.forEach((n) => tagSeen.add(n));
      }
    }
    drawQr("qrBig", joinUrl());
    $("codeBig").textContent = tx("code", { code: state.code });
    $("joinBig").textContent = state.url ? tx("scan") : tx("noPhone");
    document.querySelector(".join.big").hidden = !state.showQr || !state.signupOpen;
  }

  // ---- Countdown
  function countdownCells(target) {
    let left = Math.max(0, Math.floor(target - serverNow()));
    const d = Math.floor(left / 86400); left -= d * 86400;
    const h = Math.floor(left / 3600); left -= h * 3600;
    const m = Math.floor(left / 60); const s = left - m * 60;
    const cell = (n, k) => `<div><b>${String(n).padStart(2, "0")}</b><small>${esc(tx(k))}</small></div>`;
    return (d ? cell(d, d === 1 ? "day1" : "days") : "") + cell(h, "hours") + cell(m, "mins") + cell(s, "secs");
  }
  function dots(n, on) {
    return Array.from({ length: n }, (_, i) => `<i class="${i < on ? "on" : ""}"></i>`).join("");
  }
  function renderDrawn() {
    setView("drawn");
    const st = state.stats;
    $("drKicker").textContent = tx("drawnKicker");
    $("drTitle").textContent = state.title;
    $("drCountdown").innerHTML = state.gift ? countdownCells(state.gift) : "";
    $("drCountdown").hidden = !state.gift;
    $("drWhen").textContent = state.gift ? tx("untilGift") + " · " + when(state.gift) : "";
    $("drSeen").innerHTML = tx("seen", { n: st.seen, m: st.count });
    $("drReady").innerHTML = tx("ready", { n: st.ready, m: st.count });
    $("drSeenDots").innerHTML = dots(st.count, st.seen);
    $("drReadyDots").innerHTML = dots(st.count, st.ready);
    chips("drChips", [state.budget && tx("budget", { b: esc(state.budget) }), tx("people", { n: st.count })]);
  }

  // ---- Gerade ausgelost: Kiste
  let shuffleFor = 0;
  async function runShuffle() {
    const key = state.stats.drawnAt;
    if (shuffleFor === key) return;
    shuffleFor = key;
    setView("shuffle");
    $("shTitle").textContent = "";
    $("shLead").textContent = "";
    const stage = $("boxStage");
    stage.querySelectorAll(".flytag").forEach((n) => n.remove());
    const box = $("box");
    box.classList.add("open");
    box.classList.remove("shake");
    const W = stage.clientWidth, H = stage.clientHeight;
    const target = box.getBoundingClientRect();
    const sr = stage.getBoundingClientRect();
    const tx0 = target.left - sr.left + target.width / 2, ty0 = target.top - sr.top + target.height * 0.25;
    const tags = state.names.map((n, i) => {
      const tag = document.createElement("span");
      tag.className = "tag flytag";
      tag.textContent = n;
      const angle = (i / Math.max(1, state.names.length)) * Math.PI * 2;
      const x = W / 2 + Math.cos(angle) * W * 0.36, y = H * 0.42 + Math.sin(angle) * H * 0.3;
      tag.style.left = `${x}px`;
      tag.style.top = `${y}px`;
      tag.style.setProperty("--r", `${(hash(n) % 9) - 4}deg`);
      tag.style.transform = "translate(-50%, -50%)";
      stage.appendChild(tag);
      return { tag, x, y };
    });
    ready();
    await new Promise((r) => setTimeout(r, 1200));
    tags.forEach(({ tag, x, y }, i) => {
      setTimeout(() => {
        tag.style.transform = `translate(calc(-50% + ${tx0 - x}px), calc(-50% + ${ty0 - y}px)) scale(.3) rotate(${rnd(-90, 90)}deg)`;
        tag.style.opacity = "0";
      }, i * 160);
    });
    await new Promise((r) => setTimeout(r, tags.length * 160 + 1400));
    box.classList.remove("open");
    await new Promise((r) => setTimeout(r, 500));
    box.classList.add("shake");
    await new Promise((r) => setTimeout(r, 2600));
    box.classList.remove("shake");
    $("shTitle").textContent = tx("shTitle");
    $("shLead").textContent = tx("shLead");
    confetti(70);
  }

  // ---- Bescherung
  function renderGiving() {
    setView("giving");
    $("gvKicker").textContent = tx("gvKicker");
    $("gvTitle").textContent = tx("gvTitle");
    $("gvLead").textContent = tx("gvLead");
  }

  // ---- Auflösung
  let rvKey = "";
  function renderReveal() {
    setView("reveal");
    const rev = state.reveal;
    if (!rev) return;
    const t = serverNow();
    const inIntro = t < rev.started + rev.intro;
    $("rvIntro").hidden = !inIntro;
    $("rvStage").hidden = inIntro;
    $("rvIntroKicker").textContent = tx("rvKicker");
    $("rvIntroTitle").textContent = tx("rvTitle");
    $("rvIntroLead").textContent = tx("rvLead");
    const drumBig = document.querySelector(".drum.big");
    drumBig.classList.toggle("roll", inIntro && t > rev.started + rev.intro - 3);
    const index = Math.min(rev.count - 1, Math.floor((t - rev.started - rev.intro) / rev.step));
    const trailRows = [];
    rev.shown.forEach((row, i) => {
      if (row.giver && (i < index || (i === index && t >= rev.started + rev.intro + i * rev.step + rev.drum))) trailRows.push(row);
    });
    const trailKey = trailRows.map((r) => r.giver + r.receiver).join("|");
    if ($("rvTrail").dataset.key !== trailKey) {
      $("rvTrail").dataset.key = trailKey;
      $("rvTrail").innerHTML = trailRows.map((r) => `<span class="pair">${esc(r.giver)} <span class="arrow">→</span> ${esc(r.receiver)}</span>`).join("");
    }
    if (inIntro || index < 0) return;
    const row = rev.shown[index];
    if (!row) return;
    const start = rev.started + rev.intro + index * rev.step;
    const key = `${rev.id}:${index}`;
    if (rvKey !== key) {
      rvKey = key;
      $("rvCount").textContent = tx("step", { i: index + 1, n: rev.count });
      $("rvQuestion").textContent = tx("question") + (lang === "es" ? "…" : " …");
      $("rvReceiver").textContent = lang === "es" ? `${row.receiver}?` : `${row.receiver}?`;
      $("rvGiver").textContent = "";
      $("rvGiver").classList.remove("show");
      $("rvDrum").classList.remove("away");
      $("rvDrum").classList.add("roll");
    }
    const due = t >= start + rev.drum;
    if (due && row.giver && !$("rvGiver").classList.contains("show")) {
      $("rvDrum").classList.remove("roll");
      $("rvDrum").classList.add("away");
      $("rvGiver").textContent = row.giver;
      $("rvGiver").classList.add("show");
      confetti(row.chainEnd ? 140 : 80);
    }
  }

  // ---- Alles aufgelöst
  let doneKey = "";
  function renderDone() {
    setView("done");
    const rev = state.reveal;
    $("dnKicker").textContent = tx("doneKicker");
    $("dnTitle").textContent = state.title;
    if (!rev) return;
    const rows = rev.shown.filter((r) => r.giver);
    const key = rows.map((r) => r.giver + ">" + r.receiver).join("|") + innerWidth + "x" + innerHeight;
    if (doneKey === key) return;
    doneKey = key;
    const ring = $("dnRing");
    const chains = rows.filter((r) => r.chainEnd).length;
    if (chains !== 1 || rows.length > 18 || rows.length < 3) {
      ring.innerHTML = `<div class="grid">${rows.map((r) => `<span class="pair">${esc(r.giver)} <span class="arrow">→</span> ${esc(r.receiver)}</span>`).join("")}</div>`;
      return;
    }
    const W = ring.clientWidth, H = ring.clientHeight;
    const cx = W / 2, cy = H / 2;
    const rx = W * 0.38, ry = H * 0.4;
    const n = rows.length;
    const pts = rows.map((_, i) => {
      const a = -Math.PI / 2 + (i / n) * Math.PI * 2;
      return [cx + Math.cos(a) * rx, cy + Math.sin(a) * ry];
    });
    const fs = n > 12 ? 2.4 : n > 8 ? 2.9 : 3.4;
    let svg = `<svg viewBox="0 0 ${W} ${H}"><defs><marker id="ah" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#f2c45a"/></marker></defs>`;
    for (let i = 0; i < n; i += 1) {
      const [x1, y1] = pts[i], [x2, y2] = pts[(i + 1) % n];
      // etwas nach außen gebogen, und an den Enden gekürzt
      const mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
      const ox = (mx - cx) * 0.18, oy = (my - cy) * 0.18;
      const sx = x1 + (x2 - x1) * 0.2, sy = y1 + (y2 - y1) * 0.2, ex = x1 + (x2 - x1) * 0.8, ey = y1 + (y2 - y1) * 0.8;
      svg += `<path d="M${sx} ${sy} Q${mx + ox} ${my + oy} ${ex} ${ey}" fill="none" stroke="#f2c45a" stroke-width="3" stroke-dasharray="2 9" stroke-linecap="round" marker-end="url(#ah)" opacity=".9"/>`;
    }
    svg += "</svg>";
    ring.innerHTML = svg + `<p class="center">${esc(tx("arrowHint"))}</p>` + rows.map((r, i) => `<span class="node" style="left:${pts[i][0]}px;top:${pts[i][1]}px;--fs:${fs};animation-delay:${i * 0.12}s">${esc(r.giver)}</span>`).join("");
  }

  // ------------------------------------------------------------ Ablauf

  function corner() {
    const show = state && state.showQr && state.url && ["drawn", "giving"].includes(view);
    $("corner").hidden = !show;
    if (show) {
      drawQr("qrCorner", joinUrl());
      $("joinCorner").textContent = tx("corner");
      $("codeCorner").textContent = tx("code", { code: state.code });
    }
  }

  function render() {
    if (!state) return;
    const mode = state.mode;
    if (mode === "signup") renderSignup();
    else if (mode === "drawn" && state.focus === "drawn" && shuffleFor !== state.stats.drawnAt) runShuffle();
    else if (mode === "drawn" && view === "shuffle" && state.focus === "drawn") { /* Kiste läuft noch */ }
    else if (mode === "drawn") renderDrawn();
    else if (mode === "giving") renderGiving();
    else if (mode === "reveal") renderReveal();
    else if (mode === "done") renderDone();
    corner();
  }

  let failures = 0;
  async function poll() {
    try {
      const next = await api("api/scene");
      failures = 0;
      showNote("");
      if (next.now) offset = next.now - Date.now() / 1000;
      if (next.lang && next.lang !== lang) lang = next.lang;
      document.body.className = `theme-${next.theme || "cozy"}${document.body.classList.contains("portrait") ? " portrait" : ""}`;
      snowOn = next.snow !== false;
      document.documentElement.lang = lang;
      state = next;
      render();
    } catch (error) {
      failures += 1;
      if (failures > 2) showNote(String(error.message) === "login" ? tx("login") : tx("unreachable"));
    }
    setTimeout(poll, state && state.mode === "reveal" ? 700 : 1500);
  }
  // Zwischen zwei Antworten: Countdown und Auflösung im Takt weiterführen.
  setInterval(() => {
    if (!state) return;
    if (view === "drawn") $("drCountdown").innerHTML = state.gift ? countdownCells(state.gift) : "";
    if (view === "reveal") renderReveal();
  }, 200);

  layout();
  snowFrame();
  poll();
})();
