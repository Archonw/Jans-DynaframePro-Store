# Third-party notes

- Weather data by Open-Meteo.com (https://open-meteo.com), licensed under CC BY 4.0; historical data from the ERA5 reanalysis (Copernicus Climate Change Service).
- Place names from OpenStreetMap via Nominatim, © OpenStreetMap contributors, ODbL.
- Map data (coastlines, lakes, rivers, borders) from Natural Earth (public domain), as in the Travel Map plugin.
- The scene bundles the font Caveat under the SIL Open Font License 1.1 (`dynamic/fonts/OFL-Caveat.txt`) and the font Special Elite under the Apache License 2.0 (`dynamic/fonts/LICENSE-SpecialElite.txt`).
- `exif_gps.py` is shared with the Travel Map plugin, `immich_filters.py`, `dynaframe_filters.py` and `own_playlist.py` with the other plugins of this store (own code).
