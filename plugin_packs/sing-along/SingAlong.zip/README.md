# Sing-along

Karaoke on the side. While music plays via Music Assistant, Spotify or
Jellyfin, the frame shows the lyrics line by line in time with the song,
together with the album cover and the song's progress. The current line lights
up from left to right like in a karaoke bar; instrumental breaks show three
dots that light up one after another.

## Where the lyrics come from

[LRCLIB](https://lrclib.net) is a free collection of synced lyrics. It needs no
account and no key. Songs found once are remembered on the frame, so LRCLIB is
asked only once per song. If a Pi-hole or another filter is in use, allow
`lrclib.net`.

## Music sources (one is enough)

- **Music Assistant**: address (port 8095) and a token. Taken from Playlist
  Music if it already has them. Optionally only one player.
- **Spotify on this frame**: if Playlist Music plays Spotify on the frame
  (Spotify Connect), nothing else is needed.
- **Spotify account**: sees what plays on your phone, an Echo or a computer.
  Needs your own small Spotify app (free, Client ID only, no secret) and one
  sign-in; the plugin page explains the steps.
- **Jellyfin**: address (port 8096) and an API key. Taken from Jellyfin Now
  Playing or Playlist Music if they already have them.

## On the screen

- **By itself while music plays** (needs "Allow takeover" on the Plugins page):
  as soon as a song with lyrics plays, the scene slides over your photos and
  hands the screen back once the music has stopped for a while.
- **In a playlist**: the card "A playlist for it" creates the Sing-along
  playlist, or add the scene to any playlist yourself.

Three layouts (cover and lyrics side by side, cover as background, lyrics only),
three text sizes and an offset if the lyrics run ahead of or behind the music.
A connections card shows whether LRCLIB and the music sources can be reached.

Page and scene in German, English or Spanish.
