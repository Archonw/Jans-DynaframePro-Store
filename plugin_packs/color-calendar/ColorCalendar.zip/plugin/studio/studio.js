"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/ColorCalendar/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["YearsMax", "PhotoSeconds", "PhotoPause", "RefreshHours", "PlaylistSeconds"];
const CHECK_FIELDS = ["Vivid", "FillGaps", "MonthColours", "ShowStats", "ShowPhotos", "FavoritesOnly", "IncludeArchived"];
const SELECT_FIELDS = ["Layout", "Period", "Year", "Background", "CellShape", "DayOrder", "MinRating"];
const TEXT_FIELDS = ["ServerUrl", "Title", "Folders"];
const KINDS = ["library", "playlist", "immich_album", "immich_all"];
const MAX_SOURCES = 6;
let current = null;
let editing = false;
let sources = [];
let rendered = "";
let pendingCommits = 0, lastEdit = 0, lastCommitDone = 0;
let commitChain = Promise.resolve();
const lists = { playlist: null, immich_album: null };
const listErrors = { playlist: "", immich_album: "" };

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["Farbkalender", "Colour Calendar", "Calendario de colores"],
  lede: ["Dein Jahr als Kalender aus Farben: Jeder Tag bekommt die Farbe der Fotos, die an diesem Tag entstanden sind. So siehst du Sommer, Urlaube, Winter und Weihnachten als Farbband. Jede Änderung hier wird sofort gespeichert.",
    "Your year as a calendar of colours: every day takes the colour of the photos you took that day, so summers, holidays, winters and Christmas show up as a band of colour. Every change here is saved immediately.",
    "Tu año como un calendario de colores: cada día toma el color de las fotos que hiciste ese día, así ves veranos, vacaciones, inviernos y Navidad como una franja de color. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  refresh: ["Fotos neu einlesen", "Read photos again", "Volver a leer las fotos"],
  playlist: ["Playlist anlegen", "Create playlist", "Crear lista"],
  factNow: ["Gerade", "Now", "Ahora"],
  factDays: ["Im Kalender", "In the calendar", "En el calendario"],
  factSpan: ["Fotos von", "Photos from", "Fotos de"],
  factRead: ["Zuletzt eingelesen", "Last read", "Última lectura"],
  factVersion: ["Version", "Version", "Versión"],
  nowBusy: ["Liest Fotos ein …", "Reading photos …", "Leyendo fotos …"],
  nowList: ["Sucht Fotos … {n}", "Finding photos … {n}", "Buscando fotos … {n}"],
  nowColours: ["Liest Farben: {done} von {todo}", "Reading colours: {done} of {todo}", "Leyendo colores: {done} de {todo}"],
  nowIdle: ["Bereit", "Ready", "Listo"],
  daysState: ["{photos} Fotos an {days} Tagen", "{photos} photos on {days} days", "{photos} fotos en {days} días"],
  span: ["{first} bis {last}", "{first} to {last}", "{first} a {last}"],
  skipped: ["{n} Fotos ohne Datum oder Farbe sind nicht im Kalender.", "{n} photos without a date or colour are not in the calendar.", "{n} fotos sin fecha o color no están en el calendario."],
  sourcesTitle: ["Fotos", "Photos", "Fotos"],
  sourcesHint: ["Woher die Fotos kommen. Mehrere Quellen werden zu einem Kalender zusammengelegt. Fotos ohne Aufnahmedatum zählen nicht.",
    "Where the photos come from. Several sources are merged into one calendar. Photos without a date taken don't count.",
    "De dónde vienen las fotos. Varias fuentes se unen en un solo calendario. Las fotos sin fecha de captura no cuentan."],
  add: ["Quelle hinzufügen", "Add source", "Añadir fuente"],
  remove: ["Entfernen", "Remove", "Quitar"],
  kind: ["Fotos aus", "Photos from", "Fotos de"],
  kind_library: ["Allen Fotos in DynaFrame", "All photos in DynaFrame", "Todas las fotos de DynaFrame"],
  kind_playlist: ["Einer Playlist von DynaFrame", "A DynaFrame playlist", "Una lista de DynaFrame"],
  kind_immich_album: ["Einem Immich-Album", "An Immich album", "Un álbum de Immich"],
  kind_immich_all: ["Allen Fotos in Immich", "All photos in Immich", "Todas las fotos de Immich"],
  ref_playlist: ["Playlist", "Playlist", "Lista"],
  ref_immich_album: ["Album", "Album", "Álbum"],
  ref_none: ["Keine Auswahl nötig", "Nothing to pick", "Nada que elegir"],
  pick: ["Bitte wählen …", "Please pick …", "Elige …"],
  loading: ["Lädt …", "Loading …", "Cargando …"],
  label: ["Eigener Name (optional)", "Own name (optional)", "Nombre propio (opcional)"],
  srcBusy: ["Wird eingelesen …", "Reading …", "Leyendo …"],
  srcWait: ["Wartet auf das Einlesen …", "Waiting to be read …", "Esperando la lectura …"],
  srcOk: ["{dated} von {total} Fotos haben ein Datum.", "{dated} of {total} photos have a date.", "{dated} de {total} fotos tienen fecha."],
  max: ["Mehr als sechs Quellen gehen nicht.", "No more than six sources.", "No caben más de seis fuentes."],
  calTitle: ["Kalender", "Calendar", "Calendario"],
  layout: ["Form", "Shape", "Forma"],
  layoutMonths: ["Monate (eine Zeile je Monat)", "Months (a row per month)", "Meses (una fila por mes)"],
  layoutWeeks: ["Wochen (wie ein Wandplaner)", "Weeks (like a wall planner)", "Semanas (como un planificador)"],
  layoutRing: ["Ring (das Jahr als Kreis)", "Ring (the year as a circle)", "Anillo (el año como círculo)"],
  layoutStripes: ["Streifen (ein Band je Jahr)", "Stripes (a band per year)", "Franjas (una banda por año)"],
  period: ["Zeitraum", "Period", "Periodo"],
  periodLast12: ["Die letzten 12 Monate", "The last 12 months", "Los últimos 12 meses"],
  periodYear: ["Dieses Kalenderjahr", "This calendar year", "Este año natural"],
  periodPick: ["Ein Jahr nach Wahl", "One year of my choice", "Un año a elegir"],
  periodAll: ["Mehrere Jahre", "Several years", "Varios años"],
  year: ["Jahr", "Year", "Año"],
  yearsMax: ["Höchstens … Jahre", "At most … years", "Como máximo … años"],
  periodHint: ["Mehrere Jahre zeigt der Ring als Ringe ineinander und die Streifen als ein Band je Jahr. Bei Monaten oder Wochen zeigt die Szene dann Streifen.",
    "Several years show as rings inside each other (Ring) or as one band per year (Stripes). With Months or Weeks the scene then shows Stripes.",
    "Varios años se muestran como anillos concéntricos (Anillo) o como una banda por año (Franjas). Con Meses o Semanas la escena muestra entonces Franjas."],
  background: ["Hintergrund", "Background", "Fondo"],
  bgDark: ["Dunkel", "Dark", "Oscuro"],
  bgLight: ["Hell", "Light", "Claro"],
  shape: ["Tage als", "Days as", "Días como"],
  shapeRounded: ["Abgerundete Kästchen", "Rounded squares", "Cuadros redondeados"],
  shapeDots: ["Punkte", "Dots", "Puntos"],
  shapeSquare: ["Kästchen", "Squares", "Cuadros"],
  title: ["Titel", "Title", "Título"],
  titlePlaceholder: ["Das Jahr in Farben", "The year in colour", "El año en colores"],
  vivid: ["Kräftige Farben", "Vivid colours", "Colores vivos"],
  fill: ["Kurze Lücken andeuten", "Hint at short gaps", "Insinuar huecos cortos"],
  monthColours: ["Farbe jedes Monats", "Colour of each month", "Color de cada mes"],
  stats: ["Anzahl der Fotos zeigen", "Show number of photos", "Mostrar número de fotos"],
  colourHint: ["Die Farbe eines Tages ist die Farbe, die auf seinen Fotos die meiste Fläche hat; kräftige Farben zählen etwas mehr als Grau. Kräftige Farben heben die oft gedämpften Fotofarben etwas an. Kurze Lücken: Tage ohne Fotos zwischen zwei Fototagen bekommen leise deren Farbe.",
    "A day's colour is the colour that covers most of its photos; vivid colours count a little more than grey. Vivid colours lifts the often muted photo colours a bit. Short gaps: days without photos between two photo days get a faint version of their colour.",
    "El color de un día es el que más superficie ocupa en sus fotos; los colores intensos cuentan algo más que el gris. Colores vivos realza un poco los colores apagados de las fotos. Huecos cortos: los días sin fotos entre dos días con fotos reciben su color atenuado."],
  photosTitle: ["Einen Tag hervorheben", "Highlight a day", "Destacar un día"],
  photos: ["Ab und zu einen Tag mit seinen Fotos zeigen", "Now and then show a day with its photos", "De vez en cuando mostrar un día con sus fotos"],
  order: ["Welcher Tag", "Which day", "Qué día"],
  orderRandom: ["Zufällig", "Random", "Al azar"],
  orderWalk: ["Tag für Tag durch den Kalender", "Day by day through the calendar", "Día a día por el calendario"],
  orderThisDay: ["Dieser Tag in früheren Jahren", "This day in earlier years", "Este día en años anteriores"],
  photoSeconds: ["Einen Tag zeigen für … Sekunden", "Show a day for … seconds", "Mostrar un día … segundos"],
  photoPause: ["Pause zwischen zwei Tagen (Sekunden)", "Pause between two days (seconds)", "Pausa entre dos días (segundos)"],
  orderHint: ["„Dieser Tag in früheren Jahren“ zeigt Tage um das heutige Datum (± 3 Tage) aus früheren Jahren, die im Kalender zu sehen sind; gibt es keine, geht es zufällig weiter.",
    "“This day in earlier years” shows days around today's date (± 3 days) from earlier years that are in the calendar; if there are none, it picks at random.",
    "«Este día en años anteriores» muestra días alrededor de la fecha de hoy (± 3 días) de años anteriores que están en el calendario; si no hay, elige al azar."],
  refreshHours: ["Neue Fotos suchen alle … Stunden", "Look for new photos every … hours", "Buscar fotos nuevas cada … horas"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la lista (segundos)"],
  serverTitle: ["Immich-Server", "Immich server", "Servidor Immich"],
  serverHint: ["Nur nötig, wenn eine Quelle von Immich kommt. Immich liefert zu jedem Foto einen kleinen Farbabdruck (ThumbHash), darum muss das Plugin dafür kein Bild laden.",
    "Only needed if a source comes from Immich. Immich sends a tiny colour fingerprint (ThumbHash) with every photo, so the plugin does not have to load any image for it.",
    "Solo hace falta si una fuente viene de Immich. Immich envía con cada foto una pequeña huella de color (ThumbHash), así que el plugin no tiene que cargar ninguna imagen."],
  serverUrl: ["Adresse", "Address", "Dirección"],
  apiKey: ["API-Schlüssel", "API key", "Clave API"],
  test: ["Verbindung testen", "Test connection", "Probar conexión"],
  testing: ["Teste …", "Testing …", "Probando …"],
  keySaved: ["gespeichert (leer lassen zum Behalten)", "saved (leave empty to keep)", "guardada (déjala vacía para conservarla)"],
  keyMissing: ["noch keiner", "none yet", "ninguna todavía"],
  keyHow: ["So bekommst du einen API-Schlüssel", "How to get an API key", "Cómo conseguir una clave API"],
  keyHint: ["In Immich oben rechts auf dein Profilbild, dann <b>Kontoeinstellungen &gt; API-Schlüssel &gt; Neuer API-Schlüssel</b>. Als Berechtigung reichen <code>asset.read</code>, <code>asset.view</code> und <code>album.read</code>; mit <b>Alle</b> geht es auch. Der Schlüssel bleibt im Plugin auf dem Rahmen.",
    "In Immich click your profile picture at the top right, then <b>Account Settings &gt; API Keys &gt; New API Key</b>. The permissions <code>asset.read</code>, <code>asset.view</code> and <code>album.read</code> are enough; <b>All</b> works too. The key stays in the plugin on the frame.",
    "En Immich pulsa tu foto de perfil arriba a la derecha y luego <b>Configuración de la cuenta &gt; Claves API &gt; Nueva clave API</b>. Bastan los permisos <code>asset.read</code>, <code>asset.view</code> y <code>album.read</code>; con <b>Todos</b> también funciona. La clave se queda en el plugin del marco."],
  foldersTitle: ["Weitere Ordner auf dem Rahmen", "More folders on the frame", "Más carpetas en el marco"],
  foldersHint: ["Für „Alle Fotos in DynaFrame“: Das Plugin fragt DynaFrame nach seiner Mediendatenbank und den Medienordnern. Liegen Fotos woanders (z. B. ein eingehängtes NAS), trag die Ordner hier ein, einen pro Zeile.",
    "For “All photos in DynaFrame”: the plugin asks DynaFrame for its media database and media folders. If photos are somewhere else (e.g. a mounted NAS), enter those folders here, one per line.",
    "Para «Todas las fotos de DynaFrame»: el plugin pide a DynaFrame su base de datos y sus carpetas. Si hay fotos en otro sitio (p. ej. un NAS montado), escribe aquí esas carpetas, una por línea."],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status}).", "Error (HTTP {status}).", "Error (HTTP {status})."],
  oclock: ["{time} Uhr", "{time}", "{time}"],
  filterTitle: ["Welche Immich-Fotos", "Which Immich photos", "Qué fotos de Immich"],
  minRating: ["Sterne", "Stars", "Estrellas"],
  ratingAny: ["Egal", "Any", "Da igual"],
  rating1: ["Mindestens 1 Stern", "At least 1 star", "Al menos 1 estrella"],
  rating2: ["Mindestens 2 Sterne", "At least 2 stars", "Al menos 2 estrellas"],
  rating3: ["Mindestens 3 Sterne", "At least 3 stars", "Al menos 3 estrellas"],
  rating4: ["Mindestens 4 Sterne", "At least 4 stars", "Al menos 4 estrellas"],
  rating5: ["5 Sterne", "5 stars", "5 estrellas"],
  favorites: ["Nur Favoriten", "Only favourites", "Solo favoritas"],
  archived: ["Archivierte Fotos mitnehmen", "Include archived photos", "Incluir fotos archivadas"],
  filterHint: ["Gilt für alle Immich-Quellen. Versteckte und gesperrte Fotos kommen nie in den Kalender, archivierte nur, wenn du es einschaltest. Mehrere Alben in einer Zeile werden zusammengelegt (Foto in einem der Alben).",
    "Applies to all Immich sources. Hidden and locked photos never go into the calendar, archived ones only if you switch it on. Several albums in one row are merged (photo in any of them).",
    "Se aplica a todas las fuentes de Immich. Las fotos ocultas y bloqueadas nunca entran en el calendario, las archivadas solo si lo activas. Varios álbumes en una fila se unen (foto en cualquiera de ellos)."],
  albumsPicked: ["{n} Alben gewählt", "{n} albums picked", "{n} álbumes elegidos"],
  albumsNone: ["Alben wählen …", "Pick albums …", "Elige álbumes …"],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[1]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "en";
  if (chosen === lang) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  rendered = "";
  if (current) renderSources();
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(epoch) {
  if (!epoch) return "—";
  const date = new Date(epoch * 1000);
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang]);
const fmtDate = (iso) => iso ? new Date(`${iso}T12:00:00`).toLocaleDateString(LOCALES[lang], { day: "numeric", month: "short", year: "numeric" }) : "";

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

// ------------------------------------------------------------ Quellen

async function loadList(kind, force = false) {
  if (lists[kind] && !force) return;
  lists[kind] = lists[kind] || [];
  try {
    const result = await api(kind === "playlist" ? "./api/playlists" : "./api/albums");
    lists[kind] = kind === "playlist" ? result.playlists : result.albums;
    listErrors[kind] = "";
  } catch (error) {
    listErrors[kind] = error.message;
    lists[kind] = [];
  }
  rendered = "";
  renderSources();
}

// Änderungen nacheinander speichern; eine Antwort von vorher darf die Auswahl nicht zurückdrehen.
function commit() {
  lastEdit = Date.now();
  pendingCommits++;
  const snapshot = JSON.parse(JSON.stringify(sources));
  commitChain = commitChain.then(async () => {
    try {
      await api("./api/settings", { method: "POST", body: JSON.stringify({ Sources: snapshot }) });
      setStatus(t("saved"), "ok", "sourcesNote");
    } catch (error) {
      setStatus(error.message, "bad", "sourcesNote");
    } finally {
      pendingCommits--;
      lastCommitDone = Date.now();
    }
  });
  commitChain.then(() => { if (!pendingCommits) refresh(); });
}

const needsRef = (kind) => kind === "playlist" || kind === "immich_album";

function statusText(src) {
  const row = (current && current.status[src.id]) || {};
  if (row.state === "busy") return [t("srcBusy"), ""];
  if (row.state === "wait") return [t("srcWait"), ""];
  if (row.state === "error") return [row.error || "?", "bad"];
  if (row.state === "ok") return [t("srcOk", { dated: fmt(row.dated), total: fmt(row.total) }), "ok"];
  return ["", ""];
}

function fillRef(select, src) {
  const kind = src.kind;
  select.replaceChildren();
  if (!needsRef(kind)) {
    select.disabled = true;
    select.append(new Option(t("ref_none"), ""));
    return;
  }
  select.disabled = false;
  const list = lists[kind];
  if (list === null) {
    select.append(new Option(t("loading"), ""));
    loadList(kind);
    return;
  }
  select.append(new Option(listErrors[kind] || t("pick"), ""));
  for (const row of list) {
    const count = row.count ? ` (${fmt(row.count)})` : "";
    select.append(new Option(`${row.name}${count}`, String(row.id)));
  }
  if (src.ref && !list.some((row) => String(row.id) === src.ref)) select.append(new Option(src.name || src.ref, src.ref));
  select.value = src.ref || "";
}

// Mehrere Immich-Alben je Zeile, wie bei Growing Up: eine Liste zum Ankreuzen
function albumPicker(src) {
  const box = document.createElement("details");
  box.className = "albums";
  const summary = document.createElement("summary");
  const picked = () => (src.ref || "").split(",").filter(Boolean);
  const label = () => {
    const ids = picked();
    if (!ids.length) return t("albumsNone");
    if (ids.length === 1) return (lists.immich_album || []).find((a) => String(a.id) === ids[0])?.name || ids[0];
    return t("albumsPicked", { n: ids.length });
  };
  summary.textContent = label();
  box.append(summary);
  const list = lists.immich_album;
  if (list === null) {
    summary.textContent = t("loading");
    loadList("immich_album");
    return box;
  }
  const checks = document.createElement("div");
  checks.className = "checks albums";
  if (listErrors.immich_album) {
    const note = document.createElement("p");
    note.className = "hint";
    note.textContent = listErrors.immich_album;
    checks.append(note);
  }
  const known = new Set(list.map((a) => String(a.id)));
  const rows = list.map((a) => ({ id: String(a.id), name: a.name, count: a.count }))
    .concat(picked().filter((id) => !known.has(id)).map((id) => ({ id, name: id, count: 0 })));
  for (const album of rows) {
    const item = document.createElement("label");
    const box2 = document.createElement("input");
    box2.type = "checkbox";
    box2.checked = picked().includes(album.id);
    box2.addEventListener("change", () => {
      const ids = picked().filter((id) => id !== album.id);
      if (box2.checked) ids.push(album.id);
      src.ref = ids.join(",");
      summary.textContent = label();
      commit();
    });
    const name = document.createElement("span");
    name.className = "name";
    name.textContent = album.name;
    const count = document.createElement("span");
    count.className = "count";
    count.textContent = album.count ? fmt(album.count) : "";
    item.append(box2, name, count);
    checks.append(item);
  }
  box.append(checks);
  return box;
}

function renderSources() {
  const key = JSON.stringify([lang, sources.map((s) => [s.id, s.kind]), lists.playlist?.length, lists.immich_album?.length, listErrors]);
  const box = el("sources");
  if (key !== rendered) {
    rendered = key;
    box.replaceChildren();
    sources.forEach((src, index) => {
      const row = document.createElement("div");
      row.className = src.kind === "immich_album" ? "source album" : "source";
      row.dataset.id = src.id;

      const kindField = document.createElement("label");
      kindField.className = "field";
      kindField.innerHTML = `<span>${t("kind")}</span>`;
      const kind = document.createElement("select");
      for (const k of KINDS) kind.append(new Option(t(`kind_${k}`), k));
      kind.value = src.kind;
      kind.addEventListener("change", () => {
        src.kind = kind.value;
        src.ref = "";
        commit();
        renderSources();
      });
      kindField.append(kind);

      const refField = document.createElement(src.kind === "immich_album" ? "div" : "label");
      refField.className = "field";
      refField.innerHTML = `<span>${needsRef(src.kind) ? t(`ref_${src.kind}`) : "&nbsp;"}</span>`;
      if (src.kind === "immich_album") {
        refField.append(albumPicker(src));
      } else {
        const ref = document.createElement("select");
        fillRef(ref, src);
        ref.addEventListener("change", () => {
          src.ref = ref.value;
          commit();
        });
        refField.append(ref);
      }

      const nameField = document.createElement("label");
      nameField.className = "field";
      nameField.innerHTML = `<span>${t("label")}</span>`;
      const name = document.createElement("input");
      name.type = "text";
      name.maxLength = 60;
      name.value = src.name || "";
      name.addEventListener("focus", () => { editing = true; });
      name.addEventListener("blur", () => { editing = false; });
      name.addEventListener("change", () => {
        src.name = name.value;
        commit();
      });
      nameField.append(name);

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "secondary remove";
      remove.textContent = t("remove");
      remove.disabled = sources.length <= 1;
      remove.addEventListener("click", () => {
        sources.splice(index, 1);
        commit();
        renderSources();
      });

      const meta = document.createElement("p");
      meta.className = "meta";
      row.append(kindField, refField, nameField, remove, meta);
      box.append(row);
    });
  }
  for (const src of sources) {
    const meta = box.querySelector(`.source[data-id="${src.id}"] .meta`);
    if (!meta) continue;
    const [text, tone] = statusText(src);
    meta.textContent = text;
    meta.className = `meta${tone ? " " + tone : ""}`;
  }
  el("addSource").disabled = sources.length >= MAX_SOURCES;
}

el("addSource").addEventListener("click", () => {
  if (sources.length >= MAX_SOURCES) { setStatus(t("max"), "bad", "sourcesNote"); return; }
  const used = new Set(sources.map((s) => s.id));
  let n = 1;
  while (used.has(`s${n}`)) n++;
  sources.push({ id: `s${n}`, kind: "playlist", ref: "", name: "" });
  commit();
  renderSources();
});

// ------------------------------------------------------------ Stand

function render(state, started = 0) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  const progress = state.progress || {};
  let now = t("nowIdle");
  if (state.busy) {
    now = progress.phase === "colours" && progress.todo ? t("nowColours", { done: fmt(progress.done), todo: fmt(progress.todo) })
      : progress.phase === "list" && progress.done ? t("nowList", { n: fmt(progress.done) }) : t("nowBusy");
  }
  el("factNow").textContent = now;
  el("progress").hidden = !(state.busy && progress.phase === "colours" && progress.todo);
  el("progressBar").style.width = progress.todo ? `${(progress.done / progress.todo) * 100}%` : "0";
  el("factDays").textContent = state.days ? t("daysState", { photos: fmt(state.photos), days: fmt(state.days) }) : "—";
  el("factSpan").textContent = state.first ? t("span", { first: fmtDate(state.first), last: fmtDate(state.last) }) : "—";
  el("factRead").textContent = clock(state.at);
  el("factVersion").textContent = state.version;
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Colour Calendar ${state.version}] `);
  if (!state.busy && state.skipped && !el("statusNote").textContent) setStatus(t("skipped", { n: fmt(state.skipped) }));

  // Jahre zur Auswahl: die mit Fotos, dazu das eingestellte
  const years = [...new Set([...(state.years || []), String(s.Year), String(new Date().getFullYear())])].sort().reverse();
  const yearSelect = el("Year");
  if (yearSelect.options.length !== years.length || [...yearSelect.options].some((o, i) => o.value !== years[i])) {
    yearSelect.replaceChildren(...years.map((y) => new Option(y, y)));
  }

  if (!editing) {
    for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) el(name).value = String(s[name]);
    el("Language").value = lang;
    if (document.activeElement !== el("ApiKey")) {
      el("ApiKey").placeholder = state.secretsSet.ApiKey ? t("keySaved") : t("keyMissing");
    }
    if (!pendingCommits && started > lastCommitDone && started > lastEdit &&
        JSON.stringify(s.Sources) !== JSON.stringify(sources)) {
      sources = JSON.parse(JSON.stringify(s.Sources));
      rendered = "";
    }
  }
  el("yearField").hidden = s.Period !== "pick";
  el("yearsField").hidden = s.Period !== "all";
  for (const name of ["DayOrder", "PhotoSeconds", "PhotoPause"]) el(name).disabled = !s.ShowPhotos;
  renderSources();
}

async function refresh() {
  try {
    const started = Date.now();
    render(await api("./api/state"), started);
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS, ["ApiKey"])) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
}
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: name === "MinRating" ? Number(e.target.value) : e.target.value }));
el("Title").addEventListener("change", (e) => save({ Title: e.target.value }));
el("Folders").addEventListener("change", (e) => save({ Folders: e.target.value }));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save({ Language: e.target.value });
});

async function saveServer() {
  const changes = { ServerUrl: el("ServerUrl").value };
  const key = el("ApiKey").value.trim();
  if (key) changes.ApiKey = key;
  const changed = await save(changes);
  el("ApiKey").value = "";
  if (changed.includes("ServerUrl") || changed.includes("ApiKey")) await testConnection();
}

async function testConnection() {
  setStatus(t("testing"), "busy", "testNote");
  try {
    const result = await api("./api/test", { method: "POST" });
    setStatus(result.message, result.ok ? "ok" : "bad", "testNote");
    if (result.ok) loadList("immich_album", true);
  } catch (error) {
    setStatus(error.message, "bad", "testNote");
  }
}

el("ServerUrl").addEventListener("change", saveServer);
el("ApiKey").addEventListener("change", saveServer);
el("testButton").addEventListener("click", async () => {
  if (el("ApiKey").value.trim() || el("ServerUrl").value !== (current?.settings.ServerUrl || "")) await saveServer();
  else await testConnection();
});
el("refreshButton").addEventListener("click", async () => {
  try {
    const result = await api("./api/refresh", { method: "POST" });
    setStatus(result.message || "", "busy");
    setTimeout(refresh, 1500);
  } catch (error) {
    setStatus(error.message, "bad");
  }
});
el("playlistButton").addEventListener("click", async () => {
  try {
    const result = await api("./api/playlist", { method: "POST" });
    setStatus(result.message || "", "ok");
  } catch (error) {
    setStatus(error.message, "bad");
  }
});

refresh();
setInterval(refresh, 4000);
