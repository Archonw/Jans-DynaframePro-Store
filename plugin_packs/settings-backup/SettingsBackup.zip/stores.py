"""Fehlende Store-Pakete auf dem neuen Rahmen nachinstallieren.

Beim Sichern kommt die Liste der installierten Store-Pakete mit in die Datei
(GET /Store/GetInstalledPacks der Weboberfläche) und die Stores, aus denen sie
stammen (GET /Store/GetStores). Beim Zurückspielen holt dieses Modul für jedes
fehlende Paket den Katalog seines Stores (GET /Store/GetCatalog) und
installiert es genau so, wie es die Store-Seite der Weboberfläche tut:
POST /Store/DownloadAndInstall{Plugin,Dynamic,Theme,FontPack} bzw.
/Store/DownloadPack, danach POST /Store/MarkPackInstalled. Installiert wird die
Version, die der Store heute anbietet.
"""
from pathlib import Path
from urllib.parse import urljoin

OFFICIAL_CATALOG = "https://geek-toolkit.com/license/api/v3/public-catalog"
OFFICIAL_BASE = "https://geek-toolkit.com/media4/"
FOLDERS = {
    "image": "image_packs", "media": "image_packs", "fontpack": "font_packs", "font": "font_packs",
    "plugin": "plugin_packs", "dynamic": "dynamic_packs", "integration": "integration_packs",
    "overlay": "overlay_packs", "theme": "theme_packs",
}
HOME = Path.home()
TARGET_DIRS = {
    "plugin": HOME / ".local/share/dfr/plugins",
    "dynamic": HOME / ".local/share/dfr/dynamic-packages",
    "integration": HOME / ".local/share/dfr/dynamic-packages",
    "overlay": HOME / ".local/share/dfr/overlays",
    "theme": HOME / ".local/share/dfr/themes",
    "fontpack": HOME / ".local/share/fonts",
    "image": HOME / "Pictures",
    "media": HOME / "Pictures",
    "magic-mirror-module": HOME / "Pictures",
}


def _rows(value, key):
    if isinstance(value, dict):
        value = value.get(key) or value.get(key[:1].upper() + key[1:]) or []
    return [r for r in value if isinstance(r, dict)] if isinstance(value, list) else []


def _get(row, *names, default=""):
    for name in names:
        for key in (name, name[:1].upper() + name[1:]):
            if row.get(key) not in (None, ""):
                return row[key]
    return default


def pack_type(value):
    text = str(value or "").strip().lower()
    return {"fonts": "fontpack", "font-pack": "fontpack", "images": "image", "plugins": "plugin"}.get(text, text)


def installed_packs(webui):
    """[{packId, type, title, version, author, sourceStore}] der Store-Pakete dieses Rahmens."""
    try:
        rows = _rows(webui("GET", "/Store/GetInstalledPacks"), "packs")
    except Exception:
        return None
    out = []
    for row in rows:
        pack_id = str(_get(row, "packId", "id"))
        if pack_id:
            out.append({"packId": pack_id, "type": pack_type(_get(row, "type")), "title": str(_get(row, "title")),
                        "version": str(_get(row, "version")), "author": str(_get(row, "author")),
                        "sourceStore": str(_get(row, "sourceStore"))})
    return out


def list_stores(webui):
    try:
        rows = _rows(webui("GET", "/Store/GetStores"), "stores")
    except Exception:
        return []
    return [{"id": str(_get(r, "id")), "name": str(_get(r, "name")), "description": str(_get(r, "description")),
             "website": str(_get(r, "website")), "manifestUrl": str(_get(r, "manifestUrl")),
             "isEnabled": bool(_get(r, "isEnabled", default=True))}
            for r in rows if _get(r, "manifestUrl")]


def _norm(url):
    return str(url or "").strip().rstrip("/").lower()


def missing_stores(payload, webui):
    """Stores aus der Sicherung, die in der Store-Liste dieses Rahmens fehlen."""
    wanted = [s for s in payload.get("stores") or [] if isinstance(s, dict) and s.get("manifestUrl")]
    if not wanted:
        return []
    have = {_norm(s["manifestUrl"]) for s in list_stores(webui)}
    return [{"name": s.get("name") or s["manifestUrl"], "manifestUrl": s["manifestUrl"],
             "isEnabled": bool(s.get("isEnabled", True))} for s in wanted if _norm(s["manifestUrl"]) not in have]


def add_store(webui, store):
    """Einen Store in die Liste dieses Rahmens eintragen, ein- oder ausgeschaltet wie auf dem alten."""
    result = webui("POST", "/Store/AddStore", {"name": store.get("name") or "", "description": store.get("description") or "",
                                               "website": store.get("website") or "",
                                               "manifestUrl": store["manifestUrl"]})
    if isinstance(result, dict) and result.get("success") is False:
        raise RuntimeError(result.get("error") or result.get("message") or "AddStore failed")
    row = next((s for s in list_stores(webui) if _norm(s["manifestUrl"]) == _norm(store["manifestUrl"])), None)
    if row and row["id"] and row["isEnabled"] != bool(store.get("isEnabled", True)):
        try:
            webui("POST", "/Store/ToggleStore", {"storeId": row["id"], "isEnabled": bool(store.get("isEnabled", True))})
        except Exception:
            pass
    return row is not None


def ensure_store(webui, payload, url, done):
    """Vor dem Installieren: fehlt der Store des Pakets hier, ihn mit den Angaben aus der Sicherung anlegen."""
    key = _norm(url)
    if not key or key in done:
        return
    done.add(key)
    if any(_norm(s["manifestUrl"]) == key for s in list_stores(webui)):
        return
    info = next((s for s in payload.get("stores") or [] if isinstance(s, dict) and _norm(s.get("manifestUrl")) == key),
                {"manifestUrl": url, "name": url})
    try:
        add_store(webui, info)
    except Exception:
        pass  # installieren geht trotzdem, nur Updates zeigt der Store dann nicht


def missing_packs(payload, webui):
    """Store-Pakete aus der Sicherung, die hier fehlen; None, wenn die Weboberfläche nicht antwortet."""
    wanted = [p for p in payload.get("storePacks") or [] if isinstance(p, dict) and p.get("packId")]
    if not wanted:
        return []
    here = installed_packs(webui)
    if here is None:
        return None
    have = {p["packId"].lower() for p in here}
    names = {s["manifestUrl"].lower(): s["name"] for s in payload.get("stores") or [] if isinstance(s, dict)
             and s.get("manifestUrl")}
    out = []
    for pack in wanted:
        if pack["packId"].lower() in have:
            continue
        kind = pack_type(pack.get("type"))
        out.append({"packId": pack["packId"], "type": kind, "title": pack.get("title") or pack["packId"],
                    "version": pack.get("version") or "", "sourceStore": pack.get("sourceStore") or "",
                    "storeName": names.get(str(pack.get("sourceStore") or "").lower(), ""),
                    "supported": kind in TARGET_DIRS or kind in FOLDERS})
    return out


def _catalog_packs(webui, url, cache):
    key = url.lower()
    if key not in cache:
        try:
            value = webui("GET", "/Store/GetCatalog", params={"catalogUrl": url, "forceRefresh": "true"})
        except Exception:
            value = None
        if isinstance(value, dict) and isinstance(value.get("catalog"), dict):
            value = value["catalog"]
        cache[key] = _rows(value, "packs") if isinstance(value, dict) else []
    return cache[key]


def _base_url(store_url):
    if store_url.rstrip("/").lower() == OFFICIAL_CATALOG.lower():
        return OFFICIAL_BASE
    return urljoin(store_url if store_url.endswith(("/", ".json")) else store_url + "/", ".")


def _direct_zip(entry, kind, store_url):
    url = str(entry.get("download_url") or "")
    if url.lower().startswith(("http://", "https://")):
        return url
    base = _base_url(store_url)
    folder = FOLDERS.get(kind, f"{kind}_packs")
    if not url:
        return urljoin(base, f"{folder}/{entry['id']}/{entry['id']}.zip")
    if "/" not in url.strip("/"):
        return urljoin(base, f"{folder}/{entry['id']}/{url}")
    return urljoin(base, url.lstrip("/"))


def install_pack(webui, pack, cache):
    """Ein Paket aus seinem Store installieren. Gibt (ok, Version, Fehler) zurück."""
    store_url = pack.get("sourceStore") or ""
    if not store_url:
        return False, "", "no-store"
    entry = next((e for e in _catalog_packs(webui, store_url, cache)
                  if str(e.get("id") or "").lower() == pack["packId"].lower()), None)
    if entry is None:
        return False, "", "not-in-catalog"
    kind = pack_type(entry.get("type") or pack.get("type"))
    fallback = _direct_zip(entry, kind, store_url)
    tracking = str(entry.get("tracking_url") or "")
    zip_url = tracking if tracking.lower().startswith(("http://", "https://")) else fallback
    common = {"packId": entry["id"], "packTitle": entry.get("title") or entry["id"], "zipUrl": zip_url,
              "fallbackZipUrl": fallback, "version": entry.get("version") or "",
              "checksum": entry.get("checksum") or ""}
    if kind == "plugin":
        path, body = "/Store/DownloadAndInstallPlugin", dict(common, sourceStore=store_url,
                                                             downloadUrl=entry.get("download_url") or "",
                                                             security=entry.get("security"),
                                                             installAction="install", previousVersion=None)
    elif kind in ("dynamic", "integration"):
        path, body = "/Store/DownloadAndInstallDynamic", dict(common, packType=kind, sourceStore=store_url,
                                                              downloadUrl=entry.get("download_url") or "",
                                                              security=entry.get("security"))
    elif kind == "theme":
        path, body = "/Store/DownloadAndInstallTheme", dict(common, downloadUrl=entry.get("download_url") or "",
                                                            security=entry.get("security"),
                                                            installAction="install", previousVersion=None)
    elif kind == "fontpack":
        path, body = "/Store/DownloadAndInstallFontPack", dict(common, installAction="install",
                                                               previousVersion=None)
    else:
        path, body = "/Store/DownloadPack", dict(common, packType=kind,
                                                 targetDirectory=str(TARGET_DIRS.get(kind, HOME / "Pictures")),
                                                 assetCategory=entry.get("asset_category") or "",
                                                 assetCategoryTitle=entry.get("asset_category_title") or "",
                                                 installAction="install", previousVersion=None)
    try:
        result = webui("POST", path, body)
    except Exception as exc:
        return False, common["version"], str(exc)
    if not isinstance(result, dict) or not (result.get("success") or result.get("Success")):
        error = (result or {}).get("error") or (result or {}).get("message") if isinstance(result, dict) else ""
        return False, common["version"], str(error or "install failed")
    install_path = next((result.get(k) for k in ("extractedPath", "ExtractedPath", "installPath", "InstallPath",
                                                 "targetDir") if result.get(k)), "")
    try:
        webui("POST", "/Store/MarkPackInstalled", {
            "PackId": entry["id"], "Type": kind, "Title": entry.get("title") or entry["id"],
            "Author": entry.get("author") or "", "Version": entry.get("version") or "", "SourceStore": store_url,
            "InstallPath": install_path, "Checksum": entry.get("checksum") or "",
            "Size": entry.get("size_bytes") or entry.get("size") or 0})
    except Exception:
        pass  # installiert ist es trotzdem; der Store zeigt es dann nur nicht als installiert
    if kind == "theme":
        try:
            webui("POST", "/Settings/RefreshThemes", {})
        except Exception:
            pass
    return True, common["version"], ""
