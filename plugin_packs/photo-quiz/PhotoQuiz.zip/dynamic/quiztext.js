/* Photo Quiz: Texte, die Szene und Handy gleich brauchen (Hinweise, Datum).
 * Dieselbe Datei liegt in plugin/phone/ und in dynamic/. */
(function () {
  "use strict";
  const L = { de: 0, en: 1, es: 2 };
  const pickLang = (lang) => (lang in L ? lang : "en");
  const W = {
    season: ["Jahreszeit", "Season", "Estación"],
    winter: ["Winter", "winter", "invierno"], spring: ["Frühling", "spring", "primavera"],
    summer: ["Sommer", "summer", "verano"], autumn: ["Herbst", "autumn", "otoño"],
    morning: ["morgens", "in the morning", "por la mañana"], noon: ["mittags", "around noon", "a mediodía"],
    afternoon: ["nachmittags", "in the afternoon", "por la tarde"], evening: ["abends", "in the evening", "al anochecer"],
    night: ["nachts", "at night", "de noche"],
    weather: ["Wetter damals", "Weather back then", "El tiempo entonces"],
    camera: ["Aufgenommen mit", "Taken with", "Hecha con"],
    country: ["Land", "Country", "País"],
    near: ["Ganz in der Nähe von zu Hause", "Very close to home", "Muy cerca de casa"],
    away: ["≈ {km} km {dir} von zu Hause", "≈ {km} km {dir} of home", "≈ {km} km al {dir} de casa"],
    N: ["nördlich", "north", "norte"], NE: ["nordöstlich", "north-east", "noreste"], E: ["östlich", "east", "este"],
    SE: ["südöstlich", "south-east", "sureste"], S: ["südlich", "south", "sur"], SW: ["südwestlich", "south-west", "suroeste"],
    W: ["westlich", "west", "oeste"], NW: ["nordwestlich", "north-west", "noroeste"],
    clear: ["sonnig", "sunny", "soleado"], cloudy: ["bewölkt", "cloudy", "nublado"], fog: ["Nebel", "foggy", "niebla"],
    drizzle: ["Nieselregen", "drizzle", "llovizna"], rain: ["Regen", "rain", "lluvia"], snow: ["Schnee", "snow", "nieve"],
    storm: ["Gewitter", "thunderstorm", "tormenta"]
  };
  const w = (key, lang) => (W[key] || [key, key, key])[L[pickLang(lang)]];
  const fill = (text, values) => text.replace(/\{(\w+)\}/g, (_, k) => (values[k] ?? ""));

  function sky(code) {
    if (code == null) return "";
    if (code <= 1) return "clear";
    if (code <= 3) return "cloudy";
    if (code <= 48) return "fog";
    if (code <= 57) return "drizzle";
    if (code <= 67 || (code >= 80 && code <= 82)) return "rain";
    if (code <= 77 || code === 85 || code === 86) return "snow";
    return "storm";
  }

  function temp(t, units) {
    if (t == null) return "";
    return units === "f" ? `${Math.round(t * 9 / 5 + 32)} °F` : `${Math.round(t)} °C`;
  }

  /** Ein Hinweis als [Überschrift, Text]. */
  function hint(h, lang, units) {
    switch (h.kind) {
      case "season":
        return [w("season", lang), w(h.season, lang) + (h.part ? ", " + w(h.part, lang) : "")];
      case "weather": {
        const s = sky(h.code);
        return [w("weather", lang), [temp(h.t, units), s ? w(s, lang) : ""].filter(Boolean).join(", ")];
      }
      case "camera":
        return [w("camera", lang), h.name];
      case "distance":
        if (h.km < 3 || !h.dir) return ["", w("near", lang)];
        return ["", fill(w("away", lang), { km: h.km >= 100 ? Math.round(h.km / 10) * 10 : h.km, dir: w(h.dir, lang) })];
      case "country":
        return [w("country", lang), h.name];
      default:
        return ["", ""];
    }
  }

  const LOCALE = { de: "de-DE", en: "en-GB", es: "es-ES" };

  /** "2016-08-14T15:20:00" -> "14. August 2016" (ohne Uhrzeit). */
  function date(t, lang) {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(t || "");
    if (!m) return t || "";
    const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3], 12));
    return d.toLocaleDateString(LOCALE[pickLang(lang)], { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });
  }

  function distance(km, lang) {
    if (km == null) return "";
    const n = Number(km).toLocaleString(LOCALE[pickLang(lang)], { maximumFractionDigits: km < 10 ? 1 : 0 });
    return `${n} km`;
  }

  window.QuizText = { hint, date, distance, temp, lang: pickLang };
})();
