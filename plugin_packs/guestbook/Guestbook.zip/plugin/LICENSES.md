# Third-party notes

- QR Code Generator for JavaScript (`phone/qrcode.js`, and a copy in the scene), © 2009 Kazuhiko Arase, MIT licence. The word "QR Code" is a registered trademark of DENSO WAVE INCORPORATED.
- The scene bundles the fonts Fraunces, Inter and Caveat under the SIL Open Font License 1.1 (see `dynamic/fonts/OFL-*.txt`); the phone page and the print page use Caveat as well.
- Images are read with Pillow (HPND licence) and pillow-heif (BSD-3-Clause), installed from PyPI.
