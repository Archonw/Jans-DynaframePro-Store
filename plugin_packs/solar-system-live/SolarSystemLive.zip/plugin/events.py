"""Himmelsereignisse der nächsten Monate, lokal gerechnet (Astronomy Engine).

Jedes Ereignis ist ein dict:
    id, type, start, peak, end (Unix-Sekunden), bodies (Liste), visible (True/False/None),
    info (Zahlen für den Text), prio (1 = groß, 2 = mittel, 3 = klein)

Die Texte macht texts.event_title() in der eingestellten Sprache, damit Seite und
Szene dasselbe sagen.

Typen:
    lunar-eclipse   Mondfinsternis (kind total/partial/penumbral)
    solar-eclipse   Sonnenfinsternis (kind total/annular/partial/hybrid; lokal: obscuration)
    transit         Merkur- oder Venustransit
    opposition      Mars, Jupiter, Saturn, Uranus, Neptun gegenüber der Sonne
    elongation      Merkur/Venus am weitesten von der Sonne (Morgen-/Abendstern)
    conjunction     zwei helle Planeten dicht beieinander
    supermoon       Vollmond in Erdnähe
    meteors         Höhepunkt eines Meteorstroms (feste Tabelle)
    season          Frühlings-/Herbstanfang, Sonnenwenden
    comet           Komet am sonnennächsten Punkt (aus der Kometenliste)
"""

import math
from datetime import datetime, timezone

import astronomy as A

DAY = 86400.0

PLANETS_OPP = (A.Body.Mars, A.Body.Jupiter, A.Body.Saturn, A.Body.Uranus, A.Body.Neptune)
BRIGHT = (A.Body.Mercury, A.Body.Venus, A.Body.Mars, A.Body.Jupiter, A.Body.Saturn)

# Meteorströme: (Schlüssel, Monat, Tag des Höhepunkts, Stunden Länge, ZHR)
METEORS = (
    ("quadrantids", 1, 3, 30, 110),
    ("lyrids", 4, 22, 48, 18),
    ("eta-aquariids", 5, 6, 72, 50),
    ("perseids", 8, 12, 72, 100),
    ("draconids", 10, 8, 24, 10),
    ("orionids", 10, 21, 72, 20),
    ("leonids", 11, 17, 48, 15),
    ("geminids", 12, 14, 48, 150),
    ("ursids", 12, 22, 24, 10),
)


def unix(t):
    return (t.ut * DAY) + 946728000.0       # J2000 = 2000-01-01T12:00Z = 946728000


def atime(seconds):
    return A.Time((seconds - 946728000.0) / DAY)


def body_name(body):
    return str(body).split(".")[-1].lower()


def altitude(body, seconds, observer):
    t = atime(seconds)
    eq = A.Equator(body, t, observer, True, True)
    return A.Horizon(t, observer, eq.ra, eq.dec, A.Refraction.Normal).altitude


def moon_up_during(start, end, observer):
    """Steht der Mond irgendwann zwischen start und end über dem Horizont? (Abtastung alle 10 min)"""
    t = start
    best = -90.0
    while t <= end:
        best = max(best, altitude(A.Body.Moon, t, observer))
        if best > 0:
            return True, best
        t += 600
    return False, best


def sun_down(seconds, observer):
    return altitude(A.Body.Sun, seconds, observer) < -6


def lunar_eclipses(t0, t1, observer):
    out = []
    t = atime(t0)
    for _ in range(8):
        e = A.SearchLunarEclipse(t)
        peak = unix(e.peak)
        if peak > t1:
            break
        half = e.sd_penum * 60.0
        start, end = peak - half, peak + half
        kind = {A.EclipseKind.Total: "total", A.EclipseKind.Partial: "partial"}.get(e.kind, "penumbral")
        info = {"kind": kind, "obscuration": round(e.obscuration, 3),
                "totalMin": round(2 * e.sd_total), "partialMin": round(2 * e.sd_partial),
                "penumbralMin": round(2 * e.sd_penum)}
        if kind == "total":
            info["totalStart"], info["totalEnd"] = round(peak - e.sd_total * 60), round(peak + e.sd_total * 60)
        if kind in ("total", "partial"):
            info["partialStart"], info["partialEnd"] = round(peak - e.sd_partial * 60), round(peak + e.sd_partial * 60)
        visible = None
        if observer is not None:
            lo = info.get("partialStart", start)
            hi = info.get("partialEnd", end)
            visible, best = moon_up_during(lo, hi, observer)
            info["moonAlt"] = round(best, 1)
        if end > t0:
            out.append({"type": "lunar-eclipse", "start": round(start), "peak": round(peak), "end": round(end),
                        "bodies": ["moon", "earth"], "visible": visible, "info": info,
                        "prio": 1 if kind != "penumbral" else 2})
        t = e.peak.AddDays(10)
    return out


def solar_eclipses(t0, t1, observer):
    out = []
    t = atime(t0 - 3 * 3600)
    for _ in range(8):
        g = A.SearchGlobalSolarEclipse(t)
        peak = unix(g.peak)
        if peak > t1:
            break
        kind = {A.EclipseKind.Total: "total", A.EclipseKind.Annular: "annular",
                A.EclipseKind.Partial: "partial"}.get(g.kind, "hybrid")
        info = {"kind": kind}
        if g.latitude is not None and not math.isnan(g.latitude or float("nan")):
            info["lat"], info["lon"] = round(g.latitude, 2), round(g.longitude, 2)
        # Gesamtdauer auf der Erde: grob +-3 h um den Höhepunkt
        start, end = peak - 3 * 3600, peak + 3 * 3600
        visible = None
        if observer is not None:
            try:
                loc = A.SearchLocalSolarEclipse(g.peak.AddDays(-1), observer)
                lpeak = unix(loc.peak.time)
                if abs(lpeak - peak) < 0.5 * DAY and loc.peak.altitude > 0:
                    visible = True
                    info["local"] = {
                        "kind": {A.EclipseKind.Total: "total", A.EclipseKind.Annular: "annular"}.get(loc.kind, "partial"),
                        "obscuration": round(loc.obscuration, 3),
                        "start": round(unix(loc.partial_begin.time)), "peak": round(lpeak),
                        "end": round(unix(loc.partial_end.time)), "sunAlt": round(loc.peak.altitude, 1)}
                else:
                    visible = False
            except Exception:  # noqa: BLE001 - kein lokaler Treffer
                visible = False
        if end > t0:
            out.append({"type": "solar-eclipse", "start": round(start), "peak": round(peak), "end": round(end),
                        "bodies": ["sun", "moon", "earth"], "visible": visible, "info": info, "prio": 1})
        t = g.peak.AddDays(10)
    return out


def transits(t0, t1, observer):
    out = []
    for body in (A.Body.Mercury, A.Body.Venus):
        t = atime(t0 - DAY)
        tr = A.SearchTransit(body, t)
        if unix(tr.peak) > t1 or unix(tr.finish) < t0:
            continue
        visible = None
        if observer is not None:
            visible = altitude(A.Body.Sun, unix(tr.peak), observer) > 0
        out.append({"type": "transit", "start": round(unix(tr.start)), "peak": round(unix(tr.peak)),
                    "end": round(unix(tr.finish)), "bodies": [body_name(body), "sun"], "visible": visible,
                    "info": {"body": body_name(body)}, "prio": 1})
    return out


def oppositions(t0, t1):
    out = []
    for body in PLANETS_OPP:
        t = atime(t0 - 2 * DAY)
        for _ in range(3):
            hit = A.SearchRelativeLongitude(body, 0.0, t)
            s = unix(hit)
            if s > t1:
                break
            if s > t0 - 2 * DAY:
                dist = A.GeoVector(body, hit, True).Length()
                mag = A.Illumination(body, hit).mag
                out.append({"type": "opposition", "start": round(s - DAY), "peak": round(s), "end": round(s + DAY),
                            "bodies": [body_name(body), "earth", "sun"], "visible": None,
                            "info": {"body": body_name(body), "au": round(dist, 3), "mag": round(mag, 1)},
                            "prio": 2 if body in (A.Body.Mars, A.Body.Jupiter, A.Body.Saturn) else 3})
            t = hit.AddDays(30)
    return out


def elongations(t0, t1):
    out = []
    for body in (A.Body.Mercury, A.Body.Venus):
        t = atime(t0 - DAY)
        for _ in range(8):
            e = A.SearchMaxElongation(body, t)
            s = unix(e.time)
            if s > t1:
                break
            out.append({"type": "elongation", "start": round(s - DAY), "peak": round(s), "end": round(s + DAY),
                        "bodies": [body_name(body), "sun", "earth"], "visible": None,
                        "info": {"body": body_name(body), "deg": round(e.elongation, 1),
                                 "when": "morning" if e.visibility == A.Visibility.Morning else "evening"},
                        "prio": 3 if body == A.Body.Mercury else 2})
            t = e.time.AddDays(20)
    return out


def separation(a, b, t):
    va, vb = A.GeoVector(a, t, True), A.GeoVector(b, t, True)
    return A.AngleBetween(va, vb)


def conjunctions(t0, t1, limit=1.5):
    """Zwei helle Planeten dichter als limit Grad, nicht zu nah an der Sonne."""
    out = []
    pairs = [(a, b) for i, a in enumerate(BRIGHT) for b in BRIGHT[i + 1:]]
    for a, b in pairs:
        prev2 = prev = None
        s = t0 - DAY
        while s <= t1 + DAY:
            sep = separation(a, b, atime(s))
            if prev is not None and prev2 is not None and prev < prev2 and prev <= sep and prev < limit:
                # Minimum zwischen s-2d und s fein suchen
                lo, hi = s - 2 * DAY, s
                for _ in range(30):
                    m1, m2 = lo + (hi - lo) / 3, hi - (hi - lo) / 3
                    if separation(a, b, atime(m1)) < separation(a, b, atime(m2)):
                        hi = m2
                    else:
                        lo = m1
                peak = (lo + hi) / 2
                tt = atime(peak)
                sun_el = min(A.AngleBetween(A.GeoVector(A.Body.Sun, tt, True), A.GeoVector(x, tt, True))
                             for x in (a, b))
                if sun_el > 15 and t0 - DAY < peak < t1:
                    out.append({"type": "conjunction", "start": round(peak - 2 * DAY), "peak": round(peak),
                                "end": round(peak + 2 * DAY), "bodies": [body_name(a), body_name(b), "earth"],
                                "visible": None,
                                "info": {"a": body_name(a), "b": body_name(b),
                                         "deg": round(separation(a, b, tt), 2), "sunDeg": round(sun_el)},
                                "prio": 2})
            prev2, prev = prev, sep
            s += DAY
    return out


def supermoons(t0, t1):
    out = []
    t = atime(t0 - DAY)
    while True:
        full = A.SearchMoonPhase(180, t, 40)
        if full is None:
            break
        s = unix(full)
        if s > t1:
            break
        km = A.GeoMoon(full).Length() * A.KM_PER_AU
        if km < 361500:
            out.append({"type": "supermoon", "start": round(s - 12 * 3600), "peak": round(s), "end": round(s + 12 * 3600),
                        "bodies": ["moon", "earth"], "visible": None, "info": {"km": round(km)}, "prio": 3})
        t = full.AddDays(20)
    return out


def moon_illum(seconds):
    t = atime(seconds)
    return A.Illumination(A.Body.Moon, t).phase_fraction


def meteor_showers(t0, t1):
    out = []
    y0 = datetime.fromtimestamp(t0, timezone.utc).year
    for year in (y0, y0 + 1, y0 + 2):
        for key, month, day, hours, zhr in METEORS:
            peak = datetime(year, month, day, 12, tzinfo=timezone.utc).timestamp()
            if not (t0 - DAY < peak < t1):
                continue
            moon = moon_illum(peak)
            out.append({"type": "meteors", "start": round(peak - hours * 1800), "peak": round(peak),
                        "end": round(peak + hours * 1800), "bodies": ["earth"], "visible": None,
                        "info": {"key": key, "zhr": zhr, "moon": round(moon, 2)},
                        "prio": 2 if zhr >= 50 else 3})
    return out


def seasons(t0, t1):
    out = []
    y0 = datetime.fromtimestamp(t0, timezone.utc).year
    for year in (y0, y0 + 1, y0 + 2):
        s = A.Seasons(year)
        for key, t in (("march", s.mar_equinox), ("june", s.jun_solstice),
                       ("september", s.sep_equinox), ("december", s.dec_solstice)):
            x = unix(t)
            if t0 - DAY < x < t1:
                out.append({"type": "season", "start": round(x - 12 * 3600), "peak": round(x),
                            "end": round(x + 12 * 3600), "bodies": ["earth", "sun"], "visible": None,
                            "info": {"key": key}, "prio": 3})
    return out


def comet_events(t0, t1, comets):
    out = []
    for c in comets or []:
        tp = c.get("tp")
        if not tp or not (t0 - 5 * DAY < tp < t1):
            continue
        out.append({"type": "comet", "start": round(tp - 5 * DAY), "peak": round(tp), "end": round(tp + 5 * DAY),
                    "bodies": ["comet:" + c["id"], "sun"], "visible": None,
                    "info": {"name": c.get("name", c["id"]), "id": c["id"], "q": round(c.get("q", 0), 3),
                             "mag": c.get("mag")},
                    "prio": 2 if (c.get("mag") is not None and c["mag"] < 7) else 3})
    return out


def compute(t0, days, lat=None, lon=None, height=0.0, comets=None):
    t1 = t0 + days * DAY
    observer = A.Observer(lat, lon, height or 0.0) if lat is not None and lon is not None else None
    out = []
    for part in (lambda: lunar_eclipses(t0, t1, observer), lambda: solar_eclipses(t0, t1, observer),
                 lambda: transits(t0, t1, observer), lambda: oppositions(t0, t1), lambda: elongations(t0, t1),
                 lambda: conjunctions(t0, t1), lambda: supermoons(t0, t1), lambda: meteor_showers(t0, t1),
                 lambda: seasons(t0, t1), lambda: comet_events(t0, t1, comets)):
        out.extend(part())
    for e in out:
        e["id"] = f"{e['type']}-{'-'.join(b.replace(':', '_') for b in e['bodies'][:2])}-{e['peak']}"
    out = [e for e in out if e["end"] > t0]
    out.sort(key=lambda e: e["peak"])
    return out


if __name__ == "__main__":
    import json
    import time
    start = time.time()
    found = compute(time.time(), 400, 52.52, 13.40, 40)
    for e in found:
        print(datetime.fromtimestamp(e["peak"], timezone.utc).strftime("%Y-%m-%d %H:%M"), e["type"], e["bodies"][:2],
              e["visible"], json.dumps(e["info"])[:110])
    print(f"{len(found)} Ereignisse in {time.time() - start:.1f} s")
