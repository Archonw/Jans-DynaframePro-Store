"""Zusatzmodule von anderen: finden, prüfen, laden.

Ein Zusatzmodul ist ein Ordner "magicframe" mit einer module.json, einem
Renderer module.js und auf Wunsch module.css und fetch.py. Mit "kind": "skin"
in der module.json ist es ein Skin für die ganze Szene statt eines Moduls. Dynaframe's Magic Mirror sucht
solche Ordner an drei Stellen:

1. in jedem anderen installierten DynaFrame-Plugin (ein Zusatzmodul kann also
   ganz normal als Plugin über einen Store kommen), und
2. unter ~/Pictures/<Titel>/, wohin der Store Module (unbekannter Typ) legt, und
3. in data/addons/<typ>/ dieses Plugins (dahin installiert die Plugin-Seite
   ein Modul aus Katalog oder ZIP-Link).

Die Beschreibung des Formats steht in MODULES.md im Paket.
"""

import importlib.util
import io
import json
import re
import shutil
import sys
import threading
import time
import zipfile
from pathlib import Path
from urllib.parse import urljoin

import modules
import sources

TYPE = re.compile(r"^[a-z0-9][a-z0-9_.-]{1,47}$")
FILE = re.compile(r"^[A-Za-z0-9_.-]{1,64}\.(js|css|py)$")
KINDS = {"text", "textarea", "number", "bool", "select", "secret", "stop"}
SCAN_SECONDS = 60
MAX_ZIP = 2 * 1024 * 1024

_lock = threading.Lock()
_found = {"at": 0.0, "modules": {}, "problems": []}


def _label(value, fallback=""):
    """"Text" oder {"de": ..., "en": ..., "es": ...} -> [de, en, es]."""
    if isinstance(value, dict):
        first = next((str(v) for v in value.values() if v), fallback)
        return [str(value.get(code) or value.get("en") or first)[:300] for code in modules.LANGS]
    text = str(value or fallback)[:300]
    return [text, text, text]


def _field(raw):
    if not isinstance(raw, dict):
        return None
    key, kind = str(raw.get("key") or ""), str(raw.get("kind") or "text")
    if not re.match(r"^[A-Za-z][A-Za-z0-9_]{0,31}$", key) or kind not in KINDS or key == "header":
        return None
    field = {"key": key, "kind": kind, "label": _label(raw.get("label"), key), "default": raw.get("default")}
    if raw.get("hint"):
        field["hint"] = _label(raw["hint"])
    for name in ("min", "max"):
        if isinstance(raw.get(name), (int, float)):
            field[name] = raw[name]
    if kind == "select":
        options = []
        for option in raw.get("options") or []:
            if isinstance(option, dict) and "value" in option:
                options.append({"value": str(option["value"]), "label": _label(option.get("label"), str(option["value"]))})
            elif isinstance(option, (str, int)):
                options.append({"value": str(option), "label": _label(str(option))})
        if not options:
            return None
        field["options"] = options
        if str(field["default"]) not in [o["value"] for o in options]:
            field["default"] = options[0]["value"]
    if isinstance(raw.get("showIf"), dict):
        field["showIf"] = {str(k): v for k, v in raw["showIf"].items()}
    return field


_fetch_cache = {}


def _load_fetch(path, module_type):
    """fetch.py laden; beim nächsten Suchlauf nur neu, wenn sich die Datei geändert hat."""
    key = (str(path), path.stat().st_mtime)
    if key in _fetch_cache:
        return _fetch_cache[key]
    name = "mf_addon_" + re.sub(r"\W", "_", module_type)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    if not callable(getattr(module, "fetch", None)):
        raise ValueError("fetch.py hat keine Funktion fetch(config, ctx)")
    _fetch_cache[key] = module.fetch
    return module.fetch


def read_folder(folder, origin):
    """Ein magicframe-Ordner -> Modul-Spezifikation wie in modules.MODULES."""
    manifest = json.loads((folder / "module.json").read_text(encoding="utf-8"))
    module_type = str(manifest.get("type") or "").lower()
    if not TYPE.match(module_type):
        raise ValueError(f"ungültiger type {module_type!r}")
    if module_type in modules.MODULES or module_type in modules.SKINS:
        raise ValueError(f"type {module_type!r} gibt es schon eingebaut")
    is_skin = manifest.get("kind") == "skin"
    script = str(manifest.get("script") or "module.js")
    if not FILE.match(script) or not (folder / script).is_file():
        raise ValueError(f"{script} fehlt")
    style = str(manifest.get("style") or "")
    if style and (not FILE.match(style) or not (folder / style).is_file()):
        style = ""
    fields = [f for f in (_field(raw) for raw in manifest.get("fields") or []) if f][:30]
    region = manifest.get("region") if manifest.get("region") in modules.REGION_IDS else "middle_center"
    spec = {
        "name": _label(manifest.get("name"), module_type),
        "description": _label(manifest.get("description")),
        "region": region,
        "fields": fields if is_skin else [modules.HEADER] + fields,
        "skin": is_skin,
        "addon": {
            "origin": origin, "folder": str(folder), "script": script, "style": style,
            "version": str(manifest.get("version") or "")[:20], "author": str(manifest.get("author") or "")[:60],
            "url": str(manifest.get("url") or "")[:300],
        },
    }
    # Widget-Typen, die das Modul für Felder in Skins liefert, und eigene Typnamen
    spec["widgets"] = [w for w in (manifest.get("widgets") or []) if isinstance(w, str) and modules.WIDGET_TYPE.match(w)][:20]
    names = manifest.get("widgetNames") if isinstance(manifest.get("widgetNames"), dict) else {}
    spec["widgetNames"] = {k: _label(v, k) for k, v in names.items() if modules.WIDGET_TYPE.match(str(k))}
    if is_skin:
        spec["own"] = [w for w in (manifest.get("own") or []) if isinstance(w, str) and modules.WIDGET_TYPE.match(w)][:30]
        slots = []
        for raw in manifest.get("slots") or []:
            if not isinstance(raw, dict) or not re.match(r"^[a-z][a-z0-9_-]{0,23}$", str(raw.get("id") or "")):
                continue
            accepts = [w for w in (raw.get("accepts") or []) if isinstance(w, str) and modules.WIDGET_TYPE.match(w)][:40]
            try:
                most = min(4, max(1, int(raw.get("max") or 1)))
            except (TypeError, ValueError):
                most = 1
            # Schriftgröße einstellbar: "sizes" für alle Felder, "size" am Feld überschreibt das
            size = raw.get("size", manifest.get("sizes", False))
            row = {"id": raw["id"], "name": _label(raw.get("name"), raw["id"]), "accepts": accepts, "max": most,
                   "size": size is True}
            row["default"] = modules.slot_value(row, raw.get("default") or "") or ""
            slots.append(row)
        spec["slots"] = slots[:24]
    fetch_file = str(manifest.get("fetch") or ("fetch.py" if (folder / "fetch.py").is_file() else ""))
    if fetch_file:
        if not FILE.match(fetch_file) or not (folder / fetch_file).is_file():
            raise ValueError(f"{fetch_file} fehlt")
        spec["fetch"] = _load_fetch(folder / fetch_file, module_type)
        spec["visibleOnly"] = bool(manifest.get("visibleOnly"))
        # Nur sichtbar holende Module dürfen öfter (z. B. "läuft gerade")
        spec["every"] = max(10 if spec["visibleOnly"] else 30, min(86400, int(manifest.get("every") or 600)))
        spec["place"] = bool(manifest.get("place"))
    return module_type, spec


def store_roots(plugin_dir):
    """Wohin der DynaFrame-Store Module legt. Der Store kennt nur plugin,
    integration, fontpack (nimmt nur Schriftdateien), overlay und theme; einen
    unbekannten Typ wie "magic-mirror-module" entpackt er als Medien nach
    ~/Pictures/<Titel>/. Das erscheint nicht unter Plugins."""
    homes = {Path.home()}
    try:
        homes.add(plugin_dir.resolve().parents[4])   # ~/.local/share/dfr/plugins/MagicFrame
    except (IndexError, OSError):
        pass
    return [home / "Pictures" for home in homes]


def _store_folders(root, depth=3):
    """Ordner mit module.json und module.js unter root (höchstens depth tief)."""
    try:
        children = sorted(c for c in root.iterdir() if c.is_dir())
    except OSError:
        return
    for child in children:
        try:
            if (child / "module.json").is_file() and (child / "module.js").is_file():
                yield child
            elif depth > 1:
                yield from _store_folders(child, depth - 1)
        except OSError:
            continue


def candidates(plugin_dir):
    """Andere Plugins neben diesem, Module aus dem Store und data/addons/*."""
    own = plugin_dir.resolve()
    roots = {plugin_dir.parent}
    for root in roots:
        try:
            children = sorted(root.iterdir())
        except OSError:
            continue
        for child in children:
            try:
                if child.resolve() != own and (child / "magicframe" / "module.json").is_file():
                    yield child / "magicframe", child.name
            except OSError:
                continue
    for root in store_roots(plugin_dir):
        for folder in _store_folders(root):
            yield folder, "store"
    store = plugin_dir / "data" / "addons"
    if store.is_dir():
        for child in sorted(store.iterdir()):
            if (child / "module.json").is_file():
                yield child, "link"


def scan(plugin_dir, log, force=False):
    with _lock:
        if not force and time.time() - _found["at"] < SCAN_SECONDS:
            return _found["modules"]
        found, problems = {}, []
        for folder, origin in candidates(plugin_dir):
            try:
                module_type, spec = read_folder(folder, origin)
            except Exception as exc:
                problems.append({"origin": origin, "error": str(exc)[:200]})
                continue
            if module_type in found:
                # z. B. aus dem Store und per Katalog installiert: die neuere Fassung gilt
                if version_key(spec["addon"]["version"]) > version_key(found[module_type]["addon"]["version"]):
                    found[module_type] = spec
                continue
            found[module_type] = spec
        if set(found) != set(_found["modules"]):
            log(f"Zusatzmodule: {', '.join(sorted(found)) or 'keine'}")
        for problem in problems:
            if problem not in _found["problems"]:
                log(f"Zusatzmodul in {problem['origin']}: {problem['error']}", "warning")
        _found.update(at=time.time(), modules=found, problems=problems)
        return found


def problems():
    return list(_found["problems"])


def file_of(spec, name):
    """Die Datei, die die Szene laden darf (nur script und style)."""
    addon = spec.get("addon") or {}
    if name not in (addon.get("script"), addon.get("style")) or not name:
        return None
    return Path(addon["folder"]) / name


# --------------------------------------------------------------------------
# Modul-Kataloge: Listen installierbarer Module (JSON), z. B. in Jans Store
# {"modules": [{"type", "name", "description", "version", "author", "zip", "url"}]}
# "zip" darf relativ zum Katalog sein.
# --------------------------------------------------------------------------

DEFAULT_CATALOG = ("https://raw.githubusercontent.com/Archonw/Jans-DynaframePro-Store/main/"
                   "plugin_packs/magic-frame/modules/catalog.json")
CATALOG_SECONDS = 600
_catalog = {"key": None, "at": 0.0, "value": None}


def version_key(text):
    return tuple(int(part) if part.isdigit() else 0 for part in re.split(r"[.-]", str(text or "0"))[:4])


def catalogs(extra_urls, force=False):
    urls = [DEFAULT_CATALOG] + [u for u in extra_urls if u != DEFAULT_CATALOG][:5]
    key = tuple(urls)
    if not force and _catalog["key"] == key and time.time() - _catalog["at"] < CATALOG_SECONDS:
        return _catalog["value"]
    items, errors, seen = [], [], set()
    for url in urls:
        try:
            payload = sources._get(url)
            rows = payload.get("modules") if isinstance(payload, dict) else None
            if not isinstance(rows, list):
                raise ValueError("keine Modulliste")
        except Exception as exc:
            errors.append({"catalog": url, "error": str(getattr(exc, "code", "") or exc)[:200]})
            continue
        for row in rows:
            if not isinstance(row, dict):
                continue
            module_type = str(row.get("type") or "").lower()
            if not TYPE.match(module_type) or module_type in seen or not row.get("zip"):
                continue
            seen.add(module_type)
            items.append({
                "type": module_type, "name": _label(row.get("name"), module_type),
                "description": _label(row.get("description")), "version": str(row.get("version") or "")[:20],
                "author": str(row.get("author") or "")[:60], "url": str(row.get("url") or "")[:300],
                "zip": urljoin(url, str(row["zip"])), "catalog": url,
            })
    value = {"modules": items, "errors": errors}
    _catalog.update(key=key, at=time.time(), value=value)
    return value


def install_from_url(url, plugin_dir):
    """Ein ZIP mit module.json (oben oder in einem Ordner) nach data/addons/<type>/."""
    if not re.match(r"^https?://", url or ""):
        raise sources.SourceError("no-url")
    return install_zip(sources._get(url, expect="text"), url, plugin_dir)


def install_zip(body, source, plugin_dir):
    """Ein ZIP (aus dem Netz oder als Datei hochgeladen) installieren."""
    if isinstance(body, str):
        body = body.encode("latin-1")
    if len(body) > MAX_ZIP:
        raise ValueError("ZIP größer als 2 MB")
    try:
        archive = zipfile.ZipFile(io.BytesIO(body))
    except zipfile.BadZipFile as exc:
        raise ValueError("kein ZIP") from exc
    names = [n for n in archive.namelist() if n.endswith("module.json")]
    if not names:
        raise ValueError("im ZIP fehlt module.json")
    prefix = min(names, key=len)[: -len("module.json")]
    temp = plugin_dir / "data" / "addons" / ".incoming"
    shutil.rmtree(temp, ignore_errors=True)
    temp.mkdir(parents=True)
    for name in archive.namelist():
        if not name.startswith(prefix) or name.endswith("/"):
            continue
        relative = name[len(prefix):]
        if "/" in relative or not (relative == "module.json" or FILE.match(relative)):
            continue  # nur flache, bekannte Dateien
        (temp / relative).write_bytes(archive.read(name))
    try:
        module_type, spec = read_folder(temp, "link")
    except Exception:
        shutil.rmtree(temp, ignore_errors=True)
        raise
    target = plugin_dir / "data" / "addons" / module_type
    shutil.rmtree(target, ignore_errors=True)
    temp.rename(target)
    (target / ".source").write_text(source, encoding="utf-8")
    return module_type, spec


def remove(module_type, plugin_dir):
    target = plugin_dir / "data" / "addons" / module_type
    if TYPE.match(module_type) and target.is_dir():
        shutil.rmtree(target)
        return True
    return False
