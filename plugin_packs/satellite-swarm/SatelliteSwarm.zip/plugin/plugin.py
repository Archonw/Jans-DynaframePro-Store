#!/usr/bin/env python3
"""Satellite Swarm - der Plugin-Teil des Pakets.

Die Szene "satellite-swarm" zeigt alle aktiven Satelliten (rund 10.000:
Starlink-Ketten, OneWeb, GPS & Co., Wetter- und Erdbeobachter, der
geostationäre Ring) als Schwarm um die Erde oder als Himmel über dem Haus.

Dieses Plugin holt die Bahnelemente von CelesTrak (alle 8 Stunden, CelesTrak
bittet um höchstens alle 2 Stunden), bringt sie auf eine gemeinsame Zeit und
gibt sie der Szene; die Grafikkarte rechnet daraus jede Bildwiederholung die
Orte. Für ISS, Tiangong, Hubble und frische Starlink-Züge rechnet das Plugin
die Überflüge über dem eingestellten Ort (36 Stunden voraus) und sagt sie an.
Auf Wunsch legt es einen Überflug über die laufende Playlist (Takeover).
"""

import json
import os
import re
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

try:
    # Räumt nach einem Takeover auf, wenn DynaFrame das nicht tut (siehe dort).
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None

import orbit  # noqa: E402
import own_playlist  # noqa: E402
import texts  # noqa: E402

plugin = create_plugin()

PLUGIN_ID = "SatelliteSwarm"
SCENE_ID = "satellite-swarm"          # id in scene.dynamic - nie ändern
PLAYLIST_NAME = "Satellite Swarm"     # in allen Sprachen gleich (englische Namen, Jans Regel 12.11.2026)
DISPLAY_NAME = "Satellite Swarm"
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"
CONNECT_TIMEOUT = 10
CELESTRAK_URL = os.environ.get("SSW_CELESTRAK_URL",
                               "https://celestrak.org/NORAD/elements/gp.php?GROUP=active&FORMAT=csv")
GEOCODE_URL = os.environ.get("SSW_GEOCODE_URL", "https://geocoding-api.open-meteo.com/v1/search")
FETCH_EVERY = 8 * 3600
FETCH_MIN_GAP = 2 * 3600 + 60         # CelesTrak: nicht öfter als alle 2 Stunden
PASS_HOURS = 36


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def log(text, level="info"):
    plugin.log(text, level=level)


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        log(f"Konnte {path.name} nicht lesen: {exc}", "warning")
        return default


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

GROUP_SETTINGS = {g: "Show" + g.capitalize() for g in orbit.GROUPS}
SCHEMA = {
    "Language":       {"kind": "choice", "default": "de", "choices": texts.LANGUAGES},
    # Was die Szene zeigt
    "View":           {"kind": "choice", "default": "both", "choices": ("both", "globe", "sky")},
    "SwitchSeconds":  {"kind": "int", "default": 60, "min": 20, "max": 900},
    "Camera":         {"kind": "choice", "default": "cycle", "choices": ("cycle", "near", "far")},
    "Labels":         {"kind": "bool", "default": True},
    "Orbits":         {"kind": "bool", "default": True},
    "Panel":          {"kind": "bool", "default": True},
    "DotSize":        {"kind": "choice", "default": "normal", "choices": ("small", "normal", "large")},
    **{name: {"kind": "bool", "default": True} for name in GROUP_SETTINGS.values()},
    # Ort
    "PlaceName":      {"kind": "name", "default": ""},
    "Lat":            {"kind": "coord", "default": None, "min": -90, "max": 90},
    "Lon":            {"kind": "coord", "default": None, "min": -180, "max": 180},
    # Ansagen
    "AnnounceIss":    {"kind": "bool", "default": True},
    "AnnounceCss":    {"kind": "bool", "default": True},
    "AnnounceHst":    {"kind": "bool", "default": False},
    "AnnounceTrains": {"kind": "bool", "default": True},
    "MinElevation":   {"kind": "choice", "default": "20", "choices": ("10", "20", "30", "40", "60")},
    "AnnounceWhen":   {"kind": "choice", "default": "all", "choices": ("all", "visible")},
    "LeadMinutes":    {"kind": "choice", "default": "5", "choices": ("0", "2", "5", "10", "15")},
    "SkyOnPass":      {"kind": "bool", "default": True},
    "Takeover":       {"kind": "choice", "default": "off", "choices": ("off", "visible", "all")},
    "WakeScreen":     {"kind": "bool", "default": False},
    # Playlist
    "PlaylistSeconds": {"kind": "int", "default": 300, "min": 30, "max": 86400},
    "MakePlaylist":   {"kind": "bool", "default": False},
}
SCENE_SETTINGS = ("Language", "View", "SwitchSeconds", "Camera", "Labels", "Orbits", "Panel", "DotSize",
                  "LeadMinutes", "SkyOnPass", "PlaceName", "Lat", "Lon", *GROUP_SETTINGS.values())
PASS_SETTINGS = ("Lat", "Lon", "AnnounceIss", "AnnounceCss", "AnnounceHst", "AnnounceTrains", "MinElevation",
                 "AnnounceWhen", "Takeover")
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "name":
        return re.sub(r"[\x00-\x1f]", " ", str(raw or "")).strip()[:80]
    if kind == "coord":
        if raw is None or str(raw).strip() == "":
            return None
        try:
            number = float(str(raw).replace(",", "."))
        except ValueError:
            return spec["default"]
        return round(number, 4) if spec["min"] <= number <= spec["max"] else spec["default"]
    value = str(raw if raw is not None else "").strip()
    return value if value in spec["choices"] else spec["default"]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


def has_place(values=None):
    values = values or settings()
    return values["Lat"] is not None and values["Lon"] is not None


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=120):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "at": 0.0}


def find_scene():
    if _scene["dbId"] is not None and now() - _scene["at"] < 600:
        return {"id": _scene["dbId"]}
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}", read_timeout=15)
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], at=now())
        return row
    _scene.update(dbId=None, at=0.0)
    return None


# --------------------------------------------------------------------------
# Bahndaten von CelesTrak
# --------------------------------------------------------------------------

CATALOG_FILE = DATA_DIR / "active.csv"
META_FILE = DATA_DIR / "catalog.json"
_cat_lock = threading.Lock()
_cat = {"sats": [], "t0": 0.0, "cols": None, "ver": 0, "fetchedAt": 0.0, "notable": {}, "trains": [],
        "counts": {}, "error": "", "busy": "", "nextFetch": 0.0}
_stop = threading.Event()
_wake_fetch = threading.Event()
_force_fetch = {"on": False}


def load_catalog(text, fetched_at):
    sats = orbit.parse_csv(text)
    if len(sats) < 50:
        raise ValueError(f"nur {len(sats)} Satelliten")
    # Sortiert nach Gruppe: so liegen die Gruppen in der Szene zusammen
    sats.sort(key=lambda s: (orbit.GROUPS.index(s.group), s.norad))
    t0 = round(now())
    cols = orbit.prepare(sats, t0)
    notable = {}
    for idx, s in enumerate(sats):
        key = orbit.NOTABLE.get(s.norad)
        if key:
            notable[key] = idx
    trains = orbit.starlink_trains(sats, t0)
    index = {id(s): k for k, s in enumerate(sats)}
    for train in trains:
        train["idx"] = index[id(train["rep"])]
    counts = {g: 0 for g in orbit.GROUPS}
    for s in sats:
        counts[s.group] += 1
    with _cat_lock:
        _cat.update(sats=sats, t0=t0, cols=cols, ver=int(t0) % 2_000_000_000, fetchedAt=fetched_at,
                    notable=notable, trains=trains, counts=counts)
    log(f"Bahndaten: {len(sats)} Satelliten, {len(trains)} Starlink-Züge")


def fetch_catalog():
    _cat["busy"] = "fetch"
    try:
        response = requests.get(CELESTRAK_URL, timeout=(CONNECT_TIMEOUT, 120), headers={
            "User-Agent": f"DynaFrame-SatelliteSwarm/{version()} (+https://github.com/Archonw/Jans-DynaframePro-Store)",
            "Accept": "text/csv, text/plain"})
    except requests.RequestException as exc:
        raise RuntimeError(tr("CelesTrak ist nicht erreichbar: {exc}", exc=exc.__class__.__name__)) from exc
    finally:
        _cat["busy"] = ""
    text = response.text or ""
    if response.status_code != 200 or not text.startswith("OBJECT_NAME"):
        snippet = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", text))[:120].strip() or f"HTTP {response.status_code}"
        raise RuntimeError(tr("CelesTrak hat keine Bahndaten geliefert ({text}).", text=snippet))
    fetched = now()
    load_catalog(text, fetched)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = CATALOG_FILE.with_suffix(".tmp")
    temp.write_text(text, encoding="utf-8")
    temp.replace(CATALOG_FILE)
    write_json(META_FILE, {"fetchedAt": fetched})


def load_cached():
    try:
        text = CATALOG_FILE.read_text(encoding="utf-8")
    except OSError:
        return False
    fetched = float(read_json(META_FILE, {}).get("fetchedAt") or CATALOG_FILE.stat().st_mtime)
    try:
        load_catalog(text, fetched)
        return True
    except Exception as exc:  # noqa: BLE001
        log(f"Gespeicherte Bahndaten unbrauchbar: {exc}", "warning")
        return False


def fetch_loop():
    load_cached()
    failures = 0
    while not _stop.is_set():
        age = now() - _cat["fetchedAt"] if _cat["fetchedAt"] else 1e9
        due = age >= FETCH_EVERY or (_force_fetch["on"] and age >= FETCH_MIN_GAP)
        if due:
            _force_fetch["on"] = False
            try:
                fetch_catalog()
                _cat["error"] = ""
                failures = 0
                _wake_pass.set()
            except Exception as exc:  # noqa: BLE001
                failures += 1
                _cat["error"] = str(exc)
                log(str(exc), "warning")
        if _cat["error"] and failures:
            wait = min(3600, 300 * 2 ** min(failures - 1, 4))     # 5, 10, 20, 40, 60 min
        else:
            wait = FETCH_EVERY - (now() - _cat["fetchedAt"])
        _cat["nextFetch"] = now() + max(60, wait)
        _wake_fetch.clear()
        _wake_fetch.wait(max(60, wait))


def refresh_now():
    age = now() - _cat["fetchedAt"] if _cat["fetchedAt"] else 1e9
    if age < FETCH_MIN_GAP:
        at = datetime.fromtimestamp(_cat["fetchedAt"] + FETCH_MIN_GAP).strftime("%H:%M")
        return {"success": True, "message": tr(
            "Die Bahndaten sind gerade erst geholt worden. CelesTrak bittet, höchstens alle zwei Stunden zu "
            "fragen; neu geholt wird um {time}.", time=at)}
    _force_fetch["on"] = True
    _wake_fetch.set()
    return {"success": True, "message": tr("Holt die Bahndaten jetzt neu von CelesTrak.")}


# --------------------------------------------------------------------------
# Überflüge und Ansagen
# --------------------------------------------------------------------------

_passes = {"list": [], "key": None, "at": 0.0, "above": None, "test": None}
_wake_pass = threading.Event()


def pass_targets(values):
    with _cat_lock:
        sats, notable, trains = _cat["sats"], dict(_cat["notable"]), list(_cat["trains"])
    targets = []
    for key, flag in (("iss", "AnnounceIss"), ("css", "AnnounceCss"), ("hst", "AnnounceHst")):
        if key in notable:
            targets.append({"key": key, "name": orbit.NOTABLE_NAMES[key], "idx": notable[key],
                            "sat": sats[notable[key]], "announce": values[flag]})
    for train in trains:
        targets.append({"key": "train-" + train["key"], "name": "Starlink", "train": train["count"],
                        "idx": train["idx"], "sat": train["rep"], "announce": values["AnnounceTrains"]})
    return targets


def compute_passes():
    values = settings()
    key = (_cat["ver"], tuple(values[k] for k in PASS_SETTINGS), int(now() // 600))
    if key == _passes["key"]:
        return
    if not has_place(values) or not _cat["sats"]:
        _passes.update(list=[], key=key, at=now())
        return
    lat, lon = values["Lat"], values["Lon"]
    start = now() - 900
    min_el = float(values["MinElevation"])
    out = []
    for target in pass_targets(values):
        try:
            found = orbit.find_passes(target["sat"], lat, lon, 0.05, start, PASS_HOURS, min_el=10.0)
        except Exception as exc:  # noqa: BLE001
            log(f"Überflüge {target['name']}: {exc}", "warning")
            continue
        for p in found:
            p.update(key=target["key"], name=target["name"], idx=target["idx"])
            if target.get("train"):
                p["train"] = target["train"]
            p["announce"] = bool(target["announce"] and p["maxEl"] >= min_el
                                 and (values["AnnounceWhen"] == "all" or p["visible"]))
            p["takeover"] = bool(p["announce"] and values["Takeover"] != "off"
                                 and (values["Takeover"] == "all" or p["visible"]))
            p["id"] = f"{target['key']}-{p['start']}"
            out.append(p)
    out.sort(key=lambda p: p["start"])
    _passes.update(list=out, key=key, at=now())


def count_above(values):
    """Wie viele Satelliten gerade über dem Horizont stehen (je Gruppe)."""
    if not has_place(values) or not _cat["sats"]:
        return None
    t = now()
    obs, theta = orbit.observer_eci(values["Lat"], values["Lon"], 0.05, t)
    sun = orbit.sun_direction(t)
    groups = {g: 0 for g in orbit.GROUPS}
    lit = 0
    lat = values["Lat"]
    for s in _cat["sats"]:
        p = s.position(t)
        # schneller Vorfilter: Skalarprodukt mit der Ortsrichtung
        if (p[0] - obs[0]) * obs[0] + (p[1] - obs[1]) * obs[1] + (p[2] - obs[2]) * obs[2] <= 0:
            continue
        if orbit.look_angles(p, obs, theta, lat)[1] > 0:
            groups[s.group] += 1
            lit += orbit.sunlit(p, sun)
    return {"total": sum(groups.values()), "groups": groups, "sunlit": lit, "at": round(t)}


def pass_loop():
    last_count = 0.0
    while not _stop.is_set():
        try:
            compute_passes()
            values = settings()
            if now() - last_count > 60 or (_passes["above"] is None and _cat["sats"]):
                last_count = now()
                _passes["above"] = count_above(values)
        except Exception as exc:  # noqa: BLE001
            log(f"Überflüge: {exc}", "warning")
        _wake_pass.clear()
        _wake_pass.wait(20)


def all_passes():
    items = list(_passes["list"])
    test = _passes["test"]
    if test and test["end"] > now():
        items = [test] + items
    return items


def active_pass(t=None):
    """Der Überflug, der gerade angesagt wird (läuft gerade)."""
    t = t or now()
    for p in all_passes():
        if p["announce"] and p["start"] <= t <= p["end"]:
            return p
    return None


def test_pass():
    """Probe: eine Minute „Jetzt fliegt die ISS über dich“, mit Takeover, wenn eingeschaltet."""
    values = settings()
    with _cat_lock:
        idx = _cat["notable"].get("iss", -1)
    t = round(now())
    _passes["test"] = {"id": f"test-{t}", "key": "iss", "name": "ISS", "idx": idx, "start": t, "end": t + 60,
                       "max": t + 30, "maxEl": 67.0, "azStart": 250, "azMax": 180, "azEnd": 75, "rangeKm": 460,
                       "visible": True, "visibleFrom": t, "visibleTo": t + 60, "announce": True,
                       "takeover": values["Takeover"] != "off", "test": True}
    _wake_takeover.set()
    return {"success": True, "message": tr("Probe-Überflug: die Szene spielt eine Minute lang eine Ansage.")}


# --------------------------------------------------------------------------
# Den Bildschirm übernehmen (Takeover) bei einem Überflug
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = "Satellite Swarm (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Played by the Satellite Swarm plugin when a satellite passes over and it takes "
                                 "over the screen. Stays switched off so it does not end up in a Quick Mix. The "
                                 "plugin creates it again if it is deleted.")
TAKEOVER_ITEM_SECONDS = 6 * 3600
TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
STATE_FILE = DATA_DIR / "state.json"
_takeover_lock = threading.Lock()
_takeover = {"handle": None, "since": None, "token": 0, "note": "", "passId": None, "tried": set()}
_playlists = {"at": 0.0, "takeoverId": None, "note": ""}
_playlist_lock = threading.Lock()
_wake_takeover = threading.Event()


def load_state():
    data = read_json(STATE_FILE, {})
    return data if isinstance(data, dict) else {}


def save_state(**changes):
    data = load_state()
    data.update(changes)
    write_json(STATE_FILE, data)


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError:
        return False
    return bool(status.get("active"))


def ensure_takeover_playlist(scene_db_id):
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if i.get("dynamicSceneId") == scene_db_id]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_PLAYLIST_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(f"no id for {TAKEOVER_PLAYLIST_NAME}")
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": scene_db_id, "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def maintain_playlists(force=False):
    """Die Übernahme-Playlist gibt es nur, solange Takeover eingeschaltet ist."""
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        if settings()["Takeover"] == "off":
            _playlists["note"] = ""
            return
        row = find_scene()
        if row is None:
            _playlists["note"] = tr("Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.")
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(row["id"]), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Konnte die Übernahme-Playlist nicht anlegen: {exc}", exc=exc)
            log(_playlists["note"], "warning")


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform", read_timeout=10) or {}
    except EngineError:
        return True
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover", read_timeout=10) or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Satellite Swarm ist auf der Plugins-Seite ausgeschaltet.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Übernahme erlauben“ ist für Satellite Swarm auf der Plugins-Seite aus. Schalte es ein, sonst "
                  "kann der Überflug nicht über die Playlist gelegt werden.")
    return ""


def display_is_off():
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def scene_on_screen():
    """Läuft die Szene gerade ganz normal in einer Playlist? Dann sagt sie selbst an."""
    if _scene["dbId"] is None:
        return False
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", read_timeout=5) or {}
    except EngineError:
        return False
    item = status.get("currentItem") or {}
    return bool(status.get("isRunning") and item.get("dynamicSceneId") == _scene["dbId"]
                and not same_id(status.get("activePlaylistId"), _playlists["takeoverId"]))


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        log(text)
    return False



def _check_after_release():
    """Nach dem Zurückgeben: Bild stehen geblieben oder Playlist nicht wieder da? (playback_guard)"""
    if playback_guard is None:
        return
    threading.Thread(target=playback_guard.restore_if_stalled, name="playback-guard",
                     args=(engine_base(), engine_headers, lambda m, level="info": log(m, level)),
                     kwargs={"stop_event": _stop}, daemon=True).start()

def _on_session_state(handle_or_state):
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _takeover.update(handle=None, since=None, passId=None)
    log(f"Der Rahmen hat den Überflug beendet: {new_state}.")
    _check_after_release()


def end_takeover(reason, token=None):
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        _takeover.update(handle=None, since=None, passId=None)
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:  # noqa: BLE001
        log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", "warning")
    log(f"Bildschirm zurückgegeben ({reason}).")
    if reason not in ("stopped", "gestoppt"):
        _check_after_release()
    return True


def takeover_window(p):
    """Wann der Überflug den Bildschirm bekommt: rund um den höchsten Punkt,
    bei „nur sichtbare“ der sichtbare Teil."""
    lo, hi = max(p["start"], p["max"] - 240), min(p["end"], p["max"] + 240)
    if settings()["Takeover"] == "visible" and p.get("visibleFrom") and not p.get("test"):
        lo, hi = max(lo, p["visibleFrom"] - 30), min(max(hi, p["visibleTo"] + 15), p["end"])
    return lo, hi


def show_pass(p):
    if not takeover_supported():
        return _note(tr("Dieser Rahmen ist zu alt, damit ein Plugin den Bildschirm übernehmen kann."))
    if find_scene() is None:
        return _note(tr("Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("Die Übernahme-Playlist ist noch nicht angelegt."))
    wake = settings()["WakeScreen"]
    if not wake and display_is_off():
        return _note(tr("Der Bildschirm ist aus; der Überflug wird nicht gezeigt."))
    lo, hi = takeover_window(p)
    seconds = int(max(30, min(1200, hi - now() + 20)))
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             "overlay": {"enabled": False}}
    try:
        _leftover["askedAt"] = time.time()
        handle = plugin.acquire_display_session(
            session_key="pass", state=state, display_name=DISPLAY_NAME,
            max_duration_seconds=seconds, wake_if_off=bool(wake))
    except Exception as exc:  # noqa: BLE001
        return _note(tr("Konnte den Überflug nicht zeigen: {exc}", exc=exc))
    if handle is None:
        return _note(takeover_permission_note() or tr("Gerade hat etwas anderes den Bildschirm."))
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, since=now(), note="", passId=p["id"])
    try:
        handle.on_state_change(_on_session_state)
    except Exception:  # noqa: BLE001
        pass
    try:
        if not handle.wait_until_active(timeout=10):
            end_takeover("failed", token)
            return _note(tr("Der Rahmen hat den Überflug nicht rechtzeitig gezeigt."))
    except Exception as exc:  # noqa: BLE001
        end_takeover("failed", token)
        return _note(tr("Konnte den Überflug nicht zeigen: {exc}", exc=exc))
    _note(tr("Zeigt gerade den Überflug von {name}.", name=p["name"]))
    return True


def decide_takeover():
    t = now()
    want = None
    for p in all_passes():
        if p.get("takeover"):
            lo, hi = takeover_window(p)
            if lo <= t <= hi:
                want = p
                break
    with _takeover_lock:
        handle = _takeover["handle"]
        held_for = _takeover["passId"]
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        if want is None or want["id"] != held_for:
            end_takeover("done")
        return
    if want is None or want["id"] in _takeover["tried"]:
        return
    _takeover["tried"].add(want["id"])
    if scene_on_screen():
        log("Die Szene läuft schon in einer Playlist und sagt den Überflug selbst an.")
        return
    show_pass(want)


# ---- Takeover-Playlist, die nach dem Zurückgeben weiterläuft ---------------
# Lief vor einem Takeover keine Playlist, stellt die Engine dieses "nichts"
# nicht wieder her, und die Takeover-Playlist läuft einfach weiter (Jans
# Rahmen, 2026-10-24). Jeder Durchlauf hält sie dann mit POST /slideshow/stop
# an: nur wenn sie läuft, niemand den Bildschirm hält und das Plugin nicht
# gerade selbst darum gebeten hat.
_leftover = {"askedAt": 0.0, "failed": False}


def stop_leftover_takeover():
    try:
        playlist_id = _playlists["takeoverId"]
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status", read_timeout=5) or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status", read_timeout=5) or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop", read_timeout=10)
    except Exception as exc:  # noqa: BLE001 - darf die Schleife nie aufhalten
        if not _leftover["failed"]:
            log(f"The takeover playlist kept running and could not be stopped: {exc}", "warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def takeover_loop():
    last_leftover = 0.0
    while not _stop.is_set():
        try:
            if settings()["Takeover"] != "off" or _takeover["handle"] is not None:
                maintain_playlists()
                decide_takeover()
            if now() - last_leftover > 15:
                last_leftover = now()
                stop_leftover_takeover()
        except Exception as exc:  # noqa: BLE001
            log(f"Takeover: {exc}", "warning")
        _wake_takeover.clear()
        _wake_takeover.wait(5)


# --------------------------------------------------------------------------
# Die eigene Playlist
# --------------------------------------------------------------------------

OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=(PLAYLIST_NAME,),
    name=lambda: PLAYLIST_NAME,
    description=lambda: tr("Alle aktiven Satelliten live als Schwarm um die Erde und am Himmel über deinem Haus."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
    held=screen_held,
)


def make_playlist():
    return OWN.create_now()


# --------------------------------------------------------------------------
# Ort suchen
# --------------------------------------------------------------------------

def search_places(query):
    name = (query.get("q") or [""])[0].strip()[:80]
    if len(name) < 2:
        return {"success": True, "places": []}
    try:
        response = requests.get(GEOCODE_URL, params={"name": name, "count": 8, "language": settings()["Language"],
                                                     "format": "json"},
                                timeout=(CONNECT_TIMEOUT, 20),
                                headers={"User-Agent": f"DynaFrame-SatelliteSwarm/{version()}"})
        response.raise_for_status()
        data = response.json()
    except (requests.RequestException, ValueError) as exc:
        return {"success": False, "error": f"Open-Meteo: {exc.__class__.__name__}"}
    out = []
    for row in data.get("results") or []:
        try:
            lat, lon = float(row["latitude"]), float(row["longitude"])
        except (KeyError, TypeError, ValueError):
            continue
        region = ", ".join(str(x) for x in (row.get("admin1"), row.get("country")) if x)
        out.append({"name": row.get("name") or "?", "region": region, "lat": round(lat, 4), "lon": round(lon, 4),
                    "height": row.get("elevation")})
    return {"success": True, "places": out}


# --------------------------------------------------------------------------
# Was die Szene und die Seite bekommen
# --------------------------------------------------------------------------

def public_pass(p):
    keys = ("id", "key", "name", "idx", "start", "end", "max", "maxEl", "azStart", "azMax", "azEnd", "rangeKm",
            "visible", "visibleFrom", "visibleTo", "announce", "takeover", "train", "test")
    return {k: p.get(k) for k in keys if p.get(k) is not None}


def scene_payload(query):
    values = settings()
    have = as_int((query.get("v") or ["-1"])[0], -1)
    with _takeover_lock:
        focus = _takeover["passId"] if _takeover["handle"] is not None else None
    t = now()
    upcoming = [public_pass(p) for p in all_passes() if p["end"] > t][:12]
    head = {"success": True, "settings": {k: values[k] for k in SCENE_SETTINGS}, "now": round(t, 1),
            "error": _cat["error"], "busy": _cat["busy"], "passes": upcoming, "focus": focus,
            "fetchedAt": round(_cat["fetchedAt"]), "counts": _cat["counts"]}
    with _cat_lock:
        if not _cat["cols"]:
            return dict(head, ver=0)
        body = {"ver": _cat["ver"], "t0": _cat["t0"]}
        if have != _cat["ver"]:
            body.update(cols=_cat["cols"], groups=list(orbit.GROUPS),
                        notable={k: v for k, v in _cat["notable"].items()},
                        trains=[{"key": tr_["key"], "count": tr_["count"], "alt": tr_["alt"], "idx": tr_["idx"]}
                                for tr_ in _cat["trains"]])
    return dict(head, **body)


DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))

# --------------------------------------------------------------------------
# Öffentliche Kopie für den Remote Frame
#
# Mit DynaFrames HTTPS/Login verlangt /Plugins/Advanced/<Plugin>/ eine Anmeldung
# (401). Die Remote-Frame-Ansicht (Fire TV, Pi, fremder Browser) ist aber nicht
# angemeldet, sie lädt nur die Szene über /engine-proxy/dynamic-scenes/content/.
# Darum legt das Plugin den Stand für die Szene zusätzlich als Dateien in den
# Ordner der Szene (data/live.json, data/catalog.json); die Szene liest sie, wenn
# sie ihr Plugin nicht erreicht. Geschrieben wird nur bei Änderungen.

_mirror = {"live": {}, "ver": {}}


def scene_dirs():
    root = DFR_DATA_DIR / "dynamic-packages" / SCENE_ID
    try:
        return [d for d in root.glob("*/dynamic") if (d / "scene.dynamic").is_file()]
    except OSError:
        return []


def mirror_once():
    body = scene_payload({"v": ["-1"]})
    cols = body.pop("cols", None)
    catalog = None
    if cols:
        catalog = {"ver": body["ver"], "t0": body["t0"], "cols": cols}
        for key in ("groups", "notable", "trains"):
            catalog[key] = body.pop(key, None)
    body.pop("now", None)
    live_text = json.dumps(body, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    for folder in scene_dirs():
        key = str(folder)
        try:
            if catalog and _mirror["ver"].get(key) != catalog["ver"]:
                write_json(folder / "data" / "catalog.json", catalog)
                _mirror["ver"][key] = catalog["ver"]
            if _mirror["live"].get(key) != live_text:
                write_json(folder / "data" / "live.json", body)
                _mirror["live"][key] = live_text
        except OSError as exc:
            if _mirror["live"].get(key) != "error":
                log(f"Kopie für den Remote Frame in {folder} nicht möglich: {exc}", "warning")
            _mirror["live"][key] = "error"


def mirror_loop():
    while not _stop.is_set():
        try:
            mirror_once()
        except Exception as exc:  # noqa: BLE001
            log(f"Kopie für den Remote Frame: {exc}", "warning")
        _stop.wait(5)


THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    t = now()
    with _takeover_lock:
        note = _takeover["note"] if values["Takeover"] != "off" else ""
    if values["Takeover"] != "off" and not note:
        note = _playlists["note"] or takeover_permission_note()
    with _cat_lock:
        trains = [{"key": x["key"], "count": x["count"], "alt": x["alt"]} for x in _cat["trains"]]
        total = len(_cat["sats"])
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": values,
        "busy": _cat["busy"],
        "error": _cat["error"],
        "satellites": total,
        "counts": _cat["counts"],
        "fetchedAt": _cat["fetchedAt"],
        "nextFetch": _cat["nextFetch"],
        "above": _passes["above"],
        "passes": [public_pass(p) for p in all_passes() if p["end"] > t][:10],
        "trains": trains,
        "takeoverNote": note,
        "theme": {"id": theme_id()},
    }


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(min(length, 1024 * 1024)) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(query), cors=True)
                return
            if path == "/api/places":
                self._json(search_places(query))
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                changed = save_settings(self._body())
                if "MakePlaylist" in changed:
                    OWN.changed()
                if any(name in PASS_SETTINGS for name in changed):
                    _passes["above"] = None
                    _wake_pass.set()
                if "Takeover" in changed:
                    _playlists["at"] = 0.0
                    _wake_takeover.set()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(refresh_now())
                return
            if path == "/api/test":
                self._json(test_pass())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}")
    plugin.on_action("refresh", lambda _context=None: refresh_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())
    plugin.on_action("test-pass", lambda _context=None: test_pass())
    start_studio()
    plugin.connect_sse()
    plugin.ready()
    _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
    threading.Thread(target=fetch_loop, name=f"{PLUGIN_ID}-fetch", daemon=True).start()
    threading.Thread(target=pass_loop, name=f"{PLUGIN_ID}-passes", daemon=True).start()
    threading.Thread(target=takeover_loop, name=f"{PLUGIN_ID}-takeover", daemon=True).start()
    threading.Thread(target=mirror_loop, name=f"{PLUGIN_ID}-mirror", daemon=True).start()
    try:
        while not _stop.is_set():
            _stop.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop.set()
    _wake_fetch.set()
    _wake_pass.set()
    _wake_takeover.set()
    end_takeover("stopped")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:  # noqa: BLE001
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:  # noqa: BLE001
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
