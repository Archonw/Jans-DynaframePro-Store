#!/usr/bin/env python3
"""Jellyfin Now Playing - der Plugin-Teil des Pakets.

Die Szene "jellyfin-now-playing" zeigt, was ein gewählter Jellyfin-Benutzer
gerade schaut oder hört: Cover, Hintergrundbild, Titel, Staffel/Folge, Jahr,
Genres, Inhalt und den Fortschritt. Dieses Plugin macht, was eine Szene nicht
kann:

- Es fragt Jellyfin alle paar Sekunden, was der Benutzer abspielt, und
  liefert der Szene die Daten (/api/scene) und die Bilder (/api/image/...).
  Der API-Schlüssel bleibt im Plugin.
- Solange etwas läuft, holt es die Szene über die laufende Playlist
  (Display-Takeover) und gibt den Bildschirm zurück, sobald nichts mehr läuft.
- Alle Einstellungen liegen auf einer eigenen Seite (Plugins > Jellyfin Now
  Playing öffnen), auf Deutsch, Englisch oder Spanisch.

Bis 0.3.5 war das ein reines Plugin, das das Cover als Bild an DynaFrame gab.
Beim ersten Start räumt es das alte Cover und die alte Playlist
"Jellyfin (takeover)" weg und übernimmt die alten Einstellungen.
"""

import os
import sys
import traceback
from datetime import datetime

_plugin_dir = os.environ.get("DYNAFRAME_PLUGIN_DIR") or os.path.dirname(os.path.abspath(__file__))
try:
    os.chdir(_plugin_dir)
except Exception:
    pass
_crash_log_path = os.path.join(_plugin_dir, "crash.log")


def _write_crash_log(exc_type, exc_value, exc_tb):
    try:
        with open(_crash_log_path, "a") as f:
            f.write(f"\n=== Crash at {datetime.now().isoformat()} ===\n")
            traceback.print_exception(exc_type, exc_value, exc_tb, file=f)
    except Exception:
        pass
    sys.__excepthook__(exc_type, exc_value, exc_tb)


sys.excepthook = _write_crash_log

import hashlib
import json
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

plugin = create_plugin()

import page  # noqa: E402

try:
    import playback_guard  # optional: startet den Quick Mix neu, wenn Dynaframe es nicht tut
except Exception:  # noqa: BLE001
    playback_guard = None

PLUGIN_ID = "JellyfinNowPlaying"
DISPLAY_NAME = "Jellyfin Now Playing"
SCENE_ID = "jellyfin-now-playing"   # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(_plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen und Zustand; bleibt bei Updates
CACHE_DIR = PLUGIN_DIR / "cache"
IMAGE_DIR = CACHE_DIR / "images"
TICKS_PER_MS = 10_000

TAKEOVER_PLAYLIST_NAME = "Jellyfin Now Playing (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Made by the Jellyfin Now Playing plugin. Leave it switched OFF: the plugin "
                                 "plays it by itself while the chosen user is watching.")
OLD_PLAYLIST_NAME = "Jellyfin (takeover)"   # bis 0.3.5
TAKEOVER_ITEM_SECONDS = 6 * 3600
MAX_SESSION_SECONDS = 4 * 3600           # danach fragt das Plugin einfach neu

_shutdown_event = threading.Event()
_wake = threading.Event()
_sync_lock = threading.Lock()
_take_lock = threading.RLock()

# Was gerade läuft, für Szene und Seite.
_now = {"item": None, "key": None, "sampledAt": 0, "positionMs": 0, "paused": False,
        "session": {}, "version": 0}
_details = {}        # item id -> volles Item von Jellyfin (Inhalt, Genres ...)
_images = {}         # Bildname -> (item id, Bildtyp, Index, tag)
_status = {"connection": "", "connectionOk": False, "lastCheckAt": 0, "error": ""}
_take = {"handle": None, "since": None, "note": ""}
_scene = {"dbId": None, "note": ""}


def version():
    try:
        manifest = json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))
        return str(manifest.get("Version") or "")
    except Exception:
        return ""


def now_ms():
    return int(time.time() * 1000)


def cfg():
    return page.settings()


# ---------------------------------------------------------------- Zustand

def _load_state():
    try:
        return json.loads((DATA_DIR / "state.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save_state(**kv):
    st = _load_state()
    st.update(kv)
    try:
        DATA_DIR.mkdir(exist_ok=True)
        (DATA_DIR / "state.json").write_text(json.dumps(st), encoding="utf-8")
    except OSError:
        pass


# ---------------------------------------------------------------- Jellyfin

def _headers(values):
    key = values["ApiKey"]
    return {
        "Authorization": f'MediaBrowser Client="Dynaframe", Device="Dynaframe", '
                         f'DeviceId="dynaframe-jellyfin", Version="{version() or "0.4"}", Token="{key}"',
        "X-Emby-Token": key,
        "Accept": "application/json",
    }


def jf_get(path, binary=False, timeout=15, values=None):
    values = values or cfg()
    if not values["ServerUrl"]:
        raise RuntimeError("no server address")
    req = urllib.request.Request(values["ServerUrl"] + path, headers=_headers(values))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = resp.read()
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            raise RuntimeError(f"HTTP {exc.code}: the API key was refused") from exc
        raise RuntimeError(f"HTTP {exc.code} for {path.split('?')[0]}") from exc
    except (urllib.error.URLError, OSError) as exc:
        reason = getattr(exc, "reason", exc)
        raise RuntimeError(f"server not reachable ({reason})") from exc
    return data if binary else json.loads(data.decode("utf-8"))


def configured(values=None):
    values = values or cfg()
    return bool(values["ServerUrl"] and values["ApiKey"] and values["UserName"])


def find_now_playing(values):
    """(session, item) der zuletzt aktiven Wiedergabe des Benutzers, sonst (None, None)."""
    user = values["UserName"].lower()
    sessions = jf_get("/Sessions?activeWithinSeconds=960", values=values)
    best = None
    for s in sessions or []:
        if str(s.get("UserName", "")).lower() != user:
            continue
        item = s.get("NowPlayingItem")
        if not item:
            continue
        if item.get("Type") == "Audio" and not values["IncludeMusic"]:
            continue
        if (s.get("PlayState") or {}).get("IsPaused") and not values["ShowWhenPaused"]:
            continue
        if best is None or str(s.get("LastActivityDate", "")) > str(best[0].get("LastActivityDate", "")):
            best = (s, item)
    return best if best else (None, None)


def item_details(session, item):
    """Das volle Item (Inhalt, Genres, Bewertung). Einmal je Item."""
    item_id = item.get("Id")
    if item_id in _details:
        return _details[item_id]
    full = {}
    user_id = session.get("UserId")
    try:
        if user_id:
            full = jf_get(f"/Users/{user_id}/Items/{item_id}") or {}
    except Exception as exc:  # noqa: BLE001
        plugin.log(f"Could not read the details of {item.get('Name')}: {exc}", level="warning")
    if len(_details) > 20:
        _details.clear()
    _details[item_id] = full
    return full


def _image_name(kind, item_id, image_type, index, tag):
    raw = f"{item_id}|{image_type}|{index}|{tag or ''}"
    name = f"{kind}-{hashlib.sha1(raw.encode()).hexdigest()[:16]}.jpg"
    _images[name] = (item_id, image_type, index, tag)
    return name


def pick_images(item, full, values):
    """Namen für Cover und Hintergrund (oder None). Die Szene lädt sie über /api/image/."""
    merged = dict(full or {})
    merged.update({k: v for k, v in item.items() if v not in (None, "", [])})
    typ = merged.get("Type")
    poster = backdrop = None
    if typ == "Episode" and values["EpisodeCover"] == "series" and merged.get("SeriesId") \
            and merged.get("SeriesPrimaryImageTag"):
        poster = _image_name("poster", merged["SeriesId"], "Primary", None, merged["SeriesPrimaryImageTag"])
    elif typ == "Audio" and merged.get("AlbumId") and merged.get("AlbumPrimaryImageTag"):
        poster = _image_name("poster", merged["AlbumId"], "Primary", None, merged["AlbumPrimaryImageTag"])
    elif (merged.get("ImageTags") or {}).get("Primary"):
        poster = _image_name("poster", merged["Id"], "Primary", None, merged["ImageTags"]["Primary"])
    elif typ == "Episode" and merged.get("SeriesId"):
        poster = _image_name("poster", merged["SeriesId"], "Primary", None, merged.get("SeriesPrimaryImageTag"))
    if merged.get("BackdropImageTags"):
        backdrop = _image_name("backdrop", merged["Id"], "Backdrop", 0, merged["BackdropImageTags"][0])
    elif merged.get("ParentBackdropItemId") and merged.get("ParentBackdropImageTags"):
        backdrop = _image_name("backdrop", merged["ParentBackdropItemId"], "Backdrop", 0,
                               merged["ParentBackdropImageTags"][0])
    return poster, backdrop


def image_bytes(name):
    """Ein Bild für die Szene, aus dem Cache oder frisch von Jellyfin."""
    if not re.match(r"^(poster|backdrop)-[0-9a-f]{16}\.jpg$", name or ""):
        return None
    path = IMAGE_DIR / name
    if path.exists():
        data = path.read_bytes()
    else:
        ref = _images.get(name)
        if ref is None:
            return None
        item_id, image_type, index, tag = ref
        query = {"quality": 90}
        query.update({"maxHeight": 1200} if image_type == "Primary" else {"maxWidth": 1920})
        if tag:
            query["tag"] = tag
        suffix = f"/{index}" if index is not None else ""
        data = jf_get(f"/Items/{item_id}/Images/{image_type}{suffix}?{urllib.parse.urlencode(query)}",
                      binary=True, timeout=30)
        if len(data) < 64:
            return None
        IMAGE_DIR.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        _trim_images()
    kind = "image/png" if data[:8] == b"\x89PNG\r\n\x1a\n" else \
        "image/webp" if data[8:12] == b"WEBP" else "image/jpeg"
    return data, kind


def _trim_images(keep=12):
    files = sorted(IMAGE_DIR.glob("*.jpg"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in files[keep:]:
        try:
            old.unlink()
        except OSError:
            pass


def _ticks_ms(value):
    try:
        return int(int(value) / TICKS_PER_MS)
    except (TypeError, ValueError):
        return 0


def describe(session, item, values):
    """Alles, was Szene und Seite über das laufende Item brauchen."""
    full = item_details(session, item)
    merged = dict(full or {})
    merged.update({k: v for k, v in item.items() if v not in (None, "", [])})
    typ = merged.get("Type") or ""
    poster, backdrop = pick_images(item, full, values)
    season, episode = merged.get("ParentIndexNumber"), merged.get("IndexNumber")
    info = {
        "id": merged.get("Id"),
        "type": typ,
        "title": merged.get("Name") or "",
        "series": merged.get("SeriesName") or "",
        "season": season if isinstance(season, int) else None,
        "episode": episode if isinstance(episode, int) else None,
        "year": merged.get("ProductionYear"),
        "genres": list(merged.get("Genres") or [])[:3],
        "rating": merged.get("OfficialRating") or "",
        "communityRating": merged.get("CommunityRating"),
        "overview": (merged.get("Overview") or "")[:900],
        "artists": list(merged.get("Artists") or [])[:3],
        "album": merged.get("Album") or "",
        "runtimeMs": _ticks_ms(merged.get("RunTimeTicks")),
        "poster": poster,
        "backdrop": backdrop,
    }
    if typ == "Episode" and values["EpisodeCover"] == "series" and not info["year"]:
        info["year"] = (full or {}).get("ProductionYear")
    return info


def display_title(info):
    if not info:
        return ""
    if info["type"] == "Episode":
        code = f" S{info['season']:02d}E{info['episode']:02d}" if info["season"] is not None \
            and info["episode"] is not None else ""
        return f"{info['series']}{code} - {info['title']}".strip(" -")
    if info["type"] == "Audio":
        return f"{(info['artists'] or [''])[0]} - {info['title']}".strip(" -")
    return f"{info['title']} ({info['year']})" if info["year"] else info["title"]


# ---------------------------------------------------------------- Engine

class EngineError(RuntimeError):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_url():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    h = {"Content-Type": "application/json", "Accept": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    cred = str(getattr(plugin, "plugin_credential", "") or "")
    gen = str(getattr(plugin, "process_generation", "") or "")
    if cred:
        h["X-Dfr-Plugin-Credential"] = cred
    if gen:
        h["X-Dfr-Plugin-Generation"] = gen
    return h


def engine_call(method, path, payload=None, timeout=20):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(engine_url() + path, data=data, method=method, headers=engine_headers())
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
    except urllib.error.HTTPError as exc:
        body = ""
        try:
            body = exc.read().decode("utf-8", "replace")[:200]
        except Exception:
            pass
        raise EngineError(f"{method} {path} returned HTTP {exc.code} {body}", status=exc.code) from exc
    except (urllib.error.URLError, OSError) as exc:
        raise EngineError(f"{method} {path} failed: {exc}") from exc
    if not raw:
        return None
    try:
        return json.loads(raw.decode("utf-8"))
    except ValueError:
        return None


def find_scene():
    """Die installierte Szene. Ihre numerische id braucht der Playlist-Eintrag."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else "sceneOff")
    else:
        _scene.update(dbId=None, note="noScene")
    return _scene["dbId"]


def _playlists():
    rows = engine_call("GET", "/playlists") or []
    if isinstance(rows, dict):
        rows = rows.get("playlists") or []
    return [p for p in rows if isinstance(p, dict)]


def _playlist_items(pid):
    items = engine_call("GET", f"/playlists/{pid}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def _get_playlist(pid):
    try:
        return engine_call("GET", f"/playlists/{pid}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def ensure_takeover_playlist():
    """Ein Takeover spielt eine Playlist: die Szene allein, ausgeschaltet."""
    pid = _load_state().get("takeoverPlaylistId")
    playlist = _get_playlist(pid) if pid else None
    if playlist is None:
        playlist = next((p for p in _playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        pid = playlist.get("id") if playlist else None
    if playlist is not None and pid:
        items = _playlist_items(pid)
        if len(items) == 1 and items[0].get("dynamicSceneId") == _scene["dbId"]:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{pid}", {"isEnabled": False})
            if str(pid) != str(_load_state().get("takeoverPlaylistId")):
                _save_state(takeoverPlaylistId=pid)
            return pid
        engine_call("DELETE", f"/playlists/{pid}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_PLAYLIST_DESCRIPTION}) or {}
    pid = created.get("id") or (created.get("playlist") or {}).get("id")
    if not pid:
        raise EngineError("The frame did not make the takeover playlist")
    engine_call("POST", f"/playlists/{pid}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{pid}", {"isEnabled": False})  # neue Playlists sind sonst im Mix
    _save_state(takeoverPlaylistId=pid)
    plugin.log(f"Made the playlist {TAKEOVER_PLAYLIST_NAME} ({pid}). Leave it switched OFF.")
    return pid


def cleanup_old_version():
    """Einmal nach dem Update von 0.3.x: altes Cover und alte Playlist weg."""
    state = _load_state()
    if state.get("cleaned040"):
        return
    try:
        plugin.submit_media([], replace_catalog=True)
    except Exception:  # noqa: BLE001
        pass
    for f in CACHE_DIR.glob("jellyfin_*"):
        try:
            f.unlink()
        except OSError:
            pass
    try:
        old = state.get("playlistId")
        ids = {str(old)} if old else set()
        ids |= {str(p.get("id")) for p in _playlists() if p.get("name") == OLD_PLAYLIST_NAME}
        for pid in ids:
            try:
                engine_call("DELETE", f"/playlists/{pid}")
                plugin.log(f"Removed the old playlist {OLD_PLAYLIST_NAME} ({pid}).")
            except EngineError as exc:
                if exc.status != 404:
                    raise
    except EngineError as exc:
        plugin.log(f"Could not tidy up the old version yet: {exc}", level="warning")
        return
    _save_state(cleaned040=True, playlistId=None)


def permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    enabled = config.get("enabledPluginNames")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return "noPermission"
    return ""


# ---------------------------------------------------------------- Takeover

def _on_session_state(h):
    state = str(getattr(h, "state", h)).strip().lower()
    if state in ("preempted", "expired", "failed", "released"):
        with _take_lock:
            if _take["handle"] is h or not hasattr(h, "state"):
                _take.update(handle=None, since=None, note="ended:" + state)
        plugin.log(f"The frame ended the takeover ({state}).")


def _renderer_url():
    parts = urllib.parse.urlparse(engine_url())
    return f"{parts.scheme}://{parts.hostname}:8080"


def _after_release():
    """Nach der Rückgabe: Dynaframe zurück zur Playlist bringen. Ist nichts
    gewählt, bliebe die Szene stehen, also lieber schwarz."""
    outcome = None
    if playback_guard is not None:
        try:
            outcome = playback_guard.restore_if_stalled(
                engine_url(), engine_headers, plugin.log, stop_event=_shutdown_event)
        except Exception as exc:  # noqa: BLE001
            plugin.log(f"Playback check failed: {exc}", level="warning")
    else:
        _shutdown_event.wait(6)
    if outcome not in (None, "not-requested", "skipped") or _shutdown_event.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
        if status.get("isRunning") or status.get("isPaused"):
            return
        if (engine_call("GET", "/display-sessions/status") or {}).get("active"):
            return
        black = PLUGIN_DIR / "assets" / "black.png"
        if not black.exists():
            return
        data = json.dumps({"path": str(black), "mediaType": "image"}).encode("utf-8")
        req = urllib.request.Request(_renderer_url() + "/play", data=data, method="POST",
                                     headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=10).read()
        plugin.log("Nothing is selected to play, so the screen shows black instead of the scene.")
    except Exception as exc:  # noqa: BLE001
        plugin.log(f"Could not clear the screen after the scene: {exc}", level="warning")


# ---- Takeover-Playlist, die nach dem Zurückgeben weiterläuft ---------------
# Lief vor einem Takeover keine Playlist, stellt die Engine dieses "nichts"
# nicht wieder her, und die Takeover-Playlist läuft einfach weiter (Jans
# Rahmen, 2026-10-24). Jeder Durchlauf hält sie dann mit POST /slideshow/stop
# an: nur wenn sie läuft, niemand den Bildschirm hält und das Plugin nicht
# gerade selbst darum gebeten hat.
_leftover = {"askedAt": 0.0, "failed": False}


def stop_leftover_takeover():
    try:
        playlist_id = _load_state().get("takeoverPlaylistId")
        if _take["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status", timeout=5) or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status", timeout=5) or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop", timeout=10)
    except Exception as exc:  # noqa: BLE001 - darf die Schleife nie aufhalten
        if not _leftover["failed"]:
            plugin.log(f"The takeover playlist kept running and could not be stopped: {exc}", level="warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    plugin.log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def release_takeover(reason="done"):
    with _take_lock:
        handle = _take["handle"]
        _take.update(handle=None, since=None)
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:  # noqa: BLE001
        plugin.log(f"Could not hand the screen back: {exc}", level="warning")
    plugin.log(f"Handed the screen back ({reason}).")
    if reason == "nothing playing":
        threading.Thread(target=_after_release, daemon=True).start()
    return True


def _set_note(code):
    with _take_lock:
        changed = _take["note"] != code
        _take["note"] = code
    if changed and code:
        plugin.log(f"Takeover not possible: {code}", level="warning")


def apply_takeover(playing, values):
    """Nach jeder Abfrage. playing: läuft gerade etwas für den Benutzer?"""
    with _take_lock:
        if not playing:
            if release_takeover("nothing playing"):
                _take["note"] = ""
            return
        if not values["Takeover"]:
            release_takeover("takeover off")
            _take["note"] = ""
            return
        if _take["handle"] is not None:
            return
        if "display-sessions-v1" not in (getattr(plugin, "features", None) or {"display-sessions-v1"}):
            return _set_note("tooOld")
        if find_scene() is None or _scene["note"]:
            return _set_note(_scene["note"] or "noScene")
        status = engine_call("GET", "/display-sessions/status") or {}
        if status.get("active"):
            return _set_note("busy")  # ein anderes Plugin hat den Bildschirm
        try:
            pid = ensure_takeover_playlist()
        except EngineError as exc:
            plugin.log(f"Takeover playlist: {exc}", level="warning")
            return _set_note("playlist")
        _leftover["askedAt"] = time.time()
        handle = plugin.acquire_display_session(
            session_key="jellyfin-now-playing",
            state={"playback": {"kind": "playlist", "playlistId": pid, "isRunning": True},
                   "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "transitionDurationMs": 600,
                                "randomizeOrder": False},
                   "overlay": {"enabled": values["ShowOverlay"]}},
            display_name=DISPLAY_NAME,
            max_duration_seconds=MAX_SESSION_SECONDS,
            wake_if_off=False)
        if handle is None:
            return _set_note(permission_note() or "busy")
        _take.update(handle=handle, since=time.time(), note="")
        try:
            handle.on_state_change(_on_session_state)
        except Exception:  # noqa: BLE001
            pass
        try:
            if not handle.wait_until_active(timeout=10):
                release_takeover("failed")
                return _set_note("failed")
        except Exception:  # noqa: BLE001
            release_takeover("failed")
            raise
        plugin.log("Jellyfin Now Playing is on the screen.")


# ---------------------------------------------------------------- Abfrage

def sync_once():
    """Eine Abfrage. True, wenn gerade etwas läuft."""
    if not _sync_lock.acquire(blocking=False):
        return _now["item"] is not None
    try:
        values = cfg()
        _status["lastCheckAt"] = now_ms()
        if not configured(values):
            _status.update(connection="unset", connectionOk=False, error="")
            session, item = None, None
        else:
            try:
                session, item = find_now_playing(values)
            except Exception as exc:
                _status.update(connection="error", connectionOk=False, error=str(exc))
                raise
            _status.update(connection="ok", connectionOk=True, error="")
        key = None
        if item is not None:
            key = f"{item.get('Id')}|{values['EpisodeCover']}"
        if key != _now["key"]:
            info = describe(session, item, values) if item is not None else None
            if info:
                plugin.log(f"Now playing: {display_title(info)}")
            elif _now["item"]:
                plugin.log("Nothing is playing any more.")
            _now.update(item=info, key=key)
        play = (session or {}).get("PlayState") or {}
        _now.update(sampledAt=now_ms(), positionMs=_ticks_ms(play.get("PositionTicks")),
                    paused=bool(play.get("IsPaused")),
                    session={"device": (session or {}).get("DeviceName") or "",
                             "client": (session or {}).get("Client") or "",
                             "user": (session or {}).get("UserName") or ""},
                    version=_now["version"] + 1)
        playing = _now["item"] is not None
        try:
            apply_takeover(playing, values)
        except Exception as exc:  # noqa: BLE001
            plugin.log(f"Takeover problem: {exc}", level="warning")
        return playing
    finally:
        _sync_lock.release()


def main_loop():
    failures = 0
    while plugin.is_running() and not _shutdown_event.is_set():
        try:
            sync_once()
            failures = 0
        except Exception as exc:  # noqa: BLE001
            failures += 1
            if failures in (1, 10) or failures % 60 == 0:
                plugin.log(f"Jellyfin not reachable / error: {exc}", level="warning")
            # Ohne Verbindung weiß niemand, ob noch etwas läuft: nach einer
            # Weile den Bildschirm lieber zurückgeben.
            if failures == 6:
                _now.update(item=None, key=None)
                release_takeover("nothing playing")
        stop_leftover_takeover()
        _wake.wait(cfg()["PollSeconds"])
        _wake.clear()


# ---------------------------------------------------------------- Seite und Szene

def scene_payload():
    values = cfg()
    item = _now["item"]
    return {
        "success": True,
        "lang": values["Language"],
        "look": values["Look"],
        "showOverview": values["ShowOverview"],
        "showClock": values["ShowClock"],
        "playing": item is not None,
        "item": item,
        "positionMs": _now["positionMs"],
        "paused": _now["paused"],
        "sampledAt": _now["sampledAt"],
        "serverNow": now_ms(),
        "device": _now["session"].get("device", ""),
        "version": _now["version"],
    }


def page_state():
    with _take_lock:
        take = {"active": _take["handle"] is not None, "since": int((_take["since"] or 0) * 1000),
                "note": _take["note"]}
    if not take["active"] and not take["note"] and cfg()["Takeover"]:
        take["note"] = permission_note()
    return {"version": version(), "status": dict(_status), "now": scene_payload(), "takeover": take,
            "scene": {"found": _scene["dbId"] is not None, "note": _scene["note"]}}


def on_settings_changed(changed):
    changed = set(changed)
    if changed & {"ServerUrl", "ApiKey", "UserName", "EpisodeCover", "IncludeMusic", "ShowWhenPaused"}:
        _now["key"] = "?"    # neu beschreiben (Cover-Wahl, anderer Benutzer ...)
        _details.clear()
    if "ShowOverlay" in changed:
        release_takeover("overlay setting changed")   # beim nächsten Mal mit der neuen Einstellung
    _wake.set()


def action_refresh(_body=None):
    _wake.set()
    return {"success": True}


def action_test(_body=None):
    values = cfg()
    if not values["ServerUrl"] or not values["ApiKey"]:
        return {"success": True, "ok": False, "code": "unset"}
    try:
        info = jf_get("/System/Info/Public", values=values)
        names = [u.get("Name") for u in jf_get("/Users", values=values) or [] if u.get("Name")]
    except Exception as exc:  # noqa: BLE001
        plugin.log(f"Test failed: {exc}", level="error")
        return {"success": True, "ok": False, "error": str(exc)}
    user_known = any(n.lower() == values["UserName"].lower() for n in names) if values["UserName"] else None
    server = f"{info.get('ServerName', 'Jellyfin')} {info.get('Version', '')}".strip()
    plugin.log(f"Connected to {server}. Users: {', '.join(names)}")
    _wake.set()
    return {"success": True, "ok": True, "server": server, "users": names, "userKnown": user_known}


def refresh(_action=None):
    plugin.content_refresh_started("Checking Jellyfin...")
    try:
        sync_once()
    except Exception as exc:  # noqa: BLE001
        plugin.content_refresh_failed(f"Jellyfin check failed: {exc}")
    else:
        plugin.content_refresh_completed(1 if _now["item"] else 0, "Jellyfin is up to date.")


def test_connection(_action=None):
    result = action_test()
    if not result.get("ok"):
        plugin.log(f"Test failed: {result.get('error') or 'server address or API key missing'}", level="error")


def main():
    DATA_DIR.mkdir(exist_ok=True)
    page.migrate(plugin)
    plugin.on_action("refresh", refresh)
    plugin.on_action("test-connection", test_connection)
    page.start(plugin, state=page_state, changed=on_settings_changed, scene=scene_payload,
               image=image_bytes, actions={"refresh": action_refresh, "test": action_test})
    plugin.connect_sse()
    plugin.ready()
    plugin.log(f"Jellyfin Now Playing {version()} started")
    cleanup_old_version()
    find_scene()
    if not configured():
        plugin.log("Open the plugin page and enter server address, API key and user name.", level="warning")
    try:
        main_loop()
    finally:
        _shutdown_event.set()
        release_takeover("stopping")
        page.stop(plugin)


if __name__ == "__main__":
    main()
