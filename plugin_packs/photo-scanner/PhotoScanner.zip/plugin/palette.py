"""Die Hauptfarben eines Fotos (aus Color Palette).

Vorgehen:
1. Das Foto auf etwa 160 Pixel verkleinern (JPEG wird gleich klein dekodiert).
2. Pillow fasst die Pixel zu 32 Farben zusammen (Median Cut, mit k-means
   nachgeschärft). Das geht in C und braucht auf dem Pi 4 wenige Millisekunden.
3. Diese 32 Farben in Lab umrechnen (Abstände wie das Auge sie sieht), fast
   gleiche zusammenlegen.
4. Gierig auswählen: zuerst die Farbe mit der meisten Fläche (kräftige Farben
   zählen etwas mehr als Grau), danach immer die, die viel Fläche hat UND sich
   von den schon gewählten deutlich unterscheidet. So kommen das helle Sandbeige,
   das dunkle Oliv und das Blau eines Strandfotos zusammen, statt fünf Grautöne.
5. Jede der 32 Farben zählt zur nächsten gewählten: das ist der Anteil.

Ergebnis: [{"hex": "cdbcaa", "share": 0.31}, ...], sortiert wie gewünscht.
"""

import colorsys
import io
import math

CANDIDATES = 32
THUMB = 160


# --------------------------------------------------------------------------
# Farbräume
# --------------------------------------------------------------------------

def _lin(c):
    c /= 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def rgb_to_lab(rgb):
    r, g, b = (_lin(c) for c in rgb)
    x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047
    y = 0.2126 * r + 0.7152 * g + 0.0722 * b
    z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883

    def f(t):
        return t ** (1 / 3) if t > 0.008856 else 7.787 * t + 16 / 116

    fx, fy, fz = f(x), f(y), f(z)
    return (116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz))


def delta(a, b):
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2)


def chroma(lab):
    return math.hypot(lab[1], lab[2])


def to_hex(rgb):
    return "%02x%02x%02x" % tuple(max(0, min(255, int(round(c)))) for c in rgb)


# --------------------------------------------------------------------------
# Auswahl
# --------------------------------------------------------------------------

def _candidates(image):
    """[(rgb, anteil)] aus einem kleinen PIL-Bild (RGB)."""
    from PIL import Image

    total = image.width * image.height
    try:
        quant = image.quantize(colors=CANDIDATES, method=Image.Quantize.MEDIANCUT, kmeans=2)
    except (AttributeError, TypeError, ValueError):   # sehr altes Pillow
        quant = image.quantize(colors=CANDIDATES)
    pal = quant.getpalette() or []
    out = []
    for count, idx in quant.getcolors(CANDIDATES * 4) or []:
        rgb = tuple(pal[idx * 3: idx * 3 + 3])
        if len(rgb) == 3 and count:
            out.append((rgb, count / total))
    return out


def _merge(cands, limit=4.5):
    """Fast gleiche Farben (Delta E < limit) zusammenlegen."""
    rows = []   # [lab, rgb, share]
    for rgb, share in sorted(cands, key=lambda c: -c[1]):
        lab = rgb_to_lab(rgb)
        for row in rows:
            if delta(row[0], lab) < limit:
                total = row[2] + share
                row[1] = tuple((row[1][i] * row[2] + rgb[i] * share) / total for i in range(3))
                row[2] = total
                row[0] = rgb_to_lab(row[1])
                break
        else:
            rows.append([lab, rgb, share])
    return rows


def _weight(row):
    """Fläche, kräftige Farben etwas mehr, fast Schwarz und fast Weiß etwas weniger."""
    lab, _rgb, share = row
    c = min(chroma(lab), 80) / 80
    l = lab[0]
    edge = 0.55 if (l < 8 or l > 97) else 1.0
    return share * (0.7 + 1.1 * c) * edge


def pick(rows, count):
    if not rows:
        return []
    chosen = [max(rows, key=_weight)]
    while len(chosen) < min(count, len(rows)):
        best, best_score = None, -1.0
        for row in rows:
            if any(row is c for c in chosen):
                continue
            d = min(delta(row[0], c[0]) for c in chosen)
            # Abstand zählt bis ~45 voll, darunter stark weniger; sehr kleine Flächen bremsen
            spread = min(d, 45) / 45
            score = (_weight(row) ** 0.55) * (spread ** 1.6)
            if score > best_score:
                best, best_score = row, score
        if best is None:
            break
        chosen.append(best)
    # Anteile: jede Kandidatenfarbe gehört zur nächsten gewählten
    shares = [0.0] * len(chosen)
    for row in rows:
        i = min(range(len(chosen)), key=lambda j: delta(row[0], chosen[j][0]))
        shares[i] += row[2]
    total = sum(shares) or 1.0
    return [(chosen[i], shares[i] / total) for i in range(len(chosen))]


def order(colours, how):
    """colours: [{"hex","share","l","h"}]; how: share | light | dark | hue."""
    if how == "light":
        return sorted(colours, key=lambda c: -c["l"])
    if how == "dark":
        return sorted(colours, key=lambda c: c["l"])
    if how == "hue":
        # Graue ans Ende, sonst wie im Regenbogen
        return sorted(colours, key=lambda c: (c["c"] < 8, c["h"] if c["c"] >= 8 else -c["l"]))
    return sorted(colours, key=lambda c: -c["share"])


def from_image(image, count=5, sort="share"):
    """Palette aus einem PIL-Bild (beliebige Größe)."""
    small = image.convert("RGB")
    small.thumbnail((THUMB, THUMB))
    rows = _merge(_candidates(small))
    out = []
    for (lab, rgb, _share), share in pick(rows, count):
        h, _l, _s = colorsys.rgb_to_hls(*(c / 255 for c in rgb))
        out.append({"hex": to_hex(rgb), "share": round(share, 3), "l": round(lab[0], 1),
                    "c": round(chroma(lab), 1), "h": round(h * 360, 1)})
    return order(out, sort)


def from_bytes(data, count=5, sort="share"):
    from PIL import Image

    with Image.open(io.BytesIO(data)) as image:
        try:
            image.draft("RGB", (THUMB * 2, THUMB * 2))
        except (AttributeError, ValueError, OSError):
            pass
        return from_image(image, count, sort)
