/* Endless Stairs - die Szene.
 *
 * Man geht langsam eine endlose Treppe hoch. Links an der Wand hängen die
 * Fotos in verschiedenen Bilderrahmen, rechts ist eine geschlossene Wand mit
 * Handlauf. Nach jedem Treppenlauf kommt ein Absatz, dann geht es nach rechts
 * um die Ecke und weiter hoch (wie ein eckiges Treppenhaus, ohne Ende).
 *
 * So funktioniert es:
 *  - Ein Treppenlauf ("flight") hat eigene Koordinaten: Stufen steigen entlang
 *    +z, die Bilderwand ist x=0 (links), die rechte Wand x=-W. Oben liegt ein
 *    Absatz, der nächste Lauf beginnt dort um 90° nach rechts gedreht.
 *  - Es gibt höchstens drei Läufe: den vorigen, den aktuellen, den nächsten.
 *    Wechselt man in den nächsten Lauf, wird alles so verschoben, dass der
 *    aktuelle Lauf wieder im Ursprung liegt (keine riesigen Zahlen).
 *  - Fotos kommen eins nach dem anderen vom Plugin. Jedes neue Foto bekommt
 *    einen Rahmen an der nächsten freien Stelle der Wand, immer weit voraus
 *    (meist um die Ecke, also unsichtbar). Fehlen Fotos, bleibt man stehen.
 *  - Ab und zu bleibt man vor einem Bild stehen und dreht sich hin.
 *
 * Gezeichnet mit three.js (WebGL). Für den Pi 4: keine Schattenberechnung
 * (weiche Schatten sind fertige Bilder), wenige Lichter, Stufen als
 * Instanzen, die Auflösung sinkt von selbst, wenn es ruckelt.
 *
 * Zum Ausprobieren: ?plugin=<URL der Plugin-Seite> &lang=de|en|es &speed=2
 * &demo=1 (Fotos aus ?photos=a.jpg,b.jpg oder gemalt, ohne Plugin)
 * &look=light|dark &pace=slow|calm|lively &stops=never|sometimes|often|every
 * &stop=8 &flight=10 &seed=3
 * Standbilder für Store-Bilder: &freeze=1 &at=<Meter auf dem Weg> (&hold=1:
 * vor dem nächsten Bild stehen)
 */
import * as THREE from "three";

const PLUGIN_ID = "EndlessStairs";
const params = new URLSearchParams(location.search);
const SPEED = Math.max(0.1, Number(params.get("speed")) || 1);
const DEMO = params.get("demo") === "1";
const FREEZE = params.get("freeze") === "1";
const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
// Über die Weboberfläche (Port 80/443, z. B. RemoteFrame über HTTPS) nur derselbe Ursprung:
// mit DynaFrames HTTPS/Login verwirft die Firewall :8003 von außen ohne Antwort.
const viaWebUi = location.port === "" || location.port === "80" || location.port === "443";
const pluginBases = params.get("plugin") ? [params.get("plugin").replace(/\/?$/, "/")]
  : viaWebUi && /^https?:$/.test(location.protocol) ? [`${location.origin}${advanced}`]
  : [...new Set([
    `${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`,
    `http://${location.hostname || "localhost"}${advanced}`
  ])];
let baseIndex = 0;

const TEXT = {
  de: {
    wait: "Endless Stairs liest die Fotos …", none: "Endless Stairs findet keine Fotos. Wähle auf der Plugin-Seite eine Quelle.",
    unreachable: "Endless Stairs antwortet nicht.", login: "Bitte zuerst im Browser beim Rahmen anmelden.",
    nogl: "Dieser Bildschirm kann kein 3D (WebGL)."
  },
  en: {
    wait: "Endless Stairs is reading the photos …", none: "Endless Stairs finds no photos. Pick a source on the plugin page.",
    unreachable: "Endless Stairs is not responding.", login: "Please sign in to the frame in the browser first.",
    nogl: "This screen cannot draw 3D (WebGL)."
  },
  es: {
    wait: "Endless Stairs está leyendo las fotos …", none: "Endless Stairs no encuentra fotos. Elige una fuente en la página del plugin.",
    unreachable: "Endless Stairs no responde.", login: "Inicia sesión primero en el marco desde el navegador.",
    nogl: "Esta pantalla no puede dibujar 3D (WebGL)."
  }
};
let lang = params.get("lang") || "en";
const tx = (key) => (TEXT[lang] || TEXT.en)[key] ?? TEXT.en[key] ?? key;

const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const lerp = (a, b, k) => a + (b - a) * k;
const smooth = (k) => { k = clamp(k); return k * k * (3 - 2 * k); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms / SPEED));

// Zufall, mit ?seed= wiederholbar (für Store-Bilder)
let seed = Number(params.get("seed")) || 0;
const rand = seed ? () => {
  seed = (seed + 0x6D2B79F5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
} : Math.random;
const pick = (list) => list[Math.floor(rand() * list.length)];

// ------------------------------------------------------------ Plugin

async function fetchTimed(target, ms) {
  const control = typeof AbortController === "function" ? new AbortController() : null;
  const timer = control ? setTimeout(() => control.abort(), ms) : 0;
  try {
    return await fetch(target, { cache: "no-store", credentials: "same-origin", signal: control ? control.signal : undefined });
  } finally {
    clearTimeout(timer);
  }
}

async function api(path) {
  let lastError = null;
  for (let i = 0; i < pluginBases.length; i += 1) {
    const base = pluginBases[(baseIndex + i) % pluginBases.length];
    try {
      const response = await fetchTimed(base + path, 12000);
      if (response.redirected && /login/i.test(response.url)) throw new Error("login");
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const body = await response.json();
      baseIndex = (baseIndex + i) % pluginBases.length;
      return body;
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError || new Error("unreachable");
}
const url = (path) => pluginBases[baseIndex] + path;

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";     // als WebGL-Textur nur mit CORS
    img.decoding = "async";
    const timer = setTimeout(() => { img.src = ""; reject(new Error("image timeout")); }, 30000);
    img.onload = () => { clearTimeout(timer); resolve(img); };
    img.onerror = () => { clearTimeout(timer); reject(new Error("image")); };
    img.src = src;
  });
}

function report(message) {
  if (!DEMO) api("api/report?m=" + encodeURIComponent(String(message).slice(0, 180))).catch(() => {});
}

// DynaFrame wartet, bis die Szene meldet, dass sie steht; sonst bricht der
// Fernseher nach einer Frist ab ("scene readiness deadline expired").
let readySent = false;
function ready() {
  if (readySent) return;
  readySent = true;
  try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
}
setTimeout(ready, 8000);

const note = document.getElementById("note");
function showNote(text) {
  note.textContent = text || "";
  note.hidden = !text;
}

// ------------------------------------------------------------ Einstellungen

const KEYMAP = { Look: "look", Pace: "pace", Stops: "stops", StopSeconds: "stop", FlightPictures: "flight" };
const cfg = {
  Look: params.get("look") || "light", Pace: params.get("pace") || "calm",
  Stops: params.get("stops") || "sometimes", StopSeconds: Number(params.get("stop")) || 8,
  FlightPictures: Number(params.get("flight")) || 10
};
let built = false;
function applySettings(s) {
  if (!s) return;
  if (s.Language && !params.get("lang")) lang = s.Language;
  const before = cfg.Look + "/" + cfg.FlightPictures;
  for (const key of Object.keys(cfg)) {
    if (s[key] === undefined || params.has(KEYMAP[key])) continue;
    cfg[key] = s[key];
  }
  cfg.StopSeconds = clamp(Number(cfg.StopSeconds) || 8, 2, 600);
  cfg.FlightPictures = clamp(Math.round(Number(cfg.FlightPictures) || 10), 4, 24);
  document.documentElement.lang = lang;
  // Anderes Treppenhaus: neu laden (passiert nur nach einer Änderung auf der Seite)
  if (built && before !== cfg.Look + "/" + cfg.FlightPictures) location.reload();
}
const PACE = { slow: 0.13, calm: 0.2, lively: 0.32 };
const STOP_CHANCE = { never: 0, sometimes: 0.22, often: 0.5, every: 1 };

// ------------------------------------------------------------ Maße (Meter)

const R = 0.18, T = 0.28, SLOPE = R / T, ANG = Math.atan(SLOPE), W = 1.15;
const EYE = 1.62, CX = -0.95, HANG = 1.42;
let NSTEPS = 26, L = NSTEPS * T, H = NSTEPS * R;
function setFlightSize() {
  // etwa 0,85 m Wand je Bild, plus Platz am Anfang und Ende
  NSTEPS = clamp(Math.round((cfg.FlightPictures * 0.85 + 0.6) / T), 21, 80);
  L = NSTEPS * T; H = NSTEPS * R;
}
const lineY = (z) => clamp(z, 0, L) * SLOPE;

// ------------------------------------------------------------ Renderer

let renderer;
try {
  renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance", preserveDrawingBuffer: FREEZE });
} catch (error) {
  showNote(tx("nogl"));
  ready();
  throw error;
}
let pixelRatio = Math.min(window.devicePixelRatio || 1, 1);
renderer.setPixelRatio(pixelRatio);
renderer.setSize(innerWidth, innerHeight);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.domElement.id = "stage";
document.body.prepend(renderer.domElement);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(58, innerWidth / innerHeight, 0.05, 40);
scene.add(camera);
addEventListener("resize", () => {
  renderer.setSize(innerWidth, innerHeight);
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
});

// ------------------------------------------------------------ Texturen (gemalt)

function canvasTex(w, h, draw, repeat) {
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  draw(c.getContext("2d"), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4;
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeat[0], repeat[1]); }
  return t;
}
function woodTex(base, dark, w = 512, h = 128) {
  return canvasTex(w, h, (g, Wd, Ht) => {
    g.fillStyle = base; g.fillRect(0, 0, Wd, Ht);
    for (let i = 0; i < 90; i += 1) {
      const y0 = rand() * Ht, a = 0.05 + rand() * 0.18, amp = 1 + rand() * 4, f = 0.004 + rand() * 0.01;
      g.strokeStyle = dark; g.globalAlpha = a; g.lineWidth = 0.6 + rand() * 2.2; g.beginPath();
      for (let x = 0; x <= Wd; x += 6) g.lineTo(x, y0 + Math.sin(x * f + i) * amp);
      g.stroke();
    }
    g.globalAlpha = 1;
  });
}
function plasterTex(base, n) {
  return canvasTex(512, 512, (g, Wd, Ht) => {
    g.fillStyle = base; g.fillRect(0, 0, Wd, Ht);
    const d = g.getImageData(0, 0, Wd, Ht);
    for (let i = 0; i < d.data.length; i += 4) {
      const v = (rand() - 0.5) * 255 * n; d.data[i] += v; d.data[i + 1] += v; d.data[i + 2] += v;
    }
    g.putImageData(d, 0, 0);
  }, [1, 1]);
}
function stripeTex(a, b) {
  return canvasTex(256, 256, (g, Wd, Ht) => {
    g.fillStyle = a; g.fillRect(0, 0, Wd, Ht);
    g.fillStyle = b; for (let x = 0; x < Wd; x += 64) g.fillRect(x, 0, 30, Ht);
    g.globalAlpha = 0.05;
    for (let i = 0; i < 4000; i += 1) { g.fillStyle = rand() < 0.5 ? "#000" : "#fff"; g.fillRect(rand() * Wd, rand() * Ht, 1, 1); }
  }, [1, 1]);
}
// weicher Schatten eines Rahmens (fertig gemalt statt berechnet)
const shadowTex = canvasTex(128, 128, (g) => {
  g.filter = "blur(9px)";
  g.fillStyle = "#000";
  g.fillRect(24, 24, 80, 80);
});
// Lichtkegel einer Bilderleuchte
const glowTex = canvasTex(128, 128, (g) => {
  g.scale(1, 2);
  const r = g.createRadialGradient(64, 0, 2, 64, 0, 62);
  r.addColorStop(0, "rgba(255,226,170,0.95)"); r.addColorStop(0.45, "rgba(255,210,150,0.35)"); r.addColorStop(1, "rgba(255,200,140,0)");
  g.fillStyle = r; g.fillRect(0, 0, 128, 64);
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.globalCompositeOperation = "destination-in";          // oben weich auslaufen, keine Kante
  const fade = g.createLinearGradient(0, 0, 0, 128);
  fade.addColorStop(0, "rgba(0,0,0,0)"); fade.addColorStop(0.12, "rgba(0,0,0,1)"); fade.addColorStop(1, "rgba(0,0,0,1)");
  const side = g.createLinearGradient(0, 0, 128, 0);
  g.fillStyle = fade; g.fillRect(0, 0, 128, 128);
  side.addColorStop(0, "rgba(0,0,0,0)"); side.addColorStop(0.15, "rgba(0,0,0,1)"); side.addColorStop(0.85, "rgba(0,0,0,1)"); side.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = side; g.fillRect(0, 0, 128, 128);
});

// ------------------------------------------------------------ Aussehen

let S, M, FS, mats;
function makeStyle() {
  if (cfg.Look === "dark") {
    return {
      wall: stripeTex("#2f4a3e", "#2a4237"), wallRep: 0.64, ceiling: 0xd8d2c4,
      tread: woodTex("#5a3a22", "#2c1a0e"), riser: 0xe8e2d6, skirting: 0xe8e2d6, runner: 0x6b1e24,
      rail: new THREE.MeshStandardMaterial({ color: 0xb8913f, metalness: 1, roughness: 0.3 }),
      hemi: 0.8, dir: 0.5, head: 1.8, exposure: 1.2, bg: 0x141412, fog: [4.5, 12], envLevel: 0.35, envColor: 0x2a2a26,
      photoTint: 0xdcd7cf, pictureLights: true,
      frames: ["gold", "walnut", "gold", "black", "goldOrnate", "walnut", "gold", "silver"]
    };
  }
  return {
    wall: plasterTex("#d6d3ce", 0.05), wallRep: 1.6, ceiling: 0xf3f1ec,
    tread: woodTex("#c79f6e", "#8a6538"), riserWood: true, skirting: 0xd6d3ce, runner: null,
    rail: new THREE.MeshStandardMaterial({ color: 0x1b1b1b, metalness: 0.6, roughness: 0.35 }),
    hemi: 1.7, dir: 1.4, head: 1.3, exposure: 1.35, bg: 0xe9e7e3, fog: [6.5, 15], envLevel: 0.6, envColor: 0x9a958c,
    photoTint: 0xf6f4f0, pictureLights: false,
    frames: ["black", "black", "white", "oak", "black", "silver", "white", "oak"]
  };
}

function makeMaterials() {
  // Umgebung für Metall-Spiegelungen (Gold, Silber, Handlauf)
  const env = new THREE.Scene();
  env.add(new THREE.Mesh(new THREE.BoxGeometry(10, 6, 10), new THREE.MeshBasicMaterial({ color: S.envColor, side: THREE.BackSide })));
  const l1 = new THREE.Mesh(new THREE.PlaneGeometry(3, 2), new THREE.MeshBasicMaterial({ color: 0xffffff }));
  l1.position.set(0, 2.9, 0); l1.rotation.x = Math.PI / 2; env.add(l1);
  const l2 = new THREE.Mesh(new THREE.PlaneGeometry(2, 3), new THREE.MeshBasicMaterial({ color: 0xfff1d6 }));
  l2.position.set(4.9, 1, 0); l2.rotation.y = -Math.PI / 2; env.add(l2);
  const pm = new THREE.PMREMGenerator(renderer);
  scene.environment = pm.fromScene(env, 0.04).texture;
  scene.environmentIntensity = S.envLevel;
  pm.dispose();

  M = {
    black: new THREE.MeshLambertMaterial({ color: 0x151515 }),
    white: new THREE.MeshLambertMaterial({ color: 0xf2efe8 }),
    oak: new THREE.MeshLambertMaterial({ map: woodTex("#c49a63", "#7a5530", 256, 64) }),
    walnut: new THREE.MeshLambertMaterial({ map: woodTex("#5b3a22", "#24140a", 256, 64) }),
    gold: new THREE.MeshStandardMaterial({ color: 0xc8a050, metalness: 1, roughness: 0.32 }),
    goldL: new THREE.MeshStandardMaterial({ color: 0xe3c27a, metalness: 1, roughness: 0.25 }),
    goldD: new THREE.MeshStandardMaterial({ color: 0x7a5a24, metalness: 1, roughness: 0.45 }),
    silver: new THREE.MeshStandardMaterial({ color: 0xc8c8c8, metalness: 1, roughness: 0.25 }),
    mat: new THREE.MeshLambertMaterial({ color: 0xf6f3ec }),
    linen: new THREE.MeshLambertMaterial({ color: 0xe8dfcc })
  };
  FS = {
    black: { rings: [[0.024, 0.032, "black"]], mat: 0.075 },
    white: { rings: [[0.055, 0.03, "white"]], mat: 0 },
    oak: { rings: [[0.045, 0.036, "oak"]], mat: 0.03 },
    walnut: { rings: [[0.04, 0.04, "walnut"], [0.012, 0.05, "walnut"]], mat: 0.04 },
    silver: { rings: [[0.014, 0.026, "silver"]], mat: 0.06 },
    gold: { rings: [[0.03, 0.05, "gold"], [0.022, 0.062, "goldL"], [0.014, 0.045, "gold"], [0.006, 0.03, "goldD"]], mat: 0.045, matMat: "linen" },
    goldOrnate: { rings: [[0.035, 0.055, "goldD"], [0.03, 0.075, "gold"], [0.02, 0.06, "goldL"], [0.012, 0.045, "gold"]], mat: 0 }
  };
  mats = {
    wall: new THREE.MeshLambertMaterial({ map: S.wall }),
    ceil: new THREE.MeshLambertMaterial({ color: S.ceiling }),
    tread: new THREE.MeshLambertMaterial({ map: S.tread }),
    riser: S.riserWood ? new THREE.MeshLambertMaterial({ map: S.tread, color: 0x9a8a78 }) : new THREE.MeshLambertMaterial({ color: S.riser }),
    skirt: new THREE.MeshLambertMaterial({ color: S.skirting }),
    runner: S.runner ? new THREE.MeshLambertMaterial({ color: S.runner }) : null,
    lamp: new THREE.MeshBasicMaterial({ color: 0xfff6e6 }),
    shadow: new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, opacity: cfg.Look === "dark" ? 0.55 : 0.3, depthWrite: false }),
    glow: new THREE.MeshBasicMaterial({ map: glowTex, transparent: true, opacity: 0.85, depthWrite: false, blending: THREE.AdditiveBlending })
  };
}

// ------------------------------------------------------------ Ein Treppenlauf

const unitBox = new THREE.BoxGeometry(1, 1, 1);
const lampDisc = new THREE.CylinderGeometry(0.16, 0.16, 0.05, 24);
function box(g, sx, sy, sz, x, y, z, mat) {
  const m = new THREE.Mesh(unitBox, mat);
  m.scale.set(sx, sy, sz); m.position.set(x, y, z); g.add(m); return m;
}
function sloped(g, x, h, thick, off, mat) {
  const len = L / Math.cos(ANG);
  const m = box(g, thick, h, len, x, L / 2 * SLOPE + off, L / 2, mat);
  m.rotation.x = -ANG; return m;
}
function wallPlane(g, len, h, x, y, z, rotY) {
  const mat = mats.wall.clone();
  mat.map = mats.wall.map.clone();
  mat.map.repeat.set(len / S.wallRep, h / S.wallRep);
  mat.map.needsUpdate = true;
  mat.userData.own = true;
  const m = new THREE.Mesh(new THREE.PlaneGeometry(len, h), mat);
  m.rotation.y = rotY; m.position.set(x, y, z); g.add(m); return m;
}
function instanced(g, n, mat, place) {
  const im = new THREE.InstancedMesh(unitBox, mat, n);
  const o = new THREE.Object3D();
  for (let i = 0; i < n; i += 1) { place(o, i); o.updateMatrix(); im.setMatrixAt(i, o.matrix); }
  im.instanceMatrix.needsUpdate = true;
  im.userData.instanced = true;
  g.add(im); return im;
}

function buildFlight() {
  const g = new THREE.Group();
  g.userData = { frames: [], stops: [] };
  instanced(g, NSTEPS, mats.tread, (o, i) => { o.scale.set(W, 0.035, T + 0.03); o.position.set(-W / 2, (i + 1) * R + 0.0175, i * T + T / 2 - 0.015); });
  instanced(g, NSTEPS, mats.riser, (o, i) => { o.scale.set(W, R, 0.02); o.position.set(-W / 2, i * R + R / 2, i * T + 0.01); });
  if (mats.runner) {
    instanced(g, NSTEPS, mats.runner, (o, i) => { o.scale.set(0.62, 0.008, T); o.position.set(-W / 2 + 0.03, (i + 1) * R + 0.039, i * T + T / 2); });
    instanced(g, NSTEPS, mats.runner, (o, i) => { o.scale.set(0.62, R - 0.02, 0.008); o.position.set(-W / 2 + 0.03, i * R + R / 2 + 0.02, i * T + 0.025); });
    box(g, 0.9, 0.008, 0.9, -W / 2, H + 0.039, L + W / 2, mats.runner);
  }
  box(g, W, 0.06, W, -W / 2, H + 0.005, L + W / 2, mats.tread);          // Absatz
  const top = H + 3.2;
  wallPlane(g, L + 2 * W, top + 3, 0, top / 2 - 1.5, L / 2, -Math.PI / 2); // Bilderwand
  wallPlane(g, L, top + 3, -W, top / 2 - 1.5, L / 2, Math.PI / 2);          // rechte Wand
  sloped(g, -0.012, 0.2, 0.024, 0.1, mats.skirt);
  sloped(g, -W + 0.012, 0.2, 0.024, 0.1, mats.skirt);
  box(g, 0.024, 0.2, W, -0.012, H + 0.135, L + W / 2, mats.skirt);
  const cl = new THREE.Mesh(new THREE.PlaneGeometry(W, L / Math.cos(ANG)), mats.ceil);
  cl.rotation.x = Math.PI / 2 - ANG; cl.position.set(-W / 2, L / 2 * SLOPE + 2.75, L / 2); g.add(cl);
  const cf = new THREE.Mesh(new THREE.PlaneGeometry(W, W), mats.ceil);
  cf.rotation.x = Math.PI / 2; cf.position.set(-W / 2, H + 2.75, L + W / 2); g.add(cf);
  // einfacher Handlauf an der rechten Wand, mit Haltern
  const rail = new THREE.Mesh(new THREE.CylinderGeometry(0.022, 0.022, (L - 0.2) / Math.cos(ANG), 16), S.rail);
  rail.rotation.x = Math.PI / 2 - ANG; rail.position.set(-W + 0.075, L / 2 * SLOPE + 0.92, L / 2); g.add(rail);
  for (let z = 0.6; z < L - 0.3; z += 1.2) {
    box(g, 0.06, 0.012, 0.012, -W + 0.03, z * SLOPE + 0.89, z, S.rail);
    box(g, 0.012, 0.08, 0.012, -W + 0.06, z * SLOPE + 0.87, z, S.rail);
  }
  // Deckenleuchten (nur gemalt)
  const l1 = new THREE.Mesh(lampDisc, mats.lamp); l1.position.set(-W / 2, H + 2.72, L + W / 2); g.add(l1);
  const l2 = new THREE.Mesh(lampDisc, mats.lamp); l2.rotation.x = -ANG; l2.position.set(-W / 2, L / 2 * SLOPE + 2.72, L / 2); g.add(l2);
  return g;
}

// ------------------------------------------------------------ Rahmen

function ring(g, ow, oh, w, d, mat) {
  for (const [a, b, x, y] of [[ow, w, 0, (oh - w) / 2], [ow, w, 0, -(oh - w) / 2], [w, oh - 2 * w, (ow - w) / 2, 0], [w, oh - 2 * w, -(ow - w) / 2, 0]]) {
    box(g, a, b, d, x, y, d / 2, mat);
  }
}
function makeFrame(styleName, pw, ph, tex, noLamp = false) {
  const st = FS[styleName], g = new THREE.Group();
  const fw = st.rings.reduce((s, r) => s + r[0], 0);
  let ow = pw + 2 * (st.mat + fw), oh = ph + 2 * (st.mat + fw);
  const W0 = ow, H0 = oh;
  const sh = new THREE.Mesh(new THREE.PlaneGeometry(W0 * 1.6 + 0.06, H0 * 1.6 + 0.06), mats.shadow);
  sh.position.set(0, -0.03, 0.002); g.add(sh);
  for (const [w, d, m] of st.rings) { ring(g, ow, oh, w, d, M[m]); ow -= 2 * w; oh -= 2 * w; }
  box(g, ow, oh, 0.01, 0, 0, 0.006, M[st.matMat || "mat"]);
  const pmat = new THREE.MeshBasicMaterial({ map: tex, color: S.photoTint });
  pmat.userData.own = true;
  const photo = new THREE.Mesh(new THREE.PlaneGeometry(pw, ph), pmat);
  photo.position.z = 0.0125; g.add(photo);
  if (S.pictureLights && !noLamp) {
    const lampLen = Math.min(0.36, W0 * 0.6);
    const lamp = box(g, lampLen, 0.04, 0.04, 0, H0 / 2 + 0.08, 0.11, M.gold);
    lamp.userData.lamp = true;
    box(g, 0.012, 0.012, 0.11, 0, H0 / 2 + 0.07, 0.055, M.gold);
    const glow = new THREE.Mesh(new THREE.PlaneGeometry(W0 * 1.25, H0 * 0.9), mats.glow);
    glow.position.set(0, H0 / 2 - H0 * 0.42, 0.017); g.add(glow);
  }
  g.userData = { W: W0, H: H0, tex };
  return g;
}

function disposeObject(root) {
  root.traverse((o) => {
    if (o.geometry && o.geometry !== unitBox && o.geometry !== lampDisc) o.geometry.dispose();
    if (o.material && o.material.userData.own) {
      if (o.material.map) o.material.map.dispose();
      o.material.dispose();
    }
  });
}

// ------------------------------------------------------------ Fotos holen

const photoLong = () => Math.round(clamp(Math.min(innerWidth, innerHeight) * 0.75 * Math.min(window.devicePixelRatio || 1, 1.5), 480, 1100));

async function fetchNext() {
  if (DEMO) return demoPhoto();
  const n = photoLong();
  const info = await api(`api/next?w=${n}&h=${n}`);
  if (!info || !info.success) {
    throw new Error(info && info.error === "empty" ? (info.busy ? "wait" : "none") : "photo");
  }
  const img = await loadImage(url(`api/photo?id=${info.id}`));
  try { await img.decode(); } catch (_) { /* schon dekodiert */ }
  return { img, info };
}

let demoIndex = 0;
const demoList = (params.get("photos") || "").split(",").filter(Boolean);
function paintDemo(i) {
  const c = document.createElement("canvas");
  c.width = i % 3 === 1 ? 600 : 900; c.height = i % 3 === 1 ? 820 : 600;
  const g = c.getContext("2d");
  const sky = g.createLinearGradient(0, 0, 0, c.height);
  const themes = [["#1d3b72", "#f08a4b", "#ffd27a"], ["#7fb7e6", "#cfe8f7", "#f7f3e8"], ["#2b1844", "#8e3b6b", "#f2a65a"], ["#3c7a5a", "#a9d18e", "#f0f4d8"], ["#5a2a1a", "#d4683a", "#f6d38a"]];
  const th = themes[i % themes.length];
  sky.addColorStop(0, th[0]); sky.addColorStop(0.6, th[1]); sky.addColorStop(1, th[2]);
  g.fillStyle = sky; g.fillRect(0, 0, c.width, c.height);
  g.fillStyle = "rgba(255,240,200,.9)";
  g.beginPath(); g.arc(150 + 180 * (i % 3), 190, 55, 0, Math.PI * 2); g.fill();
  g.fillStyle = "#2a2f3a";
  g.beginPath(); g.moveTo(0, c.height * 0.75);
  for (let x = 0; x <= c.width; x += 60) g.lineTo(x, c.height * 0.65 + 45 * Math.sin(x / 110 + i));
  g.lineTo(c.width, c.height); g.lineTo(0, c.height); g.fill();
  return c.toDataURL("image/jpeg", 0.9);
}
async function demoPhoto() {
  const i = demoIndex;
  demoIndex += 1;
  if (!FREEZE) await sleep(120);
  const src = demoList.length ? demoList[i % demoList.length] : paintDemo(i);
  const img = await loadImage(src);
  try { await img.decode(); } catch (_) { /* schon dekodiert */ }
  return { img, info: {} };
}

function makeTexture(img) {
  const t = new THREE.Texture(img);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  t.generateMipmaps = true;
  t.needsUpdate = true;
  return t;
}

// ------------------------------------------------------------ Läufe und Wand füllen

const flights = [];   // höchstens: voriger, aktueller, nächster (und einer im Bau)
let current = 0;      // Index des Laufs, auf dem man gerade ist
function addFlight() {
  const g = buildFlight();
  if (flights.length) {
    const prev = flights[flights.length - 1];
    prev.updateMatrixWorld(true);
    g.position.copy(prev.localToWorld(new THREE.Vector3(-W, H, L + W)));
    g.rotation.y = prev.rotation.y - Math.PI / 2;
  }
  scene.add(g);
  g.updateMatrixWorld(true);
  flights.push(g);
  return g;
}

// Wo der nächste Rahmen hinkommt. Abschnitte je Lauf:
// "far" = Stirnwand des Absatzes darunter (z in [-W,0], gehört zur Bilderwand dieses Laufs),
// "stairs" = an der Treppe, "landing" = am Absatz oben (z in [L, L+W]).
const fill = { flight: 0, part: "stairs", z: 0.75, column: null };
let filledFrames = 0;

function hang(g, f, z, y) {
  f.rotation.y = -Math.PI / 2;
  f.position.set(-0.001, y, z);
  g.add(f);
  g.userData.frames.push(f);
}

function sizeFor(aspect, small) {
  const size = small ? 0.3 + rand() * 0.08 : pick([0.42, 0.5, 0.6, 0.6, 0.72, 0.85]);
  let pw, ph;
  if (aspect >= 1) { pw = size * (aspect > 1.45 ? 1.15 : 1); ph = pw / aspect; } else { ph = size * 1.1; pw = ph * aspect; }
  return [pw, ph];
}
function fitInto(pw, ph, maxW, maxH) {
  const k = Math.min(1, maxW / pw, maxH / ph);
  return [pw * k, ph * k];
}

let frameStyleIndex = Math.floor(rand() * 8);
function nextStyle() { frameStyleIndex += 1; return S.frames[frameStyleIndex % S.frames.length]; }
function maybeStop(g, f, z, landing) {
  if (rand() < (STOP_CHANCE[cfg.Stops] ?? 0.22)) g.userData.stops.push({ frame: f, z, landing });
}

// Ein Foto an die Wand hängen. false: gerade kein Platz (zu weit voraus).
function placePhoto(entry) {
  if (fill.flight > current + 1) return false;
  while (fill.flight >= flights.length) addFlight();
  const g = flights[fill.flight];
  const img = entry.img, aspect = img.naturalWidth / Math.max(1, img.naturalHeight);
  const tex = makeTexture(img);
  renderer.initTexture(tex);      // jetzt hochladen, nicht erst wenn es um die Ecke ins Bild kommt
  filledFrames += 1;

  if (fill.part === "far") {
    const [pw, ph] = fitInto(...sizeFor(aspect, false), 0.62, 0.72);
    hang(g, makeFrame(nextStyle(), pw, ph, tex), -W / 2, HANG + 0.08);
    fill.part = "stairs"; fill.z = 0.4;
    return true;
  }
  if (fill.part === "landing") {
    const [pw, ph] = fitInto(...sizeFor(aspect, false), 0.62, 0.75);
    const f = makeFrame(nextStyle(), pw, ph, tex);
    hang(g, f, L + W / 2, H + HANG + 0.05);
    maybeStop(g, f, L + W / 2, true);
    fill.flight += 1; fill.part = "far"; fill.z = -W;
    return true;
  }
  // an der Treppe: zweites Bild einer Spalte (zwei übereinander)?
  if (fill.column) {
    const col = fill.column;
    const f = makeFrame(nextStyle(), ...sizeFor(aspect, true), tex, true);
    const gap = 0.09, top = col.frame;
    const total = top.userData.H + gap + f.userData.H;
    top.position.y = col.yc + total / 2 - top.userData.H / 2;
    hang(g, f, col.zc, col.yc - total / 2 + f.userData.H / 2);
    fill.z = col.z0 + Math.max(col.width, f.userData.W) + 0.16 + rand() * 0.18;
    fill.column = null;
    if (fill.z > L - 0.75) fill.part = "landing";
    return true;
  }
  const cluster = rand() < 0.26;
  let f = makeFrame(nextStyle(), ...sizeFor(aspect, cluster), tex);
  if (fill.z + f.userData.W > L - 0.35) {
    // passt nicht mehr an die Treppe: kommt an den Absatz
    disposeObject(f);
    const [pw, ph] = fitInto(...sizeFor(aspect, false), 0.62, 0.75);
    const tex2 = makeTexture(img);
    renderer.initTexture(tex2);
    f = makeFrame(nextStyle(), pw, ph, tex2);
    hang(g, f, L + W / 2, H + HANG + 0.05);
    maybeStop(g, f, L + W / 2, true);
    fill.flight += 1; fill.part = "far"; fill.z = -W;
    return true;
  }
  const zc = fill.z + f.userData.W / 2;
  const yc = lineY(zc) + HANG + (rand() - 0.5) * 0.24;
  hang(g, f, zc, yc);
  if (cluster) {
    fill.column = { frame: f, zc, yc, z0: fill.z, width: f.userData.W };
  } else {
    fill.z += f.userData.W + 0.16 + rand() * 0.18;
    maybeStop(g, f, zc, false);
    if (fill.z > L - 0.75) fill.part = "landing";
  }
  return true;
}

// ------------------------------------------------------------ Licht

function addLights() {
  scene.background = new THREE.Color(S.bg);
  scene.fog = new THREE.Fog(S.bg, S.fog[0], S.fog[1]);
  renderer.toneMappingExposure = S.exposure;
  scene.add(new THREE.HemisphereLight(0xfff6e8, 0x6b5a48, S.hemi));
  const sun = new THREE.DirectionalLight(0xfff0dc, S.dir);
  sun.position.set(-1, 3, 1);
  camera.add(sun); camera.add(sun.target);
  sun.target.position.set(0.3, -1, -1);
  // eine warme Lampe, die mitgeht: nahe Wände heller als ferne
  const head = new THREE.PointLight(0xfff0d8, S.head, 6, 1.5);
  head.position.set(0, 0.6, 0.2);
  camera.add(head);
}

// ------------------------------------------------------------ Der Weg

// Je Lauf zwei Wegstücke: geradeaus die Treppe hoch, dann ein weicher Bogen über
// den Absatz nach rechts. Der Bogen weicht nach links aus und bleibt gut einen
// halben Meter von der inneren Ecke weg (sonst schiebt sich die Ecke vor die
// Kamera). Am Ende des Bogens steht man im nächsten Lauf bei x = CX, z = Z0.
const Z0 = 2.2, CURVE_IN = 2.6;
let curve = null;
function makeCurve() {
  // Punkte in Koordinaten des alten Laufs; im neuen Lauf gilt z' = -W - x, x' = z - (L + W)
  const P = (x, z) => new THREE.Vector3(x, 0, z);
  const pts = [
    P(CX, L - CURVE_IN), P(CX, L - 2.0), P(-0.57, L - 0.65),
    // Viertelkreis um die innere Ecke (-W, L) mit 0,65 m Abstand
    P(-W + 0.65, L), P(-W + 0.65 * Math.SQRT1_2, L + 0.65 * Math.SQRT1_2), P(-W, L + 0.65),
    P(-W - 0.6, L + 0.6), P(-W - (Z0 - 0.6), L + W + CX), P(-W - Z0, L + W + CX)
  ];
  const c = new THREE.CatmullRomCurve3(pts, false, "centripetal");
  c.arcLengthDivisions = 600;
  return { c, len: c.getLength() };
}
function onCurve(dist) {
  const u = clamp(dist / curve.len);
  const p = curve.c.getPointAt(u), t = curve.c.getTangentAt(u);
  return { p, fwd: Math.atan2(t.x, t.z), u };
}
const straightLen = () => (L - CURVE_IN) - Z0;
const flightPathLen = () => straightLen() + curve.len;

function floorLocal(x, z) {
  if (x < -W) return H + clamp(-W - x, 0, L) * SLOPE;   // schon im nächsten Lauf
  return z <= 0 ? 0 : z >= L ? H : z * SLOPE;
}

let pathS = Number(params.get("at")) || 0;   // Meter auf dem Weg im aktuellen Lauf
let velocity = 0;
let stop = null;           // { frame, phase: "in"|"hold"|"out", t }
let stopBlend = 0;
let bob = 0;

function wallReady(flightIndex, z) {
  // Hängen bis z (im Lauf flightIndex) schon Bilder? Sonst warten.
  if (fill.flight > flightIndex) return true;
  if (fill.flight < flightIndex) return false;
  if (fill.part === "landing") return true;
  if (fill.part === "far") return false;
  return fill.z > z;
}

const tmpV = new THREE.Vector3(), tmpL = new THREE.Vector3(), tmpE = new THREE.Euler();
const sm = { yaw: null, y: null };   // geglättet, in Weltkoordinaten
function poseCamera(dt = 0) {
  const g = flights[current];
  const sLen = straightLen();
  let x, z, fwd, onTurn = 0;
  if (pathS <= sLen) {
    x = CX; z = Z0 + pathS; fwd = 0;
  } else {
    const c = onCurve(pathS - sLen);
    x = c.p.x; z = c.p.z; fwd = c.fwd; onTurn = Math.sin(Math.PI * c.u);
  }
  const floor = floorLocal(x, z);
  // auf der Treppe nach oben schauen, auf dem Absatz geradeaus
  const fx = Math.sin(fwd) * 0.6, fz = Math.cos(fwd) * 0.6;
  const climb = clamp((floorLocal(x + fx, z + fz) - floorLocal(x - fx, z - fz)) / (1.2 * SLOPE));
  let yaw = fwd + 0.81 * (1 - 0.75 * onTurn);      // 0,81 rad ≈ 46° nach links zur Bilderwand
  let pitch = 0.235 * climb;
  const eyeY = floor + EYE + Math.sin(bob) * 0.007 * clamp(velocity / 0.2);
  let fov = 58;
  const k = smooth(stopBlend);
  if (k > 0 && stop) {
    const f = stop.frame;   // hängt am aktuellen Lauf, also gleiche Koordinaten
    const dx = f.position.x - x, dz = f.position.z - z;
    const dist = Math.hypot(dx, dz);
    yaw = lerp(yaw, Math.atan2(dx, dz), k);
    pitch = lerp(pitch, Math.atan2(f.position.y - eyeY, dist), k);
    const hh = Math.max(f.userData.H, f.userData.W * 0.62);
    fov = lerp(58, clamp(2 * Math.atan(hh * 0.8 / dist) * 180 / Math.PI, 28, 58), k);
  }
  camera.fov = fov;
  camera.position.copy(g.localToWorld(tmpV.set(x, eyeY, z)));
  // Höhe und Blickrichtung weich nachführen: kein Ruck am Anfang/Ende der Treppe und im Bogen
  const wantYaw = g.rotation.y + yaw;
  if (sm.yaw === null || !dt) { sm.yaw = wantYaw; sm.y = camera.position.y; } else {
    const d = Math.atan2(Math.sin(wantYaw - sm.yaw), Math.cos(wantYaw - sm.yaw));
    sm.yaw += d * (1 - Math.exp(-dt / 0.8));
    sm.y += (camera.position.y - sm.y) * (1 - Math.exp(-dt / 0.35));
  }
  camera.position.y = sm.y;
  const cp = camera.position;
  camera.lookAt(tmpL.set(cp.x + Math.sin(sm.yaw) * Math.cos(pitch), cp.y + Math.sin(pitch), cp.z + Math.cos(sm.yaw) * Math.cos(pitch)));
  // Architektur-Blick: Senkrechte bleiben senkrecht, das Objektiv wird verschoben
  const keep = lerp(0.3, 1, k);
  tmpE.setFromQuaternion(camera.quaternion, "YXZ");
  const rest = tmpE.x * (1 - keep);
  tmpE.x *= keep;
  camera.quaternion.setFromEuler(tmpE);
  const hgt = innerHeight, shift = Math.tan(rest) / Math.tan(camera.fov * Math.PI / 360) * hgt / 2;
  camera.setViewOffset(innerWidth, hgt, 0, -shift, innerWidth, hgt);
  camera.updateProjectionMatrix();
}

const UP = new THREE.Vector3(0, 1, 0);
function rebase() {
  // den aktuellen Lauf zurück in den Ursprung legen, geradeaus entlang +z
  const g = flights[current];
  const off = g.position.clone(), rot = g.rotation.y;
  for (const f of flights) {
    f.position.sub(off).applyAxisAngle(UP, -rot);
    f.rotation.y -= rot;
    f.updateMatrixWorld(true);
  }
  if (sm.yaw !== null) { sm.yaw -= rot; sm.y -= off.y; }
}

function advance(dt) {
  const g = flights[current];
  const sLen = straightLen();
  const speed = PACE[cfg.Pace] || 0.2;
  if (!stop) {
    for (const st of g.userData.stops) {
      if (st.done) continue;
      if (!st.landing && st.z < Z0 + 0.6) { st.done = true; continue; }
      const trigger = st.landing ? sLen + curve.len * 0.2 : st.z - 0.3 - Z0;
      if (pathS >= trigger - 0.02) {
        st.done = true;
        if (pathS < trigger + 0.4) { stop = { frame: st.frame, phase: "in", t: 0 }; break; }
      }
    }
  }
  let target = pathS > sLen ? speed * 0.8 : speed;   // im Bogen etwas langsamer
  if (stop) {
    stop.t += dt;
    if (stop.phase === "in") {
      target = 0;
      stopBlend = clamp(stopBlend + dt / 2.4);
      if (stopBlend >= 1 && velocity < 0.005) { stop.phase = "hold"; stop.t = 0; }
    } else if (stop.phase === "hold") {
      target = 0;
      if (stop.t >= cfg.StopSeconds) stop.phase = "out";
    } else {
      stopBlend = clamp(stopBlend - dt / 2.4);
      target = speed * (1 - stopBlend * 0.8);
      if (stopBlend <= 0) stop = null;
    }
  }
  // auf fehlende Fotos warten (nur, wenn die Wand vor einem noch leer ist)
  const ok = pathS <= sLen ? wallReady(current, Math.min(Z0 + pathS + 3.2, L - 0.4)) : wallReady(current + 1, Math.min(Z0 + 3.2, L - 0.4));
  if (!ok) target = 0;
  // weich anfahren und bremsen
  velocity = target > velocity ? Math.min(target, velocity + 0.1 * dt) : Math.max(target, velocity - 0.22 * dt);
  pathS += velocity * dt;
  bob += velocity * dt / T * Math.PI;
  if (pathS >= flightPathLen()) {
    pathS -= flightPathLen();
    current += 1;
    while (flights.length <= current + 1) addFlight();
    while (current > 1) {            // ältere Läufe weg
      const old = flights.shift();
      scene.remove(old);
      disposeObject(old);
      current -= 1;
      fill.flight -= 1;
    }
    rebase();
    topUp();
  }
}

// ------------------------------------------------------------ Fotos nachladen

let loading = 0, failures = 0;
const pending = [];
const needMore = () => fill.flight <= current + 1;   // bis der nächste Lauf ganz hängt
function topUp() {
  while (pending.length && placePhoto(pending[0])) pending.shift();
  while (loading < 2 && needMore() && pending.length + loading < 3) {
    loading += 1;
    fetchNext().then((entry) => {
      failures = 0;
      pending.push(entry);
      if (note.textContent && note.textContent !== tx("none")) showNote("");
    }).catch((error) => {
      failures += 1;
      if (filledFrames < 2) {
        if (error.message === "wait" || error.message === "none") showNote(tx(error.message));
        else if (failures > 1) showNote(error.message === "login" ? tx("login") : tx("unreachable"));
      }
      if (failures === 3) report("photo: " + error.message);
      ready();
    }).finally(() => {
      loading -= 1;
      const pause = failures ? Math.min(15000, 2000 * failures) : 0;
      setTimeout(topUp, pause / SPEED);
    });
  }
}

async function poll() {
  if (DEMO) return { count: 1 };
  try {
    const data = await api("api/scene");
    applySettings(data.settings);
    if (!data.count) showNote(data.busy || data.status === "" ? tx("wait") : tx("none"));
    else if ([tx("wait"), tx("none"), tx("unreachable"), tx("login")].includes(note.textContent)) showNote("");
    return data;
  } catch (error) {
    if (!filledFrames) showNote(error.message === "login" ? tx("login") : tx("unreachable"));
    ready();
    return null;
  }
}
async function pollLoop() {
  while (true) {
    await sleep(20000);
    await poll();
  }
}

// ------------------------------------------------------------ Bildrate: Auflösung anpassen

let fpsTime = 0, fpsFrames = 0, lowCount = 0;
function watchFrameRate(dt) {
  fpsTime += dt; fpsFrames += 1;
  if (fpsTime < 4) return;
  const fps = fpsFrames / fpsTime;
  fpsTime = 0; fpsFrames = 0;
  if (fps < 24 && pixelRatio > 0.55) {
    lowCount += 1;
    if (lowCount >= 2) {
      pixelRatio = Math.max(0.55, pixelRatio * 0.85);
      renderer.setPixelRatio(pixelRatio);
      renderer.setSize(innerWidth, innerHeight);
      lowCount = 0;
      report(`fps ${fps.toFixed(1)}, pixel ratio now ${pixelRatio.toFixed(2)}`);
    }
  } else lowCount = 0;
  window.__fps = fps;
  window.__mem = { ...renderer.info.memory, calls: renderer.info.render.calls, flights: flights.length, frames: filledFrames };
}

// ------------------------------------------------------------ Start

let last = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const real = last ? Math.min(0.1, (now - last) / 1000) : 0;
  last = now;
  advance(real * SPEED);
  poseCamera(real * SPEED);
  renderer.render(scene, camera);
  watchFrameRate(real);
}

async function start() {
  if (!DEMO) await poll();
  setFlightSize();
  curve = makeCurve();
  window.__es = { onCurve, L, W, H, len: curve.len, cam: () => [camera.position.x, camera.position.y, camera.position.z, sm.yaw] };
  S = makeStyle();
  makeMaterials();
  addLights();
  addFlight(); addFlight();
  built = true;
  if (FREEZE) {
    // Standbild: Wand füllen, an die Stelle ?at= gehen, ein Bild machen
    while (needMore()) {
      if (!placePhoto(await fetchNext())) break;
    }
    if (params.get("hold") === "1") {
      const f = flights[0].userData.frames.find((fr) => fr.position.z > Z0 + pathS + 0.5 && fr.position.z < L - 0.3);
      if (f) { stop = { frame: f, phase: "hold", t: 0 }; stopBlend = 1; pathS = f.position.z - 0.3 - Z0; }
    }
    poseCamera();
    renderer.render(scene, camera);
    ready();
    document.body.dataset.shot = "ready";
    return;
  }
  topUp();
  // erst losgehen, wenn die ersten Bilder hängen
  const until = Date.now() + 20000;
  while (filledFrames < 4 && Date.now() < until) await sleep(300);
  poseCamera();
  renderer.render(scene, camera);
  ready();
  requestAnimationFrame(frame);
  pollLoop();
}
start();
