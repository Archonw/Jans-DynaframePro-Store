"""Texte des Plugins auf Deutsch, Englisch und Spanisch (Meldungen und Ereignis-Titel)."""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Die Planeten an ihrem echten Ort von heute, mit Monden, Raumsonden, Kometen und den nächsten Finsternissen.": (
        "The planets at their real position today, with moons, space probes, comets and the next eclipses.",
        "Los planetas en su posición real de hoy, con lunas, sondas, cometas y los próximos eclipses."),
    "Solar System Live ist auf der Plugins-Seite ausgeschaltet.": (
        "Solar System Live is switched off on the Plugins page.", "Solar System Live está desactivado en la página de plugins."),
    "„Übernahme erlauben“ ist für Solar System Live auf der Plugins-Seite aus. Schalte es ein, sonst kann das Ereignis nicht über die Playlist gelegt werden.": (
        "“Allow takeover” is off for Solar System Live on the Plugins page. Switch it on, otherwise the event cannot be put over the playlist.",
        "“Permitir toma de control” está desactivado para Solar System Live en la página de plugins. Actívalo; si no, el evento no se puede poner sobre la playlist."),
    "Gerade hat etwas anderes den Bildschirm.": ("Something else has the screen right now.", "Ahora mismo otra cosa tiene la pantalla."),
    "Der Bildschirm ist aus; das Ereignis wird nicht gezeigt.": (
        "The screen is off; the event is not shown.", "La pantalla está apagada; el evento no se muestra."),
    "Dieser Rahmen ist zu alt, damit ein Plugin den Bildschirm übernehmen kann.": (
        "This frame is too old to let a plugin take over the screen.", "Este marco es demasiado antiguo para que un plugin tome la pantalla."),
    "Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The scene is not installed on this frame. Install the pack again.", "La escena no está instalada en este marco. Instala el paquete de nuevo."),
    "Die Übernahme-Playlist ist noch nicht angelegt.": (
        "The takeover playlist has not been created yet.", "La playlist de toma de control aún no se ha creado."),
    "Konnte die Übernahme-Playlist nicht anlegen: {exc}": (
        "Could not create the takeover playlist: {exc}", "No se pudo crear la playlist de toma de control: {exc}"),
    "Konnte das Ereignis nicht zeigen: {exc}": ("Could not show the event: {exc}", "No se pudo mostrar el evento: {exc}"),
    "Der Rahmen hat das Ereignis nicht rechtzeitig gezeigt.": (
        "The frame did not show the event in time.", "El marco no mostró el evento a tiempo."),
    "Zeigt gerade: {name}.": ("Showing right now: {name}.", "Mostrando ahora: {name}."),
    "Vorführung: Die Szene zeigt zwei Minuten lang „{name}“ im Zeitraffer.": (
        "Demo: the scene shows “{name}” as a time-lapse for two minutes.",
        "Demostración: la escena muestra «{name}» a cámara rápida durante dos minutos."),
    "Kein Ereignis in den nächsten Monaten gefunden.": (
        "No event found in the next months.", "No se ha encontrado ningún evento en los próximos meses."),
    "Holt die Daten der Raumsonden und Kometen jetzt neu.": (
        "Fetching the probe and comet data again now.", "Volviendo a cargar ahora los datos de sondas y cometas."),
}

PLANETS = {
    "sun": ("Sonne", "Sun", "Sol"), "mercury": ("Merkur", "Mercury", "Mercurio"), "venus": ("Venus", "Venus", "Venus"),
    "earth": ("Erde", "Earth", "Tierra"), "moon": ("Mond", "Moon", "Luna"), "mars": ("Mars", "Mars", "Marte"),
    "jupiter": ("Jupiter", "Jupiter", "Júpiter"), "saturn": ("Saturn", "Saturn", "Saturno"),
    "uranus": ("Uranus", "Uranus", "Urano"), "neptune": ("Neptun", "Neptune", "Neptuno"),
}

METEORS = {
    "quadrantids": ("Quadrantiden", "Quadrantids", "Cuadrántidas"), "lyrids": ("Lyriden", "Lyrids", "Líridas"),
    "eta-aquariids": ("Eta-Aquariiden", "Eta Aquariids", "Eta Acuáridas"), "perseids": ("Perseiden", "Perseids", "Perseidas"),
    "draconids": ("Draconiden", "Draconids", "Dracónidas"), "orionids": ("Orioniden", "Orionids", "Oriónidas"),
    "leonids": ("Leoniden", "Leonids", "Leónidas"), "geminids": ("Geminiden", "Geminids", "Gemínidas"),
    "ursids": ("Ursiden", "Ursids", "Úrsidas"),
}

EV = {
    "lunar-total": ("Totale Mondfinsternis", "Total lunar eclipse", "Eclipse total de Luna"),
    "lunar-partial": ("Partielle Mondfinsternis", "Partial lunar eclipse", "Eclipse parcial de Luna"),
    "lunar-penumbral": ("Halbschatten-Mondfinsternis", "Penumbral lunar eclipse", "Eclipse penumbral de Luna"),
    "solar-total": ("Totale Sonnenfinsternis", "Total solar eclipse", "Eclipse total de Sol"),
    "solar-annular": ("Ringförmige Sonnenfinsternis", "Annular solar eclipse", "Eclipse anular de Sol"),
    "solar-partial": ("Partielle Sonnenfinsternis", "Partial solar eclipse", "Eclipse parcial de Sol"),
    "solar-hybrid": ("Hybride Sonnenfinsternis", "Hybrid solar eclipse", "Eclipse híbrido de Sol"),
    "transit": ("{body} zieht vor der Sonne vorbei", "{body} crosses the Sun", "{body} pasa por delante del Sol"),
    "opposition": ("{body} in Opposition", "{body} at opposition", "{body} en oposición"),
    "conjunction": ("{a} und {b} dicht beieinander", "{a} and {b} close together", "{a} y {b} muy juntos"),
    "elong-morning": ("{body} als Morgenstern", "{body} as morning star", "{body} como lucero del alba"),
    "elong-evening": ("{body} als Abendstern", "{body} as evening star", "{body} como lucero vespertino"),
    "supermoon": ("Supermond", "Supermoon", "Superluna"),
    "meteors": ("Meteorstrom der {name}", "{name} meteor shower", "Lluvia de meteoros {name}"),
    "season-spring": ("Frühlingsanfang", "First day of spring", "Comienza la primavera"),
    "season-summer": ("Sommeranfang", "First day of summer", "Comienza el verano"),
    "season-autumn": ("Herbstanfang", "First day of autumn", "Comienza el otoño"),
    "season-winter": ("Winteranfang", "First day of winter", "Comienza el invierno"),
    "comet": ("Komet {name} an der Sonne", "Comet {name} closest to the Sun", "Cometa {name} junto al Sol"),
    # Untertitel
    "sub-local": ("bei dir zu {p} % bedeckt", "{p} % covered at your place", "{p} % cubierto en tu lugar"),
    "sub-visible": ("bei dir sichtbar", "visible from your place", "visible desde tu lugar"),
    "sub-notvisible": ("bei dir nicht sichtbar", "not visible from your place", "no visible desde tu lugar"),
    "sub-best": ("die ganze Nacht zu sehen und am hellsten", "visible all night and at its brightest",
                 "visible toda la noche y en su máximo brillo"),
    "sub-deg": ("{deg}° Abstand am Himmel", "{deg}° apart in the sky", "{deg}° de separación en el cielo"),
    "sub-elong": ("{deg}° neben der Sonne", "{deg}° from the Sun", "a {deg}° del Sol"),
    "sub-moonkm": ("Vollmond, nur {km} km entfernt", "full moon only {km} km away", "luna llena a solo {km} km"),
    "sub-zhr": ("bis zu {zhr} Sternschnuppen pro Stunde", "up to {zhr} meteors per hour", "hasta {zhr} meteoros por hora"),
    "sub-moonbad": ("der helle Mond stört", "the bright Moon gets in the way", "la Luna brillante molesta"),
    "sub-moongood": ("kaum Mondlicht", "hardly any moonlight", "apenas luz de Luna"),
}

_SEASON_N = {"march": "spring", "june": "summer", "september": "autumn", "december": "winter"}
_SEASON_S = {"march": "autumn", "june": "winter", "september": "spring", "december": "summer"}


def _pick(row, language):
    return row[LANGUAGES.index(language)] if language in LANGUAGES else row[0]


def t(language, text, **values):
    row = _TEXTS.get(text)
    if row and language in LANGUAGES[1:]:
        text = row[LANGUAGES.index(language) - 1]
    for key, value in values.items():
        text = text.replace("{" + key + "}", str(value))
    return text


def _fill(key, language, **values):
    text = _pick(EV[key], language)
    for k, v in values.items():
        text = text.replace("{" + k + "}", str(v))
    return text


def planet(language, key):
    return _pick(PLANETS.get(key, (key, key, key)), language)


def _num(language, value):
    text = f"{value:,.0f}" if isinstance(value, (int, float)) and value >= 1000 else f"{value:g}"
    if language == "de":
        text = text.replace(",", "X").replace(".", ",").replace("X", ".")
    elif language == "es":
        text = text.replace(",", " ").replace(".", ",")
    return text


def event_text(language, e, lat=None):
    """(Titel, Untertitel) eines Ereignisses."""
    typ, info = e["type"], e.get("info") or {}
    sub = []
    if typ == "lunar-eclipse":
        title = _fill("lunar-" + info.get("kind", "penumbral"), language)
        if e.get("visible") is True:
            sub.append(_fill("sub-visible", language))
        elif e.get("visible") is False:
            sub.append(_fill("sub-notvisible", language))
    elif typ == "solar-eclipse":
        title = _fill("solar-" + info.get("kind", "partial"), language)
        local = info.get("local")
        if local:
            sub.append(_fill("sub-local", language, p=round(local["obscuration"] * 100)))
        elif e.get("visible") is False:
            sub.append(_fill("sub-notvisible", language))
    elif typ == "transit":
        title = _fill("transit", language, body=planet(language, info.get("body")))
    elif typ == "opposition":
        title = _fill("opposition", language, body=planet(language, info.get("body")))
        sub.append(_fill("sub-best", language))
    elif typ == "conjunction":
        title = _fill("conjunction", language, a=planet(language, info.get("a")), b=planet(language, info.get("b")))
        sub.append(_fill("sub-deg", language, deg=_num(language, round(info.get("deg", 0), 1))))
    elif typ == "elongation":
        title = _fill("elong-" + info.get("when", "evening"), language, body=planet(language, info.get("body")))
        sub.append(_fill("sub-elong", language, deg=_num(language, round(info.get("deg", 0)))))
    elif typ == "supermoon":
        title = _fill("supermoon", language)
        sub.append(_fill("sub-moonkm", language, km=_num(language, info.get("km", 0))))
    elif typ == "meteors":
        title = _fill("meteors", language, name=_pick(METEORS.get(info.get("key"), ("?",) * 3), language))
        sub.append(_fill("sub-zhr", language, zhr=info.get("zhr")))
        sub.append(_fill("sub-moonbad" if info.get("moon", 0) > 0.6 else "sub-moongood", language)
                   if info.get("moon", 0) > 0.6 or info.get("moon", 1) < 0.3 else "")
    elif typ == "season":
        table = _SEASON_S if (lat is not None and lat < 0) else _SEASON_N
        title = _fill("season-" + table.get(info.get("key"), "spring"), language)
    elif typ == "comet":
        title = _fill("comet", language, name=info.get("name", "?"))
    else:
        title = typ
    return title, " · ".join(s for s in sub if s)
