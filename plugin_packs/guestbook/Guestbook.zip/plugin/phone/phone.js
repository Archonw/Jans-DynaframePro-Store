/* Guestbook: die Seite für die Gäste.
 * Code steht im QR-Code (?c=1234). Selfie (Frontkamera), Name, Gruß, absenden.
 * Danach: Danke-Karte, ändern/löschen (48 h), noch jemand, Buch ansehen.
 * Das Handy merkt sich eine zufällige Geräte-ID; nur damit lassen sich die
 * eigenen Einträge ändern. */
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const T = {
    defaultTitle: ["Unser Gästebuch", "Our guestbook", "Nuestro libro de visitas"],
    loading: ["Das Gästebuch wird geöffnet …", "Opening the guestbook …", "Abriendo el libro de visitas …"],
    codeTitle: ["Fast geschafft", "Almost there", "Casi listo"],
    codeLead: ["Gib die vier Ziffern ein, die neben dem QR-Code stehen (auf dem Fernseher oder auf dem Kärtchen).",
      "Enter the four digits next to the QR code (on the TV or on the card).",
      "Escribe las cuatro cifras que hay junto al código QR (en la tele o en la tarjeta)."],
    code: ["Code", "Code", "Código"],
    next: ["Weiter", "Next", "Seguir"],
    badCode: ["Der Code stimmt nicht.", "That code is not right.", "El código no es correcto."],
    noAnswer: ["Der Rahmen antwortet nicht. Bist du im selben WLAN?", "The frame does not answer. Are you on the same Wi-Fi?", "El marco no responde. ¿Estás en la misma wifi?"],
    kicker: ["Gästebuch", "Guestbook", "Libro de visitas"],
    signLead: ["Schön, dass du da bist! Mach ein Selfie und schreib ein paar Zeilen. Der Rahmen hebt es auf und erinnert sich noch in Jahren daran.",
      "Lovely to have you here! Take a selfie and write a few lines. The frame keeps it and will remember it years from now.",
      "¡Qué alegría tenerte aquí! Hazte un selfie y escribe unas líneas. El marco lo guarda y lo recordará dentro de años."],
    signLeadParty: ["Trag dich ins Gästebuch der Feier ein: ein Selfie, dein Name und ein paar Zeilen. Gleich danach bist du auf dem Fernseher.",
      "Sign the guestbook of the party: a selfie, your name and a few lines. Right after, you are on the TV.",
      "Firma en el libro de visitas de la fiesta: un selfie, tu nombre y unas líneas. Justo después sales en la tele."],
    takeSelfie: ["Selfie machen", "Take a selfie", "Hacer un selfie"],
    optional: ["freiwillig", "optional", "opcional"],
    required: ["gehört dazu", "please add one", "por favor, añade uno"],
    retake: ["Noch mal", "Take it again", "Otra vez"],
    gallery: ["Aus der Galerie", "Choose from gallery", "De la galería"],
    noPhoto: ["Ohne Foto", "Without photo", "Sin foto"],
    name: ["Wer seid ihr?", "Who are you?", "¿Quiénes sois?"],
    namePh: ["z. B. Tante Anke & Onkel Bernd", "e.g. Aunt Anne & Uncle Ben", "p. ej. tía Ana y tío Beni"],
    text: ["Euer Gruß", "Your greeting", "Vuestro saludo"],
    textPh: ["Ein paar Zeilen fürs Gästebuch …", "A few lines for the guestbook …", "Unas líneas para el libro de visitas …"],
    handEmpty: ["Hier steht gleich euer Gruß", "Your greeting goes here", "Aquí irá vuestro saludo"],
    send: ["Ins Gästebuch eintragen", "Sign the guestbook", "Firmar en el libro"],
    needName: ["Bitte schreib deinen Namen dazu.", "Please add your name.", "Escribe tu nombre, por favor."],
    needPhoto: ["Bitte mach ein Selfie für das Gästebuch.", "Please take a selfie for the guestbook.", "Hazte un selfie para el libro, por favor."],
    needSomething: ["Schreib einen Gruß oder mach ein Selfie.", "Write a greeting or take a selfie.", "Escribe un saludo o hazte un selfie."],
    preparing: ["Foto wird vorbereitet …", "Preparing the photo …", "Preparando la foto …"],
    sending: ["Wird eingetragen … {p} %", "Signing … {p} %", "Firmando … {p} %"],
    thanks: ["Danke, {name}!", "Thank you, {name}!", "¡Gracias, {name}!"],
    thanksLead: ["Du stehst jetzt im Gästebuch.", "You are in the guestbook now.", "Ya estás en el libro de visitas."],
    thanksWait: ["Dein Eintrag erscheint, sobald er freigegeben ist.", "Your entry appears as soon as it is approved.", "Tu entrada aparecerá en cuanto se apruebe."],
    lookTv: ["Schau mal auf den Fernseher!", "Have a look at the TV!", "¡Mira la tele!"],
    again1: ["Schön, dass du wieder da bist: dein {n}. Besuch, zum ersten Mal am {date}.", "Lovely to see you again: your visit no. {n}, the first one on {date}.", "Qué bien verte otra vez: tu visita n.º {n}, la primera el {date}."],
    edit: ["Ändern", "Change", "Cambiar"],
    delete: ["Löschen", "Delete", "Borrar"],
    deleteSure: ["Wirklich löschen?", "Really delete?", "¿Seguro que lo borras?"],
    deleted: ["Gelöscht.", "Deleted.", "Borrado."],
    save: ["Speichern", "Save", "Guardar"],
    cancel: ["Abbrechen", "Cancel", "Cancelar"],
    saved: ["Gespeichert.", "Saved.", "Guardado."],
    again: ["Noch jemand trägt sich ein", "Someone else signs", "Firma otra persona"],
    seeBook: ["Im Gästebuch blättern", "Look through the guestbook", "Hojear el libro de visitas"],
    bookTitle: ["Das Gästebuch", "The guestbook", "El libro de visitas"],
    bookLeadParty: ["Alle Einträge von „{title}“.", "All entries of “{title}”.", "Todas las entradas de «{title}»."],
    bookLead: ["Die neuesten Einträge.", "The newest entries.", "Las entradas más recientes."],
    bookOff: ["Hier stehen nur deine eigenen Einträge.", "Only your own entries are listed here.", "Aquí solo aparecen tus propias entradas."],
    noEntries: ["Noch keine Einträge.", "No entries yet.", "Aún no hay entradas."],
    back: ["Zurück", "Back", "Volver"],
    yours: ["dein Eintrag", "your entry", "tu entrada"],
    waiting: ["wartet auf Freigabe", "waiting for approval", "pendiente de aprobación"],
    tooBig: ["Das Foto ist zu groß.", "The photo is too large.", "La foto es demasiado grande."]
  };
  const LANGS = ["de", "en", "es"];
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const browser = (navigator.languages || [navigator.language || ""]).map((l) => String(l).slice(0, 2).toLowerCase());
  let lang = browser.find((l) => LANGS.includes(l)) || (document.documentElement.lang || "en").slice(0, 2);
  if (!LANGS.includes(lang)) lang = "en";
  const tx = (key, values) => {
    const row = T[key] || [key, key, key];
    let text = row[LANGS.indexOf(lang)] ?? row[1];
    for (const [k, v] of Object.entries(values || {})) text = text.split(`{${k}}`).join(v);
    return text;
  };
  const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const day = (iso) => new Date(iso + "T12:00:00").toLocaleDateString(LOCALES[lang], { day: "numeric", month: "long", year: "numeric" });

  function applyLanguage() {
    document.documentElement.lang = lang;
    document.querySelectorAll("[data-t]").forEach((node) => { node.textContent = tx(node.dataset.t); });
    document.querySelectorAll("[data-tp]").forEach((node) => { node.placeholder = tx(node.dataset.tp); });
    $("handPreview").dataset.empty = tx("handEmpty");
  }

  // ------------------------------------------------------------ Speicher

  const store = {
    get(key) { try { return localStorage.getItem("guestbook." + key) || ""; } catch (_) { return ""; } },
    set(key, value) { try { localStorage.setItem("guestbook." + key, value); } catch (_) { /* privat */ } }
  };
  let device = store.get("dev");
  if (!/^[A-Za-z0-9_-]{8,64}$/.test(device)) {
    const bytes = new Uint8Array(16);
    (window.crypto || {}).getRandomValues ? crypto.getRandomValues(bytes) : bytes.forEach((_, i) => { bytes[i] = Math.random() * 256; });
    device = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
    store.set("dev", device);
  }
  const params = new URLSearchParams(location.search);
  let code = (params.get("c") || store.get("code") || "").replace(/\D/g, "").slice(0, 4);
  if (params.get("c")) history.replaceState(null, "", location.pathname);   // Code nicht im Verlauf teilen
  let info = null;
  let photo = null;        // Blob, schon verkleinert
  let mine = null;         // zuletzt eingetragen

  const q = () => `c=${encodeURIComponent(code)}&dev=${encodeURIComponent(device)}`;
  async function getJson(path) {
    const response = await fetch(path, { cache: "no-store" });
    return response.json();
  }
  async function postJson(path, body) {
    const response = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    return response.json();
  }

  function show(id) {
    for (const screen of ["codeScreen", "signScreen", "thanksScreen", "bookScreen"]) $(screen).hidden = screen !== id;
    $("loadNote").hidden = true;
    scrollTo(0, 0);
  }

  // ------------------------------------------------------------ Start

  async function load() {
    applyLanguage();
    try {
      info = await getJson(`api/info?${q()}`);
    } catch (_) {
      $("loadNote").textContent = tx("noAnswer");
      setTimeout(load, 4000);
      return;
    }
    if (!info.title) info.title = tx("defaultTitle");
    $("bookTitle").textContent = info.event ? info.event.title : info.title;
    if (!info.codeOk) {
      $("code").value = "";
      show("codeScreen");
      return;
    }
    store.set("code", code);
    prepareSign();
    show("signScreen");
  }

  $("codeButton").addEventListener("click", async () => {
    code = $("code").value.replace(/\D/g, "").slice(0, 4);
    $("codeNote").textContent = "";
    try {
      info = await getJson(`api/info?${q()}`);
    } catch (_) {
      $("codeNote").textContent = tx("noAnswer");
      return;
    }
    if (!info.codeOk) {
      $("codeNote").textContent = tx("badCode");
      return;
    }
    store.set("code", code);
    prepareSign();
    show("signScreen");
  });
  $("code").addEventListener("keydown", (e) => { if (e.key === "Enter") $("codeButton").click(); });

  function prepareSign() {
    if (!info.title) info.title = tx("defaultTitle");
    $("signTitle").textContent = info.event ? info.event.title : info.title;
    $("signLead").textContent = tx(info.event ? "signLeadParty" : "signLead");
    $("photoOptional").textContent = tx(info.requirePhoto ? "required" : "optional");
    if (!$("name").value) $("name").value = store.get("name");
    $("bookButton").hidden = false;
    updateHand();
  }

  // ------------------------------------------------------------ Selfie

  async function shrink(file) {
    // Schon im Handy verkleinern (geht im WLAN schneller) und HEIC dabei in JPEG wandeln.
    try {
      let source;
      try {
        source = await createImageBitmap(file, { imageOrientation: "from-image" });
      } catch (_) {
        source = await new Promise((resolve, reject) => {
          const img = new Image();
          img.onload = () => resolve(img);
          img.onerror = reject;
          img.src = URL.createObjectURL(file);
        });
      }
      const w = source.width || source.naturalWidth, h = source.height || source.naturalHeight;
      const scale = Math.min(1, 1800 / Math.max(w, h));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(w * scale);
      canvas.height = Math.round(h * scale);
      canvas.getContext("2d").drawImage(source, 0, 0, canvas.width, canvas.height);
      const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.88));
      return blob && blob.size > 1000 ? blob : file;
    } catch (_) {
      return file;   // das Plugin kann es selbst (auch HEIC)
    }
  }

  async function pick(event) {
    const file = event.target.files && event.target.files[0];
    event.target.value = "";
    if (!file) return;
    $("sendNote").textContent = tx("preparing");
    $("sendNote").className = "note";
    photo = await shrink(file);
    $("sendNote").textContent = "";
    if (photo.size > 38 * 1024 * 1024) {
      photo = null;
      $("sendNote").textContent = tx("tooBig");
      $("sendNote").className = "note bad";
      return;
    }
    $("preview").src = URL.createObjectURL(photo);
    $("preview").hidden = false;
    $("shoot").hidden = true;
    $("retake").hidden = false;
    $("dropPhoto").hidden = false;
  }
  for (const id of ["selfie", "selfie2", "gallery"]) $(id).addEventListener("change", pick);
  $("dropPhoto").addEventListener("click", () => {
    photo = null;
    $("preview").hidden = true;
    $("preview").removeAttribute("src");
    $("shoot").hidden = false;
    $("retake").hidden = true;
    $("dropPhoto").hidden = true;
  });

  function updateHand() {
    $("handPreview").textContent = $("text").value;
    const left = 400 - $("text").value.length;
    $("count").textContent = left < 80 ? String(left) : "";
  }
  $("text").addEventListener("input", updateHand);

  // ------------------------------------------------------------ Absenden

  function send(form) {
    return new Promise((resolve) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "api/entry");
      xhr.upload.onprogress = (e) => {
        if (!e.lengthComputable) return;
        $("sendNote").textContent = tx("sending", { p: Math.round((e.loaded / e.total) * 100) });
      };
      xhr.onload = () => {
        let body = {};
        try { body = JSON.parse(xhr.responseText); } catch (_) { /* leer */ }
        resolve(body.success ? body : { success: false, error: body.error || `HTTP ${xhr.status}` });
      };
      xhr.onerror = () => resolve({ success: false, error: tx("noAnswer") });
      xhr.send(form);
    });
  }

  $("sendButton").addEventListener("click", async () => {
    const name = $("name").value.trim();
    const text = $("text").value.trim();
    const note = $("sendNote");
    note.className = "note bad";
    if (!name) { note.textContent = tx("needName"); $("name").focus(); return; }
    if (info.requirePhoto && !photo) { note.textContent = tx("needPhoto"); return; }
    if (!photo && !text) { note.textContent = tx("needSomething"); return; }
    store.set("name", name);
    const form = new FormData();
    form.append("c", code);
    form.append("dev", device);
    form.append("name", name);
    form.append("text", text);
    if (photo) form.append("photo", photo, "selfie.jpg");
    $("sendButton").disabled = true;
    note.className = "note";
    note.textContent = tx("sending", { p: 0 });
    const result = await send(form);
    $("sendButton").disabled = false;
    if (!result.success) {
      if (result.error === "code") { show("codeScreen"); return; }
      note.className = "note bad";
      note.textContent = result.error;
      return;
    }
    note.textContent = "";
    mine = result.entry;
    thanks(result);
  });

  function card(entry, size = "f") {
    const src = entry.photo ? `api/photo?id=${encodeURIComponent(entry.id)}&s=${size}&${q()}` : "";
    return `${entry.photo ? `<div class="shot"><img src="${src}" alt="" loading="lazy"></div>` : ""}
      ${entry.text ? `<p class="hand">${esc(entry.text)}</p>` : ""}
      <p class="who"><span>${esc(entry.name)}</span><small>${esc(day(entry.day))}</small></p>`;
  }

  function thanks(result) {
    const entry = result.entry;
    $("thanksTitle").textContent = tx("thanks", { name: entry.name });
    $("thanksLead").textContent = result.waiting ? tx("thanksWait") : tx("thanksLead");
    $("myCard").className = `polaroid entry${entry.photo ? "" : " noshot"}`;
    $("myCard").innerHTML = card(entry);
    const lines = [];
    if (entry.visit > 1) lines.push(tx("again1", { n: entry.visit, date: day(entry.first) }));
    if (result.tv) lines.push(tx("lookTv"));
    $("thanksNote").textContent = lines.join(" ");
    $("thanksNote").className = "note ok";
    $("editBox").hidden = true;
    $("thanksButtons").hidden = false;
    $("deleteButton").textContent = tx("delete");
    $("deleteButton").dataset.sure = "";
    show("thanksScreen");
  }

  $("againButton").addEventListener("click", () => {
    photo = null;
    $("dropPhoto").click();
    $("name").value = "";
    $("text").value = "";
    updateHand();
    show("signScreen");
  });

  $("editButton").addEventListener("click", () => {
    $("editName").value = mine.name;
    $("editText").value = mine.text;
    $("editBox").hidden = false;
    $("thanksButtons").hidden = true;
  });
  $("editCancel").addEventListener("click", () => { $("editBox").hidden = true; $("thanksButtons").hidden = false; });
  $("editSave").addEventListener("click", async () => {
    const result = await postJson("api/edit", { c: code, dev: device, id: mine.id, name: $("editName").value, text: $("editText").value }).catch(() => ({ success: false, error: tx("noAnswer") }));
    if (!result.success) { $("thanksNote").className = "note bad"; $("thanksNote").textContent = result.error; return; }
    mine = Object.assign(mine, result.entry);
    $("myCard").innerHTML = card(mine);
    $("thanksTitle").textContent = tx("thanks", { name: mine.name });
    $("editBox").hidden = true;
    $("thanksButtons").hidden = false;
    $("thanksNote").className = "note ok";
    $("thanksNote").textContent = tx("saved");
  });
  $("deleteButton").addEventListener("click", async () => {
    const button = $("deleteButton");
    if (!button.dataset.sure) {
      button.dataset.sure = "1";
      button.textContent = tx("deleteSure");
      setTimeout(() => { button.dataset.sure = ""; button.textContent = tx("delete"); }, 4000);
      return;
    }
    const result = await postJson("api/edit", { c: code, dev: device, id: mine.id, delete: true }).catch(() => ({ success: false, error: tx("noAnswer") }));
    if (!result.success) { $("thanksNote").className = "note bad"; $("thanksNote").textContent = result.error; return; }
    $("thanksTitle").textContent = tx("deleted");
    $("thanksLead").textContent = "";
    $("myCard").innerHTML = "";
    $("myCard").className = "";
    $("thanksNote").textContent = "";
    $("thanksButtons").hidden = true;
  });

  // ------------------------------------------------------------ Buch ansehen

  let from = "signScreen";
  $("bookButton").addEventListener("click", () => openBook("thanksScreen"));
  $("backButton").addEventListener("click", () => show(from));

  async function openBook(back) {
    from = back;
    show("bookScreen");
    $("entries").innerHTML = "";
    let result;
    try {
      result = await getJson(`api/book?${q()}`);
    } catch (_) {
      $("bookLead").textContent = tx("noAnswer");
      return;
    }
    if (!result.success) { show("codeScreen"); return; }
    $("bookLead").textContent = !info.seeBook ? tx("bookOff") : result.event ? tx("bookLeadParty", { title: result.event }) : tx("bookLead");
    let rows = result.entries || [];
    if (!info.seeBook) rows = (info.mine || []);
    $("entries").innerHTML = rows.length ? rows.map((e) => `<div class="polaroid entry${e.photo ? "" : " noshot"}${e.mine ? " mine" : ""}">${card(e, "t")}
      ${e.mine ? `<span class="tag">${esc(tx("yours"))}${e.st === "wait" ? " · " + esc(tx("waiting")) : ""}</span>` : ""}</div>`).join("")
      : `<p class="empty">${esc(tx("noEntries"))}</p>`;
  }

  load();
})();
