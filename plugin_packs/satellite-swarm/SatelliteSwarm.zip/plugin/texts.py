"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Alle aktiven Satelliten live als Schwarm um die Erde und am Himmel über deinem Haus.": (
        "All active satellites live as a swarm around the Earth and in the sky above your home.",
        "Todos los satélites activos en directo como un enjambre alrededor de la Tierra y en el cielo sobre tu casa."),
    "Holt die Bahndaten jetzt neu von CelesTrak.": (
        "Fetching the orbit data from CelesTrak again now.", "Volviendo a cargar ahora los datos orbitales de CelesTrak."),
    "CelesTrak ist nicht erreichbar: {exc}": (
        "CelesTrak cannot be reached: {exc}", "No se puede acceder a CelesTrak: {exc}"),
    "CelesTrak hat keine Bahndaten geliefert ({text}).": (
        "CelesTrak did not send any orbit data ({text}).", "CelesTrak no ha enviado datos orbitales ({text})."),
    "Die Bahndaten sind gerade erst geholt worden. CelesTrak bittet, höchstens alle zwei Stunden zu fragen; neu geholt wird um {time}.": (
        "The orbit data was fetched only a moment ago. CelesTrak asks not to ask more often than every two hours; next fetch at {time}.",
        "Los datos orbitales se acaban de cargar. CelesTrak pide no consultar más de una vez cada dos horas; próxima carga a las {time}."),
    "Satellite Swarm ist auf der Plugins-Seite ausgeschaltet.": (
        "Satellite Swarm is switched off on the Plugins page.", "Satellite Swarm está desactivado en la página de plugins."),
    "„Übernahme erlauben“ ist für Satellite Swarm auf der Plugins-Seite aus. Schalte es ein, sonst kann der Überflug nicht über die Playlist gelegt werden.": (
        "“Allow takeover” is off for Satellite Swarm on the Plugins page. Switch it on, otherwise the pass cannot be put over the playlist.",
        "“Permitir toma de control” está desactivado para Satellite Swarm en la página de plugins. Actívalo; si no, el paso no se puede poner sobre la playlist."),
    "Gerade hat etwas anderes den Bildschirm.": (
        "Something else has the screen right now.", "Ahora mismo otra cosa tiene la pantalla."),
    "Der Bildschirm ist aus; der Überflug wird nicht gezeigt.": (
        "The screen is off; the pass is not shown.", "La pantalla está apagada; el paso no se muestra."),
    "Dieser Rahmen ist zu alt, damit ein Plugin den Bildschirm übernehmen kann.": (
        "This frame is too old to let a plugin take over the screen.",
        "Este marco es demasiado antiguo para que un plugin tome la pantalla."),
    "Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The scene is not installed on this frame. Install the pack again.",
        "La escena no está instalada en este marco. Instala el paquete de nuevo."),
    "Die Übernahme-Playlist ist noch nicht angelegt.": (
        "The takeover playlist has not been created yet.", "La playlist de toma de control aún no se ha creado."),
    "Konnte die Übernahme-Playlist nicht anlegen: {exc}": (
        "Could not create the takeover playlist: {exc}", "No se pudo crear la playlist de toma de control: {exc}"),
    "Konnte den Überflug nicht zeigen: {exc}": (
        "Could not show the pass: {exc}", "No se pudo mostrar el paso: {exc}"),
    "Der Rahmen hat den Überflug nicht rechtzeitig gezeigt.": (
        "The frame did not show the pass in time.", "El marco no mostró el paso a tiempo."),
    "Zeigt gerade den Überflug von {name}.": (
        "Showing the pass of {name} right now.", "Mostrando ahora el paso de {name}."),
    "Starlink-Zug": ("Starlink train", "Tren Starlink"),
    "Trag zuerst deinen Ort ein.": ("Enter your place first.", "Introduce primero tu lugar."),
    "Kein passender Überflug in den nächsten 36 Stunden.": (
        "No matching pass in the next 36 hours.", "Ningún paso adecuado en las próximas 36 horas."),
    "Probe-Überflug: die Szene spielt eine Minute lang eine Ansage.": (
        "Test pass: the scene plays an announcement for one minute.",
        "Paso de prueba: la escena muestra un aviso durante un minuto."),
}


def t(language, text, **values):
    row = _TEXTS.get(text)
    if row and language in LANGUAGES[1:]:
        text = row[LANGUAGES.index(language) - 1]
    for key, value in values.items():
        text = text.replace("{" + key + "}", str(value))
    return text
