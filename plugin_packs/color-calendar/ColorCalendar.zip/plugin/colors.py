"""Die Farbe eines Fotos und eines Tages.

Ein Foto bekommt bis zu drei Farben mit Gewicht ("Palette"): die Farbe, die
im Bild am meisten Fläche hat, wobei kräftige Farben etwas mehr zählen als
Grau, damit ein Strandtag blau und gelb wird und nicht graubraun. Ein Tag
bekommt aus den Paletten seiner Fotos wieder bis zu vier Farben.

Die Pixel kommen aus einem kleinen Vorschaubild (Pillow) oder, bei Immich,
aus dem ThumbHash, den Immich zu jedem Foto mitliefert. Dann muss das Plugin
kein einziges Bild herunterladen.
"""

import base64
import colorsys
import io
import math

HUE_BINS = 24
NEUTRAL = ("dark", "mid", "light")
MAX_COLOURS = 3


def _bin(r, g, b):
    """(Fach, Gewicht) für ein Pixel mit Werten 0..1."""
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    if v < 0.12:
        return HUE_BINS, 0.12                    # fast schwarz zählt kaum
    if s < 0.2 or (s < 0.3 and v < 0.3):
        return HUE_BINS + (0 if v < 0.4 else 1 if v < 0.75 else 2), 0.55
    return int(h * HUE_BINS) % HUE_BINS, 0.6 + 1.3 * s * (0.4 + 0.6 * v)


def _pick(bins, total, limit):
    """Die stärksten Fächer, Nachbarn mitgezählt, ohne zwei fast gleiche Farben."""
    def score(i):
        own = bins.get(i)
        if own is None:
            return 0.0
        if i >= HUE_BINS:
            return own[0]
        near = sum(0.5 * bins[j][0] for j in ((i - 1) % HUE_BINS, (i + 1) % HUE_BINS) if j in bins)
        return own[0] + near

    ranked = sorted(bins, key=score, reverse=True)
    chosen = []
    for i in ranked:
        if len(chosen) >= limit:
            break
        if i < HUE_BINS and any(c < HUE_BINS and min((i - c) % HUE_BINS, (c - i) % HUE_BINS) <= 1 for c in chosen):
            continue
        if i >= HUE_BINS and i in chosen:
            continue
        chosen.append(i)
    out = []
    for i in chosen:
        members = [i] if i >= HUE_BINS else [i, (i - 1) % HUE_BINS, (i + 1) % HUE_BINS]
        w = r = g = b = 0.0
        for j, factor in zip(members, (1.0, 0.35, 0.35)):
            if j in bins:
                bw, br, bg, bb = bins[j]
                w += bw * factor
                r += br * factor
                g += bg * factor
                b += bb * factor
        if w <= 0:
            continue
        out.append((r / w, g / w, b / w, score(i) / total if total else 0.0))
    weight = sum(c[3] for c in out) or 1.0
    return [(to_hex(c[0], c[1], c[2]), round(c[3] / weight, 3)) for c in out if c[3] / weight >= 0.06]


def to_hex(r, g, b):
    return "%02x%02x%02x" % tuple(max(0, min(255, round(c * 255))) for c in (r, g, b))


def from_hex(text):
    return tuple(int(text[i:i + 2], 16) / 255 for i in (0, 2, 4))


def palette(pixels, limit=MAX_COLOURS):
    """[(rrggbb, Anteil)] aus Pixeln (r, g, b) mit 0..255."""
    bins, total = {}, 0.0
    for r, g, b in pixels:
        r, g, b = r / 255, g / 255, b / 255
        i, w = _bin(r, g, b)
        row = bins.get(i)
        if row is None:
            row = bins[i] = [0.0, 0.0, 0.0, 0.0]
        row[0] += w
        row[1] += r * w
        row[2] += g * w
        row[3] += b * w
        total += w
    if not bins:
        return []
    return _pick(bins, total, limit)


def merge(palettes, limit=4):
    """Die Farben eines Tages aus den Paletten seiner Fotos (jedes Foto zählt gleich)."""
    bins, total = {}, 0.0
    for colours in palettes:
        for hex_colour, share in colours:
            r, g, b = from_hex(hex_colour)
            i, w = _bin(r, g, b)
            w *= share
            row = bins.get(i)
            if row is None:
                row = bins[i] = [0.0, 0.0, 0.0, 0.0]
            row[0] += w
            row[1] += r * w
            row[2] += g * w
            row[3] += b * w
            total += w
    if not bins:
        return []
    return _pick(bins, total, limit)


def pack(colours):
    """[(hex, Anteil)] -> "rrggbb:57,rrggbb:30" (Anteil in Prozent), klein für den Cache."""
    return ",".join(f"{h}:{round(w * 100)}" for h, w in colours)


def unpack(text):
    out = []
    for part in str(text or "").split(","):
        hex_colour, _, share = part.partition(":")
        if len(hex_colour) == 6:
            try:
                out.append((hex_colour, int(share or 100) / 100))
            except ValueError:
                continue
    return out


# --------------------------------------------------------------------------
# Bilder
# --------------------------------------------------------------------------

def image_pixels(data_or_path, size=48):
    """Pixel eines Bildes (Bytes oder Pfad), auf size x size verkleinert."""
    from PIL import Image  # erst hier: ohne Pillow geht Immich trotzdem

    source = io.BytesIO(data_or_path) if isinstance(data_or_path, (bytes, bytearray)) else data_or_path
    with Image.open(source) as image:
        try:
            image.draft("RGB", (size * 2, size * 2))     # JPEG: gleich verkleinert dekodieren, viel schneller
        except (AttributeError, ValueError, OSError):
            pass
        image = image.convert("RGB")
        image.thumbnail((size, size))
        raw = image.tobytes()
        return [(raw[i], raw[i + 1], raw[i + 2]) for i in range(0, len(raw) - 2, 3)]


def heif_ready():
    try:
        import pillow_heif  # noqa: F401
    except ImportError:
        return False
    try:
        pillow_heif.register_heif_opener()
    except Exception:
        return False
    return True


# --------------------------------------------------------------------------
# ThumbHash (https://evanw.github.io/thumbhash/, MIT, Evan Wallace),
# hier nur das Dekodieren in ein kleines Bild
# --------------------------------------------------------------------------

def thumbhash_pixels(text, grid=12):
    """Pixel (0..255) aus einem ThumbHash als Base64 (so liefert ihn Immich)."""
    raw = str(text or "").strip()
    raw += "=" * (-len(raw) % 4)
    hash_ = base64.b64decode(raw)
    if len(hash_) < 6:
        raise ValueError("ThumbHash zu kurz")
    header24 = hash_[0] | (hash_[1] << 8) | (hash_[2] << 16)
    header16 = hash_[3] | (hash_[4] << 8)
    l_dc = (header24 & 63) / 63
    p_dc = ((header24 >> 6) & 63) / 31.5 - 1
    q_dc = ((header24 >> 12) & 63) / 31.5 - 1
    l_scale = ((header24 >> 18) & 31) / 31
    has_alpha = header24 >> 23
    p_scale = ((header16 >> 3) & 63) / 63
    q_scale = ((header16 >> 9) & 63) / 63
    is_landscape = header16 >> 15
    lx = max(3, (5 if has_alpha else 7) if is_landscape else header16 & 7)
    ly = max(3, header16 & 7 if is_landscape else (5 if has_alpha else 7))
    ac_start = 6 if has_alpha else 5
    index = [0]

    def channel(nx, ny, scale):
        ac = []
        for cy in range(ny):
            cx = 0 if cy else 1
            while cx * ny < nx * (ny - cy):
                at = ac_start + (index[0] >> 1)
                nibble = (hash_[at] >> ((index[0] & 1) << 2)) & 15 if at < len(hash_) else 7.5
                ac.append((nibble / 7.5 - 1) * scale)
                index[0] += 1
                cx += 1
        return ac

    l_ac = channel(lx, ly, l_scale)
    p_ac = channel(3, 3, p_scale * 1.25)
    q_ac = channel(3, 3, q_scale * 1.25)

    out = []
    n = max(lx, ly, 3)
    for y in range(grid):
        fy = [math.cos(math.pi / grid * (y + 0.5) * c) for c in range(n)]
        for x in range(grid):
            fx = [math.cos(math.pi / grid * (x + 0.5) * c) for c in range(n)]
            l, p, q = l_dc, p_dc, q_dc
            j = 0
            for cy in range(ly):
                cx = 0 if cy else 1
                fy2 = fy[cy] * 2
                while cx * ly < lx * (ly - cy):
                    l += l_ac[j] * fx[cx] * fy2
                    j += 1
                    cx += 1
            j = 0
            for cy in range(3):
                cx = 0 if cy else 1
                fy2 = fy[cy] * 2
                while cx < 3 - cy:
                    f = fx[cx] * fy2
                    p += p_ac[j] * f
                    q += q_ac[j] * f
                    j += 1
                    cx += 1
            b = l - 2 / 3 * p
            r = (3 * l - b + q) / 2
            g = r - q
            out.append(tuple(max(0, min(255, round(255 * c))) for c in (r, g, b)))
    return out
