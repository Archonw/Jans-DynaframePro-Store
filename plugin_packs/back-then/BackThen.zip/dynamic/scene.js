/* Back Then - die Szene.
 *
 * Zeigt ein paar alte Fotos aus einem Jahr und daneben, was damals los war:
 * Ereignisse, der Nummer-eins-Hit am Tag des Fotos, wer regiert hat, Preise
 * damals und heute, wer in dem Jahr geboren wurde und wie alt die eigenen
 * Leute waren. Alles kommt vom Plugin BackThen über den Proxy der Weboberfläche.
 *
 * Zwei Ansichten: panel (Foto + Almanach-Seite) und paper (Titelseite einer
 * Zeitung von damals). Nach dem letzten Foto des Jahres sagt die Szene dem
 * Plugin Bescheid (api/scene?done=<id>) und zeigt dann das nächste Jahr.
 *
 * ?plugin=<url> nimmt ein anderes Plugin (Tests), ?lang=, ?layout=, ?photo=<n> bleibt bei Foto n.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "BackThen";
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set([
    `${location.protocol}//${location.hostname}:8003${advanced}`,
    `${location.protocol}//${location.hostname}${advanced}`,
    `${location.origin}${advanced}`,
  ])];
  // Kommt die Szene über Port 80/443 (RemoteFrame, Web Login), zuerst denselben Ursprung fragen.
  if (!params.get("plugin") && (location.port === "" || location.port === "80" || location.port === "443")) {
    pluginBases.sort((a, b) => (b.startsWith(location.origin) ? 1 : 0) - (a.startsWith(location.origin) ? 1 : 0));
  }
  let baseIndex = 0;
  const base = () => pluginBases[baseIndex];
  const abs = (path) => (path.startsWith("./") ? base() + path.slice(2) : path);

  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const TEXT = {
    de: {
      kicker: "Was war damals los?", ago: "vor {n} Jahren", ago1: "vor einem Jahr", news: "In den Nachrichten",
      hitDay: "Nummer eins an dem Tag", hitYear: "Hit des Jahres", weeks: "{n} Wochen auf Platz 1", weeks1: "1 Woche auf Platz 1",
      leader: "Regierung", prices: "Was kostete was?", then: "damals", today: "heute", born: "Geboren {y}",
      age: "{name} war {n}", unborn: "{name} noch nicht geboren", ageTitle: "Wie alt wart ihr?",
      inflation: "Insgesamt kostet heute alles etwa {n}-mal so viel.",
      busy: "Die alten Fotos werden gesucht …", offline: "Back Then antwortet nicht",
      noSource: "Wähle auf der Plugin-Seite, woher die Fotos kommen.",
      emptyTitle: "Noch keine alten Fotos", emptyText: "Back Then braucht Fotos mit Aufnahmedatum, die mindestens {n} Jahre alt sind.",
      paper: "Der Damals-Bote", issue: "Ausgabe {y}", price: "Preis: {p}", photoOf: "Unser Foto des Tages",
      items: { bread: "Brot", milk: "Milch", butter: "Butter", petrol: "Benzin", diesel: "Diesel", stamp: "Briefmarke",
        eggs: "Eier", beer: "Bier", coffee: "Kaffee", cinema: "Kino", sugar: "Zucker", potatoes: "Kartoffeln" },
      units: { kg: "1 kg", l: "1 l", "250g": "250 g", "500g": "500 g", letter: "Brief", dozen: "12 Stück", lb: "1 lb",
        gal: "1 Gallone", "10": "10 Stück", ticket: "Karte", "0.5l": "0,5 l" },
      sources: "Wikipedia, Wikidata, Statistikämter",
    },
    en: {
      kicker: "What was going on back then?", ago: "{n} years ago", ago1: "a year ago", news: "In the news",
      hitDay: "Number one that day", hitYear: "Hit of the year", weeks: "{n} weeks at number 1", weeks1: "1 week at number 1",
      leader: "Government", prices: "What things cost", then: "then", today: "today", born: "Born in {y}",
      age: "{name} was {n}", unborn: "{name} not born yet", ageTitle: "How old were you?",
      inflation: "Overall, things cost about {n} times as much today.",
      busy: "Looking for old photos …", offline: "Back Then is not responding",
      noSource: "Pick on the plugin page where the photos come from.",
      emptyTitle: "No old photos yet", emptyText: "Back Then needs photos with a date taken that are at least {n} years old.",
      paper: "The Back Then Times", issue: "Edition {y}", price: "Price: {p}", photoOf: "Our photo of the day",
      items: { bread: "Bread", milk: "Milk", butter: "Butter", petrol: "Petrol", diesel: "Diesel", stamp: "Stamp",
        eggs: "Eggs", beer: "Beer", coffee: "Coffee", cinema: "Cinema", sugar: "Sugar", potatoes: "Potatoes" },
      units: { kg: "1 kg", l: "1 l", "250g": "250 g", "500g": "500 g", letter: "letter", dozen: "dozen", lb: "1 lb",
        gal: "1 gallon", "10": "10", ticket: "ticket", "0.5l": "0.5 l" },
      sources: "Wikipedia, Wikidata, statistics offices",
    },
    es: {
      kicker: "¿Qué pasaba entonces?", ago: "hace {n} años", ago1: "hace un año", news: "En las noticias",
      hitDay: "Número uno ese día", hitYear: "Éxito del año", weeks: "{n} semanas en el n.º 1", weeks1: "1 semana en el n.º 1",
      leader: "Gobierno", prices: "Lo que costaban las cosas", then: "entonces", today: "hoy", born: "Nacidos en {y}",
      age: "{name} tenía {n}", unborn: "{name} aún no había nacido", ageTitle: "¿Cuántos años teníais?",
      inflation: "En general, hoy todo cuesta unas {n} veces más.",
      busy: "Buscando fotos antiguas …", offline: "Back Then no responde",
      noSource: "Elige en la página del plugin de dónde vienen las fotos.",
      emptyTitle: "Aún no hay fotos antiguas", emptyText: "Back Then necesita fotos con fecha que tengan al menos {n} años.",
      paper: "El Diario de Entonces", issue: "Edición {y}", price: "Precio: {p}", photoOf: "Nuestra foto del día",
      items: { bread: "Pan", milk: "Leche", butter: "Mantequilla", petrol: "Gasolina", diesel: "Diésel", stamp: "Sello",
        eggs: "Huevos", beer: "Cerveza", coffee: "Café", cinema: "Cine", sugar: "Azúcar", potatoes: "Patatas" },
      units: { kg: "1 kg", l: "1 l", "250g": "250 g", "500g": "500 g", letter: "carta", dozen: "docena", lb: "1 lb",
        gal: "1 galón", "10": "10", ticket: "entrada", "0.5l": "0,5 l" },
      sources: "Wikipedia, Wikidata, oficinas de estadística",
    },
  };
  const CURRENCY = { DM: "DM", "€": "€", EUR: "€", USD: "$", "$": "$", GBP: "£", "£": "£", CHF: "Fr.", ATS: "S", ESP: "Pta", "c": "¢" };

  const el = (id) => document.getElementById(id);
  const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const state = {
    lang: params.get("lang") || "en",
    s: { Layout: params.get("layout") || "panel", PhotoSeconds: 15, FadeSeconds: 1.5, KenBurns: true, ShowPlace: true,
      ShowEvents: true, ShowHit: true, ShowLeader: true, ShowPrices: true, ShowBorn: true, ShowAges: true, EventCount: 4 },
    visit: null, busy: false, sources: 1, minYears: 10, failures: 0, loaded: false,
  };
  let shown = null;          // die Besuchs-ID, die gerade läuft
  let pos = -1;
  let timer = 0;
  let front = "A";
  let readySent = false;
  let viewShown = "";

  const tx = (key, values = {}) => String((TEXT[state.lang] || TEXT.en)[key] ?? TEXT.en[key] ?? key)
    .replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");
  const dict = (key) => (TEXT[state.lang] || TEXT.en)[key] || TEXT.en[key];
  const locale = () => LOCALES[state.lang] || "en-GB";

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 8000);

  function report(text) {
    try {
      fetch(`${base()}api/report?m=${encodeURIComponent(String(text).slice(0, 200))}`, { cache: "no-store" }).catch(() => {});
    } catch (_) { /* egal */ }
  }

  function sizeUnit() {
    const u = Math.min(innerWidth, innerHeight) / 100;
    document.documentElement.style.setProperty("--u", `${u}px`);
    document.body.classList.toggle("tall", innerHeight > innerWidth * 1.05);
  }
  addEventListener("resize", sizeUnit);
  sizeUnit();

  // ------------------------------------------------------------ Formatieren

  function fmtDate(iso, opts) {
    if (!iso) return "";
    const d = new Date(`${iso.slice(0, 10)}T12:00:00`);
    return isNaN(d) ? "" : d.toLocaleDateString(locale(), opts);
  }
  const longDate = (iso) => fmtDate(iso, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  const shortDate = (iso) => fmtDate(iso, { day: "numeric", month: "short" });

  function money(value, cur) {
    if (value == null) return "";
    const sym = CURRENCY[cur] ?? cur;
    if (cur === "c") return `${Math.round(value)} ¢`;
    const digits = value >= 100 ? 0 : 2;
    const num = Number(value).toLocaleString(locale(), { minimumFractionDigits: digits, maximumFractionDigits: digits });
    if (sym === "$" || sym === "£") return `${sym}${num}`;
    return `${num} ${sym}`;
  }

  function agoText(n) { return n === 1 ? tx("ago1") : tx("ago", { n }); }

  function agesText(list) {
    return (list || []).map((a) => a.unborn ? tx("unborn", { name: esc(a.name) })
      : tx("age", { name: `<b>${esc(a.name)}</b>`, n: a.age })).join(" · ");
  }

  // ------------------------------------------------------------ Bausteine (gemeinsam für beide Ansichten)

  function newsHtml(facts, count, withDesc) {
    const events = (facts.events || []).slice(0, count).sort((a, b) => (a.date || "").localeCompare(b.date || ""));
    if (!events.length) return "";
    return `<h3>${esc(tx("news"))}</h3><ul>${events.map((e) => `<li>${e.date && e.date.slice(5) !== "01-01" ? `<span class="d">${esc(shortDate(e.date))}</span>` : ""}`
      + `<span class="t">${esc(e.label)}</span>${withDesc && e.desc ? `<span class="s">${esc(e.desc)}</span>` : ""}</li>`).join("")}</ul>`;
  }

  function hitHtml(photo, facts) {
    const day = photo && photo.hit;
    const hit = day || facts.hitYear;
    if (!hit) return "";
    const weeks = hit.weeks ? (hit.weeks === 1 ? tx("weeks1") : tx("weeks", { n: hit.weeks })) : "";
    return `<h3>${esc(tx(day ? "hitDay" : "hitYear"))}</h3><p class="song"><span class="disc"></span><span><b>${esc(hit.title)}</b><br>${esc(hit.artist)}</span></p>`
      + (weeks ? `<p class="small">${esc(weeks)}</p>` : "");
  }

  function leaderHtml(photo, facts) {
    const who = (photo && photo.leader) || facts.leader;
    if (!who || !who.name) return "";
    const img = who.portrait ? `<img class="portrait" src="${esc(abs(who.portrait))}" alt="" onerror="this.remove()">` : "";
    const since = who.since ? fmtDate(who.since, { year: "numeric" }) : "";
    return `<h3>${esc(who.title || tx("leader"))}</h3><p class="person">${img}<span><b>${esc(who.name)}</b>${since ? `<br><span class="small">${esc(state.lang === "de" ? "seit" : state.lang === "es" ? "desde" : "since")} ${esc(since)}</span>` : ""}</span></p>`;
  }

  function pricesHtml(facts) {
    const rows = facts.prices || [];
    if (!rows.length) {
      const inf = facts.inflation;
      return inf && inf.factor >= 1.1 ? `<h3>${esc(tx("prices"))}</h3><p>${esc(tx("inflation", { n: inf.factor.toLocaleString(locale(), { maximumFractionDigits: 1 }) }))}</p>` : "";
    }
    const items = dict("items"), units = dict("units");
    const body = rows.slice(0, 5).map((p) => {
      const name = `${items[p.item] || p.item}${p.unit ? ` <span class="u">${esc(units[p.unit] || p.unit)}</span>` : ""}`;
      const then = (p.exact === false && p.year >= 2003 ? "≈ " : "") + money(p.then, p.cur)
        + (p.euro != null ? ` <span class="u">(${money(p.euro, "€")})</span>` : "");
      return `<tr><th>${name}</th><td class="then">${then}</td><td class="now">${p.exact === false ? "≈ " : ""}${money(p.now, p.nowCur)}</td></tr>`;
    }).join("");
    const nowYear = Math.max(0, ...rows.slice(0, 5).map((p) => p.nowYear || 0));
    const inf = facts.inflation;
    const infText = inf && inf.factor >= 1.1
      ? `<p class="small">${esc(tx("inflation", { n: inf.factor.toLocaleString(locale(), { maximumFractionDigits: 1 }) }))}</p>` : "";
    return `<h3>${esc(tx("prices"))}</h3><table><thead><tr><th></th><td>${esc(tx("then"))}</td><td>${esc(tx("today"))}${nowYear ? ` (${nowYear})` : ""}</td></tr></thead><tbody>${body}</tbody></table>${infText}`;
  }

  function bornHtml(facts, year, count) {
    const list = (facts.born || []).slice(0, count);
    if (!list.length) return "";
    return `<h3>${esc(tx("born", { y: year }))}</h3><p>${list.map((b) => `<b>${esc(b.label)}</b>${b.desc ? ` <span class="small">${esc(b.desc)}</span>` : ""}`).join("<br>")}</p>`;
  }

  function setBlock(node, html, on) {
    node.innerHTML = on ? html : "";
    node.hidden = !on || !html;
  }

  // ------------------------------------------------------------ Ansichten

  function showView(id) {
    for (const v of ["panel", "paper", "message"]) el(v).hidden = v !== id;
    if (viewShown !== id) {
      el(id).classList.remove("in");
      void el(id).offsetWidth;
      el(id).classList.add("in");
    }
    viewShown = id;
  }

  function showMessage(kind) {
    clearTimeout(timer);
    shown = null;
    const titles = {
      busy: [tx("busy"), ""], offline: [tx("offline"), ""], noSource: [tx("noSource"), ""],
      empty: [tx("emptyTitle"), tx("emptyText", { n: state.minYears })],
    };
    const [title, text] = titles[kind] || titles.busy;
    el("msgTitle").textContent = title;
    el("msgText").textContent = text;
    showView("message");
    ready();
  }

  function fillPanel(visit, photo) {
    const f = visit.facts || {};
    const s = state.s;
    el("panelKicker").textContent = tx("kicker");
    el("panelYear").textContent = visit.year;
    el("panelWhen").textContent = `${longDate(photo.t)} · ${agoText(new Date().getFullYear() - visit.year)}`;
    const ages = s.ShowAges ? agesText(photo.ages) : "";
    el("panelAges").innerHTML = ages;
    el("panelAges").hidden = !ages;
    const tall = document.body.classList.contains("tall");
    setBlock(el("panelNews"), newsHtml(f, s.EventCount, !tall && s.EventCount <= 4), s.ShowEvents);
    setBlock(el("panelHit"), hitHtml(photo, f), s.ShowHit);
    setBlock(el("panelLeader"), leaderHtml(photo, f), s.ShowLeader);
    setBlock(el("panelPrices"), pricesHtml(f), s.ShowPrices);
    setBlock(el("panelBorn"), bornHtml(f, visit.year, tall ? 2 : 3), s.ShowBorn);
    el("panelCaption").textContent = [s.ShowPlace ? photo.place : "", fmtDate(photo.t, { day: "numeric", month: "long", year: "numeric" })]
      .filter(Boolean).join(" · ");
    el("panelFoot").textContent = tx("sources");
    fitPage(el("panelPage"));
    if (document.fonts && document.fonts.status !== "loaded") document.fonts.ready.then(() => fitPage(el("panelPage")));
  }

  /* Die Seite muss passen: zu lange Blöcke werden der Reihe nach gekürzt. */
  function fitPage(page, tries = 0) {
    if (!page.clientHeight) {             // Ansicht noch versteckt: gleich noch einmal
      if (tries < 40) requestAnimationFrame(() => fitPage(page, tries + 1));
      return;
    }
    page.style.fontSize = "";
    const base = parseFloat(getComputedStyle(page).fontSize) || 20;
    let scale = 1;
    for (let i = 0; i < 8 && page.scrollHeight > page.clientHeight + 2; i++) {
      scale -= 0.05;
      page.style.fontSize = `${(base * scale).toFixed(2)}px`;
    }
    if (page.scrollHeight > page.clientHeight + 2) {
      for (const id of ["panelBorn", "panelPrices"]) {
        if (page.scrollHeight <= page.clientHeight + 2) break;
        const node = page.querySelector(`#${id}`);
        if (node) node.hidden = true;
      }
    }
  }

  function fillPaper(visit, photo) {
    const f = visit.facts || {};
    const s = state.s;
    const events = f.events || [];
    el("mastTitle").textContent = tx("paper");
    el("mastLeft").textContent = tx("issue", { y: visit.year });
    const bread = (f.prices || []).find((p) => p.item === "bread") || (f.prices || [])[0];
    el("mastRight").textContent = agoText(new Date().getFullYear() - visit.year);
    el("dateline").textContent = longDate(photo.t);
    const top = s.ShowEvents ? events[0] : null;
    el("headline").textContent = top ? top.label : tx("kicker");
    el("subhead").textContent = top ? (top.desc || "") : "";
    el("paperCaption").innerHTML = `<b>${esc(tx("photoOf"))}</b> ${esc([s.ShowPlace ? photo.place : "", fmtDate(photo.t, { day: "numeric", month: "long", year: "numeric" })].filter(Boolean).join(" · "))}`;
    setBlock(el("paperHit"), hitHtml(photo, f), s.ShowHit);
    setBlock(el("paperLeader"), leaderHtml(photo, f), s.ShowLeader);
    const ages = s.ShowAges ? agesText(photo.ages) : "";
    setBlock(el("paperAges"), ages ? `<h3>${esc(tx("ageTitle"))}</h3><p>${ages.replace(/ · /g, "<br>")}</p>` : "", !!ages);
    const rest = { events: events.slice(1) };
    setBlock(el("paperNews"), newsHtml(rest, Math.max(1, s.EventCount - 1), true), s.ShowEvents);
    setBlock(el("paperPrices"), pricesHtml(f), s.ShowPrices);
    setBlock(el("paperBorn"), bornHtml(f, visit.year, 3), s.ShowBorn);
    void bread;
    fitSheet();
  }

  function fitSheet() {
    const sheet = el("sheet");
    sheet.style.fontSize = "";
    let scale = 1;
    for (let i = 0; i < 8 && sheet.scrollHeight > sheet.clientHeight + 2; i++) {
      scale -= 0.06;
      sheet.style.fontSize = `${scale}em`;
    }
  }

  // ------------------------------------------------------------ Fotos

  function loadImage(img, url) {
    return new Promise((resolve) => {
      const probe = new Image();
      probe.onload = () => { img.src = url; resolve(true); };
      probe.onerror = () => resolve(false);
      probe.src = url;
    });
  }

  async function showPhoto(visit, index) {
    const layout = state.s.Layout === "paper" ? "paper" : "panel";
    const prefix = layout === "paper" ? "n" : "p";
    const next = front === "A" ? "B" : "A";
    const slide = el(prefix + next), old = el(prefix + front);
    const photo = visit.photos[index];
    const url = `${base()}api/photo?v=${encodeURIComponent(visit.id)}&i=${photo.i}`;
    const ok = await loadImage(slide.querySelector("img"), url);
    if (!ok) report(`Foto ${photo.i} aus ${visit.year} lädt nicht`);
    if (layout === "panel") {
      el("panelBlur").src = ok ? url : "";
      fillPanel(visit, photo);
    } else {
      fillPaper(visit, photo);
    }
    document.documentElement.style.setProperty("--fade", `${state.s.FadeSeconds}s`);
    slide.style.setProperty("--kb-dur", `${state.s.PhotoSeconds + state.s.FadeSeconds}s`);
    slide.classList.toggle("kb", !!state.s.KenBurns);
    slide.classList.remove("moving");
    void slide.offsetWidth;
    slide.classList.add("show", "moving");
    old.classList.remove("show");
    front = next;
    showView(layout);
    ready();
  }

  function step() {
    clearTimeout(timer);
    const visit = state.visit;
    if (!visit || !visit.photos.length) return;
    const fixed = params.get("photo");
    if (fixed != null) {
      pos = Math.min(visit.photos.length - 1, Number(fixed) || 0);
      showPhoto(visit, pos);
      return;
    }
    pos += 1;
    if (pos >= visit.photos.length) {
      // Jahr fertig: dem Plugin sagen; kommt ein neues Jahr, startet poll() es selbst
      const finished = visit.id;
      poll(finished).then(() => {
        if (shown === finished) { pos = -1; step(); }   // kein neues Jahr da: noch einmal
      });
      return;
    }
    showPhoto(visit, pos);
    timer = setTimeout(step, state.s.PhotoSeconds * 1000);
  }

  function begin() {
    shown = state.visit ? state.visit.id : null;
    pos = -1;
    for (const id of ["pA", "pB", "nA", "nB"]) el(id).classList.remove("show");
    step();
  }

  // ------------------------------------------------------------ Daten

  async function poll(done = "") {
    try {
      const response = await fetch(`${base()}api/scene${done ? `?done=${encodeURIComponent(done)}` : ""}`, { cache: "no-store" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      state.failures = 0;
      const layoutBefore = state.s.Layout, langBefore = state.lang;
      state.s = Object.assign(state.s, data.settings || {});
      if (params.get("layout")) state.s.Layout = params.get("layout");
      state.lang = params.get("lang") || state.s.Language || "en";
      document.documentElement.lang = state.lang;
      state.busy = !!data.busy;
      state.sources = data.sources ?? 1;
      state.minYears = data.minYears ?? 10;
      state.visit = data.visit;
      state.loaded = true;
      if (!state.visit) {
        if (!state.sources) showMessage("noSource");
        else showMessage(state.busy ? "busy" : "empty");
        return;
      }
      if (shown === null || state.visit.id !== shown || layoutBefore !== state.s.Layout || langBefore !== state.lang) begin();
    } catch (error) {
      state.failures++;
      if (state.failures >= 2 && pluginBases.length > 1) baseIndex = (baseIndex + 1) % pluginBases.length;
      if (state.failures >= 4 && !state.loaded) showMessage("offline");
    }
  }

  poll();
  setInterval(() => { if (!state.visit || shown === null || state.failures) poll(); }, 5000);
  // Einstellungen (Ansicht, Sprache) auch während ein Jahr läuft übernehmen
  setInterval(() => { if (state.visit && shown) poll(); }, 30000);
})();
