# Fußball Live

Fußball Live zeigt die aktuellen Ergebnisse, den Spieltag und die Tabelle deiner Ligen auf dem Rahmen: 1. Bundesliga, 2. Bundesliga und Champions League sind voreingestellt, 3. Liga, DFB-Pokal, Europa League, Conference League, Premier League, LaLiga, Serie A und Ligue 1 lassen sich dazuschalten.

Fußball Live besteht aus zwei Teilen, die zusammen installiert werden:

- **Die Szene Fußball Live** zeichnet die Spiele und die Tabelle. Jede gewählte Liga ist eine eigene Seite; die Seiten wechseln im eingestellten Takt.
- **Das Plugin** liest die Ergebnisse, hält alle Einstellungen und legt die Szene nach Zeitplan über die laufende Playlist.

## Einrichten

1. Paket installieren (Plugins > Hochladen, oder über den Store).
2. Auf der Plugins-Seite bei Fußball Live **Allow takeover** einschalten. Ohne das kann Fußball Live die Playlist nicht kurz beiseiteschieben.
3. **Fußball Live öffnen** und Ligen, Takt und Anzeigedauer wählen. Alles wird sofort gespeichert.
4. Zum Ausprobieren **Anzeigen** drücken.

## Wie die Szene über die Playlist kommt

Es gibt drei Wege, und sie lassen sich kombinieren:

- **Regelmäßig (Takeover):** Unter *Regelmäßig über die Playlist legen* stellst du ein, **wann** (immer, nur an Spieltagen, nur wenn ein Spiel läuft, oder nie), **alle wie viele Minuten** und **für wie viele Sekunden**. Fußball Live bittet den Rahmen dann um den Bildschirm, zeigt die Szene und gibt den Bildschirm danach zurück; die Playlist läuft an der Stelle weiter, an der sie war. Mit **Von/Bis Uhr** bleibt es z. B. nachts ruhig. Ein ausgeschalteter Bildschirm wird nie geweckt.
- **Bei einem Tor:** Wenn eingeschaltet, kommt die Szene bei einem Tor sofort für die eingestellte Zeit, mit der Liga des Tores zuerst. Tore werden einmal pro Minute erkannt.
- **In einer Playlist:** Die Szene Fußball Live kann wie jedes Bild in eine Playlist; dann kommt sie in deren Reihenfolge dran (empfohlene Dauer 60 Sekunden). Mit *Eine Playlist dafür* legt das Plugin eine Playlist „Fußball Live“ für dich an.

Die Playlist **Fußball Live (takeover)** benutzt das Plugin selbst für die Übernahme. Lass sie ausgeschaltet; wird sie gelöscht, legt das Plugin sie neu an.

Tipp: Damit in einer Anzeige alle Ligen zu sehen sind, sollte *Für … Sekunden* mindestens *Ligen × Sekunden je Liga* sein. Die Plugin-Seite rechnet es dir vor.

## Was die Szene zeigt

- Kopf: Liga, Spieltag (bzw. Spieltermine), Anzahl der Live-Spiele, Uhrzeit und Stand der Daten.
- Je Spiel: Anstoß oder Spielminute, beide Vereine mit Wappen und das Ergebnis. Laufende Spiele sind rot markiert, mit dem letzten Torschützen, wenn die Quelle ihn kennt. Bei beendeten Bundesliga-Spielen steht der Halbzeitstand.
- Daneben (im Hochformat darunter) die Tabelle, mit den Vereinen, die gerade spielen, in Rot.
- Sehr viele Spiele (Champions League) werden zweispaltig gezeigt.

## Automationen

Aktionen: **Anzeigen**, **Beenden**, **Umschalten**, **Jetzt aktualisieren**.

Ereignisse:

- **fussball_tor** mit liga, heim, gast, stand, torschuetze.
- **fussball_anzeige_gestartet** mit grund (show, zeitplan, tor).
- **fussball_anzeige_beendet** mit grund (fertig, abgebrochen, verdraengt, abgelaufen, fehlgeschlagen, gestoppt).

Der Overlay-Dienst **Live-Stand** liefert eine Zeile mit den laufenden Spielen, sonst das nächste Spiel.

## Woher die Daten kommen

- **OpenLigaDB** (api.openligadb.de) für 1., 2. und 3. Liga: Spieltag, Ergebnisse, Torschützen, Tabelle. Gemeinschaftlich gepflegt und frei. Die Spielminute nennt OpenLigaDB nicht; sie wird aus der Anstoßzeit geschätzt.
- **ESPN** (site.api.espn.com) für Champions League und alle anderen Wettbewerbe, und als Ersatz, wenn OpenLigaDB nicht antwortet. Das ist die öffentliche Schnittstelle der ESPN-Webseite, ohne Konto, aber nicht offiziell dokumentiert.

Gelesen wird jede Minute, solange ein Spiel läuft oder bald anfängt, alle 10 Minuten an Spieltagen und sonst jede halbe Stunde. Vereinswappen werden einmal geladen und auf dem Rahmen gespeichert.

## Wenn etwas nicht stimmt

- **Die Szene kommt nicht von selbst.** Ist *Allow takeover* an? Die Plugin-Seite sagt unter Status, warum nicht (Bildschirm aus, anderes Plugin hat den Bildschirm, außerhalb der Uhrzeiten, kein Spieltag …).
- **Unten rechts steht „Plugin nicht erreichbar – Notbetrieb“.** Die Szene liest dann 1., 2. Bundesliga und Champions League selbst, ohne Tabellen der anderen Ligen. Prüfe, ob das Plugin läuft.
- **„Stand“ oben rechts ist gelb.** Die Daten sind älter als 15 Minuten, meist weil die Quelle oder das Internet nicht antwortet. Die Szene zeigt den letzten Stand weiter.
- **Nach der Anzeige läuft die Playlist nicht weiter.** Das ist ein bekannter Fehler des Rahmens bei einem Quick Mix; das Plugin versucht ihn selbst zu beheben. Mit einer gespeicherten Playlist passiert es nicht.
