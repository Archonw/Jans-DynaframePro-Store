"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/OnThisDay/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["PerYear", "PhotoSeconds", "FadeSeconds", "SummarySeconds", "DayWindow", "RefreshHours", "PlaylistSeconds"];
const CHECK_FIELDS = ["KenBurns", "ShowSummary", "ShowPlace", "AutoWiden", "ShowWeather"];
const SELECT_FIELDS = ["Layout", "YearOrder", "Units", "TodayAt"];
const BOOL_SELECTS = [];
let albums = null, albumError = "";
const TEXT_FIELDS = ["ServerUrl", "Folders"];
const KINDS = ["library", "playlist", "immich_album", "immich_all"];
const MAX_SOURCES = 6;
let current = null;
let editing = false;
let sources = [];
let rendered = "";
let pendingCommits = 0, lastEdit = 0, lastCommitDone = 0;
let commitChain = Promise.resolve();
let langChangedAt = 0;
const lists = { playlist: null, immich_album: null };
const listErrors = { playlist: "", immich_album: "" };

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["On This Day", "On This Day", "On This Day"],
  lede: ["Deine Fotos vom heutigen Tag aus früheren Jahren, als Zeitreise durch die Jahre. Zu jedem Foto steht das Wetter von damals an diesem Ort und das Wetter heute. Jede Änderung hier wird sofort gespeichert.",
    "Your photos of this day in earlier years, as a journey through time. Every photo shows the weather back then at that place and the weather today. Every change here is saved immediately.",
    "Tus fotos de este día en años anteriores, como un viaje en el tiempo. Cada foto muestra el tiempo que hacía entonces en ese lugar y el de hoy. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  todayTitle: ["Heute", "Today", "Hoy"],
  todayDate: ["Heute, {date}", "Today, {date}", "Hoy, {date}"],
  refresh: ["Fotos neu einlesen", "Read photos again", "Volver a leer las fotos"],
  playlist: ["Playlist anlegen", "Create playlist", "Crear lista"],
  factNow: ["Gerade", "Now", "Ahora"],
  factIndex: ["DynaFrame-Fotos mit Datum", "DynaFrame photos with a date", "Fotos de DynaFrame con fecha"],
  factRead: ["Zuletzt eingelesen", "Last read", "Última lectura"],
  factVersion: ["Version", "Version", "Versión"],
  nowBusy: ["Sucht Fotos …", "Looking for photos …", "Buscando fotos …"],
  nowList: ["Liest die Mediendatenbank …", "Reading the media library …", "Leyendo la biblioteca …"],
  nowExif: ["Liest Datum und Ort: {done} von {todo}", "Reading date and place: {done} of {todo}", "Leyendo fecha y lugar: {done} de {todo}"],
  nowIdle: ["Bereit", "Ready", "Listo"],
  dayLine: ["{photos} Fotos aus {years} Jahren", "{photos} photos from {years} years", "{photos} fotos de {years} años"],
  dayLine1: ["{photos} Fotos aus einem Jahr", "{photos} photos from one year", "{photos} fotos de un año"],
  dayWide: [" (± {n} Tage)", " (± {n} days)", " (± {n} días)"],
  dayNone: ["Für heute gibt es noch keine Fotos aus früheren Jahren.", "There are no photos of this day from earlier years yet.", "Todavía no hay fotos de este día de años anteriores."],
  dayNext: [" Die nächste Erinnerung: {date}.", " Next memory: {date}.", " Próximo recuerdo: {date}."],
  undated: ["{n} ohne Datum", "{n} without a date", "{n} sin fecha"],
  weatherError: ["Wetter (Open-Meteo) nicht erreichbar: {e}. Steht ein Werbeblocker wie Pi-hole dazwischen? Dann archive-api.open-meteo.com und api.open-meteo.com erlauben.",
    "Weather (Open-Meteo) cannot be reached: {e}. Is an ad blocker like Pi-hole in the way? Then allow archive-api.open-meteo.com and api.open-meteo.com.",
    "No se puede acceder al tiempo (Open-Meteo): {e}. ¿Hay un bloqueador como Pi-hole? Permite archive-api.open-meteo.com y api.open-meteo.com."],
  sourcesTitle: ["Fotos", "Photos", "Fotos"],
  sourcesHint: ["Woher die Fotos kommen. Mehrere Quellen werden zusammengelegt. Es zählen Fotos mit Aufnahmedatum; für das Wetter am Ort braucht das Foto GPS-Daten.",
    "Where the photos come from. Several sources are merged. Photos need a date taken; for the weather at the place they need GPS data.",
    "De dónde vienen las fotos. Varias fuentes se unen. Las fotos necesitan fecha de captura; para el tiempo del lugar necesitan datos GPS."],
  add: ["Quelle hinzufügen", "Add source", "Añadir fuente"],
  remove: ["Entfernen", "Remove", "Quitar"],
  kind: ["Fotos aus", "Photos from", "Fotos de"],
  kind_library: ["Allen Fotos in DynaFrame", "All photos in DynaFrame", "Todas las fotos de DynaFrame"],
  kind_playlist: ["Einer Playlist von DynaFrame", "A DynaFrame playlist", "Una lista de DynaFrame"],
  kind_immich_album: ["Einem Immich-Album", "An Immich album", "Un álbum de Immich"],
  kind_immich_all: ["Allen Fotos in Immich", "All photos in Immich", "Todas las fotos de Immich"],
  ref_playlist: ["Playlist", "Playlist", "Lista"],
  ref_immich_album: ["Album", "Album", "Álbum"],
  ref_none: ["Keine Auswahl nötig", "Nothing to pick", "Nada que elegir"],
  pick: ["Bitte wählen …", "Please pick …", "Elige …"],
  loading: ["Lädt …", "Loading …", "Cargando …"],
  label: ["Eigener Name (optional)", "Own name (optional)", "Nombre propio (opcional)"],
  srcBusy: ["Wird eingelesen …", "Reading …", "Leyendo …"],
  srcWait: ["Wartet auf das Einlesen …", "Waiting to be read …", "Esperando la lectura …"],
  srcOk: ["{dated} von {total} Fotos haben ein Datum, {located} einen Ort.", "{dated} of {total} photos have a date, {located} a location.", "{dated} de {total} fotos tienen fecha, {located} ubicación."],
  srcImmich: ["{n} Fotos um den heutigen Tag gefunden.", "{n} photos found around today's date.", "{n} fotos encontradas alrededor de hoy."],
  max: ["Mehr als sechs Quellen gehen nicht.", "No more than six sources.", "No caben más de seis fuentes."],
  showTitle: ["Anzeige", "Display", "Visualización"],
  layout: ["Ansicht", "View", "Vista"],
  layoutJourney: ["Zeitreise (ein Foto nach dem anderen)", "Time travel (one photo after another)", "Viaje en el tiempo (una foto tras otra)"],
  layoutWall: ["Nebeneinander (alle Jahre als Karten)", "Side by side (all years as cards)", "Lado a lado (todos los años como tarjetas)"],
  yearOrder: ["Reihenfolge der Jahre", "Order of the years", "Orden de los años"],
  orderOldest: ["Älteste zuerst", "Oldest first", "Primero los más antiguos"],
  orderNewest: ["Neueste zuerst", "Newest first", "Primero los más recientes"],
  perYear: ["Fotos je Jahr (höchstens)", "Photos per year (at most)", "Fotos por año (como máximo)"],
  photoSeconds: ["Jedes Foto zeigen für … Sekunden", "Show each photo for … seconds", "Mostrar cada foto … segundos"],
  fadeSeconds: ["Übergang (Sekunden)", "Transition (seconds)", "Transición (segundos)"],
  summarySeconds: ["Übersicht zeigen für … Sekunden", "Show the summary for … seconds", "Mostrar el resumen … segundos"],
  kenBurns: ["Langsam ins Foto zoomen", "Slow zoom into the photo", "Zoom lento en la foto"],
  showSummary: ["Übersicht nach dem letzten Jahr", "Summary after the last year", "Resumen tras el último año"],
  showPlace: ["Ort anzeigen", "Show the place", "Mostrar el lugar"],
  showHint: ["Je Jahr nimmt das Plugin Fotos, die über den Tag verteilt sind, und lässt Serienbilder weg; Favoriten aus Immich und Fotos mit Ort kommen zuerst. Die Übersicht zeigt ein Foto je Jahr, die Temperaturen der Jahre im Vergleich zu heute und ein paar Auffälligkeiten.",
    "For each year the plugin takes photos spread over the day and skips bursts; Immich favourites and photos with a location come first. The summary shows one photo per year, the temperatures of the years compared with today and a few highlights.",
    "Para cada año el plugin toma fotos repartidas a lo largo del día y omite las ráfagas; primero las favoritas de Immich y las fotos con ubicación. El resumen muestra una foto por año, las temperaturas comparadas con hoy y algunos datos curiosos."],
  daysTitle: ["Welche Tage", "Which days", "Qué días"],
  dayWindow: ["Auch Tage drumherum nehmen (± Tage)", "Also take days around it (± days)", "Incluir también días cercanos (± días)"],
  autoWiden: ["Gibt es an diesem Tag keine Fotos, ein paar Tage drumherum suchen", "If there are no photos on this day, look a few days around it", "Si no hay fotos ese día, buscar unos días alrededor"],
  daysHint: ["0 heißt: genau der heutige Tag. Mit „drumherum suchen“ geht das Plugin Tag für Tag weiter (bis ± 7), bis es Fotos findet. Am 28. Februar zählen in Nicht-Schaltjahren auch Fotos vom 29.",
    "0 means: exactly today's date. With “look around” the plugin widens day by day (up to ± 7) until it finds photos. On 28 February in non-leap years, photos from the 29th count too.",
    "0 significa: exactamente el día de hoy. Con «buscar alrededor» el plugin amplía día a día (hasta ± 7) hasta encontrar fotos. El 28 de febrero de los años no bisiestos cuentan también las fotos del 29."],
  weatherTitle: ["Wetter", "Weather", "Tiempo"],
  showWeather: ["Wetter anzeigen", "Show the weather", "Mostrar el tiempo"],
  units: ["Temperatur in", "Temperature in", "Temperatura en"],
  todayAt: ["Vergleichen mit dem Wetter heute", "Compare with today's weather", "Comparar con el tiempo de hoy"],
  todayHome: ["zu Hause", "at home", "en casa"],
  todayThere: ["am Ort des Fotos", "at the place of the photo", "en el lugar de la foto"],
  homeTitle: ["Dein Wohnort", "Your home town", "Tu ciudad"],
  homeSet: ["{name}: heute {t}, {text}", "{name}: today {t}, {text}", "{name}: hoy {t}, {text}"],
  homeSetNoWx: ["{name}", "{name}", "{name}"],
  homeClear: ["Entfernen", "Remove", "Quitar"],
  homeMissing: ["Noch kein Wohnort. Ohne ihn vergleicht die Szene mit dem Wetter heute am Ort des Fotos.", "No home town yet. Without it the scene compares with today's weather at the place of the photo.", "Aún no hay ciudad. Sin ella la escena compara con el tiempo de hoy en el lugar de la foto."],
  placeholderPlace: ["Ort oder Stadt", "Town or city", "Pueblo o ciudad"],
  search: ["Suchen", "Search", "Buscar"],
  searching: ["Sucht …", "Searching …", "Buscando …"],
  noPlaces: ["Nichts gefunden.", "Nothing found.", "No se ha encontrado nada."],
  weatherHint: ["Das Wetter kommt kostenlos und ohne Schlüssel von Open-Meteo: damals aus dem Wetterarchiv (ab 1940, für die Stunde und den Ort des Fotos), heute aus der Vorhersage. Fotos ohne GPS bekommen das Wetter vom Ort eines anderen Fotos dieses Tages, sonst das von deinem Wohnort. Ortsnamen kommen von OpenStreetMap.",
    "The weather comes free and without a key from Open-Meteo: back then from the weather archive (from 1940, for the hour and place of the photo), today from the forecast. Photos without GPS get the weather of another photo of that day, otherwise that of your home town. Place names come from OpenStreetMap.",
    "El tiempo viene gratis y sin clave de Open-Meteo: el de entonces del archivo meteorológico (desde 1940, para la hora y el lugar de la foto), el de hoy de la previsión. Las fotos sin GPS reciben el tiempo de otra foto de ese día o, si no, el de tu ciudad. Los nombres de lugares vienen de OpenStreetMap."],
  serverTitle: ["Immich-Server", "Immich server", "Servidor Immich"],
  serverHint: ["Nur nötig, wenn eine Quelle von Immich kommt. Das Plugin fragt Immich nur nach den Fotos um den heutigen Tag. Steht der Server schon in Immich Slideshow oder Growing Up, wird er übernommen.",
    "Only needed if a source comes from Immich. The plugin only asks Immich for the photos around today's date. If the server is already set in Immich Slideshow or Growing Up, it is taken from there.",
    "Solo hace falta si una fuente viene de Immich. El plugin solo pide a Immich las fotos alrededor de hoy. Si el servidor ya está en Immich Slideshow o Growing Up, se toma de ahí."],
  serverUrl: ["Adresse", "Address", "Dirección"],
  apiKey: ["API-Schlüssel", "API key", "Clave API"],
  test: ["Verbindung testen", "Test connection", "Probar conexión"],
  testing: ["Teste …", "Testing …", "Probando …"],
  keySaved: ["gespeichert (leer lassen zum Behalten)", "saved (leave empty to keep)", "guardada (déjala vacía para conservarla)"],
  keyMissing: ["noch keiner", "none yet", "ninguna todavía"],
  keyHow: ["So bekommst du einen API-Schlüssel", "How to get an API key", "Cómo conseguir una clave API"],
  keyHint: ["In Immich oben rechts auf dein Profilbild, dann <b>Kontoeinstellungen &gt; API-Schlüssel &gt; Neuer API-Schlüssel</b>. Als Berechtigung reichen <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code>, <code>person.read</code> und <code>tag.read</code>; mit <b>Alle</b> geht es auch. Der Schlüssel bleibt im Plugin auf dem Rahmen.",
    "In Immich click your profile picture at the top right, then <b>Account Settings &gt; API Keys &gt; New API Key</b>. The permissions <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code>, <code>person.read</code> and <code>tag.read</code> are enough; <b>All</b> works too. The key stays in the plugin on the frame.",
    "En Immich pulsa tu foto de perfil arriba a la derecha y luego <b>Configuración de la cuenta &gt; Claves API &gt; Nueva clave API</b>. Bastan los permisos <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code>, <code>person.read</code> y <code>tag.read</code>; con <b>Todos</b> también funciona. La clave se queda en el plugin del marco."],
  filterTitle: ["Welche Immich-Fotos verwendet werden", "Which Immich photos may be used", "Qué fotos de Immich se usan"],
  filterHint: ["Damit nichts Privates auf den Rahmen kommt: Für die Immich-Quellen nimmt das Plugin nur Fotos, die zu diesen Filtern passen. Nach einer Änderung verschwinden die gezeigten Fotos sofort und werden neu gesucht.",
    "So nothing private ends up on the frame: for the Immich sources the plugin only takes photos that match these filters. After a change the photos on show disappear right away and are looked up again.",
    "Para que no llegue nada privado al marco: en las fuentes de Immich el plugin solo toma fotos que cumplan estos filtros. Tras un cambio, las fotos mostradas desaparecen al instante y se vuelven a buscar."],
  albumsTitle: ["Alben", "Albums", "Álbumes"],
  albumsHint: ["Gilt für „Allen Fotos in Immich“. Keins angehakt: alle Fotos. Sonst nur Fotos aus den angehakten Alben (auch geteilte). Eine Quelle „Einem Immich-Album“ nimmt immer ihr Album; Sterne, Favoriten und Archiv gelten für beide.",
    "Applies to “All photos in Immich”. None ticked: all photos. Otherwise only photos from the ticked albums (shared ones too). A source “An Immich album” always takes its album; stars, favourites and archive apply to both.",
    "Se aplica a «Todas las fotos de Immich». Ninguno marcado: todas las fotos. Si no, solo fotos de los álbumes marcados (también compartidos). Una fuente «Un álbum de Immich» siempre usa su álbum; estrellas, favoritos y archivo se aplican a ambas."],
  albumFilter: ["Album suchen …", "Search album …", "Buscar álbum …"],
  noAlbums: ["In Immich gibt es keine Alben.", "There are no albums in Immich.", "No hay álbumes en Immich."],
  connectFirst: ["Erst den Immich-Server verbinden.", "Connect the Immich server first.", "Conecta primero el servidor Immich."],
  albumsChosen: ["{n} Alben ausgewählt", "{n} albums ticked", "{n} álbumes marcados"],
  albumChosen: ["1 Album ausgewählt", "1 album ticked", "1 álbum marcado"],
  minRating: ["Sterne", "Stars", "Estrellas"],
  ratingAny: ["Egal", "Any", "Da igual"],
  rating1: ["Mindestens 1 Stern", "At least 1 star", "Al menos 1 estrella"],
  rating2: ["Mindestens 2 Sterne", "At least 2 stars", "Al menos 2 estrellas"],
  rating3: ["Mindestens 3 Sterne", "At least 3 stars", "Al menos 3 estrellas"],
  rating4: ["Mindestens 4 Sterne", "At least 4 stars", "Al menos 4 estrellas"],
  rating5: ["5 Sterne", "5 stars", "5 estrellas"],
  favoritesOnly: ["Favoriten", "Favourites", "Favoritos"],
  favAll: ["Alle Fotos", "All photos", "Todas las fotos"],
  favOnly: ["Nur Favoriten", "Only favourites", "Solo favoritos"],
  archived: ["Archivierte Fotos", "Archived photos", "Fotos archivadas"],
  archNo: ["Weglassen", "Leave out", "Excluir"],
  archYes: ["Auch verwenden", "Use them too", "Usarlas también"],
  foldersTitle: ["Weitere Ordner auf dem Rahmen", "More folders on the frame", "Más carpetas en el marco"],
  foldersHint: ["Für „Alle Fotos in DynaFrame“: Das Plugin fragt DynaFrame nach seiner Mediendatenbank und den Medienordnern. Liegen Fotos woanders (z. B. ein eingehängtes NAS), trag die Ordner hier ein, einen pro Zeile.",
    "For “All photos in DynaFrame”: the plugin asks DynaFrame for its media database and media folders. If photos are somewhere else (e.g. a mounted NAS), enter those folders here, one per line.",
    "Para «Todas las fotos de DynaFrame»: el plugin pide a DynaFrame su base de datos y sus carpetas. Si hay fotos en otro sitio (p. ej. un NAS montado), escribe aquí esas carpetas, una por línea."],
  refreshHours: ["Neue Fotos suchen alle … Stunden", "Look for new photos every … hours", "Buscar fotos nuevas cada … horas"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la lista (segundos)"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status}).", "Error (HTTP {status}).", "Error (HTTP {status})."],
  oclock: ["{time} Uhr", "{time}", "{time}"],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „On This Day“ anlegen", "Create the playlist “On This Day”", "Crear la lista «On This Day»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistHint: ["Die Playlist enthält nur die Szene und ist eingeschaltet. Die Dauer gilt beim Anlegen; danach änderst du sie in der Playlist selbst. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist holds only the scene and is switched on. The duration applies when it is created; after that you change it in the playlist itself. You can also add the scene to any playlist yourself.",
    "La lista contiene solo la escena y está activada. La duración se aplica al crearla; después la cambias en la propia lista. También puedes añadir la escena a cualquier lista."],
  // Immich-Filter (wie Photo Mosaic)
  ifAlbumFilter: ["Album suchen …", "Search album …", "Buscar álbum …"],
  ifArchNo: ["Weglassen", "Leave out", "Excluir"],
  ifArchYes: ["Auch verwenden", "Use them too", "Usarlas también"],
  ifArchived: ["Archivierte Fotos", "Archived photos", "Fotos archivadas"],
  ifCameraOnly: ["Nur Fotos aus einer Kamera (ohne Screenshots und gespeicherte Bilder)", "Only photos taken with a camera (skips screenshots and saved images)", "Solo fotos de una cámara (sin capturas ni imágenes guardadas)"],
  ifCity: ["Stadt", "City", "Ciudad"],
  ifCountry: ["Land", "Country", "País"],
  ifDescription: ["Beschreibung enthält", "Description contains", "La descripción contiene"],
  ifFavAll: ["Alle Fotos", "All photos", "Todas las fotos"],
  ifFavOnly: ["Nur Favoriten", "Only favourites", "Solo favoritos"],
  ifFavoritesOnly: ["Favoriten", "Favourites", "Favoritos"],
  ifFileName: ["Dateiname enthält", "File name contains", "El nombre del archivo contiene"],
  ifGrpCamera: ["Kamera", "Camera", "Cámara"],
  ifGrpJunk: ["Aussortieren", "Skip the junk", "Descartar"],
  ifGrpSkip: ["Weglassen", "Leave out", "Excluir"],
  ifGrpText: ["Text", "Text", "Texto"],
  ifGrpWhat: ["Was", "What", "Qué"],
  ifGrpWhere: ["Wo", "Where", "Dónde"],
  ifGrpWho: ["Wer", "Who", "Quién"],
  ifLandscape: ["Querformat", "Landscape", "Horizontal"],
  ifLens: ["Objektiv", "Lens", "Objetivo"],
  ifMake: ["Hersteller", "Make", "Marca"],
  ifMinFileKB: ["Mindestens … KB Dateigröße", "File size at least … KB", "Tamaño de archivo de al menos … KB"],
  ifMinMegapixels: ["Mindestens … Megapixel", "At least … megapixels", "Al menos … megapíxeles"],
  ifMinRating: ["Sterne", "Stars", "Estrellas"],
  ifModel: ["Modell", "Model", "Modelo"],
  ifNoScreenshots: ["Dateinamen weglassen, die nach Bildschirmfoto aussehen", "Skip file names that look like screenshots", "Omitir nombres de archivo que parecen capturas"],
  ifNotInAlbum: ["Nur Fotos, die in keinem Album sind", "Only photos that are not in any album", "Solo fotos que no están en ningún álbum"],
  ifOcrText: ["Text im Bild enthält", "Text in the image contains", "El texto de la imagen contiene"],
  ifOrientation: ["Ausrichtung", "Orientation", "Orientación"],
  ifPeopleFilter: ["Person suchen …", "Search person …", "Buscar persona …"],
  ifPeopleHint: ["Keine angehakt: egal wer. Sonst nur Fotos, auf denen mindestens eine dieser Personen ist (aus der Gesichtserkennung von Immich).", "None ticked: anyone. Otherwise only photos with at least one of these people (from Immich's face recognition).", "Ninguna marcada: cualquiera. Si no, solo fotos con al menos una de estas personas (del reconocimiento facial de Immich)."],
  ifPortrait: ["Hochformat", "Portrait", "Vertical"],
  ifRating1: ["Mindestens 1 Stern", "At least 1 star", "Al menos 1 estrella"],
  ifRating2: ["Mindestens 2 Sterne", "At least 2 stars", "Al menos 2 estrellas"],
  ifRating3: ["Mindestens 3 Sterne", "At least 3 stars", "Al menos 3 estrellas"],
  ifRating4: ["Mindestens 4 Sterne", "At least 4 stars", "Al menos 4 estrellas"],
  ifRating5: ["5 Sterne", "5 stars", "5 estrellas"],
  ifRatingAny: ["Egal", "Any", "Da igual"],
  ifSkipAlbums: ["Alben weglassen", "Albums to leave out", "Álbumes a excluir"],
  ifSkipHint: ["Ein weggelassenes Album lässt alles darin weg, auch wenn es woanders noch vorkommt.", "Leaving out an album leaves out everything in it, wherever else it turns up.", "Excluir un álbum excluye todo lo que contiene, aunque aparezca en otro sitio."],
  ifSkipNames: ["Dateinamen weglassen (mit Komma getrennt)", "File names to leave out (separate with commas)", "Nombres de archivo a excluir (separados por comas)"],
  ifSkipTags: ["Tags weglassen", "Tags to leave out", "Etiquetas a excluir"],
  ifSquareShape: ["Quadratisch", "Square", "Cuadrada"],
  ifState: ["Bundesland", "State or province", "Estado o provincia"],
  ifTagFilter: ["Tag suchen …", "Search tag …", "Buscar etiqueta …"],
  ifWithPeople: ["Nur Fotos mit Personen", "Only photos with people in them", "Solo fotos con personas"],
  ifNothingHere: ["Keine gefunden.", "None found.", "No se encontró ninguno."],
  ifOneChosen: ["1 ausgewählt", "1 ticked", "1 marcado"],
  ifManyChosen: ["{n} ausgewählt", "{n} ticked", "{n} marcados"],
  ifLoading: ["Lädt …", "Loading …", "Cargando …"],
  // DynaFrame-Filter (wie Photo Mosaic)
  dfTitle: ["Welche Fotos aus DynaFrame", "Which photos from DynaFrame", "Qué fotos de DynaFrame"],
  dfHint: ["Gilt für Fotos aus DynaFrame (alle Fotos, Ordner, Playlists). Die Daten liest DynaFrame selbst aus den Fotos (EXIF, auch Sterne aus .xmp-Dateien daneben). Fotos, die DynaFrame nicht in seiner Mediendatenbank hat, fallen weg, sobald ein Filter gesetzt ist.", "Applies to photos from DynaFrame (all photos, folders, playlists). DynaFrame reads the data from the photos itself (EXIF, also stars from .xmp files next to them). Photos that are not in DynaFrame's media database are left out as soon as a filter is set.", "Se aplica a las fotos de DynaFrame (todas las fotos, carpetas, listas). DynaFrame lee los datos de las propias fotos (EXIF, también las estrellas de archivos .xmp al lado). Las fotos que no están en la base de datos de DynaFrame se omiten en cuanto hay un filtro."],
  dfCount: ["{n} von {m} Fotos aus DynaFrame passen zu den Filtern.", "{n} of {m} photos from DynaFrame match the filters.", "{n} de {m} fotos de DynaFrame cumplen los filtros."],
  dfCameraOnly: ["Nur Fotos aus einer Kamera (ohne Screenshots und gespeicherte Bilder)", "Only photos taken with a camera (skips screenshots and saved images)", "Solo fotos de una cámara (sin capturas ni imágenes guardadas)"],
  dfPlace: ["Ort enthält", "Place contains", "El lugar contiene"],
  dfText: ["Titel, Beschreibung oder Tags enthalten", "Title, description or tags contain", "Título, descripción o etiquetas contienen"],
  dfFileName: ["Dateiname enthält", "File name contains", "El nombre del archivo contiene"],
  dfGrpCamera: ["Kamera", "Camera", "Cámara"],
  dfGrpJunk: ["Aussortieren", "Skip the junk", "Descartar"],
  dfGrpText: ["Text", "Text", "Texto"],
  dfGrpWhat: ["Was", "What", "Qué"],
  dfGrpWhere: ["Wo", "Where", "Dónde"],
  dfLandscape: ["Querformat", "Landscape", "Horizontal"],
  dfLens: ["Objektiv", "Lens", "Objetivo"],
  dfMake: ["Hersteller", "Make", "Marca"],
  dfMinMegapixels: ["Mindestens … Megapixel", "At least … megapixels", "Al menos … megapíxeles"],
  dfMinRating: ["Sterne", "Stars", "Estrellas"],
  dfModel: ["Modell", "Model", "Modelo"],
  dfNoScreenshots: ["Dateinamen weglassen, die nach Bildschirmfoto aussehen", "Skip file names that look like screenshots", "Omitir nombres de archivo que parecen capturas"],
  dfOrientation: ["Ausrichtung", "Orientation", "Orientación"],
  dfPortrait: ["Hochformat", "Portrait", "Vertical"],
  dfRating1: ["Mindestens 1 Stern", "At least 1 star", "Al menos 1 estrella"],
  dfRating2: ["Mindestens 2 Sterne", "At least 2 stars", "Al menos 2 estrellas"],
  dfRating3: ["Mindestens 3 Sterne", "At least 3 stars", "Al menos 3 estrellas"],
  dfRating4: ["Mindestens 4 Sterne", "At least 4 stars", "Al menos 4 estrellas"],
  dfRating5: ["5 Sterne", "5 stars", "5 estrellas"],
  dfRatingAny: ["Egal", "Any", "Da igual"],
  dfSkipNames: ["Dateinamen weglassen (mit Komma getrennt)", "File names to leave out (separate with commas)", "Nombres de archivo a excluir (separados por comas)"],
  dfSquareShape: ["Quadratisch", "Square", "Cuadrada"],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
  wx: [
    ["Sonnig", "Heiter", "Teils bewölkt", "Bedeckt", "Nebel", "Niesel", "Regen", "Schnee", "Schauer", "Gewitter"],
    ["Sunny", "Mostly clear", "Partly cloudy", "Overcast", "Fog", "Drizzle", "Rain", "Snow", "Showers", "Thunderstorm"],
    ["Soleado", "Poco nuboso", "Parcialmente nuboso", "Cubierto", "Niebla", "Llovizna", "Lluvia", "Nieve", "Chubascos", "Tormenta"]],
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "";

const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[1]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "en";
  if (chosen === lang && document.documentElement.dataset.applied === chosen) return;
  lang = chosen;
  document.documentElement.dataset.applied = lang;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  rendered = "";
  if (current) render(current);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(epoch) {
  if (!epoch) return "—";
  const date = new Date(epoch * 1000);
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang]);
const fmtDate = (iso) => iso ? new Date(`${iso}T12:00:00`).toLocaleDateString(LOCALES[lang], { day: "numeric", month: "short", year: "numeric" }) : "";

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

// ------------------------------------------------------------ Quellen

async function loadList(kind, force = false) {
  if (lists[kind] && !force) return;
  lists[kind] = lists[kind] || [];
  try {
    const result = await api(kind === "playlist" ? "./api/playlists" : "./api/albums");
    lists[kind] = kind === "playlist" ? result.playlists : result.albums;
    listErrors[kind] = "";
  } catch (error) {
    listErrors[kind] = error.message;
    lists[kind] = [];
  }
  rendered = "";
  renderSources();
}

// Änderungen nacheinander speichern; eine Antwort von vorher darf die Auswahl nicht zurückdrehen.
function commit() {
  lastEdit = Date.now();
  pendingCommits++;
  const snapshot = JSON.parse(JSON.stringify(sources));
  commitChain = commitChain.then(async () => {
    try {
      await api("./api/settings", { method: "POST", body: JSON.stringify({ Sources: snapshot }) });
      setStatus(t("saved"), "ok", "sourcesNote");
    } catch (error) {
      setStatus(error.message, "bad", "sourcesNote");
    } finally {
      pendingCommits--;
      lastCommitDone = Date.now();
    }
  });
  commitChain.then(() => { if (!pendingCommits) refresh(); });
}

const needsRef = (kind) => kind === "playlist" || kind === "immich_album";

function statusText(src) {
  const row = (current && current.status[src.id]) || {};
  if (row.state === "busy") return [t("srcBusy"), ""];
  if (row.state === "wait") return [t("srcWait"), ""];
  if (row.state === "error") return [row.error || "?", "bad"];
  if (row.state === "ok" && String(row.kind || src.kind).startsWith("immich")) return [t("srcImmich", { n: fmt(row.total) }), "ok"];
  if (row.state === "ok") return [t("srcOk", { dated: fmt(row.dated), total: fmt(row.total), located: fmt(row.located) }), "ok"];
  return ["", ""];
}

function fillRef(select, src) {
  const kind = src.kind;
  select.replaceChildren();
  if (!needsRef(kind)) {
    select.disabled = true;
    select.append(new Option(t("ref_none"), ""));
    return;
  }
  select.disabled = false;
  const list = lists[kind];
  if (list === null) {
    select.append(new Option(t("loading"), ""));
    loadList(kind);
    return;
  }
  select.append(new Option(listErrors[kind] || t("pick"), ""));
  for (const row of list) {
    const count = row.count ? ` (${fmt(row.count)})` : "";
    select.append(new Option(`${row.name}${count}`, String(row.id)));
  }
  if (src.ref && !list.some((row) => String(row.id) === src.ref)) select.append(new Option(src.name || src.ref, src.ref));
  select.value = src.ref || "";
}

function renderSources() {
  const key = JSON.stringify([lang, sources.map((s) => [s.id, s.kind]), lists.playlist?.length, lists.immich_album?.length, listErrors]);
  const box = el("sources");
  if (key !== rendered) {
    rendered = key;
    box.replaceChildren();
    sources.forEach((src, index) => {
      const row = document.createElement("div");
      row.className = "source";
      row.dataset.id = src.id;

      const kindField = document.createElement("label");
      kindField.className = "field";
      kindField.innerHTML = `<span>${t("kind")}</span>`;
      const kind = document.createElement("select");
      for (const k of KINDS) kind.append(new Option(t(`kind_${k}`), k));
      kind.value = src.kind;
      kind.addEventListener("change", () => {
        src.kind = kind.value;
        src.ref = "";
        commit();
        renderSources();
      });
      kindField.append(kind);

      const refField = document.createElement("label");
      refField.className = "field";
      refField.innerHTML = `<span>${needsRef(src.kind) ? t(`ref_${src.kind}`) : "&nbsp;"}</span>`;
      const ref = document.createElement("select");
      fillRef(ref, src);
      ref.addEventListener("change", () => {
        src.ref = ref.value;
        commit();
      });
      refField.append(ref);

      const nameField = document.createElement("label");
      nameField.className = "field";
      nameField.innerHTML = `<span>${t("label")}</span>`;
      const name = document.createElement("input");
      name.type = "text";
      name.maxLength = 60;
      name.value = src.name || "";
      name.addEventListener("focus", () => { editing = true; });
      name.addEventListener("blur", () => { editing = false; });
      name.addEventListener("change", () => {
        src.name = name.value;
        commit();
      });
      nameField.append(name);

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "secondary remove";
      remove.textContent = t("remove");
      remove.disabled = sources.length <= 1;
      remove.addEventListener("click", () => {
        sources.splice(index, 1);
        commit();
        renderSources();
      });

      const meta = document.createElement("p");
      meta.className = "meta";
      row.append(kindField, refField, nameField, remove, meta);
      box.append(row);
    });
  }
  for (const src of sources) {
    const meta = box.querySelector(`.source[data-id="${src.id}"] .meta`);
    if (!meta) continue;
    const [text, tone] = statusText(src);
    meta.textContent = text;
    meta.className = `meta${tone ? " " + tone : ""}`;
  }
  el("addSource").disabled = sources.length >= MAX_SOURCES;
}

el("addSource").addEventListener("click", () => {
  if (sources.length >= MAX_SOURCES) { setStatus(t("max"), "bad", "sourcesNote"); return; }
  const used = new Set(sources.map((s) => s.id));
  let n = 1;
  while (used.has(`s${n}`)) n++;
  sources.push({ id: `s${n}`, kind: "playlist", ref: "", name: "" });
  commit();
  renderSources();
});

// ------------------------------------------------------------ Stand

function wxText(code) {
  code = Number(code) || 0;
  const row = I18N.wx[LANGS.indexOf(lang)] || I18N.wx[1];
  const i = code === 0 ? 0 : code === 1 ? 1 : code === 2 ? 2 : code === 3 ? 3 : code < 50 ? 4 : code < 60 ? 5
    : code < 70 ? 6 : code < 80 ? 7 : code < 90 ? 8 : 9;
  return row[i];
}

function temp(c) {
  if (c === null || c === undefined) return "–";
  const f = current && current.settings.Units === "f";
  return `${Math.round(f ? c * 9 / 5 + 32 : c)}°`;
}

function renderToday(state) {
  const date = state.date ? new Date(`${state.date}T12:00:00`).toLocaleDateString(LOCALES[lang], { day: "numeric", month: "long" }) : "";
  el("todayTitle").textContent = date ? t("todayDate", { date }) : t("todayTitle");
  let line;
  if (state.years) {
    line = (state.years === 1 ? t("dayLine1", { photos: fmt(state.photos) }) : t("dayLine", { photos: fmt(state.photos), years: fmt(state.years) }))
      + (state.window ? t("dayWide", { n: state.window }) : "");
  } else if (!state.busy) {
    line = t("dayNone") + (state.next ? t("dayNext", { date: new Date(`${state.next}T12:00:00`).toLocaleDateString(LOCALES[lang], { day: "numeric", month: "long" }) }) : "");
  } else line = t("nowBusy");
  el("todayLine").textContent = line;
  const key = JSON.stringify([state.ver, lang, state.settings.Units, state.preview]);
  const box = el("preview");
  if (box.dataset.key !== key) {
    box.dataset.key = key;
    box.innerHTML = (state.preview || []).map((p) => `<figure><img loading="lazy" src="./api/photo?i=${p.i}&v=${state.ver}" alt="">
      <figcaption><b>${p.y}</b>${p.t !== null && p.t !== undefined ? ` · ${temp(p.t)} ${esc(wxText(p.code))}` : ""}<span>${esc(p.place || "")}</span></figcaption></figure>`).join("");
  }
}

function renderHome(state) {
  const s = state.settings;
  const box = el("homeNow");
  if (s.HomeLat === null || s.HomeLat === undefined) {
    box.textContent = t("homeMissing");
    return;
  }
  const w = state.home;
  const text = w ? t("homeSet", { name: s.HomeName || `${s.HomeLat}, ${s.HomeLon}`, t: temp(w.t), text: wxText(w.code) })
    : t("homeSetNoWx", { name: s.HomeName || `${s.HomeLat}, ${s.HomeLon}` });
  const key = JSON.stringify([text, lang]);
  if (box.dataset.key === key) return;
  box.dataset.key = key;
  box.innerHTML = `<b>${esc(text)}</b><button type="button" class="secondary clear" id="homeClear">${esc(t("homeClear"))}</button>`;
  el("homeClear").addEventListener("click", () => save({ HomeName: "", HomeLat: "", HomeLon: "" }));
}

function render(state, started = 0) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  // Eine eben gewählte Sprache nicht von einer älteren Antwort zurückdrehen lassen.
  if (Date.now() - langChangedAt > 6000 || s.Language === lang) applyLanguage(s.Language);
  const progress = state.progress || {};
  let now = t("nowIdle");
  if (state.busy) {
    now = progress.phase === "exif" && progress.todo ? t("nowExif", { done: fmt(progress.done), todo: fmt(progress.todo) })
      : progress.phase === "list" ? t("nowList") : t("nowBusy");
  }
  el("factNow").textContent = now;
  el("progress").hidden = !(state.busy && progress.phase === "exif" && progress.todo);
  el("progressBar").style.width = progress.todo ? `${(progress.done / progress.todo) * 100}%` : "0";
  el("factIndex").textContent = state.indexed || state.undated ? `${fmt(state.indexed)}${state.undated ? " · " + t("undated", { n: fmt(state.undated) }) : ""}` : "—";
  el("factRead").textContent = clock(state.indexAt);
  el("factVersion").textContent = state.version;
  if (document.activeElement !== el("MakePlaylist")) el("MakePlaylist").value = String(Boolean(state.settings.MakePlaylist));
  el("playlistNote").textContent = state.ownPlaylist || "";
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[On This Day ${state.version}] `);
  renderToday(state);
  renderHome(state);
  if (state.weatherError && s.ShowWeather) setStatus(t("weatherError", { e: state.weatherError }), "bad", "placeNote");
  else if (el("placeNote").classList.contains("bad") && el("placeNote").textContent.startsWith(t("weatherError", { e: "" }).slice(0, 12))) setStatus("", "", "placeNote");

  if (!editing) {
    for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) el(name).value = String(s[name]);
    for (const name of BOOL_SELECTS) el(name).value = String(Boolean(s[name]));
    el("Language").value = lang;
    if (document.activeElement !== el("ApiKey")) {
      el("ApiKey").placeholder = state.secretsSet.ApiKey ? t("keySaved") : t("keyMissing");
    }
    if (!pendingCommits && started > lastCommitDone && started > lastEdit &&
        JSON.stringify(s.Sources) !== JSON.stringify(sources)) {
      sources = JSON.parse(JSON.stringify(s.Sources));
      rendered = "";
    }
  }
  el("SummarySeconds").disabled = !s.ShowSummary;
  for (const name of ["Units", "TodayAt"]) el(name).disabled = !s.ShowWeather;
  renderSources();
  if (albums === null && s.ServerUrl && state.secretsSet.ApiKey) loadAlbums();
  renderAlbums();
  ifRender(s);
  dfRender(s, state);
}

// ------------------------------------------------------------ Immich-Alben (Filter)

async function loadAlbums() {
  if (!current || !current.settings.ServerUrl || !current.secretsSet.ApiKey) {
    albums = [];
    albumError = t("connectFirst");
  } else {
    albums = albums || [];
    try {
      albums = (await api("./api/albums")).albums || [];
      albumError = albums.length ? "" : t("noAlbums");
    } catch (error) {
      albums = [];
      albumError = error.message;
    }
  }
  renderAlbums();
}

function renderAlbums() {
  if (!current) return;
  const chosen = new Set(current.settings.Albums || []);
  const query = el("albumFilter").value.trim().toLowerCase();
  const list = albums || [];
  // Angehakte Alben zuerst, damit sie in einer langen Liste sichtbar bleiben.
  const rows = list.filter((a) => !query || a.name.toLowerCase().includes(query))
    .sort((a, b) => (chosen.has(b.id) - chosen.has(a.id)) || a.name.localeCompare(b.name));
  const html = rows.map((a) => `<label><input type="checkbox" value="${esc(a.id)}" ${chosen.has(a.id) ? "checked" : ""}>
      <span>${esc(a.name)}</span><small>${fmt(a.count)}</small></label>`).join("");
  const box = el("albumList");
  if (box.dataset.html !== html) { box.innerHTML = html; box.dataset.html = html; }
  const error = albums !== null && albumError;
  const note = error || (chosen.size === 1 ? t("albumChosen") : chosen.size ? t("albumsChosen", { n: chosen.size }) : "");
  setStatus(note, error ? "bad" : "", "albumNote");
}

el("albumFilter").addEventListener("input", renderAlbums);
el("albumList").addEventListener("change", () => {
  const ticked = [...el("albumList").querySelectorAll("input:checked")].map((box) => box.value);
  // Angehakte Alben behalten, die der Suchfilter gerade ausblendet.
  const hidden = (current.settings.Albums || []).filter((id) => !el("albumList").querySelector(`input[value="${id}"]`));
  const next = [...hidden, ...ticked];
  current.settings.Albums = next;
  save({ Albums: next });
});
for (const name of BOOL_SELECTS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value === "true" }));

async function refresh() {
  try {
    const started = Date.now();
    render(await api("./api/state"), started);
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS, ["ApiKey", "placeQuery", "albumFilter"])) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
}
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: name === "MinRating" ? Number(e.target.value) : e.target.value }));
el("Folders").addEventListener("change", (e) => save({ Folders: e.target.value }));
el("Language").addEventListener("change", (e) => {
  const chosen = e.target.value;
  langChangedAt = Date.now();
  if (current) current.settings.Language = chosen;
  applyLanguage(chosen);
  save({ Language: chosen });
});

// ------------------------------------------------------------ Wohnort

async function searchPlace() {
  const q = el("placeQuery").value.trim();
  if (q.length < 2) return;
  setStatus(t("searching"), "busy", "placeNote");
  try {
    const result = await api(`./api/places?q=${encodeURIComponent(q)}`);
    const box = el("places");
    box.replaceChildren();
    if (!result.places.length) { setStatus(t("noPlaces"), "bad", "placeNote"); return; }
    setStatus("", "", "placeNote");
    for (const place of result.places) {
      const button = document.createElement("button");
      button.type = "button";
      button.innerHTML = `${esc(place.name)}<small>${esc(place.region)}</small>`;
      button.addEventListener("click", async () => {
        box.replaceChildren();
        el("placeQuery").value = "";
        await save({ HomeName: [place.name, place.region.split(", ").pop()].filter(Boolean).join(", "), HomeLat: place.lat, HomeLon: place.lon });
        setTimeout(refresh, 2500);
      });
      box.append(button);
    }
  } catch (error) {
    setStatus(error.message, "bad", "placeNote");
  }
}
el("placeSearch").addEventListener("click", searchPlace);
el("placeQuery").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); searchPlace(); } });

// ------------------------------------------------------------ Immich, Knöpfe

async function saveServer() {
  const changes = { ServerUrl: el("ServerUrl").value };
  const key = el("ApiKey").value.trim();
  if (key) changes.ApiKey = key;
  const changed = await save(changes);
  el("ApiKey").value = "";
  if (changed.includes("ServerUrl") || changed.includes("ApiKey")) await testConnection();
}

async function testConnection() {
  setStatus(t("testing"), "busy", "testNote");
  try {
    const result = await api("./api/test", { method: "POST" });
    setStatus(result.message, result.ok ? "ok" : "bad", "testNote");
    if (result.ok) { loadList("immich_album", true); loadAlbums(); }
  } catch (error) {
    setStatus(error.message, "bad", "testNote");
  }
}

el("ServerUrl").addEventListener("change", saveServer);
el("ApiKey").addEventListener("change", saveServer);
el("testButton").addEventListener("click", async () => {
  if (el("ApiKey").value.trim() || el("ServerUrl").value !== (current?.settings.ServerUrl || "")) await saveServer();
  else await testConnection();
});
el("refreshButton").addEventListener("click", async () => {
  try {
    const result = await api("./api/refresh", { method: "POST" });
    setStatus(result.message || "", "busy");
    setTimeout(refresh, 1500);
  } catch (error) {
    setStatus(error.message, "bad");
  }
});
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));

applyLanguage("en");
refresh();
setInterval(refresh, 4000);

// ------------------------------------------------------------ Immich-Filter (wie Photo Mosaic, immich_filters.py)

const IF_TEXT = ["City", "State", "Country", "TakenAfter", "TakenBefore", "Make", "Model", "Lens", "Description", "OcrText", "FileName", "SkipNames"];
const IF_NUMBER = ["LastDays", "MinMegapixels", "MinFileKB"];
const IF_CHECK = ["OnThisDay", "WithPeople", "CameraOnly", "NoScreenshots", "NotInAlbum"];
const IF_BOOL_SELECT = ["FavoritesOnly", "IncludeArchived"];
const IF_PICKERS = { People: ["./api/people", "people"], SkipAlbums: ["./api/albums", "albums"], SkipTags: ["./api/tags", "tags"] };
const ifLists = {};
const ifErrors = {};
const ifEsc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const ifHere = (names) => names.filter((name) => el(name));
let ifSettings = null;

async function ifLoad(name, force = false) {
  if (ifLists[name] && !force) return;
  ifLists[name] = ifLists[name] || [];
  try {
    const result = await api(IF_PICKERS[name][0]);
    if (result.success === false) throw new Error(result.error || "?");
    ifLists[name] = result[IF_PICKERS[name][1]] || [];
    ifErrors[name] = "";
  } catch (error) {
    ifLists[name] = [];
    ifErrors[name] = error.message;
  }
  ifLists[name].loaded = true;
  if (ifSettings) ifRenderPickers(ifSettings);
}

function ifRenderPickers(s) {
  for (const name of Object.keys(IF_PICKERS)) {
    const box = el(name + "List");
    if (!box) continue;
    const items = ifLists[name];
    if (!items || !items.loaded) {
      if (s.ServerUrl && !items) ifLoad(name);
      if (!items) box.innerHTML = s.ServerUrl ? `<p class="hint">${ifEsc(t("ifLoading"))}</p>` : "";
      continue;
    }
    const chosen = new Set((s[name] || "").split(",").filter(Boolean));
    const query = el(name + "Filter").value.trim().toLowerCase();
    // Lange Listen: angehakte und gesuchte zuerst, höchstens 200 zeigen
    const rows = items.filter((a) => chosen.has(String(a.id)) || !query || String(a.name).toLowerCase().includes(query))
      .sort((a, b) => (chosen.has(String(b.id)) - chosen.has(String(a.id))) || String(a.name).localeCompare(String(b.name)))
      .slice(0, Math.max(200, chosen.size));
    const html = rows.map((a) => `<label title="${ifEsc(a.name)}"><input type="checkbox" value="${ifEsc(String(a.id))}" ${chosen.has(String(a.id)) ? "checked" : ""}>
        <span class="name">${ifEsc(a.name)}</span>${a.count != null ? `<span class="count">${fmt(a.count)}</span>` : ""}</label>`).join("");
    if (box.dataset.html !== html) { box.innerHTML = html; box.dataset.html = html; }
    const note = el(name + "Note");
    note.textContent = ifErrors[name] || (!items.length ? t("ifNothingHere") : chosen.size ? t(chosen.size === 1 ? "ifOneChosen" : "ifManyChosen", { n: chosen.size }) : "");
    note.className = "status" + (ifErrors[name] ? " bad" : "");
  }
}

function ifRender(s) {
  if (!el("immichFilters")) return;
  if (ifSettings && ifSettings.ServerUrl !== s.ServerUrl) {
    for (const name of Object.keys(ifLists)) delete ifLists[name];
  }
  ifSettings = s;
  for (const name of ifHere(IF_TEXT.concat(IF_NUMBER))) {
    if (document.activeElement !== el(name)) el(name).value = s[name] ?? "";
  }
  for (const name of ifHere(IF_CHECK)) el(name).checked = Boolean(s[name]);
  for (const name of ifHere(IF_BOOL_SELECT)) el(name).value = String(Boolean(s[name]));
  if (el("MinRating")) el("MinRating").value = String(s.MinRating || 0);
  if (el("Orientation")) el("Orientation").value = s.Orientation || "any";
  ifRenderPickers(s);
}

for (const name of ifHere(IF_TEXT)) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of ifHere(IF_NUMBER)) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) || 0 }));
for (const name of ifHere(IF_CHECK)) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of ifHere(IF_BOOL_SELECT)) el(name).addEventListener("change", (e) => save({ [name]: e.target.value === "true" }));
if (el("MinRating")) el("MinRating").addEventListener("change", (e) => save({ MinRating: Number(e.target.value) }));
if (el("Orientation")) el("Orientation").addEventListener("change", (e) => save({ Orientation: e.target.value }));
for (const name of Object.keys(IF_PICKERS)) {
  if (!el(name + "List")) continue;
  el(name + "Filter").addEventListener("input", () => ifSettings && ifRenderPickers(ifSettings));
  el(name + "List").addEventListener("change", () => {
    const list = el(name + "List");
    const ticked = [...list.querySelectorAll("input:checked")].map((box) => box.value);
    // Angehakte behalten, die der Suchfilter gerade ausblendet
    const hidden = (ifSettings[name] || "").split(",").filter(Boolean)
      .filter((id) => !list.querySelector(`input[value="${CSS.escape(id)}"]`));
    save({ [name]: [...hidden, ...ticked].join(",") });
  });
}
// ------------------------------------------------------------ DynaFrame-Filter (wie Photo Mosaic, dynaframe_filters.py)

const DF_TEXT = ["DfAfter", "DfBefore", "DfPlace", "DfMake", "DfModel", "DfLens", "DfText", "DfFileName", "DfSkipNames"];
const DF_NUMBER = ["DfLastDays", "DfMinMegapixels"];
const DF_CHECK = ["DfOnThisDay", "DfCameraOnly", "DfNoScreenshots"];
const dfHere = (names) => names.filter((name) => el(name));

// render(): dfRender(state.settings, state) aufrufen
function dfRender(s, state) {
  if (!el("dynaframeFilters")) return;
  for (const name of dfHere(DF_TEXT.concat(DF_NUMBER))) {
    if (document.activeElement !== el(name)) el(name).value = s[name] || (DF_NUMBER.includes(name) ? 0 : "");
  }
  for (const name of dfHere(DF_CHECK)) el(name).checked = Boolean(s[name]);
  if (el("DfMinRating")) el("DfMinRating").value = String(s.DfMinRating || 0);
  if (el("DfOrientation")) el("DfOrientation").value = s.DfOrientation || "any";
  const note = el("dfNote");
  const count = state && state.dfCount;
  if (note) {
    note.textContent = count && count.total ? t("dfCount", { n: fmt(count.kept), m: fmt(count.total) }) : "";
    note.className = "status" + (count && count.total && !count.kept ? " bad" : "");
  }
}

for (const name of dfHere(DF_TEXT)) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of dfHere(DF_NUMBER)) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) || 0 }));
for (const name of dfHere(DF_CHECK)) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
if (el("DfMinRating")) el("DfMinRating").addEventListener("change", (e) => save({ DfMinRating: Number(e.target.value) }));
if (el("DfOrientation")) el("DfOrientation").addEventListener("change", (e) => save({ DfOrientation: e.target.value }));

// ---- accordion:start
// ------------------------------------------------------------ Aufklappen (tools/plugin-vorlage/accordion)
// Karten und Abschnitte auf- und zuklappen, damit lange Plugin-Seiten übersichtlich
// bleiben. Gesteuert nur über Attribute im HTML (Anleitung: accordion/README.md):
//   <section class="card" data-fold="immich" data-fold-when="uses:immich"> …
//   <h3 class="sub" data-fold="immichFilter" data-fold-start="closed" data-fold-badge="count">
// Eigene Texte (DE/EN/ES) stehen hier, die Sprache kommt aus <html lang>.
(() => {
  const TEXT = {
    open: ["Aufklappen", "Expand", "Desplegar"],
    close: ["Zuklappen", "Collapse", "Plegar"],
    active: ["{n} aktiv", "{n} active", "{n} activos"],
    none: ["Keine Filter", "No filters", "Sin filtros"],
    set: ["Eingerichtet", "Set up", "Configurado"],
    optional: ["Optional", "Optional", "Opcional"],
    lines: ["{n} eingetragen", "{n} entered", "{n} introducidos"],
    svcOk: ["Alles erreichbar", "All reachable", "Todo accesible"],
    svcBad: ["{n} Problem", "{n} problem", "{n} problema"],
    svcBads: ["{n} Probleme", "{n} problems", "{n} problemas"],
    svcWarn: ["Teilweise", "Partly", "Parcial"],
    svcWait: ["Wird geprüft", "Checking", "Comprobando"],
    "off:immich": ["Nur mit Immich als Quelle nötig", "Only needed with Immich as source", "Solo con Immich como fuente"],
    "off:dynaframe": ["Nur mit Fotos aus DynaFrame nötig", "Only needed with photos from DynaFrame", "Solo con fotos de DynaFrame"],
    "off:library": ["Nur mit „Alle Fotos in DynaFrame“ nötig", "Only needed with “All photos in DynaFrame”", "Solo con «Todas las fotos de DynaFrame»"],
    off: ["Gerade nicht gebraucht", "Not needed right now", "No se necesita ahora"],
  };
  const LANGS = ["de", "en", "es"];
  const say = (key, n) => {
    const row = TEXT[key] || TEXT.off;
    const i = Math.max(0, LANGS.indexOf(document.documentElement.lang));
    return (row[i] ?? row[0]).replace("{n}", String(n));
  };
  const store = (() => {
    try { return window.localStorage; } catch (_) { return null; }
  })();
  const keyOf = (id) => `fold:${location.pathname}:${id}`;
  const remembered = (id) => {
    try { return JSON.parse(store?.getItem(keyOf(id)) || "null"); } catch (_) { return null; }
  };
  const remember = (id, value) => {
    try { store?.setItem(keyOf(id), JSON.stringify(value)); } catch (_) { /* privat */ }
  };

  // Quellen-Auswahl: jedes <select>, das eine Immich-Option hat (auch Quellen-Zeilen, die studio.js erst später baut)
  const DF_KINDS = ["library", "folders", "playlist", "same"];
  function sourceValues() {
    const values = [];
    for (const select of document.querySelectorAll("select")) {
      if ([...select.options].some((o) => o.value.startsWith("immich"))) values.push(select.value);
    }
    return values;
  }
  function holds(rule) {
    // "uses:immich", "uses:dynaframe", "uses:library" oder "Feld=wert1,wert2", mehrere mit "|"
    return rule.split("|").some((part) => {
      part = part.trim();
      if (part.startsWith("uses:")) {
        const values = sourceValues();
        if (!values.length) return true; // keine Quellen-Auswahl auf der Seite: immer gebraucht
        const what = part.slice(5);
        if (what === "immich") return values.some((v) => v.startsWith("immich"));
        if (what === "dynaframe") return values.some((v) => DF_KINDS.includes(v));
        return values.includes(what);
      }
      const [id, list] = part.split("=");
      const field = document.getElementById(id);
      if (!field) return true;
      const value = field.type === "checkbox" ? String(field.checked) : field.value;
      return (list || "").split(",").map((v) => v.trim()).includes(value);
    });
  }

  // Wie viele Einstellungen in einem Bereich vom Standard abweichen (Felder mit Wert, Häkchen, Auswahl ≠ erste Option)
  function activeCount(nodes) {
    let n = 0;
    for (const node of nodes) {
      for (const field of node.querySelectorAll("input, select, textarea")) {
        if (field.closest(".checks") || field.type === "password" || field.type === "button") continue;
        if (field.type === "checkbox") n += field.checked ? 1 : 0;
        else if (field.tagName === "SELECT") n += field.selectedIndex > 0 ? 1 : 0;
        else n += field.value.trim() && field.value.trim() !== "0" ? 1 : 0;
      }
      for (const list of node.querySelectorAll(".checks")) n += list.querySelector("input:checked") ? 1 : 0;
    }
    return n;
  }

  function badgeFor(fold) {
    if (!fold.needed) return [say(`off:${fold.rule.replace(/^uses:/, "").split("|")[0]}`), "off"];
    const nodes = fold.body();
    switch (fold.badge) {
      case "count": {
        const n = activeCount(nodes);
        return n ? [say("active", n), "on"] : [say("none"), ""];
      }
      case "filled": {
        const filled = nodes.some((node) => [...node.querySelectorAll('input[type="url"], input[type="text"]')].some((f) => f.value.trim()));
        return filled ? [say("set"), "on"] : [say("optional"), ""];
      }
      case "lines": {
        const n = nodes.reduce((sum, node) => sum + [...node.querySelectorAll("textarea")]
          .reduce((s, area) => s + area.value.split("\n").filter((line) => line.trim()).length, 0), 0);
        return n ? [say("lines", n), "on"] : [say("optional"), ""];
      }
      case "services": {
        const bad = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.bad").length, 0);
        const warn = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.warn").length, 0);
        const ok = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.ok").length, 0);
        if (bad) return [say(bad === 1 ? "svcBad" : "svcBads", bad), "bad"];
        if (warn) return [say("svcWarn"), "warn"];
        return ok ? [say("svcOk"), "ok"] : [say("svcWait"), ""];
      }
      default:
        return ["", ""];
    }
  }

  const folds = [];

  function setup(head, id, isCard) {
    const host = isCard ? head : head.parentElement;
    const title = isCard ? (head.querySelector(":scope > .card-head") || head.querySelector(":scope > h2")) : head;
    if (!title) return;
    const bar = document.createElement("div");
    bar.className = "fold-bar" + (isCard ? " fold-bar-card" : " fold-bar-sub");
    bar.setAttribute("role", "button");
    bar.tabIndex = 0;
    title.replaceWith(bar);
    bar.append(title);
    const badge = document.createElement("span");
    badge.className = "fold-badge";
    const chevron = document.createElement("span");
    chevron.className = "fold-chevron";
    chevron.setAttribute("aria-hidden", "true");
    bar.append(badge, chevron);
    let body = null;
    if (!isCard) {
      // Unterabschnitt: alles bis zum nächsten h3.sub / <details> / Kartenende
      body = document.createElement("div");
      body.className = "fold-body";
      let next = bar.nextElementSibling;
      while (next && !(next.matches("h3.sub, .fold-bar, details"))) {
        const after = next.nextElementSibling;
        body.append(next);
        next = after;
      }
      bar.after(body);
    }
    const src = head;
    const fold = {
      id, host, bar, body: () => (isCard ? [...host.children].filter((c) => c !== bar) : [body]),
      rule: src.dataset.foldWhen || "",
      startClosed: src.dataset.foldStart === "closed",
      badge: src.dataset.foldBadge || "", badgeEl: badge,
      needed: true, open: true, isCard, sub: body,
    };
    const toggle = (e) => {
      if (e.type === "click" && e.target.closest("button, a, input, select, textarea, label")) return;
      if (e.type === "keydown" && (e.target !== bar || (e.key !== "Enter" && e.key !== " "))) return;
      if (e.type === "keydown") e.preventDefault();
      show(fold, !fold.open);
      remember(id, { open: fold.open, needed: fold.needed });
    };
    bar.addEventListener("click", toggle);
    bar.addEventListener("keydown", toggle);
    folds.push(fold);
    if (fold.rule) show(fold, false); // erst entscheiden, wenn studio.js den Stand gesetzt hat
    else start(fold);
  }

  function start(fold) {
    const saved = remembered(fold.id);
    fold.needed = fold.rule ? holds(fold.rule) : true;
    fold.wasNeeded = fold.needed;
    fold.started = true;
    show(fold, saved && saved.needed === fold.needed ? saved.open : wanted(fold));
  }

  function wanted(fold) {
    if (!fold.needed) return false;
    if (fold.badge === "services") {
      const [, tone] = badgeFor(fold);
      if (tone === "bad") return true;
    }
    return !fold.startClosed;
  }

  function show(fold, open) {
    fold.open = open;
    fold.host.classList.toggle("fold-closed", fold.isCard && !open);
    if (fold.sub) fold.sub.hidden = !open;
    fold.bar.setAttribute("aria-expanded", String(open));
    fold.bar.title = say(open ? "close" : "open");
  }

  // Bereit, sobald studio.js den ersten Stand gezeigt hat (Version steht da) oder nach 5 s
  const born = Date.now();
  function stateShown() {
    const version = document.getElementById("factVersion");
    return !version || /\d/.test(version.textContent) || Date.now() - born > 5000;
  }

  function refresh() {
    const ready = stateShown();
    for (const fold of folds) {
      if (!fold.started) {
        if (!ready) continue;
        start(fold);
      }
      fold.needed = fold.rule ? holds(fold.rule) : true;
      if (fold.needed !== fold.wasNeeded) {
        // Quelle gewechselt: Karte auf- bzw. zuklappen, eigene Wahl vergessen
        fold.wasNeeded = fold.needed;
        remember(fold.id, null);
        show(fold, wanted(fold));
      }
      fold.host.classList.toggle("fold-unused", fold.isCard && !fold.needed);
      const [text, tone] = badgeFor(fold);
      // Verbindungen: bei einem neuen Problem von selbst aufklappen
      if (fold.badge === "services" && tone === "bad" && fold.lastTone !== "bad") show(fold, true);
      fold.lastTone = tone;
      if (fold.badgeEl.textContent !== text) fold.badgeEl.textContent = text;
      fold.badgeEl.className = "fold-badge" + (tone ? ` ${tone}` : "");
      fold.badgeEl.hidden = !text;
      fold.bar.title = say(fold.open ? "close" : "open");
    }
  }

  function init() {
    for (const card of document.querySelectorAll(".card[data-fold]")) setup(card, card.dataset.fold, true);
    for (const head of document.querySelectorAll("h3.sub[data-fold]")) setup(head, head.dataset.fold, false);
    refresh();
    document.addEventListener("change", refresh);
    document.addEventListener("input", refresh);
    setInterval(refresh, 1000); // studio.js setzt Werte beim Abfragen des Stands
  }

  window.Fold = { refresh, open: (id, value = true) => { const f = folds.find((x) => x.id === id); if (f) show(f, value); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
// ---- accordion:end

// ==== photo-privacy:start (tools/plugin-vorlage/photo-privacy, nicht von Hand ändern) ====
const PP_TEXT = {
  "de": {
    "title": "Fotopositionen",
    "label": "Fotopositionen bleiben auf dem Rahmen",
    "hint": "Ist der Haken gesetzt, schickt das Plugin die GPS-Position deiner Fotos an keinen Online-Dienst mehr. Das betrifft: {uses}. Was schon geladen ist, bleibt; für neue Fotos fehlt es dann. Deine Heimat ist kein Foto und bleibt erlaubt.",
    "places": "Ortsnamen (OpenStreetMap)",
    "weather": "Wetter von damals (Open-Meteo)",
    "elevation": "Höhe über dem Meer (Open-Meteo)",
    "sights": "Sehenswürdigkeiten und Ortsinfos (Wikipedia, Wikidata, OpenStreetMap)",
    "guide": "Achtung: Der Reiseführer lebt von diesen Infos. Mit Haken zeigt er nur noch Orte, die er schon kennt.",
    "on": "An: keine Fotoposition verlässt den Rahmen.",
    "off": "",
    "map": "Kartenkacheln am Fotoort (CARTO; die Karte zeigt dann nur Küstenlinien)"
  },
  "en": {
    "title": "Photo locations",
    "label": "Keep photo locations on the frame",
    "hint": "When ticked, the plugin no longer sends the GPS position of your photos to any online service. This affects: {uses}. Anything already loaded stays; new photos go without it. Your home is not a photo and stays allowed.",
    "places": "place names (OpenStreetMap)",
    "weather": "weather back then (Open-Meteo)",
    "elevation": "elevation (Open-Meteo)",
    "sights": "sights and place info (Wikipedia, Wikidata, OpenStreetMap)",
    "guide": "Note: the travel guide lives on this info. When ticked it only shows places it already knows.",
    "on": "On: no photo location leaves the frame.",
    "off": "",
    "map": "map tiles at the photo place (CARTO; the map then shows coastlines only)"
  },
  "es": {
    "title": "Ubicaciones de las fotos",
    "label": "Las ubicaciones de las fotos se quedan en el marco",
    "hint": "Si está marcado, el plugin ya no envía la posición GPS de tus fotos a ningún servicio en línea. Afecta a: {uses}. Lo que ya está cargado se queda; las fotos nuevas no lo tendrán. Tu casa no es una foto y sigue permitida.",
    "places": "nombres de lugares (OpenStreetMap)",
    "weather": "el tiempo de entonces (Open-Meteo)",
    "elevation": "altitud (Open-Meteo)",
    "sights": "lugares de interés e información (Wikipedia, Wikidata, OpenStreetMap)",
    "guide": "Ojo: la guía de viaje vive de esta información. Con la casilla marcada solo muestra lugares que ya conoce.",
    "on": "Activado: ninguna ubicación de foto sale del marco.",
    "off": "",
    "map": "teselas del mapa en el lugar de la foto (CARTO; el mapa muestra entonces solo las costas)"
  }
};

function ppRender(state) {
  const box = document.getElementById("KeepPhotoPlaces");
  if (!box) return;
  const tx = PP_TEXT[String(lang || document.documentElement.lang || "en").slice(0, 2)] || PP_TEXT.en;
  const card = document.getElementById("photoPrivacy");
  const uses = String(card?.dataset.ppUses || "places").split(",").filter((k) => tx[k] && k !== "guide").map((k) => tx[k]);
  for (const node of document.querySelectorAll("[data-pp]")) {
    const key = node.dataset.pp;
    node.textContent = key === "hint" ? tx.hint.replace("{uses}", uses.join(", ")) : (tx[key] || "");
  }
  const on = Boolean(state?.settings?.KeepPhotoPlaces);
  if (state?.settings && document.activeElement !== box) box.checked = on;
  const note = document.getElementById("photoPrivacyNote");
  if (note) { note.textContent = on ? tx.on : tx.off; note.className = on ? "status ok" : "status"; }
}

{
  const ppOriginalRender = render;
  // eslint-disable-next-line no-func-assign
  render = function (...args) {
    const out = ppOriginalRender.apply(this, args);
    try { ppRender(args[0]); } catch (_) { /* Seite läuft weiter */ }
    return out;
  };
  document.getElementById("KeepPhotoPlaces")?.addEventListener("change", (event) => save({ KeepPhotoPlaces: event.target.checked }));
  try { ppRender(current); } catch (_) { /* noch nicht geladen */ }
}
// ==== photo-privacy:end ====
