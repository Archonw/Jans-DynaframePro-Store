# Growing Up

Watch your children (or anyone) grow up on the frame. Growing Up takes people from your own **Immich** server (its face recognition), goes through all their photos, picks the best face per month, quarter or year and cuts out square portraits lined up on the face.

The package has two parts that are installed together:

- **The Growing Up scene** shows, for each person in turn:
  - **Time-lapse:** the face grows up portrait by portrait (crossfade, faces lined up), with age, date and a timeline of the years.
  - **Contact sheet:** all portraits of a person at once, with age and year.
  - **Then and now:** the first and the latest portrait, and how many years lie between them.
  - **At the same age:** two or more people (e.g. siblings) side by side at 6 months, 1 year, 2 years, … (needs birthdays).
- **The plugin** talks to Immich, picks the faces, keeps the portraits on the frame and can show the scene over the playlist on birthdays or on a schedule.

Landscape and portrait. English, German or Spanish.

## Setting up

1. Install the package (from the store, or Plugins > Upload).
2. Open **Open Growing Up** on the Plugins page.
3. Enter your Immich server address and an API key (Immich: *Account settings › API keys*; needs at least `person.read`, `asset.read`, `asset.view` and `face.read`). If Immich Slideshow is installed, Growing Up takes its server and key.
4. Pick the people. Only people with a name in Immich are listed. With a birthday (from Immich, or entered on the page) every portrait shows the age.
5. Add the scene to a playlist, or let Growing Up create the playlist "Growing Up". For birthdays or a schedule over the playlist switch on **Allow takeover** for Growing Up on the Plugins page.

## How the faces are picked

Per period (automatic: monthly in the first year, quarterly until 3, half-yearly until 6, then yearly) the best face wins: big, whole in the picture, rather from the front; favourites and stars count too. Faces smaller than the set minimum are only used if a period has nothing better. Don't like a portrait? Click it on the plugin page and Growing Up takes the next best photo for that period.

The scene uses a crossfade between portraits lined up on the face, not a real face morph.

## Your photos

The photos stay on your Immich server. The frame keeps only the cut-out portraits (about 60 KB each) and the list of photos with faces. Removing a person deletes both.

Problems or wishes: https://github.com/Archonw/Jans-DynaframePro-Store/issues
