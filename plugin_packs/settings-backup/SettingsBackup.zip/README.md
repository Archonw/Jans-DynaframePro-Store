# Settings Backup

Saves the settings of all plugins and scenes on a DynaFrame to one file and puts them back, on the same frame or on another one. Plugin page in German, English and Spanish.

## What is in the backup

For every installed plugin (under `~/.local/share/dfr/plugins/<Name>/`):

- the values from the Plugins page (`manifest.json`, `Settings[].Value`), optionally also on/off,
- the `data/` folder (where most plugins keep their settings) and common settings files in the plugin folder (`settings.json`, `config.json`, ...),
- the settings of the scenes known to the Engine (`/dynamic-scenes/{id}/settings`).

Left out, because they only belong to one frame or come back by themselves: `state.json` (takeover playlist numbers), caches, pictures, videos, databases, logs, paired phones (`devices.json`) and files over 2 MB.

## Secrets

- **With a password** the file is encrypted (PBKDF2-SHA256 + HMAC-SHA256, Python standard library only) and also holds API keys, passwords and tokens.
- **Without a password** these are replaced by placeholders. When restoring, the keys already entered on the target frame are kept.

## Moving to another frame

1. On the old frame: Plugins > Settings Backup > *Download backup*.
2. On the new frame install the same plugins from the Store, and Settings Backup.
3. Open the file there. Packs that came from a store and are missing here are listed; *Install selected packs* installs them from the same store (the version it offers today). Plugins that came from no store travel with their code and are installed by *Apply*.
4. *Apply*. Settings are set through the Engine and affected plugins restart; only if the Engine does not answer is a DynaFrame restart needed.

Before applying, the current state is kept; *Undo* brings it back.

Problems or wishes: https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=%5BSettings%20Backup%5D%20
