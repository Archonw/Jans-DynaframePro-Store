"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Angekommen. Das Video wird für den Rahmen umgewandelt und erscheint danach.": (
        "Arrived. The video is being converted for the frame and appears afterwards.",
        "Recibido. El vídeo se está convirtiendo para el marco y aparecerá después."),
    "Der Rahmen konnte dieses Video nicht abspielen ({code}).": (
        "The frame could not play this video ({code}).",
        "El marco no pudo reproducir este vídeo ({code})."),
    "Die Datei ist zu groß (höchstens {mb} MB).": (
        "The file is too large (at most {mb} MB).",
        "El archivo es demasiado grande (como máximo {mb} MB)."),
    "Dieses Video ({codec}) kann der Rahmen vielleicht nicht abspielen, und ffmpeg zum Umwandeln fehlt.": (
        "The frame may not be able to play this video ({codec}), and ffmpeg for converting it is missing.",
        "Puede que el marco no reproduzca este vídeo ({codec}) y falta ffmpeg para convertirlo."),
    "Konnte das Video nicht abspielen: {exc}": (
        "Could not play the video: {exc}", "No se pudo reproducir el vídeo: {exc}"),
    "Der Bildschirm ist aus; das Video wird nicht gezeigt.": (
        "The screen is off; the video is not shown.",
        "La pantalla está apagada; el vídeo no se muestra."),
    "Etwas anderes hat gerade den Bildschirm; das Video kommt danach.": (
        "Something else has the screen right now; the video follows afterwards.",
        "Ahora mismo otra cosa ocupa la pantalla; el vídeo vendrá después."),
    "Umwandeln fehlgeschlagen: {exc}": ("Converting failed: {exc}", "La conversión falló: {exc}"),
    "Auf dem Rahmen.": ("On the frame.", "En el marco."),
    "Das Foto ist zu groß (höchstens {mb} MB).": (
        "The photo is too large (at most {mb} MB).",
        "La foto es demasiado grande (como máximo {mb} MB)."),
    "Das ist kein Foto, das der Rahmen lesen kann.": (
        "That is not a photo the frame can read.",
        "Eso no es una foto que el marco pueda leer."),
    "Der Bildschirm ist aus; das Foto wird nicht gezeigt.": (
        "The screen is off; the photo is not shown.",
        "La pantalla está apagada; la foto no se muestra."),
    "Der Rahmen hat das Foto nicht rechtzeitig angezeigt.": (
        "The frame did not show the photo in time.",
        "El marco no ha mostrado la foto a tiempo."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.",
        "El marco no ha creado la lista {name}."),
    "Der Rahmen ist nach den Fotos nicht zu deiner Playlist zurückgekehrt. Starte sie auf der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix passiert das nicht.": (
        "The frame did not return to your playlist after the photos. Start it again on the frame's home page. This does not happen with a saved playlist instead of a Quick Mix.",
        "El marco no ha vuelto a tu lista después de las fotos. Vuelve a iniciarla en la página de inicio del marco. Con una lista guardada en lugar de un Quick Mix no pasa."),
    "Die Szene Foto Cast ist auf der Plugins-Seite ausgeschaltet.": (
        "The Foto Cast scene is switched off on the Plugins page.",
        "La escena Foto Cast está desactivada en la página de plugins."),
    "Die Szene Foto Cast ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The Foto Cast scene is not installed on this frame. Install the package again.",
        "La escena Foto Cast no está instalada en este marco. Vuelve a instalar el paquete."),
    "Die Szene Foto Cast wurde nicht gefunden.": (
        "The Foto Cast scene was not found.",
        "No se ha encontrado la escena Foto Cast."),
    "Die Takeover-Playlist ist noch nicht angelegt.": (
        "The takeover playlist has not been created yet.",
        "La lista de takeover aún no se ha creado."),
    "Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.": (
        "This frame is too old to hand the screen to a plugin.",
        "Este marco es demasiado antiguo para ceder la pantalla a un plugin."),
    "Es kam kein Foto an.": ("No photo arrived.", "No ha llegado ninguna foto."),
    "Etwas anderes hat gerade den Bildschirm.": (
        "Something else has the screen right now.",
        "Ahora mismo otra cosa ocupa la pantalla."),
    "Falscher Code.": ("Wrong code.", "Código incorrecto."),
    "HEIC-Fotos vom iPhone kann der Rahmen nicht lesen. Füge im Kurzbefehl „Bild konvertieren“ in JPEG ein oder schick das Foto über die Handy-Seite.": (
        "The frame cannot read HEIC photos from the iPhone. Add “Convert Image” to JPEG in the shortcut, or send the photo from the phone page.",
        "El marco no puede leer fotos HEIC del iPhone. Añade «Convertir imagen» a JPEG en el atajo o envía la foto desde la página del móvil."),
    "Handy": ("Phone", "Móvil"),
    "Kein freier Port für die Handy-Seite (8095 bis 8098).": (
        "No free port for the phone page (8095 to 8098).",
        "No hay puerto libre para la página del móvil (8095 a 8098)."),
    "Konnte das Foto nicht anzeigen: {exc}": ("Could not show the photo: {exc}", "No se pudo mostrar la foto: {exc}"),
    "Konnte das Foto nicht lesen: {exc}": ("Could not read the photo: {exc}", "No se pudo leer la foto: {exc}"),
    "Konnte die Takeover-Playlist nicht anlegen: {exc}": (
        "Could not create the takeover playlist: {exc}",
        "No se pudo crear la lista de takeover: {exc}"),
    "Foto Cast ist auf der Plugins-Seite ausgeschaltet.": (
        "Foto Cast is switched off on the Plugins page.",
        "Foto Cast está desactivado en la página de plugins."),
    "„Allow takeover“ ist für Foto Cast auf der Plugins-Seite aus. Schalte es ein, sonst kann kein Foto gezeigt werden.": (
        "“Allow takeover” is off for Foto Cast on the Plugins page. Switch it on, otherwise no photo can be shown.",
        "«Allow takeover» está desactivado para Foto Cast en la página de plugins. Actívalo; si no, no se puede mostrar ninguna foto."),
    "{count} Fotos auf dem Rahmen.": ("{count} photos on the frame.", "{count} fotos en el marco."),
}


def t(lang, template, **values):
    text = template
    if lang in LANGUAGES and lang != "de":
        row = _TEXTS.get(template)
        if row:
            text = row[LANGUAGES.index(lang) - 1]
    try:
        return text.format(**values) if values else text
    except (KeyError, IndexError, ValueError):
        return text
