#!/usr/bin/env python3
"""Wikipedia Breathes - der Plugin-Teil des Pakets.

Die Szene "wikipedia-breathes" zeigt jede Änderung an Wikipedia weltweit als
Lichtpunkt auf einer Weltkarte, am Ort ihrer Sprache: groß bei viel Text, rot,
wenn etwas gelöscht wurde. Dieses Plugin liest den Datenstrom der Wikimedia
EventStreams (recentchange), behält nur Wikipedia-Änderungen, zählt mit und
gibt der Szene jede Sekunde die neuen Änderungen, ausgedünnt auf so viele, wie
der Pi flüssig zeichnet. Der Strom läuft nur, solange jemand zusieht.
"""

import json
import os
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import own_playlist  # noqa: E402
import stream  # noqa: E402
import texts  # noqa: E402

plugin = create_plugin()

PLUGIN_ID = "WikipediaBreathes"
SCENE_ID = "wikipedia-breathes"              # id in scene.dynamic - nie ändern
PLAYLIST_NAME = "Wikipedia Breathes"         # in allen Sprachen gleich (englische Namen, Jans Regel 12.11.2026)
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"
CONNECT_TIMEOUT = 10
WATCH_SECONDS = 90                    # so lange bleibt der Strom nach der letzten Frage der Szene offen


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def log(text, level="info"):
    plugin.log(text, level=level)


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        log(f"Konnte {path.name} nicht lesen: {exc}", "warning")
        return default


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

SCHEMA = {
    "Language":        {"kind": "choice", "default": "de", "choices": texts.LANGUAGES},
    "Region":          {"kind": "choice", "default": "world", "choices": ("world", "europe", "americas", "asia", "africa")},
    "Bots":            {"kind": "choice", "default": "dim", "choices": ("show", "dim", "hide")},
    "Pages":           {"kind": "choice", "default": "all", "choices": ("all", "articles")},
    "PerSecond":       {"kind": "choice", "default": "20", "choices": ("10", "20", "40", "80")},
    "Glow":            {"kind": "choice", "default": "8", "choices": ("4", "8", "15", "30")},
    "Ticker":          {"kind": "bool", "default": True},
    "Panel":           {"kind": "bool", "default": True},
    "LanguageLabels":  {"kind": "bool", "default": True},
    "PlaylistSeconds": {"kind": "int", "default": 300, "min": 30, "max": 86400},
    "MakePlaylist":    {"kind": "bool", "default": False},
}
SCENE_SETTINGS = ("Language", "Region", "Bots", "Pages", "PerSecond", "Glow", "Ticker", "Panel", "LanguageLabels")
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    value = str(raw if raw is not None else "").strip()
    return value if value in spec["choices"] else spec["default"]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 120))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=(PLAYLIST_NAME,),
    name=lambda: PLAYLIST_NAME,
    description=lambda: tr("Jede Änderung an Wikipedia weltweit als Lichtpunkt am Ort ihrer Sprache."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()


# --------------------------------------------------------------------------
# Der Datenstrom
# --------------------------------------------------------------------------

STREAM = stream.Stream(
    user_agent=f"DynaFrame-WikipediaBreathes/{version()} (+https://github.com/Archonw/Jans-DynaframePro-Store)",
    log=lambda text, level="info": log(text, level),
)
_stop = threading.Event()


def test_stream():
    """Knopf „Datenstrom testen“: eine Minute verbinden, auch ohne Szene."""
    STREAM.want(60)
    return {"success": True, "message": tr("Verbindet sich für eine Minute mit dem Datenstrom.")}


# --------------------------------------------------------------------------
# Was die Szene und die Seite bekommen
# --------------------------------------------------------------------------

def scene_payload(query):
    STREAM.want(WATCH_SECONDS)
    values = settings()
    since = as_int((query.get("since") or ["-1"])[0], -1)
    limit = max(0, min(400, as_int((query.get("n") or ["40"])[0], 40)))
    hide_bots = values["Bots"] == "hide"
    only_articles = values["Pages"] == "articles"

    def keep(flags):
        if hide_bots and flags & stream.F_BOT:
            return False
        return not only_articles or bool(flags & (stream.F_ARTICLE | stream.F_DELETED))

    last, rows, dropped = STREAM.since(since, limit, keep)
    events = []
    for _seq, at, lang, delta, flags, title in rows:
        # Titel nur für die Laufzeile: Artikel, keine Bots
        show = title if (flags & stream.F_ARTICLE and not flags & stream.F_BOT) else ""
        events.append([lang, delta, flags, show, round(at, 2)])
    body = {"success": True, "settings": {k: values[k] for k in SCENE_SETTINGS},
            "state": STREAM.state, "error": STREAM.error, "seq": last,
            "events": events, "dropped": dropped, "now": round(now(), 2)}
    if as_int((query.get("stats") or ["1"])[0], 1):
        body["stats"] = STREAM.numbers()
    return body


DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    numbers = STREAM.numbers()
    numbers.pop("rate", None)
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": values,
        "state": STREAM.state,
        "error": STREAM.error,
        "stats": numbers,
        "theme": {"id": theme_id()},
    }


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(min(length, 1024 * 1024)) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(query), cors=True)
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                changed = save_settings(self._body())
                if "MakePlaylist" in changed:
                    OWN.changed()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/test":
                self._json(test_stream())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}")
    plugin.on_action("test", lambda _context=None: test_stream())
    plugin.on_action("playlist", lambda _context=None: make_playlist())
    start_studio()
    plugin.connect_sse()
    plugin.ready()
    STREAM.start()
    try:
        while not _stop.is_set():
            _stop.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop.set()
    STREAM.stop()
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
