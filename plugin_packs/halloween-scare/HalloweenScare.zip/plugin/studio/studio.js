"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/HalloweenScare/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["Lurk", "Cooldown", "Chance", "Volume", "QuietFrom", "QuietTo"];
const CHECK_FIELDS = ["Armed", "Sound", "SeasonOnly", "WakeScreen", "QuietEnabled"];
const SELECT_FIELDS = ["MotionMode", "DoorbellMode", "Intensity", "Variant", "Doorbell"];
const SOUNDS = ["ambient", "scream", "whisper", "shriek", "static", "bang", "growl", "roar", "giggle", "boo"];
let current = null;
let entities = null;
let editing = false;

// [en, de, es]
const I18N = {
  eyebrow: ["Plugin page", "Plugin-Seite", "Página del plugin"],
  lede: ["Your frame shows your photos as usual. When someone walks past a motion sensor or rings the doorbell, it gives them a fright, then the playlist carries on. Every change here is saved immediately.",
    "Dein Rahmen zeigt ganz normal deine Fotos. Läuft jemand an einem Bewegungsmelder vorbei oder klingelt es, bekommt er einen Schreck, danach läuft die Playlist weiter. Jede Änderung hier wird sofort gespeichert.",
    "Tu marco muestra tus fotos como siempre. Cuando alguien pasa junto a un sensor de movimiento o llama al timbre, se lleva un susto y luego la lista sigue. Cada cambio aquí se guarda al instante."],
  language: ["Language", "Sprache", "Idioma"],
  status: ["Status", "Status", "Estado"],
  cancel: ["Stop", "Beenden", "Terminar"],
  armed: ["Armed: motion sensors and the doorbell trigger scares", "Scharf: Bewegungsmelder und Klingel lösen Schrecks aus",
    "Activado: los sensores de movimiento y el timbre provocan sustos"],
  factScreen: ["Screen", "Bildschirm", "Pantalla"],
  factLast: ["Last scare", "Letzter Schreck", "Último susto"],
  factVersion: ["Version", "Version", "Versión"],
  tryTitle: ["Try it now", "Jetzt ausprobieren", "Probar ahora"],
  mPortrait: ["Haunted portrait", "Spukporträt", "Retrato embrujado"],
  mPortraitSub: ["eyes follow you, then it screams", "die Augen folgen dir, dann schreit es", "los ojos te siguen y luego grita"],
  mGhost: ["Ghost in the photo", "Geist im Foto", "Fantasma en la foto"],
  mGhostSub: ["a pale figure, then it jumps at you", "eine blasse Gestalt, dann springt sie dich an", "una figura pálida y luego salta hacia ti"],
  mStatic: ["TV static", "Störsignal", "Interferencia"],
  mStaticSub: ["a figure comes closer with every glitch", "bei jeder Störung kommt eine Gestalt näher", "una figura se acerca con cada fallo"],
  mMonster: ["Monster", "Monster", "Monstruo"],
  mMonsterSub: ["claws at the edge, then it roars", "Klauen an der Kante, dann brüllt es", "garras en el borde y luego ruge"],
  mRandom: ["Different each time", "Jedes Mal ein anderer", "Cada vez uno distinto"],
  tryHint: ["Shows the scare right away with the settings below, ignoring pause, chance and quiet hours.",
    "Zeigt den Schreck sofort mit den Einstellungen unten, ohne Pause, Zufall und Ruhezeit.",
    "Muestra el susto ahora mismo con los ajustes de abajo, sin pausa, azar ni horas de silencio."],
  recent: ["Recently", "Zuletzt", "Recientes"],
  noRecent: ["No scares yet.", "Noch keine Schrecks.", "Todavía no hay sustos."],
  shown: ["shown", "gezeigt", "mostrado"],
  skipped: ["skipped", "ausgelassen", "omitido"],
  seen: ["received from Home Assistant", "von Home Assistant gemeldet", "recibido de Home Assistant"],
  srcHa: ["Change", "Änderung", "Cambio"],
  srcMotion: ["Motion", "Bewegung", "Movimiento"],
  srcDoorbell: ["Doorbell", "Klingel", "Timbre"],
  srcAutomation: ["Automation", "Automation", "Automatización"],
  srcTest: ["Test", "Probe", "Prueba"],
  connTitle: ["Connect to Home Assistant", "Mit Home Assistant verbinden", "Conectar con Home Assistant"],
  url: ["Address", "Adresse", "Dirección"],
  token: ["Long-lived access token", "Langlebiger Zugangstoken", "Token de acceso de larga duración"],
  tokenSet: ["saved – leave empty to keep it", "gespeichert – leer lassen, um ihn zu behalten", "guardado: déjalo vacío para conservarlo"],
  connect: ["Connect", "Verbinden", "Conectar"],
  connecting: ["Connecting …", "Verbinde …", "Conectando …"],
  howtoTitle: ["How to get the access token", "So bekommst du den Zugangstoken", "Cómo obtener el token de acceso"],
  howto1: ["Open Home Assistant and click your <b>name</b> at the bottom left (profile).",
    "Öffne Home Assistant und klicke unten links auf deinen <b>Namen</b> (Profil).",
    "Abre Home Assistant y haz clic en tu <b>nombre</b> abajo a la izquierda (perfil)."],
  howto2: ["Choose the <b>Security</b> tab at the top and scroll all the way down.",
    "Wähle oben den Reiter <b>Sicherheit</b> und scrolle ganz nach unten.",
    "Elige la pestaña <b>Seguridad</b> arriba y baja hasta el final."],
  howto3: ["Under <b>Long-lived access tokens</b> click <b>Create token</b> and enter a name such as “DynaFrame”.",
    "Unter <b>Langlebige Zugangstoken</b> auf <b>Token erstellen</b> klicken, z. B. „DynaFrame“ als Namen eingeben.",
    "En <b>Tokens de acceso de larga duración</b> pulsa <b>Crear token</b> e introduce un nombre, p. ej. «DynaFrame»."],
  howto4: ["Copy the token shown (it is only shown once) and paste it above. Then Connect.",
    "Den angezeigten Token kopieren (er wird nur einmal gezeigt) und oben einfügen. Dann Verbinden.",
    "Copia el token que aparece (solo se muestra una vez) y pégalo arriba. Después, Conectar."],
  profileLink: ["Open your profile in Home Assistant", "Profil in Home Assistant öffnen", "Abrir tu perfil en Home Assistant"],
  noHaHint: ["Without Home Assistant you can still start a scare with the buttons above or the plugin's “Scare now” action, e.g. from a DynaFrame automation.",
    "Auch ohne Home Assistant lässt sich ein Schreck starten: mit den Knöpfen oben oder der Aktion „Scare now“ des Plugins, z. B. aus einer DynaFrame-Automation.",
    "Sin Home Assistant también puedes iniciar un susto con los botones de arriba o con la acción «Scare now» del plugin, p. ej. desde una automatización de DynaFrame."],
  motionTitle: ["Motion sensors", "Bewegungsmelder", "Sensores de movimiento"],
  motionHint: ["A scare starts when one of these switches from “clear” to “detected”.",
    "Ein Schreck startet, wenn einer davon von „keine Bewegung“ auf „Bewegung“ wechselt.",
    "Un susto empieza cuando uno de ellos pasa de «despejado» a «detectado»."],
  moreSensors: ["Other sensors (door contacts, switches, lights …)", "Andere Sensoren (Türkontakte, Schalter, Lampen …)", "Otros sensores (contactos de puerta, interruptores, luces …)"],
  noMotion: ["Home Assistant has no motion sensors. Pick another sensor below.", "Home Assistant hat keine Bewegungsmelder. Wähle unten einen anderen Sensor.",
    "Home Assistant no tiene sensores de movimiento. Elige otro sensor abajo."],
  detected: ["motion now", "Bewegung", "movimiento"],
  motionMode: ["Scare on motion", "Schreck bei Bewegung", "Susto con movimiento"],
  bellTitle: ["Doorbell", "Haustürklingel", "Timbre"],
  optional: ["(optional)", "(optional)", "(opcional)"],
  bellHint: ["For trick-or-treaters: when it rings, the frame greets them. The scare comes faster here (at most 4 seconds of creeping).",
    "Für Süßes-oder-Saures-Besuch: Klingelt es, begrüßt sie der Rahmen. Hier kommt der Schreck schneller (höchstens 4 Sekunden Anschleichen).",
    "Para quienes piden caramelos: cuando llaman, el marco los recibe. Aquí el susto llega antes (como mucho 4 segundos de espera)."],
  bell: ["Doorbell", "Klingel", "Timbre"],
  bellMode: ["Scare on the doorbell", "Schreck bei der Klingel", "Susto con el timbre"],
  none: ["– none –", "– keine –", "– ninguno –"],
  bellGroup: ["Doorbells", "Klingeln", "Timbres"],
  otherGroup: ["Other switches and sensors", "Andere Schalter und Sensoren", "Otros interruptores y sensores"],
  scareTitle: ["The scare", "Der Schreck", "El susto"],
  intensity: ["How scary", "Wie gruselig", "Cuánto miedo"],
  scary: ["Scary (with screams)", "Gruselig (mit Schreien)", "De miedo (con gritos)"],
  gentle: ["Gentle, for children", "Sanft, für Kinder", "Suave, para niños"],
  variant: ["Portrait", "Porträt", "Retrato"],
  vRandom: ["Different each time", "Jedes Mal ein anderes", "Cada vez uno distinto"],
  vLady: ["The lady", "Die Dame", "La dama"],
  vCaptain: ["The captain", "Der Kapitän", "El capitán"],
  vChild: ["The child", "Das Kind", "La niña"],
  lurk: ["Creeping before the scare (seconds)", "Anschleichen vor dem Schreck (Sekunden)", "Espera antes del susto (segundos)"],
  monsterText: ["Monster's words", "Was das Monster sagt", "Lo que dice el monstruo"],
  monsterPh: ["Trick or treat!", "Süßes oder Saures!", "¡Truco o trato!"],
  cooldown: ["Pause after a scare (minutes)", "Pause nach einem Schreck (Minuten)", "Pausa tras un susto (minutos)"],
  chance: ["Chance per trigger (%)", "Wahrscheinlichkeit je Auslösung (%)", "Probabilidad por activación (%)"],
  scareHint: ["The ghost, the TV static and the monster use the photo that is on screen at that moment. With a video or no photo they appear in a dark corridor instead. Less than 100 % chance makes it unpredictable.",
    "Geist, Störsignal und Monster nehmen das Foto, das in dem Moment zu sehen ist. Bei einem Video oder ohne Foto erscheinen sie in einem dunklen Flur. Weniger als 100 % Wahrscheinlichkeit macht es unberechenbar.",
    "El fantasma, la interferencia y el monstruo usan la foto que se ve en ese momento. Con un vídeo o sin foto aparecen en un pasillo oscuro. Con menos del 100 % de probabilidad es imprevisible."],
  soundTitle: ["Sound", "Ton", "Sonido"],
  soundOn: ["Play screams and noises on the frame", "Schreie und Geräusche auf dem Rahmen abspielen", "Reproducir gritos y ruidos en el marco"],
  volume: ["Volume during the scare (0 = leave as it is)", "Lautstärke beim Schreck (0 = wie eingestellt)", "Volumen durante el susto (0 = sin cambiar)"],
  soundHint: ["All sounds are made by the plugin itself. The volume goes back to what it was after the scare. The buttons play a sound on the frame.",
    "Alle Geräusche erzeugt das Plugin selbst. Nach dem Schreck geht die Lautstärke zurück. Die Knöpfe spielen ein Geräusch auf dem Rahmen.",
    "Todos los sonidos los crea el propio plugin. Tras el susto el volumen vuelve a como estaba. Los botones reproducen un sonido en el marco."],
  sAmbient: ["Creaking", "Knarzen", "Crujidos"], sScream: ["Scream", "Schrei", "Grito"], sWhisper: ["Whisper", "Flüstern", "Susurro"],
  sShriek: ["Shriek", "Kreischen", "Chillido"], sStatic: ["Static", "Rauschen", "Interferencia"], sBang: ["Bang", "Knall", "Golpe"],
  sGrowl: ["Growl", "Knurren", "Gruñido"], sRoar: ["Roar", "Brüllen", "Rugido"], sGiggle: ["Giggle", "Kichern", "Risita"],
  sBoo: ["Boo", "Buuh", "Buu"],
  whenTitle: ["When", "Wann", "Cuándo"],
  season: ["Only around Halloween (1 October to 2 November)", "Nur rund um Halloween (1. Oktober bis 2. November)", "Solo en Halloween (1 de octubre a 2 de noviembre)"],
  wake: ["Also switch on a screen that is off", "Auch einen ausgeschalteten Bildschirm einschalten", "Encender también una pantalla apagada"],
  quietEnabled: ["No scares at night", "Nachts keine Schrecks", "Sin sustos por la noche"],
  from: ["From … o'clock", "Von … Uhr", "Desde las …"],
  to: ["Until … o'clock", "Bis … Uhr", "Hasta las …"],
  autoTitle: ["From an automation", "Aus einer Automation", "Desde una automatización"],
  autoHint: ["For advanced users: any Home Assistant automation can start a scare by firing the halloween_scare event, e.g. when a door opens or with your own conditions. All fields are optional: mode is portrait, ghost, static, monster or random; intensity is scary or gentle; force: true ignores pause, chance and quiet hours. Needs a token of an administrator.",
    "Für Fortgeschrittene: Jede Automation in Home Assistant kann einen Schreck starten, indem sie das Ereignis halloween_scare auslöst, z. B. wenn eine Tür aufgeht oder mit eigenen Bedingungen. Alle Felder sind freiwillig: mode ist portrait, ghost, static, monster oder random; intensity ist scary oder gentle; force: true übergeht Pause, Zufall und Ruhezeit. Braucht den Token eines Administrators.",
    "Para usuarios avanzados: cualquier automatización de Home Assistant puede iniciar un susto lanzando el evento halloween_scare, p. ej. al abrirse una puerta o con tus propias condiciones. Todos los campos son opcionales: mode es portrait, ghost, static, monster o random; intensity es scary o gentle; force: true ignora la pausa, el azar y las horas de silencio. Necesita el token de un administrador."],
  actionHint: ["In DynaFrame itself, the plugin offers the actions “Scare now”, “Stop”, “Arm” and “Disarm”.",
    "In DynaFrame selbst bietet das Plugin die Aktionen „Scare now“, „Stop“, „Arm“ und „Disarm“.",
    "En DynaFrame, el plugin ofrece las acciones «Scare now», «Stop», «Arm» y «Disarm»."],
  takeoverTitle: ["Important", "Wichtig", "Importante"],
  takeoverHint: ["For Halloween Scare to show anything, <b>Allow takeover</b> must be switched on on the frame's Plugins page. The “Halloween Scare (takeover)” playlist is used by the plugin itself; leave it switched off. You can also put the Halloween Scare scene into a normal playlist: the portrait then hangs there quietly and comes alive when someone walks by.",
    "Damit Halloween Scare etwas zeigen darf, muss auf der Plugins-Seite des Rahmens <b>Allow takeover</b> eingeschaltet sein. Die Playlist „Halloween Scare (takeover)“ benutzt das Plugin selbst; lass sie ausgeschaltet. Du kannst die Szene Halloween Scare auch in eine normale Playlist legen: Das Porträt hängt dann ruhig da und wird lebendig, wenn jemand vorbeigeht.",
    "Para que Halloween Scare pueda mostrar algo, <b>Allow takeover</b> debe estar activado en la página de plugins del marco. La lista «Halloween Scare (takeover)» la usa el propio plugin; déjala desactivada. También puedes poner la escena Halloween Scare en una lista normal: el retrato queda colgado tranquilamente y cobra vida cuando alguien pasa."],
  showing: ["scaring someone", "erschreckt gerade", "asustando"],
  playlistRuns: ["playlist is playing", "Playlist läuft", "la lista está en curso"],
  offNote: ["switched off", "ausgeschaltet", "desactivado"],
  quietNow: ["quiet hours now", "gerade Ruhezeit", "ahora horas de silencio"],
  seasonNo: ["outside Halloween season", "außerhalb der Halloween-Zeit", "fuera de temporada"],
  pauseLeft: ["pause: {n} s", "Pause: {n} s", "pausa: {n} s"],
  never: ["never", "noch nie", "nunca"],
  noAnswer: ["The plugin is not responding – it was probably restarted. Reload the page.",
    "Das Plugin antwortet nicht – vermutlich wurde es neu gestartet. Lade die Seite neu.",
    "El plugin no responde; probablemente se ha reiniciado. Recarga la página."],
  restarted: ["The plugin was restarted (HTTP {status}). Reload the page.", "Das Plugin wurde neu gestartet (HTTP {status}). Lade die Seite neu.",
    "El plugin se ha reiniciado (HTTP {status}). Recarga la página."],
  error: ["Error (HTTP {status})", "Fehler (HTTP {status})", "Error (HTTP {status})"],
  oclock: ["{time}", "{time} Uhr", "{time} h"],
  saved: ["Saved.", "Gespeichert.", "Guardado."],
  supportAsk: ["Problems, questions or feature requests?", "Probleme, Fragen oder Wünsche?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Open an issue on GitHub", "Schreib ein Issue auf GitHub", "Abre una incidencia en GitHub"],
  supportTail: [" with the plugin name and version.", ", mit Plugin-Name und Version.", " con el nombre y la versión del plugin."],
};
const LANGS = ["en", "de", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "en";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "en";
  if (chosen === lang && document.documentElement.lang === chosen) return false;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  el("MonsterText").placeholder = t("monsterPh");
  fillModeSelects();
  renderSoundButtons();
  return true;
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([502, 503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setNote(id, text, tone = "") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}
const setStatus = (text, tone) => setNote("statusNote", text, tone);

function clock(iso) {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes, quiet = false) {
  try {
    await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    if (!quiet) setStatus(t("saved"), "ok");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

function make(tag, props = {}, children = []) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (key === "class") node.className = value;
    else if (key === "text") node.textContent = value;
    else if (key.startsWith("on")) node.addEventListener(key.slice(2), value);
    else node[key] = value;
  }
  for (const child of children) if (child) node.append(child);
  return node;
}

const label = (row) => (row.name && row.name !== row.id ? row.name : row.id);
const MODE_KEYS = { random: "mRandom", portrait: "mPortrait", ghost: "mGhost", static: "mStatic", monster: "mMonster" };

function fillModeSelects() {
  for (const select of document.querySelectorAll(".modeSelect")) {
    const value = select.value;
    select.replaceChildren(...Object.entries(MODE_KEYS).map(([v, k]) => make("option", { value: v, text: t(k) })));
    if (value) select.value = value;
  }
}

function renderSoundButtons() {
  const box = el("soundButtons");
  box.replaceChildren(...SOUNDS.map((name) => make("button", {
    type: "button", class: "secondary", text: `▶ ${t("s" + name[0].toUpperCase() + name.slice(1))}`,
    onclick: async () => {
      try {
        const result = await api("./api/sound", { method: "POST", body: JSON.stringify({ name }) });
        setStatus(result.message || "", "busy");
      } catch (error) {
        setStatus(error.message, "bad");
      }
    }
  })));
}

function fillSelect(select, groups, chosen) {
  select.replaceChildren(make("option", { value: "", text: t("none") }));
  let found = !chosen;
  for (const [title, rows] of groups) {
    if (!rows.length) continue;
    const parent = title ? make("optgroup", { label: title }) : select;
    for (const row of rows) {
      parent.append(make("option", { value: row.id, text: label(row) }));
      if (row.id === chosen) found = true;
    }
    if (title) select.append(parent);
  }
  if (!found) select.append(make("option", { value: chosen, text: chosen }));
  select.value = chosen || "";
}

function checkList(box, rows, chosen) {
  box.replaceChildren(...rows.map((row) => {
    const input = make("input", { type: "checkbox", checked: chosen.has(row.id) });
    input.addEventListener("change", () => {
      const next = new Set(current.settings.Motion);
      if (input.checked) next.add(row.id); else next.delete(row.id);
      save({ Motion: [...next] });
    });
    return make("label", {}, [input, make("span", { text: label(row) }),
      make("span", { class: "state", text: row.state === "on" ? t("detected") : "" })]);
  }));
}

let sensorKey = "";

function renderSensors(s, force = false) {
  // Nur neu aufbauen, wenn sich etwas geändert hat: sonst springt eine offene
  // Auswahlliste oder die Liste beim Scrollen alle 5 Sekunden nach oben.
  const key = JSON.stringify([lang, s.Motion, s.Doorbell, entities ? entities.motion.length + entities.binary.length +
    entities.doorbells.length + entities.triggers.length : -1]);
  if (!force && key === sensorKey) return;
  const active = document.activeElement;
  if (!force && active && (active === el("Doorbell") || el("afterConnect").contains(active) && active.type === "checkbox")) return;
  sensorKey = key;
  const chosen = new Set(s.Motion);
  const motion = (entities && entities.motion) || [];
  const binary = (entities && entities.binary) || [];
  // gewählte, die Home Assistant nicht (mehr) kennt, trotzdem zeigen
  const known = new Set([...motion, ...binary].map((r) => r.id));
  const missing = [...chosen].filter((id) => !known.has(id)).map((id) => ({ id, name: id }));
  const box = el("motionList");
  checkList(box, [...motion, ...missing], chosen);
  if (entities && !motion.length && !missing.length) box.replaceChildren(make("p", { class: "hint", text: t("noMotion") }));
  checkList(el("binaryList"), binary, chosen);
  const bells = (entities && entities.doorbells) || [];
  const others = (entities && entities.triggers) || [];
  fillSelect(el("Doorbell"), [[bells.length ? t("bellGroup") : "", bells], [t("otherGroup"), others]], s.Doorbell);
}

const SOURCE_KEYS = { ha: "srcHa", motion: "srcMotion", doorbell: "srcDoorbell", automation: "srcAutomation", test: "srcTest" };

function renderStatus(state) {
  const c = state.connection;
  const dd = el("factConnection");
  dd.textContent = c.text;
  dd.className = c.state;
  const s = state.settings;
  el("factScreen").textContent = state.showing ? t("showing") : t("playlistRuns");
  el("factLast").textContent = state.lastScare ? clock(state.lastScare) : t("never");
  el("factVersion").textContent = state.version;
  const notes = [];
  if (!s.Armed) notes.push(t("offNote"));
  else {
    if (s.SeasonOnly && !state.seasonNow) notes.push(t("seasonNo"));
    if (state.quietNow) notes.push(t("quietNow"));
    if (state.cooldownLeft > 0) notes.push(t("pauseLeft", { n: state.cooldownLeft }));
  }
  el("armedNote").textContent = notes.join(" · ");
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Halloween Scare ${state.version}] `);
  const permission = el("permissionNote");
  permission.textContent = state.permission || "";
  permission.hidden = !state.permission;
  const extra = [state.note, state.lastError].filter(Boolean);
  if (!editing && extra.length) setStatus(extra.join(" "), state.lastError ? "bad" : "");

  el("recentList").replaceChildren(...(state.recent.length ? state.recent.map((e) => make("li", {}, [
    make("span", { class: "time", text: clock(e.at) }),
    make("span", { class: "what", text: e.mode ? `${t(SOURCE_KEYS[e.source] || "srcTest")}: ${t(MODE_KEYS[e.mode] || "mPortrait")}`
      : t(SOURCE_KEYS[e.source] || "srcTest") }),
    make("span", { class: "text", text: `${t(e.result)}${e.detail ? " · " + e.detail : ""}` }),
  ])) : [make("li", { class: "empty", text: t("noRecent") })]));
}

function render(state) {
  const first = current === null;
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  const languageChanged = applyLanguage(s.Language);
  renderStatus(state);

  const ready = state.tokenSet && s.Url;
  el("afterConnect").classList.toggle("locked", !ready);
  if (first) el("howto").open = !state.tokenSet;
  el("Token").placeholder = state.tokenSet ? t("tokenSet") : "";
  if (document.activeElement !== el("Url") && (first || !editing)) el("Url").value = s.Url;
  const link = el("profileLink");
  link.hidden = !s.Url;
  if (s.Url) link.href = `${s.Url}/profile/security`;

  if (!editing) {
    for (const name of NUMBER_FIELDS) if (document.activeElement !== el(name)) el(name).value = s[name];
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) {
      if (name !== "Doorbell" && document.activeElement !== el(name) && el(name).value !== s[name]) el(name).value = s[name];
    }
    if (document.activeElement !== el("MonsterText")) el("MonsterText").value = s.MonsterText;
    el("Language").value = lang;
  }
  renderSensors(s);
  const reachable = ["ok", "busy"].includes(state.connection.state);
  if (ready && (!entities || languageChanged) && reachable) loadEntities();
}

let loadingEntities = false;
async function loadEntities() {
  if (loadingEntities) return;
  loadingEntities = true;
  try {
    entities = await api("./api/entities");
    if (current) renderSensors(current.settings, true);
  } catch (error) {
    setNote("connNote", error.message, "bad");
  } finally {
    loadingEntities = false;
  }
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

// ---------------------------------------------------------------- Eingaben

fillModeSelects();
renderSoundButtons();
for (const name of NUMBER_FIELDS) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
  input.addEventListener("change", () => save({ [name]: Number(input.value) }));
}
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
el("MonsterText").addEventListener("focus", () => { editing = true; });
el("MonsterText").addEventListener("blur", () => { editing = false; });
el("MonsterText").addEventListener("change", (e) => save({ MonsterText: e.target.value }));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save({ Language: e.target.value });
});
for (const id of ["Url", "Token"]) {
  el(id).addEventListener("focus", () => { editing = true; });
  el(id).addEventListener("blur", () => { editing = false; });
  el(id).addEventListener("keydown", (e) => { if (e.key === "Enter") el("connectButton").click(); });
}

el("connectButton").addEventListener("click", async () => {
  const button = el("connectButton");
  button.disabled = true;
  setNote("connNote", t("connecting"), "busy");
  try {
    const result = await api("./api/connect", { method: "POST",
      body: JSON.stringify({ Url: el("Url").value.trim(), Token: el("Token").value.trim() }) });
    el("Token").value = "";
    setNote("connNote", result.message || "", "ok");
    entities = null;
    editing = false;
    await refresh();
  } catch (error) {
    setNote("connNote", error.message, "bad");
    await refresh();
  } finally {
    button.disabled = false;
  }
});

for (const button of document.querySelectorAll("[data-mode]")) {
  button.addEventListener("click", async () => {
    try {
      const result = await api("./api/test", { method: "POST", body: JSON.stringify({ mode: button.dataset.mode }) });
      setStatus(result.message || "", "busy");
      setTimeout(refresh, 2500);
    } catch (error) {
      setStatus(error.message, "bad");
    }
  });
}
el("cancelButton").addEventListener("click", async () => {
  try {
    const result = await api("./api/cancel", { method: "POST" });
    setStatus(result.message || "", "busy");
    setTimeout(refresh, 1500);
  } catch (error) {
    setStatus(error.message, "bad");
  }
});

refresh();
setInterval(refresh, 5000);
