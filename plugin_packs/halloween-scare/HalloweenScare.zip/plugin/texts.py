"""Texte des Plugins auf Englisch, Deutsch und Spanisch.

Der englische Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim englischen Text.
"""

LANGUAGES = ("en", "de", "es")

_TEXTS = {
    "Asking the frame for the screen …": ("Bitte den Rahmen um den Bildschirm …", "Pidiendo la pantalla al marco …"),
    "Connected to {name}": ("Verbunden mit {name}", "Conectado a {name}"),
    "Connected to {name}.": ("Verbunden mit {name}.", "Conectado a {name}."),
    "Connecting …": ("Verbinde …", "Conectando …"),
    "Could not create the takeover playlist: {exc}": (
        "Konnte die Takeover-Playlist nicht anlegen: {exc}", "No se ha podido crear la lista de takeover: {exc}"),
    "Could not play the sound ({problem}).": (
        "Konnte den Ton nicht abspielen ({problem}).", "No se ha podido reproducir el sonido ({problem})."),
    "Could not show the scare: {exc}": (
        "Konnte den Schreck nicht zeigen: {exc}", "No se ha podido mostrar el susto: {exc}"),
    "Could not start the scare.": ("Konnte den Schreck nicht starten.", "No se ha podido iniciar el susto."),
    "Enter a long-lived access token first.": (
        "Trage zuerst einen langlebigen Zugangstoken ein.", "Introduce primero un token de acceso de larga duración."),
    "Enter the address of your Home Assistant first.": (
        "Trage zuerst die Adresse deines Home Assistant ein.", "Introduce primero la dirección de tu Home Assistant."),
    "Filled in right away: {names}.": ("Gleich eingetragen: {names}.", "Añadido directamente: {names}."),
    "Halloween Scare is switched off on the Plugins page.": (
        "Halloween Scare ist auf der Plugins-Seite ausgeschaltet.",
        "Halloween Scare está desactivado en la página de plugins."),
    "Handing the screen back.": ("Gebe den Bildschirm zurück.", "Devolviendo la pantalla."),
    "Home Assistant answers with error {code}.": (
        "Home Assistant antwortet mit Fehler {code}.", "Home Assistant responde con el error {code}."),
    "Home Assistant cannot be reached at this address. Check the address and port.": (
        "Home Assistant ist unter dieser Adresse nicht erreichbar. Prüfe Adresse und Port.",
        "No se puede acceder a Home Assistant en esta dirección. Comprueba la dirección y el puerto."),
    "Home Assistant rejects the access token. Create a new one and paste it here.": (
        "Home Assistant lehnt den Zugangstoken ab. Erstelle einen neuen und füge ihn hier ein.",
        "Home Assistant rechaza el token de acceso. Crea uno nuevo y pégalo aquí."),
    "Home Assistant's certificate is not accepted. Use the local address with http:// and port 8123, e.g. http://192.168.1.20:8123.": (
        "Das Zertifikat von Home Assistant wird nicht akzeptiert. Nimm die lokale Adresse mit http:// und Port 8123, "
        "z. B. http://192.168.178.20:8123.",
        "No se acepta el certificado de Home Assistant. Usa la dirección local con http:// y el puerto 8123, "
        "p. ej. http://192.168.1.20:8123."),
    "No Home Assistant answers at this address. Is the port right (usually 8123)?": (
        "Unter dieser Adresse antwortet kein Home Assistant. Stimmt der Port (meist 8123)?",
        "Ningún Home Assistant responde en esta dirección. ¿Es correcto el puerto (normalmente 8123)?"),
    "No audio player found on the frame.": (
        "Kein Abspielprogramm auf dem Rahmen gefunden.", "No se ha encontrado ningún reproductor en el marco."),
    "Not set up yet.": ("Noch nicht eingerichtet.", "Todavía sin configurar."),
    "Playing the sound on the frame.": ("Spiele den Ton auf dem Rahmen.", "Reproduciendo el sonido en el marco."),
    "Something else has the screen right now.": (
        "Etwas anderes hat gerade den Bildschirm.", "Otra cosa tiene la pantalla en este momento."),
    "The Halloween Scare scene is not installed on this frame. Install the package again.": (
        "Die Szene Halloween Scare ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.",
        "La escena Halloween Scare no está instalada en este marco. Vuelve a instalar el paquete."),
    "The Halloween Scare scene is switched off on the Plugins page.": (
        "Die Szene Halloween Scare ist auf der Plugins-Seite ausgeschaltet.",
        "La escena Halloween Scare está desactivada en la página de plugins."),
    "The Halloween Scare scene was not found.": (
        "Die Szene Halloween Scare wurde nicht gefunden.", "No se ha encontrado la escena Halloween Scare."),
    "The frame did not create the playlist {name}.": (
        "Der Rahmen hat die Playlist {name} nicht angelegt.", "El marco no ha creado la lista {name}."),
    "The frame did not return to your playlist after the scare. Start it again on the frame's home page. This does not happen with a saved playlist instead of a Quick Mix.": (
        "Der Rahmen ist nach dem Schreck nicht zu deiner Playlist zurückgekehrt. Starte sie auf der Startseite des "
        "Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix passiert das nicht.",
        "El marco no ha vuelto a tu lista después del susto. Vuelve a iniciarla en la página principal del marco. "
        "Con una lista guardada en lugar de un Quick Mix no ocurre."),
    "The frame did not show the scare in time.": (
        "Der Rahmen hat den Schreck nicht rechtzeitig gezeigt.", "El marco no ha mostrado el susto a tiempo."),
    "The screen is off; the scare is not shown.": (
        "Der Bildschirm ist aus; der Schreck wird nicht gezeigt.", "La pantalla está apagada; el susto no se muestra."),
    "The takeover playlist has not been created yet.": (
        "Die Takeover-Playlist ist noch nicht angelegt.", "La lista de takeover aún no se ha creado."),
    "The websocket-client package is missing. Install Halloween Scare again.": (
        "Das Paket websocket-client fehlt. Installiere Halloween Scare noch einmal.",
        "Falta el paquete websocket-client. Vuelve a instalar Halloween Scare."),
    "This frame is too old to let a plugin take over the screen.": (
        "Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.",
        "Este marco es demasiado antiguo para ceder la pantalla a un plugin."),
    "a scare is already running": ("es läuft schon ein Schreck", "ya hay un susto en curso"),
    "chance said no": ("der Zufall sagte nein", "el azar dijo que no"),
    "not Halloween season": ("nicht in der Halloween-Zeit", "fuera de la temporada de Halloween"),
    "pause after the last scare": ("Pause nach dem letzten Schreck", "pausa tras el último susto"),
    "quiet hours": ("Ruhezeit", "horas de silencio"),
    "switched off": ("ausgeschaltet", "desactivado"),
    "test": ("Probe", "prueba"),
    "“Allow takeover” is off for Halloween Scare on the Plugins page. Switch it on, otherwise nothing can be shown.": (
        "„Allow takeover“ ist für Halloween Scare auf der Plugins-Seite aus. Schalte es ein, sonst kann nichts "
        "angezeigt werden.",
        "«Allow takeover» está desactivado para Halloween Scare en la página de plugins. Actívalo; si no, no se "
        "puede mostrar nada."),
}


def t(lang, template, **values):
    text = template
    if lang in LANGUAGES and lang != "en":
        row = _TEXTS.get(template)
        if row:
            text = row[LANGUAGES.index(lang) - 1]
    try:
        return text.format(**values) if values else text
    except (KeyError, IndexError, ValueError):
        return text
