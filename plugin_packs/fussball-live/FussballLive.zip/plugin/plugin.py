#!/usr/bin/env python3
"""Fußball Live - der Plugin-Teil des Fußball-Live-Pakets.

Die Szene "fussball-live" zeichnet Spieltage und Tabellen. Dieses Plugin
macht, was eine Szene nicht kann:

- Es liest die Ergebnisse der gewählten Ligen (leagues.py) in seinem eigenen
  Takt: jede Minute, solange ein Spiel läuft, sonst seltener. Vereinswappen
  werden einmal geladen und lokal ausgeliefert.
- Es holt die Szene alle X Minuten für Y Sekunden über die laufende
  Playlist (Display-Takeover) und gibt den Bildschirm danach zurück. Dazu
  wahlweise nur an Spieltagen, nur bei laufenden Spielen oder bei einem Tor.
- Show, Cancel und Toggle machen dasselbe von Hand oder aus einer
  Automation.
- Alle Einstellungen liegen auf einer Seite (Plugins > Fußball Live öffnen).

Die Szene erreicht die Seite dieses Plugins über den Proxy der Weboberfläche
auf :8003 (der Proxy der Engine lehnt lokale Adressen ab), wie bei Live
Flights. Antwortet das Plugin nicht, liest die Szene die Quellen selbst.
"""

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import leagues  # noqa: E402
import texts  # noqa: E402

try:
    # Umgeht einen Dynaframe-Fehler, der einen Quick Mix nach einem Takeover
    # gestoppt lassen kann (siehe dort). Ohne die Datei läuft alles weiter.
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None

plugin = create_plugin()

PLUGIN_ID = "FussballLive"
DISPLAY_NAME = "Fußball Live"
SCENE_ID = "fussball-live"       # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"   # Einstellungen und Zustand; bleibt bei Updates
CACHE_DIR = PLUGIN_DIR / "cache"  # Wappen; darf gelöscht werden
LOGO_DIR = CACHE_DIR / "logos"

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30
SERVICE_STATUS = f"{PLUGIN_ID}.Status"

EVENT_GOAL = "fussball_tor"
EVENT_STARTED = "fussball_anzeige_gestartet"
EVENT_ENDED = "fussball_anzeige_beendet"


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        pass
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def ensure_dirs():
    for folder in (DATA_DIR, CACHE_DIR, LOGO_DIR):
        folder.mkdir(parents=True, exist_ok=True)


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    ensure_dirs()
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=1, ensure_ascii=False)
    temp.replace(path)


def local_text(epoch):
    if not epoch:
        return ""
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Einstellungen (alle auf der Plugin-Seite; das Manifest deklariert keine)
# --------------------------------------------------------------------------

SETTINGS = {
    "Leagues":        {"kind": "leagues", "default": list(leagues.DEFAULT_LEAGUES)},
    "PageSeconds":    {"kind": "number", "default": 20, "min": 5, "max": 300},
    "ShowTable":      {"kind": "bool", "default": True},
    # Wann die Szene von selbst über die Playlist geholt wird.
    "AutoMode":       {"kind": "choice", "default": "always",
                       "options": ["off", "always", "matchday", "live"]},
    "EveryMinutes":   {"kind": "number", "default": 15, "min": 2, "max": 720},
    "ShowForSeconds": {"kind": "number", "default": 60, "min": 10, "max": 3600},
    "ActiveFrom":     {"kind": "number", "default": 8, "min": 0, "max": 23},
    "ActiveTo":       {"kind": "number", "default": 23, "min": 1, "max": 24},
    "GoalTakeover":   {"kind": "bool", "default": False},
    "GoalSeconds":    {"kind": "number", "default": 30, "min": 10, "max": 600},
    # Ton bei einem Tor: Datei aus sounds/ (mitgeliefert) oder data/sounds/ (eigene),
    # Lautstärke 0 = so laut, wie der Rahmen gerade eingestellt ist.
    "GoalSound":      {"kind": "bool", "default": False},
    "GoalSoundFile":  {"kind": "text", "default": "torjubel.wav"},
    "GoalVolume":     {"kind": "number", "default": 0, "min": 0, "max": 100},
    # Die Namen des House Standards, wie in den anderen Szenen-Plugins.
    "MakePlaylist":   {"kind": "bool", "default": False},
    # Sprache der Plugin-Seite, der Hinweise und der Szene.
    "Language":       {"kind": "choice", "default": "de", "options": list(texts.LANGUAGES)},
    # Der eigene Verein: Wappen im Hintergrund, auf Wunsch seine Farben als Akzent.
    "Team":           {"kind": "team", "default": None},
    "TeamColors":     {"kind": "bool", "default": False},
}

SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return list(default) if isinstance(default, list) else default
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "number":
        return max(spec["min"], min(spec["max"], as_int(raw, default)))
    if kind == "choice":
        value = str(raw).strip().lower()
        return value if value in spec["options"] else default
    if kind == "leagues":
        items = raw if isinstance(raw, list) else str(raw).split(",")
        chosen = []  # in der Reihenfolge, die der Nutzer gewählt hat
        for item in items:
            lid = str(item).strip().lower()
            if lid in leagues.LEAGUES and lid not in chosen:
                chosen.append(lid)
        return chosen
    if kind == "team":
        return coerce_team(raw)
    return str(raw)[:200]


def coerce_team(raw):
    """{league, id, name, short, logo, color, alt} oder None (kein Verein)."""
    if not isinstance(raw, dict) or raw.get("league") not in leagues.LEAGUES or not raw.get("name"):
        return None
    logo = str(raw.get("logo") or "")
    return {"league": raw["league"], "id": str(raw.get("id") or "")[:20],
            "name": str(raw["name"])[:80], "short": str(raw.get("short") or raw["name"])[:40],
            "logo": logo[:400] if logo.startswith("https://") else "",
            "color": leagues.hex_color(raw.get("color")), "alt": leagues.hex_color(raw.get("alt"))}


def team_view(values):
    """Der eigene Verein, wie Szene und Plugin-Seite ihn brauchen, oder None."""
    team = values["Team"]
    if not team:
        return None
    accent, ink = leagues.team_accent(team["color"], team["alt"])
    key = logo_key(team["logo"])
    return {"name": team["name"], "short": team["short"], "league": team["league"],
            "logo": f"api/logo/{key}" if key else "", "accent": accent, "accentInk": ink,
            "useColors": bool(values["TeamColors"] and accent)}


_teams_cache = {}
TEAMS_SECONDS = 12 * 3600


def teams_payload(league_id):
    """Vereine einer Liga für die Auswahl. Ohne ESPN die Vereine aus der
    gelesenen Tabelle, dann aber ohne Farben."""
    if league_id not in leagues.TEAM_LEAGUES:
        return {"success": False, "error": "Unbekannte Liga"}
    cached = _teams_cache.get(league_id)
    if cached and now() - cached[0] < TEAMS_SECONDS:
        return {"success": True, "teams": cached[1]}
    try:
        teams = leagues.fetch_teams(league_id)
    except leagues.SourceError as exc:
        plugin.log(f"Vereine {leagues.LEAGUES[league_id]['name']}: {exc}", level="warning")
        with _data_lock:
            table = list((_data.get(league_id) or {}).get("table") or [])
        teams = sorted(({"id": r["team"]["name"][:20], "name": r["team"]["name"], "short": r["team"]["short"],
                         "logo": r["team"]["logo"], "color": "", "alt": ""} for r in table),
                       key=lambda x: x["name"].lower())
        if not teams:
            return {"success": False, "error": tr("Konnte die Vereine nicht laden: {exc}", exc=exc)}
        return {"success": True, "teams": teams, "noColors": True}
    _teams_cache[league_id] = (now(), teams)
    return {"success": True, "teams": teams}


def settings():
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
    return {name: coerce(name, stored.get(name)) for name in SETTINGS}


def tr(template, **values):
    """Ein Text in der eingestellten Sprache (siehe texts.py)."""
    return texts.t(settings()["Language"], template, **values)


def save_settings(changes):
    changed = []
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            value = coerce(name, raw)
            if stored.get(name) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, stored)
    return changed


_state_lock = threading.Lock()


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**fields):
    with _state_lock:
        state = read_json(STATE_FILE, {}) or {}
        if all(k in state and state[k] == v for k, v in fields.items()):
            return state  # nichts Neues, also kein Schreiben auf die SD-Karte
        state.update(fields)
        write_json(STATE_FILE, state)
    return state


# --------------------------------------------------------------------------
# Die Engine auf diesem Rahmen
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "note": ""}


def find_scene():
    """Die installierte Szene. Ihre numerische id braucht ein Playlist-Eintrag."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else
                      tr("Die Szene Fußball Live ist auf der Plugins-Seite ausgeschaltet."))
        return row
    _scene.update(dbId=None, note=tr("Die Szene Fußball Live ist auf diesem Rahmen nicht installiert. "
                                     "Installiere das Fußball-Live-Paket noch einmal."))
    return None


# --------------------------------------------------------------------------
# Ergebnisse
# --------------------------------------------------------------------------

_data_lock = threading.Lock()
# league id -> {"round", "matches", "table", "source", "matchesAt", "tableAt", "error"}
_data = {}
_version = {"n": 0}
_scores = {}   # match id -> (home, away), um Tore zu erkennen
_goals = []    # erkannte Tore, die noch nicht gezeigt wurden


def bump():
    with _data_lock:
        _version["n"] += 1


def any_live(data=None):
    data = _data if data is None else data
    return any(m["state"] == "live" for row in data.values() for m in row.get("matches") or [])


def matchday_today(data=None):
    """Hat eine gewählte Liga heute ein Spiel, oder läuft eines?"""
    data = _data if data is None else data
    today = datetime.now().date()
    for row in data.values():
        for match in row.get("matches") or []:
            if match["state"] == "live":
                return True
            if match["kickoff"] and datetime.fromtimestamp(match["kickoff"]).date() == today:
                return True
    return False


def soon_kickoff(row, within):
    t = now()
    return any(m["state"] == "pre" and 0 <= m["kickoff"] - t <= within for m in row.get("matches") or [])


def started_since_read(row):
    """Ein Spiel, das beim letzten Lesen noch nicht lief, aber laut Anstoßzeit
    seit bis zu drei Stunden läuft oder gerade zu Ende ist."""
    t = now()
    return any(m["state"] == "pre" and m["kickoff"] and 0 <= t - m["kickoff"] <= 3 * 3600
               for m in row.get("matches") or [])


# Bei Live-Spielen alle 20 Sekunden fragen, damit Tore schnell da sind.
# Bremst eine Quelle (HTTP 429/503), eine Viertelstunde lang nur jede Minute.
LIVE_SECONDS = 20
SLOW_LIVE_SECONDS = 60
_slowdown = {"until": 0.0}


def live_seconds():
    return SLOW_LIVE_SECONDS if now() < _slowdown["until"] else LIVE_SECONDS


def matches_due(row):
    """Wie oft eine Liga gelesen wird: alle 20 Sekunden bei Live-Spielen,
    jede Minute kurz vor Anstoß, alle 10 Minuten an Spieltagen, sonst jede
    halbe Stunde."""
    age = now() - (row.get("matchesAt") or 0)
    if row.get("error"):
        # Nach einem Fehler in 2 Minuten neu versuchen, nicht erst im normalen Takt.
        return age >= 120
    if any(m["state"] == "live" for m in row.get("matches") or []):
        return age >= live_seconds()
    if soon_kickoff(row, 600) or started_since_read(row):
        return age >= 60
    if matchday_today({"x": row}):
        return age >= 600
    return age >= 1800


def table_due(row, live):
    """Die Tabelle bei Live-Spielen alle 5 Minuten, an Spieltagen alle 10
    Minuten (Endstände), sonst stündlich."""
    age = now() - (row.get("tableAt") or 0)
    if live:
        return age >= 300
    return age >= (600 if matchday_today({"x": row}) else 3600)


def detect_goals(league_id, matches):
    found = []
    for match in matches:
        key = match["id"]
        score = (match["scoreHome"], match["scoreAway"])
        before = _scores.get(key)
        _scores[key] = score
        if before is None or None in score or None in before or match["state"] != "live":
            continue
        if sum(score) > sum(before):
            found.append({"league": league_id, "match": match, "at": now()})
    return found


def refresh_data(force=False):
    chosen = settings()["Leagues"]
    show_table = settings()["ShowTable"]
    changed = False
    for league_id in chosen:
        with _data_lock:
            row = dict(_data.get(league_id) or {})
        if force or matches_due(row):
            try:
                round_name, matches, source = leagues.fetch_matches(league_id)
                goals = detect_goals(league_id, matches)
                row.update({"round": round_name, "matches": matches, "source": source,
                            "matchesAt": now(), "error": ""})
                if goals:
                    with _data_lock:
                        _goals.extend(goals)
                    for goal in goals:
                        announce_goal(goal)
            except leagues.RateLimited as exc:
                # Alten Stand behalten und erst in einer Minute wieder fragen.
                if now() >= _slowdown["until"]:
                    plugin.log(f"{leagues.LEAGUES[league_id]['name']}: Die Quelle bremst ({exc}). "
                               "Eine Viertelstunde lang nur jede Minute nachfragen.", level="warning")
                _slowdown["until"] = now() + 900
                row["matchesAt"] = now()
            except leagues.SourceError as exc:
                row.update(error=str(exc), matchesAt=now())
                plugin.log(f"{leagues.LEAGUES[league_id]['name']}: {exc}", level="warning")
            changed = True
        live = any(m["state"] == "live" for m in row.get("matches") or [])
        if show_table and leagues.LEAGUES[league_id]["table"] and (force or table_due(row, live)):
            try:
                row.update(table=leagues.fetch_table(league_id), tableAt=now())
            except leagues.SourceError as exc:
                row["tableAt"] = now() - 3000  # in 10 Minuten noch einmal
                plugin.log(f"Tabelle {leagues.LEAGUES[league_id]['name']}: {exc}", level="warning")
            changed = True
        with _data_lock:
            _data[league_id] = row
    with _data_lock:
        for league_id in [k for k in _data if k not in chosen]:
            del _data[league_id]
            changed = True
    if changed:
        bump()
        save_cache()


CACHE_FILE = CACHE_DIR / "results.json"


def save_cache():
    with _data_lock:
        payload = {"data": _data, "scores": {k: list(v) for k, v in _scores.items()}}
    try:
        write_json(CACHE_FILE, payload)
    except OSError as exc:
        plugin.log(f"Konnte die Ergebnisse nicht zwischenspeichern: {exc}", level="warning")


def load_cache():
    """Der letzte Stand, damit die Szene nach einem Neustart sofort etwas
    zeigt. Er wird beim ersten Lesen ersetzt."""
    stored = read_json(CACHE_FILE, {}) or {}
    with _data_lock:
        for key, row in (stored.get("data") or {}).items():
            if key in leagues.LEAGUES and isinstance(row, dict):
                row["matchesAt"] = 0
                row["tableAt"] = 0
                _data[key] = row
        for key, value in (stored.get("scores") or {}).items():
            if isinstance(value, list) and len(value) == 2:
                _scores[key] = tuple(value)


def short_score(match):
    return f"{match['home']['short']} {match['scoreHome']}:{match['scoreAway']} {match['away']['short']}"


def announce_goal(goal):
    match = goal["match"]
    scorer = (match.get("lastGoal") or {}).get("name") or ""
    plugin.log(f"Tor: {short_score(match)}" + (f" ({scorer})" if scorer else ""))
    emit(EVENT_GOAL, liga=leagues.LEAGUES[goal["league"]]["name"], heim=match["home"]["name"],
         gast=match["away"]["name"], stand=f"{match['scoreHome']}:{match['scoreAway']}", torschuetze=scorer)


def emit(event, **data):
    try:
        plugin.emit_event(event, {key: str(value) for key, value in data.items()})
    except Exception as exc:  # pragma: no cover
        plugin.log(f"Konnte das Ereignis {event} nicht senden: {exc}", level="warning")


# ---- Wappen ---------------------------------------------------------------
# Die Szene lädt Wappen über das Plugin: einmal aus dem Netz, danach von der
# SD-Karte. Nur Adressen, die in den Ergebnissen vorkommen, werden geladen.

_logo_urls = {}
LOGO_TYPES = {b"\x89PNG": ("png", "image/png"), b"<svg": ("svg", "image/svg+xml"),
              b"<?xm": ("svg", "image/svg+xml"), b"GIF8": ("gif", "image/gif"),
              b"\xff\xd8\xff": ("jpg", "image/jpeg"), b"RIFF": ("webp", "image/webp")}


def logo_key(url):
    if not url or not str(url).startswith(("https://", "http://")):
        return ""
    key = hashlib.sha1(url.encode("utf-8")).hexdigest()[:20]
    _logo_urls[key] = url
    return key


def logo_type(body):
    head = body[:5].lstrip()
    for magic, kind in LOGO_TYPES.items():
        if head.startswith(magic):
            return kind
    return None


def logo_bytes(key):
    """(body, content type) oder None."""
    if not re.fullmatch(r"[0-9a-f]{20}", key or ""):
        return None
    for path in LOGO_DIR.glob(f"{key}.*"):
        try:
            body = path.read_bytes()
        except OSError:
            continue
        kind = logo_type(body)
        if kind:
            return body, kind[1]
    url = _logo_urls.get(key)
    if not url:
        return None
    try:
        response = requests.get(url, headers={"User-Agent": leagues.HTTP_HEADERS["User-Agent"]},
                                timeout=(8, 15))
    except requests.RequestException:
        return None
    body = response.content or b""
    kind = logo_type(body)
    if response.status_code >= 400 or not kind or len(body) > 1_500_000:
        return None
    ensure_dirs()
    try:
        (LOGO_DIR / f"{key}.{kind[0]}").write_bytes(body)
    except OSError:
        pass
    return body, kind[1]


def with_logo(team):
    key = logo_key(team.get("logo"))
    return dict(team, logo=f"api/logo/{key}" if key else "")


def snapshot():
    """Alles, was die Szene braucht. Unter /api/scene abgerufen."""
    values = settings()
    with _data_lock:
        data = {k: dict(v) for k, v in _data.items()}
        version_n = _version["n"]
    pages = []
    for league_id in values["Leagues"]:
        league = leagues.LEAGUES[league_id]
        row = data.get(league_id) or {}
        matches = [dict(m, home=with_logo(m["home"]), away=with_logo(m["away"]))
                   for m in row.get("matches") or []]
        table = None
        if values["ShowTable"] and league["table"] and row.get("table"):
            table = [dict(r, team=with_logo(r["team"])) for r in row["table"]]
        pages.append({"id": league_id, "name": leagues.display_name(league_id, values["Language"]), "color": league["color"],
                      "round": texts.round_name(values["Language"], row.get("round") or ""),
                      "matches": matches, "table": table,
                      "source": row.get("source") or "", "updatedAt": row.get("matchesAt") or 0,
                      "error": row.get("error") or ""})
    with _takeover_lock:
        focus = None
        if _focus["value"] and (_takeover["handle"] is not None or now() < _focus["until"]):
            focus = dict(_focus["value"], id=_focus["id"])
    return {"version": version_n, "at": now(), "pageSeconds": values["PageSeconds"],
            "focus": focus, "pages": pages, "lang": values["Language"], "team": team_view(values)}


# --------------------------------------------------------------------------
# Playlists: die Takeover-Playlist und auf Wunsch eine für den Besitzer
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = "Fußball Live (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Wird vom Plugin Fußball Live abgespielt, wenn es den Bildschirm "
                                 "übernimmt. Bleibt ausgeschaltet, damit es nicht im Quick Mix landet. "
                                 "Das Plugin legt sie neu an, wenn sie gelöscht wird.")
OWNER_PLAYLIST_NAME = "Fußball Live"
OWNER_PLAYLIST_DESCRIPTION = ("Vom Plugin Fußball Live angelegt. Ausschalten, planen oder löschen "
                              "wie jede Playlist.")
TAKEOVER_ITEM_SECONDS = 6 * 3600  # das Plugin beendet die Anzeige lange vorher
SCENE_SECONDS = 60                # recommendedDurationSec in scene.dynamic

_playlists = {"at": 0.0, "takeoverId": None, "note": "", "ownerNote": ""}
_playlist_lock = threading.Lock()


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    """Hat irgendetwas den Bildschirm? Playlists werden nur angelegt, solange
    nichts ihn hält: der Rahmen baut den Quick Mix nach einem Takeover neu,
    und eine inzwischen angelegte Playlist ändert, was er wiederherstellt."""
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError as exc:
        return exc.status != 404
    return bool(status.get("active"))


def create_playlist(name, description, seconds, enabled):
    created = engine_call("POST", "/playlists", {"name": name, "description": description}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=name))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": seconds})
    if not enabled:
        engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    return playlist_id


def ensure_takeover_playlist():
    """Ein Takeover spielt eine Playlist, keine einzelne Szene. Also: die
    Szene allein, sechs Stunden, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if i.get("dynamicSceneId") == _scene["dbId"]]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    playlist_id = create_playlist(TAKEOVER_PLAYLIST_NAME, TAKEOVER_PLAYLIST_DESCRIPTION,
                                  TAKEOVER_ITEM_SECONDS, enabled=False)
    save_state(takeoverPlaylistId=playlist_id)
    plugin.log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def maintain_owner_playlist(values):
    state = load_state()
    playlist_id = state.get("ownerPlaylistId")
    if playlist_id:
        if get_playlist(playlist_id) is None:
            save_state(ownerPlaylistId=None, ownerPlaylistDeleted=bool(values["MakePlaylist"]))
            if values["MakePlaylist"]:
                save_settings({"MakePlaylist": False})
                plugin.log("Die Playlist Fußball Live wurde gelöscht; sie wird nicht neu angelegt.")
        return ""
    if not values["MakePlaylist"]:
        return ""
    if screen_held():
        return tr("Wartet, bis der Bildschirm wieder frei ist.")
    playlist_id = create_playlist(OWNER_PLAYLIST_NAME, OWNER_PLAYLIST_DESCRIPTION, SCENE_SECONDS, enabled=True)
    save_state(ownerPlaylistId=playlist_id, ownerPlaylistDeleted=False)
    plugin.log(f"Playlist {OWNER_PLAYLIST_NAME} angelegt ({playlist_id}), eingeschaltet.")
    return ""


def maintain_playlists(force=False):
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        find_scene()
        if _scene["dbId"] is None:
            _playlists.update(note=_scene["note"], ownerNote=_scene["note"])
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc)
            plugin.log(_playlists["note"], level="warning")
        try:
            _playlists["ownerNote"] = maintain_owner_playlist(settings())
        except EngineError as exc:
            _playlists["ownerNote"] = tr("Konnte die Playlist Fußball Live nicht pflegen: {exc}", exc=exc)


def owner_playlist_text(values, state):
    if values["MakePlaylist"]:
        if state.get("ownerPlaylistId"):
            return tr("Angelegt: die Playlist Fußball Live steht unter Playlists.")
        return _playlists["ownerNote"] or tr("Noch nicht angelegt; das passiert innerhalb einer Minute.")
    if state.get("ownerPlaylistDeleted"):
        return tr("Die Playlist wurde gelöscht, deshalb steht das wieder auf Nein.")
    if state.get("ownerPlaylistId"):
        return tr("Die früher angelegte Playlist steht noch unter Playlists; das Plugin pflegt sie nicht mehr.")
    return ""


# --------------------------------------------------------------------------
# Den Bildschirm übernehmen und zurückgeben
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
ENDED_REASON = {"released": "abgebrochen", "expired": "abgelaufen", "failed": "fehlgeschlagen",
                "preempted": "verdraengt"}

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "reason": None, "since": None, "until": None, "started": False,
             "token": 0, "note": "", "focus": None, "deadline": None}
# Die Liga, mit der die Szene beginnen soll. Gesetzt, bevor der Rahmen um den
# Bildschirm gebeten wird: die Szene lädt und fragt schon, bevor
# acquire_display_session zurückkommt. "id" sagt der Szene, dass es eine
# neue Übernahme ist, auch wenn sie schon lief.
_focus = {"value": None, "until": 0.0, "id": 0}
_schedule = {"nextAt": 0.0, "lastAt": 0.0}
_stop_requested = threading.Event()
_wake = threading.Event()


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform") or {}
    except EngineError:
        return True  # nicht entscheidbar: der Versuch selbst sagt es dann
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Fußball Live ist auf der Plugins-Seite ausgeschaltet.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Fußball Live auf der Plugins-Seite aus, deshalb kann es "
                  "den Bildschirm nicht übernehmen.")
    return ""


def display_is_off():
    """Nur wahr, wenn der Rahmen sagt, dass der Bildschirm aus ist. Fußball
    weckt keinen Bildschirm."""
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def scene_turn_on_screen():
    """Läuft die Szene gerade als normaler Playlist-Eintrag? Ein Takeover
    darüber lässt den Rahmen danach gestoppt zurück (bekannter Fehler), und
    die Ergebnisse sind ohnehin zu sehen."""
    if _scene["dbId"] is None:
        return False
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", read_timeout=5) or {}
    except EngineError:
        return False
    item = status.get("currentItem") or {}
    return bool(status.get("isRunning") and item.get("dynamicSceneId") == _scene["dbId"]
                and not same_id(status.get("activePlaylistId"), _playlists["takeoverId"]))


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        plugin.log(text)
    return False


def _on_session_state(handle_or_state):
    """Das SDK ruft das mit dem Handle auf, nicht mit dem neuen Zustand."""
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        started = _takeover["started"]
        _takeover.update(handle=None, reason=None, since=None, until=None, started=False, focus=None,
                         note=tr("Der Rahmen hat die Anzeige beendet ({state}).", state=new_state))
        _focus["value"] = None
    plugin.log(f"Der Rahmen hat Fußball Live beendet: {new_state}.")
    if started:
        emit(EVENT_ENDED, grund=ENDED_REASON.get(new_state, new_state))
    publish_status()
    threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason, token=None):
    """Bildschirm zurückgeben. Mehrfach aufrufbar."""
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        started = _takeover["started"]
        _takeover.update(handle=None, reason=None, since=None, until=None, started=False, focus=None, note="")
        _focus["value"] = None
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:
        plugin.log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", level="warning")
    plugin.log(f"Bildschirm zurückgegeben ({reason}).")
    if started:
        emit(EVENT_ENDED, grund=reason)
    publish_status()
    if reason != "gestoppt":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def _release_after(seconds, token):
    if _stop_requested.wait(max(1, int(seconds))):
        return
    end_takeover("fertig", token)


def show_scene(reason="show", seconds=None, focus=None):
    """Die Szene für `seconds` über alles legen. True, wenn der Rahmen den
    Bildschirm hergegeben hat."""
    if _takeover["handle"] is not None:
        return _note(tr("Fußball Live ist schon auf dem Bildschirm."))
    if not takeover_supported():
        return _note(tr("Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen."))
    if _scene["dbId"] is None:
        find_scene()
    if _scene["dbId"] is None or _scene["note"]:
        return _note(_scene["note"] or tr("Die Szene Fußball Live wurde nicht gefunden."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("Die Takeover-Playlist ist noch nicht angelegt."))
    if scene_turn_on_screen():
        return _note(tr("Fußball Live läuft gerade in deiner Playlist; die Anzeige bleibt so."))
    if display_is_off():
        return _note(tr("Der Bildschirm ist aus. Fußball Live weckt ihn nicht."))
    if reason != "show" and _stop_call["value"] == "" and frame_idle():
        return _note(tr("Auf dem Rahmen läuft keine Playlist. {name} wartet, weil der Rahmen die Anzeige "
                        "danach nicht von selbst beendet.", name=DISPLAY_NAME))
    seconds = int(seconds or settings()["ShowForSeconds"])
    _asked["at"] = now()
    with _takeover_lock:
        _focus["id"] += 1
        _focus.update(value=focus, until=now() + 30)
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             # Die Szene hat ihre eigene Schrift; eine Bildunterschrift stört nur.
             "overlay": {"enabled": False}}
    try:
        handle = plugin.acquire_display_session(
            session_key=reason, state=state, display_name=DISPLAY_NAME,
            # Etwas länger als gewünscht: der Timer unten ist das ordentliche
            # Ende, die Grenze der Engine greift nur, wenn das Plugin stirbt.
            max_duration_seconds=seconds + 10, wake_if_off=False)
    except Exception as exc:
        return _note(f"Konnte Fußball Live nicht anzeigen: {exc}")
    if handle is None:
        _focus["value"] = None
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    t = now()
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, reason=reason, since=t, until=t + seconds, started=False,
                         note="", focus=focus, deadline=t + seconds + 10)
    try:
        handle.on_state_change(_on_session_state)
    except Exception:
        pass
    try:
        if not handle.wait_until_active(timeout=10):
            end_takeover("fehlgeschlagen", token)
            return _note(tr("Der Rahmen hat Fußball Live nicht rechtzeitig angezeigt."))
    except Exception as exc:
        end_takeover("fehlgeschlagen", token)
        return _note(f"Konnte Fußball Live nicht anzeigen: {exc}")
    with _takeover_lock:
        if _takeover["token"] != token or _takeover["handle"] is None:
            return False
        _takeover["started"] = True
    emit(EVENT_STARTED, grund=reason)
    plugin.log(f"Fußball Live für {seconds} Sekunden auf dem Bildschirm ({reason}).")
    publish_status()
    threading.Thread(target=_release_after, args=(seconds, token),
                     name=f"{PLUGIN_ID}-timer", daemon=True).start()
    return True


def retarget_to_goal(goal, seconds):
    """Ein Tor, während Fußball Live schon auf dem Bildschirm ist: die Szene
    springt auf die Seite des Tores, und die Anzeige läuft ab jetzt
    `seconds` lang. Reicht die Grenze der Engine dafür nicht, wird der
    Bildschirm zurückgegeben und neu geholt."""
    focus = {"league": goal["league"], "match": goal["match"]["id"]}
    t = now()
    with _takeover_lock:
        if _takeover["handle"] is None:
            return False
        fits = (_takeover["deadline"] or 0) - 5 >= t + seconds
        if fits:
            _takeover["token"] += 1
            token = _takeover["token"]
            _focus["id"] += 1
            _focus.update(value=focus, until=t + 30)
            _takeover.update(reason="tor", until=t + seconds, focus=focus)
    if not fits:
        end_takeover("tor")
        return show_scene("tor", seconds, focus=focus)
    plugin.log(f"Tor: Fußball Live springt auf {leagues.LEAGUES[goal['league']]['name']} "
               f"und bleibt {seconds} Sekunden.")
    publish_status()
    threading.Thread(target=_release_after, args=(seconds, token),
                     name=f"{PLUGIN_ID}-timer", daemon=True).start()
    return True


def cancel_scene():
    stop_sound()
    if not end_takeover("abgebrochen"):
        _note(tr("Fußball Live hatte den Bildschirm nicht."))


def toggle_scene():
    if _takeover["handle"] is not None:
        cancel_scene()
    else:
        show_scene("show")


_action_lock = threading.Lock()


def run_action(name):
    """Show, Cancel und Toggle antworten sofort und arbeiten in einem Thread."""
    work = {"show": lambda: show_scene("show"), "cancel": cancel_scene, "toggle": toggle_scene}[name]
    showing = _takeover["handle"] is not None
    asking, returning = tr("Bitte den Rahmen um den Bildschirm."), tr("Gebe den Bildschirm zurück.")
    message = {"show": asking, "cancel": returning, "toggle": returning if showing else asking}[name]

    def run():
        with _action_lock:
            try:
                work()
            except Exception as exc:  # pragma: no cover
                _note(tr("{name} hat nicht geklappt: {exc}", name=name, exc=exc))
    threading.Thread(target=run, name=f"{PLUGIN_ID}-{name}", daemon=True).start()
    return {"success": True, "message": message}


# ---- Wenn vorher nichts lief -----------------------------------------------
# Lief vor dem Takeover keine Playlist, stellt die Engine nach dem Zurückgeben
# dieses "nichts" nicht wieder her: die Takeover-Playlist läuft einfach weiter
# (Jans Rahmen, 2026-10-24). Dann hält das Plugin sie selbst an. Ein Aufruf
# dafür ist nicht dokumentiert; probiert werden die naheliegenden, und der
# erste, der wirkt, wird bis zum nächsten Neustart gemerkt. Wirkt keiner,
# wartet die regelmäßige Anzeige, solange keine Playlist läuft.
STOP_CALLS = (("POST", "/slideshow/stop"), ("POST", "/playback/stop"))
_stop_call = {"value": None}  # None = noch nicht probiert, "" = keiner wirkt
_asked = {"at": 0.0}  # wann zuletzt um den Bildschirm gebeten wurde


def frame_idle():
    """True, wenn auf dem Rahmen gerade keine Playlist läuft."""
    try:
        status = engine_call("GET", "/slideshow/status", read_timeout=5) or {}
    except EngineError:
        return False
    return not status.get("isRunning")


def _takeover_playlist_left_running(log=False):
    """Läuft die Takeover-Playlist, obwohl niemand den Bildschirm hält?"""
    if _takeover["handle"] is not None or not _playlists["takeoverId"] or now() - _asked["at"] < 30:
        return False
    try:
        status = engine_call("GET", "/slideshow/status", read_timeout=5) or {}
    except EngineError:
        return False
    if log:
        plugin.log(f"Nach dem Zurückgeben: läuft={status.get('isRunning')}, "
                   f"Playlist={status.get('activePlaylistId')} ({status.get('playlistName')}).")
    if not (status.get("isRunning") and same_id(status.get("activePlaylistId"), _playlists["takeoverId"])):
        return False
    try:
        sessions = engine_call("GET", "/display-sessions/status", read_timeout=5) or {}
    except EngineError as exc:
        return exc.status == 404  # ältere Engine ohne diese Abfrage
    return not sessions.get("active")


def stop_leftover_takeover(first_wait=3):
    """Läuft die Takeover-Playlist ohne Takeover weiter, anhalten. Nach jedem
    Zurückgeben und in jedem Durchlauf, denn auf Jans Rahmen kam sie erst
    später wieder (2026-10-24). True, wenn sie weiterlief."""
    if first_wait and _stop_requested.wait(first_wait):
        return False
    if first_wait:
        _takeover_playlist_left_running(log=True)
    seen = 0
    for _ in range(4):  # zweimal hintereinander gesehen, damit ein langsames Zurückschalten Zeit hat
        if not _takeover_playlist_left_running():
            return False
        seen += 1
        if seen >= 2:
            break
        if _stop_requested.wait(1):
            return False
    calls = list(STOP_CALLS)
    known = _stop_call["value"]
    if known:
        calls.sort(key=lambda call: " ".join(call) != known)
    for method, path in calls:
        try:
            engine_call(method, path, read_timeout=10)
        except EngineError as exc:
            plugin.log(f"Anhalten mit {method} {path} ging nicht: {exc}")
            continue
        if _stop_requested.wait(2):
            return True
        if not _takeover_playlist_left_running():
            _stop_call["value"] = f"{method} {path}"
            save_state(playbackStalled="")
            plugin.log(f"Vor {DISPLAY_NAME} lief keine Playlist; die Takeover-Playlist wurde mit "
                       f"{method} {path} angehalten.")
            return True
    _stop_call["value"] = ""
    message = tr("Vor {name} lief auf dem Rahmen keine Playlist, und der Rahmen hat die Anzeige danach "
                 "nicht beendet. Wähle auf der Startseite des Rahmens eine Playlist. Solange keine "
                 "Playlist läuft, kommt {name} nicht mehr von selbst.", name=DISPLAY_NAME)
    save_state(playbackStalled=message)
    plugin.log(message, level="warning")
    return True


def check_playback_resumed():
    if stop_leftover_takeover():
        return
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log,
                                                    stop_event=_stop_requested)
        if outcome == "not-requested":
            save_state(playbackStalled="")
            return
    elif _stop_requested.wait(12):
        return
    if _stop_requested.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
    except EngineError:
        return
    if status.get("isRunning") or _takeover["handle"] is not None:
        save_state(playbackStalled="")
        return
    message = tr("Der Rahmen ist nach Fußball Live nicht zu deiner Playlist zurückgekehrt. Starte sie auf "
                 "der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix "
                 "passiert das nicht.")
    save_state(playbackStalled=message)
    plugin.log(message, level="warning")


# ---- Der Zeitplan ----------------------------------------------------------

def in_active_hours(values, moment=None):
    hour = (moment or datetime.now()).hour
    start, end = values["ActiveFrom"], values["ActiveTo"]
    if start == end:
        return True
    if start < end:
        return start <= hour < end
    return hour >= start or hour < end  # über Mitternacht, z.B. 18 bis 2


def auto_wanted(values):
    """(ja/nein, Grund) für die regelmäßige Anzeige."""
    mode = values["AutoMode"]
    if mode == "off":
        return False, tr("Regelmäßige Anzeige ist aus.")
    if not values["Leagues"]:
        return False, tr("Keine Liga gewählt.")
    if not in_active_hours(values):
        return False, tr("Außerhalb von {start}–{end} Uhr.", start=values["ActiveFrom"], end=values["ActiveTo"])
    with _data_lock:
        data = dict(_data)
    if mode == "live" and not any_live(data):
        return False, tr("Gerade läuft kein Spiel.")
    if mode == "matchday" and not matchday_today(data):
        return False, tr("Heute ist in den gewählten Ligen kein Spieltag.")
    return True, ""


_auto = {"note": ""}


def decide_takeover():
    values = settings()
    t = now()
    # Ein Tor geht vor, wenn gewünscht, auch wenn Fußball Live schon zu sehen
    # ist (dann springt die Szene um). Ein Tor, das niemand binnen zwei
    # Minuten zeigen konnte, ist keine Nachricht mehr.
    with _data_lock:
        _goals[:] = [g for g in _goals if t - g["at"] < 120]
    if _takeover["handle"] is not None:
        with _takeover_lock:
            handle = _takeover["handle"]
        if handle is not None and str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        if not (_goals and values["GoalTakeover"]):
            return
        # Ein gerade gezeigtes Tor bekommt erst seine Zeit (bis 20 Sekunden),
        # bevor das nächste kommt.
        shown_at = _focus["until"] - 30  # wann die Szene zuletzt auf ein Tor gesprungen ist
        if _takeover["reason"] == "tor" and t - shown_at < min(20, values["GoalSeconds"]):
            return
        with _data_lock:
            goal = _goals.pop(0) if _goals else None
        if goal is not None:
            retarget_to_goal(goal, values["GoalSeconds"])
        return
    with _data_lock:
        goal = _goals[0] if _goals and _goals[0].get("retryAt", 0) <= t else None
    if goal is not None and values["GoalTakeover"] and in_active_hours(values):
        if show_scene("tor", values["GoalSeconds"], focus={"league": goal["league"], "match": goal["match"]["id"]}):
            with _data_lock:
                if goal in _goals:
                    _goals.remove(goal)
            _schedule["lastAt"] = t
            return
        # Nicht bekommen (anderes Plugin, Bildschirm aus): in 20 Sekunden
        # noch einmal, solange das Tor frisch ist.
        goal["retryAt"] = t + 20
        return
    wanted, why = auto_wanted(values)
    _auto["note"] = why
    if not wanted:
        _schedule["nextAt"] = 0.0
        return
    if not _schedule["nextAt"]:
        # Erste Runde nach dem Start oder nach einer Pause: nicht sofort,
        # sondern eine Minute später, damit der Rahmen fertig starten kann.
        _schedule["nextAt"] = max(t + 60, _schedule["lastAt"] + values["EveryMinutes"] * 60)
    if t < _schedule["nextAt"]:
        return
    if show_scene("zeitplan"):
        _schedule["lastAt"] = t
        _schedule["nextAt"] = t + values["EveryMinutes"] * 60
    else:
        # Nicht bekommen (Bildschirm aus, anderes Plugin, eigene Runde):
        # in zwei Minuten noch einmal versuchen.
        _schedule["nextAt"] = t + 120


# --------------------------------------------------------------------------
# Overlay-Text
# --------------------------------------------------------------------------

_overlay = {"text": None}


def status_line():
    with _data_lock:
        data = {k: dict(v) for k, v in _data.items()}
    live = [m for row in data.values() for m in row.get("matches") or [] if m["state"] == "live"]
    if live:
        scores = " · ".join(short_score(m) for m in live[:4]) + (" …" if len(live) > 4 else "")
        return tr("Live: {scores}", scores=scores)
    upcoming = sorted((m for row in data.values() for m in row.get("matches") or [] if m["state"] == "pre"),
                      key=lambda m: m["kickoff"])
    if upcoming:
        m = upcoming[0]
        when = datetime.fromtimestamp(m["kickoff"]).strftime("%d.%m. %H:%M")
        return tr("Nächstes Spiel: {when} {home} – {away}", when=when, home=m["home"]["short"], away=m["away"]["short"])
    return tr("Keine Spiele")


def publish_status():
    text = status_line()
    if _overlay["text"] == text:
        return
    _overlay["text"] = text
    try:
        plugin.update_overlay_text(SERVICE_STATUS, text)
    except Exception:
        pass


# --------------------------------------------------------------------------
# Die Schleife
# --------------------------------------------------------------------------

TICK_SECONDS = 15
_loop = {"lastCheckAt": None, "lastError": "", "force": False}


def tick(force=False):
    try:
        maintain_playlists(force)
        refresh_data(force)
        if _stop_call["value"] != "":
            stop_leftover_takeover(first_wait=0)
        decide_takeover()
        _loop.update(lastCheckAt=local_text(now()), lastError="")
    except Exception as exc:  # pragma: no cover - die Schleife muss weiterlaufen
        _loop["lastError"] = str(exc)
        plugin.log(f"Durchlauf fehlgeschlagen: {exc}", level="error")
    publish_status()


def main_loop():
    _stop_requested.wait(3)
    while not _stop_requested.is_set():
        _wake.clear()
        force, _loop["force"] = _loop["force"], False
        tick(force)
        # Bei Live-Spielen öfter, damit die 20 Sekunden auch eingehalten werden.
        _wake.wait(5 if any_live() else TICK_SECONDS)


def check_now():
    _loop["force"] = True
    _wake.set()
    return {"success": True, "message": tr("Lese die Ergebnisse jetzt neu.")}


# --------------------------------------------------------------------------
# Die Plugin-Seite und die Daten für die Szene
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


# --------------------------------------------------------------------------
# Ton bei einem Tor
# --------------------------------------------------------------------------
# Gespielt vom Plugin, nicht von der Szene: der Browser eines Rahmens, den
# niemand angefasst hat, darf oft keinen Ton machen. Die Szene sagt dem Plugin,
# wann die Seite mit dem Tor fertig auf dem Bildschirm ist (/api/scene/ready),
# erst dann kommt der Ton. Spieler und Lautstärke wie bei FireWatch.

BUILTIN_SOUNDS = PLUGIN_DIR / "sounds"
OWN_SOUNDS = DATA_DIR / "sounds"   # bleibt bei Updates
SOUND_TYPES = {".wav": "audio/wav", ".ogg": "audio/ogg", ".oga": "audio/ogg", ".flac": "audio/flac",
               ".mp3": "audio/mpeg"}
SOUND_MAX_BYTES = 5 * 1024 * 1024
SOUND_NAME = re.compile(r"[^A-Za-z0-9ÄÖÜäöüß _.()-]+")
_sound = {"playedFor": 0, "note": "", "process": None}
_sound_lock = threading.Lock()


def sound_files():
    """[{name, own}] aller Töne; eigene zuerst nach Name, dann die mitgelieferten."""
    found = []
    for folder, own in ((OWN_SOUNDS, True), (BUILTIN_SOUNDS, False)):
        try:
            files = sorted(p for p in folder.iterdir() if p.is_file() and p.suffix.lower() in SOUND_TYPES)
        except OSError:
            continue
        found += [{"name": p.name, "own": own} for p in files]
    return found


def sound_path(name):
    name = Path(str(name or "")).name
    for folder in (OWN_SOUNDS, BUILTIN_SOUNDS):
        path = folder / name
        if name and path.is_file() and path.suffix.lower() in SOUND_TYPES:
            return path
    return None


def looks_like_sound(data):
    return (data[:4] == b"RIFF" and data[8:12] == b"WAVE") or data[:4] in (b"OggS", b"fLaC") \
        or data[:3] == b"ID3" or (len(data) > 1 and data[0] == 0xFF and data[1] & 0xE0 == 0xE0)


def add_sound(filename, data):
    stem, suffix = os.path.splitext(Path(str(filename or "")).name)
    suffix = suffix.lower()
    if suffix not in SOUND_TYPES:
        return {"success": False, "error": tr("Bitte eine WAV-, MP3-, OGG- oder FLAC-Datei.")}
    if not data or len(data) > SOUND_MAX_BYTES or not looks_like_sound(data):
        return {"success": False, "error": tr("Das ist keine Tondatei bis 5 MB.")}
    stem = SOUND_NAME.sub("", stem).strip(" .")[:60] or "ton"
    name = stem + suffix
    if (BUILTIN_SOUNDS / name).exists():
        name = f"{stem} (eigener){suffix}"
    OWN_SOUNDS.mkdir(parents=True, exist_ok=True)
    (OWN_SOUNDS / name).write_bytes(data)
    plugin.log(f"Eigener Ton {name} gespeichert ({len(data)} Bytes).")
    save_settings({"GoalSoundFile": name})
    return {"success": True, "name": name}


def delete_sound(name):
    path = OWN_SOUNDS / Path(str(name or "")).name
    if not path.is_file():
        return {"success": False, "error": tr("Nur eigene Töne lassen sich löschen.")}
    path.unlink()
    if settings()["GoalSoundFile"] == path.name:
        save_settings({"GoalSoundFile": SETTINGS["GoalSoundFile"]["default"]})
    return {"success": True}


def player_commands(path):
    """Die Spieler, die es auf dem Rahmen gibt, passend zur Dateiart."""
    suffix = path.suffix.lower()
    options = [("pw-play", []), ("paplay", [])]
    if suffix == ".wav":
        options.append(("aplay", ["-q"]))
    if suffix == ".mp3":
        options.insert(0, ("mpg123", ["-q"]))
    options += [("ffplay", ["-nodisp", "-autoexit", "-loglevel", "error"]), ("mpv", ["--no-video", "--really-quiet"])]
    commands = []
    for name, args in options:
        tool = shutil.which(name)
        if tool:
            commands.append([tool, *args, str(path)])
    return commands


def sound_environment():
    """Der Rahmen startet Plugins ohne XDG_RUNTIME_DIR; ohne finden pw-play
    und paplay den Tondienst nicht (gemessen von FireWatch)."""
    env = dict(os.environ)
    env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
    return env


def run_player(path):
    """Eine Datei mit dem ersten Spieler, der es schafft. "" oder der Fehler."""
    said = tr("Kein Abspielprogramm auf dem Rahmen gefunden.")
    for command in player_commands(path):
        try:
            process = subprocess.Popen(command, env=sound_environment(),
                                       stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        except OSError as exc:
            said = f"{Path(command[0]).name}: {exc}"
            continue
        _sound["process"] = process
        try:
            _, errors = process.communicate(timeout=60)
        except subprocess.TimeoutExpired:
            process.kill()
            _, errors = process.communicate()
        finally:
            _sound["process"] = None
        if process.returncode == 0 or process.returncode < 0:
            return ""
        said = f"{Path(command[0]).name}: " + \
            ((errors or b"").decode("utf-8", "replace").strip()[:160] or str(process.returncode))
    return said


def stop_sound():
    process = _sound.get("process")
    if process is not None:
        try:
            process.terminate()
        except OSError:
            pass


# Der Tondienst selbst (PipeWire) kann stumm sein, während die Engine
# "muted": false meldet (Jans Rahmen, 2026-10-27: HDMI-Ausgang stumm, Ton
# kam nie an, die Spieler meldeten trotzdem Erfolg). Deshalb wird der
# Ausgang für den Ton auch direkt mit wpctl laut gestellt und danach wieder
# so gesetzt, wie er war.
SINK = "@DEFAULT_AUDIO_SINK@"


def sink_state():
    """(Lautstärke 0.0-1.5, stumm) des Ausgangs laut wpctl, oder None."""
    tool = shutil.which("wpctl")
    if not tool:
        return None
    try:
        done = subprocess.run([tool, "get-volume", SINK], env=sound_environment(),
                              capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return None
    match = re.search(r"Volume:\s*([0-9.]+)", done.stdout or "")
    if done.returncode != 0 or not match:
        return None
    return float(match.group(1)), "MUTED" in done.stdout


def set_sink(volume=None, muted=None):
    tool = shutil.which("wpctl")
    if not tool:
        return
    commands = []
    if volume is not None:
        commands.append([tool, "set-volume", SINK, f"{max(0.0, min(1.0, volume)):.2f}"])
    if muted is not None:
        commands.append([tool, "set-mute", SINK, "1" if muted else "0"])
    for command in commands:
        try:
            subprocess.run(command, env=sound_environment(), capture_output=True, timeout=10)
        except (OSError, subprocess.TimeoutExpired) as exc:
            plugin.log(f"wpctl ging nicht: {exc}", level="warning")


def repair_sink():
    """Den Ausgang so zurückstellen, wie er vor dem Ton war (auch nach einem
    Neustart mitten im Ton)."""
    saved = load_state().get("sinkBefore")
    if not isinstance(saved, dict):
        return
    set_sink(volume=saved.get("volume"), muted=bool(saved.get("muted")))
    save_state(sinkBefore=None)


def frame_volume():
    """(Lautstärke 0-100 oder None, stumm oder None), wie der Rahmen sie meldet."""
    try:
        body = engine_call("GET", "/api/v1/system/volume", read_timeout=10) or {}
    except EngineError:
        return None, None
    if not isinstance(body, dict):
        return None, None
    level = next((body[k] for k in ("value", "volume", "level") if isinstance(body.get(k), (int, float))), None)
    muted = next((body[k] for k in ("muted", "isMuted", "mute") if isinstance(body.get(k), bool)), None)
    return level, muted


def repair_volume():
    """Die Lautstärke des Rahmens zurückstellen, aber nur, wenn sie noch die ist,
    die das Plugin gesetzt hat (auch nach einem Neustart mitten im Ton)."""
    saved = load_state().get("volumeBefore")
    if not isinstance(saved, dict):
        return
    level, muted = frame_volume()
    try:
        if level is not None and int(level) == int(saved.get("set", -1)) and saved.get("volume") is not None:
            engine_call("POST", "/api/v1/system/volume", {"value": int(saved["volume"])}, read_timeout=10)
        if saved.get("muted") is True and muted is False:
            engine_call("POST", "/api/v1/system/mute", {"value": True}, read_timeout=10)
    except EngineError as exc:
        plugin.log(f"Konnte die Lautstärke nicht zurückstellen: {exc}", level="warning")
    save_state(volumeBefore=None)


def play_sound(name=None):
    """Den gewählten Ton einmal spielen, in der eingestellten Lautstärke. Blockiert."""
    values = settings()
    path = sound_path(name or values["GoalSoundFile"])
    if path is None:
        _sound["note"] = tr("Der Ton {name} ist nicht mehr da.", name=name or values["GoalSoundFile"])
        plugin.log(_sound["note"], level="warning")
        return False
    if not _sound_lock.acquire(blocking=False):
        return False  # es läuft schon einer
    try:
        if values["GoalVolume"] > 0:
            level, muted = frame_volume()
            if level is not None:
                save_state(volumeBefore={"volume": level, "muted": muted, "set": values["GoalVolume"]})
                engine_call("POST", "/api/v1/system/volume", {"value": values["GoalVolume"]}, read_timeout=10)
                if muted:
                    engine_call("POST", "/api/v1/system/mute", {"value": False}, read_timeout=10)
        sink = sink_state()
        if sink is not None:
            save_state(sinkBefore={"volume": sink[0], "muted": sink[1]})
            wanted = values["GoalVolume"] / 100 if values["GoalVolume"] > 0 else None
            set_sink(volume=wanted, muted=False)
        plugin.log(f"Spiele {path.name} (Lautstärke {values['GoalVolume'] or 'wie eingestellt'}, "
                   f"Ausgang vorher {'stumm' if sink and sink[1] else 'an' if sink else 'unbekannt'}"
                   f"{f', {round(sink[0] * 100)} %' if sink else ''}).")
        problem = run_player(path)
        if problem:
            plugin.log(f"Konnte den Ton nicht abspielen: {problem}", level="warning")
        _sound["note"] = tr("Konnte den Ton nicht abspielen ({problem}).", problem=problem) if problem else ""
        return not problem
    except (OSError, EngineError) as exc:
        _sound["note"] = tr("Konnte den Ton nicht abspielen ({problem}).", problem=exc)
        plugin.log(_sound["note"], level="warning")
        return False
    finally:
        repair_sink()
        repair_volume()
        _sound_lock.release()


def scene_ready(focus_id):
    """Die Szene zeigt die Seite des Tores fertig an. Einmal je Tor-Anzeige."""
    values = settings()
    with _takeover_lock:
        ours = (values["GoalSound"] and _takeover["handle"] is not None and _takeover["reason"] == "tor"
                and str(_focus["id"]) == str(focus_id) and _sound["playedFor"] != _focus["id"])
        if ours:
            _sound["playedFor"] = _focus["id"]
    if not ours:
        return False
    threading.Thread(target=play_sound, name=f"{PLUGIN_ID}-sound", daemon=True).start()
    return True


def test_sound(name):
    if sound_path(name) is None:
        return {"success": False, "error": tr("Der Ton {name} ist nicht mehr da.", name=name)}
    threading.Thread(target=play_sound, args=(name,), name=f"{PLUGIN_ID}-sound", daemon=True).start()
    return {"success": True, "message": tr("Spiele {name} auf dem Rahmen.", name=name)}


def state_payload():
    values = settings()
    state = load_state()
    with _data_lock:
        data = {k: dict(v) for k, v in _data.items()}
    with _takeover_lock:
        takeover = {"active": _takeover["handle"] is not None, "reason": _takeover["reason"],
                    "until": local_text(_takeover["until"]), "note": _takeover["note"]}
    rows = []
    for league_id in values["Leagues"]:
        row = data.get(league_id) or {}
        matches = row.get("matches") or []
        rows.append({"id": league_id, "name": leagues.display_name(league_id, values["Language"]),
                     "round": texts.round_name(values["Language"], row.get("round") or ""),
                     "source": row.get("source") or "",
                     "matches": len(matches), "live": sum(1 for m in matches if m["state"] == "live"),
                     "at": local_text(row.get("matchesAt")), "error": row.get("error") or ""})
    return {
        "success": True,
        "version": version(),
        "settings": values,
        "leagues": [{"id": k, "name": leagues.display_name(k, values["Language"]), "table": v["table"]}
                    for k, v in leagues.LEAGUES.items()],
        "sources": rows,
        "status": status_line(),
        "scene": {"found": _scene["dbId"] is not None, "note": _scene["note"]},
        "takeover": takeover,
        "permission": takeover_permission_note(),
        "next": local_text(_schedule["nextAt"]) if _schedule["nextAt"] else "",
        "autoNote": _auto["note"],
        "ownerPlaylist": owner_playlist_text(values, state),
        "lastCheckAt": _loop["lastCheckAt"],
        "lastError": _loop["lastError"] or state.get("playbackStalled") or "",
        "theme": {"id": theme_id()},
        "team": team_view(values),
        "sounds": sound_files(),
        "soundNote": _sound["note"],
        "teamLeagues": [{"id": k, "name": leagues.display_name(k, values["Language"])} for k in leagues.TEAM_LEAGUES],
    }


def settings_saved(changed):
    if "MakePlaylist" in changed:
        if settings()["MakePlaylist"]:
            save_state(ownerPlaylistDeleted=False)
        threading.Thread(target=maintain_playlists, kwargs={"force": True}, daemon=True).start()
    if set(changed) & {"Leagues", "ShowTable"}:
        check_now()
    if "Language" in changed:
        bump()  # die Szene holt sich die Daten mit der neuen Sprache
        publish_status()
    if set(changed) & {"AutoMode", "EveryMinutes", "ActiveFrom", "ActiveTo"}:
        _schedule["nextAt"] = 0.0
    bump()
    _wake.set()


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über :8003.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        """Den ganzen Body lesen: ungelesene Bytes würden auf einer offenen
        Verbindung zum Anfang der nächsten Anfrage."""
        length = as_int(self.headers.get("Content-Length"), 0)
        if length > SOUND_MAX_BYTES + 65536:
            self.close_connection = True  # zu groß: nicht lesen, Verbindung schließen
            self._raw_body = None
            return
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(snapshot(), cors=True)
                return
            if path == "/api/scene/ready":
                focus_id = (parse_qs(urlparse(self.path).query).get("focus") or [""])[0]
                self._json({"success": True, "sound": scene_ready(focus_id)}, cors=True)
                return
            if path == "/api/teams":
                league_id = (parse_qs(urlparse(self.path).query).get("league") or [""])[0]
                self._json(teams_payload(league_id))
                return
            if path.startswith("/api/logo/"):
                found = logo_bytes(path.rsplit("/", 1)[-1])
                if found is None:
                    self._json({"success": False, "error": "Kein Wappen"}, 404, cors=True)
                else:
                    self._send(found[0], found[1], cache="max-age=604800", cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                changed = save_settings(self._body())
                if changed:
                    settings_saved(changed)
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(check_now())
                return
            if path == "/api/sounds":
                if self._raw_body is None:
                    self._json({"success": False, "error": tr("Das ist keine Tondatei bis 5 MB.")}, 413)
                    return
                name = (parse_qs(urlparse(self.path).query).get("name") or [""])[0]
                self._json(add_sound(name, self._raw_body))
                return
            if path == "/api/sounds/delete":
                self._json(delete_sound(self._body().get("name")))
                return
            if path == "/api/sounds/test":
                self._json(test_sound(self._body().get("name") or settings()["GoalSoundFile"]))
                return
            if path in ("/api/show", "/api/cancel", "/api/toggle"):
                self._json(run_action(path.rsplit("/", 1)[-1]))
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    ensure_dirs()
    plugin.log(f"Starte {PLUGIN_ID} {version()}")
    load_cache()

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: check_now())
    plugin.on_action("show", lambda _context=None: run_action("show"))
    plugin.on_action("cancel", lambda _context=None: run_action("cancel"))
    plugin.on_action("toggle", lambda _context=None: run_action("toggle"))

    start_studio()
    threading.Thread(target=lambda: (repair_sink(), repair_volume()), daemon=True).start()
    publish_status()
    plugin.connect_sse()
    plugin.ready()

    threading.Thread(target=main_loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    end_takeover("gestoppt")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    plugin.log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
