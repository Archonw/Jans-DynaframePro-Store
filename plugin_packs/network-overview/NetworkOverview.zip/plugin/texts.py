"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    # Status auf der Plugin-Seite
    "Ausgeschaltet": ("Switched off", "Desactivado"),
    "Noch nicht eingerichtet": ("Not set up yet", "Aún sin configurar"),
    "Lädt …": ("Loading …", "Cargando …"),
    "Verbunden um {time}": ("Connected at {time}", "Conectado a las {time}"),
    "Fehler: {code}": ("Error: {code}", "Error: {code}"),
    "Keine Verbindung. Stimmt die Adresse?": ("No connection. Is the address right?",
                                            "Sin conexión. ¿Es correcta la dirección?"),
    "Keine Antwort (Zeitüberschreitung).": ("No answer (timeout).", "Sin respuesta (tiempo agotado)."),
    "Zertifikatsfehler bei https.": ("Certificate error with https.", "Error de certificado con https."),
    "Der Server meldet einen Fehler.": ("The server reports an error.", "El servidor informa de un error."),
    "Anmeldung abgelehnt. Stimmt das Passwort?": ("Login refused. Is the password right?",
                                                 "Inicio de sesión rechazado. ¿Es correcta la contraseña?"),
    "Pi-hole verlangt ein Passwort.": ("Pi-hole asks for a password.", "Pi-hole pide una contraseña."),
    "Pi-hole hat zu viele offene Sitzungen. Es geht gleich von selbst weiter.": (
        "Pi-hole has too many open sessions. It continues by itself shortly.",
        "Pi-hole tiene demasiadas sesiones abiertas. Seguirá solo en breve."),
    "Unter dieser Adresse antwortet kein Pi-hole.": ("No Pi-hole answers at this address.",
                                                     "Ningún Pi-hole responde en esta dirección."),
    "Anmeldung abgelehnt. Stimmen Benutzer und Passwort?": (
        "Login refused. Are the user and password right?",
        "Inicio de sesión rechazado. ¿Son correctos el usuario y la contraseña?"),
    "Dem Benutzer fehlt das Recht „FRITZ!Box Einstellungen“.": (
        "The user lacks the “FRITZ!Box settings” right.",
        "Al usuario le falta el permiso «Ajustes de FRITZ!Box»."),
    "Die Fritzbox antwortet nicht über TR-064. Ist „Zugriff für Anwendungen zulassen“ an?": (
        "The FRITZ!Box does not answer via TR-064. Is “Allow access for applications” switched on?",
        "La FRITZ!Box no responde por TR-064. ¿Está activado «Permitir acceso para aplicaciones»?"),
    "Der API-Key wird nicht angenommen.": ("The API key is not accepted.", "La clave API no se acepta."),
    "Keine Unraid-API gefunden. Sie gibt es ab Unraid 7.2; sonst Glances nehmen.": (
        "No Unraid API found. It exists from Unraid 7.2; otherwise use Glances.",
        "No se encontró la API de Unraid. Existe desde Unraid 7.2; si no, usa Glances."),
    "Die Unraid-API versteht die Abfrage nicht: {detail}": (
        "The Unraid API does not understand the query: {detail}",
        "La API de Unraid no entiende la consulta: {detail}"),
    "Unter dieser Adresse antwortet kein Glances.": ("No Glances answers at this address.",
                                                     "Ningún Glances responde en esta dirección."),
    "Noch kein Passwort": ("No password yet", "Aún sin contraseña"),
    "Noch kein API-Key": ("No API key yet", "Aún sin clave API"),
    "{n} online, {m} bekannt": ("{n} online, {m} known", "{n} en línea, {m} conocidos"),
    "Die Daten werden neu geladen.": ("Reloading the data.", "Recargando los datos."),

    # Playlist
    "Die Szene Network Overview ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The Network Overview scene is not installed on this frame. Install the package again.",
        "La escena Network Overview no está instalada en este marco. Vuelve a instalar el paquete."),
    "Die Playlist {name} gibt es schon.": ("The playlist {name} already exists.", "La lista {name} ya existe."),
    "Dein Heimnetz auf einen Blick.": ("Your home network at a glance.", "Tu red doméstica de un vistazo."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": ("The frame did not create the playlist {name}.",
                                                           "El marco no ha creado la lista {name}."),
    "Konnte die Playlist nicht anlegen: {exc}": ("Could not create the playlist: {exc}",
                                                 "No se ha podido crear la lista: {exc}"),
    "Playlist {name} angelegt. Starte sie auf der Startseite des Rahmens oder nimm die Szene in eine andere Playlist auf.": (
        "Playlist {name} created. Start it on the frame's home page, or add the scene to another playlist.",
        "Lista {name} creada. Iníciala en la página principal del marco o añade la escena a otra lista."),

    # Lagebild
    "Internet ist getrennt": ("Internet is disconnected", "Internet está desconectado"),
    "Die Fritzbox meldet: {state}": ("The FRITZ!Box reports: {state}", "La FRITZ!Box informa: {state}"),
    "Pi-hole blockt gerade nicht": ("Pi-hole is not blocking right now", "Pi-hole no está bloqueando ahora"),
    "{name} blockt gerade nicht": ("{name} is not blocking right now", "{name} no está bloqueando ahora"),
    "{name} antwortet nicht": ("{name} does not answer", "{name} no responde"),
    "Die anderen Pi-holes laufen weiter.": ("The other Pi-holes keep running.", "Los otros Pi-hole siguen funcionando."),
    "Werbung und Tracker kommen ungefiltert durch.": ("Ads and trackers get through unfiltered.",
                                                      "Anuncios y rastreadores pasan sin filtro."),
    "Neues Gerät: {name}": ("New device: {name}", "Dispositivo nuevo: {name}"),
    "Neue Geräte: {names}": ("New devices: {names}", "Dispositivos nuevos: {names}"),
    "zum ersten Mal gesehen um {time}": ("first seen at {time}", "visto por primera vez a las {time}"),
    "{n} Geräte, zuerst gesehen heute": ("{n} devices, first seen today", "{n} dispositivos, vistos hoy por primera vez"),
    "{disk} ist {temp} °C warm": ("{disk} is at {temp} °C", "{disk} está a {temp} °C"),
    "Wärmer als die Grenze von {limit} °C.": ("Warmer than the limit of {limit} °C.",
                                              "Más caliente que el límite de {limit} °C."),
    "Server-Speicher zu {pct} % voll": ("Server storage {pct} % full", "Almacenamiento del servidor al {pct} %"),
    "Noch {free} frei.": ("{free} left.", "Quedan {free}."),
    "Array ist nicht gestartet": ("Array is not started", "El array no está iniciado"),
    "Unraid meldet: {state}": ("Unraid reports: {state}", "Unraid informa: {state}"),
    "{disk} meldet {status}": ("{disk} reports {status}", "{disk} informa {status}"),
    "Heute {pct} % der Anfragen geblockt": ("{pct} % of queries blocked today",
                                            "Hoy bloqueado el {pct} % de las consultas"),
    "mehr als im Schnitt der letzten Tage ({avg} %)": ("more than the average of the last days ({avg} %)",
                                                        "más que la media de los últimos días ({avg} %)"),
    "weniger als im Schnitt der letzten Tage ({avg} %)": ("less than the average of the last days ({avg} %)",
                                                          "menos que la media de los últimos días ({avg} %)"),
    "wie im Schnitt der letzten Tage": ("as on an average day", "como un día normal"),
    "Am aktivsten: {name}": ("Most active: {name}", "El más activo: {name}"),
    "{n} DNS-Anfragen in 24 Stunden, {pct} % von allen": ("{n} DNS queries in 24 hours, {pct} % of all",
                                                         "{n} consultas DNS en 24 horas, {pct} % del total"),
    "Am häufigsten geblockt: {domain}": ("Blocked most often: {domain}", "Bloqueado con más frecuencia: {domain}"),
    "{n}-mal in 24 Stunden": ("{n} times in 24 hours", "{n} veces en 24 horas"),
    "{n} Geräte online": ("{n} devices online", "{n} dispositivos en línea"),
    "mehr als sonst um diese Zeit ({avg})": ("more than usual at this time ({avg})", "más de lo habitual a esta hora ({avg})"),
    "weniger als sonst um diese Zeit ({avg})": ("fewer than usual at this time ({avg})", "menos de lo habitual a esta hora ({avg})"),
    "Heute {volume} aus dem Internet geladen": ("{volume} downloaded from the internet today",
                                                "Hoy {volume} descargados de internet"),
    "{pct} % mehr als an einem normalen Tag bis jetzt": ("{pct} % more than on a normal day so far",
                                                        "{pct} % más que un día normal hasta ahora"),
    "{pct} % weniger als an einem normalen Tag bis jetzt": ("{pct} % less than on a normal day so far",
                                                           "{pct} % menos que un día normal hasta ahora"),
    "Gerade viel los: {rate} im Download": ("Busy right now: {rate} download", "Mucho tráfico ahora: {rate} de descarga"),
    "{pct} % der Leitung": ("{pct} % of the line", "{pct} % de la línea"),
    "Alles ruhig": ("All quiet", "Todo tranquilo"),
    "Server läuft seit {days} Tagen": ("Server up for {days} days", "Servidor en marcha desde hace {days} días"),
    "{n} von {m} Containern laufen": ("{n} of {m} containers running", "{n} de {m} contenedores en marcha"),
    "Platten schlafen: {names}": ("Disks asleep: {names}", "Discos en reposo: {names}"),
    "spart Strom": ("saves power", "ahorra energía"),
}


def t(lang, template, **values):
    text = template
    if lang in LANGUAGES and lang != "de":
        row = _TEXTS.get(template)
        if row:
            text = row[LANGUAGES.index(lang) - 1]
    try:
        return text.format(**values) if values else text
    except (KeyError, IndexError, ValueError):
        return text


def number(lang, n):
    return f"{int(n):,}".replace(",", "," if lang == "en" else ".")


def decimal(lang, value, digits=1):
    text = f"{value:.{digits}f}"
    return text if lang == "en" else text.replace(".", ",")


def size(lang, n):
    """Bytes als 1,2 GB / 830 MB / 4,1 TB (dezimal, wie Unraid und Fritzbox)."""
    n = float(n or 0)
    for unit, factor in (("TB", 1e12), ("GB", 1e9), ("MB", 1e6), ("kB", 1e3)):
        if n >= factor:
            value = n / factor
            return f"{decimal(lang, value, 1 if value < 100 else 0)} {unit}"
    return f"{int(n)} B"


def rate(lang, bps):
    bps = float(bps or 0)
    if bps >= 1e9:
        return f"{decimal(lang, bps / 1e9)} Gbit/s"
    if bps >= 1e6:
        return f"{decimal(lang, bps / 1e6, 1 if bps < 1e8 else 0)} Mbit/s"
    return f"{decimal(lang, bps / 1e3, 0)} kbit/s"
