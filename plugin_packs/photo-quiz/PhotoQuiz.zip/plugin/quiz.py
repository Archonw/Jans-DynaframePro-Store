"""Das Spiel von Photo Quiz, ohne Netz und ohne DynaFrame (darum gut zu testen).

- pick(): das nächste Foto. Erst ein Jahr gleichmäßig auslosen, dann ein Foto
  daraus, damit nicht immer das Jahr mit den meisten Fotos dran ist. Kürzlich
  gezeigte Fotos und Tage bleiben weg.
- hints(): Hinweise als Daten (die Szene und das Handy machen den Text in
  ihrer Sprache daraus).
- year_points() / place_points(): Punkte für einen Tipp.
- Game: der Ablauf (Raten, Auflösung, Endstand) mit den Mitspielern. Die Zeit
  kommt von außen (now), damit Tests sie vorspulen können.
"""

import math
import random
import re
import secrets
import statistics

YEAR_POINTS = (1000, 600, 300, 100)     # genau, 1, 2, 3 Jahre daneben
COLORS = ("#ff6b6b", "#4dabf7", "#ffd43b", "#69db7c", "#da77f2", "#ff922b",
          "#3bc9db", "#f783ac", "#a9e34b", "#9775fa", "#ffa8a8", "#63e6be")
MAX_PLAYERS = 12
ACTIVE_SECONDS = 25        # so lange gilt ein Handy nach seiner letzten Frage als dabei
MIN_GUESS_SECONDS = 6      # vorher endet das Raten nicht, auch wenn alle getippt haben


# --------------------------------------------------------------------------
# Rechnen mit Orten
# --------------------------------------------------------------------------

def km(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(min(1.0, math.sqrt(a)))


def direction(lat1, lon1, lat2, lon2):
    """Himmelsrichtung von 1 nach 2: N, NE, E, SE, S, SW, W, NW."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    x = math.sin(dl) * math.cos(p2)
    y = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    deg = (math.degrees(math.atan2(x, y)) + 360) % 360
    return ("N", "NE", "E", "SE", "S", "SW", "W", "NW")[int((deg + 22.5) // 45) % 8]


def home_of(rows):
    """Wo die meisten Fotos entstehen (Raster 0,1 Grad, Mitte der Fotos darin)."""
    cells = {}
    for row in rows:
        if row.get("lat") is None:
            continue
        key = (round(row["lat"], 1), round(row["lon"], 1))
        cells.setdefault(key, []).append(row)
    if not cells:
        return None
    best = max(cells.values(), key=len)
    return (round(sum(r["lat"] for r in best) / len(best), 4), round(sum(r["lon"] for r in best) / len(best), 4))


def place_scale(rows, home):
    """Wie weit „daneben“ für 1000 Punkte noch zählt: der typische Abstand der
    Fotos von zu Hause. Wer nur zu Hause fotografiert, muss genauer tippen als
    jemand, der in der Welt herumkommt."""
    if not home:
        return 300.0
    dists = [km(home[0], home[1], r["lat"], r["lon"]) for r in rows if r.get("lat") is not None]
    if not dists:
        return 300.0
    return max(3.0, min(1500.0, statistics.median(dists) or 3.0))


def year_points(guess, actual):
    off = abs(int(guess) - int(actual))
    return YEAR_POINTS[off] if off < len(YEAR_POINTS) else 0


def place_points(dist_km, scale):
    return int(round(1000 * math.exp(-dist_km / max(1.0, scale))))


# --------------------------------------------------------------------------
# Fotos auswählen und Hinweise
# --------------------------------------------------------------------------

def pick(rows, recent_keys, recent_days, need_place=False, rng=random):
    """Ein Foto für die nächste Runde, oder None."""
    pool = [r for r in rows if len(r.get("t") or "") >= 10]
    if need_place:
        located = [r for r in pool if r.get("lat") is not None]
        pool = located or pool
    if not pool:
        return None
    fresh = [r for r in pool if r["k"] not in recent_keys and r["t"][:10] not in recent_days]
    if not fresh:
        fresh = [r for r in pool if r["k"] not in recent_keys] or pool
    by_year = {}
    for row in fresh:
        by_year.setdefault(row["t"][:4], []).append(row)
    year = rng.choice(sorted(by_year))
    return rng.choice(by_year[year])


def season(month, lat):
    """Jahreszeit nach Monat; auf der Südhalbkugel andersherum."""
    north = ("winter", "winter", "spring", "spring", "spring", "summer",
             "summer", "summer", "autumn", "autumn", "autumn", "winter")[month - 1]
    if lat is not None and lat < -5:
        return {"winter": "summer", "summer": "winter", "spring": "autumn", "autumn": "spring"}[north]
    return north


def daypart(hour):
    if hour < 5:
        return "night"
    if hour < 11:
        return "morning"
    if hour < 14:
        return "noon"
    if hour < 18:
        return "afternoon"
    if hour < 22:
        return "evening"
    return "night"


def country_of(place):
    """Aus "Lissabon, Portugal" oder "Sintra, Lisboa, Portugal" das Land."""
    parts = [p.strip() for p in str(place or "").split(",") if p.strip()]
    return parts[-1] if parts else ""


def hints(row, home, wanted, weather=None, rng=random):
    """Bis zu drei Hinweise, vom vagen zum genauen. wanted: erlaubte Arten."""
    out = []
    taken = row.get("t") or ""
    has_time = len(taken) >= 16 and taken[11:16] != "00:00"
    if "season" in wanted and len(taken) >= 10:
        hint = {"kind": "season", "season": season(int(taken[5:7]), row.get("lat"))}
        if has_time:
            hint["part"] = daypart(int(taken[11:13]))
        out.append(hint)
    if "weather" in wanted and weather and weather.get("t") is not None:
        out.append({"kind": "weather", "t": weather.get("t"), "code": weather.get("code")})
    if "camera" in wanted and row.get("cam"):
        out.append({"kind": "camera", "name": row["cam"]})
    if "distance" in wanted and home and row.get("lat") is not None:
        dist = km(home[0], home[1], row["lat"], row["lon"])
        hint = {"kind": "distance", "km": round(dist)}
        if dist >= 3:
            hint["dir"] = direction(home[0], home[1], row["lat"], row["lon"])
        out.append(hint)
    if "country" in wanted:
        land = country_of(row.get("place"))
        if land:
            out.append({"kind": "country", "name": land})
    # vage zuerst: Jahreszeit, Wetter, Kamera, Entfernung, Land; höchstens drei
    if len(out) > 3:
        keep = [out[0]] + rng.sample(out[1:-1], 1) + [out[-1]]
        out = keep
    return out


# --------------------------------------------------------------------------
# Das Spiel
# --------------------------------------------------------------------------

NAME_CLEAN = re.compile(r"[\x00-\x1f<>]")


class Game:
    """Der Ablauf, gesteuert von tick(now). Phasen:
    off (die Szene ist nicht zu sehen), wait (Foto wird geholt), guess, reveal, final."""

    def __init__(self, store=None):
        self.store = store or {}          # dauerhaft: {"players": {...}}
        self.store.setdefault("players", {})
        self.phase = "off"
        self.until = 0.0
        self.started = 0.0
        self.round = 0
        self.ident = 0                    # zählt jede Runde hoch (für Szene und Handy)
        self.photo = None                 # {"k", "t", "lat", "lon", "place", "hints": [...], ...}
        self.next_photo = None
        self.guesses = {}                 # Spieler-ID -> {"year", "lat", "lon", "at"}
        self.results = []
        self.scores = {}                  # Punkte im laufenden Spiel
        self.played = set()               # wer in diesem Spiel getippt hat
        self.seen = {}                    # Spieler-ID -> zuletzt gesehen (time)
        self.final = []

    # ---- Mitspieler -------------------------------------------------------

    def players(self):
        return self.store["players"]

    def join(self, name, now, ident=None):
        name = NAME_CLEAN.sub("", str(name or "")).strip()[:16]
        if not name:
            return None, "name"
        people = self.players()
        if ident and ident in people:
            people[ident]["name"] = name
        else:
            if len(people) >= 60:
                oldest = min(people, key=lambda k: people[k].get("last", 0))
                del people[oldest]
            taken = {p["color"] for p in people.values() if p.get("last", 0) > now - 3600}
            color = next((c for c in COLORS if c not in taken), COLORS[len(people) % len(COLORS)])
            ident = secrets.token_hex(12)
            people[ident] = {"name": name, "color": color, "games": 0, "wins": 0, "best": 0, "last": now}
        self.seen[ident] = now
        people[ident]["last"] = now
        return ident, ""

    def touch(self, ident, now):
        if ident in self.players():
            self.seen[ident] = now
            return True
        return False

    def active(self, now):
        return [i for i, at in self.seen.items() if now - at <= ACTIVE_SECONDS and i in self.players()]

    def guess(self, ident, year, lat, lon, now):
        if self.phase != "guess" or ident not in self.players():
            return False
        entry = {"at": now}
        if year is not None:
            entry["year"] = int(year)
        if lat is not None and lon is not None and abs(lat) <= 90 and abs(lon) <= 180:
            entry["lat"], entry["lon"] = round(float(lat), 5), round(float(lon), 5)
        self.guesses[ident] = entry
        self.seen[ident] = now
        self.played.add(ident)
        return True

    # ---- Ablauf -----------------------------------------------------------

    def start_round(self, photo, now, seconds):
        self.round += 1
        self.ident += 1
        self.photo = photo
        self.guesses = {}
        self.results = []
        self.phase = "guess"
        self.started = now
        self.until = now + seconds

    def all_guessed(self, now):
        active = self.active(now)
        return bool(active) and all(i in self.guesses for i in active)

    def reveal(self, now, seconds, scale, mode):
        photo = self.photo or {}
        year = int(str(photo.get("t") or "0")[:4] or 0)
        results = []
        for ident, entry in self.guesses.items():
            person = self.players().get(ident)
            if not person:
                continue
            row = {"id": ident, "name": person["name"], "color": person["color"], "points": 0}
            if mode in ("both", "when") and "year" in entry and year:
                row["year"] = entry["year"]
                row["yearPoints"] = year_points(entry["year"], year)
                row["points"] += row["yearPoints"]
            if mode in ("both", "where") and "lat" in entry and photo.get("lat") is not None:
                dist = km(entry["lat"], entry["lon"], photo["lat"], photo["lon"])
                row.update(lat=entry["lat"], lon=entry["lon"], km=round(dist, 1),
                           placePoints=place_points(dist, scale))
                row["points"] += row["placePoints"]
            self.scores[ident] = self.scores.get(ident, 0) + row["points"]
            row["total"] = self.scores[ident]
            results.append(row)
        results.sort(key=lambda r: -r["points"])
        self.results = results
        self.phase = "reveal"
        self.started = now
        self.until = now + seconds

    def finish(self, now, seconds):
        board = sorted(({"id": i, "name": self.players()[i]["name"], "color": self.players()[i]["color"],
                         "score": s} for i, s in self.scores.items() if i in self.players()),
                       key=lambda r: -r["score"])
        if board:
            top = board[0]["score"]
            for row in board:
                person = self.players()[row["id"]]
                person["games"] = person.get("games", 0) + 1
                person["best"] = max(person.get("best", 0), row["score"])
                if row["score"] == top and top > 0:
                    person["wins"] = person.get("wins", 0) + 1
                    row["winner"] = True
        self.final = board
        self.phase = "final"
        self.started = now
        self.until = now + seconds

    def reset_game(self):
        self.round = 0
        self.scores = {}
        self.played = set()
        self.final = []

    def stop(self):
        """Die Szene ist weg: Spiel unterbrechen. Die Punkte bleiben, falls sie gleich wiederkommt."""
        self.phase = "off"
        self.photo = None
