# Third-party notes

- ThumbHash decoding in `colors.py` follows the reference implementation by Evan Wallace, https://github.com/evanw/thumbhash, MIT License, Copyright (c) 2023 Evan Wallace.
- The scene bundles the fonts Fraunces and Inter under the SIL Open Font License 1.1 (see `dynamic/fonts/OFL-*.txt`).
- `exif_gps.py` is shared with the Travel Map plugin (own code).
