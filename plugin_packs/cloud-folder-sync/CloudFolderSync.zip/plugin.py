#!/usr/bin/env python3
"""Cloud Folder Sync - Fotos aus einem Cloud-Ordner auf den Rahmen.

Das Plugin holt mit rclone (https://rclone.org) einen oder mehrere Ordner aus
Google Drive, Dropbox, OneDrive, pCloud, Nextcloud/WebDAV (oder jeder anderen
rclone-Quelle) in einen Ordner unter DynaFrames Bilder-Ordner. DynaFrame zeigt
die Fotos dann selbst: in jeder Playlist, die den Ordner enthält, oder in der
Playlist „Cloud Folder Sync“, die das Plugin auf Wunsch anlegt.

- Hochladen geht mit der App des Anbieters, von überall. Der Rahmen öffnet
  keinen Port, er holt nur ab (alle 15 Minuten, einstellbar).
- rclone wird beim ersten Bedarf von downloads.rclone.org geladen und mit der
  SHA-256-Liste dort geprüft (oder es wird ein vorhandenes rclone genommen).
- Anmeldung bei Google/Dropbox/Microsoft/pCloud: rclone authorize läuft auf dem
  Rahmen. Der Browser der Nutzerin landet nach dem Erlauben auf
  http://127.0.0.1:53682/... (Fehlerseite, weil das ihr eigenes Gerät ist);
  diese Adresse fügt sie auf der Plugin-Seite ein, und das Plugin reicht sie
  auf dem Rahmen an rclone weiter. So braucht es keinen eigenen Server.
"""

import base64
import configparser
import hashlib
import io
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import threading
import time
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse, urlencode

import requests

# Das SDK liegt eine Ebene höher (…/plugins/), wie bei Immich Slideshow
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import own_playlist  # noqa: E402

plugin = create_plugin()

PLUGIN_ID = "CloudFolderSync"
DISPLAY_NAME = "Cloud Folder Sync"
PLAYLIST_NAME = "Cloud Folder Sync"   # englisch, in allen Sprachen gleich
FOLDER_NAME = "Cloud Folder Sync"     # Ordner unter DynaFrames Bilder-Ordner
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"
BIN_DIR = DATA_DIR / "bin"
CONF_FILE = DATA_DIR / "rclone.conf"
SOURCES_FILE = DATA_DIR / "sources.json"
GOOGLE_FILE = DATA_DIR / "google_client.json"
SETTINGS_FILE = DATA_DIR / "settings.json"
CONNECT_TIMEOUT = 10
AUTH_PORT = 53682
RCLONE_SITE = "https://downloads.rclone.org"

PHOTO_EXT = ("jpg", "jpeg", "png", "webp", "gif", "bmp", "tif", "tiff", "heic", "heif")
VIDEO_EXT = ("mp4", "mov", "m4v", "mkv", "webm", "avi")

# Anbieter: rclone-Typ, Anmeldung per OAuth oder Zugangsdaten
PROVIDERS = {
    "drive":    {"label": "Google Drive", "type": "drive", "oauth": True, "auth": {"scope": "drive.readonly"}},
    "dropbox":  {"label": "Dropbox", "type": "dropbox", "oauth": True},
    "onedrive": {"label": "OneDrive", "type": "onedrive", "oauth": True},
    "pcloud":   {"label": "pCloud", "type": "pcloud", "oauth": True},
    "webdav":   {"label": "Nextcloud / WebDAV", "type": "webdav", "oauth": False},
    "mega":     {"label": "MEGA", "type": "mega", "oauth": False, "login": "pass"},
    "koofr":    {"label": "Koofr", "type": "koofr", "oauth": False, "login": "password"},
    "icloud":   {"label": "iCloud", "type": "iclouddrive", "oauth": False},
    "icloudalbum": {"label": "iCloud Shared Album", "type": "", "oauth": False},
    "custom":   {"label": "rclone", "type": "", "oauth": False},
}


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def log(text, level="info"):
    plugin.log(text, level=level)


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        log(f"Konnte {path.name} nicht lesen: {exc}", "warning")
        return default


def write_json(path, payload, private=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, indent=1)
    if private:
        os.chmod(temp, 0o600)
    temp.replace(path)


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Texte (Deutsch ist der Schlüssel)
# --------------------------------------------------------------------------

LANGS = ("de", "en", "es")
TEXTS = {
    "DynaFrame antwortet nicht: {exc}": ("DynaFrame does not answer: {exc}", "DynaFrame no responde: {exc}"),
    "Antwortet.": ("Answers.", "Responde."),
    "rclone {version} ist bereit.": ("rclone {version} is ready.", "rclone {version} está listo."),
    "rclone wird beim ersten Abgleich von downloads.rclone.org geladen (ca. 25 MB).": (
        "rclone is downloaded from downloads.rclone.org on the first sync (about 25 MB).",
        "rclone se descarga de downloads.rclone.org en la primera sincronización (unos 25 MB)."),
    "Lade rclone {version} …": ("Downloading rclone {version} …", "Descargando rclone {version} …"),
    "Konnte rclone nicht laden: {exc}": ("Could not download rclone: {exc}", "No se pudo descargar rclone: {exc}"),
    "Prüfsumme von rclone passt nicht.": ("The rclone checksum does not match.", "La suma de control de rclone no coincide."),
    "Für diesen Prozessor ({arch}) gibt es kein rclone.": (
        "There is no rclone for this processor ({arch}).", "No hay rclone para este procesador ({arch})."),
    "Noch nicht verbunden.": ("Not connected yet.", "Aún no conectado."),
    "Kein Ordner gewählt: es wird alles aus der Cloud geholt.": (
        "No folder chosen: everything in the cloud will be fetched.",
        "Ninguna carpeta elegida: se traerá todo lo de la nube."),
    "Verbunden.": ("Connected.", "Conectado."),
    "Dieses rclone kann iCloud noch nicht.": ("This rclone does not support iCloud yet.", "Este rclone aún no admite iCloud."),
    "iCloud verlangt die Freigabe für das Web: auf dem iPhone Einstellungen > Apple-Account > iCloud > „Auf iCloud-Daten im Web zugreifen“ einschalten und die Anfrage bestätigen.": (
        "iCloud needs web access: on the iPhone turn on Settings > Apple Account > iCloud > “Access iCloud Data on the Web” and approve the request.",
        "iCloud necesita acceso web: en el iPhone activa Ajustes > Cuenta de Apple > iCloud > «Acceder a los datos de iCloud en la web» y aprueba la solicitud."),
    "Die iCloud-Anmeldung ist abgelaufen (gilt 30 Tage). Bitte neu anmelden.": (
        "The iCloud sign-in has expired (valid for 30 days). Please sign in again.",
        "El inicio de sesión de iCloud ha caducado (vale 30 días). Vuelve a iniciar sesión."),
    "Apple hat die Anmeldung abgelehnt: Apple-ID oder Passwort falsch? Nimm das normale Passwort, kein App-Passwort.": (
        "Apple rejected the sign-in: wrong Apple ID or password? Use your normal password, not an app-specific password.",
        "Apple rechazó el inicio de sesión: ¿Apple ID o contraseña incorrectos? Usa tu contraseña normal, no una contraseña de app."),
    "Der Code stimmt nicht oder ist abgelaufen. Bitte noch einmal anmelden.": (
        "The code is wrong or has expired. Please sign in again.", "El código es incorrecto o ha caducado. Vuelve a iniciar sesión."),
    "Apple ist nicht erreichbar ({host}). Pi-hole oder Firewall prüfen.": (
        "Apple is not reachable ({host}). Check Pi-hole or firewall.", "Apple no es accesible ({host}). Revisa Pi-hole o el cortafuegos."),
    "Eigener Google-Schlüssel entfernt.": ("Own Google key removed.", "Clave de Google propia eliminada."),
    "Die Client-ID endet auf .apps.googleusercontent.com; dazu gehört der Clientschlüssel.": (
        "The client ID ends in .apps.googleusercontent.com and needs its client secret.",
        "El ID de cliente termina en .apps.googleusercontent.com y necesita su secreto de cliente."),
    "Gespeichert. Melde Google Drive jetzt neu an.": ("Saved. Now sign in to Google Drive again.", "Guardado. Ahora vuelve a iniciar sesión en Google Drive."),
    "Gespeichert.": ("Saved.", "Guardado."),
    "Trag E-Mail und Passwort ein.": ("Enter email and password.", "Introduce correo y contraseña."),
    "Trag Apple-ID und Passwort ein.": ("Enter Apple ID and password.", "Introduce Apple ID y contraseña."),
    "Bitte den Code eingeben.": ("Please enter the code.", "Introduce el código."),
    "Das ist kein Link zu einem geteilten iCloud-Album (https://www.icloud.com/sharedalbum/#…).": (
        "This is not a link to a shared iCloud album (https://www.icloud.com/sharedalbum/#…).",
        "Esto no es un enlace a un álbum compartido de iCloud (https://www.icloud.com/sharedalbum/#…)."),
    "Album nicht gefunden. Ist „Öffentliche Website“ in der Freigabe noch an?": (
        "Album not found. Is “Public Website” still on in the sharing settings?",
        "Álbum no encontrado. ¿Sigue activado «Sitio web público» en las opciones para compartir?"),
    "iCloud hat nicht geantwortet.": ("iCloud did not answer.", "iCloud no respondió."),
    "iCloud nicht erreichbar: {exc}": ("iCloud not reachable: {exc}", "iCloud no accesible: {exc}"),
    "Album „{name}“ gefunden: {n} Fotos/Videos.": ("Found album “{name}”: {n} photos/videos.", "Álbum «{name}» encontrado: {n} fotos/vídeos."),
    "Abgeglichen {time}: {new} neu, {gone} entfernt, {total} Dateien.": (
        "Synced {time}: {new} new, {gone} removed, {total} files.",
        "Sincronizado {time}: {new} nuevos, {gone} eliminados, {total} archivos."),
    "Fehler beim Abgleich: {exc}": ("Sync failed: {exc}", "Error al sincronizar: {exc}"),
    "Anmeldung abgelaufen oder widerrufen. Bitte neu verbinden.": (
        "Sign-in expired or revoked. Please connect again.",
        "El inicio de sesión ha caducado o se ha revocado. Vuelve a conectar."),
    "Die Anmeldung hat zu lange gedauert. Bitte noch einmal von vorn.": (
        "Sign-in took too long. Please start again.", "El inicio de sesión tardó demasiado. Empieza de nuevo."),
    "In der eingefügten Adresse fehlt code= oder state=. Kopiere die ganze Adresse aus der Adresszeile.": (
        "The pasted address lacks code= or state=. Copy the whole address from the address bar.",
        "A la dirección pegada le falta code= o state=. Copia la dirección completa de la barra de direcciones."),
    "Die Adresse gehört zu einer älteren Anmeldung. Klick noch einmal auf Anmelden.": (
        "That address belongs to an older sign-in. Click sign in again.",
        "Esa dirección pertenece a un inicio de sesión anterior. Pulsa de nuevo en iniciar sesión."),
    "Der Anbieter hat den Code nicht angenommen (schon benutzt oder zu alt). Bitte noch einmal anmelden.": (
        "The provider did not accept the code (already used or too old). Please sign in again.",
        "El proveedor no aceptó el código (ya usado o demasiado antiguo). Vuelve a iniciar sesión."),
    "Der Anbieter hat die Anmeldung abgelehnt: {exc}": (
        "The provider refused the sign-in: {exc}", "El proveedor rechazó el inicio de sesión: {exc}"),
    "Kein gültiger Schlüssel gefunden. Füge die ganze Ausgabe von rclone authorize ein.": (
        "No valid token found. Paste the whole output of rclone authorize.",
        "No se encontró un token válido. Pega toda la salida de rclone authorize."),
    "Zugang abgelehnt: Passwort falsch oder Anmeldung abgelaufen.": (
        "Access denied: wrong password or sign-in expired.",
        "Acceso denegado: contraseña incorrecta o sesión caducada."),
    "Wähle jetzt den Ordner mit den Fotos.": ("Now choose the folder with the photos.", "Ahora elige la carpeta con las fotos."),
    "Trag Adresse, Benutzer und Passwort ein.": (
        "Enter address, user and password.", "Introduce dirección, usuario y contraseña."),
    "Keine gültige rclone-Konfiguration (es fehlt type = …).": (
        "Not a valid rclone configuration (type = … is missing).",
        "No es una configuración válida de rclone (falta type = …)."),
    "Auf dem Rahmen sind nur noch {free} MB frei; Abgleich angehalten (Grenze {limit} MB).": (
        "Only {free} MB left on the frame; sync paused (limit {limit} MB).",
        "Solo quedan {free} MB en el marco; sincronización en pausa (límite {limit} MB)."),
    "Abgleich läuft schon.": ("Sync is already running.", "La sincronización ya está en marcha."),
    "Abgleich gestartet.": ("Sync started.", "Sincronización iniciada."),
    "Ordner {path}: {files} Dateien, {free} MB frei.": (
        "Folder {path}: {files} files, {free} MB free.", "Carpeta {path}: {files} archivos, {free} MB libres."),
    "DynaFrame kennt {n} davon.": ("DynaFrame knows {n} of them.", "DynaFrame conoce {n} de ellos."),
    "Kann nicht in {path} schreiben: {exc}": ("Cannot write to {path}: {exc}", "No se puede escribir en {path}: {exc}"),
    "Bilder auf dem Rahmen": ("Photos on the frame", "Fotos en el marco"),
    "Fotos aus deinen Cloud-Ordnern.": ("Photos from your cloud folders.", "Fotos de tus carpetas en la nube."),
    "Bitte einen ganzen Pfad angeben, z. B. /home/pi/Pictures/Oma.": (
        "Please enter a full path, e.g. /home/pi/Pictures/Grandma.",
        "Indica una ruta completa, p. ej. /home/pi/Pictures/Abuela."),
    "Quelle nicht gefunden.": ("Source not found.", "Fuente no encontrada."),
    "Der Ordner muss in einem Medienordner von DynaFrame liegen ({roots}), sonst findet DynaFrame die Fotos nicht.": (
        "The folder must be inside a DynaFrame media folder ({roots}), otherwise DynaFrame will not find the photos.",
        "La carpeta debe estar dentro de una carpeta multimedia de DynaFrame ({roots}); si no, DynaFrame no encontrará las fotos."),
    "Ordner nicht gefunden.": ("Folder not found.", "Carpeta no encontrada."),
    "Ordner nicht lesbar.": ("Folder not readable.", "Carpeta no legible."),
    "Bitte einen Ordnernamen ohne / eingeben.": ("Please enter a folder name without /.", "Introduce un nombre de carpeta sin /."),
    "Ohne Namen": ("Unnamed", "Sin nombre"),
    "Prüfung": ("Check", "Comprobación"),
}


def t(lang, text, **values):
    row = TEXTS.get(text)
    if row and lang in ("en", "es"):
        text = row[0 if lang == "en" else 1]
    return text.format(**values) if values else text


def tr(text, **values):
    return t(settings()["Language"], text, **values)


def clock(epoch):
    return time.strftime("%H:%M", time.localtime(epoch)) if epoch else "—"


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

SCHEMA = {
    "Language":        {"kind": "choice", "default": "de", "choices": LANGS},
    "IntervalMinutes": {"kind": "int", "default": 15, "min": 5, "max": 1440},
    "MinFreeMB":       {"kind": "int", "default": 1000, "min": 100, "max": 100000},
    "BaseFolder":      {"kind": "path", "default": ""},
    "MakePlaylist":    {"kind": "bool", "default": False},
}
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "choice":
        value = str(raw if raw is not None else "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "path":
        value = str(raw or "").strip()
        return value[:400] if value.startswith("/") and "\x00" not in value else ""
    return str(raw or "").strip()[:200]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


# --------------------------------------------------------------------------
# Quellen (Cloud-Ordner)
# --------------------------------------------------------------------------

_sources_lock = threading.RLock()
SOURCE_FIELDS = {
    "name": "", "remotePath": "", "mode": "mirror", "videos": False, "sharedWithMe": False, "enabled": True,
}


def load_sources():
    rows = read_json(SOURCES_FILE, [])
    return [r for r in rows if isinstance(r, dict) and r.get("id")] if isinstance(rows, list) else []


def save_sources(rows):
    write_json(SOURCES_FILE, rows)


def find_source(sid):
    return next((r for r in load_sources() if r["id"] == sid), None)


def update_source(sid, **changes):
    with _sources_lock:
        rows = load_sources()
        for row in rows:
            if row["id"] == sid:
                row.update(changes)
                save_sources(rows)
                return row
    return None


def safe_folder(name):
    value = re.sub(r"[\\/:*?\"<>|\x00-\x1f]", " ", str(name or "")).strip(" .")
    return re.sub(r"\s+", " ", value)[:60] or "Cloud"


def remote_name(sid):
    return f"src_{sid}"


def add_source(provider):
    if provider not in PROVIDERS:
        raise ValueError("unknown provider")
    with _sources_lock:
        rows = load_sources()
        sid = hashlib.sha1(f"{now()}-{provider}-{len(rows)}".encode()).hexdigest()[:8]
        label = PROVIDERS[provider]["label"].split(" /")[0]
        taken = {r.get("folder") for r in rows}
        name, n = label, 2
        while safe_folder(name) in taken:
            name, n = f"{label} {n}", n + 1
        row = dict(SOURCE_FIELDS, id=sid, provider=provider, name=name, folder=safe_folder(name),
                   connected=False, created=now(), last={})
        rows.append(row)
        save_sources(rows)
        return row


def edit_source(sid, body):
    with _sources_lock:
        rows = load_sources()
        row = next((r for r in rows if r["id"] == sid), None)
        if row is None:
            raise ValueError(tr("Quelle nicht gefunden."))
        if "name" in body:
            name = str(body["name"] or "").strip()[:60] or tr("Ohne Namen")
            folder = safe_folder(name)
            if folder != row.get("folder") and folder not in {r.get("folder") for r in rows if r is not row}:
                old, new = base_folder() / row["folder"], base_folder() / folder
                try:
                    if old.exists() and not new.exists():
                        old.rename(new)
                    row["folder"] = folder
                except OSError as exc:
                    log(f"Konnte Ordner nicht umbenennen: {exc}", "warning")
            row["name"] = name
        if "remotePath" in body:
            row["remotePath"] = str(body["remotePath"] or "").strip().strip("/")[:400]
            row["folderChosen"] = True
        if "localPath" in body:
            row["localPath"] = clean_local_path(body["localPath"])
        if "mode" in body and body["mode"] in ("mirror", "add"):
            row["mode"] = body["mode"]
        for key in ("videos", "sharedWithMe", "enabled"):
            if key in body:
                row[key] = as_bool(body[key])
        if "sharedWithMe" in body and row["provider"] == "drive" and row.get("connected"):
            set_remote_option(sid, "shared_with_me", "true" if row["sharedWithMe"] else "")
        save_sources(rows)
        return row


MARKER = ".cloud-folder-sync"


def source_target(row):
    """Eigener Ordner der Quelle (localPath) oder <Ordner auf dem Rahmen>/<Name>."""
    custom = str(row.get("localPath") or "").strip()
    return Path(custom) if custom else base_folder() / row["folder"]


def clean_local_path(raw):
    value = str(raw or "").strip().rstrip("/")
    if not value:
        return ""
    if not value.startswith("/") or "\x00" in value or "/../" in value + "/" or value in ("/", "/home", "/home/pi"):
        raise ValueError(tr("Bitte einen ganzen Pfad angeben, z. B. /home/pi/Pictures/Oma."))
    roots = local_roots()
    if not _inside(Path(os.path.normpath(value)), roots):
        raise ValueError(tr("Der Ordner muss in einem Medienordner von DynaFrame liegen ({roots}), sonst findet DynaFrame die Fotos nicht.",
                            roots=", ".join(str(r) for r in roots)))
    return value[:400]


def remove_source(sid, delete_files):
    with _sources_lock:
        rows = load_sources()
        row = next((r for r in rows if r["id"] == sid), None)
        if row is None:
            return
        save_sources([r for r in rows if r["id"] != sid])
    conf = read_conf()
    if conf.has_section(remote_name(sid)):
        conf.remove_section(remote_name(sid))
        write_conf(conf)
    if delete_files and row.get("folder"):
        target = source_target(row)
        # Nur Ordner löschen, die das Plugin selbst angelegt hat
        if target.is_dir() and (base_folder() in target.parents or (target / MARKER).exists()):
            shutil.rmtree(target, ignore_errors=True)
            notify_dynaframe(target.parent)
    log(f"Quelle {row.get('name')} entfernt{' samt Fotos' if delete_files else ''}.")


def public_source(row):
    last = row.get("last") or {}
    return {
        "id": row["id"], "provider": row["provider"], "label": PROVIDERS.get(row["provider"], {}).get("label", "?"),
        "oauth": PROVIDERS.get(row["provider"], {}).get("oauth", False),
        "name": row.get("name"), "folder": row.get("folder"), "remotePath": row.get("remotePath", ""),
        "localPath": row.get("localPath", ""), "target": str(source_target(row)),
        "mode": row.get("mode", "mirror"), "videos": bool(row.get("videos")),
        "sharedWithMe": bool(row.get("sharedWithMe")), "enabled": row.get("enabled", True) is not False,
        "connected": bool(row.get("connected")), "account": row.get("account", ""),
        "folderChosen": bool(row.get("folderChosen")),
        "webdavUrl": row.get("webdavUrl", ""), "webdavUser": row.get("webdavUser", ""),
        "webdavVendor": row.get("webdavVendor", "nextcloud"),
        "appleId": row.get("appleId", ""), "icloudService": row.get("icloudService", "photos"),
        "albumUrl": row.get("albumUrl", ""), "authExpires": row.get("authExpires"),
        "last": {"at": last.get("at"), "ok": last.get("ok"), "text": last.get("text", ""),
                 "files": last.get("files", 0)},
        "syncing": _sync["current"] == row["id"],
        "progress": dict(_sync["progress"]) if _sync["current"] == row["id"] else {},
    }


# --------------------------------------------------------------------------
# rclone besorgen
# --------------------------------------------------------------------------

_rclone = {"path": "", "version": "", "busy": False, "error": "", "note": ""}
_rclone_lock = threading.Lock()


def rclone_arch():
    machine = platform.machine().lower()
    if machine in ("aarch64", "arm64"):
        return "arm64"
    if machine in ("x86_64", "amd64"):
        return "amd64"
    if machine.startswith("armv7") or machine == "armhf":
        return "arm-v7"
    if machine.startswith("arm"):
        return "arm"
    return ""


def rclone_version(path):
    try:
        out = subprocess.run([path, "version"], capture_output=True, text=True, timeout=20).stdout
    except (OSError, subprocess.SubprocessError):
        return ""
    match = re.search(r"rclone v?([\d.]+[\w.-]*)", out)
    return match.group(1) if match else ""


def find_rclone():
    """Eigenes rclone im Datenordner, sonst eines auf dem System."""
    own = BIN_DIR / "rclone"
    for candidate in (str(own) if own.is_file() else "", shutil.which("rclone") or ""):
        if candidate and os.access(candidate, os.X_OK):
            found = rclone_version(candidate)
            if found:
                return candidate, found
    return "", ""


def install_rclone():
    """Lädt das offizielle rclone für diesen Prozessor und prüft die SHA-256."""
    arch = rclone_arch()
    if not arch:
        raise RuntimeError(tr("Für diesen Prozessor ({arch}) gibt es kein rclone.", arch=platform.machine()))
    headers = {"User-Agent": f"DynaFrame-{PLUGIN_ID}/{version()} (+https://github.com/Archonw/Jans-DynaframePro-Store)"}
    latest = requests.get(f"{RCLONE_SITE}/version.txt", timeout=(CONNECT_TIMEOUT, 30), headers=headers)
    latest.raise_for_status()
    match = re.search(r"v(\d+\.\d+\.\d+)", latest.text)
    if not match:
        raise RuntimeError("version.txt?")
    ver = match.group(1)
    _rclone["note"] = tr("Lade rclone {version} …", version=ver)
    name = f"rclone-v{ver}-linux-{arch}.zip"
    sums = requests.get(f"{RCLONE_SITE}/v{ver}/SHA256SUMS", timeout=(CONNECT_TIMEOUT, 30), headers=headers)
    sums.raise_for_status()
    expected = next((line.split()[0] for line in sums.text.splitlines()
                     if line.strip().endswith(name) and len(line.split()[0]) == 64), "")
    if not expected:
        raise RuntimeError(f"SHA256SUMS: {name}?")
    data = requests.get(f"{RCLONE_SITE}/v{ver}/{name}", timeout=(CONNECT_TIMEOUT, 600), headers=headers)
    data.raise_for_status()
    if hashlib.sha256(data.content).hexdigest() != expected.lower():
        raise RuntimeError(tr("Prüfsumme von rclone passt nicht."))
    with zipfile.ZipFile(io.BytesIO(data.content)) as archive:
        member = next(m for m in archive.namelist() if m.endswith("/rclone"))
        BIN_DIR.mkdir(parents=True, exist_ok=True)
        temp = BIN_DIR / "rclone.new"
        temp.write_bytes(archive.read(member))
        temp.chmod(0o755)
        temp.replace(BIN_DIR / "rclone")
    log(f"rclone {ver} ({arch}) geladen und geprüft.")


def rclone(required=True):
    """Pfad zu rclone; lädt es beim ersten Mal."""
    with _rclone_lock:
        if _rclone["path"] and os.path.exists(_rclone["path"]):
            return _rclone["path"]
        path, ver = find_rclone()
        if not path and required:
            _rclone["busy"] = True
            try:
                install_rclone()
                path, ver = find_rclone()
                _rclone["error"] = ""
            except Exception as exc:  # noqa: BLE001
                _rclone["error"] = tr("Konnte rclone nicht laden: {exc}", exc=exc)
                log(_rclone["error"], "warning")
            finally:
                _rclone["busy"] = False
                _rclone["note"] = ""
        _rclone.update(path=path, version=ver)
        return path


def rclone_env():
    env = dict(os.environ)
    env["RCLONE_CONFIG"] = str(CONF_FILE)
    env["RCLONE_CACHE_DIR"] = str(DATA_DIR / "cache")
    env.pop("RCLONE_PASSWORD_COMMAND", None)
    return env


def run_rclone(args, timeout=120):
    exe = rclone()
    if not exe:
        raise RuntimeError(_rclone["error"] or "rclone?")
    proc = subprocess.run([exe] + args + ["--config", str(CONF_FILE)], capture_output=True, text=True,
                          timeout=timeout, env=rclone_env())
    if proc.returncode != 0:
        raise RuntimeError(short_error(proc.stderr or proc.stdout))
    return proc.stdout


def short_error(text):
    lines = [line for line in str(text or "").splitlines() if line.strip()]
    for line in reversed(lines):
        if "ERROR" in line or "Failed" in line or "error" in line.lower():
            text = line
            break
    else:
        text = lines[-1] if lines else "?"
    text = re.sub(r"^\d{4}/\d\d/\d\d \d\d:\d\d:\d\d\s+", "", text)
    text = re.sub(r'^(CRITICAL|ERROR|NOTICE): (Fatal error: )?(Failed to create file system for "[^"]*": )?', "", text)
    if re.search(r"couldn't login: .*(not found|EACCESS|ENOENT|denied)|invalid credentials", text, re.I):
        return tr("Zugang abgelehnt: Passwort falsch oder Anmeldung abgelaufen.")
    if re.search(r"icloud trust token|Missing PCS|requestPCS", text, re.I):
        return icloud_error(text)
    if re.search(r"invalid_grant|token.*(expired|revoked)|unauthorized_client|expired_access_token", text, re.I):
        return tr("Anmeldung abgelaufen oder widerrufen. Bitte neu verbinden.")
    if re.search(r"401 Unauthorized|\b401\b|403 Forbidden", text):
        return tr("Zugang abgelehnt: Passwort falsch oder Anmeldung abgelaufen.")
    return text[:300]


# --------------------------------------------------------------------------
# rclone-Konfiguration (data/rclone.conf, nur für das Plugin lesbar)
# --------------------------------------------------------------------------

_conf_lock = threading.Lock()


def read_conf():
    conf = configparser.RawConfigParser()
    conf.optionxform = str
    try:
        conf.read(CONF_FILE, encoding="utf-8")
    except configparser.Error as exc:
        log(f"rclone.conf kaputt: {exc}", "warning")
    return conf


def write_conf(conf):
    with _conf_lock:
        CONF_FILE.parent.mkdir(parents=True, exist_ok=True)
        temp = CONF_FILE.with_suffix(".tmp")
        with open(temp, "w", encoding="utf-8") as stream:
            conf.write(stream)
        os.chmod(temp, 0o600)
        temp.replace(CONF_FILE)


def set_remote(sid, options):
    conf = read_conf()
    section = remote_name(sid)
    if conf.has_section(section):
        conf.remove_section(section)
    conf.add_section(section)
    for key, value in options.items():
        if value not in (None, ""):
            conf.set(section, key, str(value))
    write_conf(conf)


def set_remote_option(sid, key, value):
    conf = read_conf()
    section = remote_name(sid)
    if not conf.has_section(section):
        return
    if value:
        conf.set(section, key, value)
    elif conf.has_option(section, key):
        conf.remove_option(section, key)
    write_conf(conf)


def obscure(secret):
    return run_rclone(["obscure", secret], timeout=30).strip()


# --------------------------------------------------------------------------
# Anmeldung (OAuth über rclone authorize auf dem Rahmen)
# --------------------------------------------------------------------------

_auth = {"proc": None, "sid": "", "state": "", "out": [], "started": 0.0}
_auth_lock = threading.Lock()
AUTH_TIMEOUT = 15 * 60


def stop_auth():
    proc = _auth.get("proc")
    if proc is not None and proc.poll() is None:
        try:
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:  # noqa: BLE001
            try:
                proc.kill()
            except Exception:  # noqa: BLE001
                pass
    _auth.update(proc=None, sid="", state="", out=[], started=0.0)


def _reader(proc, sink):
    for line in iter(proc.stdout.readline, ""):
        sink.append(line)
        if len(sink) > 400:
            del sink[:100]


def google_client():
    """Eigener Google-Schlüssel (OAuth-Client), weil Google den gemeinsamen von rclone 2026 abschaltet."""
    data = read_json(GOOGLE_FILE, {})
    if isinstance(data, dict) and data.get("client_id") and data.get("client_secret"):
        return {"client_id": data["client_id"], "client_secret": data["client_secret"]}
    return {}


def save_google_client(body):
    cid = str(body.get("clientId") or "").strip()
    secret = str(body.get("clientSecret") or "").strip()
    if not cid and not secret:
        try:
            GOOGLE_FILE.unlink()
        except FileNotFoundError:
            pass
        return {"ok": True, "message": tr("Eigener Google-Schlüssel entfernt.")}
    old = google_client()
    if not secret and old.get("client_id") == cid:
        secret = old["client_secret"]
    if not re.fullmatch(r"[\w.-]+\.apps\.googleusercontent\.com", cid) or not secret:
        raise ValueError(tr("Die Client-ID endet auf .apps.googleusercontent.com; dazu gehört der Clientschlüssel."))
    write_json(GOOGLE_FILE, {"client_id": cid, "client_secret": secret}, private=True)
    changed = old.get("client_id") != cid
    if changed:   # Anmeldungen mit dem alten Schlüssel gelten nicht mehr
        for row in load_sources():
            if row["provider"] == "drive" and row.get("connected"):
                update_source(row["id"], connected=False)
    return {"ok": True, "message": tr("Gespeichert. Melde Google Drive jetzt neu an.") if changed else tr("Gespeichert.")}


def auth_start(sid):
    row = find_source(sid)
    if row is None:
        raise ValueError(tr("Quelle nicht gefunden."))
    provider = PROVIDERS[row["provider"]]
    exe = rclone()
    if not exe:
        raise RuntimeError(_rclone["error"] or "rclone?")
    with _auth_lock:
        stop_auth()
        args = [exe, "authorize", provider["type"]]
        extra = dict(provider.get("auth") or {})
        if row["provider"] == "drive":
            extra.update(google_client())
        if extra:
            blob = base64.urlsafe_b64encode(json.dumps(extra).encode()).decode().rstrip("=")
            args.append(blob)
        args.append("--auth-no-open-browser")
        proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                env=rclone_env(), cwd=str(DATA_DIR))
        out = []
        threading.Thread(target=_reader, args=(proc, out), daemon=True).start()
        _auth.update(proc=proc, sid=sid, out=out, started=now())
        local = ""
        for _ in range(150):
            match = re.search(r"http://127\.0\.0\.1:%d/auth\?state=([\w-]+)" % AUTH_PORT, "".join(out))
            if match:
                local, _auth["state"] = match.group(0), match.group(1)
                break
            if proc.poll() is not None:
                break
            time.sleep(0.1)
        if not local:
            text = short_error("".join(out))
            stop_auth()
            raise RuntimeError(text)
        answer = requests.get(local, allow_redirects=False, timeout=15)
        url = answer.headers.get("Location", "")
        if not url.startswith("https://"):
            stop_auth()
            raise RuntimeError(f"rclone authorize: HTTP {answer.status_code}")
        log(f"Anmeldung bei {provider['label']} gestartet.")
        return url


def auth_finish(sid, pasted):
    text = str(pasted or "").strip()
    query = parse_qs(urlparse(text).query) if "?" in text else parse_qs(text.lstrip("?"))
    code, state = (query.get("code") or [""])[0], (query.get("state") or [""])[0]
    if not code or not state:
        raise ValueError(tr("In der eingefügten Adresse fehlt code= oder state=. Kopiere die ganze Adresse aus der Adresszeile."))
    with _auth_lock:
        proc = _auth.get("proc")
        if proc is None or proc.poll() is not None or _auth["sid"] != sid or now() - _auth["started"] > AUTH_TIMEOUT:
            stop_auth()
            raise ValueError(tr("Die Anmeldung hat zu lange gedauert. Bitte noch einmal von vorn."))
        if state != _auth["state"]:
            raise ValueError(tr("Die Adresse gehört zu einer älteren Anmeldung. Klick noch einmal auf Anmelden."))
        params = {k: v[0] for k, v in query.items()}
        try:
            requests.get(f"http://127.0.0.1:{AUTH_PORT}/?{urlencode(params)}", timeout=60)
        except requests.RequestException:
            pass   # rclone beendet sich manchmal, bevor die Antwort ganz da ist
        out = _auth["out"]
        for _ in range(300):
            if "<---End paste" in "".join(out) or proc.poll() is not None:
                break
            time.sleep(0.1)
        time.sleep(0.2)
        joined = "".join(out)
        stop_auth()
    token = extract_token(joined)
    if not token and "invalid_grant" in joined:
        raise RuntimeError(tr("Der Anbieter hat den Code nicht angenommen (schon benutzt oder zu alt). Bitte noch einmal anmelden."))
    if not token:
        log(f"rclone authorize: {joined[-500:]}", "warning")
        raise RuntimeError(tr("Der Anbieter hat die Anmeldung abgelehnt: {exc}", exc=short_error(joined)))
    configure_oauth(sid, token, hostname=params.get("hostname", ""))
    return find_source(sid)


def extract_token(text):
    """Das Token-JSON aus der Ausgabe von rclone authorize (auch von Hand eingefügt)."""
    text = str(text or "")
    match = re.search(r"--->\s*(\{.*?\})\s*<---", text, re.S)
    candidates = [match.group(1)] if match else []
    candidates += re.findall(r"\{[^{}]*\"access_token\"[^{}]*\}", text, re.S)
    for raw in candidates:
        try:
            token = json.loads(raw)
        except ValueError:
            continue
        if isinstance(token, dict) and token.get("access_token"):
            return token
    return None


def configure_oauth(sid, token, hostname=""):
    row = find_source(sid)
    if row is None:
        raise ValueError(tr("Quelle nicht gefunden."))
    provider = row["provider"]
    options = {"type": PROVIDERS[provider]["type"], "token": json.dumps(token, separators=(",", ":"))}
    access = token.get("access_token", "")
    account = ""
    if provider == "drive":
        options["scope"] = "drive.readonly"
        options.update(google_client())
        if row.get("sharedWithMe"):
            options["shared_with_me"] = "true"
    elif provider == "onedrive":
        info = requests.get("https://graph.microsoft.com/v1.0/me/drive", timeout=(CONNECT_TIMEOUT, 30),
                            headers={"Authorization": f"Bearer {access}"})
        info.raise_for_status()
        drive = info.json()
        options["drive_id"] = drive.get("id", "")
        options["drive_type"] = drive.get("driveType", "personal")
        account = ((drive.get("owner") or {}).get("user") or {}).get("displayName", "")
    elif provider == "pcloud":
        hosts = [hostname] if hostname else []
        hosts += [h for h in ("api.pcloud.com", "eapi.pcloud.com") if h not in hosts]
        for host in hosts:
            try:
                answer = requests.get(f"https://{host}/userinfo", params={"access_token": access},
                                      timeout=(CONNECT_TIMEOUT, 20)).json()
            except (requests.RequestException, ValueError):
                continue
            if answer.get("result") == 0:
                options["hostname"] = host
                account = answer.get("email", "")
                break
    set_remote(sid, options)
    update_source(sid, connected=True, account=account, last={})
    log(f"Quelle {row.get('name')} verbunden ({PROVIDERS[provider]['label']}).")
    if row.get("folderChosen"):
        start_sync(sid)


def configure_webdav(sid, body):
    row = find_source(sid)
    if row is None:
        raise ValueError(tr("Quelle nicht gefunden."))
    url = str(body.get("url") or "").strip()
    user = str(body.get("user") or "").strip()
    password = str(body.get("password") or "")
    vendor = body.get("vendor") if body.get("vendor") in ("nextcloud", "owncloud", "other") else "nextcloud"
    conf = read_conf()
    old_pass = conf.get(remote_name(sid), "pass", fallback="") if conf.has_section(remote_name(sid)) else ""
    if url and not re.match(r"^https?://", url, re.I):
        url = "https://" + url
    if vendor in ("nextcloud", "owncloud") and url and "/remote.php/" not in url and user:
        url = url.rstrip("/") + f"/remote.php/dav/files/{quote(user)}/"
    if not url or not user or not (password or old_pass):
        raise ValueError(tr("Trag Adresse, Benutzer und Passwort ein."))
    set_remote(sid, {"type": "webdav", "url": url, "vendor": vendor, "user": user,
                     "pass": obscure(password) if password else old_pass})
    update_source(sid, webdavUrl=url, webdavUser=user, webdavVendor=vendor)
    check = test_source(sid)
    if check["ok"]:
        update_source(sid, connected=True, account=user, last={})
        if row.get("folderChosen"):
            start_sync(sid)
    return check


def configure_login(sid, body):
    """MEGA und Koofr: Benutzer (E-Mail) und Passwort."""
    row = find_source(sid)
    if row is None:
        raise ValueError(tr("Quelle nicht gefunden."))
    info = PROVIDERS.get(row["provider"], {})
    key = info.get("login")
    if not key:
        raise ValueError("provider")
    user = str(body.get("user") or "").strip()
    password = str(body.get("password") or "")
    conf = read_conf()
    old_pass = conf.get(remote_name(sid), key, fallback="") if conf.has_section(remote_name(sid)) else ""
    if not user or not (password or old_pass):
        raise ValueError(tr("Trag E-Mail und Passwort ein."))
    options = {"type": info["type"], "user": user, key: obscure(password) if password else old_pass}
    if row["provider"] == "koofr":
        options.update(provider="koofr", endpoint="https://app.koofr.net")
    set_remote(sid, options)
    update_source(sid, webdavUser=user)
    check = test_source(sid)
    if check["ok"]:
        update_source(sid, connected=True, account=user, last={})
        if row.get("folderChosen"):
            start_sync(sid)
    return check


def configure_custom(sid, text):
    raw = str(text or "").strip()
    if not raw.startswith("["):
        raw = "[x]\n" + raw
    parser = configparser.RawConfigParser()
    parser.optionxform = str
    try:
        parser.read_string(raw)
    except configparser.Error as exc:
        raise ValueError(str(exc).splitlines()[0][:200]) from exc
    section = parser.sections()[0] if parser.sections() else ""
    options = dict(parser.items(section)) if section else {}
    if not options.get("type"):
        raise ValueError(tr("Keine gültige rclone-Konfiguration (es fehlt type = …)."))
    set_remote(sid, options)
    check = test_source(sid)
    update_source(sid, connected=check["ok"], account=options.get("type", ""), last={})
    if check["ok"] and (find_source(sid) or {}).get("folderChosen"):
        start_sync(sid)
    return check


def configure_token(sid, text):
    token = extract_token(text)
    if not token:
        raise ValueError(tr("Kein gültiger Schlüssel gefunden. Füge die ganze Ausgabe von rclone authorize ein."))
    configure_oauth(sid, token)
    return {"ok": True, "message": tr("Verbunden.")}


# --------------------------------------------------------------------------
# iCloud (rclone iclouddrive: Apple-ID + Zwei-Faktor-Code, gilt 30 Tage)
# --------------------------------------------------------------------------

ICLOUD_DAYS = 30


def rclone_has_icloud_photos():
    try:
        out = run_rclone(["help", "backend", "iclouddrive"], timeout=30)
    except Exception:  # noqa: BLE001
        return False
    return '"photos"' in out


def ensure_icloud_rclone():
    """iCloud Fotos braucht ein neues rclone; ein altes System-rclone wird durch ein eigenes ersetzt."""
    if rclone_has_icloud_photos():
        return
    with _rclone_lock:
        install_rclone()
        _rclone.update(path="", version="")
    if not rclone_has_icloud_photos():
        raise RuntimeError(tr("Dieses rclone kann iCloud noch nicht."))


def _config_question(out):
    """Liest die JSON-Frage von rclone config --non-interactive."""
    start = out.find("{")
    if start < 0:
        return {}
    try:
        data = json.loads(out[start:out.rfind("}") + 1])
    except ValueError:
        return {}
    return data if isinstance(data, dict) else {}


def _icloud_answer(sid, q):
    """Antwort für die Seite: fertig, oder die nächste Frage (Code / Telefon)."""
    if q.get("Error"):
        return {"ok": False, "message": icloud_error(q["Error"]), "ask": _ask(q)}
    if not q.get("State"):
        check = test_source(sid)
        if check["ok"]:
            row = find_source(sid) or {}
            update_source(sid, connected=True, account=row.get("appleId", ""), last={},
                          authExpires=now() + ICLOUD_DAYS * 86400)
            if row.get("folderChosen"):
                start_sync(sid)
        else:
            check["message"] = icloud_error(check["message"])
        return check
    return {"ok": False, "ask": _ask(q), "message": ""}


def _ask(q):
    option = q.get("Option") or {}
    if not q.get("State"):
        return None
    name = option.get("Name", "")
    kind = "phone" if name == "config_2fa_phone" else "sms" if name == "config_2fa_sms" else "code"
    return {"state": q["State"], "kind": kind,
            "help": option.get("Help", ""),
            "choices": [{"value": e.get("Value"), "label": e.get("Help") or e.get("Value")}
                        for e in (option.get("Examples") or [])]}


def icloud_error(text):
    text = re.sub(r"^(NOTICE: )?Fatal error: ", "", str(text or "").strip())
    if re.search(r"authStart:|dial tcp|no such host|i/o timeout|connection refused", text):
        host = (re.search(r"https://([^/\"]+)", text) or [None, "apple.com"])[1]
        return tr("Apple ist nicht erreichbar ({host}). Pi-hole oder Firewall prüfen.", host=host)
    if re.search(r"Missing PCS|requestPCS", text):
        return tr("iCloud verlangt die Freigabe für das Web: auf dem iPhone Einstellungen > Apple-Account > iCloud > „Auf iCloud-Daten im Web zugreifen“ einschalten und die Anfrage bestätigen.")
    if re.search(r"trust token|reconnect", text, re.I):
        return tr("Die iCloud-Anmeldung ist abgelaufen (gilt 30 Tage). Bitte neu anmelden.")
    if re.search(r"401|403|Unauthorized|Forbidden|incorrect|invalid.*password", text, re.I):
        return tr("Apple hat die Anmeldung abgelehnt: Apple-ID oder Passwort falsch? Nimm das normale Passwort, kein App-Passwort.")
    if re.search(r"-21669|verification|code", text, re.I):
        return tr("Der Code stimmt nicht oder ist abgelaufen. Bitte noch einmal anmelden.")
    return text[:300]


def _run_config(args, timeout=120):
    exe = rclone()
    if not exe:
        raise RuntimeError(_rclone["error"] or "rclone?")
    proc = subprocess.run([exe] + args + ["--non-interactive", "--config", str(CONF_FILE)],
                          capture_output=True, text=True, timeout=timeout, env=rclone_env())
    q = _config_question(proc.stdout)
    if not q and proc.returncode != 0:
        q = {"Error": short_error(proc.stderr or proc.stdout), "State": ""}
    return q


def icloud_start(sid, body):
    row = find_source(sid)
    if row is None:
        raise ValueError(tr("Quelle nicht gefunden."))
    apple_id = str(body.get("appleId") or "").strip()
    password = str(body.get("password") or "")
    service = "drive" if body.get("service") == "drive" else "photos"
    conf = read_conf()
    old_pass = conf.get(remote_name(sid), "password", fallback="") if conf.has_section(remote_name(sid)) else ""
    if not apple_id or not (password or old_pass):
        raise ValueError(tr("Trag Apple-ID und Passwort ein."))
    ensure_icloud_rclone()
    secret = obscure(password) if password else old_pass
    set_remote(sid, {"type": "iclouddrive", "service": service, "apple_id": apple_id, "password": secret})
    changes = {"appleId": apple_id, "icloudService": service, "connected": False}
    if row.get("icloudService", "photos") != service:
        changes.update(remotePath="", folderChosen=False)
    update_source(sid, **changes)
    q = _run_config(["config", "create", remote_name(sid), "iclouddrive", f"service={service}",
                     f"apple_id={apple_id}", f"password={secret}", "--no-obscure"], timeout=180)
    return _icloud_answer(sid, q)


def icloud_code(sid, body):
    if find_source(sid) is None:
        raise ValueError(tr("Quelle nicht gefunden."))
    state = str(body.get("state") or "")
    code = str(body.get("code") or "").strip().replace(" ", "")
    if not state or not code:
        raise ValueError(tr("Bitte den Code eingeben."))
    q = _run_config(["config", "update", remote_name(sid), "--continue", "--state", state, "--result", code],
                    timeout=180)
    return _icloud_answer(sid, q)


# --------------------------------------------------------------------------
# Geteiltes iCloud-Album (öffentlicher Link, ganz ohne Anmeldung)
# --------------------------------------------------------------------------

ICLOUD_SHARED = os.environ.get("ICLOUD_SHARED_BASE", "")
B62 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
ALBUM_INDEX = ".cloud-folder-sync-album.json"


def album_token(url):
    url = str(url or "").strip()
    match = re.search(r"sharedalbum/?#([A-Za-z0-9]+)", url) or re.fullmatch(r"([AB][A-Za-z0-9]{10,})", url)
    if not match:
        raise ValueError(tr("Das ist kein Link zu einem geteilten iCloud-Album (https://www.icloud.com/sharedalbum/#…)."))
    return match.group(1)


def _album_host(token):
    if ICLOUD_SHARED:
        return ICLOUD_SHARED.rstrip("/")
    try:
        part = B62.index(token[1]) if token[0] == "A" else B62.index(token[1]) * 62 + B62.index(token[2])
    except (ValueError, IndexError):
        part = 23
    return f"https://p{part:02d}-sharedstreams.icloud.com"


def _album_post(token, what, payload, host=None):
    host = host or _album_host(token)
    headers = {"Content-Type": "text/plain", "Origin": "https://www.icloud.com",
               "User-Agent": f"DynaFrame-{PLUGIN_ID}/{version()}"}
    for _ in range(3):
        resp = requests.post(f"{host}/{token}/sharedstreams/{what}", data=json.dumps(payload), headers=headers,
                             timeout=(CONNECT_TIMEOUT, 60), allow_redirects=False)
        if resp.status_code == 330:
            moved = ""
            try:
                moved = resp.json().get("X-Apple-MMe-Host", "")
            except ValueError:
                pass
            moved = moved or resp.headers.get("X-Apple-MMe-Host", "")
            if not moved:
                break
            scheme = "http" if host.startswith("http://") else "https"
            host = f"{scheme}://{moved}"
            continue
        if resp.status_code in (401, 403, 404):
            raise RuntimeError(tr("Album nicht gefunden. Ist „Öffentliche Website“ in der Freigabe noch an?"))
        resp.raise_for_status()
        return resp.json(), host
    raise RuntimeError(tr("iCloud hat nicht geantwortet."))


def album_items(token, videos):
    stream, host = _album_post(token, "webstream", {"streamCtag": None})
    items = []
    for photo in stream.get("photos") or []:
        is_video = photo.get("mediaAssetType") == "video"
        if is_video and not videos:
            continue
        ders = {k: v for k, v in (photo.get("derivatives") or {}).items()
                if isinstance(v, dict) and v.get("checksum") and k != "PosterFrame"}
        if not ders:
            continue
        best = max(ders.values(), key=lambda d: (int(d.get("width") or 0) * int(d.get("height") or 0),
                                                 int(d.get("fileSize") or 0)))
        items.append({"guid": photo.get("photoGuid"), "checksum": best["checksum"], "video": is_video,
                      "size": int(best.get("fileSize") or 0), "date": photo.get("dateCreated", ""),
                      "caption": photo.get("caption", "")})
    return stream, host, [i for i in items if i["guid"]]


def album_check(url):
    token = album_token(url)
    stream, _host, items = album_items(token, True)
    return token, str(stream.get("streamName") or "").strip(), len(items)


def configure_album(sid, body):
    row = find_source(sid)
    if row is None:
        raise ValueError(tr("Quelle nicht gefunden."))
    try:
        token, title, count = album_check(body.get("url"))
    except requests.RequestException as exc:
        return {"ok": False, "message": tr("iCloud nicht erreichbar: {exc}", exc=str(exc)[:160])}
    except RuntimeError as exc:
        return {"ok": False, "message": str(exc)}
    url = f"https://www.icloud.com/sharedalbum/#{token}"
    changes = {"albumUrl": url, "connected": True, "folderChosen": True, "remotePath": "",
               "account": title or "iCloud", "last": {}}
    if title and row.get("name", "").startswith(PROVIDERS["icloudalbum"]["label"]):
        rows = load_sources()
        taken = {r.get("folder") for r in rows if r["id"] != sid}
        if safe_folder(title) not in taken:
            changes.update(name=title[:60], folder=safe_folder(title))
    update_source(sid, **changes)
    start_sync(sid)
    return {"ok": True, "message": tr("Album „{name}“ gefunden: {n} Fotos/Videos.", name=title or "iCloud", n=count)}


def sync_album(row, target, mirror):
    token = album_token(row.get("albumUrl"))
    _stream, host, items = album_items(token, row.get("videos"))
    index_file = target / ALBUM_INDEX
    index = read_json(index_file, {})
    index = index if isinstance(index, dict) else {}
    wanted = {i["guid"]: i for i in items}
    missing = [i for i in items if not (index.get(i["guid"]) and (target / index[i["guid"]]).exists())]
    copied = deleted = 0
    errors = []
    _sync["progress"] = {"done": 0, "total": len(missing)}
    for start in range(0, len(missing), 25):
        if _stop.is_set():
            break
        batch = missing[start:start + 25]
        try:
            urls, _ = _album_post(token, "webasseturls", {"photoGuids": [i["guid"] for i in batch]}, host)
        except Exception as exc:  # noqa: BLE001
            errors.append(str(exc))
            break
        located = urls.get("items") or {}
        for item in batch:
            loc = located.get(item["checksum"])
            if not loc:
                continue
            link = loc.get("url_path", "")
            link = link if link.startswith("http") else f"https://{loc.get('url_location', '')}{link}"
            if ICLOUD_SHARED and not link.startswith(ICLOUD_SHARED):
                link = ICLOUD_SHARED + "/" + link.split("://", 1)[-1].split("/", 1)[-1]
            base = os.path.basename(urlparse(link).path) or item["guid"]
            ext = os.path.splitext(base)[1].lower().lstrip(".")
            if ext not in PHOTO_EXT + VIDEO_EXT:
                base += ".mp4" if item["video"] else ".jpg"
            name = f"{item['guid'][:8]}_{safe_folder(base)}"
            try:
                with requests.get(link, stream=True, timeout=(CONNECT_TIMEOUT, 300)) as resp:
                    resp.raise_for_status()
                    temp = target / (".part-" + name)
                    with open(temp, "wb") as out:
                        for chunk in resp.iter_content(1 << 16):
                            out.write(chunk)
                    temp.replace(target / name)
                index[item["guid"]] = name
                copied += 1
                _sync["progress"] = {"done": copied, "total": len(missing)}
            except (requests.RequestException, OSError) as exc:
                errors.append(f"{base}: {exc}")
        write_json(index_file, index)
    if mirror:
        for guid in [g for g in index if g not in wanted]:
            try:
                (target / index[guid]).unlink()
            except FileNotFoundError:
                pass
            except OSError:
                continue
            index.pop(guid, None)
            deleted += 1
        write_json(index_file, index)
    return copied, deleted, errors


def remote_spec(row, path=None):
    folder = row.get("remotePath", "") if path is None else path
    return f"{remote_name(row['id'])}:{folder.strip('/')}"


def test_source(sid):
    row = find_source(sid)
    if row is None:
        return {"ok": False, "message": tr("Quelle nicht gefunden.")}
    if row["provider"] == "icloudalbum":
        try:
            album_check(row.get("albumUrl"))
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "message": str(exc)[:300]}
        return {"ok": True, "message": tr("Verbunden.")}
    try:
        run_rclone(["lsjson", remote_spec(row, ""), "--dirs-only", "--max-depth", "1",
                    "--contimeout", "20s", "--timeout", "60s", "--low-level-retries", "2", "--retries", "1"],
                   timeout=120)
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "message": str(exc)}
    return {"ok": True, "message": tr("Verbunden.")}


def browse(sid, path):
    row = find_source(sid)
    if row is None:
        raise ValueError(tr("Quelle nicht gefunden."))
    path = str(path or "").strip("/")
    out = run_rclone(["lsjson", remote_spec(row, path), "--max-depth", "1", "--no-modtime", "--no-mimetype",
                      "--contimeout", "20s", "--timeout", "90s", "--retries", "1"], timeout=150)
    items = json.loads(out or "[]")
    dirs = sorted((i["Name"] for i in items if i.get("IsDir")), key=str.lower)
    exts = PHOTO_EXT + VIDEO_EXT
    files = sum(1 for i in items if not i.get("IsDir") and i.get("Name", "").rsplit(".", 1)[-1].lower() in exts)
    return {"path": path, "dirs": dirs[:500], "media": files}


def local_roots():
    """Wo man auf dem Rahmen Ordner aussuchen darf: nur DynaFrames Medienordner (nur dort sucht die Datenbank)."""
    roots = []
    try:
        paths = engine_call("GET", "/media/paths", timeout=15) or []
        if isinstance(paths, dict):
            paths = paths.get("paths") or paths.get("items") or []
        roots += [Path(p.rstrip("/") or "/") for p in paths if isinstance(p, str) and p.startswith("/")]
    except EngineError:
        pass
    pictures = base_folder().parent
    if pictures not in roots:
        roots.insert(0, pictures)
    out = []
    for r in roots:
        if r.is_dir() and r not in out and str(r) not in ("/", "/home"):
            out.append(r)
    return out or [Path.home()]


def _inside(path, roots):
    return any(path == r or r in path.parents for r in roots)


def local_browse(path):
    roots = local_roots()
    start = base_folder().parent
    if not start.is_dir():
        start = roots[0]
    raw = str(path or "").strip()
    target = Path(os.path.normpath(raw)) if raw.startswith("/") else start
    while not target.is_dir() and target != target.parent:
        target = target.parent
    if not _inside(target, roots):
        target = start
    exts = {"." + e for e in PHOTO_EXT + VIDEO_EXT}
    dirs, media = [], 0
    try:
        with os.scandir(target) as it:
            for e in it:
                if e.name.startswith(".") or e.name == "lost+found":
                    continue
                try:
                    if e.is_dir():
                        dirs.append(e.name)
                    elif os.path.splitext(e.name)[1].lower() in exts:
                        media += 1
                except OSError:
                    pass
    except OSError as exc:
        raise ValueError(tr("Ordner nicht lesbar.") + f" ({exc.strerror})")
    parent = target.parent if target != target.parent and _inside(target.parent, roots) else None
    return {"path": str(target), "parent": str(parent) if parent else "",
            "dirs": sorted(dirs, key=str.lower)[:500], "media": media,
            "roots": [str(r) for r in roots], "default": str(start)}


def local_mkdir(parent, name):
    name = str(name or "").strip()
    if not name or "/" in name or name.startswith(".") or len(name) > 80:
        raise ValueError(tr("Bitte einen Ordnernamen ohne / eingeben."))
    base = Path(os.path.normpath(str(parent or "")))
    if not str(parent or "").startswith("/") or not base.is_dir() or not _inside(base, local_roots()):
        raise ValueError(tr("Ordner nicht gefunden."))
    new = base / name
    new.mkdir(exist_ok=True)
    return {"path": str(new)}


# --------------------------------------------------------------------------
# Die Engine und der Ordner auf dem Rahmen
# --------------------------------------------------------------------------

class EngineError(Exception):
    pass


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, params=None, timeout=60):
    try:
        response = requests.request(method, engine_base() + path, json=payload, params=params,
                                    headers=engine_headers(), timeout=(CONNECT_TIMEOUT, timeout))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}")
    if not (response.content or b"").strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_base = {"path": None, "at": 0.0}


def base_folder():
    """<Bilder-Ordner von DynaFrame>/Cloud Folder Sync, oder der eingestellte Ordner."""
    chosen = settings()["BaseFolder"]
    if chosen:
        return Path(chosen)
    if _base["path"] is None or now() - _base["at"] > 600:
        root = None
        try:
            paths = engine_call("GET", "/media/paths", timeout=15) or []
            if isinstance(paths, dict):
                paths = paths.get("paths") or paths.get("items") or []
            local = [p for p in paths if isinstance(p, str) and p.startswith("/") and not p.startswith(("/mnt", "/media"))]
            root = next((p for p in local if p.rstrip("/").endswith("Pictures")), None) or (local[0] if local else None)
        except EngineError:
            pass
        root = Path(root) if root else Path.home() / "Pictures"
        _base.update(path=root / FOLDER_NAME, at=now())
    return _base["path"]


_notify = {"how": None}


def notify_dynaframe(folder):
    """DynaFrame die neuen Dateien einlesen lassen (Ordner-Scan, sonst Datenbank-Update)."""
    folder = str(folder)
    attempts = [
        ("POST", "/media/scan-directory", {"directory": folder, "path": folder, "directoryPath": folder}, None),
        ("POST", "/media/scan-directory", None, {"path": folder}),
        ("POST", "/media/scan-directory", None, {"directory": folder}),
        ("POST", "/media/database/update", None, None),
    ]
    order = list(range(len(attempts)))
    if _notify["how"] is not None:
        order.remove(_notify["how"])
        order.insert(0, _notify["how"])
    for index in order:
        method, path, payload, params = attempts[index]
        try:
            engine_call(method, path, payload=payload, params=params, timeout=120)
        except EngineError as exc:
            log(f"DynaFrame-Scan: {exc}")
            continue
        if _notify["how"] != index:
            log(f"DynaFrame liest neue Fotos über {path} {payload or params or ''} ein.")
        _notify["how"] = index
        return True
    log("Konnte DynaFrame nicht zum Einlesen bewegen; es findet die Fotos beim nächsten eigenen Scan.", "warning")
    return False


def count_media(folder):
    exts = {"." + e for e in PHOTO_EXT + VIDEO_EXT}
    total = 0
    for _root, _dirs, files in os.walk(folder):
        total += sum(1 for f in files if os.path.splitext(f)[1].lower() in exts)
    return total


def free_mb(path):
    probe = Path(path)
    while not probe.exists() and probe != probe.parent:
        probe = probe.parent
    try:
        return shutil.disk_usage(probe).free // (1024 * 1024)
    except OSError:
        return -1


# --------------------------------------------------------------------------
# Abgleich
# --------------------------------------------------------------------------

_sync = {"current": "", "progress": {}, "at": 0.0, "lastRun": 0.0, "queue": [], "error": ""}
_sync_lock = threading.Lock()
_sync_wake = threading.Event()
_stop = threading.Event()


def start_sync(sid=None):
    rows = [r for r in load_sources() if r.get("connected") and r.get("folderChosen")
            and r.get("enabled", True) is not False]
    ids = [r["id"] for r in rows if sid in (None, r["id"])]
    for ident in ids:
        if ident not in _sync["queue"]:
            _sync["queue"].append(ident)
    _sync_wake.set()
    return {"success": True, "message": tr("Abgleich gestartet.") if ids else tr("Noch nicht verbunden.")}


def include_pattern(videos):
    exts = PHOTO_EXT + (VIDEO_EXT if videos else ())
    return "*.{" + ",".join(exts) + "}"


def sync_source(row):
    lang = settings()["Language"]
    limit = settings()["MinFreeMB"]
    target = source_target(row)
    try:
        target.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise RuntimeError(t(lang, "Kann nicht in {path} schreiben: {exc}", path=target, exc=exc)) from exc
    free = free_mb(target)
    if 0 <= free < limit:
        raise RuntimeError(t(lang, "Auf dem Rahmen sind nur noch {free} MB frei; Abgleich angehalten (Grenze {limit} MB).",
                             free=free, limit=limit))
    mode = "sync" if row.get("mode", "mirror") == "mirror" else "copy"
    # Schutz: einen fremden Ordner, in dem schon Fotos liegen, nie spiegeln (würde sie löschen)
    if not (target / MARKER).exists():
        if count_media(target) and base_folder() not in target.parents:
            mode = "copy"
        else:
            try:
                (target / MARKER).write_text("Cloud Folder Sync\n")
            except OSError:
                pass
    if row["provider"] == "icloudalbum":
        copied, deleted, errors = sync_album(row, target, mode == "sync")
        total = count_media(target)
        if errors and not (copied or deleted):
            raise RuntimeError(short_error(errors[-1]))
        if copied or deleted:
            notify_dynaframe(target)
        text = t(lang, "Abgeglichen {time}: {new} neu, {gone} entfernt, {total} Dateien.",
                 time=clock(now()), new=copied, gone=deleted, total=total)
        if errors:
            text += " " + short_error(errors[-1])
        return {"at": now(), "ok": not errors, "text": text, "files": total, "new": copied, "gone": deleted}
    exe = rclone()
    if not exe:
        raise RuntimeError(_rclone["error"] or "rclone?")
    args = [exe, mode, remote_spec(row), str(target), "--config", str(CONF_FILE),
            "--ignore-case", "--include", include_pattern(row.get("videos")),
            "--transfers", "2", "--checkers", "4", "--retries", "2", "--low-level-retries", "5",
            "--contimeout", "30s", "--timeout", "5m", "--max-size", "1G",
            "--use-json-log", "--log-level", "INFO", "--stats", "5s", "--stats-log-level", "NOTICE"]
    if row["provider"] == "drive":
        args += ["--drive-skip-gdocs", "--drive-skip-shortcuts"]
    # Lässt beim Spiegeln nicht mehr als die Hälfte (mind. 50) auf einmal löschen
    before = count_media(target)
    if mode == "sync":
        args += ["--max-delete", str(max(50, before // 2))]
    proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=rclone_env())
    copied = deleted = 0
    errors = []
    for line in iter(proc.stdout.readline, ""):
        if _stop.is_set():
            proc.terminate()
            break
        try:
            entry = json.loads(line)
        except ValueError:
            if line.strip():
                errors.append(line.strip())
            continue
        msg = str(entry.get("msg") or "")
        if entry.get("stats"):
            s = entry["stats"]
            _sync["progress"] = {"done": s.get("transfers", 0), "total": s.get("totalTransfers", 0),
                                 "bytes": s.get("bytes", 0), "totalBytes": s.get("totalBytes", 0)}
        elif msg.startswith("Copied") or msg.startswith("Multi-thread Copied"):
            copied += 1
        elif msg.startswith("Deleted"):
            deleted += 1
        elif entry.get("level") in ("error", "critical"):
            errors.append(f"{entry.get('object') or ''} {msg}".strip())
    code = proc.wait()
    total = count_media(target)
    if code != 0 and not (copied or deleted):
        raise RuntimeError(short_error("\n".join(errors[-5:])) if errors else f"rclone exit {code}")
    if copied or deleted:
        notify_dynaframe(target)
    text = t(lang, "Abgeglichen {time}: {new} neu, {gone} entfernt, {total} Dateien.",
             time=clock(now()), new=copied, gone=deleted, total=total)
    if errors and code != 0:
        text += " " + short_error(errors[-1])
    return {"at": now(), "ok": code == 0, "text": text, "files": total, "new": copied, "gone": deleted}


def sync_loop():
    while not _stop.is_set():
        interval = settings()["IntervalMinutes"] * 60
        due = now() - _sync["lastRun"] >= interval
        if due:
            _sync["lastRun"] = now()
            start_sync()
        while _sync["queue"] and not _stop.is_set():
            sid = _sync["queue"].pop(0)
            row = find_source(sid)
            if row is None or not row.get("connected"):
                continue
            with _sync_lock:
                _sync.update(current=sid, progress={})
                try:
                    result = sync_source(row)
                    if result["new"] or result["gone"]:
                        log(f"{row.get('name')}: {result['new']} neu, {result['gone']} entfernt.")
                except Exception as exc:  # noqa: BLE001
                    text = str(exc)
                    if "abgelaufen" in text or "expired" in text:
                        update_source(sid, connected=False)
                    result = {"at": now(), "ok": False, "text": tr("Fehler beim Abgleich: {exc}", exc=text),
                              "files": count_media(source_target(row))}
                    log(f"{row.get('name')}: {text}", "warning")
                update_source(sid, last=result)
                _sync.update(current="", progress={}, at=now())
        _sync_wake.wait(30)
        _sync_wake.clear()


# --------------------------------------------------------------------------
# Verbindungen (Karte „Verbindungen“)
# --------------------------------------------------------------------------

_services = {"rows": [], "at": 0.0, "busy": False}
_services_lock = threading.Lock()
SERVICES_EVERY = 300


def _row(key, name, state, text, hint=""):
    return {"key": key, "name": name, "state": state, "text": text, "hint": hint}


def check_services(force=False):
    with _services_lock:
        if _services["busy"] or (not force and now() - _services["at"] < SERVICES_EVERY and _services["rows"]):
            return _services["rows"]
        _services["busy"] = True
    try:
        lang = settings()["Language"]
        rows = []
        try:
            engine_call("GET", "/playlists", timeout=15)
            rows.append(_row("engine", "DynaFrame", "ok", t(lang, "Antwortet.")))
        except EngineError as exc:
            rows.append(_row("engine", "DynaFrame", "bad", t(lang, "DynaFrame antwortet nicht: {exc}", exc=exc)))
        path, ver = find_rclone()
        if path:
            _rclone.update(path=path, version=ver)
            rows.append(_row("rclone", "rclone", "ok", t(lang, "rclone {version} ist bereit.", version=ver)))
        elif _rclone["error"]:
            rows.append(_row("rclone", "rclone", "bad", _rclone["error"], "downloads.rclone.org"))
        else:
            rows.append(_row("rclone", "rclone", "warn",
                             t(lang, "rclone wird beim ersten Abgleich von downloads.rclone.org geladen (ca. 25 MB).")))
        target = base_folder()
        try:
            target.mkdir(parents=True, exist_ok=True)
            probe = target / ".write-test"
            probe.write_text("ok")
            probe.unlink()
            files = count_media(target)
            text = t(lang, "Ordner {path}: {files} Dateien, {free} MB frei.", path=target, files=files, free=free_mb(target))
            state = "ok"
            known = media_known(target)
            if known is not None:
                text += " " + t(lang, "DynaFrame kennt {n} davon.", n=known)
                if files and known == 0:
                    state = "warn"
            rows.append(_row("folder", t(lang, "Bilder auf dem Rahmen"), state, text))
        except OSError as exc:
            rows.append(_row("folder", t(lang, "Bilder auf dem Rahmen"), "bad",
                             t(lang, "Kann nicht in {path} schreiben: {exc}", path=target, exc=exc)))
        for row in load_sources():
            label = f"{row.get('name')} ({PROVIDERS.get(row['provider'], {}).get('label', '?')})"
            if not row.get("connected"):
                rows.append(_row("src-" + row["id"], label, "warn", t(lang, "Noch nicht verbunden.")))
                continue
            if not row.get("folderChosen"):
                rows.append(_row("src-" + row["id"], label, "warn", t(lang, "Wähle jetzt den Ordner mit den Fotos.")))
                continue
            if path:
                check = test_source(row["id"])
                if not check["ok"]:
                    rows.append(_row("src-" + row["id"], label, "bad", check["message"]))
                    continue
            last = row.get("last") or {}
            rows.append(_row("src-" + row["id"], label, "ok" if last.get("ok", True) else "warn",
                             last.get("text") or t(lang, "Verbunden.")))
        before = {r["key"]: r["state"] for r in _services["rows"]}
        for r in rows:
            if r["state"] == "bad" and before.get(r["key"]) != "bad":
                log(f"{r['name']}: {r['text']}", "warning")
        _services.update(rows=rows, at=now())
        return rows
    finally:
        _services["busy"] = False


def media_known(folder):
    try:
        answer = engine_call("GET", "/media/database/by-directory",
                             params={"directories": str(folder), "recursive": "true"}, timeout=30)
    except EngineError:
        return None
    if isinstance(answer, list):
        return len(answer)
    if isinstance(answer, dict):
        for key in ("totalCount", "count", "total"):
            if isinstance(answer.get(key), int):
                return answer[key]
        for key in ("items", "files", "media"):
            if isinstance(answer.get(key), list):
                return len(answer[key])
    return None


def services_payload():
    rows = _services["rows"]
    return {"at": _services["at"] or None, "busy": _services["busy"], "rows": rows,
            "bad": sum(1 for r in rows if r["state"] == "bad"),
            "warn": sum(1 for r in rows if r["state"] == "warn")}


# --------------------------------------------------------------------------
# Eigene Playlist mit dem Ordner
# --------------------------------------------------------------------------

def create_folder_playlist(name):
    folder = base_folder()
    folder.mkdir(parents=True, exist_ok=True)
    created = engine_call("POST", "/playlists", {
        "name": name, "description": tr("Fotos aus deinen Cloud-Ordnern."),
        "directoryPath": str(folder), "includeSubdirectories": True}) or {}
    return created.get("id") or (created.get("playlist") or {}).get("id")


OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=(PLAYLIST_NAME,),
    name=lambda: PLAYLIST_NAME,
    description=lambda: tr("Fotos aus deinen Cloud-Ordnern."),
    scene_id=lambda: None,
    seconds=lambda: 0,
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=lambda method, path, payload=None: engine_call(method, path, payload),
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
    create=create_folder_playlist,
)


# --------------------------------------------------------------------------
# Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    rows = load_sources()
    target = base_folder()
    return {
        "success": True,
        "version": version(),
        "settings": values,
        "ownPlaylist": OWN.text(),
        "sources": [public_source(r) for r in rows],
        "folder": str(target),
        "files": sum((r.get("last") or {}).get("files", 0) for r in rows),
        "syncing": _sync["current"],
        "queue": list(_sync["queue"]),
        "lastSync": max([(r.get("last") or {}).get("at") or 0 for r in rows] or [0]) or None,
        "rclone": {"version": _rclone["version"], "busy": _rclone["busy"], "note": _rclone["note"],
                   "error": _rclone["error"]},
        "auth": {"sid": _auth["sid"]},
        "google": {"clientId": google_client().get("client_id", "")},
        "services": services_payload(),
        "theme": {"id": theme_id()},
    }


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status)

    def _body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        raw = self.rfile.read(min(length, 256 * 1024)) if length > 0 else b""
        try:
            body = json.loads(raw.decode("utf-8")) if raw else {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
            elif path in STUDIO_FILES:
                asset = STUDIO_FILES[path]
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
            elif path == "/api/state":
                self._json(state_payload())
            elif path == "/api/services":
                check_services(force=True)
                self._json({"success": True, "services": services_payload()})
            elif path == "/api/localbrowse":
                self._json(dict(local_browse((query.get("path") or [""])[0]), success=True))
            elif path == "/api/browse":
                sid = (query.get("id") or [""])[0]
                self._json(dict(browse(sid, (query.get("path") or [""])[0]), success=True))
            else:
                self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # noqa: BLE001
            self._json({"success": False, "error": str(exc)}, 500 if isinstance(exc, OSError) else 400)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        body = self._body()
        sid = str(body.get("id") or "")
        try:
            if path == "/api/settings":
                changed = save_settings(body)
                if "MakePlaylist" in changed:
                    OWN.changed()
                if "BaseFolder" in changed:
                    _base.update(path=None)
                self._json({"success": True, "changed": changed})
            elif path == "/api/source/add":
                self._json({"success": True, "source": public_source(add_source(str(body.get("provider"))))})
            elif path == "/api/localmkdir":
                self._json(dict(local_mkdir(body.get("parent"), body.get("name")), success=True))
            elif path == "/api/source/edit":
                self._json({"success": True, "source": public_source(edit_source(sid, body))})
            elif path == "/api/source/remove":
                remove_source(sid, as_bool(body.get("deleteFiles")))
                self._json({"success": True})
            elif path == "/api/source/test":
                self._json(dict(test_source(sid), success=True))
            elif path == "/api/auth/start":
                self._json({"success": True, "url": auth_start(sid)})
            elif path == "/api/auth/finish":
                row = auth_finish(sid, body.get("callback"))
                self._json({"success": True, "source": public_source(row)})
            elif path == "/api/auth/cancel":
                with _auth_lock:
                    stop_auth()
                self._json({"success": True})
            elif path == "/api/auth/token":
                self._json(dict(configure_token(sid, body.get("token")), success=True))
            elif path == "/api/icloud/start":
                self._json(dict(icloud_start(sid, body), success=True))
            elif path == "/api/icloud/code":
                self._json(dict(icloud_code(sid, body), success=True))
            elif path == "/api/album":
                self._json(dict(configure_album(sid, body), success=True))
            elif path == "/api/google":
                self._json(dict(save_google_client(body), success=True))
            elif path == "/api/login":
                self._json(dict(configure_login(sid, body), success=True))
            elif path == "/api/webdav":
                self._json(dict(configure_webdav(sid, body), success=True))
            elif path == "/api/custom":
                self._json(dict(configure_custom(sid, body.get("config")), success=True))
            elif path == "/api/sync":
                self._json(start_sync(sid or None))
            elif path == "/api/playlist":
                self._json(OWN.create_now())
            else:
                self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # noqa: BLE001
            self._json({"success": False, "error": str(exc)}, 400)


studio_server = None


def start_studio():
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")


def services_loop():
    while not _stop.is_set():
        try:
            check_services(force=True)
            OWN.maintain()
        except Exception as exc:  # noqa: BLE001
            log(f"Prüfung: {exc}", "warning")
        _stop.wait(SERVICES_EVERY)


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(DATA_DIR, 0o700)   # rclone.conf enthält die Anmeldungen
    except OSError:
        pass
    log(f"Starte {PLUGIN_ID} {version()}")
    plugin.on_action("sync", lambda _context=None: start_sync())
    plugin.on_action("playlist", lambda _context=None: OWN.create_now())
    start_studio()
    plugin.connect_sse()
    plugin.ready()
    _sync["lastRun"] = now() - settings()["IntervalMinutes"] * 60 + 20   # erster Abgleich nach 20 s
    threading.Thread(target=sync_loop, name=f"{PLUGIN_ID}-sync", daemon=True).start()
    threading.Thread(target=services_loop, name=f"{PLUGIN_ID}-services", daemon=True).start()
    try:
        while not _stop.is_set():
            _stop.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop.set()
    _sync_wake.set()
    with _auth_lock:
        stop_auth()
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:  # noqa: BLE001
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:  # noqa: BLE001
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
