/* Photo Scanner - die Szene.
 *
 * Zeigt ein Foto nach dem anderen und "scannt" es wie im Science-Fiction-Film:
 * Scanlinie über das Foto, Fadenkreuz rastet auf der Stelle mit den meisten
 * Details ein, Datenpanels tippen sich ein (Bild, Aufnahme, Optik, Analyse,
 * Archiv links und rechts, GPS mit kleinem Globus, Farbspektrum, Histogramm).
 * Unten laufen Live-Werte des Rahmens: CPU, Speicher, Netzwerk, Temperatur,
 * Speicherplatz und die Mediathek.
 *
 * Foto und Daten kommen vom Plugin PhotoScanner (api/next analysiert und
 * verkleinert, api/photo liefert das JPEG, api/telemetry die Live-Werte).
 * Das nächste Foto wird geholt, während das aktuelle zu sehen ist.
 *
 * Bewegung nur über CSS (Deckkraft, transform, clip-path) und kleine Canvas,
 * damit es auf dem Pi flüssig bleibt.
 * Test im Browser: ?plugin=<url-der-plugin-seite>/ und ?lang=, ?accent=, ?seconds=, ?tele=0
 */
(function () {
  "use strict";

  const PLUGIN_ID = "PhotoScanner";
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  // Über die Weboberfläche (Port 80/443) nur denselben Ursprung fragen: Port 8003 lässt die Firewall von außen fallen.
  const viaWebUi = location.port === "" || location.port === "80" || location.port === "443";
  const pluginBases = params.get("plugin") ? [params.get("plugin")]
    : viaWebUi ? [`${location.origin}${advanced}`]
    : [...new Set([
      `${location.protocol}//${location.hostname}:8003${advanced}`,
      `${location.origin}${advanced}`,
      `${location.protocol}//${location.hostname}${advanced}`,
    ])];
  let baseIndex = 0;
  let baseFound = false;

  const TEXT = {
    de: {
      empty: "Keine Fotos. Wähle auf der Plugin-Seite, woher sie kommen.", busy: "Suche Fotos …",
      offline: "Photo Scanner wartet auf das Plugin …",
      scanId: "Scan-ID", geo: "Geo-Position", spectrum: "Spektrum", image: "Bild", capture: "Aufnahme",
      optics: "Optik", analysis: "Analyse", archive: "Archiv", memory: "Speicher", network: "Netzwerk",
      temp: "Temperatur", disk: "Speicherplatz", library: "Mediathek",
      phaseScan: "Scanne", phaseLock: "Analyse fertig", phaseWait: "Warte auf Daten",
      res: "Auflösung", size: "Größe", format: "Format", aspect: "Format", mp: "Megapixel", preview: "nur Vorschau",
      date: "Datum", time: "Uhrzeit", day: "Wochentag", age: "Alter", noDate: "Keine Zeitangabe",
      camera: "Kamera", lens: "Objektiv", focal: "Brennweite", aperture: "Blende", shutter: "Belichtung", iso: "ISO",
      ev: "LW", flash: "Blitz", flashOn: "ausgelöst", flashOff: "aus", noExif: "Kein EXIF-Signal",
      lat: "Breite", lon: "Länge", alt: "Höhe", place: "Ort", heading: "Richtung", noGps: "Kein GPS-Fix",
      gpsLock: "GPS-Fix", hidden: "ausgeblendet",
      brightness: "Helligkeit", contrast: "Kontrast", saturation: "Sättigung", colourful: "Farbigkeit",
      sharpness: "Schärfe", detail: "Details", clip: "Clipping", entropy: "Entropie", key: "Tonwert",
      lowKey: "Low Key", highKey: "High Key", balanced: "ausgewogen", mean: "Mittel",
      rating: "Bewertung", tags: "Tags", people: "Personen", faces: "Gesichter", file: "Datei", source: "Quelle",
      title: "Titel", favorite: "Favorit", focusLock: "Fokus", none: "keine",
      cores: "Kerne", load: "Last", up: "Laufzeit", free: "frei", photos: "Fotos", videos: "Videos",
      located: "mit GPS", cameras: "Kameras", peak: "Spitze",
      ago: (y, m, d) => y ? `vor ${y} J ${m} Mon` : m ? `vor ${m} Mon ${d} T` : `vor ${d} Tagen`,
    },
    en: {
      empty: "No photos. Choose on the plugin page where they come from.", busy: "Looking for photos …",
      offline: "Photo Scanner is waiting for the plugin …",
      scanId: "Scan ID", geo: "Geo position", spectrum: "Spectrum", image: "Image", capture: "Capture",
      optics: "Optics", analysis: "Analysis", archive: "Archive", memory: "Memory", network: "Network",
      temp: "Temp", disk: "Storage", library: "Library",
      phaseScan: "Scanning", phaseLock: "Analysis complete", phaseWait: "Awaiting data",
      res: "Resolution", size: "Size", format: "Format", aspect: "Aspect", mp: "Megapixels", preview: "preview only",
      date: "Date", time: "Time", day: "Weekday", age: "Age", noDate: "No time signal",
      camera: "Camera", lens: "Lens", focal: "Focal", aperture: "Aperture", shutter: "Shutter", iso: "ISO",
      ev: "EV", flash: "Flash", flashOn: "fired", flashOff: "off", noExif: "No EXIF signal",
      lat: "Lat", lon: "Lon", alt: "Altitude", place: "Place", heading: "Heading", noGps: "No GPS lock",
      gpsLock: "GPS lock", hidden: "hidden",
      brightness: "Brightness", contrast: "Contrast", saturation: "Saturation", colourful: "Colourfulness",
      sharpness: "Sharpness", detail: "Detail", clip: "Clipping", entropy: "Entropy", key: "Tone",
      lowKey: "Low key", highKey: "High key", balanced: "balanced", mean: "Mean",
      rating: "Rating", tags: "Tags", people: "People", faces: "Faces", file: "File", source: "Source",
      title: "Title", favorite: "Favourite", focusLock: "Focus lock", none: "none",
      cores: "cores", load: "load", up: "Uptime", free: "free", photos: "photos", videos: "videos",
      located: "with GPS", cameras: "cameras", peak: "peak",
      ago: (y, m, d) => y ? `${y} y ${m} mo ago` : m ? `${m} mo ${d} d ago` : `${d} days ago`,
    },
    es: {
      empty: "No hay fotos. Elige en la página del plugin de dónde vienen.", busy: "Buscando fotos …",
      offline: "Photo Scanner está esperando al plugin …",
      scanId: "ID de escaneo", geo: "Geoposición", spectrum: "Espectro", image: "Imagen", capture: "Captura",
      optics: "Óptica", analysis: "Análisis", archive: "Archivo", memory: "Memoria", network: "Red",
      temp: "Temp", disk: "Almacenamiento", library: "Biblioteca",
      phaseScan: "Escaneando", phaseLock: "Análisis completo", phaseWait: "Esperando datos",
      res: "Resolución", size: "Tamaño", format: "Formato", aspect: "Proporción", mp: "Megapíxeles", preview: "solo vista previa",
      date: "Fecha", time: "Hora", day: "Día", age: "Edad", noDate: "Sin señal de tiempo",
      camera: "Cámara", lens: "Objetivo", focal: "Focal", aperture: "Diafragma", shutter: "Exposición", iso: "ISO",
      ev: "EV", flash: "Flash", flashOn: "disparado", flashOff: "no", noExif: "Sin señal EXIF",
      lat: "Lat", lon: "Lon", alt: "Altitud", place: "Lugar", heading: "Rumbo", noGps: "Sin señal GPS",
      gpsLock: "GPS fijado", hidden: "oculto",
      brightness: "Brillo", contrast: "Contraste", saturation: "Saturación", colourful: "Colorido",
      sharpness: "Nitidez", detail: "Detalle", clip: "Recorte", entropy: "Entropía", key: "Tono",
      lowKey: "Clave baja", highKey: "Clave alta", balanced: "equilibrado", mean: "Media",
      rating: "Valoración", tags: "Etiquetas", people: "Personas", faces: "Caras", file: "Archivo", source: "Fuente",
      title: "Título", favorite: "Favorita", focusLock: "Enfoque", none: "ninguna",
      cores: "núcleos", load: "carga", up: "Activo", free: "libre", photos: "fotos", videos: "vídeos",
      located: "con GPS", cameras: "cámaras", peak: "pico",
      ago: (y, m, d) => y ? `hace ${y} a ${m} m` : m ? `hace ${m} m ${d} d` : `hace ${d} días`,
    },
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const ACCENTS = { cyan: "#38e8ff", amber: "#ffb000", green: "#4dff8a", magenta: "#ff4fd8", white: "#e8f1f5" };
  const STORE = "photoScanner.v1";

  const $ = (id) => document.getElementById(id);
  const root = document.documentElement;
  const state = {
    lang: "en", accent: "cyan", tele: true, coords: "exact", effect: true, seconds: 25,
    loaded: false, busy: false, photos: 0,
  };
  let U = 1;
  let readySent = false;
  let current = null;
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const tx = (key) => (TEXT[state.lang] || TEXT.en)[key] ?? TEXT.en[key] ?? key;
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const num = (v, digits = 0) => Number(v).toLocaleString(LOCALES[state.lang], { minimumFractionDigits: digits, maximumFractionDigits: digits });

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 8000);   // Rückfall: DynaFrame bricht sonst die Szene ab

  function report(text) {
    try {
      fetch(`${pluginBases[baseIndex]}api/report?m=${encodeURIComponent(String(text).slice(0, 200))}`,
        { cache: "no-store" }).catch(() => {});
    } catch (_) { /* egal */ }
  }

  // ------------------------------------------------------------ Daten

  async function fetchJson(path, ms = 15000) {
    const used = baseIndex;
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), ms);
    try {
      const response = await fetch(pluginBases[used] + path, { cache: "no-store", signal: abort.signal });
      if (!response.ok && response.status !== 404) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      baseFound = true;
      return data;
    } catch (error) {
      if (!baseFound && pluginBases.length > 1 && used === baseIndex) baseIndex = (baseIndex + 1) % pluginBases.length;
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  function remember(data) { try { localStorage.setItem(STORE, JSON.stringify(data)); } catch (_) { /* kein Speicher */ } }
  function recall() { try { return JSON.parse(localStorage.getItem(STORE) || "null"); } catch (_) { return null; } }

  function hexRgb(hex) {
    const n = parseInt(String(hex).replace("#", ""), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  function setAccent(hex) {
    const [r, g, b] = hexRgb(hex);
    root.style.setProperty("--acc", hex);
    root.style.setProperty("--acc-rgb", `${r}, ${g}, ${b}`);
  }

  // Akzent "photo": die kräftigste Farbe des Fotos, hell genug für dunklen Grund
  function photoAccent(palette) {
    let best = null, score = -1;
    for (const c of palette || []) {
      const [r, g, b] = hexRgb(c.hex);
      const high = Math.max(r, g, b), low = Math.min(r, g, b);
      const s = (high - low) / (high || 1) * Math.sqrt(Math.max(0.02, c.share || 0.02));
      if (s > score) { score = s; best = [r, g, b]; }
    }
    if (!best) return ACCENTS.cyan;
    const high = Math.max(...best) || 1;
    const lift = 235 / high;   // auf volle Leuchtkraft heben
    return "#" + best.map((v) => Math.min(255, Math.round(v * lift + 20)).toString(16).padStart(2, "0")).join("");
  }

  function applySettings(s) {
    s = s || {};
    state.lang = params.get("lang") || s.Language || state.lang;
    state.accent = params.get("accent") || s.Accent || state.accent;
    state.tele = params.has("tele") ? params.get("tele") !== "0" : s.Telemetry !== false;
    state.coords = s.Coordinates || state.coords;
    state.effect = s.ScanEffect !== false;
    state.seconds = Number(params.get("seconds")) || Number(s.PhotoSeconds) || state.seconds;
    root.lang = state.lang;
    root.classList.toggle("notele", !state.tele);
    if (state.accent !== "photo") setAccent(ACCENTS[state.accent] || ACCENTS.cyan);
    else if (current) setAccent(photoAccent(current.scan.palette));
    for (const node of document.querySelectorAll("[data-t]")) node.textContent = tx(node.dataset.t);
    measure();
  }

  async function poll() {
    try {
      const data = await fetchJson("api/scene");
      if (data && data.success) {
        applySettings(data.settings);
        state.busy = !!data.busy;
        state.photos = data.photos || 0;
        state.loaded = true;
        remember({ settings: data.settings });
      }
    } catch (_) { /* nächster Versuch */ }
    setTimeout(poll, state.loaded ? 30000 : 5000);
  }

  function loadImage(url) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.decoding = "async";
      img.alt = "";
      const timer = setTimeout(() => reject(new Error("timeout")), 30000);
      img.onload = () => {
        clearTimeout(timer);
        const done = () => resolve(img);
        if (img.decode) img.decode().then(done, done);
        else done();
      };
      img.onerror = () => { clearTimeout(timer); reject(new Error("image")); };
      img.src = url;
    });
  }

  function photoBox() {
    const box = $("photo").getBoundingClientRect();
    return { w: Math.max(200, box.width), h: Math.max(200, box.height) };
  }

  async function nextItem() {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const box = photoBox();
    const data = await fetchJson(`api/next?w=${Math.round(box.w * dpr)}&h=${Math.round(box.h * dpr)}`, 45000);
    if (!data || !data.success) return { empty: true, busy: data && data.busy };
    const img = await loadImage(`${pluginBases[baseIndex]}api/photo?id=${encodeURIComponent(data.id)}`);
    return { ...data, img };
  }

  // ------------------------------------------------------------ Maße

  function measure() {
    const w = window.innerWidth, h = window.innerHeight;
    const portrait = h > w * 1.05;
    root.classList.toggle("portrait", portrait);
    U = portrait ? Math.min(w / 1080, h / 1920) * 1.15 : Math.min(w / 1920, h / 1080);
    root.style.setProperty("--u", `${U}px`);
    sizeCanvases();
    if (current) placePhoto(current.img);
  }

  function placePhoto(img) {
    if (!img) return;
    const box = photoBox();
    const ratio = (img.naturalWidth || 4) / (img.naturalHeight || 3);
    let w = box.w, h = box.w / ratio;
    if (h > box.h - 40 * U) { h = box.h - 40 * U; w = h * ratio; }
    const left = (box.w - w) / 2, top = (box.h - 40 * U - h) / 2;
    Object.assign(img.style, { left: `${left}px`, top: `${top}px`, width: `${w}px`, height: `${h}px` });
    Object.assign($("frame").style, { left: `${left}px`, top: `${top}px`, width: `${w}px`, height: `${h}px` });
  }

  const canvases = {};
  function sizeCanvases() {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    for (const id of ["globe", "histo", "cpuSpark", "memSpark", "netSpark"]) {
      const c = $(id);
      const r = c.getBoundingClientRect();
      const w = Math.max(10, Math.round(r.width * dpr)), h = Math.max(10, Math.round(r.height * dpr));
      if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
      canvases[id] = { c, ctx: c.getContext("2d"), w, h, dpr };
    }
    drawGlobe();
    if (current) drawHistogram(current.scan.image.histogram);
    if (lastTele) drawTelemetry(lastTele);
  }

  // ------------------------------------------------------------ Formatierung

  function fmtBytes(n) {
    n = Number(n) || 0;
    const units = ["B", "KB", "MB", "GB", "TB"];
    let i = 0;
    while (n >= 1000 && i < units.length - 1) { n /= 1000; i++; }
    return `${num(n, n < 10 && i ? 1 : 0)} ${units[i]}`;
  }

  function fmtRate(n) { return `${fmtBytes(n)}/s`; }

  function fmtShutter(t) {
    if (!t) return "";
    if (t >= 1) return `${num(t, t < 10 && t % 1 ? 1 : 0)} s`;
    return `1/${Math.round(1 / t)} s`;
  }

  function dms(value, pos, neg) {
    const hemi = value >= 0 ? pos : neg;
    const a = Math.abs(value);
    const d = Math.floor(a), mf = (a - d) * 60, m = Math.floor(mf), s = (mf - m) * 60;
    return `${d}°${String(m).padStart(2, "0")}′${s.toFixed(1).padStart(4, "0")}″${hemi}`;
  }

  function compass(deg) {
    const names = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
    return `${deg}° ${names[Math.round(deg / 45) % 8]}`;
  }

  function parseTaken(text) {
    const m = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}):?(\d{2})?)?/.exec(text || "");
    if (!m) return null;
    return { date: new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 12), +(m[5] || 0), +(m[6] || 0)), hasTime: !!m[4] };
  }

  function age(date) {
    const nowD = new Date();
    let months = (nowD.getFullYear() - date.getFullYear()) * 12 + nowD.getMonth() - date.getMonth();
    if (nowD.getDate() < date.getDate()) months--;
    months = Math.max(0, months);
    const days = Math.max(0, Math.floor((nowD - date) / 86400000));
    return TEXT[state.lang]?.ago ? TEXT[state.lang].ago(Math.floor(months / 12), months % 12, months ? days % 30 : days)
      : TEXT.en.ago(Math.floor(months / 12), months % 12, days);
  }

  // ------------------------------------------------------------ Panels

  let delay = 0;
  function rows(list, id) {
    const node = $(id);
    node.innerHTML = list.filter(Boolean).map(([label, value, cls]) => {
      const d = (delay += 0.09);
      return `<dt class="type" style="--d:${d.toFixed(2)}s">${esc(label)}</dt><dd class="type ${cls || ""}" style="--d:${(d + 0.05).toFixed(2)}s">${value}</dd>`;
    }).join("");
    return list.filter(Boolean).length;
  }

  function noSignal(id, key) {
    const d = (delay += 0.09);
    $(id).innerHTML = `<dt class="type nosignal" style="--d:${d.toFixed(2)}s;grid-column:1/3">// ${esc(tx(key))}</dt>`;
  }

  function fillPanels(item) {
    const scan = item.scan, m = scan.meta || {}, im = scan.image || {};
    delay = 0.2;
    const sid = scan.id.toUpperCase().match(/.{4}/g).join("-");
    decode($("scanId"), sid);

    // Bild
    const preview = !m.mp && item.w;
    rows([
      m.w ? [tx("res"), `${num(m.w)} × ${num(m.h)} <small>px</small>`, "big"] : [tx("res"), `${num(item.w)} × ${num(item.h)} <small>${esc(tx("preview"))}</small>`],
      m.mp ? [tx("mp"), `${num(m.mp, 1)} MP <small>${esc(m.aspect || "")}</small>`] : null,
      (m.format || m.bytes) ? [tx("format"), `${esc(m.format || "")}${m.bytes ? ` <small>${fmtBytes(m.bytes)}</small>` : ""}`] : null,
    ], "imgList");
    $("imgState").textContent = preview ? tx("preview") : (m.source || "").toUpperCase();

    // Aufnahme
    const taken = parseTaken(m.taken);
    if (taken) {
      const loc = LOCALES[state.lang];
      rows([
        [tx("date"), esc(taken.date.toLocaleDateString(loc, { day: "2-digit", month: "short", year: "numeric" })), "big"],
        [tx("day"), esc(taken.date.toLocaleDateString(loc, { weekday: "long" }))],
        taken.hasTime ? [tx("time"), `${esc(taken.date.toLocaleTimeString(loc, { hour: "2-digit", minute: "2-digit", second: "2-digit" }))}${m.offset ? ` <small>UTC${esc(m.offset)}</small>` : ""}`] : null,
        [tx("age"), esc(age(taken.date))],
      ], "capList");
    } else noSignal("capList", "noDate");

    // Optik
    const optics = [
      m.camera ? [tx("camera"), esc(m.camera), "big"] : null,
      m.lens ? [tx("lens"), esc(m.lens)] : null,
      m.focal ? [tx("focal"), `${num(m.focal, m.focal % 1 ? 1 : 0)} mm${m.focal35 && Math.abs(m.focal35 - m.focal) > 1 ? ` <small>≙ ${m.focal35} mm</small>` : ""}`] : null,
      (m.fnumber || m.exposure) ? [`${tx("aperture")} / ${tx("shutter")}`,
        `${m.fnumber ? `ƒ/${num(m.fnumber, m.fnumber % 1 ? 1 : 0)}` : "—"}  ${m.exposure ? fmtShutter(m.exposure) : ""}`] : null,
      (m.iso || m.ev != null) ? [`${tx("iso")} / ${tx("ev")}`, `${m.iso ? num(m.iso) : "—"}${m.ev != null ? ` <small>${tx("ev")} ${num(m.ev, 1)}${m.bias ? ` · ${m.bias > 0 ? "+" : ""}${num(m.bias, 1)}` : ""}</small>` : ""}`] : null,
      m.flash != null ? [tx("flash"), esc(m.flash ? tx("flashOn") : tx("flashOff"))] : null,
    ];
    if (optics.some(Boolean)) {
      rows(optics, "optList");
      $("optState").textContent = m.program ? m.program.toUpperCase() : "";
    } else {
      noSignal("optList", "noExif");
      $("optState").textContent = "";
    }

    // Analyse
    const bars = [
      ["brightness", im.brightness], ["contrast", im.contrast], ["saturation", im.saturation],
      ["colourful", im.colourfulness], ["sharpness", im.sharpness], ["detail", im.detail],
    ];
    $("bars").innerHTML = bars.map(([k, v], i) => `<div class="bar type" style="--d:${(delay + 0.06 * i).toFixed(2)}s"><div class="row"><span>${esc(tx(k))}</span><b>${num(v || 0)}</b></div><div class="track"><div class="fill" data-w="${Math.max(0, Math.min(100, v || 0))}"></div></div></div>`).join("");
    delay += 0.3;
    const key = im.brightness < 32 ? "lowKey" : im.brightness > 68 ? "highKey" : "balanced";
    rows([
      [tx("key"), `${esc(tx(key))} <small>${tx("entropy")} ${num(im.entropy || 0, 2)} bit</small>`],
      [tx("clip"), `▲ ${num(im.highlights || 0, 1)} %  ▼ ${num(im.shadows || 0, 1)} %`],
    ], "anaList");

    // Archiv
    const stars = m.rating ? "★".repeat(m.rating) + "☆".repeat(5 - m.rating) : "";
    const archive = [
      stars ? [tx("rating"), `<span style="color:var(--acc);letter-spacing:.2em">${stars}</span>${m.favorite ? ` <small>${esc(tx("favorite"))}</small>` : ""}`] : null,
      m.people && m.people.length ? [tx("people"), esc(m.people.join(", ")), "wrap"] : (m.faces ? [tx("faces"), num(m.faces)] : null),
      m.tags && m.tags.length ? [tx("tags"), esc(m.tags.map((t) => "#" + t).join(" ")), "wrap"] : null,
      m.title ? [tx("title"), esc(m.title)] : null,
      m.file ? [tx("file"), esc(m.file), "dim"] : null,
      [tx("source"), `${esc((m.source || "").toUpperCase())} <small>${num(scan.ms || 0)} ms</small>`, "dim"],
    ];
    rows(archive, "arcList");

    // Geo
    const hasGps = m.lat != null && m.lon != null;
    if (hasGps) {
      rows([
        [tx("lat"), `${dms(m.lat, "N", "S")} <small>${m.lat.toFixed(state.coords === "rounded" ? 2 : 5)}</small>`],
        [tx("lon"), `${dms(m.lon, "E", "W")} <small>${m.lon.toFixed(state.coords === "rounded" ? 2 : 5)}</small>`],
        m.alt != null ? [tx("alt"), `${num(m.alt)} m${m.heading != null ? ` <small>${esc(tx("heading"))} ${compass(m.heading)}</small>` : ""}`] : null,
        m.place ? [tx("place"), esc(m.place), "big"] : null,
      ], "geoList");
      $("geoLock").textContent = tx("gpsLock");
      $("geoLock").className = "lock";
      $("geoState").textContent = "";
      $("pGeo").classList.remove("off");
      globeTarget(m.lat, m.lon);
    } else {
      if (m.place) rows([[tx("place"), esc(m.place), "big"]], "geoList");
      else noSignal("geoList", state.coords === "hidden" ? "hidden" : "noGps");
      $("geoLock").textContent = state.coords === "hidden" ? tx("hidden") : tx("noGps");
      $("geoLock").className = "lock bad";
      $("pGeo").classList.add("off");
      globeTarget(null, null);
    }

    // Spektrum
    const pal = (scan.palette || []).slice(0, 6);
    const total = pal.reduce((a, c) => a + (c.share || 0), 0) || 1;
    $("paletteBar").innerHTML = pal.map((c) => `<i style="background:#${c.hex}" data-g="${((c.share || 0) / total * 100).toFixed(1)}"></i>`).join("");
    $("chips").innerHTML = pal.map((c, i) => `<span class="chip type" style="--d:${(delay + 0.07 * i).toFixed(2)}s"><i style="background:#${c.hex}"></i>#${c.hex.toUpperCase()} <small>${num((c.share || 0) / total * 100)}%</small></span>`).join("");
    $("kelvin").textContent = im.kelvin ? `≈ ${num(im.kelvin)} K` : "";
    drawHistogram(im.histogram);

    // Maße unter dem Foto
    $("dims").textContent = m.w ? `${num(m.w)} × ${num(m.h)}${m.aspect ? " · " + m.aspect : ""}` : "";
  }

  // Zeichen "entschlüsseln", bis der echte Text dasteht
  function decode(node, text) {
    const chars = "0123456789ABCDEF#%/<>";
    const start = performance.now();
    const step = (t) => {
      const p = Math.min(1, (t - start) / 1400);
      const n = Math.floor(p * text.length);
      node.textContent = text.slice(0, n) + Array.from(text.slice(n), (c) => c === "-" ? "-" : chars[Math.floor(Math.random() * chars.length)]).join("");
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  // ------------------------------------------------------------ Histogramm

  function drawHistogram(h) {
    const cv = canvases.histo;
    if (!cv || !h) return;
    const { ctx, w, hgt = cv.h } = { ctx: cv.ctx, w: cv.w, hgt: cv.h };
    ctx.clearRect(0, 0, w, hgt);
    ctx.strokeStyle = "rgba(255,255,255,.08)";
    ctx.lineWidth = 1;
    for (let i = 1; i < 4; i++) { ctx.beginPath(); ctx.moveTo((w * i) / 4, 0); ctx.lineTo((w * i) / 4, hgt); ctx.stroke(); }
    ctx.globalCompositeOperation = "lighter";
    const series = [["r", "rgba(255,70,70,.55)"], ["g", "rgba(60,255,110,.5)"], ["b", "rgba(70,120,255,.6)"]];
    for (const [k, colour] of series) {
      const v = h[k] || [];
      ctx.fillStyle = colour;
      ctx.beginPath();
      ctx.moveTo(0, hgt);
      v.forEach((y, i) => ctx.lineTo((i / (v.length - 1)) * w, hgt - y * hgt * 0.95));
      ctx.lineTo(w, hgt);
      ctx.closePath();
      ctx.fill();
    }
    ctx.globalCompositeOperation = "source-over";
    const l = h.l || [];
    ctx.strokeStyle = getComputedStyle(root).getPropertyValue("--acc").trim() || "#38e8ff";
    ctx.lineWidth = 1.5 * cv.dpr;
    ctx.beginPath();
    l.forEach((y, i) => { const x = (i / (l.length - 1)) * w; const yy = hgt - y * hgt * 0.95; if (i) ctx.lineTo(x, yy); else ctx.moveTo(x, yy); });
    ctx.stroke();
  }

  // ------------------------------------------------------------ Globus

  const globe = { lon: 10, lat: 25, toLon: 10, toLat: 25, target: null, spin: true, last: 0, raf: 0 };

  function globeTarget(lat, lon) {
    if (lat == null) {
      globe.target = null;
      globe.spin = true;
      globe.toLat = 20;
    } else {
      globe.target = [lat, lon];
      globe.spin = false;
      // kürzester Weg um die Erde
      let d = lon - globe.lon;
      d = ((d + 540) % 360) - 180;
      globe.toLon = globe.lon + d;
      globe.toLat = Math.max(-60, Math.min(60, lat));
    }
    if (!globe.raf) globe.raf = requestAnimationFrame(globeTick);
  }

  function globeTick(t) {
    globe.raf = 0;
    const dt = globe.last ? Math.min(0.2, (t - globe.last) / 1000) : 0.016;
    if (t - globe.last < 66 && globe.last) { globe.raf = requestAnimationFrame(globeTick); return; }   // ~15 fps
    globe.last = t;
    if (globe.spin) {
      globe.lon += dt * 6;
      globe.lat += (globe.toLat - globe.lat) * Math.min(1, dt * 1.5);
    } else {
      const k = Math.min(1, dt * 2.2);
      globe.lon += (globe.toLon - globe.lon) * k;
      globe.lat += (globe.toLat - globe.lat) * k;
    }
    drawGlobe(t);
    globe.raf = requestAnimationFrame(globeTick);
  }

  function project(lat, lon, cx, cy, r) {
    const toRad = Math.PI / 180;
    const phi = lat * toRad, lam = (lon - globe.lon) * toRad, phi0 = globe.lat * toRad;
    const cosc = Math.sin(phi0) * Math.sin(phi) + Math.cos(phi0) * Math.cos(phi) * Math.cos(lam);
    const x = r * Math.cos(phi) * Math.sin(lam);
    const y = r * (Math.cos(phi0) * Math.sin(phi) - Math.sin(phi0) * Math.cos(phi) * Math.cos(lam));
    return [cx + x, cy - y, cosc >= 0];
  }

  function drawGlobe(t = performance.now()) {
    const cv = canvases.globe;
    if (!cv) return;
    const { ctx, w, h, dpr } = cv;
    const acc = getComputedStyle(root).getPropertyValue("--acc-rgb").trim() || "56, 232, 255";
    ctx.clearRect(0, 0, w, h);
    const r = Math.min(w * 0.42, h * 0.46), cx = w * 0.42, cy = h / 2;
    // Atmosphäre
    const glow = ctx.createRadialGradient(cx, cy, r * 0.7, cx, cy, r * 1.15);
    glow.addColorStop(0, `rgba(${acc}, .10)`);
    glow.addColorStop(1, `rgba(${acc}, 0)`);
    ctx.fillStyle = glow;
    ctx.beginPath(); ctx.arc(cx, cy, r * 1.15, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = `rgba(${acc}, .55)`;
    ctx.lineWidth = 1.2 * dpr;
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    // Gradnetz
    ctx.strokeStyle = `rgba(${acc}, .13)`;
    ctx.lineWidth = 1 * dpr;
    for (let lat = -60; lat <= 60; lat += 30) line(Array.from({ length: 73 }, (_, i) => [lat, -180 + i * 5]), ctx, cx, cy, r);
    for (let lon = -180; lon < 180; lon += 30) line(Array.from({ length: 37 }, (_, i) => [-90 + i * 5, lon]), ctx, cx, cy, r);
    // Land
    ctx.strokeStyle = `rgba(${acc}, .75)`;
    ctx.fillStyle = `rgba(${acc}, .10)`;
    ctx.lineWidth = 1 * dpr;
    for (const ring of window.PS_LAND || []) line(ring.map(([lo, la]) => [la, lo]), ctx, cx, cy, r);
    // Ziel
    if (globe.target) {
      const [x, y, front] = project(globe.target[0], globe.target[1], cx, cy, r);
      if (front) {
        const pulse = (t / 1400) % 1;
        ctx.strokeStyle = `rgba(${acc}, ${1 - pulse})`;
        ctx.lineWidth = 2 * dpr;
        ctx.beginPath(); ctx.arc(x, y, (4 + pulse * 22) * dpr, 0, Math.PI * 2); ctx.stroke();
        ctx.fillStyle = "#fff";
        ctx.beginPath(); ctx.arc(x, y, 3.2 * dpr, 0, Math.PI * 2); ctx.fill();
        // Linie zur Beschriftung rechts
        ctx.strokeStyle = `rgba(${acc}, .8)`;
        ctx.lineWidth = 1 * dpr;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(cx + r * 1.08, y); ctx.lineTo(w - 4 * dpr, y); ctx.stroke();
        ctx.fillStyle = `rgba(${acc}, 1)`;
        ctx.font = `${12 * U * dpr}px JBMono, monospace`;
        ctx.textAlign = "right";
        ctx.fillText(`${globe.target[0].toFixed(2)}, ${globe.target[1].toFixed(2)}`, w - 4 * dpr, y - 6 * dpr);
      }
    }
  }

  function line(points, ctx, cx, cy, r) {
    ctx.beginPath();
    let open = false;
    for (const [lat, lon] of points) {
      const [x, y, front] = project(lat, lon, cx, cy, r);
      if (!front) { open = false; continue; }
      if (open) ctx.lineTo(x, y); else { ctx.moveTo(x, y); open = true; }
    }
    ctx.stroke();
  }

  // ------------------------------------------------------------ Telemetrie

  let lastTele = null;

  function spark(cv, series, max, colours, mirror = false) {
    if (!cv) return;
    const { ctx, w, h, dpr } = cv;
    ctx.clearRect(0, 0, w, h);
    const n = 90;
    ctx.strokeStyle = "rgba(255,255,255,.07)";
    ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(0, mirror ? h / 2 : h - 0.5); ctx.lineTo(w, mirror ? h / 2 : h - 0.5); ctx.stroke();
    series.forEach((values, si) => {
      if (!values || !values.length) return;
      const sign = mirror && si === 1 ? 1 : -1;
      const base = mirror ? h / 2 : h;
      const span = mirror ? h / 2 - 2 * dpr : h - 3 * dpr;
      const x0 = w - ((values.length - 1) / (n - 1)) * w;
      ctx.beginPath();
      ctx.moveTo(x0, base);
      values.forEach((v, i) => ctx.lineTo(x0 + (i / (n - 1)) * w, base + sign * Math.min(1, v / (max || 1)) * span));
      ctx.lineTo(x0 + ((values.length - 1) / (n - 1)) * w, base);
      ctx.closePath();
      ctx.fillStyle = colours[si].replace("A", ".18");
      ctx.fill();
      ctx.beginPath();
      values.forEach((v, i) => {
        const x = x0 + (i / (n - 1)) * w, y = base + sign * Math.min(1, v / (max || 1)) * span;
        if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y);
      });
      ctx.strokeStyle = colours[si].replace("A", "1");
      ctx.lineWidth = 1.5 * dpr;
      ctx.stroke();
    });
  }

  function niceMax(v) {
    const steps = [64e3, 256e3, 1e6, 4e6, 16e6, 64e6, 256e6, 1e9];
    return steps.find((s) => s >= v) || v;
  }

  function fmtUptime(sec) {
    const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60);
    return d ? `${d}d ${h}h` : `${h}h ${String(m).padStart(2, "0")}m`;
  }

  function drawTelemetry(data) {
    const s = data.system || {}, lib = data.library || {};
    const acc = getComputedStyle(root).getPropertyValue("--acc-rgb").trim() || "56, 232, 255";
    const accA = `rgba(${acc}, A)`;
    const cpu = s.cpu || [];
    const cpuNow = cpu.length ? cpu[cpu.length - 1] : null;
    $("cpuVal").textContent = cpuNow == null ? "--" : `${num(cpuNow)} %`;
    $("cpuSub").textContent = `${s.cores || "?"} ${tx("cores")} · ${tx("load")} ${(s.load || []).map((v) => num(v, 2)).join(" ")}`;
    spark(canvases.cpuSpark, [cpu], 100, [accA]);
    $("tCpu").classList.toggle("hot", cpuNow > 85);

    const mem = s.mem || {};
    const memPct = mem.total ? (100 * mem.used) / mem.total : 0;
    $("memVal").textContent = mem.total ? `${num(memPct)} %` : "--";
    $("memSub").textContent = mem.total ? `${fmtBytes(mem.used)} / ${fmtBytes(mem.total)}` : "";
    spark(canvases.memSpark, [s.memHistory || []], 100, [accA]);

    const rx = s.rx || [], tx2 = s.tx || [];
    const rxNow = rx.length ? rx[rx.length - 1] : 0, txNow = tx2.length ? tx2[tx2.length - 1] : 0;
    const peak = Math.max(1, ...rx, ...tx2);
    $("netVal").textContent = `↓ ${fmtRate(rxNow)}  ↑ ${fmtRate(txNow)}`;
    $("netSub").textContent = `${tx("peak")} ${fmtRate(peak)} · ${s.ip || ""}`;
    spark(canvases.netSpark, [rx, tx2], niceMax(peak), [accA, "rgba(255, 176, 0, A)"], true);

    const temp = s.temp;
    $("tempVal").textContent = temp ? `${num(temp, 1)} °C` : "--";
    $("tempBar").style.width = `${temp ? Math.min(100, Math.max(0, ((temp - 25) / 60) * 100)) : 0}%`;
    $("tempBar").style.backgroundColor = temp > 75 ? "var(--bad)" : temp > 65 ? "var(--warn)" : "";
    $("tTemp").classList.toggle("hot", temp > 70);
    $("tempSub").textContent = `${tx("up")} ${fmtUptime(s.uptime || 0)}`;

    const disk = s.disk;
    if (disk && disk.total) {
      const pct = (100 * disk.used) / disk.total;
      $("diskVal").textContent = `${num(pct)} %`;
      $("diskBar").style.width = `${pct}%`;
      $("diskSub").textContent = `${fmtBytes(disk.total - disk.used)} ${tx("free")}`;
    }

    if (lib.photos) {
      $("libVal").textContent = `${num(lib.photos)} ${tx("photos")}`;
      const parts = [
        lib.videos ? `${num(lib.videos)} ${tx("videos")}` : "",
        lib.bytes ? fmtBytes(lib.bytes) : "",
        lib.located ? `${num(lib.located)} ${tx("located")}` : "",
        lib.cameras ? `${num(lib.cameras)} ${tx("cameras")}` : "",
        lib.first && lib.last ? `${lib.first}–${lib.last}` : "",
      ].filter(Boolean);
      $("libSub").textContent = parts.join(" · ");
    }
    $("hostSub").textContent = s.host ? `${s.host}` : "";
  }

  async function telemetryLoop() {
    for (;;) {
      if (state.tele) {
        try {
          const data = await fetchJson("api/telemetry", 8000);
          if (data && data.success) {
            lastTele = data;
            drawTelemetry(data);
          }
        } catch (_) { /* nächster Versuch */ }
      }
      await sleep(state.tele ? 2000 : 10000);
    }
  }

  // ------------------------------------------------------------ Uhr

  function tickClock() {
    $("clock").textContent = new Date().toLocaleTimeString(LOCALES[state.lang], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  }
  setInterval(tickClock, 1000);

  // ------------------------------------------------------------ Ablauf

  function setPhase(key, blink) {
    $("phase").textContent = tx(key);
    $("phase").className = blink ? "blink" : "";
  }

  async function show(item) {
    const app = $("app");
    const frame = $("frame");
    const reticle = $("reticle");
    if (current) {
      app.classList.add("fadeout");
      reticle.classList.remove("on");
      await sleep(450);
    }
    app.classList.remove("fadeout", "shown");
    const layers = $("layers");
    const img = item.img;
    layers.append(img);
    placePhoto(img);
    const old = current;
    current = item;
    if (state.accent === "photo") setAccent(photoAccent(item.scan.palette));
    void img.offsetWidth;
    img.classList.add("on");
    if (old) setTimeout(() => old.img.remove(), 1300);
    app.classList.remove("booting");
    hideNote();
    ready();

    fillPanels(item);
    setPhase("phaseScan", true);
    frame.classList.remove("scanning");
    void frame.offsetWidth;
    if (state.effect) frame.classList.add("scanning");
    // Farbe kommt mit der Scanlinie
    setTimeout(() => img.classList.add("clear"), state.effect ? 900 : 50);
    await sleep(state.effect ? 500 : 100);
    app.classList.add("shown");
    for (const fill of document.querySelectorAll(".fill")) fill.style.width = "0";
    for (const seg of $("paletteBar").children) seg.style.flexGrow = "0";
    setTimeout(() => {
      for (const fill of document.querySelectorAll(".fill")) fill.style.width = `${fill.dataset.w}%`;
      for (const seg of $("paletteBar").children) seg.style.flexGrow = seg.dataset.g;
    }, 600);

    // Fadenkreuz rastet ein
    await sleep(state.effect ? 1900 : 300);
    const focus = item.scan.image.focus || [0.5, 0.5];
    reticle.style.left = `${focus[0] * 100}%`;
    reticle.style.top = `${focus[1] * 100}%`;
    reticle.classList.toggle("flip", focus[0] > 0.62);
    $("reticleText").textContent = `${tx("focusLock")} ${Math.round(focus[0] * 100)}·${Math.round(focus[1] * 100)}`;
    reticle.classList.add("on");
    await sleep(900);
    frame.classList.remove("scanning");
    setPhase("phaseLock", false);
  }

  const note = $("note");
  function showNote(kind) {
    note.textContent = tx(kind);
    note.classList.add("on");
    setPhase("phaseWait", true);
    ready();
  }
  function hideNote() { note.classList.remove("on"); }

  async function fetchNext() {
    try {
      return await nextItem();
    } catch (error) {
      return { failed: true, error };
    }
  }

  async function run() {
    let failures = 0;
    let next = await fetchNext();
    for (;;) {
      if (next.img) {
        failures = 0;
        const shownAt = Date.now();
        await show(next);
        const pending = fetchNext();
        await sleep(Math.max(0, Math.max(8, state.seconds) * 1000 - (Date.now() - shownAt)));
        next = await pending;
        if (!next.img) await sleep(Math.max(0, 4000 - (Date.now() - shownAt)));
        continue;
      }
      failures++;
      if (next.empty) showNote(next.busy || state.busy ? "busy" : "empty");
      else if (failures >= 2) {
        showNote("offline");
        if (failures === 3) report(`kein Foto (${next.error && next.error.message})`);
      }
      await sleep(next.empty ? 8000 : Math.min(15000, 3000 * failures));
      next = await fetchNext();
    }
  }

  // ------------------------------------------------------------ Start

  window.addEventListener("resize", measure);
  const remembered = recall();
  applySettings(remembered && remembered.settings || {});
  $("mode").textContent = "v0.1";
  tickClock();
  setPhase("phaseWait", true);
  setTimeout(() => $("app").classList.remove("booting"), 300);
  globeTarget(null, null);
  poll();
  telemetryLoop();
  run();
})();
