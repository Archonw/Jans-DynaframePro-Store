# Dynaframe's Magic Mirror

Dynaframe's Magic Mirror macht aus dem DynaFrame einen „Magic Mirror“: eine Szene mit Regionen, in die du Module setzt, ganz wie bei [MagicMirror²](https://github.com/MagicMirrorOrg/MagicMirror). Alles wird auf der Plugin-Seite eingestellt, ohne Konfigurationsdatei.

**Regionen:** oben über die ganze Breite, oben links/Mitte/rechts, links, Mitte, rechts, unten links/Mitte/rechts, unten über die ganze Breite. Leere Regionen nehmen keinen Platz weg; das Layout passt sich an Quer- und Hochformat an.

**Hintergrund:** Schwarz wie ein Spiegel, Nachtblau, eine eigene Farbe oder ein Bild (per Link oder vom Gerät hochgeladen). Auf einem Bild wird abgedunkelt und die Schrift bekommt einen Schatten, auf hellen Farben wird die Schrift dunkel.

**Skins:** Statt der Module in Regionen kann die ganze Szene ein anderes Aussehen bekommen: **Retro-LCD** (leuchtendes Display mit LCD-Ziffern, in vier Farben) oder **Farbraster** (bunte Felder wie ein Mondrian-Bild). Jeder Skin hat Felder mit einer Vorgabe (Uhr, Datum, Wetter, Sonnenzeiten, Countdown, Wetter als Pixelbild …); auf der Plugin-Seite wählst du für jedes Feld etwas anderes vom Skin oder eines deiner Module, z. B. Nachrichten, Termine, Abfahrten oder Home-Assistant-Werte. Weitere Skins installierst du wie Module, z. B. den **Bordcomputer** (schwarzer Schirm mit runden Balken wie in Raumschiff-Serien der 90er, mit Sternzeit). Eigene Skins und passende Module baut man wie Module, siehe [MODULES.md](https://github.com/Archonw/Jans-DynaframePro-Store/blob/main/plugin_packs/magic-frame/MODULES.md#skins).

**Eingebaute Module** (jedes darf mehrmals vorkommen):

- **Uhr** mit Datum, Sekunden und Kalenderwoche nach Wunsch
- **Wetter jetzt**, **Wettervorhersage** (bis 7 Tage) und **Regen in den nächsten 3 Stunden** (Open-Meteo, weltweit, ohne Schlüssel)
- **Termine** aus Nextcloud, Google oder jedem ICS-Link
- **Nachrichten** aus einem oder mehreren RSS-Feeds (nacheinander, jeweils mit der Quelle davor): eine Schlagzeile nach der anderen, als Laufband oder als Liste
- **Abfahrten** an einer Haltestelle mit Echtzeit (Transitous)
- **Sprüche** je nach Tageszeit, auch eigene
- **Unwetterwarnungen** des DWD (nur Deutschland, unsichtbar ohne Warnung)
- **Webseite** in einem Rahmen

**Weitere Module** installierst du direkt auf der Plugin-Seite aus dem Modul-Katalog, per ZIP-Link, als heruntergeladene ZIP-Datei („ZIP-Datei installieren“) oder über den Store (Einträge „Magic Mirror module: …“). Sie tauchen nicht als eigene Plugins in der Plugins-Übersicht auf. Im Katalog sind bisher: Home Assistant (Werte, Haus-Status, Raumklima, Anwesenheit, Müllabfuhr; bis 0.6.x eingebaut, ab 0.7.0 ein Zusatzmodul, die Einstellungen bleiben erhalten), Pegelstand, WLAN für Gäste (QR-Code), WebUntis Stundenplan, Music Assistant und Jellyfin. Wie man eines baut, steht in [MODULES.md](MODULES.md).

## Eigene Module und Module von MagicMirror²

Module von MagicMirror² laufen nicht direkt, lassen sich aber umbauen. Die Anleitung [MODULES.md](https://github.com/Archonw/Jans-DynaframePro-Store/blob/main/plugin_packs/magic-frame/MODULES.md) enthält alles dafür, auch eine Tabelle, welcher Teil eines MagicMirror-Moduls wohin gehört. Du kannst sie zusammen mit dem Link zu einem MagicMirror-Modul einer KI geben und sie das Modul umbauen lassen. Fertige Beispiele liegen in [module-sources](https://github.com/Archonw/Jans-DynaframePro-Store/tree/main/plugin_packs/magic-frame/module-sources).

## Einrichten

1. Paket aus dem Store installieren, dann auf der Plugins-Seite **Open Dynaframe's Magic Mirror**.
2. Oben den **Ort** suchen (für Wetter, Regen, Warnungen und Haltestellen in der Nähe).
3. Module hinzufügen, einstellen und in der Vorschau in die gewünschte Region ziehen.
4. Auf der Plugin-Seite unter **Playlists** eine Playlist anlegen und auf der Startseite starten. **„Dynaframe's Magic Mirror“** zeigt immer die Einstellung, die gerade auf der Plugin-Seite steht. Mit **Speichern** hältst du die jetzige Einstellung (Module, Skin, Felder, Hintergrund) als eigene Playlist fest, z. B. „Dynaframe's Magic Mirror: Küche“; sie bleibt so, auch wenn du die Seite später änderst. Mit **Bearbeiten** öffnest du eine gespeicherte Playlist wieder auf der Plugin-Seite und änderst nur sie; **Fertig** führt zurück zur allgemeinen Einstellung. Für einen Spiegel, der immer dasselbe zeigt, läuft eine Playlist allein; sonst kommt die Szene wie ein Bild zwischen die anderen.
5. Oder **über die Playlist legen**: Auf der Plugin-Seite einstellen, ob der Magic Mirror regelmäßig (alle N Minuten für N Sekunden) oder durchgehend in einem Zeitfenster (Tage, von/bis) über die laufende Playlist kommt und danach den Bildschirm zurückgibt. Dafür auf der Plugins-Seite **Allow takeover** einschalten. Ein ausgeschalteter Bildschirm wird nicht geweckt.

## Daten

Open-Meteo (CC BY 4.0), Transitous (transitous.org · © OpenStreetMap), Deutscher Wetterdienst über Bright Sky, OpenStreetMap/Nominatim. Abfahrten werden nur abgefragt, solange die Szene zu sehen ist. LCD-Schrift im Skin Retro-LCD: DSEG von keshikan (SIL Open Font License 1.1, Lizenz in `dynamic/fonts/`).

Dynaframe's Magic Mirror ist ein eigenständiger Nachbau für DynaFrame und gehört nicht zum MagicMirror²-Projekt; Module von MagicMirror laufen nicht direkt darin.
