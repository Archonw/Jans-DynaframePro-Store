# Photo Universe

Deine Fotos als Galaxie: Jedes Foto ist ein Stern, Fotos mit vielen Bewertungssternen leuchten heller. Die Sterne bilden Sternbilder nach Jahr, Ort oder Person, und die Kamera fliegt durch die Galaxie, steuert einen Stern an und öffnet das Foto.

- Quellen: alle Fotos in DynaFrame, ausgewählte Ordner oder Playlists, Immich (alle Fotos oder Alben).
- Sternbilder: nach Jahr (die Zeit läuft als Spirale nach außen), nach Ort (Stadt, bei verstreuten Orten das Land) oder nach Person (Gesichtserkennung von Immich). „Im Wechsel“ ordnet die Galaxie zwischendurch neu.
- Helligkeit: Sterne aus der Mediendatenbank von DynaFrame (EXIF/XMP, z. B. von StarSwipe) oder aus Immich.
- Filter wie bei Foto Mosaik für Fotos aus DynaFrame und aus Immich.
- Die Szene zeichnet mit WebGL (ohne WebGL eine einfachere Fassung mit weniger Sternen).

Problem melden: https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=%5BPhoto%20Universe%5D%20
