"""Woher die Fotos mit Ort kommen: Immich oder DynaFrame selbst.

Jede Quelle liefert Zeilen (lat, lon, taken, key, place):
- lat/lon in Grad, taken "YYYY-MM-DDTHH:MM:SS" oder "",
- key: womit die Szene das Foto später zeigen kann ("i:<asset-id>" bei
  Immich, "f:<pfad>" bei Dateien auf dem Rahmen),
- place: Ort als Text, wenn die Quelle ihn schon kennt.

Fotos ohne GPS werden nur gezählt.
"""

import json
import os
import re
import threading
import time
from pathlib import Path
from urllib.parse import quote, urlencode

import requests

import exif_gps
import immich_filters

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 60
PAGE_SIZE = 1000
MAX_PHOTOS = 300000


class SourceError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def short_error(exc):
    text = str(exc)
    for marker in ("Failed to establish a new connection: ", "Read timed out", "Name or service not known"):
        if marker in text:
            tail = text.split(marker, 1)[1] if marker.endswith(": ") else marker
            return tail.split("'))")[0].strip(" )") or marker
    return text[:200]


# --------------------------------------------------------------------------
# Immich
# --------------------------------------------------------------------------

def normalize_url(url):
    url = str(url or "").strip().rstrip("/")
    if url and not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    if url.lower().endswith("/api"):
        url = url[:-4]
    return url


class Immich:
    """Der Zugang zu einem Immich-Server mit API-Schlüssel (wie Immich Slideshow)."""

    def __init__(self, tr):
        self.tr = tr
        self.base = ""
        self.key = ""
        self.session = requests.Session()

    def configure(self, base, key):
        self.base, self.key = normalize_url(base), key

    def call(self, method, path, payload=None, params=None, raw=False, timeout=None):
        if not self.base:
            raise SourceError(self.tr("Trag die Adresse deines Immich-Servers ein."))
        if not self.key:
            raise SourceError(self.tr("Trag einen API-Schlüssel von Immich ein."))
        headers = {"x-api-key": self.key, "Accept": "image/*" if raw else "application/json"}
        try:
            response = self.session.request(method, f"{self.base}/api{path}", json=payload, params=params,
                                            headers=headers, timeout=(CONNECT_TIMEOUT, timeout or READ_TIMEOUT))
        except requests.RequestException as exc:
            raise SourceError(self.tr("Immich ist nicht erreichbar: {exc}", exc=short_error(exc))) from exc
        if response.status_code == 401:
            raise SourceError(self.tr("Immich lehnt den API-Schlüssel ab."), 401)
        if response.status_code == 403:
            raise SourceError(self.tr("Dem API-Schlüssel fehlt eine Berechtigung ({path}).",
                                      path=path.split("?")[0]), 403)
        if response.status_code >= 400:
            detail = ""
            try:
                body = response.json()
                detail = body.get("message") if isinstance(body, dict) else ""
                if isinstance(detail, list):
                    detail = "; ".join(str(d) for d in detail)
            except ValueError:
                pass
            raise SourceError(f"{method} {path}: HTTP {response.status_code} {detail or ''}".strip(),
                              response.status_code)
        if raw:
            return response
        if not response.content.strip():
            return None
        try:
            return response.json()
        except ValueError as exc:
            raise SourceError(self.tr("Unter dieser Adresse antwortet kein Immich-Server.")) from exc

    def test(self):
        me = self.call("GET", "/users/me") or {}
        about = {}
        try:
            about = self.call("GET", "/server/about") or {}
        except SourceError as exc:
            if exc.status in (401, 403):
                raise
        return {"user": me.get("name") or me.get("email") or "", "version": about.get("version") or ""}

    def albums(self):
        found = {}
        for query in ({}, {"shared": "true"}):
            rows = self.call("GET", "/albums", params=query) or []
            for row in rows if isinstance(rows, list) else []:
                if isinstance(row, dict) and row.get("id"):
                    found[row["id"]] = {"id": row["id"], "name": row.get("albumName") or "?",
                                        "count": row.get("assetCount") or 0}
        return sorted(found.values(), key=lambda a: a["name"].lower())

    @staticmethod
    def _place(*parts):
        return ", ".join(p for p in parts if p)[:80]

    def all_markers(self, stop, f=None):
        """Alle Fotos mit Ort. Ohne Filter in einem Rutsch über die Karte von
        Immich selbst, mit Filtern (wie Photo Mosaic) über die Suche."""
        f = f or {}
        if immich_filters.active(f):
            return self.album(None, stop, f)
        rows = self.call("GET", "/map/markers", params={"isArchived": "false"}, timeout=180) or []
        out = []
        for row in rows if isinstance(rows, list) else []:
            if stop.is_set():
                break
            lat, lon = row.get("lat"), row.get("lon")
            if isinstance(lat, (int, float)) and isinstance(lon, (int, float)) and row.get("id"):
                out.append((float(lat), float(lon), "", "i:" + row["id"],
                            self._place(row.get("city"), row.get("country"))))
        return out, len(out)

    def album(self, album_id, stop, f=None):
        """Die Fotos eines Albums (oder alle, album_id None) mit Ort, nach den
        Filtern. Ohne Ort zählen sie nur mit."""
        items = immich_filters.search(self, stop, f or {}, [album_id] if album_id else None, {"withExif": True})
        out = []
        for item in items:
            exif = item.get("exifInfo") or {}
            lat, lon = exif.get("latitude"), exif.get("longitude")
            if isinstance(lat, (int, float)) and isinstance(lon, (int, float)) and (lat or lon):
                taken = str(item.get("localDateTime") or exif.get("dateTimeOriginal")
                            or item.get("fileCreatedAt") or "")[:19]
                out.append((float(lat), float(lon), taken, "i:" + item["id"],
                            self._place(exif.get("city"), exif.get("country"))))
        return out, len(items)

    def asset_info(self, asset_id):
        row = self.call("GET", f"/assets/{asset_id}") or {}
        exif = row.get("exifInfo") or {}
        taken = str(row.get("localDateTime") or exif.get("dateTimeOriginal") or row.get("fileCreatedAt") or "")
        return {"taken": taken[:19], "place": self._place(exif.get("city"), exif.get("country"))}

    def photo(self, asset_id):
        response = self.call("GET", f"/assets/{asset_id}/thumbnail", params={"size": "preview"}, raw=True,
                             timeout=60)
        kind = response.headers.get("Content-Type", "image/jpeg").split(";")[0]
        if not kind.startswith("image/"):
            raise SourceError(f"Immich lieferte {kind} statt eines Bildes")
        return response.content, kind


# --------------------------------------------------------------------------
# DynaFrame: Playlists und die ganze Mediendatenbank
# --------------------------------------------------------------------------
#
# Die Engine-API für die Mediendatenbank ist nicht dokumentiert. Bekannt sind
# /playlists, /playlists/{id}/items, /media/database/search?query= und
# /media/database/by-directory?directories=. Das Plugin probiert deshalb
# mehrere Wege und merkt sich, welcher auf diesem Rahmen geht. Die Position
# liest es selbst aus den Dateien (die liegen auf dem Rahmen oder auf einem
# eingehängten Share); liefert die Engine schon Koordinaten mit, nimmt es die.

PATH_KEYS = ("filePath", "path", "fullPath", "localPath", "mediaPath", "sourcePath")
LAT_KEYS = ("latitude", "lat", "gpsLatitude", "exifLatitude")
LON_KEYS = ("longitude", "lon", "lng", "gpsLongitude", "exifLongitude")
PLACE_KEYS = ("locationName", "location", "placeName")
TAKEN_KEYS = ("dateTaken", "takenAt", "dateTimeOriginal", "captureDate", "exifDate", "takenDate")
SKIP_DIRS = {"@eaDir", "#recycle", ".thumbnails", "__pycache__", "node_modules", "lost+found", ".Trash-1000"}


def _rows(data):
    if isinstance(data, list):
        return [r for r in data if isinstance(r, dict)]
    if isinstance(data, dict):
        for key in ("items", "results", "media", "files", "data", "rows"):
            if isinstance(data.get(key), list):
                return [r for r in data[key] if isinstance(r, dict)]
    return []


def _find(row, keys, depth=0):
    """Den ersten Wert unter einem der Schlüssel, auch eine Ebene tiefer (z. B. row["media"]["filePath"])."""
    for key in keys:
        for name, value in row.items():
            if name.lower() == key.lower() and value not in (None, ""):
                return value
    if depth == 0:
        for value in row.values():
            if isinstance(value, dict):
                found = _find(value, keys, 1)
                if found not in (None, ""):
                    return found
    return None


def _coord(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number


class GeoCache:
    """Position je Datei, damit ein zweiter Durchlauf nur neue Dateien öffnet."""

    def __init__(self, read_json, write_json, path):
        self.read_json, self.write_json, self.path = read_json, write_json, path
        self.lock = threading.Lock()
        self.data = None
        self.dirty = 0

    def _load(self):
        if self.data is None:
            stored = self.read_json(self.path, {})
            self.data = stored if isinstance(stored, dict) else {}

    def lookup(self, path):
        """(lat, lon, taken) oder None, wenn die Datei gelesen werden muss."""
        try:
            info = os.stat(path)
        except OSError:
            return "missing"
        stamp = f"{int(info.st_mtime)}:{info.st_size}"
        with self.lock:
            self._load()
            row = self.data.get(path)
        if row and row[0] == stamp:
            return row[1], row[2], row[3]
        lat, lon, taken = exif_gps.read(path)
        if lat is not None:
            lat, lon = round(lat, 5), round(lon, 5)
        with self.lock:
            self.data[path] = [stamp, lat, lon, taken]
            self.dirty += 1
            if self.dirty >= 500:
                self.save_locked()
        return lat, lon, taken

    def taken(self, path):
        with self.lock:
            self._load()
            row = self.data.get(path)
        return row[3] if row else ""

    def save_locked(self):
        self.write_json(self.path, self.data)
        self.dirty = 0

    def save(self):
        with self.lock:
            if self.data is not None and self.dirty:
                self.save_locked()

    def forget_missing(self, keep):
        with self.lock:
            self._load()
            for path in [p for p in self.data if p not in keep]:
                del self.data[path]
                self.dirty += 1


def _media_folder_ok(path):
    """Nur echte Bilderordner durchsuchen, nie das ganze System."""
    clean = os.path.normpath(path)
    if clean in ("/", "/home", "/media", "/mnt", str(Path.home())) or not os.path.isdir(clean):
        return False
    if clean.startswith(("/opt", "/usr", "/etc", "/proc", "/sys", "/var", "/tmp", "/run", "/boot", "/dev")):
        return False
    return not any(part in clean for part in ("/.local", "/.config", "/.cache"))


def _quick_mix(row):
    """Eine Quick-Mix-Liste von DynaFrame: Typ steht als JSON in description."""
    text = row.get("description")
    if isinstance(text, str) and "quick_mix" in text.replace(" ", "").lower():
        try:
            data = json.loads(text)
        except ValueError:
            return True
        return str((data or {}).get("Type") or (data or {}).get("type") or "").lower() == "quick_mix" \
            if isinstance(data, dict) else True
    return False


class DynaFrame:
    def __init__(self, engine_call, engine_error, log, cache):
        self.engine_call = engine_call
        self.EngineError = engine_error
        self.log = log
        self.cache = cache
        self.library_way = ""        # welcher Weg zur ganzen Datenbank zuletzt ging
        self.logged_keys = set()

    def _log_keys(self, what, row):
        if what not in self.logged_keys and isinstance(row, dict):
            self.logged_keys.add(what)
            self.log(f"Engine {what}: Felder " + ", ".join(sorted(row.keys())))

    def playlists(self):
        """Die gespeicherten Playlists, wie unter "Choose Playlist"; ohne die
        Quick-Mix-Listen ("Selected Media"), die DynaFrame selbst anlegt."""
        data = self.engine_call("GET", "/playlists") or []
        rows = _rows(data) if not isinstance(data, list) else [r for r in data if isinstance(r, dict)]
        if isinstance(data, dict) and not rows:
            rows = _rows({"items": data.get("playlists") or []})
        return [{"id": r.get("id"), "name": r.get("name") or "?", "count": r.get("itemCount") or r.get("count")}
                for r in rows if r.get("id") is not None and not _quick_mix(r)]

    # ---------------------------------------------------------- einzelne Medien

    def _media_row(self, media_id):
        for path in (f"/media/{media_id}", f"/media/database/{media_id}", f"/media/files/{media_id}",
                     f"/media/database/item/{media_id}"):
            try:
                row = self.engine_call("GET", path)
            except self.EngineError:
                continue
            if isinstance(row, dict):
                row = row.get("item") or row.get("media") or row
                if _find(row, PATH_KEYS):
                    self._log_keys("Medium", row)
                    return row
        return None

    def _search_by_name(self, name, media_id):
        if not name:
            return None
        try:
            found = self.engine_call("GET", "/media/database/search?" + urlencode({"query": Path(str(name)).stem}))
        except self.EngineError:
            return None
        for row in _rows(found):
            if str(row.get("id")) == str(media_id) or str(row.get("mediaFileId")) == str(media_id):
                return row
        return None

    def _point(self, row, media_id=None):
        """(lat, lon, taken, key, place) aus einer Engine-Zeile, oder None ohne Ort."""
        path = _find(row, PATH_KEYS)
        lat, lon = _coord(_find(row, LAT_KEYS)), _coord(_find(row, LON_KEYS))
        taken = str(_find(row, TAKEN_KEYS) or "")[:19]
        place = str(_find(row, PLACE_KEYS) or "")[:80]
        # Mit der id der Engine kann die Szene das Foto auch zeigen, wenn es
        # nicht als Datei auf dem Rahmen liegt (WebDAV, Plugins): über das
        # Vorschaubild der Engine.
        if media_id is None:
            media_id = row.get("id")
        key = f"d:{media_id}|{path or ''}" if media_id is not None else (f"f:{path}" if path else "")
        if lat is not None and lon is not None and (lat or lon) and -90 <= lat <= 90 and -180 <= lon <= 180:
            return (lat, lon, taken, key, place)
        if not path:
            return None
        found = self.cache.lookup(str(path))
        if found == "missing" or found[0] is None:
            return None
        return (found[0], found[1], found[2] or taken, key, place)

    def _library_index(self, stop):
        """Die Mediendatenbank nach id und Pfad, um Playlist-Einträge aufzulösen."""
        by_id, by_path = {}, {}
        for row in self.library_rows(stop):
            if row.get("id") is not None:
                by_id[str(row["id"])] = row
            path = _find(row, PATH_KEYS)
            if path:
                by_path[str(path)] = row
        return by_id, by_path

    def playlist(self, playlist_id, stop):
        items = self.engine_call("GET", f"/playlists/{playlist_id}/items") or []
        rows = _rows(items)
        if rows:
            self._log_keys("Playlist-Eintrag", rows[0])
        index = None
        out, total, unresolved = [], 0, 0
        for item in rows:
            if stop.is_set():
                break
            # Ein Ordner in der Playlist: alle Fotos darin.
            folder = _find(item, ("directoryPath", "folderPath", "directory", "folder"))
            if isinstance(folder, str) and folder.startswith("/"):
                pts, n = self.folder_points([folder], stop)
                out += pts
                total += n
                continue
            media = item.get("media") if isinstance(item.get("media"), dict) else {}
            media_id = item.get("mediaFileId") or item.get("mediaId") or media.get("id")
            if item.get("dynamicSceneId") or (media_id is None and not _find(item, PATH_KEYS)):
                continue   # Szenen und anderes ohne Foto
            total += 1
            # Die Einträge selbst tragen meist keinen Ort; den hat die
            # Mediendatenbank (bei WebDAV nur sie).
            if index is None:
                index = self._library_index(stop)
            path = _find(item, PATH_KEYS) or _find(media, PATH_KEYS)
            row = (index[0].get(str(media_id)) if media_id is not None else None) or \
                (index[1].get(str(path)) if path else None)
            if row is None and media and _find(media, PATH_KEYS):
                row = media
            if row is None and _find(item, PATH_KEYS):
                row = item
            if row is None and media_id is not None and not index[0] and unresolved < 50:
                row = self._media_row(media_id) or self._search_by_name(
                    _find(item, ("fileName", "name", "title")), media_id)
            if row is None:
                unresolved += 1
                continue
            # Ein Playlist-Eintrag hat seine eigene id; das Foto hat mediaFileId.
            point = self._point(row, media_id if media_id is not None else row.get("id"))
            if point:
                out.append(point)
        self.log(f"Playlist {playlist_id}: {len(rows)} Einträge, {total} Fotos, {len(out)} mit Ort"
                 + (f", {unresolved} nicht in der Mediendatenbank gefunden" if unresolved else "") + ".")
        return out, total

    # ---------------------------------------------------------- ganze Datenbank

    def _page_through(self, path_for_page, stop):
        rows, seen, page = [], set(), 1
        while page <= 2000 and not stop.is_set():
            data = self.engine_call("GET", path_for_page(page))
            batch = _rows(data)
            fresh = 0
            for row in batch:
                path = _find(row, PATH_KEYS)
                if path and path not in seen:
                    seen.add(path)
                    rows.append(row)
                    fresh += 1
            if not batch or not fresh:
                break
            page += 1
        return rows

    def library_rows(self, stop):
        """Alle Medien, die die Engine kennt; [] wenn kein Weg geht."""
        ways = [
            ("database", lambda p: f"/media/database?page={p}&pageSize=500&limit=500&offset={(p - 1) * 500}"),
            ("search", lambda p: f"/media/database/search?query=&page={p}&pageSize=500&limit=500"
                                 f"&offset={(p - 1) * 500}"),
        ]
        for name, way in ways:
            try:
                rows = self._page_through(way, stop)
            except self.EngineError:
                continue
            rows = [r for r in rows if _find(r, PATH_KEYS)]
            if rows:
                if self.library_way != name:
                    self.library_way = name
                    self._log_keys("Datenbank", rows[0])
                    self.log(f"Mediendatenbank über /media/database ({name}): {len(rows)} Einträge.")
                return rows
        self.library_way = ""
        return []

    def media_folders(self):
        """Medienordner, die die Engine in ihren Einstellungen nennt."""
        found = []

        def walk(value, depth=0):
            if depth > 4:
                return
            if isinstance(value, dict):
                for name, inner in value.items():
                    if re.search(r"folder|director|librar|media|root|share", name, re.I):
                        walk(inner, depth + 1)
            elif isinstance(value, list):
                for inner in value:
                    walk(inner, depth + 1)
            elif isinstance(value, str) and value.startswith("/") and len(value) < 300:
                if _media_folder_ok(value):
                    found.append(value.rstrip("/"))

        for path in ("/settings/slideshow", "/settings/media", "/media/folders", "/media/directories"):
            try:
                walk(self.engine_call("GET", path))
            except self.EngineError:
                continue
        return list(dict.fromkeys(found))

    def folder_points(self, folders, stop, seen=None):
        out, total = [], 0
        seen = seen if seen is not None else set()
        for folder in folders:
            for root, dirs, files in os.walk(folder, followlinks=False):
                if stop.is_set():
                    return out, total
                dirs[:] = [d for d in dirs if not d.startswith(".") and d not in SKIP_DIRS]
                for name in files:
                    if Path(name).suffix.lower() not in exif_gps.EXTENSIONS or name.startswith("."):
                        continue
                    path = os.path.join(root, name)
                    if path in seen:
                        continue
                    seen.add(path)
                    total += 1
                    found = self.cache.lookup(path)
                    if found != "missing" and found[0] is not None:
                        out.append((found[0], found[1], found[2], f"f:{path}", ""))
                    if total % 200 == 0:
                        time.sleep(0.05)   # den Rahmen nicht ausbremsen
                    if total >= MAX_PHOTOS:
                        return out, total
        return out, total

    def library(self, extra_folders, stop):
        out, total, seen = [], 0, set()
        for row in self.library_rows(stop):
            if stop.is_set():
                break
            path = str(_find(row, PATH_KEYS))
            if Path(path).suffix.lower() not in exif_gps.EXTENSIONS and not _find(row, LAT_KEYS):
                continue
            seen.add(path)
            total += 1
            point = self._point(row)
            if point:
                out.append(point)
        folders = list(dict.fromkeys(list(extra_folders) + self.media_folders()))
        if not folders and not seen:
            home = Path.home() / "Pictures"
            folders = [str(home)] if home.is_dir() else []
        pts, n = self.folder_points([f for f in folders if os.path.isdir(f)], stop, seen)
        return out + pts, total + n

    @staticmethod
    def photo(path):
        kind = {".png": "image/png", ".webp": "image/webp", ".avif": "image/avif"}.get(
            Path(path).suffix.lower(), "image/jpeg")
        if Path(path).suffix.lower() not in (".jpg", ".jpeg", ".jpe", ".png", ".webp", ".avif"):
            raise SourceError("Dieses Format kann der Browser nicht zeigen")
        with open(path, "rb") as handle:
            return handle.read(40 * 1024 * 1024), kind


# --------------------------------------------------------------------------
# Ortsnamen für die Fotokarte (OpenStreetMap Nominatim, sparsam und gemerkt)
# --------------------------------------------------------------------------

class Places:
    URL = "https://nominatim.openstreetmap.org/reverse"

    def __init__(self, read_json, write_json, path, user_agent):
        self.read_json, self.write_json, self.path = read_json, write_json, path
        self.ua = user_agent
        self.lock = threading.Lock()
        self.data = None
        self.last = 0.0

    def name(self, lat, lon, lang):
        key = f"{lat:.2f},{lon:.2f},{lang}"
        with self.lock:
            if self.data is None:
                stored = self.read_json(self.path, {})
                self.data = stored if isinstance(stored, dict) else {}
            if key in self.data:
                return self.data[key]
            if time.time() - self.last < 1.5:     # Nutzungsregeln: höchstens eine Anfrage je Sekunde
                return None
            self.last = time.time()
        try:
            response = requests.get(self.URL, params={"lat": f"{lat:.4f}", "lon": f"{lon:.4f}", "format": "jsonv2",
                                                      "zoom": 10, "accept-language": lang},
                                    headers={"User-Agent": self.ua}, timeout=(5, 10))
            body = response.json() if response.status_code == 200 else {}
        except (requests.RequestException, ValueError):
            return None
        address = body.get("address") or {}
        town = next((address[k] for k in ("city", "town", "village", "municipality", "hamlet", "county",
                                          "state") if address.get(k)), "")
        place = ", ".join(p for p in (town, address.get("country")) if p)[:80]
        with self.lock:
            self.data[key] = place
            if len(self.data) > 20000:
                self.data = dict(list(self.data.items())[-15000:])
            self.write_json(self.path, self.data)
        return place


def quote_key(key):
    return quote(key, safe="")
