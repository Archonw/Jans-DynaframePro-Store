# Colour Calendar

Your year as a calendar of colours. Every day becomes a cell in the colour of the photos you took that day, so summers, holidays, winters and Christmas show up as a band of colour. Now and then the scene highlights one day and shows a few of its photos.

## Photos

One or more sources, merged into one calendar:

- **All photos in DynaFrame**: the DynaFrame media database (also WebDAV) plus its media folders and extra folders you enter.
- **A DynaFrame playlist**.
- **All photos in Immich** or **an Immich album**: Immich sends a ThumbHash with every photo, so the plugin gets the colours without downloading any image. You need the server address and an API key (`asset.read`, `asset.view`, `album.read`). You can pick several albums in one row, and filter Immich photos by stars (at least 1 to 5), favourites only, and whether archived photos count. Hidden and locked photos never count.

Only photos with a date taken count. The first read looks at every photo once (a small preview), newest first, and the calendar fills while it works; after that only new photos are read. Colours are cached on the frame.

## How a day gets its colour

Each photo is shrunk to a few dozen pixels. The colour covering the most area wins, vivid colours counting a bit more than grey, so a beach day turns blue and yellow instead of beige. A day mixes the colours of its photos the same way and keeps up to four colours; cells show the main colour with a hint of the second.

## Scene

- Shapes: **Months** (a row per month), **Weeks** (like a wall planner, two halves), **Ring** (the year as a circle, several years as rings inside each other), **Stripes** (a band per year, each day a thin line).
- Period: last 12 months, this calendar year, a year of your choice, or several years (Ring and Stripes).
- Dark or light background, rounded squares, dots or squares, vivid colours, faint fill for short gaps, colour of each month, title.
- Highlight a day: random, day by day, or this day in earlier years; up to four photos with date and the day's colours.

Settings are on the plugin page (Plugins > Colour Calendar > Open Colour Calendar). "Create playlist" adds a playlist with the scene. English, German or Spanish.

## Licences

Fonts Fraunces and Inter (SIL Open Font License, `dynamic/fonts`). ThumbHash decoding after Evan Wallace's ThumbHash (MIT). Problems or wishes: https://github.com/Archonw/Jans-DynaframePro-Store/issues
