"""Musik zur Zeit der Fotos.

Das Plugin merkt sich Aufnahmejahr und Land der zuletzt gezeigten Fotos
(aus der Mediendatenbank von DynaFrame) und sucht Musik, die dazu passt:

- Radio: ein Sender mit dem Jahrzehnt als Schlagwort (radio-browser.info),
  auf Wunsch aus dem Land der Fotos.
- Jellyfin: deine eigenen Stücke aus diesen Jahren.
- Spotify: Stücke aus diesen Jahren aus deinen Lieblingssongs (oder einer
  Playlist, die du wählst); das Jahr ist das Erscheinungsjahr des Albums.
- Music Assistant: eine Playlist wie „Hits 2008“ oder „80s Hits“.
"""

import collections
import random
import re
import time

# Ländernamen, wie DynaFrame sie in locationName schreibt (Deutsch, Englisch,
# Spanisch), -> (ISO-Code, englischer Name für die Suche).
_COUNTRIES = {
    "DE": ("Germany", "deutschland", "germany", "alemania"),
    "AT": ("Austria", "österreich", "austria"),
    "CH": ("Switzerland", "schweiz", "switzerland", "suiza", "suisse", "svizzera"),
    "IT": ("Italy", "italien", "italy", "italia"),
    "FR": ("France", "frankreich", "france", "francia"),
    "ES": ("Spain", "spanien", "spain", "españa", "espana"),
    "PT": ("Portugal", "portugal"),
    "GB": ("United Kingdom", "vereinigtes königreich", "united kingdom", "großbritannien", "england", "schottland",
           "scotland", "wales", "reino unido", "uk"),
    "IE": ("Ireland", "irland", "ireland", "irlanda"),
    "NL": ("Netherlands", "niederlande", "netherlands", "holland", "países bajos", "nederland"),
    "BE": ("Belgium", "belgien", "belgium", "bélgica", "belgique", "belgië"),
    "LU": ("Luxembourg", "luxemburg", "luxembourg", "luxemburgo"),
    "DK": ("Denmark", "dänemark", "denmark", "dinamarca", "danmark"),
    "SE": ("Sweden", "schweden", "sweden", "suecia", "sverige"),
    "NO": ("Norway", "norwegen", "norway", "noruega", "norge"),
    "FI": ("Finland", "finnland", "finland", "finlandia", "suomi"),
    "IS": ("Iceland", "island", "iceland", "islandia"),
    "PL": ("Poland", "polen", "poland", "polonia", "polska"),
    "CZ": ("Czechia", "tschechien", "czechia", "czech republic", "chequia", "república checa"),
    "SK": ("Slovakia", "slowakei", "slovakia", "eslovaquia"),
    "HU": ("Hungary", "ungarn", "hungary", "hungría"),
    "SI": ("Slovenia", "slowenien", "slovenia", "eslovenia"),
    "HR": ("Croatia", "kroatien", "croatia", "croacia", "hrvatska"),
    "RS": ("Serbia", "serbien", "serbia"),
    "BA": ("Bosnia", "bosnien und herzegowina", "bosnia and herzegovina", "bosnia y herzegovina"),
    "ME": ("Montenegro", "montenegro"),
    "AL": ("Albania", "albanien", "albania"),
    "MK": ("North Macedonia", "nordmazedonien", "north macedonia", "macedonia del norte"),
    "GR": ("Greece", "griechenland", "greece", "grecia"),
    "BG": ("Bulgaria", "bulgarien", "bulgaria"),
    "RO": ("Romania", "rumänien", "romania", "rumania"),
    "TR": ("Turkey", "türkei", "turkey", "türkiye", "turquía"),
    "CY": ("Cyprus", "zypern", "cyprus", "chipre"),
    "MT": ("Malta", "malta"),
    "EE": ("Estonia", "estland", "estonia"),
    "LV": ("Latvia", "lettland", "latvia", "letonia"),
    "LT": ("Lithuania", "litauen", "lithuania", "lituania"),
    "UA": ("Ukraine", "ukraine", "ucrania"),
    "US": ("USA", "vereinigte staaten", "usa", "united states", "united states of america", "estados unidos"),
    "CA": ("Canada", "kanada", "canada", "canadá"),
    "MX": ("Mexico", "mexiko", "mexico", "méxico"),
    "BR": ("Brazil", "brasilien", "brazil", "brasil"),
    "AR": ("Argentina", "argentinien", "argentina"),
    "CL": ("Chile", "chile"),
    "PE": ("Peru", "peru", "perú"),
    "CO": ("Colombia", "kolumbien", "colombia"),
    "CU": ("Cuba", "kuba", "cuba"),
    "JM": ("Jamaica", "jamaika", "jamaica"),
    "DO": ("Dominican Republic", "dominikanische republik", "dominican republic", "república dominicana"),
    "MA": ("Morocco", "marokko", "morocco", "marruecos"),
    "TN": ("Tunisia", "tunesien", "tunisia", "túnez"),
    "EG": ("Egypt", "ägypten", "egypt", "egipto"),
    "ZA": ("South Africa", "südafrika", "south africa", "sudáfrica"),
    "KE": ("Kenya", "kenia", "kenya"),
    "TZ": ("Tanzania", "tansania", "tanzania"),
    "AE": ("United Arab Emirates", "vereinigte arabische emirate", "united arab emirates", "emiratos árabes unidos"),
    "IL": ("Israel", "israel"),
    "IN": ("India", "indien", "india"),
    "TH": ("Thailand", "thailand", "tailandia"),
    "VN": ("Vietnam", "vietnam"),
    "ID": ("Indonesia", "indonesien", "indonesia"),
    "MY": ("Malaysia", "malaysia", "malasia"),
    "SG": ("Singapore", "singapur", "singapore"),
    "PH": ("Philippines", "philippinen", "philippines", "filipinas"),
    "CN": ("China", "china"),
    "JP": ("Japan", "japan", "japón"),
    "KR": ("South Korea", "südkorea", "south korea", "corea del sur"),
    "AU": ("Australia", "australien", "australia"),
    "NZ": ("New Zealand", "neuseeland", "new zealand", "nueva zelanda"),
}
_BY_NAME = {name: code for code, names in _COUNTRIES.items() for name in names[1:]}


def country_of(location):
    """ISO-Code aus locationName ('Rom, Italien' -> 'IT'), sonst ''."""
    text = str(location or "").strip()
    if not text:
        return ""
    parts = [p.strip().lower() for p in text.split(",") if p.strip()]
    for part in reversed(parts):
        code = _BY_NAME.get(part)
        if code:
            return code
        if len(part) == 2 and part.upper() in _COUNTRIES:
            return part.upper()
    return ""


def country_name(code):
    return _COUNTRIES.get(code, ("",))[0]


def year_of(value):
    match = re.match(r"^(\d{4})", str(value or ""))
    if not match:
        return 0
    year = int(match.group(1))
    return year if 1900 <= year <= time.localtime().tm_year + 1 else 0


def decade_tag(year):
    decade = year // 10 * 10
    if decade < 1960:
        return "oldies"
    if decade < 2000:
        return f"{decade % 100}s"
    return f"{decade}s"


class EraTracker:
    """Merkt sich die zuletzt gezeigten Fotos und sagt, welche Zeit gerade dran ist."""

    def __init__(self, size=8):
        self.recent = collections.deque(maxlen=size)
        self.last_key = None

    def add(self, key, year, country):
        if key == self.last_key:
            return
        self.last_key = key
        if year:
            self.recent.append((year, country))

    def clear(self):
        self.recent.clear()
        self.last_key = None

    def current(self, span, use_country):
        """(Jahr, Land) der Mehrheit der letzten Fotos, oder (0, '')."""
        if not self.recent:
            return 0, ""
        if span == "decade":
            counts = collections.Counter(y // 10 * 10 for y, _ in self.recent)
            decade = counts.most_common(1)[0][0]
            years = sorted(y for y, _ in self.recent if y // 10 * 10 == decade)
        else:
            counts = collections.Counter(y for y, _ in self.recent)
            top = counts.most_common(1)[0][0]
            years = sorted(y for y, _ in self.recent if abs(y - top) <= 1)
        year = years[len(years) // 2]
        country = ""
        if use_country:
            codes = collections.Counter(c for y, c in self.recent if c and y in years)
            if codes:
                code, hits = codes.most_common(1)[0]
                country = code if hits * 2 >= len(years) else ""
        return year, country


def era_key(year, country, span):
    if not year:
        return ""
    base = f"{year // 10 * 10}s" if span == "decade" else str(year)
    return base + (f"|{country}" if country else "")


def years_for(year, span):
    if not year:
        return []
    if span == "decade":
        start = year // 10 * 10
        return list(range(start, start + 10))
    return [year - 1, year, year + 1]


def describe(year, country, span, lang_name):
    """Kurzer Text wie '2008' / '80er' für die Statuszeile."""
    if not year:
        return ""
    if span == "decade":
        decade = year // 10 * 10
        text = {"de": f"{decade % 100:02d}er" if decade < 2000 else f"{decade}er",
                "en": f"{decade % 100:02d}s" if decade < 2000 else f"{decade}s",
                "es": f"años {decade % 100:02d}" if decade < 2000 else f"años {decade}"}.get(lang_name, f"{decade}s")
    else:
        text = str(year)
    return text + (f", {country}" if country else "")


# --------------------------------------------------------------------------
# Passende Musik je Quelle
# --------------------------------------------------------------------------

def radio(services, year, country):
    """Ein Sender fürs Jahrzehnt (und Land). (url, name, stationId)."""
    tag = decade_tag(year) if year else ""
    attempts = []
    if tag and country:
        attempts.append({"tag": tag, "countrycode": country})
    if tag:
        attempts.append({"tag": tag})
    if country:
        attempts.append({"countrycode": country})
    attempts.append({})
    for params in attempts:
        query = {"limit": 12, "hidebroken": "true", "order": "votes", "reverse": "true"}
        query.update(params)
        rows = services._radio_get("/json/stations/search", query) or []
        rows = [r for r in rows if r.get("url_resolved") or r.get("url")]
        if rows:
            pick = random.choice(rows[:4])
            return pick.get("url_resolved") or pick.get("url"), (pick.get("name") or "?").strip(), pick.get("stationuuid") or ""
    raise services.SourceError("Kein passender Radiosender gefunden")


def jellyfin_tracks(client, year, span, genre=""):
    """Eigene Stücke aus den Jahren um das Foto, breiter, wenn es zu wenige sind."""
    for current_span in ([span, "decade"] if span != "decade" else ["decade"]):
        years = years_for(year, current_span)
        rows = client.tracks_by_years(years, genre)
        if len(rows) >= 5 or not year:
            return rows
    return client.tracks_by_years([], genre)


def ma_media(client, year, country, span):
    """Eine Playlist (oder ein Sender) aus Music Assistant. (uri, name)."""
    queries = []
    if year:
        decade = year // 10 * 10
        label = f"{decade % 100:02d}s" if decade < 2000 else f"{decade}s"
        name = country_name(country) if country else ""
        if name:
            queries.append(f"{name} {label} hits" if span == "decade" else f"{name} hits {year}")
        queries.append(f"{label} hits" if span == "decade" else f"hits {year}")
        queries.append(f"top hits {year}")
    queries.append("top hits")
    for query in queries:
        data = client.call("music/search", search_query=query, media_types=["playlist", "radio"], limit=5) or {}
        for key in ("playlists", "radio"):
            rows = [r for r in data.get(key) or [] if isinstance(r, dict) and r.get("uri")]
            if rows:
                return rows[0]["uri"], rows[0].get("name") or query
    raise client_error(client, "Music Assistant hat nichts Passendes gefunden")


def client_error(_client, text):
    from services import SourceError
    return SourceError(text)


def spotify_pick(spotify, pool, year, span, wait=25):
    """Stücke aus dem Pool (Lieblingssongs/Playlist), deren Album aus diesen Jahren ist.
    (Liste von Track-URIs, Zahl der Stücke im Pool)."""
    tracks = spotify.context_tracks(pool, wait=wait)
    if not year:
        uris = [t["uri"] for t in tracks]
        random.shuffle(uris)
        return uris, len(tracks)
    for current_span in ([span, "decade"] if span != "decade" else ["decade"]):
        years = set(years_for(year, current_span))
        uris = [t["uri"] for t in tracks if year_of(t.get("year")) in years]
        if len(uris) >= 3:
            random.shuffle(uris)
            return uris, len(tracks)
    return [], len(tracks)
