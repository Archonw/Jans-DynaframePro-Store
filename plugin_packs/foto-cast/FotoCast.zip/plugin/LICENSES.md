# Licences of borrowed work

## QR Code Generator for JavaScript (studio/qrcode.js)

Copyright (c) 2009 Kazuhiko Arase, https://github.com/kazuhikoarase/qrcode-generator
Licensed under the MIT license: http://www.opensource.org/licenses/mit-license.php
The word "QR Code" is a registered trademark of DENSO WAVE INCORPORATED.
