"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/ImmichSlideshow/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["QueryLimit", "Window", "RefreshMinutes"];
const CHECK_FIELDS = ["FavoritesOnly"];
const SELECT_FIELDS = ["Source", "RatingMode", "Order", "Quality"];
const TEXT_FIELDS = ["ServerUrl", "Query"];
let current = null;
let editing = false;
let albums = null;   // [{id, name, count, thumb, shared}] oder null = noch nicht geladen
let people = null;   // [{id, name}]
const rendered = { albums: "", people: "" };   // wofür die Listen zuletzt gezeichnet wurden

// Texte der Seite auf Deutsch, Englisch und Spanisch. Die Sprache ist eine
// Einstellung des Plugins und gilt auch für die Szene.
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Fotos von deinem Immich-Server in der Diashow von DynaFrame. Die Fotos bleiben auf dem Server: Auf dem Rahmen liegen immer nur die wenigen, die gleich an der Reihe sind. Jede Änderung hier wird sofort gespeichert.",
    "Photos from your Immich server in DynaFrame's slideshow. The photos stay on the server: the frame only holds the few that are up next. Every change here is saved immediately.",
    "Fotos de tu servidor Immich en la presentación de DynaFrame. Las fotos se quedan en el servidor: en el marco solo están las pocas que van a salir. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  refresh: ["Fotos neu lesen", "Read photos again", "Volver a leer las fotos"],
  factStatus: ["Gerade", "Now", "Ahora"],
  factRead: ["Zuletzt gelesen", "Last read", "Última lectura"],
  factWindow: ["Auf dem Rahmen", "On the frame", "En el marco"],
  windowState: ["{n} Fotos, {seen} davon gezeigt", "{n} photos, {seen} shown", "{n} fotos, {seen} mostradas"],
  notShown: ["DynaFrame zeigt sie noch nicht: wähle die Quelle oder Playlist „Immich Slideshow“.",
    "DynaFrame is not showing them yet: choose the “Immich Slideshow” source or playlist.",
    "DynaFrame aún no las muestra: elige la fuente o la lista «Immich Slideshow»."],
  window: ["Fotos auf dem Rahmen vorhalten", "Photos kept on the frame", "Fotos guardadas en el marco"],
  playHint: ["Anzeigedauer, Übergänge und Overlays stellst du wie gewohnt in DynaFrame ein. Bei „Nach Aufnahmedatum“ stell DynaFrame auf die Reihenfolge der Dateinamen, nicht auf Zufall.",
    "Display time, transitions and overlays are set in DynaFrame as usual. For “by date taken”, set DynaFrame to file name order, not shuffle.",
    "La duración, las transiciones y los overlays se ajustan en DynaFrame como siempre. Para «por fecha», pon DynaFrame en orden por nombre de archivo, no aleatorio."],
  factVersion: ["Version", "Version", "Versión"],
  serverTitle: ["Immich-Server", "Immich server", "Servidor Immich"],
  serverUrl: ["Adresse", "Address", "Dirección"],
  apiKey: ["API-Schlüssel", "API key", "Clave API"],
  test: ["Verbindung testen", "Test connection", "Probar la conexión"],
  testing: ["Teste die Verbindung …", "Testing the connection …", "Probando la conexión …"],
  keyHow: ["So bekommst du einen API-Schlüssel", "How to get an API key", "Cómo conseguir una clave API"],
  keyHint: ["In Immich oben rechts auf dein Profilbild, dann <b>Kontoeinstellungen &gt; API-Schlüssel &gt; Neuer API-Schlüssel</b>. Als Berechtigung reicht <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code> und <code>person.read</code>; mit <b>Alle</b> geht es auch. Die Slideshow zeigt die Fotos des Kontos, dem der Schlüssel gehört, und die mit ihm geteilten Alben. Der Schlüssel bleibt im Plugin auf dem Rahmen.",
    "In Immich, click your profile picture at the top right, then <b>Account Settings &gt; API Keys &gt; New API Key</b>. The permissions <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code> and <code>person.read</code> are enough; <b>All</b> works too. The slideshow shows the photos of the account the key belongs to, and the albums shared with it. The key stays in the plugin on the frame.",
    "En Immich, pulsa tu foto de perfil arriba a la derecha y luego <b>Configuración de la cuenta &gt; Claves API &gt; Nueva clave API</b>. Bastan los permisos <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code> y <code>person.read</code>; con <b>Todos</b> también funciona. La presentación muestra las fotos de la cuenta a la que pertenece la clave y los álbumes compartidos con ella. La clave se queda en el plugin del marco."],
  keySaved: ["gespeichert – zum Ändern neu eingeben", "saved – type a new one to change it", "guardada – escribe otra para cambiarla"],
  keyMissing: ["noch keiner eingetragen", "none entered yet", "todavía ninguna"],
  sourceTitle: ["Welche Fotos", "Which photos", "Qué fotos"],
  source: ["Quelle", "Source", "Origen"],
  sourceAlbums: ["Gewählte Alben", "Selected albums", "Álbumes elegidos"],
  sourceAll: ["Alle Fotos", "All photos", "Todas las fotos"],
  filterAlbums: ["Alben durchsuchen", "Search albums", "Buscar álbumes"],
  filterPeople: ["Personen durchsuchen", "Search people", "Buscar personas"],
  reloadList: ["Liste neu laden", "Reload list", "Recargar la lista"],
  loadingList: ["Lade die Liste von Immich …", "Loading the list from Immich …", "Cargando la lista de Immich …"],
  noAlbums: ["In Immich gibt es keine Alben für diesen Schlüssel.", "Immich has no albums for this key.", "Immich no tiene álbumes para esta clave."],
  noPeople: ["In Immich gibt es keine Personen mit Namen.", "Immich has no people with names.", "Immich no tiene personas con nombre."],
  needServer: ["Trag oben Adresse und API-Schlüssel ein, dann erscheint hier die Liste.", "Enter address and API key above, then the list appears here.", "Introduce arriba la dirección y la clave API y aquí aparecerá la lista."],
  albumsChosen: ["{n} Alben gewählt.", "{n} albums selected.", "{n} álbumes elegidos."],
  albumOne: ["1 Album gewählt.", "1 album selected.", "1 álbum elegido."],
  albumNone: ["Noch kein Album gewählt.", "No album selected yet.", "Todavía no hay ningún álbum elegido."],
  peopleChosen: ["{n} Personen gewählt: Fotos, auf denen mindestens eine davon ist.", "{n} people selected: photos with at least one of them.", "{n} personas elegidas: fotos en las que aparece al menos una."],
  peopleOne: ["1 Person gewählt.", "1 person selected.", "1 persona elegida."],
  peopleNone: ["Keine Person gewählt: Personen sind egal.", "No one selected: people do not matter.", "Nadie elegido: las personas dan igual."],
  shared: ["geteilt", "shared", "compartido"],
  photos: ["{n} Fotos", "{n} photos", "{n} fotos"],
  filterTitle: ["Eingrenzen", "Narrow down", "Acotar"],
  filterHint: ["Alles hier ist freiwillig und gilt zusätzlich zur Quelle oben. Mehrere Alben oder Personen heißen: Fotos aus einem davon.",
    "Everything here is optional and applies on top of the source above. Several albums or people mean: photos from any of them.",
    "Todo esto es opcional y se aplica además del origen de arriba. Varios álbumes o personas significan: fotos de cualquiera de ellos."],
  rating: ["Sterne", "Stars", "Estrellas"],
  ratingAny: ["Egal", "Any", "Da igual"],
  ratingMode: ["Sterne zählen", "Count stars", "Contar estrellas"],
  ratingExact: ["Genau so viele", "Exactly this many", "Exactamente estas"],
  ratingAtLeast: ["So viele oder mehr", "This many or more", "Estas o más"],
  favorites: ["Nur Favoriten (♥)", "Favourites only (♥)", "Solo favoritas (♥)"],
  peopleTitle: ["Personen", "People", "Personas"],
  queryTitle: ["Freie Suche", "Free search", "Búsqueda libre"],
  query: ["Suchbegriff, z. B. „Strand“, „Hund im Schnee“", "Search term, e.g. “beach”, “dog in the snow”", "Término de búsqueda, p. ej. «playa», «perro en la nieve»"],
  queryLimit: ["Höchstens … Treffer", "At most … results", "Como máximo … resultados"],
  queryHint: ["Das ist Immichs Smart Search: Sie findet Fotos nach dem, was darauf zu sehen ist, und braucht das Machine Learning von Immich. Sie liefert die besten Treffer zuerst, deshalb die Grenze. Leer lassen, um nicht zu suchen.",
    "This is Immich's Smart Search: it finds photos by what is in them and needs Immich's machine learning. It returns the best matches first, hence the limit. Leave it empty to not search.",
    "Es la Smart Search de Immich: encuentra fotos por lo que aparece en ellas y necesita el machine learning de Immich. Devuelve primero los mejores resultados, por eso el límite. Déjalo vacío para no buscar."],
  playTitle: ["Wiedergabe", "Playback", "Reproducción"],
  order: ["Reihenfolge", "Order", "Orden"],
  orderRandom: ["Zufall (jedes Foto einmal, dann neu gemischt)", "Random (every photo once, then shuffled again)", "Aleatorio (cada foto una vez, luego se vuelve a mezclar)"],
  orderOldest: ["Nach Aufnahmedatum, älteste zuerst", "By date taken, oldest first", "Por fecha, las más antiguas primero"],
  orderNewest: ["Nach Aufnahmedatum, neueste zuerst", "By date taken, newest first", "Por fecha, las más recientes primero"],
  quality: ["Bildgröße", "Image size", "Tamaño de imagen"],
  qualityPreview: ["Vorschau von Immich (schnell, reicht für Full HD)", "Immich preview (fast, fine for Full HD)", "Vista previa de Immich (rápida, suficiente para Full HD)"],
  qualityFull: ["Volle Größe (für 4K, mehr Daten)", "Full size (for 4K, more data)", "Tamaño completo (para 4K, más datos)"],
  refreshMinutes: ["Neue Fotos suchen alle … Minuten", "Look for new photos every … minutes", "Buscar fotos nuevas cada … minutos"],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „Immich Slideshow“ anlegen", "Create an “Immich Slideshow” playlist", "Crear la lista «Immich Slideshow»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, leg sie für mich an", "Yes, create it for me", "Sí, créala por mí"],
  playlistHint: ["Die Playlist enthält immer die Fotos, die gerade auf dem Rahmen liegen; das Plugin tauscht sie aus, sobald DynaFrame sie gezeigt hat. Lösch sie, wenn du sie nicht mehr brauchst.",
    "The playlist always holds the photos currently on the frame; the plugin swaps them once DynaFrame has shown them. Delete it when you no longer need it.",
    "La lista contiene siempre las fotos que están en el marco; el plugin las cambia cuando DynaFrame las ha mostrado. Bórrala cuando ya no la necesites."],
  noAnswer: ["Das Plugin antwortet nicht – vermutlich wurde es neu gestartet. Lade die Seite neu.",
    "The plugin is not responding – it was probably restarted. Reload the page.",
    "El plugin no responde; probablemente se ha reiniciado. Recarga la página."],
  restarted: ["Das Plugin wurde neu gestartet (HTTP {status}). Lade die Seite neu.",
    "The plugin was restarted (HTTP {status}). Reload the page.",
    "El plugin se ha reiniciado (HTTP {status}). Recarga la página."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  oclock: ["{time} Uhr", "{time}", "{time} h"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  if (albums) renderAlbums();
  if (people) renderPeople();
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) {
    throw new Error(t("restarted", { status: response.status }));
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(iso) {
  if (!iso) return "—";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

function count(n) {
  return Number(n || 0).toLocaleString(LOCALES[lang]);
}

// ---------------------------------------------------------------- Alben und Personen

function checkRow(item, chosen, image, extra, onChange) {
  const label = document.createElement("label");
  label.className = image ? "thumbed" : "";
  const box = document.createElement("input");
  box.type = "checkbox";
  box.checked = chosen.includes(item.id);
  box.addEventListener("change", () => onChange(item.id, box.checked));
  label.append(box);
  if (image) {
    const img = document.createElement("img");
    img.className = image.className;
    img.loading = "lazy";
    img.alt = "";
    if (image.src) img.src = image.src;
    label.append(img);
  }
  const name = document.createElement("span");
  name.className = "name";
  name.textContent = item.name;
  name.title = item.name;
  label.append(name);
  if (extra) {
    const more = document.createElement("span");
    more.className = "count";
    more.textContent = extra;
    label.append(more);
  }
  return label;
}

function toggleId(list, id, on) {
  const next = list.filter((x) => x !== id);
  if (on) next.push(id);
  return next;
}

function renderAlbums() {
  const box = el("albumList");
  const chosen = current ? current.settings.Albums : [];
  rendered.albums = JSON.stringify(chosen);
  const filter = el("albumFilter").value.trim().toLowerCase();
  box.replaceChildren();
  // Gewählte Alben zuerst.
  const rows = [...albums].sort((a, b) => Number(chosen.includes(b.id)) - Number(chosen.includes(a.id)));
  for (const album of rows) {
    if (filter && !album.name.toLowerCase().includes(filter)) continue;
    const extra = t("photos", { n: count(album.count) }) + (album.shared ? ` · ${t("shared")}` : "");
    box.append(checkRow(album, chosen, { className: "thumb", src: album.thumb ? `./api/thumb/${album.thumb}` : "" }, extra,
      (id, on) => save({ Albums: toggleId(current.settings.Albums, id, on) })));
  }
  const n = chosen.length;
  setStatus(albums.length ? (n === 0 ? t("albumNone") : n === 1 ? t("albumOne") : t("albumsChosen", { n })) : t("noAlbums"),
    n === 0 && albums.length ? "bad" : "", "albumNote");
}

function renderPeople() {
  const box = el("peopleList");
  const chosen = current ? current.settings.People : [];
  rendered.people = JSON.stringify(chosen);
  const filter = el("peopleFilter").value.trim().toLowerCase();
  box.replaceChildren();
  const rows = [...people].sort((a, b) => Number(chosen.includes(b.id)) - Number(chosen.includes(a.id)));
  for (const person of rows) {
    if (filter && !person.name.toLowerCase().includes(filter)) continue;
    box.append(checkRow(person, chosen, { className: "face", src: `./api/face/${person.id}` }, "",
      (id, on) => save({ People: toggleId(current.settings.People, id, on) })));
  }
  const n = chosen.length;
  setStatus(people.length ? (n === 0 ? t("peopleNone") : n === 1 ? t("peopleOne") : t("peopleChosen", { n })) : t("noPeople"),
    "", "peopleNote");
}

async function loadLists() {
  if (!current || !current.settings.ServerUrl || !current.settings.ApiKeySet) {
    albums = null;
    people = null;
    el("albumList").replaceChildren();
    el("peopleList").replaceChildren();
    setStatus(t("needServer"), "", "albumNote");
    setStatus(t("needServer"), "", "peopleNote");
    return;
  }
  setStatus(t("loadingList"), "busy", "albumNote");
  setStatus(t("loadingList"), "busy", "peopleNote");
  try {
    albums = (await api("./api/albums")).albums;
    renderAlbums();
  } catch (error) {
    albums = null;
    setStatus(error.message, "bad", "albumNote");
  }
  try {
    people = (await api("./api/people")).people;
    renderPeople();
  } catch (error) {
    people = null;
    setStatus(error.message, "bad", "peopleNote");
  }
}

// ---------------------------------------------------------------- Seite

function render(state) {
  const first = current === null;
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  el("factStatus").textContent = state.status || "—";
  el("factRead").textContent = state.photos.busy ? "…" : clock(state.photos.at);
  el("factWindow").textContent = state.photos.window
    ? t("windowState", { n: state.photos.window, seen: state.photos.seen }) : "—";
  el("factVersion").textContent = state.version;
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Immich Slideshow ${state.version}] `);

  const notes = [state.photos.error, state.photos.window && !state.photos.detected ? t("notShown") : ""].filter(Boolean);
  if (!editing && notes.length) setStatus(notes.join(" "), state.photos.error ? "bad" : "");

  if (!editing) {
    for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) el(name).value = s[name];
    el("Rating").value = String(s.Rating);
    el("MakePlaylist").value = String(Boolean(s.MakePlaylist));
    el("Language").value = lang;
    if (document.activeElement !== el("ApiKey")) {
      el("ApiKey").placeholder = s.ApiKeySet ? t("keySaved") : t("keyMissing");
    }
  }
  el("RatingMode").disabled = !s.Rating || s.Rating === 5;
  el("albumBox").hidden = s.Source !== "albums";
  el("playlistNote").textContent = state.playlist || "";
  // Nur neu zeichnen, wenn sich die Auswahl geändert hat; sonst springt die Liste beim Scrollen.
  if (albums && JSON.stringify(s.Albums) !== rendered.albums) renderAlbums();
  if (people && JSON.stringify(s.People) !== rendered.people) renderPeople();
  if (first) loadLists();
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS, ["ApiKey"])) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
}
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
el("Query").addEventListener("change", (e) => save({ Query: e.target.value }));
el("Rating").addEventListener("change", (e) => save({ Rating: Number(e.target.value) }));
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save({ Language: e.target.value });
});

async function saveServer() {
  const changes = { ServerUrl: el("ServerUrl").value };
  const key = el("ApiKey").value.trim();
  if (key) changes.ApiKey = key;
  const changed = await save(changes);
  el("ApiKey").value = "";
  if (changed.includes("ServerUrl") || changed.includes("ApiKey")) await testConnection();
}

async function testConnection() {
  setStatus(t("testing"), "busy", "testNote");
  try {
    const result = await api("./api/test", { method: "POST" });
    setStatus(result.message, result.ok ? "ok" : "bad", "testNote");
    if (result.ok) loadLists();
  } catch (error) {
    setStatus(error.message, "bad", "testNote");
  }
}

el("ServerUrl").addEventListener("change", saveServer);
el("ApiKey").addEventListener("change", saveServer);
el("testButton").addEventListener("click", async () => {
  if (el("ApiKey").value.trim() || el("ServerUrl").value !== (current?.settings.ServerUrl || "")) await saveServer();
  else await testConnection();
});
el("albumFilter").addEventListener("input", () => albums && renderAlbums());
el("peopleFilter").addEventListener("input", () => people && renderPeople());
el("albumsReload").addEventListener("click", loadLists);
el("peopleReload").addEventListener("click", loadLists);
el("refreshButton").addEventListener("click", async () => {
  try {
    const result = await api("./api/refresh", { method: "POST" });
    setStatus(result.message || "", "busy");
    setTimeout(refresh, 2500);
  } catch (error) {
    setStatus(error.message, "bad");
  }
});

refresh();
setInterval(refresh, 5000);
