"""Termine für das Kalenderblatt: ICS-Adressen (Google, Nextcloud, iCloud,
Outlook, CalDAV-Export ...) und Kalender aus Home Assistant.

Jeder Kalender liefert Termine als einfache Zeilen:
    {"uid", "title", "start", "end", "allDay", "location", "birthday"}
start/end sind ISO-Texte in Ortszeit des Rahmens ("2026-11-14" bei
ganztägigen Terminen, sonst "2026-11-14T18:30"). end ist bei ganztägigen
Terminen wie im ICS exklusiv (der Tag danach).

Wiederkehrende Termine (RRULE, Ausnahmen, verschobene Einzeltermine) löst
recurring_ical_events auf.
"""

import datetime
import hashlib
import re

import requests

try:
    import icalendar  # type: ignore
    import recurring_ical_events  # type: ignore
except Exception:  # pragma: no cover - kommt mit requirements.txt
    icalendar = recurring_ical_events = None

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 40
MAX_BYTES = 15 * 1024 * 1024
MAX_EVENTS = 1500
USER_AGENT = "DynaFrame-CalendarPage/1 (+https://github.com/Archonw/Jans-DynaframePro-Store)"

# Ein Termin mit diesen Wörtern ist ein Geburtstag (Kuchen statt Punkt).
BIRTHDAY_WORDS = re.compile(r"geburtstag|birthday|cumpleaños|cumpleanos|\bb-?day\b|🎂", re.I)


class CalendarError(Exception):
    def __init__(self, message, code=""):
        super().__init__(message)
        self.code = code


def normalize_ics_url(raw):
    text = str(raw or "").strip()
    if not text:
        return ""
    if text.lower().startswith("webcal://"):
        text = "https://" + text[9:]
    elif text.lower().startswith("webcals://"):
        text = "https://" + text[10:]
    if not re.match(r"^https?://", text, re.I):
        text = "https://" + text
    return text[:1000]


def mask_url(url):
    """Für die Seite: nur der Server, nie der geheime Teil der Adresse."""
    match = re.match(r"^(https?://)?([^/?#]+)", str(url or ""))
    return (match.group(2) + "/…") if match else ""


def _local(value):
    """date oder datetime -> (iso, allDay) in Ortszeit des Rahmens."""
    if isinstance(value, datetime.datetime):
        if value.tzinfo is not None:
            value = value.astimezone().replace(tzinfo=None)
        return value.strftime("%Y-%m-%dT%H:%M"), False
    if isinstance(value, datetime.date):
        return value.isoformat(), True
    return "", True


def _clean(text, limit=120):
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    return text[:limit]


def short_error(exc):
    """Aus einer langen requests-Meldung den Kern holen (ohne Pool-Text und Adresse)."""
    text = str(exc)
    for pattern in (r"\[SSL: ([A-Z_]+)\]", r"certificate verify failed: ([^)(\]'\"]+)", r"(Name or service not known|"
                    r"Temporary failure in name resolution|Connection refused|No route to host|timed out|"
                    r"Network is unreachable|getaddrinfo failed|nodename nor servname provided)"):
        found = re.search(pattern, text)
        if found:
            return found.group(1).replace("_", " ").strip().lower() if pattern.startswith("\\[SSL") else found.group(1).strip()
    return _clean(re.sub(r"HTTPS?ConnectionPool\([^)]*\):\s*", "", text), 100)


def uid_hash(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()[:14]


def fetch_ics(url):
    """Die ICS-Datei laden (mit Größenbremse)."""
    try:
        response = requests.get(url, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), stream=True,
                                headers={"User-Agent": USER_AGENT, "Accept": "text/calendar, */*"})
    except requests.exceptions.SSLError as exc:
        raise CalendarError(short_error(exc), "ssl") from exc
    except requests.RequestException as exc:
        raise CalendarError(short_error(exc), "unreachable") from exc
    if response.status_code in (401, 403):
        raise CalendarError(f"HTTP {response.status_code}", "denied")
    if response.status_code == 404:
        raise CalendarError("HTTP 404", "not-found")
    if response.status_code >= 400:
        raise CalendarError(f"HTTP {response.status_code}", "http")
    chunks, size = [], 0
    for chunk in response.iter_content(65536):
        size += len(chunk)
        if size > MAX_BYTES:
            raise CalendarError("> 15 MB", "too-big")
        chunks.append(chunk)
    data = b"".join(chunks)
    if b"BEGIN:VCALENDAR" not in data[:4096].upper() and b"BEGIN:VCALENDAR" not in data.upper():
        raise CalendarError("no VCALENDAR", "not-ics")
    return data


def parse_ics(data, start, end):
    """Termine zwischen start und end (date) aus ICS-Bytes."""
    if icalendar is None or recurring_ical_events is None:
        raise CalendarError("icalendar fehlt", "missing-lib")
    try:
        cal = icalendar.Calendar.from_ical(data)
    except Exception as exc:  # noqa: BLE001 - kaputte Datei
        raise CalendarError(str(exc)[:160], "not-ics") from exc
    try:
        found = recurring_ical_events.of(cal, skip_bad_series=True).between(start, end)
    except TypeError:  # ältere Version ohne skip_bad_series
        found = recurring_ical_events.of(cal).between(start, end)
    except Exception as exc:  # noqa: BLE001
        raise CalendarError(str(exc)[:160], "not-ics") from exc
    out = []
    for event in found:
        if getattr(event, "name", "") != "VEVENT":
            continue
        status = str(event.get("STATUS") or "").upper()
        if status == "CANCELLED":
            continue
        dtstart = event.get("DTSTART")
        if dtstart is None:
            continue
        begin, all_day = _local(dtstart.dt)
        dtend = event.get("DTEND")
        if dtend is not None:
            finish, _ = _local(dtend.dt)
        elif event.get("DURATION") is not None:
            finish, _ = _local(dtstart.dt + event.get("DURATION").dt)
        elif all_day:
            finish = (dtstart.dt + datetime.timedelta(days=1)).isoformat()
        else:
            finish = begin
        title = _clean(event.get("SUMMARY")) or "—"
        out.append({
            "uid": uid_hash(event.get("UID") or title, begin),
            "title": title,
            "start": begin, "end": finish or begin, "allDay": all_day,
            "location": _clean(event.get("LOCATION"), 80),
            "birthday": bool(BIRTHDAY_WORDS.search(title)),
        })
        if len(out) >= MAX_EVENTS:
            break
    return out


# --------------------------------------------------------------------------
# Home Assistant
# --------------------------------------------------------------------------

def normalize_ha_url(raw):
    """"192.168.1.5", "homeassistant.local:8123/" oder "https://ha.example.org"
    werden zu einer Basisadresse ohne Schrägstrich (wie Moody Frame)."""
    text = str(raw or "").strip().rstrip("/")
    if not text:
        return ""
    if not re.match(r"^https?://", text, re.I):
        host = text.split("/", 1)[0]
        if ":" not in host.rsplit("]", 1)[-1]:
            text = text.replace(host, host + ":8123", 1)
        text = "http://" + text
    text = re.sub(r"/(lovelace|config|profile|dashboard)[^ ]*$", "", text)
    return text.rstrip("/")[:300]


class HomeAssistant:
    def __init__(self):
        self.base = ""
        self.token = ""

    def configure(self, base, token):
        self.base, self.token = base, token

    def _get(self, path, params=None):
        if not self.base:
            raise CalendarError("no-url", "no-url")
        if not self.token:
            raise CalendarError("no-token", "no-token")
        try:
            response = requests.get(self.base + path, params=params, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
                                    headers={"Authorization": f"Bearer {self.token}"})
        except requests.exceptions.SSLError as exc:
            raise CalendarError(short_error(exc), "ssl") from exc
        except requests.RequestException as exc:
            raise CalendarError(short_error(exc), "unreachable") from exc
        if response.status_code == 401:
            raise CalendarError("HTTP 401", "token")
        if response.status_code == 404:
            raise CalendarError("HTTP 404", "not-found")
        if response.status_code >= 400:
            raise CalendarError(f"HTTP {response.status_code}", "http")
        try:
            return response.json()
        except ValueError as exc:
            raise CalendarError("no JSON", "http") from exc

    def test(self):
        data = self._get("/api/config")
        return {"name": str(data.get("location_name") or ""), "version": str(data.get("version") or "")}

    def calendars(self):
        rows = self._get("/api/calendars") or []
        return sorted(({"id": str(r.get("entity_id")), "name": str(r.get("name") or r.get("entity_id"))}
                       for r in rows if isinstance(r, dict) and str(r.get("entity_id", "")).startswith("calendar.")),
                      key=lambda r: r["name"].lower())

    def events(self, entity_id, start, end):
        params = {"start": f"{start.isoformat()}T00:00:00", "end": f"{end.isoformat()}T00:00:00"}
        rows = self._get(f"/api/calendars/{entity_id}", params) or []
        out = []
        for row in rows if isinstance(rows, list) else []:
            if not isinstance(row, dict):
                continue
            begin, all_day = _ha_time(row.get("start"))
            finish, _ = _ha_time(row.get("end"))
            if not begin:
                continue
            title = _clean(row.get("summary") or row.get("message")) or "—"
            out.append({"uid": uid_hash(row.get("uid") or title, begin, row.get("recurrence_id") or ""),
                        "title": title, "start": begin, "end": finish or begin, "allDay": all_day,
                        "location": _clean(row.get("location"), 80),
                        "birthday": bool(BIRTHDAY_WORDS.search(title))})
            if len(out) >= MAX_EVENTS:
                break
        return out


def _ha_time(value):
    if isinstance(value, dict):
        if value.get("dateTime"):
            value = value["dateTime"]
        elif value.get("date"):
            return str(value["date"])[:10], True
        else:
            return "", True
    text = str(value or "")
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        return text, True
    try:
        moment = datetime.datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return "", True
    return _local(moment)
