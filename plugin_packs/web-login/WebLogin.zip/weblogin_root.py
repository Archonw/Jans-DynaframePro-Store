#!/usr/bin/env python3
"""Web Login - the part that needs administrator rights.

The plugin runs it as   sudo -n /usr/bin/python3 -I weblogin_root.py <verb>
using the frame user's passwordless sudo. Verbs:

  install <plugin dir>  copy this file and authd.py to /usr/local/lib/dfr-weblogin,
                        install and start dfr-weblogin.service, then apply
  apply                 make nginx and the firewall match the plugin's
                        data/authd.json (protection on or off)
  ensure                like apply, but only touches what has drifted; the
                        login service runs it at boot and whenever DynaFrame
                        has rewritten its nginx site (every update does)
  off                   remove everything again: nginx back to DynaFrame's own
                        site, firewall table gone, service stopped and removed
  status                JSON: what is in place now
  ports                 JSON: TCP ports the frame answers on from the network

How nginx is changed: DynaFrame's site stays untouched in
sites-available/dynaframe. A copy with the login added goes to
/etc/nginx/dfr-weblogin/site.conf, and the sites-enabled/dynaframe link is
pointed at that copy. DynaFrame's installer always puts the link back; the
service notices and builds the copy again from the new site. Before every
switch `nginx -t` checks the result; if it fails, DynaFrame's own site is
put back, so the web page never goes dark because of this plugin.

How the firewall works: one nftables table of our own, inet dfr_weblogin. It
only refuses the ports the owner ticked (default 8001 Engine, 8003 web page
directly, 8080 renderer) to everyone but the frame itself and trusted
addresses. Every other port, including ports of plugins installed later,
stays open. SSH (22) and the web page (80) can never be ticked. The table is
not saved; after a reboot the service builds it again.
"""

import hashlib
import ipaddress
import json
import os
import pwd
import re
import shutil
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(os.environ.get("WEBLOGIN_ROOT", "/"))
NGINX = ROOT / "etc/nginx"
SOURCE_SITE = NGINX / "sites-available/dynaframe"
ENABLED_LINK = NGINX / "sites-enabled/dynaframe"
OUR_DIR = NGINX / "dfr-weblogin"
OUR_SITE = OUR_DIR / "site.conf"
OUR_INC = OUR_DIR / "server.inc"
OUR_INC_TLS = OUR_DIR / "server-https.inc"
OUR_HASH = OUR_DIR / "source.sha256"
LIB = ROOT / "usr/local/lib/dfr-weblogin"
PLUGIN_DIR_FILE = LIB / "plugin-dir"
TLS_DIR = LIB / "tls"
SELF_CERT = TLS_DIR / "self-cert.pem"
SELF_KEY = TLS_DIR / "self-key.pem"
SELF_NAMES = TLS_DIR / "self-names.txt"
CUSTOM_CERT = TLS_DIR / "custom-cert.pem"
CUSTOM_KEY = TLS_DIR / "custom-key.pem"
UNIT_NAME = "dfr-weblogin.service"
UNIT_FILE = ROOT / "etc/systemd/system" / UNIT_NAME
TABLE = "dfr_weblogin"
AUTH_PORT = 8097
NEVER_BLOCK = {22, 80, 443}
DEFAULT_PORTS = [8001, 8003, 8080]
DEFAULT_OPEN = ["/nfc/", "/automations/"]
MARK = "# dfr-weblogin"
DRY = os.environ.get("WEBLOGIN_DRY") == "1"     # tests: no systemctl, nft or reload

os.environ["PATH"] = "/usr/sbin:/usr/bin:/sbin:/bin"


def run(*cmd, check=False, quiet=True, input_text=None):
    if DRY and cmd[0] in ("systemctl", "nft"):
        return subprocess.CompletedProcess(cmd, 0, "", "")
    result = subprocess.run(list(cmd), capture_output=True, text=True, input=input_text, timeout=120)
    if check and result.returncode != 0:
        raise RuntimeError(f"{' '.join(cmd)}: {(result.stderr or result.stdout).strip()[:400]}")
    return result


def out(payload):
    print(json.dumps(payload, ensure_ascii=False))


# --------------------------------------------------------------------------
# Settings from the plugin
# --------------------------------------------------------------------------

def plugin_dir():
    try:
        return Path(PLUGIN_DIR_FILE.read_text().strip())
    except OSError:
        return None


def load_config():
    folder = plugin_dir()
    if folder is None:
        return {}
    try:
        data = json.loads((folder / "data" / "authd.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def wanted(config):
    """What the owner asked for, checked and cleaned."""
    active = bool(config.get("active")) and bool(config.get("passwordHash"))
    ports = []
    for value in config.get("blockPorts", DEFAULT_PORTS) or []:
        try:
            port = int(value)
        except (TypeError, ValueError):
            continue
        if 0 < port < 65536 and port not in NEVER_BLOCK and port not in ports:
            ports.append(port)
    trusted4, trusted6 = [], []
    for entry in config.get("trusted") or []:
        try:
            net = ipaddress.ip_network(str(entry).strip(), strict=False)
        except ValueError:
            continue
        (trusted4 if net.version == 4 else trusted6).append(str(net))
    open_paths = [p for p in (config.get("openPaths") or DEFAULT_OPEN)
                  if isinstance(p, str) and re.fullmatch(r"/[A-Za-z0-9_\-./]*", p)]
    if config.get("protectAutomations"):
        open_paths = []
    https = config.get("https") if isinstance(config.get("https"), dict) else {}
    cert = str(https.get("cert") or "").strip()
    key = str(https.get("key") or "").strip()
    own = "BEGIN CERTIFICATE" in cert and "PRIVATE KEY" in key
    return {"active": active, "firewall": active and bool(config.get("firewall", True)),
            "ports": sorted(ports), "trusted4": trusted4, "trusted6": trusted6, "openPaths": open_paths,
            "https": active and bool(https.get("enabled")), "ownCert": cert if own else "",
            "ownKey": key if own else ""}


# --------------------------------------------------------------------------
# nginx
# --------------------------------------------------------------------------

def server_include(https_side=False, https_on=False):
    # With HTTPS on, browsers sign in over HTTPS only; the login cookie is then
    # marked Secure, so plain HTTP never carries it either.
    target = "https://$host/dfr-login/?rd=$request_uri" if https_on else "/dfr-login/?rd=$request_uri"
    return f"""{MARK}: written by the Web Login plugin, do not edit.
# Every request asks the login service first; it answers 204 (go ahead) or 401.
auth_request /dfr-auth;
auth_request_set $dfr_login_cookie $upstream_http_set_cookie;
add_header Set-Cookie $dfr_login_cookie always;
error_page 401 = @dfr_login;

location = /dfr-auth {{
    internal;
    proxy_pass http://127.0.0.1:{AUTH_PORT}/auth;
    proxy_pass_request_body off;
    proxy_set_header Content-Length "";
    proxy_set_header X-Original-URI $request_uri;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $http_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_connect_timeout 3s;
    proxy_read_timeout 5s;
}}

location ^~ /dfr-login/ {{
    auth_request off;
    proxy_pass http://127.0.0.1:{AUTH_PORT};
    proxy_set_header Host $http_host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $http_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 30s;
}}

location @dfr_login {{
    auth_request off;
    # Programs (an API key was sent) get a plain 401, browsers the login page.
    if ($http_authorization) {{ return 401; }}
    if ($http_x_dynaframe_key) {{ return 401; }}
    return 302 {target};
}}
"""


def tls_lines(cert, key):
    return [f"    ssl_certificate {cert};  {MARK}",
            f"    ssl_certificate_key {key};  {MARK}",
            f"    ssl_protocols TLSv1.2 TLSv1.3;  {MARK}",
            f"    ssl_session_cache shared:dfr_weblogin:1m;  {MARK}"]


LOCATION = re.compile(r"^(\s*)location\s+(.*?)\s*\{\s*(#.*)?$")


def _strip_comment(line):
    quote = None
    for i, ch in enumerate(line):
        if quote:
            if ch == quote:
                quote = None
        elif ch in "'\"":
            quote = ch
        elif ch == "#":
            return line[:i]
    return line


def _location_path(spec):
    parts = spec.split()
    return parts[-1] if parts else ""


def transform(source, open_paths, include=None, extra=None):
    """DynaFrame's site with the login added. Raises ValueError if the site
    does not look like one we understand (then nothing is switched)."""
    lines = source.splitlines()
    result = []
    depth = 0
    servers = 0
    i = 0
    while i < len(lines):
        line = lines[i]
        code = _strip_comment(line)
        if depth == 0 and re.match(r"^\s*server\s*\{", code):
            if not re.search(r"\{\s*$", code):
                raise ValueError("server block on one line")
            servers += 1
            result.append(line)
            result.append(f"    include {include or OUR_INC};  {MARK}")
            result.extend(extra or [])
            depth += code.count("{") - code.count("}")
            i += 1
            continue
        match = LOCATION.match(line) if depth == 1 else None
        if match:
            # Collect the whole location to see what it already sets.
            body, level, j = [line], code.count("{") - code.count("}"), i + 1
            while j < len(lines) and level > 0:
                body.append(lines[j])
                level += _strip_comment(lines[j]).count("{") - _strip_comment(lines[j]).count("}")
                j += 1
            if level != 0:
                raise ValueError("unbalanced braces")
            indent = match.group(1) + "    "
            spec = match.group(2)
            path = _location_path(spec)
            text = "\n".join(_strip_comment(b) for b in body[1:])
            inner_top = [b for b in body[1:-1]]
            added = []
            named = spec.startswith("@")
            internal = re.search(r"^\s*internal\s*;", text, re.M) is not None
            if named or internal or any(path == p or path == p.rstrip("/") for p in open_paths):
                added.append(f"{indent}auth_request off;  {MARK}")
            elif re.search(r"^\s*error_page\s", text, re.M):
                # A location with its own error_page does not inherit ours.
                added.append(f"{indent}error_page 401 = @dfr_login;  {MARK}")
            result.append(line)
            result.extend(added)
            result.extend(inner_top)
            result.append(body[-1])
            i = j
            continue
        depth += code.count("{") - code.count("}")
        if depth < 0:
            raise ValueError("unbalanced braces")
        result.append(line)
        i += 1
    if depth != 0:
        raise ValueError("unbalanced braces")
    if servers == 0:
        raise ValueError("no server block")
    if not re.search(r"^\s*listen\s+(\[::\]:)?(80|443)\b", source, re.M):
        raise ValueError("site does not listen on port 80")
    return "\n".join(result) + "\n"


LISTEN_80 = re.compile(r"^(\s*listen\s+(?:\[::\]:|0\.0\.0\.0:)?)80\b([^;]*);", re.M)


def make_site(source, want, cert=None):
    """DynaFrame's site with the login, plus the same site on port 443 when
    HTTPS is on."""
    site = transform(source, want["openPaths"])
    if want.get("https") and cert:
        https_source = LISTEN_80.sub(lambda m: f"{m.group(1)}443 ssl{m.group(2)};", source)
        site += "\n# HTTPS copy of the site above  " + MARK + "\n"
        site += transform(https_source, want["openPaths"], OUR_INC_TLS, tls_lines(*cert))
    return site


def source_hash():
    try:
        return hashlib.sha256(SOURCE_SITE.read_bytes()).hexdigest()
    except OSError:
        return ""


def link_target():
    try:
        return os.readlink(ENABLED_LINK)
    except OSError:
        return None


def nginx_ours():
    return link_target() == str(OUR_SITE)


def nginx_test():
    if DRY:
        return True, ""
    result = run("nginx", "-t")
    return result.returncode == 0, (result.stderr or "").strip()[-600:]


def nginx_reload():
    if not DRY:
        run("systemctl", "reload", "nginx")


def point_link(target):
    tmp = ENABLED_LINK.with_name(".dynaframe.dfr-weblogin")
    try:
        tmp.unlink()
    except FileNotFoundError:
        pass
    os.symlink(str(target), tmp)
    os.replace(tmp, ENABLED_LINK)


def nginx_on(want):
    source = SOURCE_SITE.read_text(encoding="utf-8")
    cert = ensure_cert(want) if want.get("https") else None
    site = make_site(source, want, cert)
    OUR_DIR.mkdir(parents=True, exist_ok=True)
    OUR_INC.write_text(server_include(False, bool(cert)), encoding="utf-8")
    OUR_INC_TLS.write_text(server_include(True, bool(cert)), encoding="utf-8")
    OUR_SITE.write_text(site, encoding="utf-8")
    OUR_HASH.write_text(source_hash() + "\n")
    before = link_target()
    point_link(OUR_SITE)
    ok, error = nginx_test()
    if not ok:
        point_link(before or SOURCE_SITE)
        raise RuntimeError(f"nginx refused the login setup, left as it was: {error}")
    nginx_reload()


def nginx_off():
    if nginx_ours() or (ENABLED_LINK.is_symlink() and not ENABLED_LINK.exists()):
        point_link(SOURCE_SITE)
        ok, _error = nginx_test()
        if ok:
            nginx_reload()
    shutil.rmtree(OUR_DIR, ignore_errors=True)


def nginx_needs_work(want):
    if not want["active"]:
        return nginx_ours() or OUR_DIR.exists()
    if not nginx_ours():
        return True
    try:
        if OUR_HASH.read_text().strip() != source_hash():
            return True
        if want.get("https") and cert_needs_work(want):
            return True
        cert = cert_paths(want) if want.get("https") else None
        expected = make_site(SOURCE_SITE.read_text(encoding="utf-8"), want, cert)
        return (OUR_SITE.read_text(encoding="utf-8") != expected
                or OUR_INC.read_text(encoding="utf-8") != server_include(False, bool(cert)))
    except (OSError, ValueError):
        return True


# --------------------------------------------------------------------------
# Certificate
# --------------------------------------------------------------------------

def frame_names():
    """Names and addresses the frame is reached by, for a self-made certificate."""
    host = socket.gethostname()
    names = {f"DNS:{host}", f"DNS:{host}.local", "DNS:localhost", "IP:127.0.0.1"}
    for address in run("hostname", "-I").stdout.split():
        try:
            ip = ipaddress.ip_address(address)
        except ValueError:
            continue
        if ip.version == 4 or not ip.is_link_local:
            names.add(f"IP:{ip}")
    return sorted(names)


def cert_paths(want):
    return (CUSTOM_CERT, CUSTOM_KEY) if want.get("ownCert") else (SELF_CERT, SELF_KEY)


def cert_needs_work(want):
    if want.get("ownCert"):
        try:
            return CUSTOM_CERT.read_text() != want["ownCert"] + "\n" or CUSTOM_KEY.read_text() != want["ownKey"] + "\n"
        except OSError:
            return True
    if not SELF_CERT.exists() or not SELF_KEY.exists():
        return True
    try:
        if SELF_NAMES.read_text().split() != frame_names():
            return True
    except OSError:
        return True
    return run("openssl", "x509", "-checkend", str(30 * 86400), "-noout", "-in", str(SELF_CERT)).returncode != 0


def ensure_cert(want):
    TLS_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(TLS_DIR, 0o755)
    if want.get("ownCert"):
        CUSTOM_CERT.write_text(want["ownCert"] + "\n")
        os.chmod(CUSTOM_CERT, 0o644)
        fd = os.open(CUSTOM_KEY, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as handle:
            handle.write(want["ownKey"] + "\n")
        run("openssl", "x509", "-noout", "-in", str(CUSTOM_CERT), check=True)
        return CUSTOM_CERT, CUSTOM_KEY
    if cert_needs_work(want):
        names = frame_names()
        host = socket.gethostname()
        run("openssl", "req", "-x509", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:prime256v1",
            "-nodes", "-days", "3650", "-subj", f"/CN={host}/O=DynaFrame Web Login",
            "-addext", "subjectAltName=" + ",".join(names),
            "-addext", "basicConstraints=critical,CA:FALSE",
            "-addext", "extendedKeyUsage=serverAuth",
            "-keyout", str(SELF_KEY), "-out", str(SELF_CERT), check=True)
        os.chmod(SELF_KEY, 0o600)
        os.chmod(SELF_CERT, 0o644)
        SELF_NAMES.write_text(" ".join(names) + "\n")
    return SELF_CERT, SELF_KEY


def cert_info():
    want = wanted(load_config())
    path = cert_paths(want)[0]
    if not path.exists():
        return None
    text = run("openssl", "x509", "-noout", "-subject", "-enddate", "-fingerprint", "-sha256",
               "-ext", "subjectAltName", "-in", str(path)).stdout
    info = {"own": bool(want.get("ownCert")), "pem": path.read_text()}
    for line in text.splitlines():
        if line.startswith("notAfter="):
            info["until"] = line.split("=", 1)[1].strip()
        elif "Fingerprint=" in line:
            info["sha256"] = line.split("=", 1)[1].strip()
        elif line.startswith("subject="):
            info["subject"] = line.split("=", 1)[1].strip()
        elif "DNS:" in line or "IP Address:" in line:
            info["names"] = line.strip()
    return info


# --------------------------------------------------------------------------
# Firewall
# --------------------------------------------------------------------------

def ruleset(want):
    ports = ", ".join(str(p) for p in want["ports"])
    rules = ['        iif "lo" accept']
    if want["trusted4"]:
        rules.append(f"        ip saddr {{ {', '.join(want['trusted4'])} }} accept")
    if want["trusted6"]:
        rules.append(f"        ip6 saddr {{ {', '.join(want['trusted6'])} }} accept")
    if ports:
        rules.append(f"        tcp dport {{ {ports} }} reject with tcp reset")
    body = "\n".join(rules)
    return f"""table inet {TABLE}
delete table inet {TABLE}
table inet {TABLE} {{
    chain input {{
        type filter hook input priority filter - 5; policy accept;
{body}
    }}
}}
"""


def firewall_on(want):
    with tempfile.NamedTemporaryFile("w", suffix=".nft", delete=False) as handle:
        handle.write(ruleset(want))
        path = handle.name
    try:
        run("nft", "-f", path, check=True)
    finally:
        os.unlink(path)


def firewall_off():
    run("nft", "delete", "table", "inet", TABLE)


def firewall_present():
    if DRY:
        return None
    return run("nft", "list", "table", "inet", TABLE).returncode == 0


def firewall_current():
    if DRY:
        return ""
    result = run("nft", "list", "table", "inet", TABLE)
    return result.stdout if result.returncode == 0 else ""


def _nets(text):
    found = set()
    for part in re.split(r"[,\s]+", text or ""):
        try:
            found.add(ipaddress.ip_network(part, strict=False))
        except ValueError:
            pass
    return found


def firewall_matches(want):
    """True if the live table refuses exactly the wanted ports to exactly the
    wanted addresses."""
    live = firewall_current()
    needed = want["firewall"] and bool(want["ports"])
    if not live:
        return not needed
    if not needed:
        return False
    match = re.search(r"tcp dport \{?\s*([0-9, ]+?)\s*\}? reject", live)
    found = sorted(int(p) for p in re.findall(r"\d+", match.group(1))) if match else []
    trusted = set()
    for text in re.findall(r"saddr \{?\s*([^}\n]+?)\s*\}? accept", live):
        trusted |= _nets(text)
    wanted_trusted = _nets(" ".join(want["trusted4"] + want["trusted6"]))
    return found == want["ports"] and trusted == wanted_trusted


# --------------------------------------------------------------------------
# The login service
# --------------------------------------------------------------------------

def unit_text(folder, user):
    return f"""[Unit]
Description=DynaFrame Web Login (Web Login plugin)
After=network.target

[Service]
User={user}
Group={user}
ExecStart=/usr/bin/python3 -I {LIB}/authd.py --config {folder}/data/authd.json --port {AUTH_PORT}
Restart=always
RestartSec=2
NoNewPrivileges=no

[Install]
WantedBy=multi-user.target
"""


def install(folder):
    folder = Path(folder).resolve()
    if not (folder / "manifest.json").is_file() or not (folder / "authd.py").is_file():
        raise RuntimeError(f"not the Web Login plugin folder: {folder}")
    user = pwd.getpwuid(folder.stat().st_uid).pw_name
    LIB.mkdir(parents=True, exist_ok=True)
    changed = False
    for name in ("authd.py", "oidc.py", "weblogin_root.py"):
        new = (folder / name).read_bytes()
        target = LIB / name
        if not target.exists() or target.read_bytes() != new:
            target.write_bytes(new)
            os.chmod(target, 0o755)
            changed = True
    PLUGIN_DIR_FILE.write_text(str(folder) + "\n")
    unit = unit_text(folder, user)
    if not UNIT_FILE.exists() or UNIT_FILE.read_text() != unit:
        UNIT_FILE.parent.mkdir(parents=True, exist_ok=True)
        UNIT_FILE.write_text(unit)
        run("systemctl", "daemon-reload")
        changed = True
    run("systemctl", "enable", UNIT_NAME)
    if changed:
        run("systemctl", "restart", UNIT_NAME)
    else:
        run("systemctl", "start", UNIT_NAME)
    return apply()


def apply(only_drift=False):
    want = wanted(load_config())
    did = []
    if want["active"]:
        if not only_drift or nginx_needs_work(want):
            nginx_on(want)
            did.append("nginx")
    elif nginx_ours() or OUR_DIR.exists():
        nginx_off()
        did.append("nginx-off")
    if want["firewall"] and want["ports"]:
        if not only_drift or not firewall_matches(want):
            firewall_on(want)
            did.append("firewall")
    elif not only_drift or firewall_present():
        firewall_off()
        did.append("firewall-off")
    return {"ok": True, "did": did, **status()}


def off():
    errors = []
    for step in (nginx_off, firewall_off):
        try:
            step()
        except Exception as exc:  # keep going: the point is to get out
            errors.append(str(exc))
    run("systemctl", "disable", UNIT_NAME)
    try:
        UNIT_FILE.unlink()
    except FileNotFoundError:
        pass
    run("systemctl", "daemon-reload")
    # Stopping last: when the service itself calls "off", this ends it.
    run("systemctl", "stop", "--no-block", UNIT_NAME)
    return {"ok": not errors, "errors": errors}


def status():
    active = run("systemctl", "is-active", UNIT_NAME).stdout.strip() if not DRY else "active"
    return {
        "nginx": "login" if nginx_ours() else "dynaframe",
        "nginxCurrent": nginx_ours() and OUR_HASH.exists() and OUR_HASH.read_text().strip() == source_hash(),
        "firewall": firewall_current(),
        "service": active,
        "installed": (LIB / "authd.py").exists(),
        "https": bool(nginx_ours() and OUR_SITE.exists()
                      and re.search(r"listen\s+\S*443", OUR_SITE.read_text())),
        "cert": cert_info(),
    }


def ports():
    rows = []
    result = run("ss", "-tlnpH")
    for line in result.stdout.splitlines():
        parts = line.split()
        if len(parts) < 4:
            continue
        local = parts[3]
        address, _, port = local.rpartition(":")
        address = address.strip("[]").split("%")[0]
        try:
            ip = ipaddress.ip_address(address) if address not in ("*", "") else None
        except ValueError:
            ip = None
        if ip is not None and ip.is_loopback:
            continue
        process = ""
        found = re.search(r'users:\(\("([^"]+)",pid=(\d+)', line)
        if found:
            process = found.group(1)
            try:
                cmd = Path(f"/proc/{found.group(2)}/cmdline").read_bytes().split(b"\0")
                text = " ".join(c.decode("utf-8", "replace") for c in cmd if c)
                plugin = re.search(r"/plugins/([^/]+)/", text)
                dll = re.search(r"/([A-Za-z]+)\.dll", text)
                process = plugin.group(1) if plugin else (dll.group(1) if dll else process)
            except OSError:
                pass
        try:
            number = int(port)
        except ValueError:
            continue
        if not any(r["port"] == number for r in rows):
            rows.append({"port": number, "process": process})
    return {"ok": True, "ports": sorted(rows, key=lambda r: r["port"])}


def main(argv):
    if not argv:
        print(__doc__)
        return 2
    verb = argv[0]
    if os.geteuid() != 0 and not DRY:
        out({"ok": False, "error": "must run as root"})
        return 2
    try:
        if verb == "install" and len(argv) > 1:
            out(install(argv[1]))
        elif verb == "apply":
            out(apply())
        elif verb == "ensure":
            out(apply(only_drift=True))
        elif verb == "off":
            out(off())
        elif verb == "status":
            out({"ok": True, **status()})
        elif verb == "ports":
            out(ports())
        else:
            out({"ok": False, "error": f"unknown verb {verb}"})
            return 2
    except Exception as exc:
        out({"ok": False, "error": str(exc)})
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
