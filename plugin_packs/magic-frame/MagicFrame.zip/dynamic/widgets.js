/* Dynaframe's Magic Mirror - Widgets für die Felder der Skins.
 *
 * Ein Widget-Typ ist ein Name für das, was in einem Feld steht (time, weather,
 * headlines, nowplaying ...), mit festem Aufbau der Daten. Hier stehen die
 * Standard-Darstellungen, MagicFrame.registerWidget(typ, { render(el, data, ctx),
 * tick?(el, data, ctx) }). Ein Skin kann jeden Typ selbst zeichnen
 * (widgets: {...} in registerSkin), sonst gilt die Darstellung von hier, in den
 * Farben, die der Skin dem Feld gibt (--w-ink, --w-dim, --w-accent).
 *
 * Woher die Daten kommen: vom Skin selbst (Uhr, Datum, Wetter vom Ort) oder
 * von einem Modul, dessen Renderer sie mit widget(typ, ctx) liefert.
 * Aufbau der Daten je Typ (Felder in [] dürfen fehlen):
 *   time, analog, date, year, weekdays, wifi   keine Daten
 *   countdown       [{target: Epoch, name}] (sonst ctx.config.countdown "HH:MM")
 *   weather, sunrise, sunset, weatherpicture
 *                   {current: {temp, code, isDay}, sunrise, sunset, [max, min], imperial}
 *   forecast        {daily: [{day, code, max, min, [pop]}], imperial}
 *   picture         {url} (sonst das Bild unter "Hintergrund")
 *   headlines       {items: [{title, [source], [at]}]}
 *   list            {[title], items: [{title, [info], [badge], [icon]}], [empty]}
 *   values          {items: [{label, value, [icon]}]}
 *   text            {text, [icon]}
 *   nowplaying      {title, [artist], [cover], [progress 0..1], [playing]}
 */
(function () {
  "use strict";

  const MF = window.MagicFrame;
  const h = MF.helpers;
  const { esc, t } = h;

  const pad = (n) => String(n).padStart(2, "0");
  // Ohne Akzente und Punkte, für LCD-Schriften (A-Z)
  const plain = (text) => String(text).normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/\./g, "").toUpperCase();

  const DAYS = { de: ["MO", "DI", "MI", "DO", "FR", "SA", "SO"], en: ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"],
    es: ["LUN", "MAR", "MIE", "JUE", "VIE", "SAB", "DOM"] };
  const days = () => DAYS[h.lang()] || DAYS.de;
  const weekday = (d) => days()[(d.getDay() + 6) % 7];
  const month = (d) => plain(d.toLocaleDateString(h.locale(), { month: "short" })).slice(0, 3);
  // "24 OKT" oder auf Englisch "OCT 24"
  const shortDate = (d) => (h.lang() === "en" ? `${month(d)} ${pad(d.getDate())}` : `${pad(d.getDate())} ${month(d)}`);

  // Stunden und Minuten nach der Einstellung 24/12 Stunden
  function clockParts(d, clock24) {
    let hours = d.getHours();
    let ampm = "";
    if (!clock24) {
      ampm = hours < 12 ? "AM" : "PM";
      hours = hours % 12 || 12;
    }
    return { hm: `${pad(hours)}:${pad(d.getMinutes())}`, sec: pad(d.getSeconds()), ampm };
  }

  // Zeigeruhr als SVG, 100 x 100. Die Zeiger stellt setHands() jede Sekunde.
  function analogSvg(opts = {}) {
    const ticks = Array.from({ length: 12 }, (_, i) => {
      const a = (i * 30 * Math.PI) / 180;
      const r1 = i % 3 === 0 ? 40 : 41.5;
      const x1 = 50 + Math.sin(a) * r1, y1 = 50 - Math.cos(a) * r1;
      const x2 = 50 + Math.sin(a) * 45, y2 = 50 - Math.cos(a) * 45;
      return i % 3 === 0 ? "" : `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}"/>`;
    }).join("");
    const numbers = opts.numbers === false ? "" : [[12, 50, 15], [3, 86, 50], [6, 50, 86], [9, 14, 50]]
      .map(([n, x, y]) => `<text x="${x}" y="${y}">${n}</text>`).join("");
    return `<svg class="analog" viewBox="0 0 100 100" aria-hidden="true">
      ${opts.face ? `<circle cx="50" cy="50" r="47" class="face"/>` : ""}
      <g class="ticks">${ticks}</g><g class="nums">${numbers}</g>
      <line class="hand hour" x1="50" y1="54" x2="50" y2="28"/>
      <line class="hand min" x1="50" y1="56" x2="50" y2="15"/>
      ${opts.seconds ? `<line class="hand sec" x1="50" y1="58" x2="50" y2="12"/>` : ""}
      <circle cx="50" cy="50" r="2.4" class="pin"/></svg>`;
  }

  function setHands(svg, d) {
    if (!svg) return;
    const s = d.getSeconds(), m = d.getMinutes() + s / 60, hr = (d.getHours() % 12) + m / 60;
    const turn = (sel, deg) => { const n = svg.querySelector(sel); if (n) n.setAttribute("transform", `rotate(${deg.toFixed(2)} 50 50)`); };
    turn(".hour", hr * 30);
    turn(".min", m * 6);
    turn(".sec", s * 6);
  }

  // Nächster Zeitpunkt HH:MM ab jetzt (heute oder morgen)
  function nextTime(text) {
    const m = String(text || "").trim().match(/^(\d{1,2})[:.](\d{2})$/);
    if (!m || Number(m[1]) > 23 || Number(m[2]) > 59) return null;
    const d = new Date();
    d.setHours(Number(m[1]), Number(m[2]), 0, 0);
    if (d.getTime() <= Date.now()) d.setDate(d.getDate() + 1);
    return d;
  }

  function countdownTarget(data, ctx) {
    if (data && data.target) return new Date(data.target * 1000);
    return nextTime(ctx.config?.countdown);
  }

  // Sekunden zeigen: beim Modul "Uhr" nach dessen Einstellung, sonst nach dem Skin
  const withSeconds = (ctx) => (ctx.moduleConfig ? !!ctx.moduleConfig.seconds : ctx.config?.seconds === true);

  // Wetter als kleines Pixelbild: Himmel nach Tageszeit, Sonne oder Mond,
  // Wolken, Regen oder Schnee, Meer und eine Wiese mit Blumen. 64 x 48 Pixel.
  function weatherScene(wx) {
    const now = h.nowSec();
    const cur = wx?.current || { code: 1, isDay: true };
    const rise = wx?.sunrise || 0, set = wx?.sunset || 0;
    const dusk = rise && set && (Math.abs(now - set) < 2700 || Math.abs(now - rise) < 2700);
    const day = cur.isDay !== false;
    const code = Number(cur.code) || 0;
    const skies = dusk ? ["#3b3f8f", "#6a4c9c", "#b85c8a", "#e8735c", "#f4a259", "#f7c873"]
      : !day ? ["#0b1030", "#111a44", "#17245a", "#1d2f6e", "#253a80", "#2e468f"]
      : code >= 51 || code === 3 || code === 45 || code === 48 ? ["#7d8a99", "#8695a3", "#909fad", "#9aa9b6", "#a5b3bf", "#b0bdc8"]
      : ["#2f7fd8", "#3f8fe0", "#55a0e6", "#6cb1ec", "#86c2f1", "#a2d3f5"];
    const r = (x, y, w, hh, c) => `<rect x="${x}" y="${y}" width="${w}" height="${hh}" fill="${c}"/>`;
    let svg = skies.map((c, i) => r(0, i * 5, 64, 5, c)).join("");
    if (!day && !dusk) {
      [[6, 3], [15, 8], [27, 4], [40, 9], [52, 3], [58, 12], [21, 14], [47, 16]].forEach(([x, y]) => { svg += r(x, y, 1, 1, "#fff8d0"); });
    }
    // Sonne oder Mond: aus Rechtecken, damit es nach Pixeln aussieht
    const bx = day ? 38 : 42, by = dusk ? 19 : 6;
    const disc = [[2, 0, 4], [1, 1, 6], [0, 2, 8], [0, 3, 8], [0, 4, 8], [0, 5, 8], [1, 6, 6], [2, 7, 4]];
    const sunColor = dusk ? "#ffd27a" : day ? "#ffe066" : "#f4f1d8";
    if (code < 3 || dusk) {
      svg += disc.map(([dx, dy, w]) => r(bx + dx, by + dy, w, 1, sunColor)).join("");
      if (!day && !dusk) svg += disc.slice(1, 7).map(([dx, dy, w]) => r(bx + dx + 3, by + dy - 1, Math.max(1, w - 3), 1, skies[1])).join("");
    }
    const cloud = (x, y, c) => r(x + 3, y, 8, 1, c) + r(x + 1, y + 1, 13, 2, c) + r(x, y + 3, 17, 2, c);
    const cloudColor = code >= 61 || code >= 95 ? "#cfd6de" : "#ffffff";
    if (code >= 1) svg += cloud(8, 7, cloudColor);
    if (code >= 2) svg += cloud(30, 11, cloudColor);
    if (code >= 3) svg += cloud(46, 5, cloudColor) + cloud(20, 2, cloudColor);
    if (code === 45 || code === 48) svg += r(0, 20, 64, 2, "#dfe5ea") + r(0, 24, 64, 1, "#dfe5ea");
    const snow = (code >= 71 && code <= 77) || code === 85 || code === 86;
    if (code >= 51 && !snow) for (let i = 0; i < 18; i++) svg += r((i * 11 + 3) % 62, 13 + ((i * 7) % 14), 1, 2, "#bfe3ff");
    if (snow) for (let i = 0; i < 22; i++) svg += r((i * 13 + 5) % 62, 12 + ((i * 5) % 16), 1, 1, "#ffffff");
    if (code >= 95) svg += r(26, 13, 2, 3, "#ffe066") + r(25, 16, 2, 2, "#ffe066") + r(24, 18, 2, 3, "#ffe066");
    // Meer mit Wellen
    const sea = day ? ["#1d6fb8", "#2a82c9", "#1d6fb8"] : ["#0c2550", "#12306a", "#0c2550"];
    svg += r(0, 30, 64, 9, sea[0]);
    for (let i = 0; i < 8; i++) svg += r((i * 9 + 2) % 60, 31 + (i % 3) * 3, 4, 1, sea[1] === "#2a82c9" ? "#7fc3ef" : "#2f5aa0");
    // Wiese mit Blumen
    svg += r(0, 39, 64, 9, day ? "#4caf50" : "#1f5a2a") + r(0, 39, 64, 1, day ? "#7bd17e" : "#2f7a3a");
    [[5, "#ff6b9a"], [13, "#ffe066"], [22, "#ffffff"], [34, "#ff6b9a"], [43, "#ffe066"], [51, "#c38dff"], [59, "#ffffff"]].forEach(([x, c], i) => {
      const y = 42 + (i % 3);
      svg += r(x, y + 1, 1, 3, day ? "#2e7d32" : "#174a20") + r(x - 1, y, 3, 1, c) + r(x, y - 1, 1, 3, c);
    });
    return `<svg class="pixel-scene" viewBox="0 0 64 48" preserveAspectRatio="xMidYMid slice" shape-rendering="crispEdges">${svg}</svg>`;
  }

  // Kein Wetter (noch nicht geholt oder kein Ort): kurzer Hinweis statt leerem Feld
  const waiting = (ctx) => `<div class="w w-wait">${esc(ctx.error ? "–" : "…")}</div>`;

  // So viele Zeilen, wie in das Feld lesbar hineinpassen (mindestens etwa 4,5 % der kürzeren Bildschirmseite je Zeile)
  const fitRows = (el, want, extra = 0) => Math.max(1, Math.min(want, Math.floor(el.clientHeight / (Math.min(innerWidth, innerHeight) * 0.045)) - extra));

  const W = {};

  W.time = {
    render(el, data, ctx) {
      el.innerHTML = `<div class="w w-time"><span class="hm"></span><span class="ss"></span><span class="ap"></span></div>`;
      this.tick(el, data, ctx);
    },
    tick(el, data, ctx) {
      const p = clockParts(new Date(), ctx.clock24);
      const set = (sel, text) => { const n = el.querySelector(sel); if (n && n.textContent !== text) n.textContent = text; };
      set(".hm", p.hm);
      set(".ss", withSeconds(ctx) ? p.sec : "");
      set(".ap", p.ampm);
    },
  };

  W.analog = {
    render(el, data, ctx) {
      el.innerHTML = `<div class="w w-analog">${analogSvg({ seconds: withSeconds(ctx), face: true })}</div>`;
      this.tick(el, data, ctx);
    },
    tick(el) { setHands(el.querySelector("svg"), new Date()); },
  };

  W.date = {
    render(el, data, ctx) { el.innerHTML = `<div class="w w-date"><b></b><span></span><small></small></div>`; this.tick(el, data, ctx); },
    tick(el) {
      const d = new Date();
      const day = String(d.getDate());
      if (el.querySelector("b").textContent === day) return;
      el.querySelector("b").textContent = day;
      el.querySelector("span").textContent = d.toLocaleDateString(h.locale(), { month: "long" });
      el.querySelector("small").textContent = d.toLocaleDateString(h.locale(), { weekday: "long" });
    },
  };

  W.year = {
    render(el, data, ctx) { el.innerHTML = `<div class="w w-year"><b></b><small></small></div>`; this.tick(el, data, ctx); },
    tick(el) {
      const d = new Date();
      el.querySelector("b").textContent = String(d.getFullYear());
      el.querySelector("small").textContent = d.toLocaleDateString(h.locale(), { weekday: "long" });
    },
  };

  W.weekdays = {
    render(el, data, ctx) {
      el.innerHTML = `<div class="w w-weekdays">${days().map((d, i) => `<span data-i="${i}">${esc(d)}</span>`).join("")}</div>`;
      this.tick(el, data, ctx);
    },
    tick(el) {
      const today = (new Date().getDay() + 6) % 7;
      el.querySelectorAll("[data-i]").forEach((n) => n.classList.toggle("on", Number(n.dataset.i) === today));
    },
  };

  W.countdown = {
    render(el, data, ctx) {
      const name = data?.name || ctx.config?.countdownLabel || t({ de: "Noch", en: "Left", es: "Faltan" });
      el.innerHTML = `<div class="w w-countdown"><small>${esc(name)}</small><b></b></div>`;
      this.tick(el, data, ctx);
    },
    tick(el, data, ctx) {
      const target = countdownTarget(data, ctx);
      const left = target ? Math.max(0, Math.floor((target - Date.now()) / 1000)) : null;
      const text = left == null ? "--:--:--" : `${pad(Math.floor(left / 3600))}:${pad(Math.floor(left / 60) % 60)}:${pad(left % 60)}`;
      const b = el.querySelector("b");
      if (b.textContent !== text) b.textContent = text;
    },
  };

  W.weather = {
    render(el, data, ctx) {
      const c = data?.current;
      if (!c) { el.innerHTML = waiting(ctx); return; }
      el.innerHTML = `<div class="w w-weather">${h.weatherIcon(c.code, c.isDay)}<b>${esc(h.degrees(c.temp, data.imperial))}</b>
        <small>${esc(h.weatherText(c.code))}</small></div>`;
      ctx.caption(h.weatherText(c.code));
    },
  };

  const sunWidget = (key, iconName) => ({
    render(el, data, ctx) {
      el.innerHTML = `<div class="w w-sun">${h.icon(iconName)}<b>${esc(data?.[key] ? h.time(data[key]) : "--:--")}</b></div>`;
    },
  });
  W.sunrise = sunWidget("sunrise", "sunrise");
  W.sunset = sunWidget("sunset", "sunset");

  W.weatherpicture = {
    render(el, data) { el.innerHTML = `<div class="w w-picture">${weatherScene(data)}</div>`; el._drawn = Date.now(); },
    tick(el, data) {
      // Tageszeit und Himmel ändern sich: alle 10 Minuten neu zeichnen
      if (Date.now() - (el._drawn || 0) > 600000) this.render(el, data);
    },
  };

  W.picture = {
    render(el, data, ctx) {
      const url = data?.url || ctx.image;
      el.innerHTML = url ? `<div class="w w-picture"><div class="photo" style="background-image:url('${esc(url).replace(/'/g, "%27")}')"></div></div>`
        : `<div class="w w-wait"><small>${esc(t({ de: "Kein Bild unter „Hintergrund“", en: "No image under “Background”", es: "No hay imagen en «Fondo»" }))}</small></div>`;
    },
  };

  W.wifi = {
    render(el) {
      el.innerHTML = `<div class="w w-icon"><svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"
        aria-hidden="true"><path d="M2.5 9a14 14 0 0 1 19 0M5.5 12.5a9.5 9.5 0 0 1 13 0M8.7 16a5 5 0 0 1 6.6 0"/><circle cx="12" cy="19.2" r="1.2"/></svg></div>`;
    },
  };

  W.forecast = {
    render(el, data, ctx) {
      const daily = (data?.daily || []).slice(0, fitRows(el, 5));
      if (!daily.length) { el.innerHTML = waiting(ctx); return; }
      el.innerHTML = `<div class="w w-rows" style="--n:${daily.length}">${daily.map((d) => `<div class="row">
        <span class="lbl">${esc(h.dayName(d.day + 43200))}</span>${h.weatherIcon(d.code, true)}
        <b>${esc(h.degrees(d.max, data.imperial))}</b><span class="dim">${esc(h.degrees(d.min, data.imperial))}</span></div>`).join("")}</div>`;
    },
  };

  W.headlines = {
    render(el, data, ctx) {
      el._items = (data?.items || []).filter((i) => i.title);
      if (!el._items.length) { el.innerHTML = waiting(ctx); return; }
      el.innerHTML = `<div class="w w-headline"><small></small><span></span></div>`;
      el._i = -1;
      el._next = 0;
      this.tick(el, data, ctx);
    },
    tick(el, data, ctx) {
      if (!el._items?.length || Date.now() < el._next) return;
      el._i = (el._i + 1) % el._items.length;
      el._next = Date.now() + (ctx.moduleConfig?.seconds || 15) * 1000;
      const item = el._items[el._i];
      el.querySelector("small").textContent = [item.source, item.at ? h.time(item.at) : ""].filter(Boolean).join(" · ");
      el.querySelector("span").textContent = item.title;
    },
  };

  W.list = {
    render(el, data, ctx) {
      if (!data) { el.innerHTML = waiting(ctx); return; }
      const items = (data.items || []).slice(0, fitRows(el, 6, data.title ? 1 : 0));
      if (!items.length) { el.innerHTML = `<div class="w w-wait"><small>${esc(data.empty || "–")}</small></div>`; return; }
      el.innerHTML = `<div class="w w-rows" style="--n:${items.length + (data.title ? 1 : 0)}">
        ${data.title ? `<div class="row head">${esc(data.title)}</div>` : ""}
        ${items.map((i) => `<div class="row">${i.badge ? `<span class="badge">${esc(i.badge)}</span>` : i.icon ? h.icon(i.icon) : ""}
          <span class="lbl">${esc(i.title)}</span><span class="dim">${esc(i.info || "")}</span></div>`).join("")}</div>`;
    },
  };

  W.values = {
    render(el, data, ctx) {
      const items = (data?.items || []).slice(0, fitRows(el, 6));
      if (!items.length) { el.innerHTML = waiting(ctx); return; }
      if (items.length === 1) {
        const i = items[0];
        el.innerHTML = `<div class="w w-weather">${i.icon ? h.icon(i.icon) : ""}<b>${esc(i.value)}</b><small>${esc(i.label)}</small></div>`;
        return;
      }
      el.innerHTML = `<div class="w w-rows" style="--n:${items.length}">${items.map((i) => `<div class="row">
        ${i.icon ? h.icon(i.icon) : ""}<span class="lbl">${esc(i.label)}</span><b>${esc(i.value)}</b></div>`).join("")}</div>`;
    },
  };

  W.text = {
    render(el, data, ctx) {
      if (!data?.text) { el.innerHTML = waiting(ctx); return; }
      const long = String(data.text).length > 60;
      el.innerHTML = `<div class="w w-text ${long ? "long" : ""}">${data.icon ? h.icon(data.icon) : ""}<span>${esc(data.text)}</span></div>`;
    },
  };

  W.nowplaying = {
    render(el, data, ctx) {
      if (!data?.title) {
        el.innerHTML = `<div class="w w-wait">${h.icon("music")}<small>${esc(t({ de: "Gerade nichts", en: "Nothing playing", es: "Nada sonando" }))}</small></div>`;
        return;
      }
      const progress = Number.isFinite(data.progress) ? `<i class="bar"><i style="width:${Math.round(Math.max(0, Math.min(1, data.progress)) * 100)}%"></i></i>` : "";
      el.innerHTML = `<div class="w w-playing">${data.cover ? `<div class="cover" style="background-image:url('${esc(data.cover).replace(/'/g, "%27")}')"></div>` : ""}
        <div class="txt"><b>${esc(data.title)}</b>${data.artist ? `<span>${esc(data.artist)}</span>` : ""}${progress}</div></div>`;
    },
  };

  window.MagicFrame.widgetDefaults = W;
  Object.entries(W).forEach(([type, renderer]) => MF.registerWidget(type, renderer));
  // Für Skins und Zusatz-Skins
  Object.assign(MF.helpers, { analogSvg, setHands, clockParts, nextTime, weatherScene, days, weekday, month, shortDate, pad, plain });
})();
