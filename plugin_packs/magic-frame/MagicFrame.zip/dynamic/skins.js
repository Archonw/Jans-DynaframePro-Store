/* Dynaframe's Magic Mirror - die eingebauten Skins.
 *
 * Ein Skin zeichnet das Gerüst der ganzen Szene: Felder mit data-slot="id"
 * (und Beschriftungen mit data-caption="id"). Was in welchem Feld steht,
 * wählt man auf der Plugin-Seite; der Kern (core.js) füllt die Felder mit
 * Widgets (widgets.js). Ein Skin kann Widget-Typen in seinem eigenen Stil
 * zeichnen: widgets: { typ: { render(el, data, ctx), tick? } }.
 *
 * MagicFrame.registerSkin(typ, { render(root, ctx), tick?(root, ctx), widgets? }),
 * genau wie ein Zusatz-Skin in seiner module.js. Die Felder und was hineinpasst
 * stehen im Plugin (modules.py, SKINS) bzw. in der module.json eines Zusatz-Skins.
 */
(function () {
  "use strict";

  const MF = window.MagicFrame;
  const h = MF.helpers;
  const { esc, t } = h;

  // ================================================================ Retro-LCD

  // Ein LCD-Feld: die nicht leuchtenden Segmente schwach dahinter
  const lcd = (text, cls = "") => {
    const lit = String(text).replace(/ /g, "!");
    const ghost = String(text).replace(/[0-9]/g, "8").replace(/[^:.8 ]/g, "~").replace(/ /g, "!");
    return `<span class="seg ${cls}"><span class="ghost">${esc(ghost)}</span><span class="lit">${esc(lit)}</span></span>`;
  };
  const setHtml = (el, sel, html) => {
    const n = el.querySelector(sel);
    if (n && n.dataset.v !== html) { n.dataset.v = html; n.innerHTML = html; }
  };
  const withSeconds = (ctx) => (ctx.moduleConfig ? !!ctx.moduleConfig.seconds : ctx.config?.seconds !== false);
  const pad = (n) => String(n).padStart(2, "0");

  // Was das LCD in seinen Ziffern zeigt, egal in welchem Feld
  const LCD_WIDGETS = {
    time: {
      render(el, data, ctx) {
        el.innerHTML = `<div class="w lcd-time"><span class="ampm"></span><span class="hm"></span><span class="sec"></span></div>`;
        this.tick(el, data, ctx);
      },
      tick(el, data, ctx) {
        const p = h.clockParts(new Date(), ctx.clock24);
        setHtml(el, ".hm", lcd(p.hm));
        setHtml(el, ".sec", withSeconds(ctx) ? lcd(p.sec) : "");
        setHtml(el, ".ampm", p.ampm ? lcd(p.ampm) : "");
      },
    },
    year: {
      render(el, data, ctx) { el.innerHTML = `<div class="w lcd-line"></div>`; this.tick(el, data, ctx); },
      tick(el) { const d = new Date(); setHtml(el, ".lcd-line", lcd(`${d.getFullYear()} ${h.weekday(d)}`)); },
    },
    date: {
      render(el, data, ctx) { el.innerHTML = `<div class="w lcd-line"></div>`; this.tick(el, data, ctx); },
      tick(el) { setHtml(el, ".lcd-line", lcd(h.shortDate(new Date()))); },
    },
    weekdays: {
      render(el, data, ctx) {
        el.innerHTML = `<div class="w lcd-days">${h.days().map((d, i) => `<span class="day" data-i="${i}">${lcd(d)}</span>`).join("")}</div>`;
        this.tick(el, data, ctx);
      },
      tick(el) {
        const today = (new Date().getDay() + 6) % 7;
        el.querySelectorAll(".day").forEach((n) => n.classList.toggle("on", Number(n.dataset.i) === today));
      },
    },
    countdown: {
      render(el, data, ctx) {
        const name = data?.name || ctx.config?.countdownLabel || t({ de: "Noch", en: "Left", es: "Faltan" });
        el.innerHTML = `<div class="w lcd-cd"><small>${esc(name)}</small><span class="cdrow"><span class="mini" data-cd="h"></span>
          <span class="mini" data-cd="m"></span><span class="mini" data-cd="s"></span></span></div>`;
        this.tick(el, data, ctx);
      },
      tick(el, data, ctx) {
        const target = data?.target ? new Date(data.target * 1000) : h.nextTime(ctx.config?.countdown);
        const left = target ? Math.max(0, Math.floor((target - Date.now()) / 1000)) : null;
        setHtml(el, '[data-cd="h"]', lcd(left == null ? "--" : pad(Math.floor(left / 3600))));
        setHtml(el, '[data-cd="m"]', lcd(left == null ? "--" : pad(Math.floor(left / 60) % 60)));
        setHtml(el, '[data-cd="s"]', lcd(left == null ? "--" : pad(left % 60)));
      },
    },
  };

  // Felder: dunkle LCD-Flächen (panel) und helle Tasten (tile), jeweils mit Beschriftung darunter
  const block = (id, kind) => `<figure class="block b-${id}"><div class="${kind}" data-slot="${id}"></div><figcaption data-caption="${id}"></figcaption></figure>`;

  MF.registerSkin("lcd", {
    render(root, ctx) {
      const cfg = ctx.config || {};
      root.innerHTML = `<div class="lcd tint-${esc(cfg.tint || "mint")}">
        <div class="panel strip b-days" data-slot="days"></div>
        ${block("time", "panel")}${block("year", "panel")}${block("date", "panel")}
        ${block("clock", "tile")}${block("rise", "tile")}${block("set", "tile")}
        ${block("cd", "tile")}${block("wx", "tile")}${block("net", "tile")}
      </div>`;
    },
    widgets: LCD_WIDGETS,
  });

  // ================================================================ Farbraster

  MF.registerSkin("mosaic", {
    render(root, ctx) {
      const cfg = ctx.config || {};
      root.innerHTML = `<div class="mosaic pal-${esc(cfg.palette || "classic")}">
        <div class="cell a"></div><div class="cell b"></div><div class="cell g"></div><div class="cell d"></div>
        <div class="cell e"></div><div class="cell f"></div>
        <div class="cell s-date" data-slot="date"></div>
        <div class="cell s-clock" data-slot="clock"></div>
        <div class="cell s-wx"><div class="inner" data-slot="wx"></div></div>
        <div class="cell s-time" data-slot="time"></div>
        <div class="cell s-pic"><div class="inner" data-slot="pic"></div></div>
      </div>`;
    },
    widgets: {
      // Datum kurz und fett wie "24 OKT"
      date: {
        render(el, data, ctx) { el.innerHTML = `<div class="w mosaic-date"></div>`; this.tick(el, data, ctx); },
        tick(el) {
          const text = h.shortDate(new Date());
          const n = el.querySelector(".mosaic-date");
          if (n.textContent !== text) n.textContent = text;
        },
      },
    },
  });
})();
