"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt nur die übergebenen Platzhalter; fehlt eine
Übersetzung, bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Auf dem Rahmen fehlt Pillow; installiere das Paket noch einmal.": (
        "Pillow is missing on the frame; install the pack again.",
        "Falta Pillow en el marco; vuelve a instalar el paquete."),
    "Auf dem Rahmen ist kein Platz mehr frei.": (
        "There is no space left on the frame.", "No queda espacio libre en el marco."),
    "Das Foto ist zu groß (höchstens {mb} MB).": (
        "The photo is too large (at most {mb} MB).", "La foto es demasiado grande (como máximo {mb} MB)."),
    "Das ist kein Foto, das der Rahmen lesen kann.": (
        "That is not a photo the frame can read.", "Eso no es una foto que el marco pueda leer."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.", "El marco no ha creado la lista {name}."),
    "Der Rahmen hat die Wand nicht rechtzeitig gezeigt.": (
        "The frame did not show the wall in time.", "El marco no ha mostrado el muro a tiempo."),
    "Die Fotowand für deine Party: Gäste laden Fotos hoch und reagieren mit Emojis.": (
        "The photo wall for your party: guests upload photos and react with emojis.",
        "El muro de fotos para tu fiesta: los invitados suben fotos y reaccionan con emojis."),
    "Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The scene is not installed on this frame. Install the pack again.",
        "La escena no está instalada en este marco. Vuelve a instalar el paquete."),
    "Die Wand ist voll ({n} Fotos).": ("The wall is full ({n} photos).", "El muro está lleno ({n} fotos)."),
    "Die laufende Party kann man nicht löschen.": (
        "The current party cannot be deleted.", "La fiesta actual no se puede borrar."),
    "Es kam kein Foto an.": ("No photo arrived.", "No ha llegado ninguna foto."),
    "Etwas anderes hat gerade den Bildschirm.": (
        "Something else has the screen right now.", "Otra cosa está usando la pantalla ahora."),
    "Gast {n}": ("Guest {n}", "Invitado {n}"),
    "HEIC-Fotos kann der Rahmen nicht lesen. Stell am iPhone unter Kamera › Formate „Maximale Kompatibilität“ ein.": (
        "The frame cannot read HEIC photos. On the iPhone, set Camera › Formats to “Most Compatible”.",
        "El marco no puede leer fotos HEIC. En el iPhone, elige Cámara › Formatos «Más compatible»."),
    "Hochladen ist gerade ausgeschaltet.": (
        "Uploading is switched off right now.", "La subida de fotos está desactivada ahora."),
    "Konnte das Foto nicht lesen: {exc}": ("Could not read the photo: {exc}", "No se ha podido leer la foto: {exc}"),
    "Konnte die Takeover-Playlist nicht anlegen: {exc}": (
        "Could not create the takeover playlist: {exc}", "No se ha podido crear la lista de toma de pantalla: {exc}"),
    "Konnte die Wand nicht zeigen: {exc}": ("Could not show the wall: {exc}", "No se ha podido mostrar el muro: {exc}"),
    "Langsam! Höchstens {n} Fotos pro Minute.": (
        "Slow down! At most {n} photos per minute.", "¡Más despacio! Como máximo {n} fotos por minuto."),
    "Videos gehen hier nicht, nur Fotos.": ("Videos do not work here, only photos.", "Aquí no van vídeos, solo fotos."),
    "„Allow takeover“ ist für Party Wall auf der Plugins-Seite aus. Schalte es ein, sonst kann die Wand nicht von hier aus auf den Fernseher.": (
        "“Allow takeover” is off for Party Wall on the Plugins page. Switch it on, otherwise the wall cannot be sent to the TV from here.",
        "«Allow takeover» está desactivado para Party Wall en la página de plugins. Actívalo; si no, el muro no puede ir a la tele desde aquí."),
}


def t(language, template, **values):
    text = template
    if language in ("en", "es"):
        row = _TEXTS.get(template)
        if row:
            text = row[0 if language == "en" else 1]
    for name, value in values.items():
        text = text.replace("{" + name + "}", str(value))
    return text
