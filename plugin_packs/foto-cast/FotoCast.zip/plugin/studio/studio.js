"use strict";

// Immer "./...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/PhonePhotos/ aus, die Handy-Seite unter :8095/.

const el = (id) => document.getElementById(id);
const PHONE = document.documentElement.hasAttribute("data-phone");
const MAX_EDGE = 3840;
let current = null;
let editing = false;
let recentKey = "";
let lang = "de";

// Texte der Seite auf Deutsch, Englisch und Spanisch. Die Sprache ist eine
// Einstellung des Plugins und gilt auch für die Szene.
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Zeig das Foto, das du gerade auf dem Handy anschaust, sofort auf dem Rahmen: aus dem Teilen-Menü oder über die Handy-Seite. Nach ein paar Minuten läuft deine Playlist weiter. Jede Änderung hier wird sofort gespeichert.",
    "Show the photo you are looking at on your phone on the frame right away: from the share menu or the phone page. After a few minutes your playlist carries on. Every change here is saved immediately.",
    "Muestra en el marco la foto que estás viendo en el móvil al instante: desde el menú compartir o la página del móvil. Después de unos minutos tu lista sigue. Cada cambio aquí se guarda al instante."],
  phoneLede: ["Foto wählen, und es erscheint auf dem Rahmen.", "Pick a photo and it appears on the frame.",
    "Elige una foto y aparece en el marco."],
  language: ["Sprache", "Language", "Idioma"],
  pinTitle: ["Code für diesen Rahmen", "Code for this frame", "Código de este marco"],
  pinHint: ["Auf diesem Rahmen dürfen nur Handys mit dem Code Fotos schicken. Du findest ihn auf der Plugin-Seite am Rahmen.",
    "Only phones with the code may send photos to this frame. You find it on the plugin page of the frame.",
    "Solo los móviles con el código pueden enviar fotos a este marco. Lo encuentras en la página del plugin del marco."],
  pinWrong: ["Der Code stimmt nicht.", "The code is not right.", "El código no es correcto."],
  ok: ["OK", "OK", "OK"],
  sendTitle: ["Foto senden", "Send a photo", "Enviar una foto"],
  hide: ["Ausblenden", "Hide", "Ocultar"],
  pick: ["Fotos auswählen", "Choose photos", "Elegir fotos"],
  pickFrame: ["Fotos auswählen oder hierher ziehen", "Choose photos or drop them here", "Elige fotos o arrástralas aquí"],
  senderName: ["Dein Name (erscheint klein unter dem Foto, optional)", "Your name (shown small below the photo, optional)",
    "Tu nombre (aparece pequeño bajo la foto, opcional)"],
  preparing: ["Bereite Foto {n} von {total} vor …", "Preparing photo {n} of {total} …", "Preparando foto {n} de {total} …"],
  sending: ["Sende Foto {n} von {total} …", "Sending photo {n} of {total} …", "Enviando foto {n} de {total} …"],
  sentOne: ["Auf dem Rahmen.", "On the frame.", "En el marco."],
  sentMany: ["{n} Fotos auf dem Rahmen.", "{n} photos on the frame.", "{n} fotos en el marco."],
  failed: ["Nicht gesendet: {error}", "Not sent: {error}", "No enviado: {error}"],
  noConnection: ["Der Rahmen antwortet nicht. Bist du im WLAN zu Hause?", "The frame is not responding. Are you on your home Wi-Fi?",
    "El marco no responde. ¿Estás en la wifi de casa?"],
  nowShowing: ["Gerade auf dem Rahmen, noch {time}.", "On the frame now, {time} left.", "Ahora en el marco, quedan {time}."],
  waiting: ["Wartet auf den Bildschirm …", "Waiting for the screen …", "Esperando la pantalla …"],
  recentTitle: ["Zuletzt gesendet", "Recently sent", "Enviadas recientemente"],
  recentHint: ["Antippen zeigt es noch einmal.", "Tap to show it again.", "Pulsa para mostrarla otra vez."],
  recentEmpty: ["Noch keine Fotos.", "No photos yet.", "Aún no hay fotos."],
  deleteAsk: ["Dieses Foto vom Rahmen löschen?", "Delete this photo from the frame?", "¿Borrar esta foto del marco?"],
  pageTitle: ["Die Handy-Seite (iPhone und Android)", "The phone page (iPhone and Android)", "La página del móvil (iPhone y Android)"],
  pageHint: ["Im WLAN mit der Kamera des Handys den QR-Code scannen, dann über das Teilen-Menü des Browsers „Zum Home-Bildschirm“ wählen. Ab dann: Symbol antippen, Fotos wählen, fertig.",
    "On your Wi-Fi scan the QR code with the phone's camera, then choose “Add to Home Screen” in the browser's share menu. From then on: tap the icon, choose photos, done.",
    "En la wifi escanea el código QR con la cámara del móvil y elige «Añadir a pantalla de inicio» en el menú compartir del navegador. A partir de ahí: toca el icono, elige fotos y listo."],
  pageNote: ["Funktioniert nur im WLAN zu Hause. Steht hier keine Adresse, ist Port 8095 auf dem Rahmen belegt.",
    "Works only on your home Wi-Fi. If there is no address here, port 8095 is taken on the frame.",
    "Solo funciona en la wifi de casa. Si aquí no hay dirección, el puerto 8095 está ocupado en el marco."],
  iosTitle: ["iPhone: „Auf DynaFrame“ im Teilen-Menü der Fotos-App", "iPhone: “On DynaFrame” in the share menu of the Photos app",
    "iPhone: «En DynaFrame» en el menú compartir de Fotos"],
  iosIntro: ["Einmal einen Kurzbefehl anlegen (App „Kurzbefehle“, ist auf jedem iPhone):",
    "Create a shortcut once (the Shortcuts app is on every iPhone):",
    "Crea un atajo una vez (la app Atajos está en todos los iPhone):"],
  iosSteps: [[
    "App <b>Kurzbefehle</b> öffnen, oben rechts auf <b>+</b> tippen und oben den Namen <b>Auf DynaFrame</b> eingeben.",
    "Unten auf <b>ⓘ</b> tippen, <b>Im Share-Sheet anzeigen</b> einschalten, <b>Fertig</b>. Oben in „Empfange … aus Share-Sheet“ auf die Eingabearten tippen und nur <b>Bilder</b> angehakt lassen.",
    "Aktion <b>Wiederholen mit jedem Objekt</b> hinzufügen (in der Suche „Wiederholen“). Sie arbeitet mit der <b>Kurzbefehleingabe</b>.",
    "In die Wiederholung die Aktion <b>Bild konvertieren</b> ziehen: <b>Wiederholungsobjekt</b> in <b>JPEG</b>.",
    "Darunter, noch in der Wiederholung, die Aktion <b>Inhalte von URL abrufen</b> mit dieser URL: <code>{url}</code>",
    "Dort auf den Pfeil <b>›</b> tippen: Methode <b>POST</b>, Haupttext anfordern <b>Datei</b>, als Datei <b>Konvertiertes Bild</b> wählen.",
    "Fertig. Ab jetzt: Foto in der Fotos-App öffnen, <b>Teilen</b>, unten <b>Auf DynaFrame</b>."
  ], [
    "Open the <b>Shortcuts</b> app, tap <b>+</b> at the top right and enter the name <b>On DynaFrame</b> at the top.",
    "Tap <b>ⓘ</b> at the bottom, switch on <b>Show in Share Sheet</b>, <b>Done</b>. At the top in “Receive … from Share Sheet” tap the input types and leave only <b>Images</b> ticked.",
    "Add the action <b>Repeat with Each</b> (search for “Repeat”). It works on the <b>Shortcut Input</b>.",
    "Drag the action <b>Convert Image</b> into the repeat: <b>Repeat Item</b> to <b>JPEG</b>.",
    "Below it, still inside the repeat, add <b>Get Contents of URL</b> with this URL: <code>{url}</code>",
    "Tap its arrow <b>›</b>: method <b>POST</b>, request body <b>File</b>, and choose <b>Converted Image</b> as the file.",
    "Done. From now on: open a photo in Photos, tap <b>Share</b>, then <b>On DynaFrame</b> at the bottom."
  ], [
    "Abre la app <b>Atajos</b>, pulsa <b>+</b> arriba a la derecha y escribe arriba el nombre <b>En DynaFrame</b>.",
    "Pulsa <b>ⓘ</b> abajo, activa <b>Mostrar en hoja para compartir</b>, <b>OK</b>. Arriba en «Recibir … de la hoja para compartir» pulsa los tipos de entrada y deja marcadas solo <b>Imágenes</b>.",
    "Añade la acción <b>Repetir con cada</b> (busca «Repetir»). Trabaja con la <b>Entrada del atajo</b>.",
    "Arrastra dentro de la repetición la acción <b>Convertir imagen</b>: <b>Elemento repetido</b> a <b>JPEG</b>.",
    "Debajo, aún dentro de la repetición, añade <b>Obtener contenido de URL</b> con esta URL: <code>{url}</code>",
    "Pulsa su flecha <b>›</b>: método <b>POST</b>, cuerpo de la solicitud <b>Archivo</b> y elige <b>Imagen convertida</b> como archivo.",
    "Listo. A partir de ahora: abre una foto en Fotos, pulsa <b>Compartir</b> y abajo <b>En DynaFrame</b>."
  ]],
  iosNote: ["Beim ersten Mal fragt das iPhone, ob der Kurzbefehl den Rahmen erreichen darf: „Immer erlauben“. Mehrere Fotos auf einmal gehen auch.",
    "The first time, the iPhone asks whether the shortcut may reach the frame: “Always Allow”. Several photos at once work too.",
    "La primera vez el iPhone pregunta si el atajo puede acceder al marco: «Permitir siempre». También funcionan varias fotos a la vez."],
  androidTitle: ["Android: im Teilen-Menü der Galerie", "Android: in the gallery's share menu", "Android: en el menú compartir de la galería"],
  androidIntro: ["Android-Browser können sich nicht ins Teilen-Menü eintragen. Dafür gibt es die kostenlose App „HTTP Shortcuts“ (Google Play oder F-Droid):",
    "Android browsers cannot add themselves to the share menu. The free app “HTTP Shortcuts” (Google Play or F-Droid) does it:",
    "Los navegadores de Android no pueden añadirse al menú compartir. Lo hace la app gratuita «HTTP Shortcuts» (Google Play o F-Droid):"],
  androidSteps: [[
    "<b>HTTP Shortcuts</b> installieren und öffnen, auf <b>+</b> tippen, <b>Normaler Shortcut</b>, Name <b>Auf DynaFrame</b>.",
    "Unter den grundlegenden Anfrage-Einstellungen: Methode <b>POST</b>, URL <code>{url}</code>",
    "Unter <b>Anfrage-Body</b>: Typ <b>Datei</b> wählen (für mehrere Fotos auf einmal: <b>Formular-Daten</b> mit einem Parameter vom Typ Datei, mehrere Dateien erlaubt).",
    "Speichern. Ab jetzt: Foto in der Galerie öffnen, <b>Teilen</b>, <b>HTTP Shortcuts</b>, <b>Auf DynaFrame</b>."
  ], [
    "Install and open <b>HTTP Shortcuts</b>, tap <b>+</b>, <b>Regular Shortcut</b>, name <b>On DynaFrame</b>.",
    "In the basic request settings: method <b>POST</b>, URL <code>{url}</code>",
    "In <b>Request Body</b>: choose type <b>File</b> (for several photos at once: <b>Form data</b> with one parameter of type file, multiple files allowed).",
    "Save. From now on: open a photo in the gallery, <b>Share</b>, <b>HTTP Shortcuts</b>, <b>On DynaFrame</b>."
  ], [
    "Instala y abre <b>HTTP Shortcuts</b>, pulsa <b>+</b>, <b>Atajo normal</b>, nombre <b>En DynaFrame</b>.",
    "En los ajustes básicos de la solicitud: método <b>POST</b>, URL <code>{url}</code>",
    "En <b>Cuerpo de la solicitud</b>: elige el tipo <b>Archivo</b> (para varias fotos a la vez: <b>Datos de formulario</b> con un parámetro de tipo archivo, varios archivos permitidos).",
    "Guarda. A partir de ahora: abre una foto en la galería, <b>Compartir</b>, <b>HTTP Shortcuts</b>, <b>En DynaFrame</b>."
  ]],
  androidNote: ["Ohne Zusatz-App: die Handy-Seite aus Schritt 1 auf den Home-Bildschirm legen. Die Bezeichnungen in den Apps können je nach Version leicht abweichen.",
    "Without an extra app: put the phone page from step 1 on the home screen. Labels in the apps may differ slightly between versions.",
    "Sin app adicional: pon la página del móvil del paso 1 en la pantalla de inicio. Los nombres en las apps pueden variar un poco según la versión."],
  settingsTitle: ["Einstellungen", "Settings", "Ajustes"],
  showMinutes: ["So lange auf dem Rahmen (Minuten)", "Time on the frame (minutes)", "Tiempo en el marco (minutos)"],
  slideSeconds: ["Bei mehreren Fotos: jedes so lange (Sekunden)", "With several photos: each for (seconds)", "Con varias fotos: cada una durante (segundos)"],
  fit: ["Darstellung", "Display", "Presentación"],
  fitContain: ["Ganzes Foto, Hintergrund unscharf", "Whole photo, blurred background", "Foto entera, fondo difuminado"],
  fitCover: ["Bildschirm füllen (Ränder abgeschnitten)", "Fill the screen (edges cropped)", "Llenar la pantalla (bordes recortados)"],
  keepPhotos: ["So viele Fotos aufheben", "Keep this many photos", "Guardar tantas fotos"],
  pin: ["Code (leer = jedes Handy im WLAN darf senden)", "Code (empty = every phone on the Wi-Fi may send)",
    "Código (vacío = cualquier móvil de la wifi puede enviar)"],
  caption: ["Absender und Uhrzeit klein unten zeigen", "Show sender and time small at the bottom", "Mostrar remitente y hora abajo en pequeño"],
  wake: ["Ausgeschalteten Bildschirm für ein Foto einschalten", "Switch an off screen on for a photo", "Encender la pantalla apagada para una foto"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noPillow: ["Pillow fehlt auf dem Rahmen: Fotos werden unverkleinert gezeigt, HEIC geht nicht.",
    "Pillow is missing on the frame: photos are shown at full size, HEIC does not work.",
    "Falta Pillow en el marco: las fotos se muestran sin reducir y HEIC no funciona."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or wishes?", "¿Problemas, preguntas o deseos?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre un issue en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", ", with plugin name and version.", ", con el nombre y la versión del plugin."],
};

function t(key, values = {}) {
  const row = I18N[key];
  const index = { de: 0, en: 1, es: 2 }[lang] ?? 0;
  const text = row ? (row[index] ?? row[0]) : key;
  if (Array.isArray(text)) return text.map((line) => fill(line, values));
  return fill(text, values);
}

function fill(text, values) {
  return String(text).replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");
}

function applyLanguage() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach((node) => {
    const value = t(node.dataset.i18n);
    if (typeof value === "string") node.textContent = value;
  });
  if (!PHONE) el("pickLabel").querySelector(".pick-text").textContent = t("pickFrame");
  renderSteps();
}

// ---------------------------------------------------------------------------
// Code (nur auf der Handy-Seite, wenn einer eingestellt ist)
// ---------------------------------------------------------------------------

function storedPin() {
  try { return localStorage.getItem("phonePhotosPin") || ""; } catch (e) { return ""; }
}

function rememberPin(value) {
  try { localStorage.setItem("phonePhotosPin", value); } catch (e) { /* egal */ }
}

function withPin(url) {
  const pin = PHONE ? storedPin() : "";
  return pin ? url + (url.includes("?") ? "&" : "?") + "pin=" + encodeURIComponent(pin) : url;
}

async function call(path, init = {}) {
  const headers = Object.assign({}, init.headers || {});
  if (PHONE && storedPin()) headers["X-Pin"] = storedPin();
  const response = await fetch("./" + path, Object.assign({ cache: "no-store" }, init, { headers }));
  let data = {};
  try { data = await response.json(); } catch (e) { data = {}; }
  if (response.status === 403 && data.needPin) {
    showPinCard(true);
    throw new Error(t("pinWrong"));
  }
  return data;
}

function showPinCard(show) {
  el("pinCard").hidden = !show;
  el("sendCard").hidden = show;
}

el("pinForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  rememberPin(el("pinInput").value.trim());
  el("pinNote").textContent = "";
  try {
    await refresh();
    if (!el("pinCard").hidden) el("pinNote").textContent = t("pinWrong");
  } catch (e) {
    el("pinNote").textContent = t("pinWrong");
  }
});

// ---------------------------------------------------------------------------
// Fotos senden
// ---------------------------------------------------------------------------

// Auf dem Handy verkleinern: spart WLAN-Zeit und macht aus iPhone-HEIC ein JPEG.
async function shrink(file) {
  try {
    let bitmap;
    try {
      bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
    } catch (e) {
      bitmap = await createImageBitmap(file);
    }
    const scale = Math.min(1, MAX_EDGE / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bitmap.width * scale);
    canvas.height = Math.round(bitmap.height * scale);
    canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    if (bitmap.close) bitmap.close();
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.9));
    if (blob && blob.size > 1000) return blob;
  } catch (e) {
    /* dann das Original; der Rahmen kümmert sich */
  }
  return file;
}

function senderName() {
  if (!PHONE) return "";
  const value = el("senderName").value.trim();
  try { localStorage.setItem("phonePhotosName", value); } catch (e) { /* egal */ }
  return value;
}

async function sendFiles(files) {
  const list = Array.from(files || []).filter((f) => !f.type || f.type.startsWith("image/") || /\.(heic|heif)$/i.test(f.name));
  if (!list.length) return;
  const note = el("sendNote");
  const pick = el("pickLabel");
  pick.classList.add("busy");
  note.className = "status busy";
  let sent = 0;
  let lastError = "";
  const name = senderName();
  for (let i = 0; i < list.length; i += 1) {
    note.textContent = t("preparing", { n: i + 1, total: list.length });
    const body = await shrink(list[i]);
    note.textContent = t("sending", { n: i + 1, total: list.length });
    try {
      const query = name ? "?from=" + encodeURIComponent(name) : "";
      const answer = await call("upload" + query, { method: "POST", body,
        headers: { "Content-Type": body.type || "application/octet-stream" } });
      if (answer.success) sent += 1;
      else lastError = answer.error || "?";
    } catch (e) {
      lastError = e.message === t("pinWrong") ? e.message : t("noConnection");
    }
  }
  pick.classList.remove("busy");
  el("fileInput").value = "";
  if (lastError && !sent) {
    note.className = "status bad";
    note.textContent = t("failed", { error: lastError });
  } else {
    note.className = "status ok";
    note.textContent = sent === 1 ? t("sentOne") : t("sentMany", { n: sent });
    if (lastError) note.textContent += " " + t("failed", { error: lastError });
  }
  refresh();
}

el("fileInput").addEventListener("change", (event) => sendFiles(event.target.files));

const pickLabel = el("pickLabel");
["dragenter", "dragover"].forEach((type) => pickLabel.addEventListener(type, (event) => {
  event.preventDefault();
  pickLabel.classList.add("drag");
}));
["dragleave", "drop"].forEach((type) => pickLabel.addEventListener(type, () => pickLabel.classList.remove("drag")));
pickLabel.addEventListener("drop", (event) => {
  event.preventDefault();
  sendFiles(event.dataTransfer.files);
});

el("hideButton").addEventListener("click", async () => {
  await call("api/control", { method: "POST", body: JSON.stringify({ action: "hide" }) }).catch(() => {});
  refresh();
});

// ---------------------------------------------------------------------------
// Zuletzt gesendet
// ---------------------------------------------------------------------------

function renderRecent(state) {
  const showing = new Set(state.showing ? state.ids : []);
  const key = JSON.stringify([state.recent.map((p) => p.id), [...showing]]);
  if (key === recentKey) return;
  recentKey = key;
  const box = el("recent");
  box.textContent = "";
  el("recentEmpty").hidden = state.recent.length > 0;
  state.recent.forEach((photo) => {
    const tile = document.createElement("div");
    tile.className = "tile" + (showing.has(photo.id) ? " on" : "");
    tile.setAttribute("role", "button");
    tile.tabIndex = 0;
    const img = document.createElement("img");
    img.loading = "lazy";
    img.alt = "";
    img.src = withPin("./" + photo.thumb);
    tile.appendChild(img);
    const who = document.createElement("span");
    who.className = "who";
    const at = photo.at ? new Date(photo.at) : null;
    who.textContent = [photo.from, at && !isNaN(at) ? at.toLocaleString(lang, { day: "numeric", month: "numeric", hour: "2-digit", minute: "2-digit" }) : ""]
      .filter(Boolean).join(" · ");
    tile.appendChild(who);
    tile.addEventListener("click", async (event) => {
      if (event.target.closest(".del")) return;
      await call("api/control", { method: "POST", body: JSON.stringify({ action: "show", id: photo.id }) }).catch(() => {});
      refresh();
    });
    if (!PHONE) {
      const del = document.createElement("button");
      del.type = "button";
      del.className = "del";
      del.textContent = "×";
      del.setAttribute("aria-label", t("deleteAsk"));
      del.addEventListener("click", async () => {
        if (!confirm(t("deleteAsk"))) return;
        await call("api/control", { method: "POST", body: JSON.stringify({ action: "delete", id: photo.id }) }).catch(() => {});
        refresh();
      });
      tile.appendChild(del);
    }
    box.appendChild(tile);
  });
}

// ---------------------------------------------------------------------------
// Einrichten (nur auf dem Rahmen)
// ---------------------------------------------------------------------------

function uploadUrl(from) {
  const base = current && current.phoneUrl ? current.phoneUrl : "http://<rahmen>:8095/";
  const pin = current && current.settings && current.settings.Pin;
  return `${base}upload?from=${from}` + (pin ? `&pin=${encodeURIComponent(pin)}` : "");
}

function escapeHtml(text) {
  return String(text).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;" }[c]));
}

let stepsKey = "";
function renderSteps() {
  if (PHONE) return;
  const key = lang + uploadUrl("");
  if (key === stepsKey) return;
  stepsKey = key;
  const fillList = (id, key, url) => {
    el(id).innerHTML = t(key, { url: escapeHtml(url) }).map((line) => `<li>${line}</li>`).join("");
  };
  fillList("iosSteps", "iosSteps", uploadUrl("iPhone"));
  fillList("androidSteps", "androidSteps", uploadUrl("Android"));
}

let qrFor = "";
function renderPhoneLink(url) {
  const link = el("phoneUrl");
  link.textContent = url || "—";
  link.href = url || "#";
  if (!url || url === qrFor || typeof qrcode !== "function") return;
  qrFor = url;
  const code = qrcode(0, "M");
  code.addData(url);
  code.make();
  const canvas = el("qr");
  const count = code.getModuleCount();
  const size = 200;
  const cell = Math.floor(size / count);
  const offset = Math.floor((size - cell * count) / 2);
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, size, size);
  ctx.fillStyle = "#000";
  for (let r = 0; r < count; r += 1) {
    for (let c = 0; c < count; c += 1) {
      if (code.isDark(r, c)) ctx.fillRect(offset + c * cell, offset + r * cell, cell, cell);
    }
  }
}

const SETTING_IDS = ["Language", "ShowMinutes", "SlideSeconds", "Fit", "KeepPhotos", "Pin", "Caption", "WakeScreen"];

function fillSettings(values) {
  if (editing) return;
  SETTING_IDS.forEach((id) => {
    const input = el(id);
    if (!input || document.activeElement === input) return;
    if (input.type === "checkbox") input.checked = !!values[id];
    else input.value = values[id] ?? "";
  });
}

async function saveSetting(id) {
  const input = el(id);
  const value = input.type === "checkbox" ? input.checked : input.value;
  const note = el("settingsNote");
  try {
    await call("api/settings", { method: "POST", body: JSON.stringify({ [id]: value }) });
    note.className = "status ok";
    note.textContent = t("saved");
  } catch (e) {
    note.className = "status bad";
    note.textContent = e.message;
  }
  editing = false;
  await refresh();
}

if (!PHONE) {
  SETTING_IDS.forEach((id) => {
    const input = el(id);
    input.addEventListener("focus", () => { editing = true; });
    input.addEventListener("change", () => saveSetting(id));
    input.addEventListener("blur", () => { editing = false; });
  });
} else {
  try { el("senderName").value = localStorage.getItem("phonePhotosName") || ""; } catch (e) { /* egal */ }
}

// ---------------------------------------------------------------------------
// Zustand
// ---------------------------------------------------------------------------

function minutesText(seconds) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

async function refresh() {
  let state;
  try {
    const response = await fetch(withPin("./api/state"), { cache: "no-store",
      headers: PHONE && storedPin() ? { "X-Pin": storedPin() } : {} });
    state = await response.json();
  } catch (e) {
    el("nowNote").className = "status bad";
    el("nowNote").textContent = t("noConnection");
    return;
  }
  if (state.language && state.language !== lang) {
    lang = state.language;
    applyLanguage();
  }
  if (!state.success) {
    if (state.needPin) showPinCard(true);
    return;
  }
  showPinCard(false);
  current = state;
  el("version").textContent = state.version ? "v" + state.version : "";
  el("hideButton").hidden = !state.showing;
  const now = el("nowNote");
  if (state.showing) {
    now.className = "status ok";
    now.textContent = state.onScreen ? t("nowShowing", { time: minutesText(state.remaining) }) : t("waiting");
  } else {
    now.textContent = "";
  }
  renderRecent(state);
  const permission = el("permissionNote");
  permission.hidden = !state.permission;
  permission.textContent = state.permission || "";
  const error = el("errorNote");
  const problem = state.note || state.lastError || (!PHONE && state.pillow === false ? t("noPillow") : "");
  error.hidden = !problem;
  error.textContent = problem;
  if (!PHONE) {
    fillSettings(state.settings || {});
    renderPhoneLink(state.phoneUrl);
    renderSteps();
  }
}

applyLanguage();
refresh();
setInterval(refresh, PHONE ? 3000 : 2000);
