# Guestbook

Your guestbook on the frame, as a DynaFrame scene with its plugin.

- **Visitors sign in with their phone.** They scan the QR code on the TV or on a printed card (the plugin page prints four per sheet). It opens a page of the plugin on port 8135 in your Wi-Fi with the code filled in: take a selfie with the front camera, write your name and a few lines, done. No app needed. On the same phone they can change or delete their entry for two days.
- **The TV leafs through the book** like an open guestbook: the selfie on the left, the handwritten greeting on the right, the date and "visit no. 3" for regular guests.
- **New entries come up right away** with "Welcome, Anne!", even in the middle of your normal slideshow (needs "Allow takeover").
- **Memories:** on the day someone visited in an earlier year, the frame says "3 years ago today, Aunt Anne came to visit." with that day's selfies and greeting. Optionally it brings this onto the TV by itself once a day at a set time.
- **Party mode:** give the party a name and start it. Every guest's entry comes up big, then joins a wall of all guests of the evening next to the QR code. When the party ends, a recap shows every entry. Later those entries come back as "2 years ago today: Anna's 40th birthday".
- **Plugin page:** title of the book, selfie required or optional, approve entries first, correct name, greeting or date of any entry, hide or delete, print the book, download all as ZIP, three looks (paper, evening, party), a "Connections" card that checks everything the plugin needs.

If you use Web Login, open port 8135 there. English, German or Spanish; the guest page follows the phone's language. Photos are stored at 1600 pixels without location or camera data.
