/* Biathlon Live - die Szene.
 *
 * Ein Nachbau von MMM-Biathlon (2hdlockness, MIT) für DynaFrame. Die Daten
 * kommen vom Plugin Biathlon Live über den Proxy der Weboberfläche (:8003
 * oder Port 80; die Szene probiert beide). Antwortet das Plugin nicht, liest
 * die Szene den Weltcup selbst über DynaFrameScene.fetchExternalJson.
 * Mit ?demo=1 zeigt sie Beispieldaten (zum Ansehen im Browser).
 *
 * Seiten: je Rennen eine (Ergebnis oder Zwischenstand), das Programm und
 * die Gesamtwertung. Sie wechseln im eingestellten Takt.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "BiathlonLive";
  const POLL_MS = 15000;
  const FALLBACK_POLL_MS = 120000;
  const params = new URLSearchParams(location.search);
  const DEMO = params.has("demo");
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set([
    `${location.protocol}//${location.hostname}:8003${advanced}`,
    `${location.protocol}//${location.hostname}${advanced}`,
    `${location.origin}${advanced}`
  ])];
  let baseIndex = 0;

  const el = (id) => document.getElementById(id);
  const ui = {
    stage: el("stage"), accent: el("accent"), title: el("title"), subtitle: el("subtitle"),
    clock: el("clock"), updated: el("updated"), dots: el("dots"), page: el("page"), foot: el("foot")
  };

  let snapshot = null;
  let pageIndex = 0;
  let pageTimer = null;
  let readySent = false;
  let mode = DEMO ? "demo" : "plugin";
  let pluginFailures = 0;
  let lastRanks = {};   // Rennen -> Anzahl im Ziel, um Neues kurz aufleuchten zu lassen
  let fresh = new Set();

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  function esc(text) {
    return String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  const TEXT = {
    de: { loading: "Ergebnisse werden geladen …", nothing: "Keine Rennen", nothingLong: "Für die gewählten Serien gibt es gerade keine Ergebnisse und kein Programm.",
      moment: "Einen Moment …", unreachable: "Die Ergebnisse sind gerade nicht erreichbar.", noResults: "Noch keine Ergebnisse.",
      asOf: "Stand", data: "Daten", direct: "Plugin nicht erreichbar – Notbetrieb", demo: "Beispieldaten",
      today: "Heute", tomorrow: "Morgen", live: "Live", final: "Ergebnis", inFinish: "{n} im Ziel", onCourse: "{n} unterwegs",
      next: "Als Nächstes", nextStation: "Nächste Station", schedule: "Programm", standings: "Gesamtwertung",
      women: "Frauen", men: "Männer", points: "Pkt.", shooting: "Schießen", time: "Zeit", noNext: "Noch kein Programm.",
      postponed: "abgesagt", until: "bis" },
    en: { loading: "Loading results …", nothing: "No races", nothingLong: "There are no results and no schedule for the selected series right now.",
      moment: "One moment …", unreachable: "Results are not available right now.", noResults: "No results yet.",
      asOf: "As of", data: "Data", direct: "Plugin not reachable – fallback mode", demo: "Sample data",
      today: "Today", tomorrow: "Tomorrow", live: "Live", final: "Result", inFinish: "{n} finished", onCourse: "{n} on course",
      next: "Coming up", nextStation: "Next venue", schedule: "Schedule", standings: "Overall standings",
      women: "Women", men: "Men", points: "Pts", shooting: "Shooting", time: "Time", noNext: "No schedule yet.",
      postponed: "cancelled", until: "to" },
    es: { loading: "Cargando resultados …", nothing: "No hay carreras", nothingLong: "Ahora mismo no hay resultados ni programa para las series elegidas.",
      moment: "Un momento …", unreachable: "Los resultados no están disponibles ahora mismo.", noResults: "Aún no hay resultados.",
      asOf: "Act.", data: "Datos", direct: "Plugin no disponible – modo de emergencia", demo: "Datos de ejemplo",
      today: "Hoy", tomorrow: "Mañana", live: "En vivo", final: "Resultado", inFinish: "{n} en meta", onCourse: "{n} en pista",
      next: "Próximamente", nextStation: "Próxima sede", schedule: "Programa", standings: "Clasificación general",
      women: "Femenino", men: "Masculino", points: "Pts", shooting: "Tiro", time: "Tiempo", noNext: "Aún no hay programa.",
      postponed: "suspendida", until: "a" }
  };
  const LOCALE = { de: "de-DE", en: "en-GB", es: "es-ES" };
  let lang = TEXT[params.get("lang")] ? params.get("lang") : "de";
  let T = TEXT[lang];
  let dayFmt, dateFmt, timeFmt;
  function setLanguage(next) {
    if (dayFmt && next === lang) return;
    lang = TEXT[next] ? next : "de";
    T = TEXT[lang];
    document.documentElement.lang = lang;
    dayFmt = new Intl.DateTimeFormat(LOCALE[lang], { weekday: "short" });
    dateFmt = new Intl.DateTimeFormat(LOCALE[lang], { day: "2-digit", month: "2-digit" });
    timeFmt = new Intl.DateTimeFormat(LOCALE[lang], { hour: "2-digit", minute: "2-digit" });
  }
  setLanguage(lang);
  const fill = (text, values) => text.replace(/\{(\w+)\}/g, (_, k) => String(values[k] ?? ""));

  // Flaggen liegen als flags/<ioc>.svg neben der Szene (flag-icons, MIT).
  const FLAGS = new Set(("GER AUT SUI FRA NOR SWE FIN ITA CZE SVK SLO POL UKR BLR RUS EST LAT LTU BEL NED GBR IRL ESP AND " +
    "BUL ROU MDA CRO SRB BIH GRE HUN DEN ISL TUR KAZ MGL CHN JPN KOR CAN USA AUS ARG BRA CHI").split(" "));
  function flag(code) {
    const nat = String(code || "").toUpperCase();
    if (FLAGS.has(nat)) return `<img class="flag" src="flags/${nat.toLowerCase()}.svg" alt="${esc(nat)}">`;
    return `<span class="flag code">${esc(nat || "?")}</span>`;
  }

  function dayText(epoch) {
    const date = new Date(epoch * 1000);
    const today = new Date();
    const tomorrow = new Date(Date.now() + 86400000);
    if (date.toDateString() === today.toDateString()) return T.today;
    if (date.toDateString() === tomorrow.toDateString()) return T.tomorrow;
    return `${dayFmt.format(date).replace(".", "")} ${dateFmt.format(date)}`;
  }

  function placeName(place) {
    // Die IBU schreibt Umlaute aus (Oestersund, Otepaeae); so bleibt es.
    return place || "";
  }

  // ------------------------------------------------------------ data: plugin

  async function loadFromPlugin() {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
      const response = await fetch(new URL("api/scene", pluginBases[baseIndex]), { signal: controller.signal, cache: "no-store" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      if (!data || !Array.isArray(data.pages)) throw new Error("unerwartete Antwort");
      data.mode = "plugin";
      return data;
    } catch (error) {
      baseIndex = (baseIndex + 1) % pluginBases.length;
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  // ------------------------------------------------- data: direkt (Notfall)

  const API = "https://biathlonresults.com/modules/sportapi/api/";
  async function getJson(url) {
    if (window.DynaFrameScene?.fetchExternalJson) return window.DynaFrameScene.fetchExternalJson(url);
    const response = await fetch(url, { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  }

  function seasonId(date) {
    const start = date.getMonth() >= 6 ? date.getFullYear() : date.getFullYear() - 1;
    return `${String(start % 100).padStart(2, "0")}${String((start + 1) % 100).padStart(2, "0")}`;
  }

  function directName(name) {
    const words = String(name || "").split(/\s+/);
    const family = [];
    for (const w of words) { if (w.replace(/[^\p{L}]/gu, "") && w === w.toUpperCase()) family.push(w); else break; }
    if (!family.length) return name;
    const nice = family.map((w) => w.split("-").map((p) => p[0] + p.slice(1).toLowerCase()).join("-")).join(" ");
    const given = words.slice(family.length);
    return given.length ? `${given[0][0]}. ${nice}` : nice;
  }

  async function loadDirect() {
    // Nur der Weltcup, die zwei jüngsten Rennen der letzten Station.
    const t = Date.now() / 1000;
    let season = seasonId(new Date());
    let events = (await getJson(`${API}Events?SeasonId=${season}&Level=1`)) || [];
    let past = events.filter((e) => e.EventClassificationId === "BTSWRLCP" && Date.parse(e.StartDate) / 1000 <= t);
    if (!past.length) {
      const s = parseInt(season.slice(0, 2), 10);
      season = `${String((s + 99) % 100).padStart(2, "0")}${String(s).padStart(2, "0")}`;
      events = (await getJson(`${API}Events?SeasonId=${season}&Level=1`)) || [];
      past = events.filter((e) => e.EventClassificationId === "BTSWRLCP" && Date.parse(e.StartDate) / 1000 <= t);
    }
    const event = past.sort((a, b) => Date.parse(a.StartDate) - Date.parse(b.StartDate)).pop();
    const pages = [];
    if (event) {
      const races = ((await getJson(`${API}Competitions?EventId=${event.EventId}`)) || [])
        .filter((r) => Date.parse(r.StartTime) / 1000 <= t)
        .sort((a, b) => Date.parse(b.StartTime) - Date.parse(a.StartTime)).slice(0, 2);
      for (const race of races) {
        const data = await getJson(`${API}Results?RaceId=${race.RaceId}`);
        const relay = /(RL|SR)$/.test(race.RaceId);
        const seen = new Set();
        const rows = (data?.Results || []).filter((r) => r.Rank && (!relay || r.IsTeam !== false) && !seen.has(r.Rank) && seen.add(r.Rank))
          .slice(0, 10).map((r) => ({
            rank: parseInt(r.Rank, 10), name: relay ? r.Name : directName(r.Name), short: relay ? r.Name : directName(r.Name),
            nat: r.Nat, time: r.TotalTime, behind: r.Behind, shootings: /^\d(\+\d)+$/.test(r.Shootings || "") ? r.Shootings.split("+").map(Number) : [],
            shootingText: r.Shootings || "", shootingTotal: parseInt(r.ShootingTotal, 10), team: relay, mine: false
          }));
        pages.push({ kind: "race", id: race.RaceId, seriesName: "BMW IBU World Cup", color: "#1f6feb", place: event.ShortDescription,
          placeNat: event.Nat, name: race.ShortDescription, start: Date.parse(race.StartTime) / 1000, relay,
          state: "post", rows, extra: null, finished: rows.length, open: 0, updatedAt: t, error: "" });
      }
    }
    return { mode: "direct", pageSeconds: 20, focus: null, at: t, showTime: true, showShooting: true, next: [], stations: [], pages };
  }

  // ------------------------------------------------------------ data: demo

  function demoData() {
    const t = Date.now() / 1000;
    const people = [["J. Simon", "FRA"], ["F. Preuss", "GER"], ["E. Oeberg", "SWE"], ["L. Jeanmonnot", "FRA"], ["L. Vittozzi", "ITA"],
      ["S. Grotian", "GER"], ["I. Tandrevold", "NOR"], ["L. Hauser", "AUT"], ["S. Minkkinen", "FIN"], ["M. Davidova", "CZE"],
      ["V. Voigt", "GER"], ["J. Braisaz-Bouchet", "FRA"]];
    const men = [["J. T. Boe", "NOR"], ["S. Laegreid", "NOR"], ["E. Perrot", "FRA"], ["P. Nawrath", "GER"], ["S. Samuelsson", "SWE"],
      ["T. Giacomel", "ITA"], ["V. Strolia", "LTU"], ["B. Doll", "GER"], ["Q. Fillon Maillet", "FRA"], ["S. Stalder", "SUI"]];
    const shots = [[0, 0], [0, 1], [1, 0], [0, 0], [1, 1], [0, 1], [2, 0], [0, 1], [1, 0], [0, 2]];
    const row = (p, i, stages) => ({ rank: i + 1, name: p[0], short: p[0], nat: p[1], time: i ? "" : "20:41.3",
      behind: i ? `+${(i * 9.7 + i * i * 1.3).toFixed(1)}` : "", shootings: stages === 4 ? [...shots[i % 10], ...shots[(i + 3) % 10]] : shots[i % 10],
      shootingText: "", shootingTotal: 0, team: false, mine: p[1] === "GER" });
    const sprint = people.slice(0, 10).map((p, i) => row(p, i, 2));
    const live = men.slice(0, 6).map((p, i) => row(p, i, 4));
    const page = (id, name, state, rows, offset, extra) => ({ kind: "race", id, series: "BTSWRLCP", seriesName: "BMW IBU Weltcup",
      color: "#1f6feb", place: "Oestersund", placeNat: "SWE", name, start: t + offset, relay: false, state, rows, extra: extra || null,
      finished: state === "live" ? 6 : rows.length, open: state === "live" ? 52 : 0, updatedAt: t, error: "" });
    const cup = (list) => list.map((p, i) => ({ rank: i + 1, name: p[0], short: p[0], nat: p[1], score: String(412 - i * 23), mine: p[1] === "GER" }));
    return {
      mode: "demo", pageSeconds: 12, focus: null, at: t, showTime: true, showShooting: true,
      nation: { code: "GER", name: "Deutschland" },
      next: [
        { id: "a", start: t + 2 * 3600, name: "Sprint 10 km · Männer", place: "Oestersund", nat: "SWE", color: "#1f6feb" },
        { id: "b", start: t + 26 * 3600, name: "Single-Mixed-Staffel", place: "Oestersund", nat: "SWE", color: "#1f6feb" },
        { id: "c", start: t + 29 * 3600, name: "Mixed-Staffel", place: "Oestersund", nat: "SWE", color: "#1f6feb" },
        { id: "d", start: t + 6 * 86400, name: "Sprint 10 km · Männer", place: "Hochfilzen", nat: "AUT", color: "#1f6feb" },
        { id: "e", start: t + 7 * 86400, name: "Sprint 7,5 km · Frauen", place: "Hochfilzen", nat: "AUT", color: "#1f6feb" }
      ],
      stations: [
        { series: "BTSWRLCP", seriesName: "BMW IBU Weltcup", color: "#1f6feb", place: "Hochfilzen", nat: "AUT", natName: "Österreich", start: t + 5 * 86400, end: t + 9 * 86400 },
        { series: "BTSWRLCH", seriesName: "Biathlon-WM", color: "#c8102e", place: "Otepaeae", nat: "EST", natName: "Estland", start: t + 100 * 86400, end: t + 112 * 86400 }
      ],
      pages: [
        page("live", "Verfolgung 12,5 km · Männer", "live", live, -1500),
        page("sp", "Sprint 7,5 km · Frauen", "post", sprint, -86400, row(people[10], 13, 2)),
        { kind: "schedule", id: "schedule" },
        { kind: "standings", id: "cup", series: "BTSWRLCP", seriesName: "BMW IBU Weltcup", color: "#1f6feb", season: "2026/27",
          columns: [{ gender: "SW", rows: cup(people.slice(0, 10)), extra: null, updatedAt: t },
            { gender: "SM", rows: cup(men), extra: null, updatedAt: t }] }
      ]
    };
  }

  // ----------------------------------------------------------------- render

  function rankCell(rank) {
    const medal = { 1: "gold", 2: "silver", 3: "bronze" }[rank];
    return medal ? `<span class="rank medal ${medal}">${esc(rank)}</span>` : `<span class="rank">${esc(rank ?? "")}</span>`;
  }

  // Schießen wie im Fernsehen: je Schießen fünf Scheiben, Treffer hell,
  // Fehler rot. Staffeln (Strafrunden+Nachlader) als Text.
  function shootCell(r) {
    if (!snapshot.showShooting) return "";
    if (!r.shootings || !r.shootings.length) {
      return `<span class="shots text">${esc(r.shootingText || "")}</span>`;
    }
    const groups = r.shootings.map((miss) => {
      const dots = [];
      for (let i = 0; i < 5; i += 1) dots.push(`<i class="${i >= 5 - Math.min(5, miss) ? "miss" : ""}"></i>`);
      return `<span class="target">${dots.join("")}</span>`;
    }).join("");
    const total = r.shootings.reduce((a, b) => a + b, 0);
    return `<span class="shots">${groups}<b class="${total ? "" : "clean"}">${total}</b></span>`;
  }

  function timeCell(r, first) {
    if (!snapshot.showTime) return "";
    if (r.irm) return `<span class="time irm">${esc(r.irm)}</span>`;
    const text = first || !r.behind ? r.time : r.behind;
    return `<span class="time${first ? " lead" : ""}">${esc(text || "")}</span>`;
  }

  function resultRow(r, i, page) {
    const classes = ["row", r.mine ? "mine" : "", fresh.has(`${page.id}:${r.rank}`) ? "fresh" : ""].join(" ");
    const name = portrait() && !r.team ? (r.short || r.name) : (r.name || r.short);
    return `<div class="${classes}">${rankCell(r.rank)}${flag(r.nat)}
      <span class="name">${esc(name)}${r.team ? "" : `<small>${esc(r.nat)}</small>`}</span>
      ${shootCell(r)}${timeCell(r, i === 0)}</div>`;
  }

  function portrait() { return innerHeight > innerWidth; }

  function columns(narrow) {
    const cols = [narrow ? "2rem" : "2.6rem", narrow ? "2rem" : "2.4rem", "minmax(0, 1fr)"];
    if (snapshot.showShooting) cols.push("auto");
    if (snapshot.showTime) cols.push(narrow ? "5.6rem" : "7.2rem");
    return cols.join(" ");
  }

  function sizeFor(lines) {
    return lines > 22 ? .72 : lines > 16 ? .84 : lines > 12 ? .94 : 1;
  }

  function racePage(page) {
    const rows = page.rows || [];
    let body;
    if (!rows.length) {
      body = `<div class="empty">${esc(page.error ? T.unreachable : page.state === "live" ? T.moment : T.noResults)}</div>`;
    } else {
      const extra = page.extra ? `<div class="row gap"><span></span><span></span><span class="name">…</span></div>${resultRow(page.extra, 1, page)}` : "";
      const lines = rows.length + (page.extra ? 2 : 0);
      body = `<div class="rows${lines < 8 ? " few" : ""}" style="--cols:${columns(false)};--cols-portrait:${columns(true)};--row-font:${sizeFor(lines)}">
        ${rows.map((r, i) => resultRow(r, i, page)).join("")}${extra}</div>`;
    }
    const progress = page.state === "live" && (page.finished || page.open)
      ? `<p class="progress"><span class="pulse"></span>${esc(fill(T.inFinish, { n: page.finished }))}${page.open ? ` · ${esc(fill(T.onCourse, { n: page.open }))}` : ""}</p>` : "";
    const side = sidePanel();
    return `<section class="panel results${page.state === "live" ? " live" : ""}">${progress}${body}</section>${side}`;
  }

  function nextList(items, limit) {
    return items.slice(0, limit).map((r) => `<li><span class="when"><b>${esc(dayText(r.start))}</b>${esc(timeFmt.format(new Date(r.start * 1000)))}</span>
      <span class="what">${esc(r.name)}<small>${flag(r.nat)}${esc(placeName(r.place))}</small></span></li>`).join("");
  }

  function stationCard(s) {
    const span = `${dateFmt.format(new Date(s.start * 1000))} ${T.until} ${dateFmt.format(new Date(s.end * 1000))}`;
    return `<div class="station" style="--series:${esc(s.color)}">${flag(s.nat)}<div><b>${esc(placeName(s.place))}</b>
      <small>${esc(s.seriesName)} · ${esc(s.natName || s.nat)}</small><small>${esc(span)}</small></div></div>`;
  }

  function sidePanel() {
    const next = snapshot.next || [];
    const stations = snapshot.stations || [];
    if (!next.length && !stations.length) return "";
    const limit = portrait() ? 3 : 5;
    return `<aside class="panel side"><h2>${esc(T.next)}</h2><ul class="next">${nextList(next, limit)}</ul>
      ${stations.length ? `<h2>${esc(T.nextStation)}</h2>${stations.slice(0, portrait() ? 1 : 2).map(stationCard).join("")}` : ""}</aside>`;
  }

  function schedulePage() {
    const next = snapshot.next || [];
    const stations = snapshot.stations || [];
    const list = next.length ? `<ul class="next big">${nextList(next, portrait() ? 10 : 9)}</ul>` : `<div class="empty">${esc(T.noNext)}</div>`;
    return `<section class="panel"><h2>${esc(T.next)}</h2>${list}</section>
      <aside class="panel side"><h2>${esc(T.nextStation)}</h2>${stations.map(stationCard).join("")}</aside>`;
  }

  function cupColumn(col) {
    const row = (r) => `<div class="row${r.mine ? " mine" : ""}">${rankCell(r.rank)}${flag(r.nat)}
      <span class="name">${esc(portrait() ? r.short : r.name)}<small>${esc(r.nat)}</small></span><span class="pts">${esc(r.score)}</span></div>`;
    const extra = col.extra ? `<div class="row gap"><span></span><span></span><span class="name">…</span></div>${row(col.extra)}` : "";
    const lines = col.rows.length + (col.extra ? 2 : 0);
    return `<section class="panel"><h2>${esc(col.gender === "SW" ? T.women : T.men)}</h2>
      <div class="rows cup${lines < 8 ? " few" : ""}" style="--row-font:${sizeFor(lines)}">${col.rows.map(row).join("")}${extra}</div></section>`;
  }

  function header(page) {
    let title = "Biathlon Live";
    let sub = "";
    if (page.kind === "race") {
      title = `${page.seriesName} · ${placeName(page.place)}`;
      const when = page.start ? `${dayText(page.start)} ${timeFmt.format(new Date(page.start * 1000))}` : "";
      sub = `${page.name}${when ? " · " + when : ""}`;
      ui.title.innerHTML = `<span>${esc(title)}</span>${page.placeNat ? flag(page.placeNat) : ""}`;
      ui.subtitle.innerHTML = `${page.state === "live" ? `<span class="pill">${esc(T.live)}</span>` : page.state === "off" ? `<span class="pill off">${esc(T.postponed)}</span>` : ""}${esc(sub)}`;
      return;
    }
    if (page.kind === "schedule") {
      title = T.schedule;
      sub = (snapshot.stations || []).map((s) => s.seriesName).filter((v, i, a) => a.indexOf(v) === i).join(" · ");
    } else if (page.kind === "standings") {
      title = `${page.seriesName} · ${T.standings}`;
      sub = page.season || "";
    }
    ui.title.textContent = title;
    ui.subtitle.textContent = sub;
  }

  function render() {
    const pages = (snapshot?.pages || []).filter(Boolean);
    if (!pages.length) {
      ui.title.textContent = "Biathlon Live";
      ui.subtitle.textContent = snapshot ? T.nothing : T.loading;
      ui.page.className = "page";
      ui.page.innerHTML = `<div class="empty">${esc(snapshot ? (snapshot.error ? T.unreachable : T.nothingLong) : T.moment)}</div>`;
      ui.dots.innerHTML = "";
      renderMeta(null);
      return;
    }
    pageIndex %= pages.length;
    const page = pages[pageIndex];
    document.documentElement.style.setProperty("--accent", page.color || "#1f6feb");
    header(page);
    if (page.kind === "race") {
      const side = (snapshot.next || []).length || (snapshot.stations || []).length;
      ui.page.className = `page race${side ? " with-side" : ""}`;
      ui.page.innerHTML = racePage(page);
    } else if (page.kind === "schedule") {
      ui.page.className = "page with-side schedule";
      ui.page.innerHTML = schedulePage();
    } else {
      ui.page.className = `page standings cols-${page.columns.length}`;
      ui.page.innerHTML = page.columns.map(cupColumn).join("");
    }
    ui.dots.innerHTML = pages.length > 1 ? pages.map((_, i) => `<span class="${i === pageIndex ? "on" : ""}"></span>`).join("") : "";
    renderMeta(page);
  }

  function renderMeta(page) {
    const at = page?.updatedAt || snapshot?.at;
    const age = at ? Date.now() / 1000 - at : Infinity;
    const stale = (page?.state === "live" ? age > 5 * 60 : age > 6 * 3600) || (page && page.error);
    ui.updated.textContent = at ? `${T.asOf} ${timeFmt.format(new Date(at * 1000))}` : "";
    ui.updated.classList.toggle("stale", Boolean(stale));
    const note = mode === "direct" ? T.direct : mode === "demo" ? T.demo : "";
    ui.foot.innerHTML = `<span>${esc(T.data)}: IBU · biathlonresults.com</span><span class="${note && mode !== "demo" ? "warn" : ""}">${esc(note)}</span>`;
  }

  function tickClock() {
    ui.clock.textContent = timeFmt.format(new Date());
  }

  // --------------------------------------------------------------- rotation

  function schedulePageTimer() {
    clearTimeout(pageTimer);
    const pages = snapshot?.pages || [];
    if (pages.length < 2) return;
    const seconds = Math.max(5, Number(snapshot.pageSeconds) || 20);
    pageTimer = setTimeout(() => {
      ui.page.classList.add("fade");
      setTimeout(() => {
        pageIndex = (pageIndex + 1) % pages.length;
        render();
        ui.page.classList.remove("fade");
        schedulePageTimer();
      }, 450);
    }, seconds * 1000);
  }

  function applySnapshot(data, first) {
    const before = snapshot;
    // Wer seit dem letzten Stand ins Ziel gekommen ist, leuchtet kurz auf.
    const now = {};
    fresh = new Set();
    for (const page of data.pages || []) {
      if (page.kind !== "race") continue;
      now[page.id] = page.finished || 0;
      if (!first && page.state === "live" && lastRanks[page.id] !== undefined && page.finished > lastRanks[page.id]) {
        for (const r of page.rows || []) fresh.add(`${page.id}:${r.rank}`);
      }
    }
    lastRanks = now;
    if (data.lang) setLanguage(data.lang);
    snapshot = data;
    if (first) {
      // Bei einer Übernahme wegen eines Rennens mit diesem Rennen beginnen.
      const focus = data.focus && data.focus.race;
      const index = focus ? (data.pages || []).findIndex((p) => p.id === focus) : -1;
      pageIndex = index >= 0 ? index : (parseInt(params.get("page"), 10) || 0);
    }
    const changed = !before || (before.pages || []).length !== (data.pages || []).length || before.pageSeconds !== data.pageSeconds;
    render();
    if (first || changed) schedulePageTimer();
  }

  // ------------------------------------------------------------------ loop

  async function poll(first) {
    let data = null;
    if (mode === "demo") {
      data = demoData();
    } else {
      try {
        data = await loadFromPlugin();
        pluginFailures = 0;
        mode = "plugin";
      } catch (_) {
        pluginFailures += 1;
        if (pluginFailures < pluginBases.length) {
          setTimeout(() => poll(first), 1000);  // gleich die nächste Adresse
          return;
        }
        if (first || pluginFailures >= 2 * pluginBases.length || mode === "direct") {
          try {
            data = await loadDirect();
            mode = "direct";
          } catch (_) {
            data = null;
          }
        }
      }
    }
    if (data) applySnapshot(data, first || !snapshot);
    else if (snapshot) renderMeta((snapshot.pages || [])[pageIndex]);
    else render();
    ready();
    setTimeout(() => poll(false), mode === "direct" ? FALLBACK_POLL_MS : POLL_MS);
  }

  function start() {
    tickClock();
    setInterval(tickClock, 5000);
    render();
    // Spätestens nach 5 s ist der erste Stand (oder "Einen Moment …") da.
    setTimeout(ready, 5000);
    poll(true);
    window.addEventListener("resize", () => { if (snapshot) render(); });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
