"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/BiathlonLive/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["MaxEntries", "RaceCount", "PageSeconds", "EveryMinutes", "ShowForSeconds", "ActiveFrom", "ActiveTo", "AlertSeconds"];
const CHECK_FIELDS = ["ShowTime", "ShowShooting", "ShowSchedule", "ShowStandings"];
let current = null;
let editing = false;

// Texte der Seite auf Deutsch, Englisch und Spanisch. Die Sprache ist eine
// Einstellung des Plugins und gilt auch für die Szene.
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Ergebnisse, Zwischenstände, Programm und Gesamtwertung aus dem Biathlon-Weltcup und weiteren IBU-Serien. Biathlon Live legt sie im eingestellten Takt für eine eingestellte Zeit über die laufende Playlist und gibt den Bildschirm danach zurück. Jede Änderung hier wird sofort gespeichert.",
    "Results, live standings, schedule and overall standings from the Biathlon World Cup and other IBU series. Biathlon Live shows them over the running playlist at the interval and for the time you set, then hands the screen back. Every change here is saved immediately.",
    "Resultados, clasificaciones en vivo, programa y clasificación general de la Copa del Mundo de biatlón y otras series de la IBU. Biathlon Live los muestra sobre la lista en curso con la frecuencia y la duración que elijas y después devuelve la pantalla. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  refresh: ["Jetzt aktualisieren", "Refresh now", "Actualizar ahora"],
  show: ["Anzeigen", "Show", "Mostrar"],
  cancel: ["Beenden", "Stop", "Terminar"],
  factStatus: ["Gerade", "Now", "Ahora"],
  factScreen: ["Bildschirm", "Screen", "Pantalla"],
  factNext: ["Nächste Anzeige", "Next display", "Próxima visualización"],
  factScene: ["Szene", "Scene", "Escena"],
  factVersion: ["Version", "Version", "Versión"],
  seriesTitle: ["Serien", "Series", "Series"],
  seriesHint: ["Welche Wettbewerbe gezeigt werden, wie in MMM-Biathlon. Von jeder Serie die Rennen der laufenden oder letzten Station.",
    "Which competitions are shown, as in MMM-Biathlon. For each series, the races of the current or last venue.",
    "Qué competiciones se muestran, como en MMM-Biathlon. De cada serie, las carreras de la sede actual o la última."],
  catTitle: ["Rennen", "Races", "Carreras"],
  catWomen: ["Frauen", "Women", "Femenino"],
  catMen: ["Männer", "Men", "Masculino"],
  catMixed: ["Mixed-Staffeln", "Mixed relays", "Relevos mixtos"],
  viewTitle: ["Anzeige", "Display", "Visualización"],
  maxEntries: ["Plätze je Rennen", "Places per race", "Puestos por carrera"],
  raceCount: ["Höchstens … Rennen", "At most … races", "Como máximo … carreras"],
  pageSeconds: ["Sekunden je Seite", "Seconds per page", "Segundos por página"],
  showTime: ["Zeit und Rückstand zeigen", "Show time and gap", "Mostrar tiempo y diferencia"],
  showShooting: ["Schießergebnis zeigen", "Show shooting", "Mostrar el tiro"],
  showSchedule: ["Programm und nächste Station zeigen", "Show schedule and next venue", "Mostrar programa y próxima sede"],
  showStandings: ["Gesamtwertung zeigen (Weltcup, IBU-Cup)", "Show overall standings (World Cup, IBU Cup)", "Mostrar la clasificación general (Copa del Mundo, Copa IBU)"],
  nationTitle: ["Meine Nation", "My nation", "Mi país"],
  nationHint: ["Athletinnen und Athleten dieser Nation werden hervorgehoben. Ist niemand unter den ersten Plätzen, steht die oder der Beste darunter.",
    "Athletes of this nation are highlighted. If none is among the top places, the best one is shown below.",
    "Los deportistas de este país se resaltan. Si ninguno está entre los primeros puestos, el mejor aparece debajo."],
  nation: ["Nation", "Nation", "País"],
  noNation: ["Keine", "None", "Ninguno"],
  autoTitle: ["Regelmäßig über die Playlist legen", "Show over the playlist regularly", "Mostrar sobre la lista periódicamente"],
  autoHint: ["Dafür muss auf der Plugins-Seite des Rahmens <b>Allow takeover</b> für Biathlon Live eingeschaltet sein. Ein ausgeschalteter Bildschirm wird nie geweckt.",
    "For this, <b>Allow takeover</b> must be switched on for Biathlon Live on the frame's Plugins page. A screen that is off is never woken.",
    "Para ello, <b>Allow takeover</b> debe estar activado para Biathlon Live en la página de plugins del marco. Una pantalla apagada nunca se enciende."],
  when: ["Wann", "When", "Cuándo"],
  modeOff: ["Nie (nur mit Anzeigen oder in einer Playlist)", "Never (only with Show or in a playlist)", "Nunca (solo con Mostrar o en una lista)"],
  modeAlways: ["Immer, im Takt unten", "Always, at the interval below", "Siempre, con la frecuencia de abajo"],
  modeRaceday: ["Nur an Renntagen", "Only on race days", "Solo en días de carrera"],
  modeLive: ["Nur, während ein Rennen läuft", "Only while a race is running", "Solo mientras hay una carrera en curso"],
  everyMinutes: ["Alle … Minuten", "Every … minutes", "Cada … minutos"],
  forSeconds: ["Für … Sekunden", "For … seconds", "Durante … segundos"],
  from: ["Von … Uhr", "From … o'clock", "Desde las …"],
  to: ["Bis … Uhr", "Until … o'clock", "Hasta las …"],
  alertTitle: ["Beim Rennen", "During a race", "Durante una carrera"],
  alertWhen: ["Sofort anzeigen", "Show right away", "Mostrar al momento"],
  alertOff: ["Nein", "No", "No"],
  alertStart: ["Beim Start eines Rennens", "When a race starts", "Cuando empieza una carrera"],
  alertResult: ["Beim Ergebnis eines Rennens", "When a race result is in", "Cuando hay resultado"],
  alertBoth: ["Beim Start und beim Ergebnis", "At the start and at the result", "Al empezar y con el resultado"],
  alertHint: ["Rennen der gewählten Serien und Kategorien. Während eines Rennens liest das Plugin alle 30 Sekunden den Zwischenstand; das Ergebnis kommt also bis zu einer halben Minute nach dem Zieleinlauf der Letzten.",
    "Races of the selected series and categories. During a race the plugin reads the standings every 30 seconds, so the result arrives up to half a minute after the last athlete finishes.",
    "Carreras de las series y categorías elegidas. Durante una carrera el plugin lee la clasificación cada 30 segundos, así que el resultado llega hasta medio minuto después de que entre en meta el último."],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „Biathlon Live“ anlegen", "Create a “Biathlon Live” playlist", "Crear la lista «Biathlon Live»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, leg sie für mich an", "Yes, create it for me", "Sí, créala por mí"],
  playlistHint: ["Statt (oder zusätzlich zu) der regelmäßigen Anzeige kannst du die Szene Biathlon Live in jede Playlist aufnehmen; dann kommt sie in deren Reihenfolge dran. Die Playlist „Biathlon Live (takeover)“ benutzt das Plugin selbst: lass sie ausgeschaltet.",
    "Instead of (or as well as) the regular display, you can add the Biathlon Live scene to any playlist; it then plays in that playlist's order. The “Biathlon Live (takeover)” playlist is used by the plugin itself: leave it switched off.",
    "En lugar de (o además de) la visualización periódica, puedes añadir la escena Biathlon Live a cualquier lista; entonces aparece en su orden. La lista «Biathlon Live (takeover)» la usa el propio plugin: déjala desactivada."],
  sources: ["Quellen", "Sources", "Fuentes"],
  sourcesHint: ["Alle Daten kommen von <b>biathlonresults.com</b>, dem öffentlichen Datacenter der IBU, ohne Konto. Gebaut nach dem MagicMirror-Modul <a href=\"https://github.com/2hdlockness/MMM-Biathlon\" target=\"_blank\" rel=\"noopener\">MMM-Biathlon</a> von 2hdlockness (MIT-Lizenz). Flaggen: flag-icons (MIT).",
    "All data comes from <b>biathlonresults.com</b>, the public IBU data centre, no account needed. Built after the MagicMirror module <a href=\"https://github.com/2hdlockness/MMM-Biathlon\" target=\"_blank\" rel=\"noopener\">MMM-Biathlon</a> by 2hdlockness (MIT licence). Flags: flag-icons (MIT).",
    "Todos los datos vienen de <b>biathlonresults.com</b>, el centro de datos público de la IBU, sin cuenta. Hecho a partir del módulo de MagicMirror <a href=\"https://github.com/2hdlockness/MMM-Biathlon\" target=\"_blank\" rel=\"noopener\">MMM-Biathlon</a> de 2hdlockness (licencia MIT). Banderas: flag-icons (MIT)."],
  noAnswer: ["Das Plugin antwortet nicht – vermutlich wurde es neu gestartet. Lade die Seite neu.",
    "The plugin is not responding – it was probably restarted. Reload the page.",
    "El plugin no responde; probablemente se ha reiniciado. Recarga la página."],
  restarted: ["Das Plugin wurde neu gestartet (HTTP {status}). Lade die Seite neu.",
    "The plugin was restarted (HTTP {status}). Reload the page.",
    "El plugin se ha reiniciado (HTTP {status}). Recarga la página."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  oclock: ["{time} Uhr", "{time}", "{time} h"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
  noSeries: ["Keine Serie gewählt.", "No series selected.", "No hay ninguna serie elegida."],
  seasonPlace: ["Saison {season}: {place}", "Season {season}: {place}", "Temporada {season}: {place}"],
  noStation: ["keine Station in dieser oder der letzten Saison", "no venue this season or last", "ninguna sede esta temporada ni la anterior"],
  nRaces: ["{n} Rennen, {done} fertig", "{n} races, {done} done", "{n} carreras, {done} terminadas"],
  liveN: [" · {n} live", " · {n} live", " · {n} en vivo"],
  nextAt: ["als Nächstes {place} ab {date}", "next {place} from {date}", "después {place} desde el {date}"],
  notRead: ["noch nicht gelesen", "not read yet", "aún sin leer"],
  showing: ["Biathlon Live wird angezeigt", "Biathlon Live is on screen", "Biathlon Live está en pantalla"],
  until: [" bis {time}", " until {time}", " hasta {time}"],
  playlistRuns: ["Playlist läuft", "Playlist is playing", "La lista está en curso"],
  off: ["aus", "off", "desactivado"],
  installed: ["installiert", "installed", "instalada"],
  notFound: ["nicht gefunden", "not found", "no encontrada"],
  duration: ["{pages} Seiten × {sec} s = {total} s für einen Durchlauf aller Seiten.",
    "{pages} pages × {sec} s = {total} s to go through all pages once.",
    "{pages} páginas × {sec} s = {total} s para recorrer todas las páginas."],
  tooShort: [" Mit {sec} s sind nicht alle Seiten zu sehen.", " With {sec} s not all pages are shown.", " Con {sec} s no se ven todas las páginas."]
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "en";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "en";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([502, 503, 504].includes(response.status)) {
    throw new Error(t("restarted", { status: response.status }));
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "") {
  const node = el("statusNote");
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(iso) {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

function shortDate(iso) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso || "";
  return date.toLocaleDateString(LOCALES[lang], { day: "2-digit", month: "2-digit", year: "numeric" });
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(name, value) {
  try {
    await api("./api/settings", { method: "POST", body: JSON.stringify({ [name]: value }) });
    setStatus(t("saved"), "ok");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

function renderSeries(state) {
  const list = el("seriesList");
  const chosen = state.settings.Series;
  list.innerHTML = "";
  for (const series of state.series) {
    const label = document.createElement("label");
    const box = document.createElement("input");
    box.type = "checkbox";
    box.value = series.id;
    box.checked = chosen.includes(series.id);
    box.addEventListener("change", () => {
      save("Series", box.checked ? [...chosen, series.id] : chosen.filter((x) => x !== series.id));
    });
    const text = document.createElement("span");
    text.textContent = series.name;
    label.append(box, text);
    list.append(label);
  }
  for (const box of el("catList").querySelectorAll("input")) box.checked = state.settings.Categories.includes(box.value);
}

for (const box of el("catList").querySelectorAll("input")) {
  box.addEventListener("change", () => {
    const chosen = [...el("catList").querySelectorAll("input")].filter((b) => b.checked).map((b) => b.value);
    save("Categories", chosen);
  });
}

function renderNations(state) {
  const select = el("Nation");
  if (document.activeElement === select && select.dataset.lang === lang) return;
  select.dataset.lang = lang;
  select.innerHTML = "";
  select.append(new Option(t("noNation"), ""));
  for (const nation of state.nations) select.append(new Option(`${nation.name} (${nation.id})`, nation.id));
  select.value = state.settings.Nation || "";
}
el("Nation").addEventListener("change", (e) => save("Nation", e.target.value));

function renderSources(state) {
  const list = el("sourceList");
  list.innerHTML = "";
  if (!state.sources.length) {
    list.innerHTML = `<li><span class="meta">${t("noSeries")}</span></li>`;
    return;
  }
  for (const row of state.sources) {
    const li = document.createElement("li");
    const dot = row.error ? "bad" : row.at || !row.place ? "" : "idle";
    li.innerHTML = `<span class="name"><span class="dot ${dot}"></span></span><span class="meta"></span>`;
    li.querySelector(".name").append(row.name);
    const parts = [];
    if (row.place) {
      parts.push(row.season ? t("seasonPlace", { season: row.season, place: row.place }) : row.place);
      parts.push(row.at ? t("nRaces", { n: row.races, done: row.done }) + (row.live ? t("liveN", { n: row.live }) : "") : t("notRead"));
    } else {
      parts.push(t("noStation"));
    }
    if (row.next) parts.push(t("nextAt", { place: row.next, date: shortDate(row.nextStart) }));
    li.querySelector(".meta").textContent = parts.join(" · ");
    if (row.error) {
      const err = document.createElement("span");
      err.className = "err";
      err.textContent = row.error;
      li.append(err);
    }
    list.append(li);
  }
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  el("factStatus").textContent = state.status || "—";
  el("factScreen").textContent = state.takeover.active
    ? `${t("showing")}${state.takeover.until ? t("until", { time: clock(state.takeover.until) }) : ""}`
    : t("playlistRuns");
  el("factNext").textContent = s.AutoMode === "off" ? t("off") : state.next ? clock(state.next) : (state.autoNote || "—");
  el("factScene").textContent = state.scene.found ? t("installed") : t("notFound");
  el("factVersion").textContent = state.version;
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Biathlon Live ${state.version}] `);

  const notes = [state.scene.note, state.takeover.note, state.lastError].filter(Boolean);
  if (!editing && notes.length) setStatus(notes.join(" "), state.lastError ? "bad" : "");
  const permission = el("permissionNote");
  permission.textContent = state.permission || "";
  permission.hidden = !state.permission;

  if (!editing) {
    for (const name of NUMBER_FIELDS) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    el("AutoMode").value = s.AutoMode;
    el("RaceAlert").value = s.RaceAlert;
    el("MakePlaylist").value = String(Boolean(s.MakePlaylist));
    el("Language").value = lang;
  }
  renderSeries(state);
  renderNations(state);
  renderSources(state);
  el("playlistNote").textContent = state.ownerPlaylist || "";

  const pages = state.pages || 0;
  const needed = pages * s.PageSeconds;
  el("durationHint").textContent = pages > 1
    ? t("duration", { pages, sec: s.PageSeconds, total: needed }) +
      (s.ShowForSeconds < needed ? t("tooShort", { sec: s.ShowForSeconds }) : "")
    : "";
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
  input.addEventListener("change", () => save(name, Number(input.value)));
}
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save(name, e.target.checked));
el("AutoMode").addEventListener("change", (e) => save("AutoMode", e.target.value));
el("RaceAlert").addEventListener("change", (e) => save("RaceAlert", e.target.value));
el("MakePlaylist").addEventListener("change", (e) => save("MakePlaylist", e.target.value === "true"));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save("Language", e.target.value);
});

for (const [id, path] of [["showButton", "show"], ["cancelButton", "cancel"], ["refreshButton", "refresh"]]) {
  el(id).addEventListener("click", async () => {
    try {
      const result = await api(`./api/${path}`, { method: "POST" });
      setStatus(result.message || "", "busy");
      setTimeout(refresh, 2500);
    } catch (error) {
      setStatus(error.message, "bad");
    }
  });
}

refresh();
setInterval(refresh, 5000);
