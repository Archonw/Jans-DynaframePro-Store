/* Dynaframe's Magic Mirror - die eingebauten Module.
 *
 * Jedes Modul meldet sich mit MagicFrame.register(typ, { render, tick }) an,
 * genau wie ein Zusatzmodul. Die Einstellungen (ctx.config) kommen von der
 * Plugin-Seite, die Daten (ctx.data) vom Plugin.
 */
(function () {
  "use strict";

  const MF = window.MagicFrame;
  const h = MF.helpers;
  const { esc, t } = h;

  // ------------------------------------------------------------ Uhr

  MF.register("clock", {
    render(el, ctx) {
      el.innerHTML = `<div class="clock-time bright ${esc(ctx.config.size || "large")}"></div>
        <div class="clock-date medium normal"></div><div class="clock-week small dimmed"></div>`;
      this.tick(el, ctx);
    },
    tick(el, ctx) {
      const now = new Date();
      const opts = { hour: "2-digit", minute: "2-digit", hour12: !ctx.clock24 };
      let main = now.toLocaleTimeString(h.locale(), opts);
      let suffix = "";
      const ampm = main.match(/\s?(AM|PM|a\.\s?m\.|p\.\s?m\.)$/i);
      if (ampm) { suffix = ampm[1]; main = main.slice(0, ampm.index); }
      const sec = ctx.config.seconds ? `<sup class="dimmed">${String(now.getSeconds()).padStart(2, "0")}</sup>` : "";
      const html = `${esc(main)}${sec}${suffix ? `<span class="ampm dimmed">${esc(suffix)}</span>` : ""}`;
      const time = el.querySelector(".clock-time");
      if (time.innerHTML !== html) time.innerHTML = html;
      const date = ctx.config.date ? now.toLocaleDateString(h.locale(), { weekday: "long", day: "numeric", month: "long", year: "numeric" }) : "";
      el.querySelector(".clock-date").textContent = date;
      el.querySelector(".clock-date").hidden = !date;
      const week = el.querySelector(".clock-week");
      week.hidden = !ctx.config.week;
      if (ctx.config.week) {
        const d = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
        d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
        const n = Math.ceil(((d - Date.UTC(d.getUTCFullYear(), 0, 1)) / 86400000 + 1) / 7);
        week.textContent = t({ de: "Kalenderwoche {n}", en: "Week {n}", es: "Semana {n}" }, { n });
      }
    },
  });

  // ------------------------------------------------------------ Wetter

  const compass = (deg) => {
    const names = { de: ["N", "NO", "O", "SO", "S", "SW", "W", "NW"], en: ["N", "NE", "E", "SE", "S", "SW", "W", "NW"],
      es: ["N", "NE", "E", "SE", "S", "SO", "O", "NO"] }[h.lang()] || ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
    return names[Math.round(((deg % 360) + 360) % 360 / 45) % 8];
  };

  MF.register("weather", {
    // Für Felder in Skins: weather, sunrise, sunset, weatherpicture haben alle denselben Aufbau
    widget(type, ctx) { return ctx.data; },
    render(el, ctx) {
      const d = ctx.data;
      if (!d) { el.innerHTML = `<div class="xsmall dimmed">…</div>`; return true; }
      const c = d.current, imp = d.imperial, cfg = ctx.config;
      const top = [];
      if (cfg.wind && c.wind != null) {
        top.push(`<span>${h.icon("wind")} ${h.number(c.wind)} <small>${imp ? "mph" : "km/h"}</small> ${esc(compass(c.windDir || 0))}</span>`);
      }
      if (cfg.sun && d.sunrise && d.sunset) {
        const now = h.nowSec();
        const next = now < d.sunrise ? ["sunrise", d.sunrise] : now < d.sunset ? ["sunset", d.sunset] : ["sunrise", d.sunrise + 86400];
        top.push(`<span>${h.icon(next[0])} ${esc(h.time(next[1]))}</span>`);
      }
      const lines = [];
      if (cfg.feels && c.feels != null) lines.push(t({ de: "Gefühlt {v}", en: "Feels like {v}", es: "Sensación {v}" }, { v: h.degrees(c.feels, imp) }));
      if (cfg.today && d.max != null) lines.push(`↑ ${h.degrees(d.max, imp)} &nbsp; ↓ ${h.degrees(d.min, imp)}`);
      el.innerHTML = `
        ${top.length ? `<div class="weather-top normal medium">${top.join("")}</div>` : ""}
        <div class="weather-main large light">${h.weatherIcon(c.code, c.isDay)}<span class="bright">${h.degrees(c.temp, imp)}</span></div>
        <div class="weather-text normal medium">${esc(h.weatherText(c.code))}${ctx.place ? `<span class="dimmed"> · ${esc(ctx.place)}</span>` : ""}</div>
        ${lines.map((l) => `<div class="dimmed small">${l}</div>`).join("")}`;
    },
  });

  MF.register("forecast", {
    widget(type, ctx) {
      return ctx.data && { daily: (ctx.data.daily || []).slice(0, ctx.config.days || 5), imperial: ctx.data.imperial };
    },
    render(el, ctx) {
      const d = ctx.data;
      if (!d) { el.innerHTML = `<div class="xsmall dimmed">…</div>`; return true; }
      const days = (d.daily || []).slice(0, ctx.config.days || 5);
      const fade = ctx.config.fade && days.length > 2;
      el.innerHTML = `<table class="small forecast">${days.map((day, i) => {
        const opacity = fade ? Math.max(0.25, 1 - Math.max(0, i - days.length / 2) / (days.length / 2) * 0.75) : 1;
        return `<tr style="opacity:${opacity.toFixed(2)}">
          <td class="day">${esc(h.dayName(day.day + 43200))}</td>
          <td class="icon">${h.weatherIcon(day.code, true)}</td>
          <td class="max bright">${h.degrees(day.max, d.imperial)}</td>
          <td class="min dimmed">${h.degrees(day.min, d.imperial)}</td>
          ${ctx.config.pop ? `<td class="pop dimmed">${day.pop != null && day.pop >= 10 ? `${h.number(day.pop)} %` : ""}</td>` : ""}
        </tr>`;
      }).join("")}</table>`;
    },
  });

  // ------------------------------------------------------------ Regen

  function rainRows(d) {
    const now = h.nowSec();
    const rows = (d.rain || []).filter((r) => r.at + 900 > now).slice(0, 12);
    const wet = (r) => r.mm >= (d.imperial ? 0.004 : 0.1);
    return { rows, wet, anyWet: rows.some(wet) };
  }

  function rainText(d) {
    const { rows, wet, anyWet } = rainRows(d);
    let text;
    if (!rows.length) text = "–";
    else if (!anyWet) text = t({ de: "Trocken bis {time}", en: "Dry until {time}", es: "Seco hasta las {time}" }, { time: h.time(rows[rows.length - 1].at + 900) });
    else if (wet(rows[0])) {
      const end = rows.find((r) => !wet(r));
      text = end ? t({ de: "Regen bis etwa {time}", en: "Rain until about {time}", es: "Lluvia hasta las {time} aprox." }, { time: h.time(end.at) })
        : t({ de: "Regen in den nächsten 3 Stunden", en: "Rain for the next 3 hours", es: "Lluvia las próximas 3 horas" });
    } else {
      const start = rows.find(wet);
      text = t({ de: "Regen ab etwa {time}", en: "Rain from about {time}", es: "Lluvia desde las {time} aprox." }, { time: h.time(start.at) });
    }
    return text;
  }

  MF.register("rain", {
    widget(type, ctx) { return ctx.data && { text: rainText(ctx.data), icon: "umbrella" }; },
    render(el, ctx) {
      const d = ctx.data;
      if (!d) { el.innerHTML = `<div class="xsmall dimmed">…</div>`; return true; }
      const { rows, wet, anyWet } = rainRows(d);
      if (!anyWet && ctx.config.hideDry) return false;
      const text = rainText(d);
      const max = Math.max(d.imperial ? 0.04 : 1, ...rows.map((r) => r.mm));
      el.innerHTML = `<div class="rain-text normal medium">${h.icon("umbrella")} ${esc(text)}</div>
        <div class="rain-bars">${rows.map((r) => `<i style="height:${Math.max(4, Math.round(r.mm / max * 100))}%" class="${wet(r) ? "wet" : ""}"></i>`).join("")}</div>
        <div class="rain-axis xsmall dimmed"><span>${rows.length ? esc(h.time(rows[0].at)) : ""}</span><span>${rows.length ? esc(h.time(rows[rows.length - 1].at + 900)) : ""}</span></div>`;
    },
  });

  // ------------------------------------------------------------ Termine

  function relative(event) {
    const now = h.nowSec();
    if (event.allDay) {
      if (event.start <= now && event.end > now) return t({ de: "Heute", en: "Today", es: "Hoy" });
      return h.dayName(event.start);
    }
    if (event.start <= now) return t({ de: "bis {time}", en: "until {time}", es: "hasta las {time}" }, { time: h.time(event.end) });
    const minutes = Math.round((event.start - now) / 60);
    if (minutes < 60) return t({ de: "in {n} Min.", en: "in {n} min", es: "en {n} min" }, { n: minutes });
    const today = h.dayStart(now) === h.dayStart(event.start);
    return today ? h.time(event.start) : `${h.dayName(event.start)} ${h.time(event.start)}`;
  }

  MF.register("calendar", {
    widget(type, ctx) {
      if (!ctx.data) return null;
      const now = h.nowSec();
      const events = (ctx.data.events || []).filter((e) => e.end > now).slice(0, ctx.config.count || 8);
      return { title: ctx.config.header || "", empty: t({ de: "Keine Termine.", en: "No upcoming events.", es: "No hay citas." }),
        items: events.map((e) => ({ title: e.title, info: relative(e), icon: "calendar" })) };
    },
    render(el, ctx) {
      const d = ctx.data;
      if (!d) { el.innerHTML = `<div class="xsmall dimmed">…</div>`; return true; }
      const now = h.nowSec();
      const events = (d.events || []).filter((e) => e.end > now).slice(0, ctx.config.count || 8);
      if (!events.length) {
        el.innerHTML = `<div class="small dimmed">${esc(t({ de: "Keine Termine.", en: "No upcoming events.", es: "No hay citas." }))}</div>`;
        return true;
      }
      const fade = ctx.config.fade && events.length > 3;
      el.innerHTML = `<table class="small calendar">${events.map((e, i) => {
        const opacity = fade ? Math.max(0.25, 1 - Math.max(0, i - events.length / 2) / (events.length / 2) * 0.75) : 1;
        return `<tr style="opacity:${opacity.toFixed(2)}">
          <td class="symbol">${h.icon("calendar")}</td>
          <td class="title bright">${esc(e.title)}${ctx.config.location && e.location ? `<div class="xsmall dimmed">${esc(e.location)}</div>` : ""}</td>
          <td class="when light">${esc(relative(e))}</td></tr>`;
      }).join("")}</table>`;
    },
    tick(el, ctx) {
      // einmal pro Minute die relativen Zeiten neu schreiben
      if (new Date().getSeconds() === 0) this.render(el, ctx);
    },
  });

  // ------------------------------------------------------------ Nachrichten

  MF.register("news", {
    widget(type, ctx) {
      if (!ctx.data) return null;
      const groups = ctx.data.sources || [{ name: "", items: ctx.data.items || [] }];
      const label = ctx.config.showSource !== false;
      return { items: groups.flatMap((g) => (g.items || []).slice(0, ctx.config.count || 8)
        .map((i) => ({ title: i.title, at: i.at, source: label ? g.name : "" }))) };
    },
    render(el, ctx) {
      const d = ctx.data;
      if (!d) { el.innerHTML = `<div class="xsmall dimmed">…</div>`; return true; }
      // Ältere Daten (vor mehreren Quellen) haben nur items
      const groups = (d.sources || [{ name: "", items: d.items || [] }])
        .map((g) => ({ name: g.name || "", items: (g.items || []).slice(0, ctx.config.count || 8) }));
      const label = ctx.config.showSource !== false && (groups.length > 1 || ctx.config.more);
      const style = ctx.config.style || "rotate";
      el.dataset.style = style;
      if (style === "list") {
        el.innerHTML = groups.map((g) => `${label && g.name ? `<div class="news-src xsmall">${esc(g.name)}</div>` : ""}
          <ul class="news-list small">${g.items.map((i) => `<li class="bright">${esc(i.title)}</li>`).join("")}</ul>`).join("");
      } else if (style === "ticker") {
        const tape = groups.map((g) => (label && g.name ? `<span class="news-src">${esc(g.name)}</span>` : "") +
          g.items.map((i) => `<span>${esc(i.title)}</span>`).join('<span class="sep">•</span>')).join('<span class="sep">•</span>');
        el.innerHTML = `<div class="news-ticker medium"><div class="tape">${tape}<span class="sep">•</span>${tape}<span class="sep">•</span></div></div>`;
        requestAnimationFrame(() => {
          const node = el.querySelector(".tape");
          if (node) node.style.animationDuration = `${Math.max(20, node.scrollWidth / 2 / 70)}s`;
        });
      } else {
        el.innerHTML = `<div class="news-rotate"><div class="news-time xsmall dimmed"></div><div class="news-title medium bright"></div></div>`;
        // Vor den Meldungen jeder Quelle kurz ihr Name
        el._items = groups.flatMap((g) => [
          ...(label && g.name ? [{ intro: g.name }] : []),
          ...g.items.map((i) => ({ ...i, source: g.name })),
        ]);
        el._index = -1;
        el._next = 0;
        this.tick(el, ctx);
      }
    },
    tick(el, ctx) {
      if ((ctx.config.style || "rotate") !== "rotate" || !el._items?.length) return;
      if (Date.now() < el._next) return;
      el._index = (el._index + 1) % el._items.length;
      const item = el._items[el._index];
      const seconds = ctx.config.seconds || 15;
      el._next = Date.now() + (item.intro ? Math.min(5, seconds) : seconds) * 1000;
      const box = el.querySelector(".news-rotate");
      box.classList.add("out");
      setTimeout(() => {
        box.classList.toggle("intro", !!item.intro);
        el.querySelector(".news-title").textContent = item.intro || item.title;
        el.querySelector(".news-time").textContent = item.intro ? "" : item.at ? `${h.dayName(item.at)} ${h.time(item.at)}` : "";
        box.classList.remove("out");
      }, el._index === 0 && !box.dataset.shown ? 0 : 600);
      box.dataset.shown = "1";
    },
  });

  // ------------------------------------------------------------ Abfahrten

  MF.register("departures", {
    widget(type, ctx) {
      if (!ctx.data) return null;
      const now = h.nowSec();
      const rows = (ctx.data.rows || []).filter((r) => r.when > now - 30).slice(0, ctx.config.count || 6);
      return { title: ctx.data.stop || "", empty: t({ de: "Gerade keine Abfahrten.", en: "No departures right now.", es: "Ahora no hay salidas." }),
        items: rows.map((r) => {
          const minutes = Math.round((r.when - now) / 60);
          const when = r.cancelled ? t({ de: "fällt aus", en: "cancelled", es: "cancelado" })
            : minutes <= 0 ? t({ de: "jetzt", en: "now", es: "ahora" })
            : minutes < 60 ? t({ de: "{n} Min.", en: "{n} min", es: "{n} min" }, { n: minutes }) : h.time(r.when);
          return { badge: r.line, title: r.direction, info: when + (r.delayMin > 0 && !r.cancelled ? ` +${r.delayMin}` : "") };
        }) };
    },
    render(el, ctx) {
      const d = ctx.data;
      if (!d) { el.innerHTML = `<div class="xsmall dimmed">…</div>`; return true; }
      el._rows = d.rows || [];
      el.innerHTML = `<div class="dep-stop xsmall dimmed">${esc(d.stop || "")}</div><table class="small departures"></table>`;
      this.tick(el, ctx, true);
    },
    tick(el, ctx, force) {
      const now = h.nowSec();
      if (!force && new Date().getSeconds() % 15) return;
      const walk = (ctx.config.walk || 0) * 60;
      const rows = (el._rows || []).filter((r) => r.when > now - 30).slice(0, ctx.config.count || 6);
      const table = el.querySelector(".departures");
      if (!rows.length) {
        table.innerHTML = `<tr><td class="dimmed">${esc(t({ de: "Gerade keine Abfahrten.", en: "No departures right now.", es: "Ahora no hay salidas." }))}</td></tr>`;
        return;
      }
      table.innerHTML = rows.map((r) => {
        const minutes = Math.round((r.when - now) / 60);
        const when = minutes <= 0 ? t({ de: "jetzt", en: "now", es: "ahora" })
          : minutes < 60 ? t({ de: "{n} Min.", en: "{n} min", es: "{n} min" }, { n: minutes }) : h.time(r.when);
        const late = r.delayMin > 0 ? `<span class="late">+${r.delayMin}</span>` : "";
        const gone = walk && r.when - now < walk;
        const cls = [r.cancelled ? "cancelled" : "", gone ? "gone" : ""].join(" ");
        return `<tr class="${cls}">
          <td class="line"><span class="badge k-${esc(r.kind)}">${esc(r.line)}</span></td>
          <td class="dir bright">${esc(r.direction)}</td>
          <td class="when">${r.cancelled ? esc(t({ de: "fällt aus", en: "cancelled", es: "cancelado" })) : `${esc(when)} ${late}`}</td></tr>`;
      }).join("");
    },
  });

  // ------------------------------------------------------------ Sprüche

  const PREFIX = { morning: ["morgens", "morning", "mañana"], afternoon: ["mittags", "nachmittags", "afternoon", "tarde"],
    evening: ["abends", "evening", "noche"], night: ["nachts", "night", "madrugada"] };

  function partOfDay() {
    const hour = new Date().getHours();
    return hour >= 5 && hour < 12 ? "morning" : hour >= 12 && hour < 18 ? "afternoon" : hour >= 18 && hour < 23 ? "evening" : "night";
  }

  function compliments(ctx) {
    const part = partOfDay();
    const pool = [];
    String(ctx.config.own || "").split("\n").map((l) => l.trim()).filter(Boolean).forEach((line) => {
      const m = line.match(/^([^\s:]+):\s*(.+)$/);
      if (m) {
        const key = Object.keys(PREFIX).find((k) => PREFIX[k].includes(m[1].toLowerCase()));
        if (key) { if (key === part) pool.push(m[2]); return; }
      }
      pool.push(line);
    });
    if (ctx.config.builtin !== false || !pool.length) {
      const c = ctx.compliments || {};
      pool.push(...(c.any || []), ...(c[part] || []));
    }
    return pool;
  }

  MF.register("compliments", {
    // Im Feld wechselt der Spruch im eingestellten Takt, aber ohne bei jedem Neuzeichnen zu springen
    widget(type, ctx) {
      const pool = compliments(ctx);
      const seconds = Math.max(10, ctx.config.seconds || 30);
      return pool.length ? { text: pool[Math.floor(Date.now() / 1000 / seconds) % pool.length] } : null;
    },
    render(el, ctx) {
      el.innerHTML = `<div class="compliment thin bright ${esc(ctx.config.size || "large")}"></div>`;
      el._next = 0;
      el._last = "";
      this.tick(el, ctx);
    },
    tick(el, ctx) {
      if (Date.now() < el._next) return;
      el._next = Date.now() + (ctx.config.seconds || 30) * 1000;
      const pool = compliments(ctx).filter((c) => c !== el._last);
      const text = pool.length ? pool[Math.floor(Math.random() * pool.length)] : el._last;
      el._last = text;
      const node = el.querySelector(".compliment");
      node.classList.add("out");
      setTimeout(() => { node.textContent = text; node.classList.remove("out"); }, node.textContent ? 600 : 0);
    },
  });

  // ------------------------------------------------------------ Unwetterwarnungen

  MF.register("warnings", {
    widget(type, ctx) {
      if (!ctx.data) return null;
      const min = Number(ctx.config.level || 2);
      const now = h.nowSec();
      const alerts = (ctx.data.alerts || []).filter((a) => a.level >= min && (!a.until || a.until > now)).sort((a, b) => b.level - a.level);
      const none = t({ de: "Keine Warnungen", en: "No warnings", es: "Sin avisos" });
      if (type === "text") return { text: alerts.length ? alerts[0].event || alerts[0].title : none, icon: alerts.length ? "warn" : "" };
      return { empty: none, items: alerts.slice(0, 4).map((a) => ({ title: a.event || a.title, icon: "warn",
        info: a.until ? t({ de: "bis {time}", en: "until {time}", es: "hasta las {time}" }, { time: h.time(a.until) }) : "" })) };
    },
    render(el, ctx) {
      const d = ctx.data;
      if (!d) return false;
      const min = Number(ctx.config.level || 2);
      const now = h.nowSec();
      const alerts = (d.alerts || []).filter((a) => a.level >= min && (!a.until || a.until > now))
        .sort((a, b) => b.level - a.level);
      if (!alerts.length) return false;
      el.innerHTML = alerts.slice(0, 3).map((a) => `<div class="warning level-${a.level}">
        ${h.icon("warn")}<div><div class="medium bright">${esc(a.event || a.title)}</div>
        <div class="xsmall dimmed">${esc(a.title)}${a.until ? ` · ${esc(t({ de: "bis {time}", en: "until {time}", es: "hasta las {time}" }, { time: `${h.dayName(a.until)} ${h.time(a.until)}` }))}` : ""}</div></div></div>`).join("");
    },
  });

  // ------------------------------------------------------------ Webseite

  MF.register("webpage", {
    render(el, ctx) {
      const url = String(ctx.config.url || "");
      if (!/^https?:\/\/.+/.test(url)) return false;
      const zoom = (ctx.config.zoom || 100) / 100;
      el.innerHTML = `<div class="webpage" style="height:${ctx.config.height || 30}vh"><iframe src="${esc(url)}"
        style="width:${100 / zoom}%;height:${100 / zoom}%;transform:scale(${zoom})" referrerpolicy="no-referrer"
        sandbox="allow-scripts allow-same-origin allow-forms"></iframe></div>`;
      el._reloadAt = ctx.config.reload ? Date.now() + ctx.config.reload * 60000 : 0;
    },
    tick(el, ctx) {
      if (el._reloadAt && Date.now() > el._reloadAt) {
        el._reloadAt = Date.now() + ctx.config.reload * 60000;
        const frame = el.querySelector("iframe");
        if (frame) frame.src = frame.src;
      }
    },
  });
})();
