"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/PlaylistMusic/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["FadeSeconds", "QuietPercent"];
const CHECK_FIELDS = ["Enabled", "SkipIfBusy", "SpotifyEnabled", "SpotifyDiscoverable"];
const SELECT_FIELDS = ["EndMode", "OnVideo", "OnTakeover"];
const TEXT_FIELDS = ["TimeFrom", "TimeTo", "SpotifyName", "JellyfinUrl", "JellyfinUser", "MaUrl"];
let current = null;
let editing = false;

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["Playlist-Musik", "Playlist Music", "Música para listas"],
  lede: ["Musik, solange eine bestimmte Playlist läuft: jede Playlist mit ihrer eigenen Musik, aus dem Internetradio, Jellyfin, einem Ordner, Spotify oder Music Assistant, am Rahmen oder auf einem anderen Lautsprecher. Jede Änderung hier wird sofort gespeichert.",
    "Music while a certain playlist is running: each playlist with its own music, from internet radio, Jellyfin, a folder, Spotify or Music Assistant, on the frame or on another speaker. Every change here is saved immediately.",
    "Música mientras suena una lista concreta: cada lista con su propia música, de radio por internet, Jellyfin, una carpeta, Spotify o Music Assistant, en el marco o en otro altavoz. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  stopNow: ["Musik jetzt stoppen", "Stop music now", "Parar la música ahora"],
  factPlaylist: ["Playlist", "Playlist", "Lista"],
  factTitle: ["Gerade", "Now", "Ahora"],
  factTarget: ["Lautsprecher", "Speaker", "Altavoz"],
  factSound: ["Ton am Rahmen", "Sound on the frame", "Sonido en el marco"],
  factVersion: ["Version", "Version", "Versión"],
  rulesTitle: ["Musik je Playlist", "Music per playlist", "Música por lista"],
  rulesHint: ["Schalte die Playlists ein, zu denen Musik laufen soll, und wähle bei „Einstellen“, was und wo. „Alle anderen Playlists“ gilt für jede Playlist ohne eigene Musik, auch für einen Quick Mix.",
    "Switch on the playlists that should have music and choose what and where under “Set up”. “All other playlists” applies to every playlist without its own music, also to a Quick Mix.",
    "Activa las listas que deben tener música y elige qué y dónde en «Configurar». «Todas las demás listas» vale para cada lista sin música propia, también para un Quick Mix."],
  enabled: ["Musik zu Playlists abspielen", "Play music with playlists", "Reproducir música con las listas"],
  allOthers: ["Alle anderen Playlists", "All other playlists", "Todas las demás listas"],
  setup: ["Einstellen", "Set up", "Configurar"],
  close: ["Schließen", "Close", "Cerrar"],
  noMusic: ["keine Musik gewählt", "no music chosen", "sin música elegida"],
  source: ["Quelle", "Source", "Fuente"],
  srcRadio: ["Internetradio", "Internet radio", "Radio por internet"],
  srcUrl: ["Eigene Stream-Adresse", "Own stream address", "Dirección de stream propia"],
  srcFolder: ["Ordner auf dem Rahmen", "Folder on the frame", "Carpeta en el marco"],
  target: ["Lautsprecher", "Speaker", "Altavoz"],
  search: ["Suchen", "Search", "Buscar"],
  searchRadio: ["Sender suchen …", "Search stations …", "Buscar emisoras …"],
  searchJellyfin: ["Playlist, Album, Interpret oder Genre …", "Playlist, album, artist or genre …", "Lista, álbum, artista o género …"],
  searchSpotify: ["Deine Playlists filtern oder Spotify-Link einfügen …", "Filter your playlists or paste a Spotify link …", "Filtra tus listas o pega un enlace de Spotify …"],
  searchMa: ["In Music Assistant suchen …", "Search Music Assistant …", "Buscar en Music Assistant …"],
  searchFolder: ["Pfad, z. B. /mnt/nas/Musik", "Path, e.g. /mnt/nas/Music", "Ruta, p. ej. /mnt/nas/Musica"],
  hintRadio: ["Ohne Suchwort: die beliebtesten Sender. Daten von radio-browser.info.", "Without a search word: the most popular stations. Data from radio-browser.info.", "Sin palabra de búsqueda: las emisoras más populares. Datos de radio-browser.info."],
  hintJellyfin: ["Ohne Suchwort: deine Playlists. „Alle Musik“ spielt deine ganze Bibliothek zufällig.", "Without a search word: your playlists. “All music” plays your whole library at random.", "Sin palabra de búsqueda: tus listas. «Toda la música» reproduce toda tu biblioteca al azar."],
  hintSpotify: ["Deine Spotify-Playlists. Fremde Playlists, Alben oder Interpreten: in Spotify Teilen > Link kopieren und hier einfügen.", "Your Spotify playlists. Other playlists, albums or artists: in Spotify Share > Copy link and paste it here.", "Tus listas de Spotify. Otras listas, álbumes o artistas: en Spotify Compartir > Copiar enlace y pégalo aquí."],
  hintMa: ["Ohne Suchwort: deine Playlists in Music Assistant.", "Without a search word: your playlists in Music Assistant.", "Sin palabra de búsqueda: tus listas en Music Assistant."],
  hintFolder: ["Ordner antippen zum Öffnen, dann „Diesen Ordner nehmen“. Unterordner werden mitgespielt.", "Tap a folder to open it, then “Use this folder”. Subfolders are played too.", "Toca una carpeta para abrirla y luego «Usar esta carpeta». Las subcarpetas también suenan."],
  useFolder: ["Diesen Ordner nehmen", "Use this folder", "Usar esta carpeta"],
  streamUrl: ["Stream-Adresse (MP3, AAC, HLS, .m3u oder .pls)", "Stream address (MP3, AAC, HLS, .m3u or .pls)", "Dirección del stream (MP3, AAC, HLS, .m3u o .pls)"],
  chosen: ["Gewählt: {what}", "Chosen: {what}", "Elegido: {what}"],
  nothingChosen: ["Noch nichts gewählt.", "Nothing chosen yet.", "Aún no hay nada elegido."],
  volume: ["Lautstärke", "Volume", "Volumen"],
  shuffle: ["Zufällige Reihenfolge", "Random order", "Orden aleatorio"],
  preview: ["Probehören", "Preview", "Probar"],
  stop: ["Stopp", "Stop", "Parar"],
  remove: ["Musik entfernen", "Remove music", "Quitar música"],
  searching: ["Suche …", "Searching …", "Buscando …"],
  noResults: ["Nichts gefunden.", "Nothing found.", "No se ha encontrado nada."],
  loadingTargets: ["Lautsprecher werden geladen …", "Loading speakers …", "Cargando altavoces …"],
  allMusic: ["Alle Musik", "All music", "Toda la música"],
  liked: ["Lieblingssongs", "Liked songs", "Canciones que te gustan"],
  kindPlaylist: ["Playlist", "Playlist", "Lista"], kindMusicAlbum: ["Album", "Album", "Álbum"], kindalbum: ["Album", "Album", "Álbum"],
  kindMusicArtist: ["Interpret", "Artist", "Artista"], kindartist: ["Interpret", "Artist", "Artista"],
  kindMusicGenre: ["Genre", "Genre", "Género"], kindradio: ["Radio", "Radio", "Radio"], kindtrack: ["Titel", "Track", "Canción"],
  kindplaylist: ["Playlist", "Playlist", "Lista"],
  behaviourTitle: ["Verhalten", "Behaviour", "Comportamiento"],
  endMode: ["Wenn die Playlist endet oder wechselt", "When the playlist ends or changes", "Cuando la lista termina o cambia"],
  endFade: ["Musik ausblenden", "Fade the music out", "Atenuar la música"],
  endContinue: ["Weiterlaufen lassen, bis andere Musik dran ist", "Keep playing until other music is due", "Seguir sonando hasta que toque otra música"],
  fadeSeconds: ["Ein- und Ausblenden (Sekunden)", "Fade in and out (seconds)", "Entrada y salida gradual (segundos)"],
  onVideo: ["Bei Videos in der Playlist", "For videos in the playlist", "Con vídeos en la lista"],
  onTakeover: ["Wenn ein anderes Plugin etwas zeigt (z. B. Tor, Türklingel)", "When another plugin shows something (e.g. goal, doorbell)", "Cuando otro plugin muestra algo (p. ej. gol, timbre)"],
  holdPause: ["Musik pausieren", "Pause the music", "Pausar la música"],
  holdQuieter: ["Musik leiser", "Music quieter", "Música más baja"],
  holdIgnore: ["Weiterspielen", "Keep playing", "Seguir sonando"],
  quietPercent: ["„Leiser“ heißt (Prozent der Lautstärke)", "“Quieter” means (percent of the volume)", "«Más bajo» significa (porcentaje del volumen)"],
  skipIfBusy: ["Nicht starten, wenn auf dem Lautsprecher schon Musik läuft", "Don’t start if music is already playing on the speaker", "No empezar si ya suena música en el altavoz"],
  timeTitle: ["Nur zu diesen Uhrzeiten", "Only at these times", "Solo a estas horas"],
  timeFrom: ["Von", "From", "Desde"],
  timeTo: ["Bis", "To", "Hasta"],
  timeHint: ["Beide leer = immer. Schläft der Rahmen oder stoppt die Wiedergabe, endet die Musik immer.", "Both empty = always. If the frame sleeps or playback stops, the music always ends.", "Ambos vacíos = siempre. Si el marco duerme o se detiene la reproducción, la música termina siempre."],
  spotifyHint: ["Der Rahmen wird zum Spotify-Lautsprecher und kann auch deine anderen Spotify-Geräte (Sonos, Echo, Fernseher …) starten. Braucht Spotify Premium, aber keinen Entwicklerschlüssel.",
    "The frame becomes a Spotify speaker and can also start your other Spotify devices (Sonos, Echo, TV …). Needs Spotify Premium, but no developer key.",
    "El marco se convierte en un altavoz de Spotify y también puede iniciar tus otros dispositivos de Spotify (Sonos, Echo, televisor …). Necesita Spotify Premium, pero ninguna clave de desarrollador."],
  spotifyEnabled: ["Spotify verwenden", "Use Spotify", "Usar Spotify"],
  spotifyName: ["Name des Rahmens in Spotify", "Name of the frame in Spotify", "Nombre del marco en Spotify"],
  spotifyDiscoverable: ["In der Spotify-App als Lautsprecher zeigen", "Show as a speaker in the Spotify app", "Mostrar como altavoz en la app de Spotify"],
  pairText: ["Einmal koppeln: Öffne diesen Link auf dem Handy oder Computer und bestätige mit deinem Spotify-Konto. Falls nach einem Code gefragt wird:",
    "Pair once: open this link on your phone or computer and confirm with your Spotify account. If you are asked for a code:",
    "Vincular una vez: abre este enlace en el móvil o el ordenador y confirma con tu cuenta de Spotify. Si te piden un código:"],
  spotifyForget: ["Abmelden und neu koppeln", "Sign out and pair again", "Cerrar sesión y volver a vincular"],
  spotifyHow: ["Wie das funktioniert", "How it works", "Cómo funciona"],
  spotifyHowText: ["Beim Einschalten lädt das Plugin einmal das freie Programm <a href=\"https://github.com/devgianlu/go-librespot\" target=\"_blank\" rel=\"noopener\">go-librespot</a> (GPL-3.0) von GitHub. Danach erscheint hier ein Link mit Code; nach dem Bestätigen bleibt der Rahmen angemeldet. Deine Playlists stehen dann bei „Einstellen“ zur Auswahl, du kannst aber auch einen Spotify-Link einfügen (Teilen &gt; Link kopieren).",
    "When switched on, the plugin downloads the free program <a href=\"https://github.com/devgianlu/go-librespot\" target=\"_blank\" rel=\"noopener\">go-librespot</a> (GPL-3.0) from GitHub once. Then a link with a code appears here; after you confirm, the frame stays signed in. Your playlists are then listed under “Set up”, and you can also paste a Spotify link (Share &gt; Copy link).",
    "Al activarlo, el plugin descarga una vez el programa libre <a href=\"https://github.com/devgianlu/go-librespot\" target=\"_blank\" rel=\"noopener\">go-librespot</a> (GPL-3.0) de GitHub. Después aparece aquí un enlace con un código; tras confirmarlo, el marco queda conectado. Tus listas aparecen en «Configurar» y también puedes pegar un enlace de Spotify (Compartir &gt; Copiar enlace)."],
  spOff: ["Aus.", "Off.", "Apagado."],
  spInstalling: ["Lade go-librespot …", "Downloading go-librespot …", "Descargando go-librespot …"],
  spStarting: ["Startet …", "Starting …", "Iniciando …"],
  spPairing: ["Wartet auf die Kopplung.", "Waiting for pairing.", "Esperando la vinculación."],
  spReady: ["Angemeldet als {user}.", "Signed in as {user}.", "Conectado como {user}."],
  spError: ["Problem: {note}", "Problem: {note}", "Problema: {note}"],
  jellyfinHint: ["Für Musik von deinem Jellyfin-Server. Ist das Plugin Jellyfin Now Playing eingerichtet, nimmt Playlist-Musik dessen Zugang, solange die Felder hier leer sind.",
    "For music from your Jellyfin server. If the Jellyfin Now Playing plugin is set up, Playlist Music uses its access as long as the fields here are empty.",
    "Para música de tu servidor Jellyfin. Si el plugin Jellyfin Now Playing está configurado, Música para listas usa su acceso mientras estos campos estén vacíos."],
  serverUrl: ["Adresse", "Address", "Dirección"],
  apiKey: ["API-Schlüssel", "API key", "Clave API"],
  user: ["Benutzer (leer = erster Admin)", "User (empty = first admin)", "Usuario (vacío = primer admin)"],
  test: ["Verbindung testen", "Test connection", "Probar conexión"],
  keyHow: ["So bekommst du einen API-Schlüssel", "How to get an API key", "Cómo obtener una clave API"],
  jellyfinHow: ["In Jellyfin unter <b>Dashboard &gt; API-Schlüssel &gt; +</b>. Der Schlüssel bleibt im Plugin auf dem Rahmen.",
    "In Jellyfin under <b>Dashboard &gt; API Keys &gt; +</b>. The key stays in the plugin on the frame.",
    "En Jellyfin en <b>Panel &gt; Claves API &gt; +</b>. La clave se queda en el plugin del marco."],
  fromOther: ["aus Jellyfin Now Playing", "from Jellyfin Now Playing", "de Jellyfin Now Playing"],
  maHint: ["Freiwillig. Damit spielen alle Quellen und Lautsprecher, die du in Music Assistant eingerichtet hast (z. B. YouTube Music, Spotify, Sonos, AirPlay, Chromecast).",
    "Optional. This plays all sources and speakers you set up in Music Assistant (e.g. YouTube Music, Spotify, Sonos, AirPlay, Chromecast).",
    "Opcional. Así suenan todas las fuentes y altavoces que configuraste en Music Assistant (p. ej. YouTube Music, Spotify, Sonos, AirPlay, Chromecast)."],
  maToken: ["Token", "Token", "Token"],
  maHow: ["So bekommst du ein Token", "How to get a token", "Cómo obtener un token"],
  maHowText: ["In Music Assistant unter <b>Einstellungen &gt; Profil</b> (bzw. <b>Benutzer</b>) ein langlebiges Token (long-lived token) anlegen und hier einfügen. Die Adresse ist die der Music-Assistant-Oberfläche, meist mit Port 8095.",
    "In Music Assistant under <b>Settings &gt; Profile</b> (or <b>Users</b>) create a long-lived token and paste it here. The address is the one of the Music Assistant web interface, usually with port 8095.",
    "En Music Assistant en <b>Ajustes &gt; Perfil</b> (o <b>Usuarios</b>) crea un token de larga duración y pégalo aquí. La dirección es la de la interfaz de Music Assistant, normalmente con el puerto 8095."],
  keySaved: ["gespeichert – leer lassen zum Behalten", "saved – leave empty to keep", "guardado – déjalo vacío para conservarlo"],
  keyMissing: ["noch keiner", "none yet", "aún ninguno"],
  testing: ["Teste …", "Testing …", "Probando …"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status}).", "Error (HTTP {status}).", "Error (HTTP {status})."],
  soundOk: ["{sink}", "{sink}", "{sink}"],
  soundMissing: ["kein Tonausgang", "no sound output", "sin salida de sonido"],
  noFfmpeg: ["ffmpeg fehlt", "ffmpeg missing", "falta ffmpeg"],
  frame: ["Der Rahmen", "The frame", "El marco"],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or wishes?", "¿Problemas, preguntas o deseos?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Write an issue on GitHub", "Escribe un issue en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", ", with plugin name and version.", ", con el nombre del plugin y la versión."],
};

const LANGS = ["de", "en", "es"];
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  if (editor) { translate(editor.node); sourceUi(); }
}

function translate(root) {
  for (const node of root.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of root.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", node = "statusNote") {
  const target = typeof node === "string" ? el(node) : node;
  target.textContent = text;
  target.className = `${target.className.split(" ").filter((c) => !["ok", "bad", "busy"].includes(c)).join(" ")}${tone ? " " + tone : ""}`;
}

const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes, note = "statusNote") {
  try {
    const result = await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    setStatus(t("saved"), "ok", note);
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad", note);
    return [];
  }
}

// ------------------------------------------------------------ Regeln

const SOURCE_NAMES = { radio: "srcRadio", url: "srcUrl", folder: "srcFolder" };
const sourceName = (source) => SOURCE_NAMES[source] ? t(SOURCE_NAMES[source]) : ({ jellyfin: "Jellyfin", spotify: "Spotify", ma: "Music Assistant" })[source] || "";

function ruleFor(key) {
  return (current?.settings.Rules || {})[key] || null;
}

function musicLabel(rule) {
  if (!rule || !rule.ref) return "";
  if (rule.kind === "AllMusic") return t("allMusic");
  if (rule.kind === "liked") return t("liked");
  return rule.label || rule.ref;
}

function summary(rule) {
  if (!rule || !rule.ref) return null;
  const target = !rule.target || rule.target === "frame" ? t("frame") : (rule.targetLabel || rule.target);
  return `${sourceName(rule.source)}: ${musicLabel(rule)} → ${target} · ${rule.volume} %`;
}

function rows() {
  const list = [{ key: "*", name: t("allOthers") }];
  for (const p of current?.playlists || []) list.push({ key: `pl:${p.id}`, name: p.name });
  // Regeln für Playlists, die es nicht mehr gibt, trotzdem zeigen (zum Entfernen)
  for (const key of Object.keys(current?.settings.Rules || {})) {
    if (!list.some((r) => r.key === key)) list.push({ key, name: ruleFor(key).playlistName || key, gone: true });
  }
  return list;
}

let lastRowsSig = "";
function renderRules() {
  const box = el("rules");
  const list = rows();
  const playingKey = current?.now?.key;
  const sig = JSON.stringify([lang, list, current?.settings.Rules, playingKey, editor?.key]);
  if (sig === lastRowsSig) return;
  lastRowsSig = sig;
  const editorNode = editor ? editor.node : null;
  if (editorNode) editorNode.remove();
  box.innerHTML = list.map((row) => {
    const rule = ruleFor(row.key);
    const text = summary(rule);
    const on = rule?.on;
    return `<div class="rule${on ? " on" : ""}${playingKey === row.key ? " playing" : ""}" data-key="${esc(row.key)}">
      <div class="rule-head">
        <input type="checkbox" class="rule-on" ${on ? "checked" : ""} aria-label="${esc(row.name)}">
        <span class="name">${esc(row.name)}${row.gone ? " ⚠" : ""}</span>
        <span class="what${text ? "" : " none"}">${esc(text || t("noMusic"))}</span>
        <button type="button" class="secondary rule-edit">${esc(editor?.key === row.key ? t("close") : t("setup"))}</button>
      </div>
    </div>`;
  }).join("");
  if (editorNode) {
    const host = box.querySelector(`.rule[data-key="${CSS.escape(editor.key)}"]`);
    if (host) host.appendChild(editorNode);
    else editor = null;
  }
}

el("rules").addEventListener("change", async (event) => {
  if (!event.target.classList.contains("rule-on")) return;
  const key = event.target.closest(".rule").dataset.key;
  const row = rows().find((r) => r.key === key);
  await saveRule(key, { on: event.target.checked, playlistName: key === "*" ? "" : row?.name || "" });
  if (event.target.checked && !ruleFor(key)?.ref) openEditor(key);
});

el("rules").addEventListener("click", (event) => {
  const button = event.target.closest(".rule-edit");
  if (!button) return;
  const key = button.closest(".rule").dataset.key;
  if (editor?.key === key) closeEditor();
  else openEditor(key);
});

async function saveRule(key, rule, note = "rulesNote") {
  try {
    const result = await api("./api/rule", { method: "POST", body: JSON.stringify({ key, rule }) });
    if (current) {
      current.settings.Rules = { ...(current.settings.Rules || {}) };
      if (result.rule) current.settings.Rules[key] = result.rule;
      else delete current.settings.Rules[key];
    }
    setStatus(t("saved"), "ok", note);
    renderRules();
    if (editor && editor.key === key) showChosen();
    return result.rule;
  } catch (error) {
    setStatus(error.message, "bad", note);
    return null;
  }
}

// ------------------------------------------------------------ Editor

let editor = null;   // { key, node, folder }
const q = (cls) => editor.node.querySelector(cls);

function openEditor(key) {
  closeEditor();
  const node = el("editorTemplate").content.firstElementChild.cloneNode(true);
  translate(node);
  editor = { key, node, folder: "" };
  lastRowsSig = "";
  renderRules();
  const rule = ruleFor(key) || {};
  q(".ed-source").value = rule.source || "radio";
  q(".ed-volume").value = rule.volume || 60;
  q(".ed-volval").textContent = rule.volume || 60;
  q(".ed-shuffle").checked = rule.shuffle !== false;
  q(".ed-url").value = rule.source === "url" ? rule.ref || "" : "";
  editor.folder = rule.source === "folder" ? rule.ref || "" : "";
  wireEditor();
  sourceUi();
  showChosen();
  loadTargets();
  runSearch(rule.source === "folder" ? editor.folder : "");
}

function closeEditor() {
  if (!editor) return;
  editor.node.remove();
  editor = null;
  lastRowsSig = "";
  renderRules();
}

function editorRule() {
  return ruleFor(editor.key) || {};
}

function sourceUi() {
  if (!editor) return;
  const source = q(".ed-source").value;
  q(".ed-urlfield").hidden = source !== "url";
  q(".ed-search").hidden = source === "url";
  q(".ed-shufflefield").hidden = ["radio", "url"].includes(source);
  const placeholder = { radio: "searchRadio", jellyfin: "searchJellyfin", spotify: "searchSpotify", ma: "searchMa", folder: "searchFolder" }[source];
  const hint = { radio: "hintRadio", jellyfin: "hintJellyfin", spotify: "hintSpotify", ma: "hintMa", folder: "hintFolder" }[source];
  if (placeholder) { q(".ed-query").dataset.i18nPlaceholder = placeholder; q(".ed-query").placeholder = t(placeholder); }
  q(".ed-searchhint").textContent = hint ? t(hint) : "";
}

function showChosen() {
  if (!editor) return;
  const rule = editorRule();
  const what = musicLabel(rule);
  q(".ed-chosen").innerHTML = what ? esc(t("chosen", { what: "" })) + `<b>${esc(what)}</b>` : esc(t("nothingChosen"));
}

async function loadTargets() {
  const select = q(".ed-target");
  const source = q(".ed-source").value;
  const rule = editorRule();
  select.innerHTML = `<option>${esc(t("loadingTargets"))}</option>`;
  try {
    const result = await api(`./api/targets?source=${encodeURIComponent(source)}`);
    if (!editor) return;
    const list = result.targets || [];
    const chosen = rule.target || "frame";
    if (chosen && !list.some((x) => x.id === chosen) && rule.source === source && rule.targetLabel) {
      list.push({ id: chosen, label: rule.targetLabel + " (?)" });
    }
    select.innerHTML = list.map((x) => `<option value="${esc(x.id)}">${esc(x.label)}</option>`).join("");
    select.value = list.some((x) => x.id === chosen) ? chosen : (list[0]?.id || "");
    if (result.errors?.length) setStatus(result.errors.join(" "), "bad", q(".ed-note"));
    // Gewählter Lautsprecher passt nicht (mehr) zur Quelle: ersten nehmen und speichern
    if (select.value && select.value !== rule.target && rule.source === source) {
      saveRule(editor.key, { target: select.value, targetLabel: select.selectedOptions[0]?.textContent || "" }, q(".ed-note"));
    }
  } catch (error) {
    select.innerHTML = "";
    setStatus(error.message, "bad", q(".ed-note"));
  }
}

let searchToken = 0;
async function runSearch(query) {
  const source = q(".ed-source").value;
  if (source === "url") return;
  const box = q(".ed-results");
  const token = ++searchToken;
  box.innerHTML = `<p class="hint">${esc(t("searching"))}</p>`;
  try {
    const result = await api(`./api/search?source=${encodeURIComponent(source)}&q=${encodeURIComponent(query || "")}`);
    if (!editor || token !== searchToken) return;
    renderResults(source, result.items || [], query);
  } catch (error) {
    if (editor && token === searchToken) box.innerHTML = `<p class="status bad">${esc(error.message)}</p>`;
  }
}

function renderResults(source, items, query) {
  const box = q(".ed-results");
  const rule = editorRule();
  if (source === "folder") {
    editor.folder = query || "";
    q(".ed-query").value = editor.folder;
    const use = editor.folder ? `<button type="button" class="ed-usefolder" data-ref="${esc(editor.folder)}"><b>${esc(t("useFolder"))}</b><span class="sub">${esc(editor.folder)}</span></button>` : "";
    box.innerHTML = use + items.map((x) => `<button type="button" class="ed-open" data-ref="${esc(x.ref)}">📁 ${esc(x.label)}</button>`).join("");
    return;
  }
  if (!items.length) { box.innerHTML = `<p class="hint">${esc(t("noResults"))}</p>`; return; }
  box.innerHTML = items.map((x, i) => {
    const kindKey = "kind" + (x.kind || "");
    const label = x.kind === "AllMusic" ? t("allMusic") : x.kind === "liked" ? t("liked") : x.label;
    const sub = [I18N[kindKey] ? t(kindKey) : "", x.sub].filter(Boolean).join(" · ");
    const pressed = rule.source === source && rule.ref === x.ref;
    return `<button type="button" class="ed-pick" data-i="${i}" aria-pressed="${pressed}"><b>${esc(label)}</b>${sub ? `<span class="sub">${esc(sub)}</span>` : ""}</button>`;
  }).join("");
  box._items = items;
}

function wireEditor() {
  q(".ed-source").addEventListener("change", async () => {
    sourceUi();
    q(".ed-query").value = "";
    q(".ed-results").innerHTML = "";
    await saveRule(editor.key, { source: q(".ed-source").value, ref: "", label: "", kind: "", stationId: "" }, q(".ed-note"));
    loadTargets();
    runSearch("");
  });
  q(".ed-go").addEventListener("click", () => runSearch(q(".ed-query").value));
  q(".ed-query").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); runSearch(q(".ed-query").value); } });
  q(".ed-results").addEventListener("click", async (e) => {
    const pick = e.target.closest(".ed-pick");
    const open = e.target.closest(".ed-open");
    const use = e.target.closest(".ed-usefolder");
    if (open) { runSearch(open.dataset.ref); return; }
    if (use) {
      const ref = use.dataset.ref;
      const name = ref.split("/").filter(Boolean).pop() || ref;
      await saveRule(editor.key, { source: "folder", ref, label: name, kind: "folder", on: true, playlistName: currentRowName(), ...targetChoice() }, q(".ed-note"));
      try {
        const count = await api(`./api/foldercount?path=${encodeURIComponent(ref)}`);
        setStatus(count.message, count.count > 0 ? "ok" : "bad", q(".ed-note"));
      } catch (_) { /* egal */ }
      return;
    }
    if (!pick) return;
    const item = q(".ed-results")._items[Number(pick.dataset.i)];
    if (!item) return;
    await saveRule(editor.key, { source: q(".ed-source").value, ref: item.ref, label: item.label, kind: item.kind || "", stationId: item.id || "", on: true, playlistName: currentRowName(), ...targetChoice() }, q(".ed-note"));
    for (const b of q(".ed-results").querySelectorAll(".ed-pick")) b.setAttribute("aria-pressed", String(b === pick));
  });
  q(".ed-url").addEventListener("change", (e) => {
    const ref = e.target.value.trim();
    saveRule(editor.key, { source: "url", ref, label: ref.replace(/^https?:\/\//, "").slice(0, 80), kind: "url", on: Boolean(ref), playlistName: currentRowName(), ...targetChoice() }, q(".ed-note"));
  });
  q(".ed-target").addEventListener("change", (e) => {
    saveRule(editor.key, { target: e.target.value, targetLabel: e.target.selectedOptions[0]?.textContent || "" }, q(".ed-note"));
  });
  q(".ed-volume").addEventListener("input", (e) => { q(".ed-volval").textContent = e.target.value; });
  q(".ed-volume").addEventListener("change", (e) => saveRule(editor.key, { volume: Number(e.target.value) }, q(".ed-note")));
  q(".ed-shuffle").addEventListener("change", (e) => saveRule(editor.key, { shuffle: e.target.checked }, q(".ed-note")));
  q(".ed-preview").addEventListener("click", async () => {
    try {
      await api("./api/preview", { method: "POST", body: JSON.stringify({ key: editor.key }) });
      setStatus("▶", "ok", q(".ed-note"));
      setTimeout(refresh, 1500);
    } catch (error) { setStatus(error.message, "bad", q(".ed-note")); }
  });
  q(".ed-stop").addEventListener("click", stopNow);
  q(".ed-delete").addEventListener("click", async () => {
    const key = editor.key;
    try {
      await api("./api/rule", { method: "POST", body: JSON.stringify({ key, delete: true }) });
      if (current) delete current.settings.Rules[key];
      closeEditor();
    } catch (error) { setStatus(error.message, "bad", q(".ed-note")); }
  });
}

function targetChoice() {
  const select = q(".ed-target");
  return select.value ? { target: select.value, targetLabel: select.selectedOptions[0]?.textContent || "" } : {};
}

function currentRowName() {
  return editor.key === "*" ? "" : (rows().find((r) => r.key === editor.key)?.name || "");
}

async function stopNow() {
  try {
    await api("./api/stop", { method: "POST" });
    setTimeout(refresh, 800);
  } catch (error) { setStatus(error.message, "bad"); }
}

// ------------------------------------------------------------ Seite

function renderSpotify(sp) {
  const pairing = el("spotifyPairing");
  let info = null;
  if (sp.state === "pairing") {
    try { info = JSON.parse(sp.note); } catch (_) { info = null; }
  }
  pairing.hidden = !info;
  if (info) {
    el("spotifyCode").textContent = info.code || "";
    el("spotifyLink").href = info.url;
    el("spotifyLink").textContent = info.url;
  }
  const text = { off: t("spOff"), installing: t("spInstalling"), starting: t("spStarting"), pairing: t("spPairing"),
    ready: t("spReady", { user: sp.note || "?" }), error: t("spError", { note: sp.note || "?" }) }[sp.state] || sp.state;
  setStatus(text, sp.state === "ready" ? "ok" : sp.state === "error" ? "bad" : sp.state === "off" ? "" : "busy", "spotifyNote");
  el("spotifyForget").hidden = !["ready", "pairing", "error"].includes(sp.state);
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  const n = state.now || {};
  el("factPlaylist").textContent = n.playlist || "—";
  el("factTitle").textContent = n.title || "—";
  el("factTarget").textContent = n.target || "—";
  const tools = state.tools || {};
  el("factSound").textContent = !tools.decoder ? t("noFfmpeg") : tools.sink ? t("soundOk", { sink: tools.sink }) : t("soundMissing");
  el("factVersion").textContent = state.version;
  setStatus(n.text || "", n.tone || "");
  el("stopButton").disabled = !n.key;
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Playlist-Musik ${state.version}] `);
  if (!editing) {
    for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
      if (document.activeElement !== el(name)) el(name).value = s[name] ?? "";
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) el(name).value = s[name];
    el("Language").value = lang;
    for (const name of ["JellyfinKey", "MaToken"]) {
      if (document.activeElement !== el(name)) el(name).placeholder = state.secretsSet[name] ? t("keySaved") : t("keyMissing");
    }
    const other = state.jellyfinOther || {};
    el("JellyfinUrl").placeholder = other.url ? `${other.url} (${t("fromOther")})` : "http://192.168.1.10:8096";
    el("JellyfinUser").placeholder = other.user ? `${other.user} (${t("fromOther")})` : "";
    if (!state.secretsSet.JellyfinKey && other.keySet && document.activeElement !== el("JellyfinKey")) {
      el("JellyfinKey").placeholder = t("fromOther");
    }
  }
  renderSpotify(state.spotify || {});
  if (state.playlistError) setStatus(state.playlistError, "bad", "rulesNote");
  renderRules();
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS, ["JellyfinKey", "MaToken"])) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
}
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }, name.startsWith("Spotify") ? "spotifyNote" : "statusNote"));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of ["TimeFrom", "TimeTo", "SpotifyName"]) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save({ Language: e.target.value });
});

async function saveService(what) {
  const fields = what === "jellyfin" ? ["JellyfinUrl", "JellyfinUser"] : ["MaUrl"];
  const secret = what === "jellyfin" ? "JellyfinKey" : "MaToken";
  const changes = {};
  for (const name of fields) changes[name] = el(name).value;
  const key = el(secret).value.trim();
  if (key) changes[secret] = key;
  const changed = await save(changes, what === "jellyfin" ? "jellyfinNote" : "maNote");
  el(secret).value = "";
  if (changed.length) await testService(what);
}

async function testService(what) {
  const note = what === "jellyfin" ? "jellyfinNote" : "maNote";
  setStatus(t("testing"), "busy", note);
  try {
    const result = await api("./api/test", { method: "POST", body: JSON.stringify({ what }) });
    setStatus(result.message, result.ok ? "ok" : "bad", note);
  } catch (error) {
    setStatus(error.message, "bad", note);
  }
}

for (const name of ["JellyfinUrl", "JellyfinUser", "JellyfinKey"]) el(name).addEventListener("change", () => saveService("jellyfin"));
for (const name of ["MaUrl", "MaToken"]) el(name).addEventListener("change", () => saveService("ma"));
el("jellyfinTest").addEventListener("click", async () => {
  if (el("JellyfinKey").value.trim()) await saveService("jellyfin");
  else await testService("jellyfin");
});
el("maTest").addEventListener("click", async () => {
  if (el("MaToken").value.trim()) await saveService("ma");
  else await testService("ma");
});
el("spotifyForget").addEventListener("click", async () => {
  try {
    const result = await api("./api/spotify/forget", { method: "POST" });
    setStatus(result.message, "busy", "spotifyNote");
  } catch (error) { setStatus(error.message, "bad", "spotifyNote"); }
});
el("stopButton").addEventListener("click", stopNow);

refresh();
setInterval(refresh, 3000);
