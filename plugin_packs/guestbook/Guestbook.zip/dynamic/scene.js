/* Guestbook - die Szene.
 *
 * Fragt alle zwei Sekunden api/scene?since=<seq> und zeigt je nach Modus:
 *   book   - das aufgeschlagene Gästebuch: links das Selfie, rechts der Gruß.
 *            Neue Einträge kommen sofort („Willkommen, Anke!“), dazwischen
 *            die Erinnerung des Tages („Heute vor 3 Jahren war … zu Besuch.“).
 *            Ist das Buch leer: großer QR-Code.
 *   party  - die Gästewand einer Feier: groß der aktuelle Eintrag, daneben
 *            alle Gäste des Abends als kleine Sofortbilder, QR-Code.
 *   recap  - der Rückblick einer Feier: Titel, jeder Eintrag als Buchseite,
 *            zum Schluss die Collage. Läuft im Kreis.
 * Zum Ausprobieren: ?plugin=<URL der Plugin-Seite>
 */
(function () {
  "use strict";

  const PLUGIN_ID = "Guestbook";
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const sameOrigin = (location.protocol === "http:" && (location.port === "" || location.port === "80"))
    || (location.protocol === "https:" && (location.port === "" || location.port === "443"));
  const pluginBases = params.get("plugin") ? [params.get("plugin").replace(/\/?$/, "/")] : [...new Set(sameOrigin ? [
    `${location.origin}${advanced}`,
    `${location.protocol}//${location.hostname}:8003${advanced}`
  ] : [
    `${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`,
    `http://${location.hostname || "localhost"}${advanced}`
  ])];
  let baseIndex = 0;

  const TEXT = {
    de: {
      join: "Tragt euch ein!", joinLead: "Scannt den Code mit dem Handy: ein Selfie, euer Name und ein paar Zeilen. Der Rahmen hebt es auf und erinnert sich noch in Jahren daran.",
      code: "Code {code}", welcomeKicker: "Gästebuch", newIn: "Neu im Gästebuch", hello: "Willkommen, {name}!",
      visit: "{n}. Besuch", first: "zum ersten Mal hier", since: "seit {date} dabei",
      yearsAgo1: "Heute vor einem Jahr", yearsAgo: "Heute vor {n} Jahren",
      visitOne: "Heute vor {when} war {names} zu Besuch.", visitMany: "Heute vor {when} waren {names} zu Besuch.",
      when1: "einem Jahr", whenN: "{n} Jahren",
      eventLine: "Heute vor {when}: {title}", eventSub: "{n} Gäste haben sich ins Gästebuch eingetragen.", eventSub1: "Ein Gast hat sich ins Gästebuch eingetragen.",
      and: "und", more: "{n} weitere",
      guests: "<b>{n}</b> Gäste im Gästebuch", guest1: "<b>1</b> Gast im Gästebuch", partyEmpty: "Wer trägt sich als Erstes ein?",
      recapKicker: "Das Gästebuch von", recapSub: "{date} · {n} Gäste", thanks: "Danke, dass ihr da wart!", thanksSub: "{n} Einträge im Gästebuch",
      q1: "„", q2: "“", unreachable: "Guestbook antwortet nicht.", login: "Bitte zuerst im Browser beim Rahmen anmelden."
    },
    en: {
      join: "Sign the guestbook!", joinLead: "Scan the code with your phone: a selfie, your name and a few lines. The frame keeps it and will remember it years from now.",
      code: "Code {code}", welcomeKicker: "Guestbook", newIn: "New in the guestbook", hello: "Welcome, {name}!",
      visit: "visit no. {n}", first: "first visit", since: "visiting since {date}",
      yearsAgo1: "One year ago today", yearsAgo: "{n} years ago today",
      visitOne: "{whenCap}, {names} came to visit.", visitMany: "{whenCap}, {names} came to visit.",
      when1: "one year ago today", whenN: "{n} years ago today",
      eventLine: "{whenCap}: {title}", eventSub: "{n} guests signed the guestbook.", eventSub1: "One guest signed the guestbook.",
      and: "and", more: "{n} more",
      guests: "<b>{n}</b> guests in the guestbook", guest1: "<b>1</b> guest in the guestbook", partyEmpty: "Who signs first?",
      recapKicker: "The guestbook of", recapSub: "{date} · {n} guests", thanks: "Thank you for coming!", thanksSub: "{n} entries in the guestbook",
      q1: "“", q2: "”", unreachable: "Guestbook is not responding.", login: "Please sign in to the frame in the browser first."
    },
    es: {
      join: "¡Firmad en el libro!", joinLead: "Escanead el código con el móvil: un selfie, vuestro nombre y unas líneas. El marco lo guarda y lo recordará dentro de años.",
      code: "Código {code}", welcomeKicker: "Libro de visitas", newIn: "Nuevo en el libro de visitas", hello: "¡Hola, {name}!",
      visit: "visita n.º {n}", first: "primera visita", since: "de visita desde {date}",
      yearsAgo1: "Hoy hace un año", yearsAgo: "Hoy hace {n} años",
      visitOne: "{whenCap} vino de visita {names}.", visitMany: "{whenCap} vinieron de visita {names}.",
      when1: "hoy hace un año", whenN: "hoy hace {n} años",
      eventLine: "{whenCap}: {title}", eventSub: "{n} invitados firmaron en el libro de visitas.", eventSub1: "Un invitado firmó en el libro de visitas.",
      and: "y", more: "{n} más",
      guests: "<b>{n}</b> invitados en el libro", guest1: "<b>1</b> invitado en el libro", partyEmpty: "¿Quién firma primero?",
      recapKicker: "El libro de visitas de", recapSub: "{date} · {n} invitados", thanks: "¡Gracias por venir!", thanksSub: "{n} entradas en el libro",
      q1: "«", q2: "»", unreachable: "Guestbook no responde.", login: "Inicia sesión primero en el marco desde el navegador."
    }
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  let lang = params.get("lang") || "en";
  const tx = (key, values) => {
    let text = (TEXT[lang] || TEXT.en)[key] || TEXT.en[key] || key;
    for (const [k, v] of Object.entries(values || {})) text = text.split(`{${k}}`).join(v);
    return text;
  };
  const $ = (id) => document.getElementById(id);
  const esc = (text) => String(text ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang] || "en-GB");
  const longDate = (iso) => new Date(iso + "T12:00:00").toLocaleDateString(LOCALES[lang], { day: "numeric", month: "long", year: "numeric" });
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const rnd = (a, b) => a + Math.random() * (b - a);

  // ------------------------------------------------------------ Plugin

  async function api(path) {
    let lastError = null;
    for (let i = 0; i < pluginBases.length; i += 1) {
      const base = pluginBases[(baseIndex + i) % pluginBases.length];
      try {
        const response = await fetch(base + path, { cache: "no-store", credentials: "same-origin" });
        if (response.redirected && /login/i.test(response.url)) throw new Error("login");
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const body = await response.json();
        baseIndex = (baseIndex + i) % pluginBases.length;
        return body;
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error("unreachable");
  }
  const photoUrl = (id, size = "f") => `${pluginBases[baseIndex]}api/photo?id=${encodeURIComponent(id)}&s=${size}`;

  function report(message) {
    api("api/report?m=" + encodeURIComponent(String(message).slice(0, 180))).catch(() => {});
  }
  addEventListener("error", (e) => report(`${e.message} ${e.filename || ""}:${e.lineno || ""}`));

  // DynaFrame wartet, bis die Szene meldet, dass sie steht.
  let readySent = false;
  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 8000);

  function showNote(text) {
    $("note").textContent = text || "";
    $("note").hidden = !text;
    if (text) ready();
  }

  // ------------------------------------------------------------ Größe

  function layout() {
    const w = innerWidth, h = innerHeight;
    document.documentElement.style.setProperty("--u", `${Math.min(w, h * 1.15) / 100}px`);
    document.body.classList.toggle("portrait", h > w * 1.05);
    fitAll();
  }
  addEventListener("resize", layout);

  function fitText(node, max, min) {
    // Größte Schrift, bei der der Gruß noch in seine Seite passt.
    if (!node || !node.isConnected) return;
    const box = node.closest("[data-fit]") || node.parentElement;
    let size = max;
    node.style.fontSize = `${size}px`;
    let guard = 0;
    while (size > min && box.scrollHeight > box.clientHeight + 1 && guard < 60) {
      size *= 0.93;
      node.style.fontSize = `${size}px`;
      guard += 1;
    }
  }
  function fitAll() {
    const u = Math.min(innerWidth, innerHeight * 1.15) / 100;
    document.querySelectorAll(".page.right .greeting").forEach((n) => fitText(n, u * 7.4, u * 2.6));
    document.querySelectorAll(".text-card .greeting").forEach((n) => fitText(n, u * 4.4, u * 2.2));
  }

  function loadImage(src) {
    return new Promise((resolve) => {
      const img = new Image();
      img.decoding = "async";
      img.onload = () => resolve(img);
      img.onerror = () => resolve(null);
      img.src = src;
    });
  }

  // ------------------------------------------------------------ QR-Code

  const qrDone = {};
  function drawQr(id, url) {
    if (!url || qrDone[id] === url || typeof qrcode !== "function") return;
    qrDone[id] = url;
    const qr = qrcode(0, "M");
    qr.addData(url);
    qr.make();
    $(id).innerHTML = qr.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
  }
  function joinUrl() {
    return state && state.url ? `${state.url}?c=${state.code}` : "";
  }
  function renderJoin() {
    const url = joinUrl();
    for (const id of ["qrBig", "qrParty", "qrCorner"]) drawQr(id, url);
    const code = tx("code", { code: state.code });
    $("codeBig").textContent = code;
    $("codeParty").textContent = code;
    $("codeCorner").textContent = code;
    $("joinParty").textContent = tx("join");
    $("joinCorner").textContent = tx("join");
  }

  // ------------------------------------------------------------ Zustand

  let state = null;
  let seq = -1;
  const fresh = [];                  // neue Einträge, die gleich groß kommen
  let wake = null;                   // weckt den Regisseur vorzeitig
  let lastMode = "";
  let lastFocus = "";
  let recapId = 0;

  function interrupt() {
    if (wake) wake();
  }
  function hold(ms) {
    return new Promise((resolve) => {
      const timer = setTimeout(done, ms);
      function done() { clearTimeout(timer); wake = null; resolve(); }
      wake = done;
    });
  }

  async function poll() {
    try {
      const body = await api(`api/scene?since=${seq}`);
      showNote("");
      const before = state;
      state = body;
      lang = TEXT[body.lang] ? body.lang : "en";
      document.documentElement.lang = lang;
      document.body.className = document.body.className.replace(/theme-\w+/, `theme-${body.theme}`);
      if (!/theme-/.test(document.body.className)) document.body.classList.add(`theme-${body.theme}`);
      renderJoin();
      if (seq >= 0 && body.fresh && body.fresh.length) {
        for (const entry of body.fresh) if (!fresh.some((e) => e.id === entry.id)) fresh.push(entry);
        interrupt();
      }
      seq = body.seq;
      const focus = body.focus ? `${body.focus.kind}:${body.focus.id}:${body.focus.at}` : "";
      if (focus !== lastFocus) {
        lastFocus = focus;
        if (body.focus && body.focus.kind === "welcome" && body.focusEntry && !fresh.some((e) => e.id === body.focusEntry.id)
            && shownWelcome !== body.focusEntry.id) {
          fresh.push(body.focusEntry);
        }
        if (focus) interrupt();
      }
      if (body.mode !== lastMode || (body.recap && body.recap.id !== recapId)) {
        lastMode = body.mode;
        recapId = body.recap ? body.recap.id : 0;
        interrupt();
      }
      if (body.mode === "party" && before) updateWall();
    } catch (error) {
      showNote(error && error.message === "login" ? tx("login") : tx("unreachable"));
    }
    setTimeout(poll, 2000);
  }

  // ------------------------------------------------------------ Bausteine

  function polaroid(entry, size = "f", tape = true) {
    if (!entry.photo) return "";
    return `<div class="polaroid" style="--r:${rnd(-3, 3).toFixed(1)}deg">${tape ? '<i class="tape"></i>' : ""}
      <img class="ph" src="${esc(photoUrl(entry.id, size))}" alt=""></div>`;
  }
  function initials(name) {
    const parts = String(name || "?").split(/[\s&,+]+/).filter(Boolean);
    return (parts[0] || "?").slice(0, 1).toUpperCase() + (parts[1] ? parts[1].slice(0, 1).toUpperCase() : "");
  }
  function metaLine(entry) {
    const bits = [];
    if (state.showDates) bits.push(`<span>${esc(longDate(entry.day))}</span>`);
    if (entry.event && lastMode !== "party" && lastMode !== "recap") bits.push(`<span>${esc(entry.event)}</span>`);
    if (entry.visit > 1) bits.push(`<span class="chip">${esc(tx("visit", { n: entry.visit }))}</span>`);
    return bits.join("");
  }

  function qrSvg() {
    const url = joinUrl();
    if (!url || typeof qrcode !== "function") return "";
    if (qrSvg.url !== url) {
      const qr = qrcode(0, "M");
      qr.addData(url);
      qr.make();
      qrSvg.url = url;
      qrSvg.svg = qr.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
    }
    return qrSvg.svg;
  }

  function spreadHtml(entry, stamp = false) {
    const left = entry.photo
      ? `<div class="polaroid" style="transform:rotate(${rnd(-3, 2).toFixed(1)}deg)"><i class="tape"></i><img class="ph" src="${esc(photoUrl(entry.id))}" alt=""></div>`
      : `<div class="monogram" style="color:${esc(entry.color)}">${esc(initials(entry.name))}</div><p class="monogram-sub">${esc(entry.name)}</p>`;
    return `<div class="page left">${left}</div>
      <div class="page right${stamp ? " with-stamp" : ""}" data-fit>
        ${entry.text ? `<p class="greeting">${esc(entry.text)}</p>` : ""}
        <div class="sign"><span class="name">${esc(entry.name)}</span></div>
        <div class="meta">${metaLine(entry)}</div>
        ${stamp ? `<div class="stamp"><div class="qr">${qrSvg()}</div><p><b>${esc(tx("join"))}</b>${esc(tx("code", { code: state.code }))}</p></div>` : ""}
      </div><i class="fold"></i>`;
  }

  async function showSpread(target, entry, stamp = false) {
    if (entry.photo) await loadImage(photoUrl(entry.id));
    const node = $(target);
    node.classList.remove("enter");
    node.classList.add("leave");
    await sleep(node.innerHTML ? 450 : 0);
    node.classList.remove("leave");
    node.innerHTML = spreadHtml(entry, stamp);
    void node.offsetWidth;
    node.classList.add("enter");
    fitAll();
    ready();
  }

  function only(id) {
    for (const view of ["book", "memory", "welcome", "party", "recap"]) $(view).hidden = view !== id;
  }
  function corner(on) {
    $("corner").hidden = !(on && state && state.showQr && state.url);
  }

  function confetti(n = 70) {
    const colors = ["#ff4fa3", "#ffb347", "#7bdff2", "#b28dff", "#5ee6a8", "#ffd84d"];
    const box = $("confetti");
    for (let i = 0; i < n; i += 1) {
      const bit = document.createElement("i");
      bit.style.left = `${rnd(0, 100)}vw`;
      bit.style.background = colors[i % colors.length];
      bit.style.setProperty("--dx", `${rnd(-12, 12)}vw`);
      bit.style.setProperty("--rot", `${rnd(-720, 720)}deg`);
      bit.style.animationDuration = `${rnd(3, 6)}s`;
      bit.style.animationDelay = `${rnd(0, 1.2)}s`;
      box.appendChild(bit);
      setTimeout(() => bit.remove(), 8000);
    }
  }

  function joinNames(names) {
    const list = names.slice(0, 4);
    const rest = names.length - list.length;
    if (rest > 0) list.push(tx("more", { n: rest }));
    if (list.length === 1) return list[0];
    return `${list.slice(0, -1).join(", ")} ${tx("and")} ${list[list.length - 1]}`;
  }

  // ------------------------------------------------------------ Buch

  let shownWelcome = "";
  async function showWelcomeEntry(entry) {
    shownWelcome = entry.id;
    only("book");
    corner(false);
    $("banner").textContent = tx("hello", { name: entry.name });
    $("banner").hidden = false;
    $("book").classList.add("has-banner");
    await showSpread("spread", entry);
    confetti();
  }

  async function showEntry(entry) {
    only("book");
    $("banner").hidden = true;
    $("book").classList.remove("has-banner");
    corner(false);
    await showSpread("spread", entry, Boolean(state.showQr && state.url));
  }

  function showEmpty(title, lead, kicker) {
    only("welcome");
    corner(false);
    $("welcomeKicker").textContent = kicker;
    $("welcomeTitle").textContent = title;
    $("welcomeLead").textContent = lead;
    ready();
  }

  async function showMemory(memory) {
    only("memory");
    corner(false);
    const when = memory.years === 1 ? tx("when1") : tx("whenN", { n: memory.years });
    const whenCap = when.charAt(0).toUpperCase() + when.slice(1);
    $("memKicker").textContent = memory.years === 1 ? tx("yearsAgo1") : tx("yearsAgo", { n: memory.years });
    const rows = memory.entries || [];
    if (memory.kind === "event") {
      $("memTitle").textContent = tx("eventLine", { when, whenCap, title: memory.title || "" });
      $("memSub").innerHTML = esc(memory.count === 1 ? tx("eventSub1") : tx("eventSub", { n: fmt(memory.count) }));
    } else {
      const names = joinNames(memory.names || []);
      const plural = (memory.people || 1) > 1;
      $("memTitle").textContent = tx(plural ? "visitMany" : "visitOne", { when, whenCap, names });
      const greet = rows.find((r) => r.text);
      $("memSub").innerHTML = greet ? `<span class="greet">${tx("q1")}${esc(greet.text.length > 160 ? greet.text.slice(0, 157) + "…" : greet.text)}${tx("q2")}</span>` : "";
    }
    // Ein Kicker wiederholt nicht, was schon im Satz steht.
    $("memKicker").hidden = true;
    const box = $("memPhotos");
    const photos = rows.filter((r) => r.photo);
    await Promise.all(photos.slice(0, 12).map((r) => loadImage(photoUrl(r.id, photos.length > 3 ? "t" : "f"))));
    box.className = "memory-photos";
    box.style.removeProperty("--cols");
    if (photos.length > 3) {
      box.classList.add("many");
      box.style.setProperty("--cols", photos.length > 8 ? 4 : 3);
      box.innerHTML = photos.slice(0, 12).map((r, i) => `<div class="polaroid" style="--r:${rnd(-4, 4).toFixed(1)}deg;animation-delay:${i * 0.12}s">
        <img class="ph" src="${esc(photoUrl(r.id, "t"))}" alt=""><span class="cap">${esc(r.name)}</span></div>`).join("");
    } else if (photos.length) {
      const spots = photos.length === 1 ? [[18, 6, -3]] : photos.length === 2 ? [[4, 2, -5], [44, 18, 4]] : [[0, 0, -6], [44, 4, 5], [20, 34, -2]];
      box.innerHTML = photos.map((r, i) => `<div class="polaroid${photos.length === 1 ? " solo" : ""}" style="left:${spots[i][0]}%;top:${spots[i][1]}%;--r:${spots[i][2]}deg;animation-delay:${i * 0.25}s">
        <i class="tape"></i><img class="ph" src="${esc(photoUrl(r.id))}" alt=""><span class="cap">${esc(r.name)}</span></div>`).join("");
    } else {
      const text = rows.find((r) => r.text);
      box.innerHTML = text ? `<div class="note-card" style="left:20%;top:20%;--r:-2deg">${esc(text.text)}\n— ${esc(text.name)}</div>` : "";
    }
    ready();
  }

  let bookCount = 0;
  let memoryIndex = 0;
  const recent = [];
  async function bookStep() {
    // 1. Neue Einträge zuerst
    if (fresh.length) {
      const entry = fresh.shift();
      await showWelcomeEntry(entry);
      await hold(Math.max(15, state.slide) * 1000);
      return;
    }
    const memories = state.memories || [];
    const focusMemory = state.focus && state.focus.kind === "memory";
    if (!state.stats.entries) {
      showEmpty(state.title, tx("joinLead"), tx("welcomeKicker"));
      await hold(20000);
      return;
    }
    // 2. Erinnerung des Tages: beim Takeover nur sie, sonst jede vierte Seite
    if (memories.length && (focusMemory || bookCount % 4 === 1)) {
      await showMemory(memories[memoryIndex % memories.length]);
      memoryIndex += 1;
      bookCount += 1;
      await hold(Math.max(14, state.slide * 1.4) * 1000);
      return;
    }
    // 3. Weiterblättern
    let entry = null;
    try {
      entry = (await api(`api/next?ex=${encodeURIComponent(recent.slice(-8).join(","))}`)).entry;
    } catch (_) { /* gleich noch einmal */ }
    if (!entry) {
      await hold(4000);
      return;
    }
    recent.push(entry.id);
    if (recent.length > 20) recent.shift();
    bookCount += 1;
    await showEntry(entry);
    await hold(state.slide * 1000);
  }

  // ------------------------------------------------------------ Party

  let spotIndex = 0;
  let wallIds = "";
  let spotId = "";
  function updateWall() {
    const rows = state.wall || [];
    const ids = rows.map((r) => r.id).join(",");
    $("partyTitle").textContent = state.event ? state.event.title : "";
    const people = state.event ? state.event.people : 0;
    $("partyCount").innerHTML = people === 1 ? tx("guest1") : tx("guests", { n: fmt(people) });
    if (ids === wallIds) {
      markSpot();
      return;
    }
    const known = new Set(wallIds.split(","));
    wallIds = ids;
    const n = rows.length;
    const box = $("wall");
    box.style.setProperty("--cols", wallColumns(box, n));
    box.innerHTML = rows.slice().reverse().map((r) => `<div class="tile${known.size > 1 && !known.has(r.id) ? " fresh" : ""}" data-id="${esc(r.id)}" style="--r:${rnd(-4, 4).toFixed(1)}deg">
      ${r.photo ? `<img class="ph" src="${esc(photoUrl(r.id, "t"))}" alt="">` : `<div class="mono" style="background:${esc(r.color)}">${esc(initials(r.name))}</div>`}
      <span class="cap">${esc(r.name)}</span></div>`).join("");
    markSpot();
  }
  function wallColumns(box, n) {
    // So viele Spalten, dass alle Sofortbilder ohne Abschneiden in die Wand passen, so groß wie möglich.
    const W = box.clientWidth || innerWidth * 0.45, H = box.clientHeight || innerHeight * 0.6;
    const u = Math.min(innerWidth, innerHeight * 1.15) / 100;
    const gap = u * 1.2, extra = u * 2.7;      // Rand und Namenszeile unter dem Bild
    let best = 1, bestSize = 0;
    for (let cols = 1; cols <= Math.max(1, n); cols += 1) {
      const rows = Math.ceil(Math.max(1, n) / cols);
      const size = (W - gap * (cols - 1)) / cols;
      if (rows * (size + extra) + gap * (rows - 1) > H) continue;
      if (size > bestSize) { best = cols; bestSize = size; }
      break;
    }
    if (!bestSize) best = Math.ceil(Math.sqrt(n * 1.6));
    return Math.max(2, best);
  }
  function markSpot() {
    document.querySelectorAll("#wall .tile").forEach((t) => t.classList.toggle("now", t.dataset.id === spotId));
  }

  async function showSpot(entry, hello) {
    spotId = entry.id;
    markSpot();
    if (entry.photo) await loadImage(photoUrl(entry.id));
    $("spotlight").innerHTML = `${hello ? `<p class="hello">${esc(tx("hello", { name: entry.name }))}</p>` : ""}
      <div class="card">${polaroid(entry)}
        <div class="text-card" data-fit style="max-height:${entry.photo ? 26 : 60}vh;overflow:hidden">
          ${entry.text ? `<p class="greeting">${esc(entry.text)}</p>` : ""}
          <div class="sign"><span class="name">${esc(entry.name)}</span></div></div></div>`;
    fitAll();
    ready();
  }

  async function partyStep() {
    only("party");
    corner(false);
    updateWall();
    const rows = state.wall || [];
    if (fresh.length) {
      const entry = fresh.shift();
      await showSpot(entry, true);
      confetti(50);
      await hold(Math.max(14, state.slide) * 1000);
      return;
    }
    if (!rows.length) {
      showEmpty(state.event ? state.event.title : state.title, tx("partyEmpty") + " " + tx("joinLead"), tx("welcomeKicker"));
      await hold(15000);
      return;
    }
    let entry = null;
    try {
      entry = (await api(`api/next?ex=${encodeURIComponent(spotId)}`)).entry;
    } catch (_) { /* gleich noch einmal */ }
    if (!entry) {
      await hold(4000);
      return;
    }
    spotIndex += 1;
    await showSpot(entry, false);
    await hold(state.slide * 1000);
  }

  // ------------------------------------------------------------ Rückblick

  function mosaic(id, rows, maxCells) {
    const list = rows.slice(0, maxCells);
    const n = Math.max(1, list.length);
    const ratio = innerWidth / innerHeight;
    const cols = Math.max(2, Math.ceil(Math.sqrt(n * ratio)));
    const box = $(id);
    box.style.setProperty("--cols", cols);
    box.innerHTML = list.map((r, i) => r.photo
      ? `<img class="ph" style="animation-delay:${(i * 0.04).toFixed(2)}s" src="${esc(photoUrl(r.id, "t"))}" alt="">`
      : `<div class="mono" style="background:${esc(r.color)};animation-delay:${(i * 0.04).toFixed(2)}s">${esc(initials(r.name))}</div>`).join("");
  }

  async function recapRun() {
    const recap = state.recap;
    const id = recap.id;
    const rows = recap.entries || [];
    only("recap");
    corner(false);
    const date = recap.started ? longDate(new Date(recap.started * 1000).toISOString().slice(0, 10)) : "";
    // Intro
    $("recapIntro").hidden = false;
    $("recapSpread").hidden = true;
    $("recapEnd").hidden = true;
    mosaic("recapMosaic", rows, 60);
    $("recapKicker").textContent = tx("recapKicker");
    $("recapTitle").textContent = recap.title;
    $("recapSub").textContent = tx("recapSub", { date, n: fmt(recap.people) });
    ready();
    await hold(9000);
    // Jede Seite
    const per = Math.max(4, Math.min(state.slide, Math.round(360 / Math.max(1, rows.length))));
    for (const entry of rows) {
      if (!state.recap || state.recap.id !== id || state.mode !== "recap" || fresh.length) return;
      $("recapIntro").hidden = true;
      $("recapSpread").hidden = false;
      await showSpread("recapSpread", entry);
      await hold(per * 1000);
    }
    if (!state.recap || state.recap.id !== id || state.mode !== "recap") return;
    // Schluss
    $("recapSpread").hidden = true;
    $("recapEnd").hidden = false;
    mosaic("recapCollage", rows, 120);
    $("endTitle").textContent = tx("thanks");
    $("endSub").textContent = `${recap.title} · ${tx("thanksSub", { n: fmt(rows.length) })}`;
    confetti(90);
    await hold(16000);
  }

  // ------------------------------------------------------------ Regisseur

  async function director() {
    while (!state) await sleep(300);
    for (;;) {
      try {
        if (state.mode === "recap" && state.recap) await recapRun();
        else if (state.mode === "party") await partyStep();
        else await bookStep();
      } catch (error) {
        report(`director: ${error && error.message}`);
        await sleep(3000);
      }
    }
  }

  layout();
  poll();
  director();
})();
