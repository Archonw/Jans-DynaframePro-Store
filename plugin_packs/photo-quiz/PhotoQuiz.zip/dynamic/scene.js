/* Photo Quiz - die Szene „Wann und wo war das?“.
 *
 * Das Plugin führt das Spiel; die Szene fragt jede Sekunde api/game und
 * zeigt, was gerade dran ist:
 *   guess  - das Foto erst verpixelt, gezoomt oder unscharf, wird mit der Zeit
 *            deutlicher; Hinweise kommen dazu; QR-Code zum Mitraten,
 *   reveal - das Foto ganz, daneben Datum, Ort, Karte mit den Tipps, Punkte,
 *   final  - der Endstand nach ein paar Runden.
 * Dass die Szene fragt, heißt fürs Plugin: sie ist zu sehen, das Spiel läuft.
 *
 * Zum Ausprobieren: ?plugin=<URL der Plugin-Seite> &lang=de|en|es
 */
(function () {
  "use strict";

  const PLUGIN_ID = "PhotoQuiz";
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const sameOrigin = (location.protocol === "http:" && (location.port === "" || location.port === "80"))
    || (location.protocol === "https:" && (location.port === "" || location.port === "443"));
  const pluginBases = params.get("plugin") ? [params.get("plugin").replace(/\/?$/, "/")] : [...new Set(sameOrigin ? [
    `${location.origin}${advanced}`,
    `${location.protocol}//${location.hostname}:8003${advanced}`
  ] : [
    `${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`,
    `http://${location.hostname || "localhost"}${advanced}`
  ])];
  let baseIndex = 0;
  const QT = window.QuizText;

  const TEXT = {
    de: {
      title: "Wann und wo war das?", titleWhen: "Wann war das?", titleWhere: "Wo war das?",
      round: "Runde {a} von {b}", quiz: "Photo Quiz",
      join: "Mitraten mit dem Handy: QR-Code scannen", code: "Code",
      answer: "Auflösung", nobody: "Diesmal hat niemand getippt.",
      final: "Endstand", finalKicker: "Photo Quiz", next: "Gleich geht es weiter mit dem nächsten Spiel.",
      wait: "Das nächste Foto kommt gleich …", reading: "Photo Quiz liest deine Fotos ein …",
      none: "Photo Quiz findet keine Fotos mit Aufnahmedatum. Wähle auf der Plugin-Seite eine Quelle.",
      unreachable: "Photo Quiz antwortet nicht.", login: "Bitte zuerst im Browser beim Rahmen anmelden.",
      exact: "genau", yearsOff: "{n} J. daneben", kmOff: "{km} daneben"
    },
    en: {
      title: "When and where was this?", titleWhen: "When was this?", titleWhere: "Where was this?",
      round: "Round {a} of {b}", quiz: "Photo Quiz",
      join: "Play along on your phone: scan the QR code", code: "Code",
      answer: "The answer", nobody: "Nobody guessed this time.",
      final: "Final score", finalKicker: "Photo Quiz", next: "The next game starts in a moment.",
      wait: "The next photo is coming …", reading: "Photo Quiz is reading your photos …",
      none: "Photo Quiz finds no photos with a date. Pick a source on the plugin page.",
      unreachable: "Photo Quiz is not responding.", login: "Please sign in to the frame in the browser first.",
      exact: "spot on", yearsOff: "{n} yr off", kmOff: "{km} off"
    },
    es: {
      title: "¿Cuándo y dónde fue?", titleWhen: "¿Cuándo fue?", titleWhere: "¿Dónde fue?",
      round: "Ronda {a} de {b}", quiz: "Photo Quiz",
      join: "Juega con el móvil: escanea el código QR", code: "Código",
      answer: "La solución", nobody: "Esta vez nadie ha respondido.",
      final: "Resultado final", finalKicker: "Photo Quiz", next: "La siguiente partida empieza enseguida.",
      wait: "La siguiente foto llega enseguida …", reading: "Photo Quiz está leyendo tus fotos …",
      none: "Photo Quiz no encuentra fotos con fecha. Elige una fuente en la página del plugin.",
      unreachable: "Photo Quiz no responde.", login: "Inicia sesión primero en el marco desde el navegador.",
      exact: "exacto", yearsOff: "{n} años de dif.", kmOff: "a {km}"
    }
  };
  let lang = params.get("lang") || "en";
  const tx = (key, values) => {
    let text = (TEXT[lang] || TEXT.en)[key] || key;
    for (const [k, v] of Object.entries(values || {})) text = text.replace(`{${k}}`, v);
    return text;
  };
  const $ = (id) => document.getElementById(id);
  const esc = (text) => String(text ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));

  // ------------------------------------------------------------ Plugin

  async function api(path) {
    let lastError = null;
    for (let i = 0; i < pluginBases.length; i += 1) {
      const base = pluginBases[(baseIndex + i) % pluginBases.length];
      try {
        const response = await fetch(base + path, { cache: "no-store", credentials: "same-origin" });
        if (response.redirected && /login/i.test(response.url)) throw new Error("login");
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const body = await response.json();
        baseIndex = (baseIndex + i) % pluginBases.length;
        return body;
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error("unreachable");
  }

  const url = (path) => pluginBases[baseIndex] + path;

  function report(message) {
    api("api/report?m=" + encodeURIComponent(String(message).slice(0, 180))).catch(() => {});
  }

  // DynaFrame wartet, bis die Szene meldet, dass sie steht; sonst bricht der
  // Fernseher nach einer Frist ab ("scene readiness deadline expired").
  let readySent = false;
  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  function showNote(text) {
    $("note").textContent = text || "";
    $("note").hidden = !text;
    if (text) ready();
  }

  // ------------------------------------------------------------ Größe

  function layout() {
    const w = innerWidth, h = innerHeight;
    document.documentElement.style.setProperty("--u", `${Math.min(w, h) / 100}px`);
    document.body.classList.toggle("portrait", h > w);
    document.body.classList.toggle("landscape", h <= w);
    if (round.img && round.style === "pixel" && !round.revealed) drawPixels(true);
    if (map) setTimeout(() => map.invalidateSize(), 50);
  }
  addEventListener("resize", layout);

  // ------------------------------------------------------------ Foto und Effekte

  const photoEl = $("photo"), pix = $("pix"), backdrop = $("backdrop");
  const round = { id: "", img: null, style: "", focus: [0.5, 0.5], start: 0, end: 0, block: 0, revealed: false };

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.decoding = "async";
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("image " + src));
      img.src = src;
    });
  }

  function progress() {
    return clamp((Date.now() - round.start) / Math.max(1, round.end - round.start));
  }

  function drawPixels(force) {
    const img = round.img;
    if (!img) return;
    const box = $("frame").getBoundingClientRect();
    const W = Math.max(1, Math.round(box.width)), H = Math.max(1, Math.round(box.height));
    const scale = Math.min(W / img.naturalWidth, H / img.naturalHeight);
    const rw = Math.round(img.naturalWidth * scale), rh = Math.round(img.naturalHeight * scale);
    // Kantenlänge eines Pixelblocks: von grob (1/9 der langen Seite) bis fein (1/150), in Stufen
    const steps = 14;
    const step = Math.min(steps - 1, Math.floor(progress() * steps));
    const big = Math.max(rw, rh) / 9, small = Math.max(rw, rh) / 150;
    const block = Math.max(2, Math.round(big * Math.pow(small / big, step / (steps - 1))));
    if (!force && block === round.block && pix.width === W && pix.height === H) return;
    round.block = block;
    if (pix.width !== W || pix.height !== H) { pix.width = W; pix.height = H; }
    const cw = Math.max(1, Math.round(rw / block)), ch = Math.max(1, Math.round(rh / block));
    const tmp = drawPixels.tmp || (drawPixels.tmp = document.createElement("canvas"));
    tmp.width = cw; tmp.height = ch;
    const t = tmp.getContext("2d");
    t.imageSmoothingEnabled = true;
    t.drawImage(img, 0, 0, cw, ch);
    const ctx = pix.getContext("2d");
    ctx.clearRect(0, 0, W, H);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(tmp, 0, 0, cw, ch, Math.round((W - rw) / 2), Math.round((H - rh) / 2), rw, rh);
  }

  function blurNow() {
    const p = progress();
    const steps = 10;
    const step = Math.min(steps - 1, Math.floor(p * steps));
    const px = Math.round(48 * Math.pow(3 / 48, step / (steps - 1)));
    return `blur(${px}px)`;
  }

  async function startRound(photo, state) {
    round.id = photo.id;
    round.revealed = false;
    round.style = photo.style || "pixel";
    round.focus = photo.focus || [0.5, 0.5];
    round.start = Date.now() - Math.max(0, state.dur - state.left) * 1000;
    round.end = Date.now() + state.left * 1000;
    round.block = 0;
    let img;
    try {
      img = await loadImage(url("api/photo?id=" + photo.id));
    } catch (error) {
      report("Foto: " + error.message);
      return;
    }
    if (round.id !== photo.id) return;
    round.img = img;
    document.body.classList.remove("revealing", "finalizing");
    backdrop.classList.remove("on");
    photoEl.classList.remove("on", "zooming");
    photoEl.style.transform = "";
    photoEl.style.filter = "";
    pix.classList.remove("on");
    photoEl.src = img.src;
    backdrop.src = img.src;
    if (round.style === "pixel") {
      drawPixels(true);
      pix.classList.add("on");
    } else if (round.style === "zoom") {
      const [fx, fy] = round.focus;
      photoEl.style.transformOrigin = `${(fx * 100).toFixed(1)}% ${(fy * 100).toFixed(1)}%`;
      photoEl.style.transform = "scale(6)";
      photoEl.style.filter = "blur(2px)";
      photoEl.getBoundingClientRect();             // Startwert festschreiben, dann losfahren
      document.documentElement.style.setProperty("--zoom-dur", `${Math.max(2, state.left)}s`);
      photoEl.classList.add("on", "zooming");
      requestAnimationFrame(() => { photoEl.style.transform = "scale(1.35)"; photoEl.style.filter = "none"; });
    } else {
      photoEl.style.filter = blurNow();
      photoEl.classList.add("on");
    }
    setTimeout(() => backdrop.classList.add("on"), 300);
    ready();
  }

  function tickEffects() {
    if (!round.img || round.revealed) return;
    if (round.style === "pixel") drawPixels(false);
    else if (round.style === "blur") {
      const filter = blurNow();
      if (photoEl.style.filter !== filter) photoEl.style.filter = filter;
    }
  }

  function revealPhoto() {
    if (round.revealed) return;
    round.revealed = true;
    photoEl.classList.remove("zooming");
    photoEl.style.transition = "opacity .9s ease, transform 1.4s cubic-bezier(.2,.7,.2,1), filter 1s ease";
    photoEl.style.transform = "none";
    photoEl.style.filter = "none";
    photoEl.classList.add("on");
    pix.classList.remove("on");
    setTimeout(() => { photoEl.style.transition = ""; }, 1500);
  }

  // ------------------------------------------------------------ Uhr

  const clock = { end: 0, dur: 1 };
  function tickClock() {
    const left = Math.max(0, (clock.end - Date.now()) / 1000);
    $("clockText").textContent = Math.ceil(left);
    $("clockRun").style.strokeDashoffset = String(276.5 * (1 - clamp(left / clock.dur)));
    $("clock").classList.toggle("hurry", left <= 5);
  }

  // ------------------------------------------------------------ Mitraten

  let qrFor = "";
  function renderJoin(state) {
    const on = state.phone && state.url && ["guess", "wait"].includes(state.phase);
    $("join").hidden = !on;
    if (!on) return;
    const link = `${state.url}?c=${state.code}`;
    if (link !== qrFor && typeof qrcode === "function") {
      qrFor = link;
      const code = qrcode(0, "M");
      code.addData(link);
      code.make();
      $("qr").innerHTML = code.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
    }
    $("joinTitle").textContent = tx("join");
    $("joinCodeLabel").textContent = tx("code");
    $("joinCode").textContent = state.code;
    $("joinUrl").textContent = state.url.replace(/^https?:\/\//, "").replace(/\/$/, "");
    const html = (state.players || []).map((p) =>
      `<li class="${p.done ? "done" : ""}"><i style="background:${esc(p.color)}"></i>${esc(p.name)} <em>${p.score}</em></li>`).join("");
    if ($("players").dataset.html !== html) { $("players").innerHTML = html; $("players").dataset.html = html; }
  }

  // ------------------------------------------------------------ Hinweise

  function renderHints(state) {
    const shown = state.phase === "guess" ? (state.hints || []) : [];
    const total = state.phase === "guess" ? (state.hintCount || 0) : 0;
    const rows = shown.map((h) => {
      const [label, text] = QT.hint(h, lang, state.units);
      return `<li>${label ? `<b>${esc(label)}</b>` : ""}<span>${esc(text)}</span></li>`;
    });
    for (let i = shown.length; i < total; i += 1) rows.push(`<li class="wait">?</li>`);
    const html = rows.join("");
    if ($("hints").dataset.html !== html) { $("hints").innerHTML = html; $("hints").dataset.html = html; }
  }

  // ------------------------------------------------------------ Karte

  let map = null, mapLayer = null;

  function landLayer() {
    const data = window.WORLD_MAP;
    if (!data || !data.land) return null;
    const rings = data.land.map((ring) => {
      const out = [];
      let lon = ring[0], lat = ring[1];
      out.push([lat / 100, lon / 100]);
      for (let i = 2; i < ring.length; i += 2) {
        lon += ring[i]; lat += ring[i + 1];
        out.push([lat / 100, lon / 100]);
      }
      return out;
    });
    return L.polygon(rings, { stroke: true, color: "#53627e", weight: 1, fillColor: "#33405a", fillOpacity: 1, interactive: false });
  }

  function ensureMap() {
    if (map || typeof L === "undefined") return;
    map = L.map("map", { zoomControl: false, attributionControl: true, preferCanvas: true,
      dragging: false, scrollWheelZoom: false, doubleClickZoom: false, boxZoom: false, keyboard: false, touchZoom: false,
      fadeAnimation: true, zoomAnimation: true });
    const land = landLayer();
    if (land) land.addTo(map);
    L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png", {
      maxZoom: 18, subdomains: "abcd", attribution: "© OpenStreetMap, © CARTO"
    }).addTo(map);
    map.setView([30, 10], 2);
  }

  function pin(color) {
    const u = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--u")) || 10;
    const s = Math.round(u * 2.4);
    return L.divIcon({ className: "", html: `<div class="pin" style="background:${esc(color)}"></div>`, iconSize: [s, s], iconAnchor: [s / 2, s * 1.15] });
  }

  function star() {
    const u = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--u")) || 10;
    const s = Math.round(u * 4.4);
    return L.divIcon({ className: "", html: `<div class="star">★</div>`, iconSize: [s, s], iconAnchor: [s / 2, s / 2] });
  }

  function drawMap(state) {
    const a = state.answer || {};
    const show = a.lat != null && state.mode !== "when";
    $("map").hidden = !show;
    if (!show) return;
    ensureMap();
    if (!map) return;
    if (mapLayer) mapLayer.remove();
    mapLayer = L.layerGroup().addTo(map);
    const points = [[a.lat, a.lon]];
    for (const r of state.results || []) {
      if (r.lat == null) continue;
      L.polyline([[r.lat, r.lon], [a.lat, a.lon]], { color: r.color, weight: 3, dashArray: "6 8", opacity: .9 }).addTo(mapLayer);
      L.marker([r.lat, r.lon], { icon: pin(r.color) }).addTo(mapLayer);
      points.push([r.lat, r.lon]);
    }
    L.marker([a.lat, a.lon], { icon: star(), zIndexOffset: 1000 }).addTo(mapLayer);
    const fit = () => {
      map.invalidateSize();
      if (points.length > 1) map.fitBounds(points, { padding: [40, 40], maxZoom: 12, animate: false });
      else map.setView(points[0], 10, { animate: false });
    };
    fit();
    setTimeout(fit, 1100);     // nach dem Einschieben der Tafel
  }

  // ------------------------------------------------------------ Auflösung und Endstand

  let revealFor = -1, finalFor = "";

  function renderReveal(state) {
    if (revealFor === state.ident) return;
    revealFor = state.ident;
    revealPhoto();
    document.body.classList.add("revealing");
    const a = state.answer || {};
    $("revealKicker").textContent = tx("answer");
    $("answerDate").textContent = QT.date(a.t, lang);
    $("answerPlace").textContent = a.place || "";
    const year = +String(a.t).slice(0, 4);
    const rows = (state.results || []).map((r) => {
      const bits = [];
      if (r.year != null) bits.push(r.year === year ? `${r.year} (${tx("exact")})` : `${r.year} (${tx("yearsOff", { n: Math.abs(r.year - year) })})`);
      if (r.km != null) bits.push(tx("kmOff", { km: QT.distance(r.km, lang) }));
      return `<li><i style="background:${esc(r.color)}"></i><span>${esc(r.name)}<small>${esc(bits.join(" · "))}</small></span><b>+${r.points}</b><span class="total">${r.total}</span></li>`;
    });
    $("results").innerHTML = rows.join("") || `<li class="none">${esc(tx("nobody"))}</li>`;
    $("reveal").hidden = false;
    $("reveal").style.animation = "none";
    $("reveal").offsetHeight;   // Animation neu starten
    $("reveal").style.animation = "";
    drawMap(state);
  }

  function renderFinal(state) {
    const key = JSON.stringify(state.final || []);
    if (finalFor === key) return;
    finalFor = key;
    document.body.classList.add("finalizing");
    $("reveal").hidden = true;
    $("finalKicker").textContent = tx("finalKicker");
    $("finalTitle").textContent = tx("final");
    $("finalNote").textContent = tx("next");
    const top = Math.max(1, ...(state.final || []).map((r) => r.score));
    $("podium").innerHTML = (state.final || []).slice(0, 8).map((r, i) => `
      <li class="${r.winner ? "winner" : ""}" style="animation-delay:${0.15 * i}s">
        <span class="rank">${i + 1}.</span>
        <span class="who"><i style="background:${esc(r.color)}"></i>${esc(r.name)}</span>
        <span class="bar"><span style="width:${(100 * r.score / top).toFixed(1)}%;background:${esc(r.color)};animation-delay:${0.15 * i + 0.3}s"></span></span>
        <span class="score">${r.score}</span>
      </li>`).join("");
    $("final").hidden = false;
  }

  // ------------------------------------------------------------ Ablauf

  let lastIdent = -1;

  function apply(state) {
    if (state.lang && TEXT[state.lang] && state.lang !== lang && !params.get("lang")) lang = state.lang;
    document.documentElement.lang = lang;
    const titleKey = state.mode === "when" ? "titleWhen" : state.mode === "where" ? "titleWhere" : "title";
    $("title").textContent = tx(titleKey);
    $("kicker").textContent = state.round ? `${tx("quiz")} · ${tx("round", { a: state.round, b: state.rounds })}` : tx("quiz");
    document.body.classList.toggle("waiting", state.phase !== "guess");

    if (state.next) {   // das nächste Foto schon mal laden
      const pre = new Image();
      pre.src = url("api/photo?id=" + state.next);
    }

    if (state.phase === "guess" && state.photo) {
      showNote("");
      clock.end = Date.now() + state.left * 1000;
      clock.dur = Math.max(1, state.dur);
      if (state.ident !== lastIdent) {
        lastIdent = state.ident;
        revealFor = -1;
        finalFor = "";
        $("reveal").hidden = true;
        $("final").hidden = true;
        document.body.classList.remove("revealing", "finalizing");
        startRound(state.photo, state);
      } else {
        round.end = clock.end;
      }
    } else if (state.phase === "reveal") {
      showNote("");
      if (state.photo && state.photo.id !== round.id) {   // Szene kam mitten in der Auflösung dazu
        lastIdent = state.ident;
        startRound(state.photo, state).then(() => { revealFor = -1; renderReveal(state); });
      } else {
        renderReveal(state);
      }
    } else if (state.phase === "final") {
      showNote("");
      renderFinal(state);
    } else if (!round.img) {
      showNote(state.count ? tx("wait") : state.busy ? tx("reading") : tx("none"));
    }
    renderHints(state);
    renderJoin(state);
  }

  async function poll() {
    try {
      const state = await api("api/game");
      apply(state);
    } catch (error) {
      if (!round.img) showNote(error.message === "login" ? tx("login") : tx("unreachable"));
    }
  }

  layout();
  $("title").textContent = tx("title");
  poll();
  setInterval(poll, 1000);
  setInterval(() => { tickClock(); tickEffects(); }, 250);
  setTimeout(ready, 8000);   // falls das erste Foto länger braucht
})();
