"""Texts of the plugin in German, English and Spanish.

The German text is also the key. t() looks up the translation in the chosen
language and fills in the placeholders; without a translation the German
text stays.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    'Trag die Adresse deines Immich-Servers ein.': (
        'Enter the address of your Immich server.',
        'Introduce la dirección de tu servidor Immich.'),
    'Trag einen API-Schlüssel von Immich ein.': (
        'Enter an API key from Immich.',
        'Introduce una clave API de Immich.'),
    'Immich ist nicht erreichbar: {exc}': (
        'Immich cannot be reached: {exc}',
        'No se puede conectar con Immich: {exc}'),
    'Immich lehnt den API-Schlüssel ab.': (
        'Immich rejects the API key.',
        'Immich rechaza la clave API.'),
    'Dem API-Schlüssel fehlt eine Berechtigung ({path}).': (
        'The API key is missing a permission ({path}).',
        'A la clave API le falta un permiso ({path}).'),
    'Unter dieser Adresse antwortet kein Immich-Server.': (
        'No Immich server answers at this address.',
        'Ningún servidor Immich responde en esta dirección.'),
    'Liest die Fotos aus Immich …': (
        'Reading the photos from Immich …',
        'Leyendo las fotos de Immich …'),
    'Schneidet Porträts aus: {done} von {total}': (
        'Cutting out portraits: {done} of {total}',
        'Recortando retratos: {done} de {total}'),
    'Die Szene Growing Up ist auf der Plugins-Seite ausgeschaltet.': (
        'The Growing Up scene is switched off on the Plugins page.',
        'La escena Growing Up está desactivada en la página de plugins.'),
    'Die Szene Growing Up ist auf diesem Rahmen nicht installiert. Installiere das Growing-Up-Paket noch einmal.': (
        'The Growing Up scene is not installed on this frame. Install the Growing Up package again.',
        'La escena Growing Up no está instalada en este marco. Vuelve a instalar el paquete Growing Up.'),
    'Der Rahmen hat die Playlist {name} nicht angelegt.': (
        'The frame did not create the playlist {name}.',
        'El marco no ha creado la lista {name}.'),
    'Wartet, bis der Bildschirm wieder frei ist.': (
        'Waiting until the screen is free again.',
        'Esperando a que la pantalla vuelva a estar libre.'),
    'Konnte die Takeover-Playlist nicht anlegen: {exc}': (
        'Could not create the takeover playlist: {exc}',
        'No se pudo crear la lista de takeover: {exc}'),
    'Konnte die Playlist Growing Up nicht pflegen: {exc}': (
        'Could not maintain the Growing Up playlist: {exc}',
        'No se pudo mantener la lista Growing Up: {exc}'),
    'Angelegt: die Playlist Growing Up steht unter Playlists.': (
        'Created: the Growing Up playlist is listed under Playlists.',
        'Creada: la lista Growing Up aparece en Playlists.'),
    'Noch nicht angelegt; das passiert innerhalb einer Minute.': (
        'Not created yet; this happens within a minute.',
        'Todavía no creada; se creará en menos de un minuto.'),
    'Die Playlist wurde gelöscht, deshalb steht das wieder auf Nein.': (
        'The playlist was deleted, so this is set back to No.',
        'La lista se ha borrado, por eso vuelve a estar en No.'),
    'Die früher angelegte Playlist steht noch unter Playlists; das Plugin pflegt sie nicht mehr.': (
        'The playlist created earlier is still under Playlists; the plugin no longer maintains it.',
        'La lista creada antes sigue en Playlists; el plugin ya no la mantiene.'),
    'Growing Up ist auf der Plugins-Seite ausgeschaltet.': (
        'Growing Up is switched off on the Plugins page.',
        'Growing Up está desactivado en la página de plugins.'),
    '„Allow takeover“ ist für Growing Up auf der Plugins-Seite aus, deshalb kann es den Bildschirm nicht übernehmen.': (
        '“Allow takeover” is off for Growing Up on the Plugins page, so it cannot take over the screen.',
        '«Allow takeover» está desactivado para Growing Up en la página de plugins, así que no puede ocupar la pantalla.'),
    'Der Rahmen hat die Anzeige beendet ({state}).': (
        'The frame ended the display ({state}).',
        'El marco ha terminado la visualización ({state}).'),
    'Growing Up ist schon auf dem Bildschirm.': (
        'Growing Up is already on screen.',
        'Growing Up ya está en pantalla.'),
    'Noch keine Porträts: wähle Personen aus und warte, bis sie ausgeschnitten sind.': (
        'No portraits yet: pick people and wait until they are cut out.',
        'Aún no hay retratos: elige personas y espera a que se recorten.'),
    'Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.': (
        'This frame is too old to hand the screen to a plugin.',
        'Este marco es demasiado antiguo para ceder la pantalla a un plugin.'),
    'Die Szene Growing Up wurde nicht gefunden.': (
        'The Growing Up scene was not found.',
        'No se ha encontrado la escena Growing Up.'),
    'Die Takeover-Playlist ist noch nicht angelegt.': (
        'The takeover playlist has not been created yet.',
        'La lista de takeover aún no se ha creado.'),
    'Growing Up läuft gerade in deiner Playlist; die Anzeige bleibt so.': (
        'Growing Up is playing in your playlist right now; the display stays as it is.',
        'Growing Up se está reproduciendo en tu lista; la pantalla se queda así.'),
    'Der Bildschirm ist aus. Growing Up weckt ihn nicht.': (
        'The screen is off. Growing Up does not wake it.',
        'La pantalla está apagada. Growing Up no la enciende.'),
    'Konnte Growing Up nicht anzeigen: {exc}': (
        'Could not show Growing Up: {exc}',
        'No se pudo mostrar Growing Up: {exc}'),
    'Etwas anderes hat gerade den Bildschirm.': (
        'Something else has the screen right now.',
        'Otra cosa está usando la pantalla ahora mismo.'),
    'Der Rahmen hat Growing Up nicht rechtzeitig angezeigt.': (
        'The frame did not show Growing Up in time.',
        'El marco no mostró Growing Up a tiempo.'),
    'Growing Up hatte den Bildschirm nicht.': (
        'Growing Up did not have the screen.',
        'Growing Up no tenía la pantalla.'),
    'Bitte den Rahmen um den Bildschirm.': (
        'Asking the frame for the screen.',
        'Pidiendo la pantalla al marco.'),
    'Gebe den Bildschirm zurück.': (
        'Handing the screen back.',
        'Devolviendo la pantalla.'),
    '{name} hat nicht geklappt: {exc}': (
        '{name} did not work: {exc}',
        '{name} no ha funcionado: {exc}'),
    'Der Rahmen ist nach Growing Up nicht zu deiner Playlist zurückgekehrt. Starte sie auf der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix passiert das nicht.': (
        'The frame did not go back to your playlist after Growing Up. Start it again on the frame\'s home page. With a saved playlist instead of a Quick Mix this does not happen.',
        'El marco no volvió a tu lista después de Growing Up. Iníciala de nuevo en la página principal del marco. Con una lista guardada en lugar de un Quick Mix esto no pasa.'),
    'Regelmäßige Anzeige ist aus.': (
        'Showing by itself is off.',
        'La visualización automática está desactivada.'),
    'Heute hat niemand Geburtstag.': (
        'Nobody has a birthday today.',
        'Hoy nadie cumple años.'),
    'Außerhalb von {start}–{end} Uhr.': (
        'Outside {start}:00–{end}:00.',
        'Fuera del horario {start}–{end} h.'),
    'Fragt Immich jetzt neu.': (
        'Asking Immich again now.',
        'Consultando Immich de nuevo.'),
    'Verbunden mit Immich {version} als {user}.': (
        'Connected to Immich {version} as {user}.',
        'Conectado a Immich {version} como {user}.'),
    'Noch nicht mit Immich verbunden.': (
        'Not connected to Immich yet.',
        'Aún no conectado con Immich.'),
    'Noch keine Person ausgewählt.': (
        'No person picked yet.',
        'Aún no has elegido ninguna persona.'),
    '{n} Porträts von {name} bereit.': (
        '{n} portraits of {name} ready.',
        '{n} retratos de {name} listos.'),
    '{n} Porträts von {people} Personen bereit.': (
        '{n} portraits of {people} people ready.',
        '{n} retratos de {people} personas listos.'),
}


def language(value):
    value = str(value or "").strip().lower()
    return value if value in LANGUAGES else "en"


def t(lang, template, **values):
    lang = language(lang)
    text = template
    if lang != "de":
        pair = _TEXTS.get(template)
        if pair:
            text = pair[LANGUAGES.index(lang) - 1]
    return text.format(**values) if values else text
