"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/ContactSheet/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["HoldSeconds", "RefreshHours", "PlaylistSeconds", "LastDays", "MinMegapixels", "MinFileKB", "DfLastDays", "DfMinMegapixels"];
const CHECK_FIELDS = ["Marker", "Grain", "OnThisDay", "WithPeople", "CameraOnly", "NoScreenshots", "NotInAlbum", "DfOnThisDay", "DfCameraOnly", "DfNoScreenshots"];
const SELECT_FIELDS = ["Direction", "Size", "Look", "Film", "Portrait", "Captions", "Distance", "Blur", "Pace", "Order", "Orientation", "DfOrientation"];
const FILTER_TEXT = ["City", "State", "Country", "TakenAfter", "TakenBefore", "Make", "Model", "Lens", "Description", "OcrText", "FileName", "SkipNames",
  "DfAfter", "DfBefore", "DfPlace", "DfMake", "DfModel", "DfLens", "DfText", "DfFileName", "DfSkipNames"];
const TEXT_FIELDS = ["ServerUrl", "Folders", "WebDavUrl", "WebDavUser"].concat(FILTER_TEXT);
// Listen zum Anhaken in den Immich-Filtern: Einstellung -> Liste
const PICKERS = { People: "people", SkipAlbums: "immich_album", SkipTags: "tags" };
const SOURCES = ["Source"];
let current = null;
let editing = false;
const lists = { playlist: null, immich_album: null, folders: null, people: null, tags: null };
const listErrors = { playlist: "", immich_album: "", folders: "", people: "", tags: "" };
const LIST_API = { playlist: ["./api/playlists", "playlists"], immich_album: ["./api/albums", "albums"], folders: ["./api/folders", "folders"], people: ["./api/people", "people"], tags: ["./api/tags", "tags"] };

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["Contact Sheet", "Contact Sheet", "Contact Sheet"],
  lede: ["Deine Fotos auf einem endlosen analogen Filmstreifen, mit Perforation, Bildnummern und Randbeschriftung. Der Streifen hält bei einem Bild an, läuft dann an, verschwimmt im Tempo und bremst beim nächsten Bild. Jede Änderung hier wird sofort gespeichert.",
    "Your photos on an endless analogue film strip, with sprocket holes, frame numbers and edge printing. The strip stops on a frame, then starts moving, blurs at speed and brakes at the next frame. Every change here is saved immediately.",
    "Tus fotos en una tira de película analógica sin fin, con perforaciones, números de fotograma y rótulos en el borde. La tira se detiene en un fotograma, arranca, se desenfoca con la velocidad y frena en el siguiente. Cada cambio aquí se guarda al instante."],
  stripTitle: ["Der Filmstreifen", "The film strip", "La tira de película"],
  direction: ["Laufrichtung", "Direction", "Dirección"],
  dirH: ["Waagrecht", "Horizontal", "Horizontal"],
  dirV: ["Von oben nach unten", "Top to bottom", "De arriba abajo"],
  size: ["Größe des Streifens", "Size of the strip", "Tamaño de la tira"],
  sizeSmall: ["Schmal", "Narrow", "Estrecha"],
  sizeMedium: ["Mittel", "Medium", "Mediana"],
  sizeLarge: ["Groß", "Large", "Grande"],
  look: ["Worauf er liegt", "What it lies on", "Sobre qué está"],
  lookLighttable: ["Leuchtpult", "Light table", "Mesa de luz"],
  lookPaper: ["Kontaktabzug auf Fotopapier", "Contact print on photo paper", "Hoja de contactos en papel fotográfico"],
  lookWood: ["Holztisch", "Wooden table", "Mesa de madera"],
  lookDark: ["Dunkler Grund", "Dark surface", "Fondo oscuro"],
  film: ["Film", "Film", "Película"],
  filmColor: ["Farbfilm", "Colour film", "Película en color"],
  filmBw: ["Schwarzweißfilm", "Black and white film", "Película en blanco y negro"],
  portrait: ["Hochformat-Fotos", "Portrait photos", "Fotos en vertical"],
  portraitCrop: ["Zuschneiden", "Crop", "Recortar"],
  portraitRotate: ["Drehen wie auf Film", "Turn like on film", "Girar como en película"],
  captions: ["Beschriftung", "Labels", "Rótulos"],
  captionsEdge: ["Nummern, Datum, Ort", "Numbers, date, place", "Números, fecha, lugar"],
  captionsNote: ["Dazu Notiz unterm Bild", "Plus a note below", "Y una nota debajo"],
  captionsNone: ["Nur Bildnummern", "Frame numbers only", "Solo números de fotograma"],
  marker: ["Angehaltenes Bild mit rotem Fettstift markieren", "Mark the stopped frame with a red grease pencil", "Marcar el fotograma detenido con lápiz graso rojo"],
  grain: ["Filmkorn", "Film grain", "Grano de película"],
  motionTitle: ["Die Bewegung", "The motion", "El movimiento"],
  holdSeconds: ["Bei einem Bild anhalten (Sekunden)", "Stop on a frame for (seconds)", "Detenerse en un fotograma (segundos)"],
  distance: ["Wie weit er dann läuft", "How far it runs then", "Cuánto avanza después"],
  distanceMixed: ["Mal eins, oft weit vorspulen", "Sometimes one, often a long spool", "A veces uno, a menudo avance largo"],
  distanceNext: ["Zum nächsten Bild", "To the next frame", "Al siguiente fotograma"],
  distanceFew: ["2 bis 4 Bilder", "2 to 4 frames", "De 2 a 4 fotogramas"],
  distanceFar: ["Weit vorspulen (10 bis 30)", "Spool far (10 to 30)", "Avance largo (10 a 30)"],
  pace: ["Tempo", "Speed", "Velocidad"],
  paceCalm: ["Ruhig", "Calm", "Tranquila"],
  paceNormal: ["Normal", "Normal", "Normal"],
  paceFast: ["Schnell", "Fast", "Rápida"],
  blur: ["Bewegungsunschärfe", "Motion blur", "Desenfoque de movimiento"],
  blurStrong: ["Deutlich", "Strong", "Marcado"],
  blurSubtle: ["Leicht", "Subtle", "Ligero"],
  blurOff: ["Aus", "Off", "Desactivado"],
  stripHint: ["Der Streifen hält bei einem Bild an. Danach läuft er langsam an, spult oft mit Vollgas viele Bilder weit durch und verschwimmt dabei, bremst ab und hält beim nächsten Bild. Jedes Bild, bei dem er anhält, ist ein neues Foto aus deiner Quelle. Von oben nach unten läuft er wie ein Kinofilm, mit etwas kleineren Bildfeldern im Querformat 4:3. Der Fettstift umrandet jedes Bild etwas anders und malt oft ein Zeichen in die Ecke. Hochformat-Fotos werden aufs Querformat zugeschnitten oder wie auf echtem Film gedreht ins Bildfeld gelegt. Die Notiz zeigt Datum und Ort in Handschrift unter dem angehaltenen Bild. Gezeichnet wird auf der Grafikkarte und nur, solange sich der Streifen bewegt.",
    "The strip stops on a frame. Then it starts slowly, often spools many frames at full speed and blurs, brakes and stops on the next frame. Every frame it stops on is a new photo from your source. Top to bottom it runs like cinema film, with slightly smaller 4:3 landscape frames. The grease pencil circles every frame a little differently and often adds a sign in the corner. Portrait photos are cropped to landscape or turned into the frame like on real film. The note shows date and place in handwriting below the stopped frame. Drawing happens on the graphics chip and only while the strip moves.",
    "La tira se detiene en un fotograma. Luego arranca despacio, a menudo avanza muchos fotogramas a toda velocidad y se desenfoca, frena y se detiene en el siguiente. Cada fotograma en el que se detiene es una foto nueva de tu fuente. De arriba abajo corre como una película de cine, con fotogramas horizontales 4:3 algo más pequeños. El lápiz graso rodea cada fotograma de forma algo distinta y a menudo dibuja un signo en la esquina. Las fotos en vertical se recortan a horizontal o se giran dentro del fotograma como en una película de verdad. La nota muestra la fecha y el lugar a mano bajo el fotograma detenido. Se dibuja con el chip gráfico y solo mientras la tira se mueve."],
  factPhotos: ["Fotos", "Photos", "Fotos"],
  factShown: ["Zuletzt gezeigt", "Last shown", "Última mostrada"],
  order: ["Reihenfolge", "Order", "Orden"],
  orderShuffle: ["Gemischt", "Shuffled", "Aleatorio"],
  orderDate: ["Nach Aufnahmedatum", "By date taken", "Por fecha de captura"],
  orderRated: ["Fotos mit mehr Sternen öfter", "Photos with more stars more often", "Fotos con más estrellas más a menudo"],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  refresh: ["Fotos neu einlesen", "Read photos again", "Volver a leer las fotos"],
  playlist: ["Playlist anlegen", "Create playlist", "Crear lista"],
  factNow: ["Gerade", "Now", "Ahora"],
  factRead: ["Zuletzt eingelesen", "Last read", "Última lectura"],
  factVersion: ["Version", "Version", "Versión"],
  nowIdle: ["Bereit", "Ready", "Listo"],
  nowList: ["Liest die Fotoliste", "Reading the photo list", "Leyendo la lista de fotos"],
  sourceTitle: ["Fotos", "Photos", "Fotos"],
  sourceHint: ["Diese Fotos kommen auf den Filmstreifen. Datum, Ort und Sterne liest das Plugin aus DynaFrame bzw. Immich.",
    "These photos go onto the film strip. The plugin reads date, place and rating from DynaFrame or Immich.",
    "Estas fotos van a la tira de película. El plugin lee la fecha, el lugar y la valoración de DynaFrame o Immich."],
  source: ["Quelle", "Source", "Fuente"],
  kindLibrary: ["Alle Fotos in DynaFrame", "All photos in DynaFrame", "Todas las fotos de DynaFrame"],
  kindPlaylist: ["Ausgewählte Playlists von DynaFrame", "Chosen DynaFrame playlists", "Listas elegidas de DynaFrame"],
  kindFolders: ["Ausgewählte Ordner in DynaFrame", "Chosen folders in DynaFrame", "Carpetas elegidas de DynaFrame"],
  playlistFilter: ["Playlist suchen …", "Search playlist …", "Buscar lista …"],
  folderFilter: ["Ordner suchen …", "Search folder …", "Buscar carpeta …"],
  noPlaylists: ["In DynaFrame gibt es keine Playlists.", "There are no playlists in DynaFrame.", "No hay listas en DynaFrame."],
  noFolders: ["DynaFrame kennt keine Fotos.", "DynaFrame knows no photos.", "DynaFrame no conoce fotos."],
  playlistNone: ["Hak mindestens eine Playlist an.", "Tick at least one playlist.", "Marca al menos una lista."],
  folderNone: ["Hak mindestens einen Ordner an.", "Tick at least one folder.", "Marca al menos una carpeta."],
  oneChosen: ["1 ausgewählt", "1 ticked", "1 marcado"],
  manyChosen: ["{n} ausgewählt", "{n} ticked", "{n} marcados"],
  kindImmichAll: ["Alle Fotos in Immich", "All photos in Immich", "Todas las fotos de Immich"],
  kindImmichAlbum: ["Ausgewählte Alben in Immich", "Chosen albums in Immich", "Álbumes elegidos de Immich"],
  albumFilter: ["Album suchen …", "Search album …", "Buscar álbum …"],
  noAlbums: ["In Immich gibt es keine Alben.", "There are no albums in Immich.", "No hay álbumes en Immich."],
  albumsChosen: ["{n} Alben ausgewählt", "{n} albums ticked", "{n} álbumes marcados"],
  albumChosen: ["1 Album ausgewählt", "1 album ticked", "1 álbum marcado"],
  albumNone: ["Hak mindestens ein Album an (auch geteilte).", "Tick at least one album (shared ones too).", "Marca al menos un álbum (también compartidos)."],
  filterTitle: ["Welche Fotos aus Immich", "Which photos from Immich", "Qué fotos de Immich"],
  filterHint: ["Gilt für Fotos aus Immich. Nach einer Änderung liest das Plugin die Fotos neu ein.",
    "Applies to photos from Immich. After a change the plugin reads the photos again.",
    "Se aplica a las fotos de Immich. Tras un cambio el plugin vuelve a leer las fotos."],
  minRating: ["Sterne", "Stars", "Estrellas"],
  ratingAny: ["Egal", "Any", "Da igual"],
  rating1: ["Mindestens 1 Stern", "At least 1 star", "Al menos 1 estrella"],
  rating2: ["Mindestens 2 Sterne", "At least 2 stars", "Al menos 2 estrellas"],
  rating3: ["Mindestens 3 Sterne", "At least 3 stars", "Al menos 3 estrellas"],
  rating4: ["Mindestens 4 Sterne", "At least 4 stars", "Al menos 4 estrellas"],
  rating5: ["5 Sterne", "5 stars", "5 estrellas"],
  favoritesOnly: ["Favoriten", "Favourites", "Favoritos"],
  grpWhat: ["Was", "What", "Qué"],
  grpWho: ["Wer", "Who", "Quién"],
  grpWhere: ["Wo", "Where", "Dónde"],
  grpWhen: ["Wann", "When", "Cuándo"],
  grpCamera: ["Kamera", "Camera", "Cámara"],
  grpText: ["Text", "Text", "Texto"],
  grpJunk: ["Aussortieren", "Skip the junk", "Descartar"],
  grpSkip: ["Weglassen", "Leave out", "Excluir"],
  orientation: ["Ausrichtung", "Orientation", "Orientación"],
  dfTitle: ["Welche Fotos aus DynaFrame", "Which photos from DynaFrame", "Qué fotos de DynaFrame"],
  dfHint: ["Gilt für Fotos aus DynaFrame (alle Fotos, Ordner, Playlists). Die Daten liest DynaFrame selbst aus den Fotos (EXIF). Fotos, die DynaFrame nicht in seiner Mediendatenbank hat, fallen weg, sobald ein Filter gesetzt ist.",
    "Applies to photos from DynaFrame (all photos, folders, playlists). DynaFrame reads this data from the photos itself (EXIF). Photos that are not in DynaFrame's media library are left out as soon as a filter is set.",
    "Se aplica a las fotos de DynaFrame (todas las fotos, carpetas, listas). DynaFrame lee estos datos de las fotos (EXIF). Las fotos que no están en la biblioteca de DynaFrame se excluyen en cuanto hay un filtro."],
  srcFiltered: ["{n} von {m} Fotos passen zu den Filtern.", "{n} of {m} photos match the filters.", "{n} de {m} fotos cumplen los filtros."],
  dfPlace: ["Ort enthält", "Place contains", "El lugar contiene"],
  dfText: ["Titel, Beschreibung oder Tags enthalten", "Title, description or tags contain", "Título, descripción o etiquetas contienen"],
  landscape: ["Querformat", "Landscape", "Horizontal"],
  portrait: ["Hochformat", "Portrait", "Vertical"],
  squareShape: ["Quadratisch", "Square", "Cuadrada"],
  peopleHint: ["Keine angehakt: egal wer. Sonst nur Fotos, auf denen mindestens eine dieser Personen ist (aus der Gesichtserkennung von Immich).",
    "None ticked: anyone. Otherwise only photos with at least one of these people (from Immich's face recognition).",
    "Ninguna marcada: cualquiera. Si no, solo fotos con al menos una de estas personas (del reconocimiento facial de Immich)."],
  peopleFilter: ["Person suchen …", "Search person …", "Buscar persona …"],
  tagFilter: ["Tag suchen …", "Search tag …", "Buscar etiqueta …"],
  nothingHere: ["Keine gefunden.", "None found.", "No se encontró ninguno."],
  city: ["Stadt", "City", "Ciudad"],
  state: ["Bundesland", "State or province", "Estado o provincia"],
  country: ["Land", "Country", "País"],
  onThisDay: ["An diesem Tag: dasselbe Datum in früheren Jahren", "On this day: the same date in earlier years", "Este día: la misma fecha en años anteriores"],
  lastDays: ["Nur die letzten … Tage (0 = aus)", "Only the last … days (0 = off)", "Solo los últimos … días (0 = desactivado)"],
  takenAfter: ["Aufgenommen ab", "Taken after", "Tomada desde"],
  takenBefore: ["Aufgenommen bis", "Taken before", "Tomada hasta"],
  make: ["Hersteller", "Make", "Marca"],
  model: ["Modell", "Model", "Modelo"],
  lens: ["Objektiv", "Lens", "Objetivo"],
  description: ["Beschreibung enthält", "Description contains", "La descripción contiene"],
  ocrText: ["Text im Bild enthält", "Text in the image contains", "El texto de la imagen contiene"],
  fileName: ["Dateiname enthält", "File name contains", "El nombre del archivo contiene"],
  withPeople: ["Nur Fotos mit Personen", "Only photos with people in them", "Solo fotos con personas"],
  cameraOnly: ["Nur Fotos aus einer Kamera (ohne Screenshots und gespeicherte Bilder)", "Only photos taken with a camera (skips screenshots and saved images)", "Solo fotos de una cámara (sin capturas ni imágenes guardadas)"],
  noScreenshots: ["Dateinamen weglassen, die nach Bildschirmfoto aussehen", "Skip file names that look like screenshots", "Omitir nombres de archivo que parecen capturas"],
  notInAlbum: ["Nur Fotos, die in keinem Album sind", "Only photos that are not in any album", "Solo fotos que no están en ningún álbum"],
  minMegapixels: ["Mindestens … Megapixel", "At least … megapixels", "Al menos … megapíxeles"],
  minFileKB: ["Mindestens … KB Dateigröße", "File size at least … KB", "Tamaño de archivo de al menos … KB"],
  skipHint: ["Ein weggelassenes Album lässt alles darin weg, auch wenn es woanders noch vorkommt.", "Leaving out an album leaves out everything in it, wherever else it turns up.", "Excluir un álbum excluye todo lo que contiene, aunque aparezca en otro sitio."],
  skipAlbums: ["Alben weglassen", "Albums to leave out", "Álbumes a excluir"],
  skipTags: ["Tags weglassen", "Tags to leave out", "Etiquetas a excluir"],
  skipNames: ["Dateinamen weglassen (mit Komma getrennt)", "File names to leave out (separate with commas)", "Nombres de archivo a excluir (separados por comas)"],
  favAll: ["Alle Fotos", "All photos", "Todas las fotos"],
  favOnly: ["Nur Favoriten", "Only favourites", "Solo favoritos"],
  archived: ["Archivierte Fotos", "Archived photos", "Fotos archivadas"],
  archNo: ["Weglassen", "Leave out", "Excluir"],
  archYes: ["Auch verwenden", "Use them too", "Usarlas también"],
  pickPlaylist: ["Playlist", "Playlist", "Lista"],
  pickAlbum: ["Album", "Album", "Álbum"],
  pick: ["Bitte wählen …", "Please pick …", "Elige …"],
  loading: ["Lädt …", "Loading …", "Cargando …"],
  srcOk: ["{n} Fotos gefunden.", "{n} photos found.", "{n} fotos encontradas."],
  srcEmpty: ["Keine Fotos gefunden.", "No photos found.", "No se han encontrado fotos."],
  refreshHours: ["Neue Fotos suchen alle … Stunden", "Look for new photos every … hours", "Buscar fotos nuevas cada … horas"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la lista (segundos)"],
  serverTitle: ["Immich-Server", "Immich server", "Servidor Immich"],
  serverHint: ["Nur nötig, wenn die Fotos von Immich kommen.", "Only needed if the photos come from Immich.", "Solo hace falta si las fotos vienen de Immich."],
  serverUrl: ["Adresse", "Address", "Dirección"],
  apiKey: ["API-Schlüssel", "API key", "Clave API"],
  keySaved: ["gespeichert (leer lassen zum Behalten)", "saved (leave empty to keep)", "guardada (deja vacío para mantenerla)"],
  keyMissing: ["noch keiner", "none yet", "ninguna todavía"],
  test: ["Verbindung testen", "Test connection", "Probar conexión"],
  testing: ["Teste …", "Testing …", "Probando …"],
  keyHow: ["So bekommst du einen API-Schlüssel", "How to get an API key", "Cómo obtener una clave API"],
  keyHint: ["In Immich oben rechts auf dein Profilbild, dann <b>Kontoeinstellungen &gt; API-Schlüssel &gt; Neuer API-Schlüssel</b>. Als Berechtigung reichen <code>asset.read</code>, <code>asset.view</code> und <code>album.read</code>; mit <b>Alle</b> geht es auch. Der Schlüssel bleibt im Plugin auf dem Rahmen.",
    "In Immich click your profile picture at the top right, then <b>Account Settings &gt; API Keys &gt; New API Key</b>. The permissions <code>asset.read</code>, <code>asset.view</code> and <code>album.read</code> are enough; <b>All</b> works too. The key stays in the plugin on the frame.",
    "En Immich pulsa tu foto de perfil arriba a la derecha y luego <b>Ajustes de la cuenta &gt; Claves API &gt; Nueva clave API</b>. Bastan los permisos <code>asset.read</code>, <code>asset.view</code> y <code>album.read</code>; con <b>Todos</b> también funciona. La clave se queda en el plugin del marco."],
  davTitle: ["Volle Auflösung für WebDAV-Fotos", "Full resolution for WebDAV photos", "Resolución completa para fotos WebDAV"],
  davHint: ["Fotos aus einer WebDAV-Quelle (z. B. Nextcloud) gibt DynaFrame an Plugins nur als kleines Vorschaubild weiter. Mit eigenen Zugangsdaten lädt das Plugin für die geöffneten Fotos das Original. Freiwillig; ohne bleibt es beim Vorschaubild.",
    "DynaFrame only hands photos from a WebDAV source (e.g. Nextcloud) to plugins as a small preview. With its own login the plugin loads the original for the opened photos. Optional; without it the preview is used.",
    "DynaFrame solo pasa a los plugins las fotos de una fuente WebDAV (p. ej. Nextcloud) como una vista previa pequeña. Con sus propios datos de acceso el plugin carga el original para las fotos abiertas. Opcional; sin ellos se usa la vista previa."],
  davUrl: ["WebDAV-Adresse", "WebDAV address", "Dirección WebDAV"],
  davUser: ["Benutzer", "User", "Usuario"],
  davPassword: ["App-Passwort", "App password", "Contraseña de aplicación"],
  davHow: ["So bekommst du ein App-Passwort", "How to get an app password", "Cómo obtener una contraseña de aplicación"],
  davHowText: ["In Nextcloud oben rechts auf dein Profilbild, dann <b>Persönliche Einstellungen &gt; Sicherheit &gt; Neues App-Passwort erstellen</b>. Adresse und Benutzer sind dieselben wie in DynaFrame unter WebDAV. Das Passwort bleibt im Plugin auf dem Rahmen.",
    "In Nextcloud click your profile picture at the top right, then <b>Personal settings &gt; Security &gt; Create new app password</b>. Address and user are the same as in DynaFrame under WebDAV. The password stays in the plugin on the frame.",
    "En Nextcloud pulsa tu foto de perfil arriba a la derecha y luego <b>Configuración personal &gt; Seguridad &gt; Crear nueva contraseña de aplicación</b>. La dirección y el usuario son los mismos que en DynaFrame en WebDAV. La contraseña se queda en el plugin del marco."],
  foldersTitle: ["Weitere Ordner auf dem Rahmen", "More folders on the frame", "Más carpetas en el marco"],
  foldersHint: ["Für „Alle Fotos in DynaFrame“: Das Plugin fragt DynaFrame nach seiner Mediendatenbank und den Medienordnern. Liegen Fotos woanders (z. B. ein eingehängtes NAS), trag die Ordner hier ein, einen pro Zeile.",
    "For “All photos in DynaFrame”: the plugin asks DynaFrame for its media library and media folders. If photos are somewhere else (e.g. a mounted NAS), enter the folders here, one per line.",
    "Para “Todas las fotos de DynaFrame”: el plugin pide a DynaFrame su biblioteca y sus carpetas. Si hay fotos en otro sitio (p. ej. un NAS montado), escribe aquí las carpetas, una por línea."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  oclock: ["{time} Uhr", "{time}", "{time}"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „Contact Sheet“ anlegen", "Create the playlist “Contact Sheet”", "Crear la lista «Contact Sheet»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistHint: ["Die Playlist enthält nur die Szene und ist eingeschaltet. Die Dauer gilt beim Anlegen; danach änderst du sie in der Playlist selbst. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist holds only the scene and is switched on. The duration applies when it is created; after that you change it in the playlist itself. You can also add the scene to any playlist yourself.",
    "La lista contiene solo la escena y está activada. La duración se aplica al crearla; después la cambias en la propia lista. También puedes añadir la escena a cualquier lista."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  if (current) {
    for (const prefix of SOURCES) renderRef(prefix, current.settings, true);
    renderPickers(current.settings);
  }
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(epoch) {
  if (!epoch) return "—";
  const date = new Date(epoch * 1000);
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

const esc = (text) => String(text).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang]);

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

// ------------------------------------------------------------ Quellen

const loading = {};
async function loadList(kind, force = false) {
  if ((lists[kind] && !force) || loading[kind]) return;   // nie zwei gleiche Anfragen auf einmal
  loading[kind] = true;
  try {
    const result = await api(LIST_API[kind][0]);
    if (result.success === false) throw new Error(result.error || "?");
    if (result.loading) {
      // Der Rahmen liest die Mediendatenbank noch; gleich noch einmal fragen
      loading[kind] = false;
      setTimeout(() => loadList(kind, true), 3000);
      return;
    }
    lists[kind] = result[LIST_API[kind][1]] || [];
    listErrors[kind] = "";
  } catch (error) {
    lists[kind] = [];
    listErrors[kind] = error.message;
  }
  loading[kind] = false;
  if (current) {
    for (const prefix of SOURCES) renderRef(prefix, current.settings, true);
    renderPickers(current.settings);
  }
}

// Playlists, Alben und Ordner: alle als Liste zum Anhaken
function chosenItems(prefix, s) {
  const kind = s[prefix + "Kind"];
  if (kind === "folders") return (s[prefix + "Dirs"] || "").split("\n").filter(Boolean);
  return (s[prefix + "Ref"] || "").split(",").filter(Boolean);
}

function saveChosen(prefix, ids) {
  const kind = current.settings[prefix + "Kind"];
  return save(kind === "folders" ? { [prefix + "Dirs"]: ids.join("\n") } : { [prefix + "Ref"]: ids.join(",") });
}

function renderChecks(prefix, s, listKind) {
  const items = lists[listKind];
  const box = el(prefix + "AlbumList");
  el(prefix + "AlbumFilter").placeholder = t(listKind === "playlist" ? "playlistFilter" : listKind === "folders" ? "folderFilter" : "albumFilter");
  if (!items) {
    box.innerHTML = `<p class="hint">${esc(t("loading"))}</p>`;
    box.dataset.html = "";
    loadList(listKind);
    return;
  }
  const chosen = new Set(chosenItems(prefix, s));
  const query = el(prefix + "AlbumFilter").value.trim().toLowerCase();
  // Angehaktes zuerst, damit es in einer langen Liste sichtbar bleibt
  const rows = items.filter((a) => !query || String(a.name).toLowerCase().includes(query))
    .sort((a, b) => (chosen.has(String(b.id)) - chosen.has(String(a.id))) || String(a.name).localeCompare(String(b.name)));
  const html = rows.map((a) => `<label title="${esc(a.name)}"><input type="checkbox" value="${esc(String(a.id))}" ${chosen.has(String(a.id)) ? "checked" : ""}>
      <span class="name">${esc(a.name)}</span>${a.count != null ? `<span class="count">${fmt(a.count)}</span>` : ""}</label>`).join("");
  if (box.dataset.html !== html) { box.innerHTML = html; box.dataset.html = html; }
  if (listErrors[listKind]) setStatus(listErrors[listKind], "bad", prefix + "Note");
  else if (!items.length) setStatus(t(listKind === "playlist" ? "noPlaylists" : listKind === "folders" ? "noFolders" : "noAlbums"), "warn", prefix + "Note");
}

function renderPickers(s) {
  for (const [name, listKind] of Object.entries(PICKERS)) {
    const items = lists[listKind];
    const box = el(name + "List");
    if (!items) {
      if (s.ServerUrl) loadList(listKind);
      continue;
    }
    const chosen = new Set((s[name] || "").split(",").filter(Boolean));
    const query = el(name + "Filter").value.trim().toLowerCase();
    // Lange Listen: angehakte und gesuchte zuerst, höchstens 200 zeigen
    const rows = items.filter((a) => chosen.has(String(a.id)) || !query || String(a.name).toLowerCase().includes(query))
      .sort((a, b) => (chosen.has(String(b.id)) - chosen.has(String(a.id))) || String(a.name).localeCompare(String(b.name)))
      .slice(0, Math.max(200, chosen.size));
    const html = rows.map((a) => `<label title="${esc(a.name)}"><input type="checkbox" value="${esc(String(a.id))}" ${chosen.has(String(a.id)) ? "checked" : ""}>
        <span class="name">${esc(a.name)}</span>${a.count != null ? `<span class="count">${fmt(a.count)}</span>` : ""}</label>`).join("");
    if (box.dataset.html !== html) { box.innerHTML = html; box.dataset.html = html; }
    const note = listErrors[listKind] || (!items.length ? t("nothingHere") : chosen.size ? t(chosen.size === 1 ? "oneChosen" : "manyChosen", { n: chosen.size }) : "");
    setStatus(note, listErrors[listKind] ? "bad" : "", name + "Note");
  }
}

function chosenNote(prefix, s) {
  const n = chosenItems(prefix, s).length;
  return n === 1 ? t("oneChosen") : n ? t("manyChosen", { n }) : "";
}

function renderRef(prefix, s) {
  const kind = s[prefix + "Kind"];
  const listKind = ["playlist", "immich_album", "folders"].includes(kind) ? kind : "";
  el(prefix + "RefField").hidden = true;
  el(prefix + "Albums").hidden = !listKind;
  if (listKind) renderChecks(prefix, s, listKind);
}

function sourceNote(prefix, state) {
  const row = state.status || {};
  const kind = state.settings[prefix + "Kind"];
  const listKind = ["playlist", "immich_album", "folders"].includes(kind) ? kind : "";
  const albums = listKind ? chosenNote(prefix, state.settings) : "";
  if (listKind && !albums) setStatus(t(kind === "playlist" ? "playlistNone" : kind === "folders" ? "folderNone" : "albumNone"), "warn", prefix + "Note");
  else if (listKind && listErrors[listKind]) setStatus(listErrors[listKind], "bad", prefix + "Note");
  else if (row.state === "error") setStatus(row.error, "bad", prefix + "Note");
  else if (row.state === "ok" || (row.state === "empty" && row.before)) {
    const found = row.before ? t("srcFiltered", { n: fmt(row.total), m: fmt(row.before) }) : row.total ? t("srcOk", { n: fmt(row.total) }) : t("srcEmpty");
    setStatus((albums ? albums + " · " : "") + found, row.total ? "ok" : "warn", prefix + "Note");
  }
  else if (row.state === "empty") setStatus(t("srcEmpty"), "warn", prefix + "Note");
  else setStatus("", "", prefix + "Note");
}

// ------------------------------------------------------------ Stand

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  const p = state.progress || {};
  el("factNow").textContent = state.busy ? t("nowList") : t("nowIdle");
  el("factPhotos").textContent = state.photos ? fmt(state.photos) : "—";
  el("factShown").textContent = state.shown && state.shown.at ? clock(state.shown.at) : "—";
  el("factRead").textContent = clock(state.at);
  el("factVersion").textContent = state.version;
  if (document.activeElement !== el("MakePlaylist")) el("MakePlaylist").value = String(Boolean(state.settings.MakePlaylist));
  el("playlistNote").textContent = state.ownPlaylist || "";
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Contact Sheet ${state.version}] `);
  if (!editing) {
    for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) el(name).value = s[name];
    el("MinRating").value = String(s.MinRating);
    el("DfMinRating").value = String(s.DfMinRating);
    renderPickers(s);
    el("FavoritesOnly").value = String(Boolean(s.FavoritesOnly));
    el("IncludeArchived").value = String(Boolean(s.IncludeArchived));
    for (const prefix of SOURCES) el(prefix + "Kind").value = s[prefix + "Kind"];
    el("Language").value = lang;
    if (document.activeElement !== el("ApiKey")) {
      el("ApiKey").placeholder = state.secretsSet.ApiKey ? t("keySaved") : t("keyMissing");
    }
    if (document.activeElement !== el("WebDavPassword")) {
      el("WebDavPassword").placeholder = state.secretsSet.WebDavPassword ? t("keySaved") : t("keyMissing");
    }
    // Adresse und Benutzer der WebDAV-Quelle von DynaFrame als Vorschlag
    const guess = state.webdav || {};
    if (guess.url) el("WebDavUrl").placeholder = guess.url;
    if (guess.user) el("WebDavUser").placeholder = guess.user;
  }
  for (const prefix of SOURCES) {
    if (document.activeElement !== el(prefix + "Ref")) renderRef(prefix, s);
    sourceNote(prefix, state);
  }
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS, ["ApiKey", "WebDavPassword"])) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
}
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const prefix of SOURCES) {
  el(prefix + "Kind").addEventListener("change", (e) => {
    el(prefix + "AlbumFilter").value = "";
    if (e.target.value === "folders") loadList("folders", true);
    save({ [prefix + "Kind"]: e.target.value, [prefix + "Ref"]: "" });
  });
}
for (const prefix of SOURCES) {
  el(prefix + "AlbumFilter").addEventListener("input", () => current && renderRef(prefix, current.settings));
  el(prefix + "AlbumList").addEventListener("change", () => {
    const list = el(prefix + "AlbumList");
    const ticked = [...list.querySelectorAll("input:checked")].map((box) => box.value);
    // Angehakte Alben behalten, die der Suchfilter gerade ausblendet
    const hidden = chosenItems(prefix, current.settings).filter((id) => !list.querySelector(`input[value="${CSS.escape(id)}"]`));
    saveChosen(prefix, [...hidden, ...ticked]);
  });
}
el("MinRating").addEventListener("change", (e) => save({ MinRating: Number(e.target.value) }));
el("DfMinRating").addEventListener("change", (e) => save({ DfMinRating: Number(e.target.value) }));
for (const name of FILTER_TEXT) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of Object.keys(PICKERS)) {
  el(name + "Filter").addEventListener("input", () => current && renderPickers(current.settings));
  el(name + "List").addEventListener("change", () => {
    const list = el(name + "List");
    const ticked = [...list.querySelectorAll("input:checked")].map((box) => box.value);
    const hidden = (current.settings[name] || "").split(",").filter(Boolean)
      .filter((id) => !list.querySelector(`input[value="${CSS.escape(id)}"]`));
    save({ [name]: [...hidden, ...ticked].join(",") });
  });
}
for (const name of ["FavoritesOnly", "IncludeArchived"]) {
  el(name).addEventListener("change", (e) => save({ [name]: e.target.value === "true" }));
}
el("Folders").addEventListener("change", (e) => save({ Folders: e.target.value }));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save({ Language: e.target.value });
});

async function saveServer() {
  const changes = { ServerUrl: el("ServerUrl").value };
  const key = el("ApiKey").value.trim();
  if (key) changes.ApiKey = key;
  const changed = await save(changes);
  el("ApiKey").value = "";
  if (changed.includes("ServerUrl") || changed.includes("ApiKey")) await testConnection();
}

async function testConnection() {
  setStatus(t("testing"), "busy", "testNote");
  try {
    const result = await api("./api/test", { method: "POST" });
    setStatus(result.message, result.ok ? "ok" : "bad", "testNote");
    if (result.ok) for (const kind of ["immich_album", "people", "tags"]) loadList(kind, true);
  } catch (error) {
    setStatus(error.message, "bad", "testNote");
  }
}

async function saveDav() {
  const guess = current?.webdav || {};
  const changes = {
    WebDavUrl: el("WebDavUrl").value.trim() || (el("WebDavPassword").value.trim() ? guess.url || "" : ""),
    WebDavUser: el("WebDavUser").value.trim() || (el("WebDavPassword").value.trim() ? guess.user || "" : ""),
  };
  const key = el("WebDavPassword").value.trim();
  if (key) changes.WebDavPassword = key;
  const changed = await save(changes);
  el("WebDavPassword").value = "";
  if (changed.length) await testDav();
}

async function testDav() {
  setStatus(t("testing"), "busy", "davNote");
  try {
    const result = await api("./api/webdavtest", { method: "POST" });
    setStatus(result.message, result.ok ? "ok" : "bad", "davNote");
  } catch (error) {
    setStatus(error.message, "bad", "davNote");
  }
}

for (const name of ["WebDavUrl", "WebDavUser", "WebDavPassword"]) el(name).addEventListener("change", saveDav);
el("davTestButton").addEventListener("click", async () => {
  const s = current?.settings || {};
  if (el("WebDavPassword").value.trim() || el("WebDavUrl").value !== (s.WebDavUrl || "") ||
      el("WebDavUser").value !== (s.WebDavUser || "")) await saveDav();
  else await testDav();
});

el("ServerUrl").addEventListener("change", saveServer);
el("ApiKey").addEventListener("change", saveServer);
el("testButton").addEventListener("click", async () => {
  if (el("ApiKey").value.trim() || el("ServerUrl").value !== (current?.settings.ServerUrl || "")) await saveServer();
  else await testConnection();
});
el("refreshButton").addEventListener("click", async () => {
  try {
    const result = await api("./api/refresh", { method: "POST" });
    setStatus(result.message || "", "busy");
    setTimeout(refresh, 1500);
  } catch (error) {
    setStatus(error.message, "bad");
  }
});
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));
refresh();
setInterval(refresh, 4000);
