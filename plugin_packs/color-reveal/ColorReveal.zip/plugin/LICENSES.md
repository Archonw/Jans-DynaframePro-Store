# Third-party notes

- The scene bundles the fonts Fraunces and Inter under the SIL Open Font License 1.1 (see `dynamic/fonts/OFL-*.txt`).
- `sources.py`, `exif_gps.py`, `immich_filters.py`, `dynaframe_filters.py` and `own_playlist.py` are shared with Jan's other DynaFrame plugins (own code).
