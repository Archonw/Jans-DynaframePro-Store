# Travel Scrapbook

The plugin finds your trips by itself and turns every trip into a scrapbook page. The frame shows one holiday after another.

## How trips are found

- **Home** is found automatically: the place where you take photos on most days. If you moved, it finds one home per year. You can also set it on the plugin page.
- A day counts as **away** if all its photos with GPS are further from home than a distance you choose (default 60 km). Days without any GPS photo don't break a trip; a day with photos at home ends it.
- A **trip** is at least 2 days away (adjustable), with at most 2 days without photos in between and at least 10 photos. Photos taken near home are left out of the trip.
- Kilometres are the route through the places of the trip, including the way there and back (as the crow flies).

## The page

- **Prints** (3–9, default 6) chosen by stars (DynaFrame's media database incl. XMP sidecars, or Immich), then favourites, spread over the days, one per burst. The best photo is the big print.
- **Route map** with coastlines, borders, the places and the route drawn by hand; home as a little house or an arrow with the distance.
- **Ticket** with days, kilometres and photos, a postmark stamp with country and month.
- **Weather** of every day from the Open-Meteo archive (free, no key), or a summary for long trips.
- **Handwritten notes**: the stations, the hottest day, rainy days, the day with the most photos, five-star photos … plus your own note in blue ink.
- Optional cover page with all trips, paper (kraft, cream, black album), animation, km/mi and °C/°F, language (English, German, Spanish).
- Order: matching the season (default), newest, oldest or random. The plugin remembers which trip was shown last.

## Plugin page

Your trips with own title, own note and "show on the frame", what counts as a trip, the home, the page settings, photo sources (DynaFrame library, playlists, Immich album or all of Immich) with filters, and "A playlist for it".

If you use an ad blocker like Pi-hole, allow `archive-api.open-meteo.com`, `geocoding-api.open-meteo.com` and `nominatim.openstreetmap.org`.
