/* Halloween Scare - die Szene.
 *
 * Alles wird auf einer Leinwand selbst gezeichnet: das Spukporträt, der
 * Geist, das Störsignal und das Monster. Keine fremden Bilder.
 *
 * Das Plugin legt die Szene über die Playlist, wenn ein Bewegungsmelder oder
 * die Klingel auslöst. Die Szene fragt jede Sekunde nach (api/scene); kommt
 * ein neuer Schreck, spielt sie ihn ab und sagt dem Plugin an den
 * passenden Stellen, welches Geräusch es spielen soll (api/cue), am Ende
 * api/done. Ohne Schreck hängt das Porträt ruhig an der Wand.
 *
 * Zum Ausprobieren im Browser: ?demo=portrait|ghost|static|monster
 * &intensity=scary|gentle &variant=lady|captain|child &lurk=5 &at=<Sekunde>
 * (friert die Zeit ein) &photo=<Bild-URL> &lang=de|en|es &plugin=<URL>.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "HalloweenScare";
  const POLL_MS = 1000;
  const MAX_SIDE = 1600;           // Auflösung der Leinwand; der Pi dankt es
  const params = new URLSearchParams(location.search);
  const DEMO = params.get("demo");
  const FREEZE = params.has("at") ? Number(params.get("at")) : null;
  const STILL = params.has("still");   // Vorschaubilder ohne Blitz
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const sameOrigin = (location.protocol === "http:" && (location.port === "" || location.port === "80"))
    || (location.protocol === "https:" && (location.port === "" || location.port === "443"));
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set(sameOrigin ? [
    `${location.origin}${advanced}`,
    `${location.protocol}//${location.hostname}:8003${advanced}`
  ] : [
    `${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`,
    `http://${location.hostname || "localhost"}${advanced}`
  ])];
  let baseIndex = 0;

  const TEXT = {
    de: { happy: "Fröhliches Halloween!", trick: "Süßes oder Saures!", boo: "Buuuh!",
      unreachable: "Halloween Scare antwortet nicht.", login: "Bitte zuerst im Browser beim Rahmen anmelden." },
    en: { happy: "Happy Halloween!", trick: "Trick or treat!", boo: "Booo!",
      unreachable: "Halloween Scare is not responding.", login: "Please sign in to the frame in the browser first." },
    es: { happy: "¡Feliz Halloween!", trick: "¡Truco o trato!", boo: "¡Buuuh!",
      unreachable: "Halloween Scare no responde.", login: "Inicia sesión primero en el marco desde el navegador." }
  };
  let lang = params.get("lang") || "en";
  const tx = (key) => (TEXT[lang] || TEXT.en)[key] || key;

  const canvas = document.getElementById("stage");
  const ctx = canvas.getContext("2d");
  let W = 0;
  let H = 0;

  // ------------------------------------------------------------ Helfer

  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const lerp = (a, b, k) => a + (b - a) * k;
  const seg = (t, a, b) => clamp((t - a) / (b - a));
  const easeOut = (k) => 1 - Math.pow(1 - k, 3);
  const easeInOut = (k) => k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
  const hash = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
  const flick = (t, rate, seed = 0) => hash(Math.floor(t * rate) + seed * 1000);

  function mix(c1, c2, k) {
    const a = parseInt(c1.slice(1), 16);
    const b = parseInt(c2.slice(1), 16);
    const ch = (s) => Math.round(lerp((a >> s) & 255, (b >> s) & 255, k));
    return `rgb(${ch(16)},${ch(8)},${ch(0)})`;
  }

  function offscreen(w, h) {
    const c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(w));
    c.height = Math.max(1, Math.round(h));
    return c;
  }

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let w = Math.round(window.innerWidth * dpr);
    let h = Math.round(window.innerHeight * dpr);
    const k = Math.min(1, MAX_SIDE / Math.max(w, h));
    w = Math.round(w * k);
    h = Math.round(h * k);
    if (w === W && h === H) return;
    W = canvas.width = w;
    H = canvas.height = h;
    room = null;
    corridor = null;
    photoCache = null;
  }

  // ------------------------------------------------------------ Rauschen

  const noiseFrames = [];
  (function makeNoise() {
    for (let f = 0; f < 6; f += 1) {
      const c = offscreen(320, 180);
      const g = c.getContext("2d");
      const img = g.createImageData(c.width, c.height);
      for (let i = 0; i < img.data.length; i += 4) {
        const v = Math.random() * 255;
        img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
        img.data[i + 3] = 255;
      }
      g.putImageData(img, 0, 0);
      noiseFrames.push(c);
    }
  }());

  function drawNoise(alpha, t) {
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(noiseFrames[Math.floor(t * 30) % noiseFrames.length], 0, 0, W, H);
    ctx.restore();
  }

  function drawScanlines(alpha) {
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = "#000";
    const step = Math.max(2, Math.round(H / 240));
    for (let y = 0; y < H; y += step * 2) ctx.fillRect(0, y, W, step);
    ctx.restore();
  }

  function vignette(strength, color = "0,0,0") {
    const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.25, W / 2, H / 2, Math.hypot(W, H) * 0.6);
    g.addColorStop(0, `rgba(${color},0)`);
    g.addColorStop(1, `rgba(${color},${strength})`);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
  }

  function flash(alpha, color = "#fff") {
    if (alpha <= 0.01 || (STILL && color !== "#000")) return;
    ctx.save();
    ctx.globalAlpha = clamp(alpha);
    ctx.fillStyle = color;
    ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }

  function black(alpha) { flash(alpha, "#000"); }

  function title(text, y, size, alpha = 1, color = "#ff7a1a") {
    if (alpha <= 0.01) return;
    ctx.save();
    ctx.globalAlpha = clamp(alpha);
    ctx.font = `${Math.round(size)}px Creepster, "Trebuchet MS", serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    let px = Math.round(size);
    while (px > 12 && ctx.measureText(text).width > W * 0.9) {
      px -= 4;
      ctx.font = `${px}px Creepster, "Trebuchet MS", serif`;
    }
    ctx.shadowColor = "rgba(255,90,0,.75)";
    ctx.shadowBlur = px * 0.35;
    ctx.lineWidth = px * 0.08;
    ctx.strokeStyle = "#1a0700";
    ctx.strokeText(text, W / 2, y);
    ctx.fillStyle = color;
    ctx.fillText(text, W / 2, y);
    ctx.restore();
  }

  // ------------------------------------------------------------ Hintergrund: Foto oder Flur

  let photo = null;          // geladenes Bild für Geist, Störsignal, Monster
  let photoCache = null;     // {img, grey, spot} passend zur Leinwand
  let corridor = null;

  function makeCorridor() {
    const c = offscreen(W, H);
    const g = c.getContext("2d");
    const cx = W * 0.5;
    const cy = H * 0.46;
    const dw = Math.min(W, H) * 0.16;
    const dh = dw * 1.9;
    const back = { l: cx - dw, r: cx + dw, t: cy - dh * 0.55, b: cy + dh * 0.55 };
    g.fillStyle = "#0b0a0c";
    g.fillRect(0, 0, W, H);
    const poly = (pts, fill) => {
      g.beginPath();
      g.moveTo(pts[0][0], pts[0][1]);
      for (const p of pts.slice(1)) g.lineTo(p[0], p[1]);
      g.closePath();
      g.fillStyle = fill;
      g.fill();
    };
    const wallL = g.createLinearGradient(0, 0, back.l, 0);
    wallL.addColorStop(0, "#1b1716");
    wallL.addColorStop(1, "#3a332c");
    poly([[0, 0], [back.l, back.t], [back.l, back.b], [0, H]], wallL);
    const wallR = g.createLinearGradient(W, 0, back.r, 0);
    wallR.addColorStop(0, "#171313");
    wallR.addColorStop(1, "#352e28");
    poly([[W, 0], [back.r, back.t], [back.r, back.b], [W, H]], wallR);
    const floor = g.createLinearGradient(0, H, 0, back.b);
    floor.addColorStop(0, "#1a120c");
    floor.addColorStop(1, "#2c2016");
    poly([[0, H], [back.l, back.b], [back.r, back.b], [W, H]], floor);
    poly([[0, 0], [back.l, back.t], [back.r, back.t], [W, 0]], "#0e0c0c");
    // Tapetenstreifen
    g.strokeStyle = "rgba(0,0,0,.25)";
    g.lineWidth = Math.max(1, W / 500);
    for (let i = 1; i < 9; i += 1) {
      const k = i / 9;
      g.beginPath();
      g.moveTo(lerp(0, back.l, k * k), lerp(0, back.t, k * k));
      g.lineTo(lerp(0, back.l, k * k), lerp(H, back.b, k * k));
      g.stroke();
      g.beginPath();
      g.moveTo(lerp(W, back.r, k * k), lerp(0, back.t, k * k));
      g.lineTo(lerp(W, back.r, k * k), lerp(H, back.b, k * k));
      g.stroke();
    }
    // Dielen
    g.strokeStyle = "rgba(0,0,0,.35)";
    for (let i = -6; i <= 6; i += 1) {
      g.beginPath();
      g.moveTo(cx + i * dw * 0.33, back.b);
      g.lineTo(cx + i * W * 0.12, H);
      g.stroke();
    }
    // die Tür hinten, einen Spalt offen, Licht dahinter
    g.fillStyle = "#1c120b";
    g.fillRect(back.l + dw * 0.45, back.t + dh * 0.12, dw * 1.1, back.b - back.t - dh * 0.12);
    const light = g.createLinearGradient(cx + dw * 0.35, 0, cx + dw * 0.5, 0);
    light.addColorStop(0, "rgba(255,190,110,.0)");
    light.addColorStop(1, "rgba(255,190,110,.55)");
    g.fillStyle = light;
    g.fillRect(cx + dw * 0.4, back.t + dh * 0.12, dw * 0.15, back.b - back.t - dh * 0.12);
    // Lichtschein auf dem Boden
    const pool = g.createRadialGradient(cx + dw * 0.4, back.b, 1, cx + dw * 0.4, back.b, dw * 2.2);
    pool.addColorStop(0, "rgba(255,170,90,.25)");
    pool.addColorStop(1, "rgba(255,170,90,0)");
    g.fillStyle = pool;
    g.fillRect(0, 0, W, H);
    const vg = g.createRadialGradient(cx, cy, dw, cx, cy, Math.hypot(W, H) * 0.6);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, "rgba(0,0,0,.85)");
    g.fillStyle = vg;
    g.fillRect(0, 0, W, H);
    return { canvas: c, spot: { x: cx - dw * 0.1, y: back.b, h: dh * 1.05 } };
  }

  function preparePhoto() {
    if (!photo) return null;
    if (photoCache && photoCache.img === photo) return photoCache;
    const c = offscreen(W, H);
    const g = c.getContext("2d");
    const iw = photo.naturalWidth || photo.width;
    const ih = photo.naturalHeight || photo.height;
    const k = Math.max(W / iw, H / ih);
    g.drawImage(photo, (W - iw * k) / 2, (H - ih * k) / 2, iw * k, ih * k);
    const grey = offscreen(W, H);
    const gg = grey.getContext("2d");
    gg.filter = "grayscale(.75) brightness(.55) contrast(1.15)";
    gg.drawImage(c, 0, 0);
    // die dunkelste Ecke, in der der Geist stehen kann (nicht ganz am Rand)
    const sw = 24;
    const sh = 14;
    const small = offscreen(sw, sh);
    const sg = small.getContext("2d");
    sg.drawImage(c, 0, 0, sw, sh);
    let d = null;
    try { d = sg.getImageData(0, 0, sw, sh).data; } catch (_) { d = null; }
    let best = null;
    for (let y = 3; d && y < sh - 3; y += 1) {
      for (let x = 3; x < sw - 3; x += 1) {
        let sum = 0;
        for (let yy = -2; yy <= 2; yy += 1) {
          for (let xx = -1; xx <= 1; xx += 1) {
            const i = ((y + yy) * sw + x + xx) * 4;
            sum += d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11;
          }
        }
        const centre = Math.abs(x - sw / 2) / sw;   // nicht genau in der Mitte, da kommt er später
        const score = sum + (centre < 0.12 ? 500 : 0);
        if (!best || score < best.score) best = { score, x, y };
      }
    }
    const spot = best ? { x: (best.x + 0.5) / sw * W, y: (best.y + 2.5) / sh * H, h: H * 0.36 }
      : { x: W * 0.25, y: H * 0.8, h: H * 0.36 };
    photoCache = { img: photo, canvas: c, grey, spot };
    return photoCache;
  }

  /** Hintergrund zeichnen; liefert die Stelle für den Geist. */
  function background(zoom = 1, greyK = 0) {
    const p = preparePhoto();
    let src;
    let spot;
    if (p) {
      src = p.canvas;
      spot = p.spot;
    } else {
      if (!corridor) corridor = makeCorridor();
      src = corridor.canvas;
      spot = corridor.spot;
    }
    ctx.save();
    ctx.translate(W / 2, H / 2);
    ctx.scale(zoom, zoom);
    ctx.translate(-W / 2, -H / 2);
    ctx.drawImage(src, 0, 0);
    if (p && greyK > 0) {
      ctx.globalAlpha = clamp(greyK);
      ctx.drawImage(p.grey, 0, 0);
    }
    ctx.restore();
    return { x: W / 2 + (spot.x - W / 2) * zoom, y: H / 2 + (spot.y - H / 2) * zoom, h: spot.h * zoom };
  }

  // ------------------------------------------------------------ Das Spukporträt

  let room = null;          // Wand, Rahmen und Struktur, einmal je Größe

  function paintingRect() {
    let ph = H * 0.72;
    let pw = ph * 0.75;
    if (pw > W * 0.74) {
      pw = W * 0.74;
      ph = pw / 0.75;
    }
    return { x: (W - pw) / 2, y: H * 0.48 - ph / 2, w: pw, h: ph };
  }

  function makeRoom() {
    const r = paintingRect();
    const c = offscreen(W, H);
    const g = c.getContext("2d");
    const wall = g.createLinearGradient(0, 0, 0, H);
    wall.addColorStop(0, "#14100c");
    wall.addColorStop(0.5, "#221a12");
    wall.addColorStop(1, "#0d0a08");
    g.fillStyle = wall;
    g.fillRect(0, 0, W, H);
    // Tapete mit Damastmuster
    const step = Math.max(40, Math.min(W, H) / 9);
    g.fillStyle = "rgba(120,90,50,.06)";
    for (let y = -step; y < H + step; y += step) {
      for (let x = -step; x < W + step; x += step) {
        const ox = (Math.round(y / step) % 2) * step / 2;
        const px = x + ox;
        g.beginPath();
        g.moveTo(px, y - step * 0.32);
        g.quadraticCurveTo(px + step * 0.22, y, px, y + step * 0.32);
        g.quadraticCurveTo(px - step * 0.22, y, px, y - step * 0.32);
        g.fill();
        g.beginPath();
        g.arc(px, y - step * 0.42, step * 0.05, 0, Math.PI * 2);
        g.fill();
      }
    }
    // Holzvertäfelung unten
    const panelTop = Math.max(r.y + r.h + H * 0.03, H * 0.86);
    if (panelTop < H) {
      const wood = g.createLinearGradient(0, panelTop, 0, H);
      wood.addColorStop(0, "#2a1a0e");
      wood.addColorStop(1, "#120a05");
      g.fillStyle = wood;
      g.fillRect(0, panelTop, W, H - panelTop);
      g.fillStyle = "#3b2512";
      g.fillRect(0, panelTop, W, Math.max(3, H * 0.008));
    }
    // Rahmen
    const fb = r.w * 0.11;
    g.save();
    g.shadowColor = "rgba(0,0,0,.8)";
    g.shadowBlur = fb * 0.8;
    g.shadowOffsetY = fb * 0.25;
    g.fillStyle = "#3a2608";
    g.fillRect(r.x - fb, r.y - fb, r.w + fb * 2, r.h + fb * 2);
    g.restore();
    const gold = (x0, y0, x1, y1) => {
      const gr = g.createLinearGradient(x0, y0, x1, y1);
      gr.addColorStop(0, "#4a300a");
      gr.addColorStop(0.3, "#c7973e");
      gr.addColorStop(0.5, "#f1d27d");
      gr.addColorStop(0.7, "#a87a2a");
      gr.addColorStop(1, "#3e2807");
      return gr;
    };
    const bands = [[1, 0.72], [0.72, 0.48], [0.48, 0.22], [0.22, 0]];
    bands.forEach(([outer, inner], i) => {
      const o = fb * outer;
      const n = fb * inner;
      g.fillStyle = gold(r.x - o, r.y - o, r.x + r.w + o, r.y + r.h + o);
      g.beginPath();
      g.rect(r.x - o, r.y - o, r.w + o * 2, r.h + o * 2);
      g.rect(r.x - n, r.y - n, r.w + n * 2, r.h + n * 2);
      g.fill("evenodd");
      g.strokeStyle = i % 2 ? "rgba(255,240,190,.35)" : "rgba(40,20,0,.55)";
      g.lineWidth = Math.max(1, fb * 0.03);
      g.strokeRect(r.x - n, r.y - n, r.w + n * 2, r.h + n * 2);
    });
    // Perlenreihe
    g.fillStyle = "#e5c06a";
    const bead = fb * 0.07;
    const inset = fb * 0.6;
    const beadRow = (x0, y0, x1, y1) => {
      const len = Math.hypot(x1 - x0, y1 - y0);
      const count = Math.floor(len / (bead * 3));
      for (let i = 0; i <= count; i += 1) {
        g.beginPath();
        g.arc(lerp(x0, x1, i / count), lerp(y0, y1, i / count), bead, 0, Math.PI * 2);
        g.fill();
      }
    };
    beadRow(r.x - inset, r.y - inset, r.x + r.w + inset, r.y - inset);
    beadRow(r.x - inset, r.y + r.h + inset, r.x + r.w + inset, r.y + r.h + inset);
    beadRow(r.x - inset, r.y - inset, r.x - inset, r.y + r.h + inset);
    beadRow(r.x + r.w + inset, r.y - inset, r.x + r.w + inset, r.y + r.h + inset);
    // Ecken-Ornamente
    for (const [cx, cy] of [[r.x - fb * 0.5, r.y - fb * 0.5], [r.x + r.w + fb * 0.5, r.y - fb * 0.5],
      [r.x - fb * 0.5, r.y + r.h + fb * 0.5], [r.x + r.w + fb * 0.5, r.y + r.h + fb * 0.5]]) {
      const rad = fb * 0.75;
      const og = g.createRadialGradient(cx - rad * 0.3, cy - rad * 0.3, rad * 0.1, cx, cy, rad);
      og.addColorStop(0, "#fbe6a0");
      og.addColorStop(0.5, "#c08f36");
      og.addColorStop(1, "#4a300a");
      g.fillStyle = og;
      g.beginPath();
      for (let i = 0; i < 16; i += 1) {
        const a = (i / 16) * Math.PI * 2;
        const rr = rad * (i % 2 ? 0.62 : 1);
        g.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr);
      }
      g.closePath();
      g.fill();
      g.strokeStyle = "rgba(60,30,0,.6)";
      g.lineWidth = Math.max(1, fb * 0.03);
      g.beginPath();
      for (let a = 0; a < Math.PI * 5; a += 0.2) {
        const rr = rad * 0.5 * (1 - a / (Math.PI * 5));
        g.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr);
      }
      g.stroke();
    }
    // Messingschild
    const pw = r.w * 0.3;
    const pTop = r.y + r.h + fb * 1.25;
    if (pTop + fb * 0.5 < H) {
      g.fillStyle = gold(r.x + (r.w - pw) / 2, pTop, r.x + (r.w + pw) / 2, pTop + fb * 0.4);
      g.fillRect(r.x + (r.w - pw) / 2, pTop, pw, fb * 0.38);
    }
    // Struktur der Leinwand: Craquelé und Körnung
    const tex = offscreen(r.w, r.h);
    const tg = tex.getContext("2d");
    const img = tg.createImageData(tex.width, tex.height);
    for (let i = 0; i < img.data.length; i += 4) {
      const v = 128 + (Math.random() - 0.5) * 60;
      img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
      img.data[i + 3] = 26;
    }
    tg.putImageData(img, 0, 0);
    tg.strokeStyle = "rgba(10,5,0,.18)";
    tg.lineWidth = Math.max(0.6, r.w / 600);
    for (let k = 0; k < 140; k += 1) {
      let x = Math.random() * r.w;
      let y = Math.random() * r.h;
      tg.beginPath();
      tg.moveTo(x, y);
      for (let s = 0; s < 6; s += 1) {
        x += (Math.random() - 0.5) * r.w * 0.08;
        y += (Math.random() - 0.5) * r.w * 0.08;
        tg.lineTo(x, y);
      }
      tg.stroke();
    }
    return { canvas: c, rect: r, tex, fb };
  }

  const VARIANTS = {
    lady: { skin: "#e9c7a6", skinDark: "#8a5a3e", hair: "#4a2412", hairHi: "#7a3d1f", iris: "#4d6b3a",
      clothes: "#1d3b3a", clothesHi: "#2f5a57", bg1: "#3b2c1b", bg2: "#0f0b07" },
    captain: { skin: "#dcb18e", skinDark: "#7a4c33", hair: "#8d8a83", hairHi: "#c4c0b6", iris: "#4a5f7a",
      clothes: "#1b2440", clothesHi: "#2d3b66", bg1: "#2f2a20", bg2: "#0c0a07" },
    child: { skin: "#f0d2b8", skinDark: "#94634a", hair: "#c9a35a", hairHi: "#ead08a", iris: "#5a7fa8",
      clothes: "#5b1a1e", clothesHi: "#7d2a2f", bg1: "#33291c", bg2: "#0d0a07" }
  };
  const GHOUL = { skin: "#a9b39a", skinDark: "#2f3a2a" };

  /* Das Gesicht im Raum 300 x 400 der Leinwand. p: lookX, lookY (-1..1),
   * ghoul, mouth, smile (0..1), blinkL, blinkR, brow, pupil, tilt. */
  function drawPortrait(g, v, p) {
    const c = VARIANTS[v] || VARIANTS.lady;
    const k = p.ghoul;
    const skin = mix(c.skin, GHOUL.skin, k);
    const skinDark = mix(c.skinDark, GHOUL.skinDark, k);
    const child = v === "child";
    const drop = 26 * p.mouth * k;          // der Kiefer fällt beim Schrei

    const bg = g.createRadialGradient(150, 160, 20, 150, 200, 260);
    bg.addColorStop(0, mix(c.bg1, "#2a0d0a", k * 0.7));
    bg.addColorStop(1, c.bg2);
    g.fillStyle = bg;
    g.fillRect(0, 0, 300, 400);

    g.save();
    g.translate(150, 300);
    g.rotate(p.tilt || 0);
    g.translate(-150, -300);

    // Haare hinten
    g.fillStyle = c.hair;
    if (v === "lady") {
      g.beginPath();
      g.ellipse(150, 158, 78, 92, 0, 0, Math.PI * 2);
      g.fill();
      g.beginPath();
      g.ellipse(150, 78, 42, 30, 0, 0, Math.PI * 2);
      g.fill();
    } else if (child) {
      g.beginPath();
      g.ellipse(150, 162, 76, 86, 0, Math.PI, 0);
      g.lineTo(226, 215);
      g.quadraticCurveTo(150, 236, 74, 215);
      g.closePath();
      g.fill();
    } else {
      g.beginPath();
      g.ellipse(150, 150, 66, 76, 0, 0, Math.PI * 2);
      g.fill();
    }

    // Körper und Kleidung
    const body = g.createLinearGradient(0, 250, 0, 400);
    body.addColorStop(0, c.clothesHi);
    body.addColorStop(1, c.clothes);
    g.fillStyle = body;
    g.beginPath();
    g.moveTo(10, 400);
    g.bezierCurveTo(20, 300, 70, 268, 120, 258);
    g.lineTo(180, 258);
    g.bezierCurveTo(230, 268, 280, 300, 290, 400);
    g.closePath();
    g.fill();

    // Hals
    const neck = g.createLinearGradient(125, 0, 175, 0);
    neck.addColorStop(0, skinDark);
    neck.addColorStop(0.5, skin);
    neck.addColorStop(1, skinDark);
    g.fillStyle = neck;
    g.beginPath();
    g.moveTo(128, 205);
    g.lineTo(126, 266);
    g.quadraticCurveTo(150, 278, 174, 266);
    g.lineTo(172, 205);
    g.closePath();
    g.fill();

    if (v === "lady") {
      // Spitzenkragen und Perlen
      g.fillStyle = "#e8e0cc";
      for (let i = 0; i < 9; i += 1) {
        const a = Math.PI * (0.15 + i * 0.0875);
        g.beginPath();
        g.arc(150 + Math.cos(a) * 62, 252 + Math.sin(a) * 18, 9, 0, Math.PI * 2);
        g.fill();
      }
      g.fillStyle = "#f6f1e6";
      for (let i = 0; i < 13; i += 1) {
        const a = Math.PI * (0.12 + i * 0.063);
        g.beginPath();
        g.arc(150 + Math.cos(a) * 30, 258 + Math.sin(a) * 14, 3.1, 0, Math.PI * 2);
        g.fill();
      }
    } else if (v === "captain") {
      // Kragen, Epauletten, Knöpfe
      g.fillStyle = "#e9e3d4";
      g.beginPath();
      g.moveTo(130, 258);
      g.lineTo(150, 300);
      g.lineTo(170, 258);
      g.closePath();
      g.fill();
      for (const x of [55, 245]) {
        g.fillStyle = "#c8962f";
        g.beginPath();
        g.ellipse(x, 292, 34, 13, x < 150 ? -0.35 : 0.35, 0, Math.PI * 2);
        g.fill();
        g.strokeStyle = "#e7c063";
        g.lineWidth = 2;
        for (let i = -4; i <= 4; i += 1) {
          g.beginPath();
          g.moveTo(x + i * 7, 300);
          g.lineTo(x + i * 7.6, 318);
          g.stroke();
        }
      }
      g.fillStyle = "#e0b04a";
      for (const y of [318, 346, 374]) {
        for (const x of [128, 172]) {
          g.beginPath();
          g.arc(x, y, 4.2, 0, Math.PI * 2);
          g.fill();
        }
      }
    } else {
      // Matrosenkragen mit Schleife
      g.fillStyle = "#efe9dc";
      g.beginPath();
      g.moveTo(92, 268);
      g.lineTo(150, 330);
      g.lineTo(208, 268);
      g.lineTo(230, 300);
      g.lineTo(150, 352);
      g.lineTo(70, 300);
      g.closePath();
      g.fill();
      g.strokeStyle = "#2b3d6b";
      g.lineWidth = 3;
      g.beginPath();
      g.moveTo(80, 296);
      g.lineTo(150, 342);
      g.lineTo(220, 296);
      g.stroke();
      g.fillStyle = "#2b3d6b";
      g.beginPath();
      g.moveTo(150, 330);
      g.lineTo(130, 318);
      g.lineTo(132, 342);
      g.closePath();
      g.moveTo(150, 330);
      g.lineTo(170, 318);
      g.lineTo(168, 342);
      g.closePath();
      g.fill();
    }

    // Kopf (der Kiefer kann fallen)
    const head = g.createRadialGradient(136, 140, 8, 150, 170, 90);
    head.addColorStop(0, mix(c.skin, "#ffffff", 0.18 * (1 - k)));
    head.addColorStop(0.55, skin);
    head.addColorStop(1, skinDark);
    g.fillStyle = head;
    const hw = child ? 58 : 60;
    const hh = child ? 72 : 78;
    g.beginPath();
    g.ellipse(150, 165, hw, hh, 0, Math.PI, 0);
    g.ellipse(150, 165, hw - 2 - 6 * k, hh + drop, 0, 0, Math.PI);
    g.fill();
    // Ohren (beim Kind und der Dame unter den Haaren)
    if (v === "captain") {
      g.fillStyle = mix(c.skin, c.skinDark, 0.45 + 0.3 * k);
      for (const x of [150 - hw + 1, 150 + hw - 1]) {
        g.beginPath();
        g.ellipse(x, 172, 6, 13, 0, 0, Math.PI * 2);
        g.fill();
      }
    }

    // Grusel: eingefallene Wangen, Adern, dunkle Augenhöhlen
    if (k > 0.01) {
      g.save();
      g.globalAlpha = k * 0.65;
      for (const x of [118, 182]) {
        const cheek = g.createRadialGradient(x, 205 + drop * 0.3, 2, x, 205 + drop * 0.3, 26);
        cheek.addColorStop(0, "rgba(20,30,15,.9)");
        cheek.addColorStop(1, "rgba(20,30,15,0)");
        g.fillStyle = cheek;
        g.fillRect(x - 30, 170, 60, 80 + drop);
      }
      g.strokeStyle = "rgba(40,60,40,.8)";
      g.lineWidth = 1.2;
      for (const [x0, y0, x1, y1] of [[120, 100, 136, 128], [182, 98, 170, 126], [150, 92, 146, 118]]) {
        g.beginPath();
        g.moveTo(x0, y0);
        g.quadraticCurveTo((x0 + x1) / 2 + 6, (y0 + y1) / 2, x1, y1);
        g.stroke();
      }
      g.restore();
    }

    // Augen
    const ew = child ? 15 : 13;
    const eh = (child ? 9 : 7) * (1 + 0.45 * k);
    for (const [x, blink] of [[126, p.blinkL], [174, p.blinkR]]) {
      drawEye(g, x, 162, ew, eh, p, blink, c, k, child);
    }

    // Brauen
    g.strokeStyle = mix(c.hair, "#1a1410", 0.5 + 0.5 * k);
    g.lineWidth = child ? 2.6 : 3.4;
    g.lineCap = "round";
    const browUp = (p.brow || 0) * 5;
    for (const side of [-1, 1]) {
      const inner = 150 + side * 9;
      const outer = 150 + side * 42;
      g.beginPath();
      g.moveTo(outer, 146 - browUp);
      g.quadraticCurveTo(150 + side * 26, 138 - browUp - 3 * (1 - k), inner, 146 - browUp + 7 * k);
      g.stroke();
    }

    // Nase
    g.strokeStyle = mix(c.skinDark, "#1a2017", k);
    g.lineWidth = 1.6;
    g.beginPath();
    g.moveTo(146, 168);
    g.quadraticCurveTo(142, 190, 145, 196);
    g.stroke();
    g.fillStyle = `rgba(60,30,20,${0.35 + 0.4 * k})`;
    for (const x of [143, 157]) {
      g.beginPath();
      g.ellipse(x, 197, 3.2 + k, 2 + k, 0, 0, Math.PI * 2);
      g.fill();
    }

    // Bart und Hut beim Kapitän
    if (v === "captain") {
      g.fillStyle = c.hair;
      g.beginPath();
      g.moveTo(92, 172);
      g.quadraticCurveTo(96, 236 + drop, 150, 252 + drop);
      g.quadraticCurveTo(204, 236 + drop, 208, 172);
      g.quadraticCurveTo(200, 210, 150, 214);
      g.quadraticCurveTo(100, 210, 92, 172);
      g.fill();
      g.strokeStyle = c.hairHi;
      g.lineWidth = 1;
      for (let i = 0; i < 26; i += 1) {
        const x = 100 + i * 3.9;
        g.beginPath();
        g.moveTo(x, 205 + Math.abs(i - 13) * -1.5);
        g.lineTo(x + 2, 232 + drop - Math.abs(i - 13) * 1.6);
        g.stroke();
      }
    }

    drawMouth(g, p, k, c, drop, v);

    if (v === "captain") {
      // Schnurrbart über dem Mund
      g.fillStyle = c.hair;
      g.beginPath();
      g.moveTo(150, 205);
      g.quadraticCurveTo(128, 200, 116, 216);
      g.quadraticCurveTo(134, 210, 150, 212);
      g.quadraticCurveTo(166, 210, 184, 216);
      g.quadraticCurveTo(172, 200, 150, 205);
      g.fill();
    }

    // Haare vorne
    g.fillStyle = c.hair;
    if (v === "lady") {
      g.beginPath();
      g.moveTo(88, 150);
      g.bezierCurveTo(92, 95, 130, 82, 152, 98);
      g.bezierCurveTo(132, 104, 112, 120, 104, 160);
      g.closePath();
      g.fill();
      g.beginPath();
      g.moveTo(212, 150);
      g.bezierCurveTo(208, 95, 170, 82, 148, 98);
      g.bezierCurveTo(168, 104, 188, 120, 196, 160);
      g.closePath();
      g.fill();
      g.strokeStyle = c.hairHi;
      g.globalAlpha = 0.5;
      g.lineWidth = 1.2;
      for (let i = 0; i < 4; i += 1) {
        for (const side of [-1, 1]) {
          g.beginPath();
          g.moveTo(150 + side * (58 - i * 3), 148 - i * 4);
          g.bezierCurveTo(150 + side * (56 - i * 2), 104 + i * 2, 150 + side * (30 - i * 2), 92 + i * 2, 150 + side * 4, 99);
          g.stroke();
        }
      }
      g.globalAlpha = 1;
      // Locke an der Seite
      g.beginPath();
      g.strokeStyle = c.hair;
      g.lineWidth = 6;
      g.moveTo(86, 170);
      g.bezierCurveTo(78, 200, 96, 205, 88, 230);
      g.stroke();
    } else if (child) {
      g.beginPath();
      g.ellipse(150, 120, 64, 46, 0, Math.PI, 0);
      g.lineTo(214, 128);
      g.lineTo(86, 128);
      g.closePath();
      g.fill();
      g.strokeStyle = c.hairHi;
      g.lineWidth = 1.2;
      for (let i = 0; i < 18; i += 1) {
        g.beginPath();
        g.moveTo(92 + i * 6.6, 84 + Math.abs(i - 9) * 2.4);
        g.lineTo(94 + i * 6.6, 127);
        g.stroke();
      }
      // Schleife im Haar
      g.fillStyle = "#9b1d2a";
      g.beginPath();
      g.moveTo(196, 86);
      g.lineTo(178, 72);
      g.lineTo(180, 98);
      g.closePath();
      g.moveTo(196, 86);
      g.lineTo(214, 72);
      g.lineTo(212, 98);
      g.closePath();
      g.fill();
    } else {
      // Seitenhaar und Hut (Zweispitz)
      g.beginPath();
      g.ellipse(94, 150, 12, 30, 0.2, 0, Math.PI * 2);
      g.ellipse(206, 150, 12, 30, -0.2, 0, Math.PI * 2);
      g.fill();
      const hat = g.createLinearGradient(0, 40, 0, 120);
      hat.addColorStop(0, "#2a3256");
      hat.addColorStop(1, "#0d1226");
      g.fillStyle = hat;
      g.beginPath();
      g.moveTo(50, 118);
      g.quadraticCurveTo(80, 52, 150, 44);
      g.quadraticCurveTo(220, 52, 250, 118);
      g.quadraticCurveTo(150, 92, 50, 118);
      g.fill();
      g.strokeStyle = "#d9a840";
      g.lineWidth = 3;
      g.beginPath();
      g.moveTo(54, 114);
      g.quadraticCurveTo(150, 90, 246, 114);
      g.stroke();
      g.fillStyle = "#d9a840";
      g.beginPath();
      g.arc(150, 80, 9, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = "#7a1420";
      g.beginPath();
      g.arc(150, 80, 5, 0, Math.PI * 2);
      g.fill();
    }
    g.restore();

    // Kerzenlicht von unten links und Firnis
    const warm = g.createRadialGradient(40, 380, 10, 40, 380, 330);
    warm.addColorStop(0, `rgba(255,160,60,${0.16 + (p.light || 0) * 0.12})`);
    warm.addColorStop(1, "rgba(255,160,60,0)");
    g.fillStyle = warm;
    g.fillRect(0, 0, 300, 400);
    const shade = g.createRadialGradient(150, 180, 90, 150, 200, 260);
    shade.addColorStop(0, "rgba(0,0,0,0)");
    shade.addColorStop(1, "rgba(0,0,0,.6)");
    g.fillStyle = shade;
    g.fillRect(0, 0, 300, 400);
    g.fillStyle = "rgba(130,90,20,.10)";
    g.fillRect(0, 0, 300, 400);
  }

  function drawEye(g, x, y, w, h, p, blink, c, k, child) {
    const open = clamp(1 - blink);
    // Augenhöhle
    const sock = g.createRadialGradient(x, y - 1, 2, x, y - 1, w * 1.7);
    sock.addColorStop(0, `rgba(${Math.round(lerp(80, 5, k))},${Math.round(lerp(40, 10, k))},20,${0.35 + 0.55 * k})`);
    sock.addColorStop(1, "rgba(40,20,10,0)");
    g.fillStyle = sock;
    g.fillRect(x - w * 2, y - w * 2, w * 4, w * 4);
    if (open < 0.08) {
      g.strokeStyle = mix(c.skinDark, "#000000", 0.4);
      g.lineWidth = 1.8;
      g.beginPath();
      g.moveTo(x - w, y);
      g.quadraticCurveTo(x, y + h * 0.8, x + w, y);
      g.stroke();
      return;
    }
    g.save();
    g.beginPath();
    g.moveTo(x - w, y);
    g.quadraticCurveTo(x, y - h * 2 * open, x + w, y);
    g.quadraticCurveTo(x, y + h * 1.4 * open, x - w, y);
    g.closePath();
    g.fillStyle = mix("#efe6d6", "#080303", k);
    g.fill();
    g.clip();
    const ix = x + (p.lookX || 0) * w * 0.48;
    const iy = y + (p.lookY || 0) * h * 0.35 - 1;
    const ir = (child ? 7.4 : 5.8) * lerp(1, 0.62, k);
    if (k > 0.3) {
      g.shadowColor = "#ff2000";
      g.shadowBlur = 14 * k;
      g.fillStyle = mix("#c01808", "#ff4a12", (p.glow || 0.6));
      g.beginPath();
      g.arc(ix, iy, ir, 0, Math.PI * 2);
      g.fill();
      g.shadowBlur = 0;
      g.fillStyle = "#ffe0a0";
      g.beginPath();
      g.arc(ix, iy, ir * 0.35, 0, Math.PI * 2);
      g.fill();
    } else {
      const iris = g.createRadialGradient(ix, iy, 1, ix, iy, ir);
      iris.addColorStop(0, mix(c.iris, "#000000", 0.3));
      iris.addColorStop(0.7, c.iris);
      iris.addColorStop(1, "#1b1b16");
      g.fillStyle = iris;
      g.beginPath();
      g.arc(ix, iy, ir, 0, Math.PI * 2);
      g.fill();
      g.fillStyle = "#050505";
      g.beginPath();
      g.arc(ix, iy, ir * 0.45 * (p.pupil || 1), 0, Math.PI * 2);
      g.fill();
      g.fillStyle = "rgba(255,255,255,.85)";
      g.beginPath();
      g.arc(ix - ir * 0.35, iy - ir * 0.4, ir * 0.18, 0, Math.PI * 2);
      g.fill();
    }
    g.restore();
    // Oberlid
    g.strokeStyle = mix("#3a2014", "#000000", k);
    g.lineWidth = 1.8;
    g.beginPath();
    g.moveTo(x - w, y);
    g.quadraticCurveTo(x, y - h * 2 * open, x + w, y);
    g.stroke();
  }

  function drawMouth(g, p, k, c, drop, v) {
    const m = p.mouth || 0;
    const cy = 216 + (v === "child" ? -4 : 0);
    const lip = mix("#8c3b34", "#2a1416", k);
    if (m < 0.03) {
      g.strokeStyle = lip;
      g.lineWidth = 2.6;
      g.lineCap = "round";
      const s = p.smile || 0;
      g.beginPath();
      g.moveTo(134 - s * 4, cy - s * 5);
      g.quadraticCurveTo(150, cy + 4 + s * 7, 166 + s * 4, cy - s * 5);
      g.stroke();
      return;
    }
    if (k < 0.2 && (p.smile || 0) > 0.4) {
      // Lachen: D-förmig, oben Zähne
      const w = 20 + m * 6;
      const h = 8 + m * 14;
      g.fillStyle = "#3a0c0c";
      g.beginPath();
      g.moveTo(150 - w, cy - 4);
      g.quadraticCurveTo(150, cy, 150 + w, cy - 4);
      g.quadraticCurveTo(150, cy + h * 1.6, 150 - w, cy - 4);
      g.fill();
      g.fillStyle = "#f4efe4";
      g.beginPath();
      g.moveTo(150 - w * 0.8, cy - 3);
      g.quadraticCurveTo(150, cy + 1, 150 + w * 0.8, cy - 3);
      g.lineTo(150 + w * 0.7, cy + 3);
      g.quadraticCurveTo(150, cy + 6, 150 - w * 0.7, cy + 3);
      g.fill();
      g.fillStyle = "#c2454a";
      g.beginPath();
      g.ellipse(150, cy + h * 0.95, w * 0.5, h * 0.25, 0, 0, Math.PI * 2);
      g.fill();
      return;
    }
    // Schrei: weit offen, nach unten gezogen, spitze Zähne
    const rx = 13 + m * (10 + 6 * k);
    const ry = 3 + m * (16 + 22 * k);
    const my = cy + ry * 0.55 + drop * 0.25;
    const inner = g.createRadialGradient(150, my, 2, 150, my, ry * 1.1);
    inner.addColorStop(0, "#000");
    inner.addColorStop(0.8, "#1a0303");
    inner.addColorStop(1, "#3a0808");
    g.fillStyle = inner;
    g.beginPath();
    g.ellipse(150, my, rx, ry, 0, 0, Math.PI * 2);
    g.fill();
    g.strokeStyle = lip;
    g.lineWidth = 2.4;
    g.stroke();
    g.save();
    g.beginPath();
    g.ellipse(150, my, rx, ry, 0, 0, Math.PI * 2);
    g.clip();
    g.fillStyle = mix("#efe9da", "#cfc6a2", k);
    const teeth = 7;
    for (let i = 0; i < teeth; i += 1) {
      const x0 = 150 - rx + (i / teeth) * rx * 2;
      const tw = (rx * 2) / teeth;
      const tl = 4 + 8 * k;
      g.beginPath();
      g.moveTo(x0, my - ry);
      g.lineTo(x0 + tw / 2, my - ry + tl + 3 + (i % 2) * 3 * k);
      g.lineTo(x0 + tw, my - ry);
      g.fill();
      g.beginPath();
      g.moveTo(x0, my + ry);
      g.lineTo(x0 + tw / 2, my + ry - tl - (i % 2) * 2 * k);
      g.lineTo(x0 + tw, my + ry);
      g.fill();
    }
    g.restore();
  }

  function portraitParamsIdle(t) {
    // Ruhig, die Augen wandern ab und zu, gelegentliches Blinzeln.
    const phase = t / 7;
    const look = Math.sin(phase * Math.PI * 2) * 0.55 + Math.sin(phase * 5.3) * 0.15;
    const blinkT = (t % 6.3);
    const blink = blinkT < 0.16 ? Math.sin(blinkT / 0.16 * Math.PI) : 0;
    return { lookX: look, lookY: 0.1 * Math.sin(t * 0.7), ghoul: 0, mouth: 0, smile: 0.05, blinkL: blink, blinkR: blink,
      brow: 0, pupil: 1, tilt: 0, light: flick(t, 6) };
  }

  /** Das Porträt mit Kamera: zoom auf das Gesicht, shake in Pixeln. */
  function renderPortrait(variant, p, zoom = 1, shake = 0) {
    if (!room) room = makeRoom();
    const r = room.rect;
    ctx.save();
    const fx = r.x + r.w * 0.5;
    const fy = r.y + r.h * (172 / 400);
    if (zoom !== 1 || shake) {
      const k = (zoom - 1) / Math.max(0.001, zoom);
      ctx.translate(W / 2 + (Math.random() - 0.5) * shake, H / 2 + (Math.random() - 0.5) * shake);
      ctx.scale(zoom, zoom);
      ctx.translate(-lerp(W / 2, fx, Math.min(1, k * 1.6)), -lerp(H / 2, fy, Math.min(1, k * 1.6)));
    }
    ctx.drawImage(room.canvas, 0, 0);
    ctx.save();
    ctx.beginPath();
    ctx.rect(r.x, r.y, r.w, r.h);
    ctx.clip();
    ctx.translate(r.x, r.y);
    ctx.scale(r.w / 300, r.h / 400);
    drawPortrait(ctx, variant, p);
    ctx.restore();
    ctx.drawImage(room.tex, r.x, r.y);
    ctx.restore();
    // flackerndes Kerzenlicht im Raum
    const light = 0.12 + 0.1 * flick(performance.now() / 1000, 9, 2);
    const glow = ctx.createRadialGradient(W * 0.12, H, 10, W * 0.12, H, Math.max(W, H) * 0.7);
    glow.addColorStop(0, `rgba(255,150,60,${light})`);
    glow.addColorStop(1, "rgba(255,150,60,0)");
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, W, H);
    vignette(0.55);
  }

  // ------------------------------------------------------------ Figuren

  /** Die blasse Frau mit den langen Haaren, aufrecht, unten verblassend. */
  function drawGhostFigure(x, yBase, h, alpha, blur = 2, dark = false) {
    if (alpha <= 0.01) return;
    const s = h / 100;
    ctx.save();
    ctx.globalAlpha = clamp(alpha);
    if (blur > 0) ctx.filter = `blur(${Math.max(0.5, blur * s / 3)}px)`;
    ctx.translate(x, yBase - h);
    ctx.scale(s, s);
    const body = ctx.createLinearGradient(0, 10, 0, 100);
    if (dark) {
      body.addColorStop(0, "rgba(5,5,6,1)");
      body.addColorStop(0.85, "rgba(5,5,6,.95)");
      body.addColorStop(1, "rgba(5,5,6,0)");
    } else {
      body.addColorStop(0, "rgba(225,234,238,1)");
      body.addColorStop(0.7, "rgba(200,212,220,.85)");
      body.addColorStop(1, "rgba(200,212,220,0)");
    }
    ctx.fillStyle = body;
    ctx.beginPath();
    ctx.moveTo(-6, 16);
    ctx.bezierCurveTo(-16, 18, -15, 30, -16, 46);
    ctx.bezierCurveTo(-18, 70, -20, 88, -24, 100);
    ctx.lineTo(24, 100);
    ctx.bezierCurveTo(20, 88, 18, 70, 16, 46);
    ctx.bezierCurveTo(15, 30, 16, 18, 6, 16);
    ctx.closePath();
    ctx.fill();
    // Arme hängen herab
    ctx.strokeStyle = dark ? "rgba(5,5,6,1)" : "rgba(215,225,230,.9)";
    ctx.lineWidth = 3.4;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(-14, 22);
    ctx.quadraticCurveTo(-21, 40, -19, 58);
    ctx.moveTo(14, 22);
    ctx.quadraticCurveTo(21, 40, 19, 58);
    ctx.stroke();
    // Kopf, fast ganz unter den Haaren
    ctx.fillStyle = dark ? "#060606" : "rgba(232,238,240,1)";
    ctx.beginPath();
    ctx.ellipse(0, 8, 6.5, 8, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = dark ? "#000" : "rgba(10,10,12,.95)";
    ctx.lineWidth = 1.3;
    for (let i = -6; i <= 6; i += 1) {
      ctx.beginPath();
      ctx.moveTo(i * 0.9, 0);
      ctx.bezierCurveTo(i * 1.3, 10, i * 1.6 + Math.sin(i) * 1.5, 22, i * 1.9, 36 + Math.abs(i) * 1.2);
      ctx.stroke();
    }
    ctx.restore();
  }

  /** Das Gesicht, das auf einen zuspringt. open: Mund 0..1. */
  function drawLungeFace(cx, cy, size, open, t, glitch = 0) {
    const s = size / 100;
    const draw = (g) => {
      g.save();
      g.translate(cx, cy);
      g.scale(s, s);
      // Haare hinten
      g.fillStyle = "#050505";
      g.beginPath();
      g.ellipse(0, -6, 52, 60, 0, 0, Math.PI * 2);
      g.fill();
      const face = g.createRadialGradient(-8, -14, 4, 0, 0, 52);
      face.addColorStop(0, "#e6ebe8");
      face.addColorStop(0.6, "#aeb8b3");
      face.addColorStop(1, "#56605b");
      g.fillStyle = face;
      g.beginPath();
      g.ellipse(0, 0, 36, 48 + open * 8, 0, 0, Math.PI * 2);
      g.fill();
      // Augenhöhlen
      for (const x of [-14, 14]) {
        const e = g.createRadialGradient(x, -8, 1, x, -8, 13);
        e.addColorStop(0, "#000");
        e.addColorStop(0.65, "#050505");
        e.addColorStop(1, "rgba(0,0,0,0)");
        g.fillStyle = e;
        g.beginPath();
        g.ellipse(x, -8, 12, 13, 0, 0, Math.PI * 2);
        g.fill();
        g.fillStyle = "#f4f4f0";
        g.beginPath();
        g.arc(x + Math.sin(t * 9 + x) * 0.6, -8, 1.3, 0, Math.PI * 2);
        g.fill();
      }
      // Mund, lang gezogen
      const my = 22 + open * 6;
      const m = g.createRadialGradient(0, my, 1, 0, my, 22);
      m.addColorStop(0, "#000");
      m.addColorStop(0.85, "#070101");
      m.addColorStop(1, "#2a0606");
      g.fillStyle = m;
      g.beginPath();
      g.ellipse(0, my, 8 + open * 6, 4 + open * 20, 0, 0, Math.PI * 2);
      g.fill();
      // Risse
      g.strokeStyle = "rgba(40,45,42,.7)";
      g.lineWidth = 0.7;
      for (const [a, b, c2, d] of [[-24, -30, -18, -20], [20, -34, 26, -18], [-26, 10, -20, 24], [22, 6, 28, 22]]) {
        g.beginPath();
        g.moveTo(a, b);
        g.lineTo((a + c2) / 2 + 3, (b + d) / 2);
        g.lineTo(c2, d);
        g.stroke();
      }
      // Haarsträhnen: dicht an den Seiten, nur wenige über dem Gesicht
      g.strokeStyle = "#030303";
      g.lineCap = "round";
      for (let i = 0; i < 26; i += 1) {
        const side = i % 2 ? 1 : -1;
        const over = i < 4;
        const sx = side * (over ? 8 + i * 3 : 26 + (i * 5.3) % 20);
        g.lineWidth = over ? 1.1 : 2 + (i % 3);
        g.beginPath();
        g.moveTo(sx * 0.5, -56);
        g.bezierCurveTo(sx * 1.05, -30, sx * 1.15 + Math.sin(i + t * 3) * 1.5, 10, sx * 1.3, 62 + (i % 5) * 6);
        g.stroke();
      }
      g.restore();
    };
    if (glitch <= 0) {
      draw(ctx);
      return;
    }
    const tmp = offscreen(W, H);
    const tg = tmp.getContext("2d");
    draw(tg);
    const slices = 18;
    const sh = H / slices;
    for (let i = 0; i < slices; i += 1) {
      const off = (flick(t, 22, i) - 0.5) * W * 0.12 * glitch * (flick(t, 7, i + 40) > 0.6 ? 1 : 0.15);
      ctx.drawImage(tmp, 0, i * sh, W, sh, off, i * sh, W, sh);
    }
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = 0.25 * glitch;
    ctx.drawImage(tmp, W * 0.012 * glitch, 0);
    ctx.restore();
  }

  /** Der freundliche Bettlaken-Geist. */
  function drawSheetGhost(cx, cy, size, t, alpha = 1, wave = 0) {
    const s = size / 100;
    ctx.save();
    ctx.globalAlpha = clamp(alpha);
    ctx.translate(cx, cy);
    ctx.scale(s, s);
    ctx.shadowColor = "rgba(190,220,255,.8)";
    ctx.shadowBlur = 30 * s;
    ctx.fillStyle = "#f5f7fb";
    ctx.beginPath();
    ctx.moveTo(-34, 40);
    ctx.bezierCurveTo(-38, -10, -30, -50, 0, -50);
    ctx.bezierCurveTo(30, -50, 38, -10, 34, 40);
    for (let i = 0; i <= 6; i += 1) {
      const x = 34 - i * (68 / 6);
      const y = 40 + (i % 2 ? 9 : 0) + Math.sin(t * 6 + i) * 3;
      ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
    // winkender Arm
    ctx.shadowBlur = 0;
    ctx.save();
    ctx.translate(30, 0);
    ctx.rotate(-0.6 - Math.sin(t * 9) * 0.45 * wave);
    ctx.beginPath();
    ctx.ellipse(10, 0, 14, 7, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    ctx.fillStyle = "#14161c";
    for (const x of [-12, 12]) {
      ctx.beginPath();
      ctx.ellipse(x, -18, 5.5, 8, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.beginPath();
    ctx.ellipse(0, 2, 6, 8 + Math.sin(t * 5) * 1.5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(255,140,160,.5)";
    for (const x of [-22, 22]) {
      ctx.beginPath();
      ctx.ellipse(x, -4, 5, 3, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  function furPath(g, cx, cy, rx, ry, spikes, jag, seed) {
    g.beginPath();
    for (let i = 0; i <= spikes; i += 1) {
      const a = (i / spikes) * Math.PI * 2;
      const r = 1 + (i % 2 ? -jag : jag * (0.4 + hash(i + seed) * 0.8));
      g.lineTo(cx + Math.cos(a) * rx * r, cy + Math.sin(a) * ry * r);
    }
    g.closePath();
  }

  /** Das Monster: Kopf mit Hörnern, Glutaugen, Maul. s = Kopfhöhe. */
  function drawBeast(cx, cy, s, open, t, eyes = 1) {
    const u = s / 100;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(u, u);
    // Schultern
    const sh = ctx.createLinearGradient(0, 30, 0, 140);
    sh.addColorStop(0, "#1a130e");
    sh.addColorStop(1, "#050302");
    ctx.fillStyle = sh;
    furPath(ctx, 0, 110, 120, 70, 140, 0.035, 3);
    ctx.fill();
    // Hörner
    for (const side of [-1, 1]) {
      const hg = ctx.createLinearGradient(side * 30, -40, side * 75, -95);
      hg.addColorStop(0, "#5b4a2e");
      hg.addColorStop(1, "#e4d6b0");
      ctx.fillStyle = hg;
      ctx.beginPath();
      ctx.moveTo(side * 22, -34);
      ctx.bezierCurveTo(side * 50, -60, side * 52, -92, side * 78, -104);
      ctx.bezierCurveTo(side * 64, -82, side * 60, -54, side * 40, -24);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = "rgba(60,40,20,.5)";
      ctx.lineWidth = 1;
      for (let i = 1; i < 6; i += 1) {
        ctx.beginPath();
        ctx.moveTo(side * (24 + i * 7), -36 - i * 7);
        ctx.lineTo(side * (34 + i * 6), -30 - i * 6);
        ctx.stroke();
      }
    }
    // Kopf mit Fell
    const head = ctx.createRadialGradient(0, 0, 5, 0, 10, 62);
    head.addColorStop(0, "#3b2c20");
    head.addColorStop(0.7, "#1e1610");
    head.addColorStop(1, "#090605");
    ctx.fillStyle = head;
    furPath(ctx, 0, 6, 50, 56 + open * 8, 90, 0.06, 7);
    ctx.fill();
    // Stirnwulst
    ctx.fillStyle = "#120c08";
    ctx.beginPath();
    ctx.moveTo(-40, -14);
    ctx.quadraticCurveTo(0, -4, 40, -14);
    ctx.quadraticCurveTo(0, -24, -40, -14);
    ctx.fill();
    // Augen
    for (const side of [-1, 1]) {
      ctx.save();
      ctx.translate(side * 19, -6);
      ctx.rotate(side * 0.25);
      ctx.shadowColor = "#ffcc22";
      ctx.shadowBlur = 18 * eyes;
      ctx.fillStyle = `rgba(255,${Math.round(205 + 30 * flick(t, 8, side + 3))},60,${eyes})`;
      ctx.beginPath();
      ctx.ellipse(0, 0, 10, 5.5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.fillStyle = "#000";
      ctx.beginPath();
      ctx.ellipse(0, 0, 1.6, 5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    // Nüstern
    ctx.fillStyle = "#050302";
    for (const x of [-6, 6]) {
      ctx.beginPath();
      ctx.ellipse(x, 12, 3, 2, x * 0.05, 0, Math.PI * 2);
      ctx.fill();
    }
    // Maul
    const my = 30 + open * 6;
    const mh = 3 + open * 26;
    const mw = 30 + open * 6;
    const mg = ctx.createRadialGradient(0, my, 2, 0, my, mh + 10);
    mg.addColorStop(0, "#000");
    mg.addColorStop(0.7, "#2a0404");
    mg.addColorStop(1, "#5a0c0c");
    ctx.fillStyle = mg;
    ctx.beginPath();
    ctx.ellipse(0, my, mw, mh, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.save();
    ctx.beginPath();
    ctx.ellipse(0, my, mw, mh, 0, 0, Math.PI * 2);
    ctx.clip();
    if (open > 0.3) {
      ctx.fillStyle = "#8a1e2a";
      ctx.beginPath();
      ctx.ellipse(0, my + mh * 0.75, mw * 0.55, mh * 0.35, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = "#ece2c4";
    const n = 11;
    for (let i = 0; i < n; i += 1) {
      const x0 = -mw + (i / n) * mw * 2;
      const tw = (mw * 2) / n;
      const long = i === 2 || i === n - 3 ? 1.8 : 1;
      ctx.beginPath();
      ctx.moveTo(x0, my - mh - 2);
      ctx.lineTo(x0 + tw / 2, my - mh + (6 + 6 * open) * long);
      ctx.lineTo(x0 + tw, my - mh - 2);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(x0, my + mh + 2);
      ctx.lineTo(x0 + tw / 2, my + mh - (5 + 5 * open) * long);
      ctx.lineTo(x0 + tw, my + mh + 2);
      ctx.fill();
    }
    // Geifer
    if (open > 0.4) {
      ctx.strokeStyle = "rgba(220,230,220,.45)";
      ctx.lineWidth = 0.9;
      for (const x of [-18, -4, 12, 22]) {
        ctx.beginPath();
        ctx.moveTo(x, my - mh + 6);
        ctx.quadraticCurveTo(x + 2, my, x + 1, my + mh * (0.5 + 0.4 * hash(x)));
        ctx.stroke();
      }
    }
    ctx.restore();
    ctx.restore();
  }

  /** Eine Klaue, die sich an die Kante klammert. edgeY = Bildschirmkante. */
  function drawClaw(x, edgeY, s, side, rise) {
    const u = s / 100;
    ctx.save();
    ctx.translate(x, edgeY - s * 0.06 + (1 - rise) * s * 0.95);
    ctx.scale(u * side, u);
    ctx.fillStyle = "#140e0a";
    furPath(ctx, 0, 40, 34, 44, 50, 0.07, 11);
    ctx.fill();
    for (let i = 0; i < 4; i += 1) {
      const fx = -22 + i * 15;
      ctx.strokeStyle = "#1a120c";
      ctx.lineWidth = 11;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(fx * 0.7, 20);
      ctx.quadraticCurveTo(fx, -22 - (i === 1 || i === 2 ? 8 : 0), fx + 8, -14);
      ctx.stroke();
      ctx.fillStyle = "#e3d8bd";
      ctx.beginPath();
      ctx.moveTo(fx + 4, -18);
      ctx.quadraticCurveTo(fx + 18, -16, fx + 20, 2);
      ctx.quadraticCurveTo(fx + 14, -6, fx + 8, -9);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  }

  /** Das niedliche Monster mit dem großen Auge. */
  function drawCuteMonster(cx, cy, s, t, look = 0, wave = 0) {
    const u = s / 100;
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(u, u);
    for (const side of [-1, 1]) {
      ctx.fillStyle = "#f2e2b5";
      ctx.beginPath();
      ctx.moveTo(side * 18, -42);
      ctx.quadraticCurveTo(side * 30, -64, side * 34, -66);
      ctx.quadraticCurveTo(side * 30, -48, side * 30, -36);
      ctx.closePath();
      ctx.fill();
    }
    const body = ctx.createRadialGradient(-12, -18, 8, 0, 0, 62);
    body.addColorStop(0, "#a77bf0");
    body.addColorStop(1, "#5a2fae");
    ctx.fillStyle = body;
    furPath(ctx, 0, 0, 48, 50, 70, 0.04, 5);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,.12)";
    ctx.beginPath();
    ctx.ellipse(0, 26, 28, 18, 0, 0, Math.PI * 2);
    ctx.fill();
    // Arm
    ctx.strokeStyle = "#6a3cc2";
    ctx.lineWidth = 11;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(40, 10);
    const a = -0.9 - Math.sin(t * 8) * 0.5 * wave;
    ctx.lineTo(40 + Math.cos(a) * 30, 10 + Math.sin(a) * 30);
    ctx.stroke();
    // Auge
    ctx.fillStyle = "#fff";
    ctx.beginPath();
    ctx.ellipse(0, -10, 21, 22, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#2c8de0";
    ctx.beginPath();
    ctx.arc(look * 8, -8, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#081018";
    ctx.beginPath();
    ctx.arc(look * 9, -8, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.beginPath();
    ctx.arc(look * 9 - 3, -11, 2, 0, Math.PI * 2);
    ctx.fill();
    const blinkT = t % 3.4;
    if (blinkT < 0.14) {
      ctx.fillStyle = "#7d52d6";
      ctx.beginPath();
      ctx.ellipse(0, -10, 22, 23 * Math.sin(blinkT / 0.14 * Math.PI), 0, 0, Math.PI * 2);
      ctx.fill();
    }
    // Mund
    ctx.fillStyle = "#2a0c3a";
    ctx.beginPath();
    ctx.moveTo(-18, 18);
    ctx.quadraticCurveTo(0, 22, 18, 18);
    ctx.quadraticCurveTo(0, 40, -18, 18);
    ctx.fill();
    ctx.fillStyle = "#fff";
    for (const x of [-8, 6]) {
      ctx.beginPath();
      ctx.moveTo(x, 19.5);
      ctx.lineTo(x + 2.5, 26);
      ctx.lineTo(x + 5, 19.8);
      ctx.fill();
    }
    ctx.restore();
  }

  // ------------------------------------------------------------ Die vier Schrecks

  /* Jeder Ablauf: duration(show), draw(show, t), cues [[Zeit, Name]].
   * L ist die Zeit bis zum Schreck. */

  const MODES = {
    portrait: {
      duration: (s) => s.lurk + (s.gentle ? 5.5 : 7.5),
      cues: (s) => s.gentle ? [[0, "ambient"], [s.lurk, "giggle"]] : [[0, "ambient"], [s.lurk - 0.12, "scream"]],
      draw(s, t) {
        const L = s.lurk;
        const v = s.variant;
        if (t < L || s.gentle) {
          // Anschleichen: die Augen finden den Betrachter
          const p = portraitParamsIdle(t);
          const find = easeInOut(seg(t, L * 0.35, L * 0.8));
          p.lookX = lerp(-0.85 + 0.15 * Math.sin(t * 1.3), 0, find);
          p.lookY = lerp(0.05, 0.15, find);
          p.blinkL = p.blinkR = t > L * 0.5 ? 0 : p.blinkL;
          p.pupil = lerp(1, 0.7, seg(t, L - 0.8, L));
          p.brow = seg(t, L - 1.2, L - 0.4) * 0.6;
          p.light = flick(t, 6 + 10 * seg(t, L * 0.5, L));
          let zoom = 1 + 0.04 * seg(t, 0, L);
          if (s.gentle && t >= L) {
            const k = t - L;
            p.lookX = 0;
            p.blinkR = k < 0.55 ? Math.sin(seg(k, 0, 0.55) * Math.PI) : 0;   // zwinkern
            p.smile = easeOut(seg(k, 0, 0.3));
            p.mouth = k > 0.3 && k < 2.6 ? 0.4 + 0.35 * Math.abs(Math.sin(k * 9)) : 0;
            p.brow = 0.8;
            p.tilt = Math.sin(k * 7) * 0.025 * (k < 2.6 ? 1 : 0);
            zoom = 1.04;
            renderPortrait(v, p, zoom);
            title(tx("happy"), H * 0.955, Math.min(H * 0.075, W * 0.08), seg(k, 0.6, 1.2) * (1 - seg(k, 4.6, 5.4)));
            return;
          }
          renderPortrait(v, p, zoom);
          vignette(0.35 * seg(t, L * 0.4, L), "40,0,0");
          return;
        }
        const k = t - L;
        if (k < 2.7) {
          const g = easeOut(seg(k, 0, 0.18));
          const p = { lookX: 0, lookY: 0.15, ghoul: g, mouth: g * (0.85 + 0.15 * Math.sin(k * 40)), smile: 0,
            blinkL: 0, blinkR: 0, brow: 0, pupil: 1, tilt: Math.sin(k * 31) * 0.01, glow: 0.5 + 0.5 * Math.sin(k * 25),
            light: 1 };
          const zoom = lerp(1.04, 2.5, easeOut(seg(k, 0, 0.35)));
          const shake = W * 0.03 * (1 - seg(k, 0, 2.2));
          renderPortrait(v, p, zoom, shake);
          flash(0.5 * (1 - seg(k, 0.02, 0.18)) + 0.25 * (flick(k, 14) > 0.85 ? 1 : 0) * (1 - seg(k, 0.5, 2.4)), "#fff");
          flash(0.12 + 0.08 * Math.sin(k * 30), "#8a0000");
          black(seg(k, 2.1, 2.7));
          return;
        }
        if (k < 3.7) {
          black(1);
          return;
        }
        // Wieder ruhig, aber jetzt lächelt es und starrt dich an.
        const p = portraitParamsIdle(t);
        p.lookX = 0;
        p.lookY = 0.15;
        p.blinkL = p.blinkR = 0;
        p.smile = 0.7;
        p.pupil = 0.75;
        renderPortrait(v, p, 1);
        black(1 - seg(k, 3.7, 4.8));
      }
    },

    ghost: {
      duration: (s) => s.lurk + 5,
      cues: (s) => s.gentle ? [[s.lurk + 0.4, "boo"]] :
        [[s.lurk * 0.45, "whisper"], [s.lurk + 0.8, "shriek"]],
      draw(s, t) {
        const L = s.lurk;
        const zoom = 1 + 0.05 * seg(t, 0, L + 3);
        if (s.gentle) {
          background(zoom);
          const k = t - L;
          if (k > 0) {
            const x = lerp(-W * 0.15, W * 1.15, seg(k, 0, 4.2));
            const y = H * 0.62 + Math.sin(k * 3) * H * 0.04;
            drawSheetGhost(x, y, H * 0.32, t, seg(k, 0, 0.3) * (1 - seg(k, 3.8, 4.2)), 1);
            title(tx("boo"), H * 0.2, H * 0.12, seg(k, 0.4, 0.8) * (1 - seg(k, 3, 3.6)), "#f5f7fb");
          }
          return;
        }
        const k = t - L;
        if (k < 0.9) {
          const spot = background(zoom, seg(t, L * 0.4, L) * 0.85);
          vignette(0.3 + 0.4 * seg(t, L * 0.4, L));
          // 1. Erscheinen: weit weg, flackernd
          const a = L * 0.45;
          if (t > a && t < a + 1.5) {
            const on = flick(t, 13, 1) > 0.35 ? 1 : 0.15;
            const fade = seg(t, a, a + 0.3) * (1 - seg(t, a + 1.1, a + 1.5));
            drawGhostFigure(spot.x, spot.y, spot.h, 0.42 * fade * on, 2.2);
          }
          // 2. Erscheinen: mitten im Bild, viel näher
          if (k > 0) {
            const on = flick(t, 16, 2) > 0.25 ? 1 : 0.3;
            drawGhostFigure(W / 2, H * 1.02, H * lerp(0.7, 0.9, seg(k, 0, 0.9)), 0.6 * on * seg(k, 0, 0.12), 1.5);
          }
          return;
        }
        if (k < 2.4) {
          // Sprung ins Gesicht
          const j = k - 0.9;
          background(1.1, 1);
          black(0.55);
          const size = Math.min(W, H) * lerp(0.45, 1.05, easeOut(seg(j, 0, 0.22)));
          const shake = W * 0.025 * (1 - seg(j, 0, 1.4));
          drawLungeFace(W / 2 + (Math.random() - 0.5) * shake, H * 0.52 + (Math.random() - 0.5) * shake,
            size, easeOut(seg(j, 0.05, 0.3)), t, 0.25);
          flash(0.6 * (1 - seg(j, 0, 0.12)));
          black(seg(j, 1.1, 1.5));
          return;
        }
        background(zoom);
        black(1 - seg(k, 2.9, 3.7));
      }
    },

    static: {
      duration: (s) => s.lurk + 4.8,
      cues: (s) => {
        const L = s.lurk;
        const list = [[L * 0.3, "static"], [L * 0.62, "static"], [L, "static"]];
        list.push(s.gentle ? [L + 1.0, "giggle"] : [L + 0.95, "bang"]);
        return list;
      },
      draw(s, t) {
        const L = s.lurk;
        const k = t - L;
        const bursts = [[L * 0.3, 0.55, 0.28], [L * 0.62, 0.6, 0.52], [L, 1.0, 0.92]];
        if (k < 1.0 || (s.gentle && k < 3.4)) {
          let burst = null;
          for (const [at, len, size] of bursts) {
            if (t >= at && t < at + len) burst = { at, len, size };
          }
          if (s.gentle && k >= 0) burst = { at: L, len: 3.4, size: 0.6 };
          if (!burst) {
            background(1 + 0.03 * seg(t, 0, L));
            // kleine Störungen zwischendurch
            if (t > L * 0.25 && flick(t, 9, 5) > 0.93) drawNoise(0.25, t);
            return;
          }
          // Störung: Bild reißt, Rauschen, dunkler Raum, die Gestalt
          background(1.02, 1);
          black(0.55);
          drawNoise(0.16, t);
          if (s.gentle && k >= 0) {
            drawNoise(0.4 * (1 - seg(k, 0, 0.6)), t);
            drawSheetGhost(W / 2, H * 0.5 + Math.sin(k * 3) * H * 0.03, H * 0.42, t, seg(k, 0.1, 0.5), 1);
          } else {
            const jitter = (flick(t, 20, 9) - 0.5) * W * 0.02;
            drawGhostFigure(W / 2 + jitter, H * (0.62 + burst.size * 0.45), H * burst.size, 0.95, 0.8, true);
          }
          drawNoise(0.14 + 0.12 * flick(t, 30, 7), t);
          // rollender Balken
          const barY = ((t * 0.9) % 1) * H;
          ctx.fillStyle = "rgba(255,255,255,.07)";
          ctx.fillRect(0, barY, W, H * 0.12);
          drawScanlines(0.3);
          vignette(0.7);
          if (s.gentle && k >= 0) title(tx("happy"), H * 0.86, H * 0.1, seg(k, 0.6, 1.0));
          return;
        }
        if (s.gentle) {
          background(1);
          drawNoise(0.4 * (1 - seg(k, 3.4, 3.9)), t);
          return;
        }
        if (k < 2.2) {
          const j = k - 1.0;
          black(1);
          drawNoise(0.12, t);
          const size = Math.min(W, H) * lerp(0.6, 1.1, easeOut(seg(j, 0, 0.18)));
          drawLungeFace(W / 2, H * 0.52, size, easeOut(seg(j, 0, 0.2)), t, 0.6 + 0.4 * flick(t, 12, 3));
          drawNoise(0.08 + 0.12 * flick(t, 20), t);
          drawScanlines(0.3);
          flash(0.7 * (1 - seg(j, 0, 0.1)));
          return;
        }
        background(1);
        drawNoise(0.5 * (1 - seg(k, 2.2, 2.9)), t);
        drawScanlines(0.4 * (1 - seg(k, 2.2, 2.9)));
      }
    },

    monster: {
      duration: (s) => s.lurk + 6.5,
      cues: (s) => s.gentle ? [[s.lurk, "giggle"]] : [[s.lurk * 0.35, "growl"], [s.lurk - 0.1, "roar"]],
      draw(s, t) {
        const L = s.lurk;
        const k = t - L;
        const text = s.text || tx("trick");
        if (s.gentle) {
          background(1);
          black(0.25 * seg(t, 0, L));
          const peek = easeOut(seg(t, L * 0.4, L * 0.8));
          const up = easeOut(seg(k, 0, 0.6));
          const size = H * lerp(0.42, 0.62, up);
          const y = lerp(H + size * 0.2, H - size * 0.32, peek) - up * H * 0.22;
          drawCuteMonster(W / 2, y + Math.sin(t * 4) * H * 0.01, size, t, Math.sin(t * 1.4), k > 0 ? 1 : 0);
          title(text, H * 0.16, H * 0.12, seg(k, 0.5, 1.0));
          return;
        }
        background(1 + 0.04 * seg(t, 0, L));
        black(0.35 * seg(t, 0, L) + 0.35 * seg(k, 0, 0.3));
        if (k < 0) {
          // Klauen an der Kante, dann die Augen
          const c = easeOut(seg(t, L * 0.35, L * 0.6));
          const e = easeInOut(seg(t, L * 0.65, L * 0.95));
          const S = Math.min(H, W * 1.2);    // im Hochformat schmaler
          const apart = W > H ? 0.23 : 0.36;
          if (e > 0) drawBeast(W / 2, lerp(H + S * 0.5, H - S * 0.05, e), S * 0.55, 0, t, e);
          drawClaw(W * (0.5 - apart), H, S * 0.42, -1, c);
          drawClaw(W * (0.5 + apart), H, S * 0.42, 1, easeOut(seg(t, L * 0.42, L * 0.67)));
          vignette(0.5);
          return;
        }
        const j = easeOut(seg(k, 0, 0.25));
        const breathe = Math.sin(k * 3) * 0.015;
        const size = Math.min(H, W * 1.2) * lerp(0.6, 0.95, j) * (1 + breathe);
        const shake = W * 0.03 * (1 - seg(k, 0, 1.8));
        const roar = k < 2.4 ? 0.85 + 0.15 * Math.sin(k * 30) : lerp(0.85, 0.25, seg(k, 2.4, 3.2));
        drawBeast(W / 2 + (Math.random() - 0.5) * shake, lerp(H * 1.05, H * 0.5, j) + (Math.random() - 0.5) * shake,
          size, roar, t, 1);
        flash(0.45 * (1 - seg(k, 0, 0.14)));
        vignette(0.6);
        title(text, H * 0.14, H * 0.13, seg(k, 2.2, 2.8));
      }
    }
  };

  // ------------------------------------------------------------ Ablauf

  let data = null;
  let show = null;          // der laufende Schreck
  let idleVariant = params.get("variant") || "lady";
  let readySent = false;

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  function post(path, body) {
    if (DEMO) return;
    const base = pluginBases[baseIndex];
    fetch(`${base}${path}`, { method: "POST", cache: "no-store", credentials: "same-origin",
      headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).catch(() => {});
  }

  function loadImage(url) {
    return new Promise((resolve) => {
      if (!url) { resolve(null); return; }
      const img = new Image();
      if (/^https?:/i.test(url)) img.crossOrigin = "anonymous";   // das Plugin erlaubt es; sonst wäre die Leinwand gesperrt
      const timer = setTimeout(() => resolve(null), 4000);
      img.onload = () => { clearTimeout(timer); resolve(img); };
      img.onerror = () => { clearTimeout(timer); resolve(null); };
      img.src = url;
    });
  }

  async function startShow(event) {
    const mode = MODES[event.mode] ? event.mode : "portrait";
    const s = { id: event.id, mode, variant: VARIANTS[event.variant] ? event.variant : "lady",
      gentle: event.intensity === "gentle", lurk: clamp(Number(event.lurk) || 5, 1.5, 30),
      text: String(event.text || ""), started: null, cuesDone: new Set(), loading: true };
    show = s;
    if (mode !== "portrait") {
      const url = event.photo ? (DEMO ? event.photo : new URL(event.photo, pluginBases[baseIndex]).href) : "";
      const img = await loadImage(url);
      if (show !== s) return;
      photo = img;
      photoCache = null;
    }
    try { await document.fonts.load(`40px Creepster`); } catch (_) { /* egal */ }
    if (show !== s) return;
    s.loading = false;
    s.started = performance.now();
    s.cues = MODES[mode].cues(s).map(([at, name], i) => ({ at, name, key: `${i}:${name}` }));
    s.duration = MODES[mode].duration(s);
    post("api/started", { id: s.id });
  }

  function stopShow() {
    show = null;
  }

  function frame() {
    resize();
    const now = performance.now();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.filter = "none";
    if (show && !show.loading) {
      let t = FREEZE !== null ? FREEZE : (now - show.started) / 1000;
      if (FREEZE === null) {
        for (const cue of show.cues) {
          if (t >= cue.at && !show.cuesDone.has(cue.key)) {
            show.cuesDone.add(cue.key);
            post("api/cue", { id: show.id, cue: cue.name });
          }
        }
      }
      if (t >= show.duration && FREEZE === null && !show.finished) {
        // Fertig: das Plugin gibt den Bildschirm zurück. Bis dahin bleibt das
        // letzte Bild stehen (das Foto oder das ruhige Porträt), damit der
        // Wechsel zurück zur Playlist nahtlos ist.
        post("api/done", { id: show.id });
        show.finished = now;
      }
      if (show.finished && now - show.finished > 20000) {
        idleVariant = show.variant;
        show = null;
      } else {
        ctx.fillStyle = "#000";
        ctx.fillRect(0, 0, W, H);
        MODES[show.mode].draw(show, show.finished ? show.duration - 0.01 : t);
      }
    }
    if (!show) {
      if (data || DEMO === "idle") {
        renderPortrait(idleVariant, portraitParamsIdle(now / 1000));
      } else {
        ctx.fillStyle = "#000";
        ctx.fillRect(0, 0, W, H);
      }
    } else if (show.loading) {
      ctx.fillStyle = "#000";
      ctx.fillRect(0, 0, W, H);
    }
    ready();
    requestAnimationFrame(frame);
  }

  function note(text) {
    const box = document.getElementById("note");
    box.hidden = !text;
    box.textContent = text || "";
  }

  function apply(next) {
    data = next;
    lang = next.lang || lang;
    document.documentElement.lang = lang;
    if (!show && next.idleVariant && VARIANTS[next.idleVariant]) idleVariant = next.idleVariant;
    const ev = next.event;
    if (ev && (!show || show.id !== ev.id)) startShow(ev);
    else if (!ev && show && !show.loading && FREEZE === null) {
      const t = (performance.now() - show.started) / 1000;
      // Abgebrochen (Stopp-Knopf) oder abgelaufen: nicht mitten im Bild hängen bleiben.
      if (t > 1.5 && !show.finished) show.finished = performance.now();
    }
  }

  async function poll() {
    let loginNeeded = false;
    for (let attempt = 0; attempt < pluginBases.length; attempt += 1) {
      const base = pluginBases[(baseIndex + attempt) % pluginBases.length];
      try {
        const response = await fetch(`${base}api/scene`, { cache: "no-store", credentials: "same-origin" });
        if (response.redirected && response.url.includes("/dfr-login/")) { loginNeeded = true; throw new Error("login"); }
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const next = await response.json();
        baseIndex = (baseIndex + attempt) % pluginBases.length;
        note("");
        apply(next);
        return;
      } catch (_) { /* nächster Weg */ }
    }
    if (!data) {
      data = { lang };
      note(tx(loginNeeded ? "login" : "unreachable"));
    }
  }

  resize();
  window.addEventListener("resize", resize);
  if (DEMO && DEMO !== "idle") {
    data = { lang };
    startShow({ id: 1, mode: DEMO, variant: params.get("variant") || "lady",
      intensity: params.get("intensity") || "scary", lurk: Number(params.get("lurk") || 5),
      text: params.get("text") || "", photo: params.get("photo") || "" });
  } else if (DEMO === "idle") {
    data = { lang };
  } else {
    poll();
    setInterval(poll, POLL_MS);
  }
  requestAnimationFrame(frame);
})();
