"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Dem API-Schlüssel fehlt eine Berechtigung ({path}).": (
        "The API key lacks a permission ({path}).",
        "A la clave API le falta un permiso ({path})."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.",
        "El marco no ha creado la lista {name}."),
    "Die Fotos werden neu eingelesen.": ("Reading the photos again.", "Volviendo a leer las fotos."),
    "Die Playlist gibt es nicht mehr.": ("That playlist no longer exists.", "Esa lista ya no existe."),
    "Die Playlist {name} gibt es schon.": ("The playlist {name} already exists.", "La lista {name} ya existe."),
    "Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The scene is not installed on this frame. Install the package again.",
        "La escena no está instalada en este marco. Vuelve a instalar el paquete."),
    "Deine Fotos von heute aus früheren Jahren, mit dem Wetter von damals.": (
        "Your photos of this day in earlier years, with the weather back then.",
        "Tus fotos de este día en años anteriores, con el tiempo de entonces."),
    "Die Ortssuche (Open-Meteo) antwortet nicht: {exc}": (
        "The place search (Open-Meteo) does not answer: {exc}",
        "La búsqueda de lugares (Open-Meteo) no responde: {exc}"),
    "DynaFrame antwortet nicht: {exc}": ("DynaFrame does not answer: {exc}", "DynaFrame no responde: {exc}"),
    "Immich ist nicht erreichbar: {exc}": ("Immich cannot be reached: {exc}", "No se puede acceder a Immich: {exc}"),
    "Immich lehnt den API-Schlüssel ab.": ("Immich refuses the API key.", "Immich rechaza la clave API."),
    "Konnte die Playlist nicht anlegen: {exc}": (
        "Could not create the playlist: {exc}", "No se ha podido crear la lista: {exc}"),
    "Playlist {name} angelegt. Starte sie auf der Startseite des Rahmens oder nimm die Szene in eine andere Playlist auf.": (
        "Playlist {name} created. Start it on the frame's home page, or add the scene to another playlist.",
        "Lista {name} creada. Iníciala en la página principal del marco o añade la escena a otra lista."),
    "Trag die Adresse deines Immich-Servers ein.": (
        "Enter the address of your Immich server.", "Introduce la dirección de tu servidor Immich."),
    "Trag einen API-Schlüssel von Immich ein.": (
        "Enter an API key from Immich.", "Introduce una clave API de Immich."),
    "Unter dieser Adresse antwortet kein Immich-Server.": (
        "No Immich server answers at this address.", "Ningún servidor Immich responde en esta dirección."),
    "Verbunden als {user} (Immich {version}).": (
        "Connected as {user} (Immich {version}).", "Conectado como {user} (Immich {version})."),
    "Wähle ein Album.": ("Pick an album.", "Elige un álbum."),
    "Wähle eine Playlist.": ("Pick a playlist.", "Elige una lista."),
}


def t(lang, template, **values):
    text = template
    if lang in LANGUAGES and lang != "de":
        row = _TEXTS.get(template)
        if row:
            text = row[LANGUAGES.index(lang) - 1]
    try:
        return text.format(**values) if values else text
    except (KeyError, IndexError, ValueError):
        return text
