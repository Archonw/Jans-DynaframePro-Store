# Third-party notes

- School holidays from the OpenHolidays API (https://www.openholidaysapi.org), OpenHolidays project, data under the Open Database License (ODbL).
- Public holidays are calculated with the Python package `holidays` (MIT License), installed from PyPI.
- Calendar files are read with the Python packages `icalendar` (BSD License) and `recurring-ical-events` (LGPL-3.0-or-later), installed from PyPI and used unmodified.
- The scene bundles the fonts Fraunces and Inter under the SIL Open Font License 1.1 (`dynamic/fonts/OFL-*.txt`).
- `sources.py` and `exif_gps.py` are shared with the Travel Scrapbook and Travel Map plugins, `immich_filters.py`, `dynaframe_filters.py`, `own_playlist.py` and `playback_guard.py` with the other plugins of this store (own code).
