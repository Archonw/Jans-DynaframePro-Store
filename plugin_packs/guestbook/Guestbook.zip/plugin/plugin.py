#!/usr/bin/env python3
"""Guestbook - der Plugin-Teil des Pakets "guestbook".

Besucher scannen einen QR-Code (auf dem Fernseher oder als ausgedrucktes
Kärtchen), machen auf ihrem Handy ein Selfie und schreiben einen Gruß. Die
Szene "guestbook" blättert durch das Buch, begrüßt neue Einträge sofort auf
dem Fernseher und erinnert Jahre später daran: „Heute vor 3 Jahren war Tante
Anke zu Besuch.“

Party-Modus: Für eine Feier (Name, ein paar Stunden) wird das Buch zur
Gästewand. Jeder Eintrag erscheint sofort groß und wandert dann in die Wand
aller Gäste des Abends. Beim Beenden zeigt ein Rückblick alle Einträge der
Feier. Die Einträge bleiben im Buch und kommen als Erinnerung wieder.

Dieses Plugin
- liefert die Seite für die Gäste im WLAN (Port 8135, PortKeeper),
- nimmt Selfies an (dreht sie richtig, verkleinert sie, wirft GPS und
  Kameradaten weg),
- sagt der Szene, was sie zeigen soll,
- holt die Szene auf Wunsch über das laufende Programm (Takeover): neue
  Einträge, Erinnerung des Tages, Feier, Rückblick,
- zeigt die Plugin-Seite.
"""

import datetime
import io
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
import threading
import time
import zipfile
from email.parser import BytesParser
from email.policy import HTTP
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import book as booklib  # noqa: E402
import own_playlist  # noqa: E402
import plugin_ports  # noqa: E402
import texts  # noqa: E402

try:
    import playback_guard  # noqa: E402
except Exception:  # noqa: BLE001 - nur ein Behelf, darf fehlen
    playback_guard = None

try:
    from PIL import Image, ImageOps
except ImportError:  # pragma: no cover - kommt mit requirements.txt
    Image = ImageOps = None

HEIF = False
if Image is not None:
    try:
        from pillow_heif import register_heif_opener  # type: ignore

        register_heif_opener()
        HEIF = True
    except Exception:  # noqa: BLE001 - optional
        HEIF = False

plugin = create_plugin()

PLUGIN_ID = "Guestbook"
SCENE_ID = "guestbook"               # id in scene.dynamic - nie ändern
DISPLAY_NAME = "Guestbook"
PLAYLIST_NAMES = {"de": "Guestbook", "en": "Guestbook", "es": "Guestbook"}
TAKEOVER_PLAYLIST_NAME = "Guestbook (takeover)"
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"       # Einstellungen und das Buch; bleibt bei Updates
BOOK_DIR = DATA_DIR / "book"

CONNECT_TIMEOUT = 10
SCENE_GONE = 10                      # so lange ohne Frage der Szene: sie ist nicht zu sehen
FULL_EDGE = 1600
THUMB_EDGE = 400
MAX_UPLOAD = 40 * 1024 * 1024
ENTRIES_PER_HOUR = 30                # je Handy
MIN_FREE = 200 * 1024 * 1024
WELCOME_SECONDS = 75                 # so lange holt ein neuer Eintrag den Fernseher
OWN_EDIT_HOURS = 48                  # so lange darf ein Gast seinen Eintrag ändern oder löschen


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


read_json = booklib.read_json
write_json = booklib.write_json


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

SCHEMA = {
    "Language":        {"kind": "choice", "default": "en", "choices": texts.LANGUAGES},
    "BookTitle":       {"kind": "text", "default": "", "max": 60},
    "Theme":           {"kind": "choice", "default": "paper", "choices": ("paper", "evening", "party")},
    "SlideSeconds":    {"kind": "int", "default": 12, "min": 5, "max": 60},
    "ShowQr":          {"kind": "bool", "default": True},
    "ShowDates":       {"kind": "bool", "default": True},
    "RequirePhoto":    {"kind": "bool", "default": False},
    "Approve":         {"kind": "bool", "default": False},
    "GuestsSeeBook":   {"kind": "bool", "default": True},
    "WelcomeOnTv":     {"kind": "bool", "default": True},
    "Memories":        {"kind": "bool", "default": True},
    "MemoryOnTv":      {"kind": "bool", "default": True},
    "MemoryTime":      {"kind": "clock", "default": "18:00"},
    "MemoryMinutes":   {"kind": "int", "default": 2, "min": 1, "max": 30},
    "PartyHours":      {"kind": "int", "default": 6, "min": 1, "max": 24},
    "PartyOnTv":       {"kind": "bool", "default": True},
    "RecapMinutes":    {"kind": "int", "default": 10, "min": 0, "max": 120},
    "WakeScreen":      {"kind": "bool", "default": True},
    "PlaylistSeconds": {"kind": "int", "default": 600, "min": 60, "max": 86400},
    "MakePlaylist":    {"kind": "bool", "default": False},
}
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()
_settings_cache = {"at": 0.0, "values": None}


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "choice":
        value = str(raw or "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "clock":
        match = re.match(r"^\s*(\d{1,2})[:.](\d{2})\s*$", str(raw or ""))
        if not match or int(match.group(1)) > 23 or int(match.group(2)) > 59:
            return spec["default"]
        return f"{int(match.group(1)):02d}:{match.group(2)}"
    return booklib.clean_text(raw, spec.get("max", 80))


def settings():
    # Die Szene und die Handys fragen oft: kurz zwischenspeichern.
    cached = _settings_cache["values"]
    if cached is not None and now() - _settings_cache["at"] < 1.0:
        return dict(cached)
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    values = {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}
    _settings_cache.update(at=now(), values=values)
    return dict(values)


def save_settings(changes):
    with _settings_lock:
        _settings_cache["values"] = None
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        _settings_cache["values"] = None
    if "Language" in changed:
        # Die Verbindungszeilen sind übersetzt: neu prüfen, damit sie die neue Sprache sprechen.
        threading.Thread(target=check_services, args=(True,), name=f"{PLUGIN_ID}-services",
                         daemon=True).start()
    return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


def book_title(values=None):
    values = values or settings()
    return values["BookTitle"] or texts.t(values["Language"], "Unser Gästebuch")


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=60):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


# --------------------------------------------------------------------------
# Das Buch
# --------------------------------------------------------------------------

book = None
_scene = {"seen": 0.0}


def scene_visible(t=None):
    return (t or now()) - _scene["seen"] < SCENE_GONE


def entry_public(row, admin=False, me_hash=""):
    if not row:
        return None
    event = book.event(row.get("ev")) if row.get("ev") else None
    out = {"id": row["id"], "name": row.get("name") or "", "text": row.get("text") or "", "at": row["at"],
           "day": row["day"], "photo": bool(row.get("photo")), "w": row.get("w", 0), "h": row.get("h", 0),
           "color": row.get("color") or "#c2410c", "visit": book.visit_number(row),
           "first": book.first_visit(row), "event": (event or {}).get("title") or "",
           "people": booklib.people(row.get("name"))}
    if admin:
        out["st"] = row.get("st")
        out["ev"] = row.get("ev") or ""
        out["shown"] = book.shown.get(row["id"], 0)
    if me_hash:
        out["mine"] = row.get("dev") == me_hash
        out["editable"] = out["mine"] and now() - row["at"] < OWN_EDIT_HOURS * 3600
    return out


def memory_public(memory, limit=12):
    rows = [entry_public(e) for e in memory["entries"]]
    with_photo = [r for r in rows if r["photo"]]
    rows = (with_photo + [r for r in rows if not r["photo"]])[:limit]
    out = {k: v for k, v in memory.items() if k != "entries"}
    out["entries"] = rows
    return out


# ---- Selfies annehmen -----------------------------------------------------

class EntryError(Exception):
    pass


IMAGE_BRANDS = (b"heic", b"heix", b"hevc", b"heim", b"heis", b"mif1", b"msf1", b"avif", b"avis")


def sniff(data):
    head = data[:16]
    if head.startswith(b"\xff\xd8\xff"):
        return "jpeg"
    if head.startswith(b"\x89PNG"):
        return "png"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if head[4:8] == b"ftyp":
        return "heic" if head[8:12] in IMAGE_BRANDS else "video"
    return ""


def prepare(data):
    """Drehen wie aufgenommen, verkleinern, als JPEG ohne Metadaten. (full, thumb, w, h)"""
    kind = sniff(data)
    if kind == "video":
        raise EntryError(tr("Videos gehen hier nicht, nur Fotos."))
    if not kind:
        raise EntryError(tr("Das ist kein Foto, das der Rahmen lesen kann."))
    if Image is None:
        raise EntryError(tr("Auf dem Rahmen fehlt Pillow; installiere das Paket noch einmal."))
    if kind == "heic" and not HEIF:
        raise EntryError(tr("HEIC-Fotos kann der Rahmen nicht lesen. Stell am iPhone unter Kamera › Formate "
                            "„Maximale Kompatibilität“ ein."))
    try:
        image = Image.open(io.BytesIO(data))
        image.draft("RGB", (FULL_EDGE * 2, FULL_EDGE * 2))
        image = ImageOps.exif_transpose(image)
        if image.mode not in ("RGB", "L"):
            background = Image.new("RGB", image.size, (255, 255, 255))
            rgba = image.convert("RGBA")
            background.paste(rgba, mask=rgba.split()[3])
            image = background
        image = image.convert("RGB")
        image.thumbnail((FULL_EDGE, FULL_EDGE), Image.LANCZOS)
        width, height = image.size
        full = io.BytesIO()
        image.save(full, "JPEG", quality=87, optimize=True)      # ohne EXIF: kein GPS, kein Gerät
        small = image.copy()
        small.thumbnail((THUMB_EDGE, THUMB_EDGE), Image.LANCZOS)
        thumb = io.BytesIO()
        small.save(thumb, "JPEG", quality=80)
        return full.getvalue(), thumb.getvalue(), width, height
    except EntryError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise EntryError(tr("Konnte das Foto nicht lesen: {exc}", exc=exc)) from exc


_recent = {}                              # Handy -> Zeiten der letzten Einträge
_prepare_lock = threading.Semaphore(2)    # der Pi soll nicht zehn Fotos gleichzeitig rechnen


def add_entry(device, name, text, photo_bytes):
    values = settings()
    name = booklib.clean_text(name, 60)
    text = booklib.clean_text(text, 400, lines=True)
    if not name:
        raise EntryError(tr("Bitte schreib deinen Namen dazu."))
    if values["RequirePhoto"] and not photo_bytes:
        raise EntryError(tr("Bitte mach ein Selfie für das Gästebuch."))
    if not photo_bytes and not text:
        raise EntryError(tr("Schreib einen Gruß oder mach ein Selfie."))
    digest = booklib.device_hash(device) or "anon"
    t = now()
    recent = [x for x in _recent.get(digest, []) if t - x < 3600]
    if len(recent) >= ENTRIES_PER_HOUR:
        raise EntryError(tr("Das sind genug Einträge von diesem Handy für den Moment."))
    if booklib.free_bytes(DATA_DIR) < MIN_FREE:
        raise EntryError(tr("Auf dem Rahmen ist kein Platz mehr frei."))
    full = thumb = None
    width = height = 0
    if photo_bytes:
        with _prepare_lock:
            full, thumb, width, height = prepare(photo_bytes)
    try:
        row = book.add(name, text, device, bool(full), width, height, approved=not values["Approve"])
    except ValueError as exc:
        raise EntryError(tr("Das Gästebuch ist voll.")) from exc
    if full:
        (book.photo_dir() / f"{row['id']}.jpg").write_bytes(full)
        (book.photo_dir() / f"{row['id']}.t.jpg").write_bytes(thumb)
    recent.append(t)
    _recent[digest] = recent
    event = book.current_event()
    log(f"Neuer Eintrag von {row['name']}" + (f" (Feier „{event['title']}“)" if event else "")
        + (" mit Selfie" if full else "") + (", wartet auf Freigabe" if row["st"] == "wait" else "") + ".")
    if row["st"] == "ok":
        welcome(row)
    return row


def photo_file(ident, size):
    if not re.match(r"^[0-9A-Za-z-]{6,40}$", ident or ""):
        return None
    path = book.photo_dir() / (f"{ident}.t.jpg" if size == "t" else f"{ident}.jpg")
    try:
        return path.read_bytes()
    except OSError:
        return None


# --------------------------------------------------------------------------
# Was die Szene zeigt
# --------------------------------------------------------------------------

_recap = {"event": "", "until": 0.0, "id": 0}
_focus = {"kind": "", "id": "", "at": 0.0}


def mode(t=None):
    t = t or now()
    if _recap["event"] and (t < _recap["until"] or _recap["until"] == 0):
        return "recap"
    if book.current_event():
        return "party"
    return "book"


def compact(row):
    return {"id": row["id"], "name": row.get("name") or "", "photo": bool(row.get("photo")),
            "w": row.get("w", 0), "h": row.get("h", 0), "color": row.get("color"), "at": row["at"]}


def scene_state(since):
    t = now()
    values = settings()
    current = mode(t)
    out = {
        "success": True,
        "lang": values["Language"],
        "mode": current,
        "title": book_title(values),
        "theme": values["Theme"],
        "slide": values["SlideSeconds"],
        "showQr": values["ShowQr"],
        "showDates": values["ShowDates"],
        "url": phone_url(),
        "code": book.code,
        "seq": book.seq,
        "stats": book.stats(),
        "takeover": _takeover["handle"] is not None,
        "focus": dict(_focus) if _focus["kind"] and wanted_reason(t) in ("welcome", "memory") else None,
        "today": datetime.date.today().isoformat(),
    }
    if out["focus"] and out["focus"]["kind"] == "welcome":
        out["focusEntry"] = entry_public(book.find(out["focus"]["id"]))
    if since >= 0:
        out["fresh"] = [entry_public(e) for e in sorted(book.fresh(since), key=lambda e: e["seq"])][-6:]
    if values["Memories"] and current == "book":
        out["memories"] = [memory_public(m) for m in book.memories()]
    if current == "party":
        event = book.current_event()
        rows = sorted(book.visible(event["id"]), key=lambda e: e["at"])
        out["event"] = {"id": event["id"], "title": event["title"], "started": event["started"],
                        "count": len(rows), "people": sum(booklib.people(r.get("name")) for r in rows)}
        out["wall"] = [compact(r) for r in rows[-120:]]
    if current == "recap":
        event = book.event(_recap["event"]) or {}
        rows = sorted(book.visible(_recap["event"]), key=lambda e: e["at"])
        out["recap"] = {"id": _recap["id"], "event": event.get("id") or "", "title": event.get("title") or "",
                        "started": event.get("started") or 0, "ended": event.get("ended") or 0,
                        "count": len(rows), "people": sum(booklib.people(r.get("name")) for r in rows),
                        "entries": [entry_public(r) for r in rows[:240]]}
    return out


def next_entry(query):
    exclude = set(((query.get("ex") or [""])[0]).split(","))
    event = None
    if mode() == "party":
        event = (book.current_event() or {}).get("id")
    row = book.pick(exclude, event)
    return {"success": True, "entry": entry_public(row)}


# --------------------------------------------------------------------------
# Handy: eintragen, ansehen, ändern
# --------------------------------------------------------------------------

def code_ok(code):
    return str(code or "").strip() == book.code


def phone_info(query):
    values = settings()
    code = (query.get("c") or [""])[0]
    device = (query.get("dev") or [""])[0]
    event = book.current_event()
    out = {"success": True, "lang": values["Language"], "title": values["BookTitle"], "codeOk": code_ok(code),
           "requirePhoto": values["RequirePhoto"], "approve": values["Approve"], "seeBook": values["GuestsSeeBook"],
           "event": {"title": event["title"]} if event else None, "tv": scene_visible(),
           "takeover": values["WelcomeOnTv"] and takeover_allowed_cached()}
    if out["codeOk"]:
        digest = booklib.device_hash(device)
        mine = [e for e in book.entries if digest and e.get("dev") == digest]
        out["mine"] = [entry_public(e, me_hash=digest) | {"st": e.get("st")} for e in mine[-10:]]
    return out


def phone_book(query):
    values = settings()
    if not code_ok((query.get("c") or [""])[0]):
        return {"success": False, "error": "code"}
    digest = booklib.device_hash((query.get("dev") or [""])[0])
    event = book.current_event()
    if values["GuestsSeeBook"]:
        rows = book.visible(event["id"]) if event else book.visible()
    else:
        rows = []
    rows = sorted(rows, key=lambda e: -e["at"])[:80]
    return {"success": True, "entries": [entry_public(e, me_hash=digest) for e in rows],
            "event": event["title"] if event else ""}


def phone_edit(body):
    if not code_ok(body.get("c")):
        return {"success": False, "error": "code"}
    row = book.mine(str(body.get("id") or ""), body.get("dev"))
    if not row or now() - row["at"] > OWN_EDIT_HOURS * 3600:
        return {"success": False, "error": tr("Diesen Eintrag kannst du nicht mehr ändern.")}
    if body.get("delete"):
        book.delete(row["id"])
        log(f"{row['name']} hat den eigenen Eintrag gelöscht.")
        return {"success": True, "deleted": True}
    name = booklib.clean_text(body.get("name"), 60)
    if not name:
        return {"success": False, "error": tr("Bitte schreib deinen Namen dazu.")}
    book.update(row["id"], name=name, text=body.get("text"))
    return {"success": True, "entry": entry_public(book.find(row["id"]), me_hash=row["dev"])}


def multipart_fields(content_type, body):
    message = BytesParser(policy=HTTP).parsebytes(
        b"Content-Type: " + content_type.encode("latin-1") + b"\r\n\r\n" + body)
    fields, photo = {}, b""
    for part in message.iter_parts() if message.is_multipart() else []:
        name = part.get_param("name", header="content-disposition") or ""
        payload = part.get_payload(decode=True) or b""
        if name == "photo" or part.get_filename() is not None:
            if payload:
                photo = payload
        else:
            fields[name] = payload.decode("utf-8", "replace")
    return fields, photo


def lan_address():
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("10.255.255.255", 1))     # schickt nichts, sucht nur die Route
        return probe.getsockname()[0]
    except OSError:
        return ""
    finally:
        probe.close()


_lan = {"at": 0.0, "ip": ""}


def phone_url():
    if now() - _lan["at"] > 60:
        _lan.update(at=now(), ip=lan_address())
    port = PORTS.port
    if not port:
        return ""
    host = _lan["ip"] or socket.gethostname()
    return f"http://{host}:{port}/"


# --------------------------------------------------------------------------
# Takeover: das Buch über das laufende Programm legen
# --------------------------------------------------------------------------
# Gründe (wichtigster zuerst): Rückblick, Feier, neuer Eintrag, von Hand,
# Erinnerung des Tages. Solange einer gilt, hält das Plugin den Bildschirm.

REASONS = ("recap", "party", "welcome", "manual", "memory")
TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
TAKEOVER_DESCRIPTION = ("Wird vom Plugin Guestbook abgespielt: neue Einträge, die Erinnerung des Tages, eine "
                        "Feier im Party-Modus. Bleibt ausgeschaltet, damit es nicht im Quick Mix landet. "
                        "Das Plugin legt sie neu an, wenn sie gelöscht wird.")
TAKEOVER_ITEM_SECONDS = 24 * 3600
STATE_FILE = DATA_DIR / "state.json"

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "since": 0.0, "limit": 0, "reason": "", "note": "", "retryAt": 0.0,
             "busy": False, "playlistId": None, "playlistAt": 0.0}
_want = {reason: 0.0 for reason in REASONS}
_stop_requested = threading.Event()


def load_state():
    stored = read_json(STATE_FILE, {})
    return stored if isinstance(stored, dict) else {}


def save_state(**fields):
    stored = load_state()
    stored.update(fields)
    write_json(STATE_FILE, stored)


def want(reason, seconds):
    with _takeover_lock:
        _want[reason] = max(_want[reason], now() + seconds) if seconds > 0 else 0.0
        _takeover["retryAt"] = 0.0
    if reason == "party":
        save_state(partyUntil=_want["party"])


def wanted_reason(t=None):
    t = t or now()
    for reason in REASONS:
        if _want[reason] > t:
            return reason
    return ""


def welcome(row):
    """Ein neuer Eintrag: kurz auf den Fernseher, damit der Gast sich gleich sieht."""
    values = settings()
    with _takeover_lock:
        _focus.update(kind="welcome", id=row["id"], at=now())
    if values["WelcomeOnTv"] and mode() == "book":
        want("welcome", WELCOME_SECONDS)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


def ensure_takeover_playlist(scene_db_id):
    """Ein Takeover spielt eine Playlist: die Szene allein, lange, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = None
    if playlist_id:
        try:
            playlist = engine_call("GET", f"/playlists/{playlist_id}")
        except EngineError as exc:
            if exc.status != 404:
                raise
    if not playlist:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist and playlist_id:
        items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
        items = items.get("items") if isinstance(items, dict) else items
        items = [i for i in items or [] if isinstance(i, dict)]
        if len(items) == 1 and str(items[0].get("dynamicSceneId")) == str(scene_db_id):
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=TAKEOVER_PLAYLIST_NAME))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": scene_db_id, "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


_permission = {"at": 0.0, "ok": True, "note": ""}


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover", read_timeout=8) or {}
    except EngineError:
        return ""
    enabled = config.get("enabledPluginNames")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Guestbook auf der Plugins-Seite aus. Schalte es ein, sonst kann "
                  "das Gästebuch nicht von selbst auf den Fernseher.")
    return ""


def takeover_allowed_cached():
    if now() - _permission["at"] > 60:
        note = takeover_permission_note()
        _permission.update(at=now(), ok=not note, note=note)
    return _permission["ok"]


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        log(text)
    return False


def _on_session_state(handle_or_state):
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        reason = _takeover["reason"]
        _takeover.update(handle=None, since=0.0, reason="")
        if new_state != "expired":
            for key in REASONS:            # jemand anderes hat den Bildschirm genommen
                if key != "party":
                    _want[key] = 0.0
            _takeover["retryAt"] = now() + 120
    log(f"Der Rahmen hat das Gästebuch beendet ({reason}): {new_state}.")
    if new_state != "expired":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason):
    with _takeover_lock:
        handle = _takeover["handle"]
        _takeover.update(handle=None, since=0.0, reason="")
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:  # noqa: BLE001
        log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", "warning")
    log(f"Bildschirm zurückgegeben ({reason}).")
    if reason != "neu":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def show_book(reason):
    scene = find_scene()
    if not scene:
        return _note(tr("Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal."))
    try:
        if not _takeover["playlistId"] or now() - _takeover["playlistAt"] > 600:
            _takeover.update(playlistId=ensure_takeover_playlist(scene["id"]), playlistAt=now())
    except EngineError as exc:
        return _note(tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc))
    playlist_id = _takeover["playlistId"]
    left = max(60, int(_want[reason] - now()))
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             "overlay": {"enabled": False}}
    handle, limit, last_error = None, 0, None
    for seconds in sorted({min(left + 60, 12 * 3600), min(left + 60, 4 * 3600), min(left + 60, 3600),
                           min(left + 60, 300)}, reverse=True):
        try:
            _leftover["askedAt"] = time.time()
            handle = plugin.acquire_display_session(
                session_key="guestbook", state=state, display_name=DISPLAY_NAME,
                max_duration_seconds=seconds, wake_if_off=settings()["WakeScreen"])
            limit = seconds
            break
        except Exception as exc:  # noqa: BLE001
            last_error = exc
    if handle is None:
        if last_error is not None:
            return _note(takeover_permission_note() or tr("Konnte das Gästebuch nicht zeigen: {exc}", exc=last_error))
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    with _takeover_lock:
        _takeover.update(handle=handle, since=now(), limit=limit, note="", reason=reason)
    try:
        handle.on_state_change(_on_session_state)
    except Exception:  # noqa: BLE001
        pass
    try:
        if not handle.wait_until_active(timeout=15):
            end_takeover("fehlgeschlagen")
            return _note(tr("Der Rahmen hat das Gästebuch nicht rechtzeitig gezeigt."))
    except Exception as exc:  # noqa: BLE001
        end_takeover("fehlgeschlagen")
        return _note(tr("Konnte das Gästebuch nicht zeigen: {exc}", exc=exc))
    _scene["seen"] = max(_scene["seen"], now())   # Zeit, bis die Szene geladen ist
    log(f"Guestbook hat den Bildschirm ({reason}).")
    return True


def decide_takeover():
    t = now()
    reason = wanted_reason(t)
    with _takeover_lock:
        handle, since, limit = _takeover["handle"], _takeover["since"], _takeover["limit"]
        retry_at, busy = _takeover["retryAt"], _takeover["busy"]
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        if not reason:
            end_takeover("fertig")
        elif limit and t - since >= limit - 20:
            end_takeover("neu")
        else:
            _takeover["reason"] = reason
        return
    if not reason:
        stop_leftover_takeover()
        return
    if t < retry_at or busy:
        return
    _takeover["busy"] = True
    try:
        if not show_book(reason):
            with _takeover_lock:
                _takeover["retryAt"] = t + 20
    finally:
        _takeover["busy"] = False


def stop_all(note=""):
    with _takeover_lock:
        for key in REASONS:
            _want[key] = 0.0
    save_state(partyUntil=0)
    end_takeover("von der Plugin-Seite beendet")
    return {"success": True}


# ---- Feiern ----------------------------------------------------------------

def start_party(title):
    values = settings()
    if book.current_event():
        return {"success": False, "error": tr("Es läuft schon eine Feier.")}
    title = booklib.clean_text(title, 60)
    if not title:
        return {"success": False, "error": tr("Gib der Feier einen Namen.")}
    _recap.update(event="", until=0.0)
    event = book.start_event(title, values["PartyHours"])
    log(f"Feier „{event['title']}“ begonnen ({values['PartyHours']} h).")
    if values["PartyOnTv"]:
        want("party", values["PartyHours"] * 3600)
    return {"success": True, "event": event}


def end_party(reason="Plugin-Seite"):
    event = book.end_event()
    want("party", 0)
    if not event:
        return {"success": False, "error": tr("Es läuft gerade keine Feier.")}
    log(f"Feier „{event['title']}“ beendet ({reason}).")
    values = settings()
    if values["RecapMinutes"] and book.visible(event["id"]):
        show_recap(event["id"], values["RecapMinutes"])
    return {"success": True}


def show_recap(ident, minutes=None):
    if not book.event(ident):
        return {"success": False, "error": tr("Diese Feier gibt es nicht mehr.")}
    minutes = minutes or settings()["RecapMinutes"] or 10
    _recap.update(event=ident, until=now() + minutes * 60, id=int(now()))
    want("recap", minutes * 60)
    return {"success": True}


def stop_recap():
    _recap.update(event="", until=0.0)
    want("recap", 0)
    return {"success": True}


# ---- Erinnerung des Tages ----------------------------------------------------

def memory_due(values, t):
    if not (values["Memories"] and values["MemoryOnTv"]):
        return False
    today = datetime.date.today()
    if load_state().get("memoryDay") == today.isoformat():
        return False
    hour, minute = (int(x) for x in values["MemoryTime"].split(":"))
    start = datetime.datetime.combine(today, datetime.time(hour, minute)).timestamp()
    if not (start <= t < start + 3 * 3600):
        return False
    save_state(memoryDay=today.isoformat())
    if not book.memories(today):
        return False
    return True


def show_memory_now(minutes=None):
    if not book.memories():
        return {"success": False, "error": tr("Heute gibt es keine Erinnerung aus früheren Jahren.")}
    with _takeover_lock:
        _focus.update(kind="memory", id="", at=now())
    want("memory", (minutes or settings()["MemoryMinutes"]) * 60)
    return {"success": True}


def tick():
    t = now()
    values = settings()
    event = book.current_event()
    if event and t > event["started"] + event.get("hours", values["PartyHours"]) * 3600 + 60:
        end_party("Zeit abgelaufen")
    if memory_due(values, t) and mode() == "book":
        log("Erinnerung des Tages auf den Fernseher.")
        show_memory_now(values["MemoryMinutes"])
    if _recap["event"] and _recap["until"] and t > _recap["until"] + 2:
        _recap.update(event="", until=0.0)
    with _takeover_lock:
        if _focus["kind"] and not wanted_reason(t) and t - _focus["at"] > 30:
            _focus.update(kind="", id="")
    decide_takeover()


def loop():
    while not _stop_requested.is_set():
        try:
            tick()
            if now() - _services["at"] > SERVICES_EVERY and not _services["busy"]:
                _services["at"] = now()
                threading.Thread(target=check_services, args=(True,), name=f"{PLUGIN_ID}-services",
                                 daemon=True).start()
        except Exception as exc:  # noqa: BLE001 - der Faden darf nicht sterben
            log(f"Schleife: {exc!r}", "warning")
        _stop_requested.wait(1.0)


# ---- Takeover-Playlist, die nach dem Zurückgeben weiterläuft ---------------
# Lief vor einem Takeover keine Playlist, stellt die Engine dieses "nichts"
# nicht wieder her, und die Takeover-Playlist läuft einfach weiter (Jans
# Rahmen, 2026-10-24). Dann hält das Plugin sie mit POST /slideshow/stop an:
# nur wenn sie läuft, niemand den Bildschirm hält und das Plugin nicht
# gerade selbst darum gebeten hat.
_leftover = {"askedAt": 0.0, "failed": False, "checkedAt": 0.0}


def stop_leftover_takeover():
    if time.time() - _leftover["checkedAt"] < 15:
        return False
    _leftover["checkedAt"] = time.time()
    try:
        playlist_id = _takeover["playlistId"] or load_state().get("takeoverPlaylistId")
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status") or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status") or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop")
    except Exception as exc:  # noqa: BLE001 - darf die Schleife nie aufhalten
        if not _leftover["failed"]:
            log(f"The takeover playlist kept running and could not be stopped: {exc}", "warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def check_playback_resumed():
    if playback_guard is not None:
        try:
            playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log, stop_event=_stop_requested)
        except Exception as exc:  # noqa: BLE001
            log(f"playback_guard: {exc}", "warning")


# --------------------------------------------------------------------------
# Verbindungen (Karte auf der Plugin-Seite)
# --------------------------------------------------------------------------

SERVICES_EVERY = 5 * 60
_services = {"at": 0.0, "rows": [], "busy": False}
_services_lock = threading.Lock()


def _row(key, name, state, text, hint=""):
    return {"key": key, "name": name, "state": state, "text": text, "hint": hint}


def _check_engine():
    name = tr("DynaFrame auf diesem Rahmen")
    started = time.time()
    try:
        engine_call("GET", "/slideshow/status", read_timeout=8)
    except EngineError as exc:
        return _row("engine", name, "bad", tr("Nicht erreichbar: {exc}", exc=exc),
                    tr("Starte den Rahmen neu, wenn das rot bleibt."))
    return _row("engine", name, "ok", tr("Erreichbar ({ms} ms).", ms=int((time.time() - started) * 1000)))


def _check_scene():
    name = tr("Szene „Guestbook“")
    scene = find_scene()
    if not scene:
        return _row("scene", name, "bad", tr("Nicht installiert."), tr("Installiere das Paket noch einmal."))
    return _row("scene", name, "ok", tr("Installiert."))


def _check_takeover():
    name = tr("Von selbst auf den Fernseher")
    note = takeover_permission_note()
    _permission.update(at=now(), ok=not note, note=note)
    if note:
        return _row("takeover", name, "warn", tr("„Allow takeover“ ist aus."),
                    tr("Ohne das zeigt der Fernseher neue Einträge, Erinnerungen und Feiern nur, wenn die "
                       "Playlist „Guestbook“ läuft. Einschalten auf der Plugins-Seite."))
    return _row("takeover", name, "ok", tr("Erlaubt."))


def _check_phone():
    name = tr("Seite für die Gäste")
    url = phone_url()
    if not url:
        return _row("phone", name, "bad", tr("Kein freier Port gefunden."), tr("Trag unten einen freien Port ein."))
    started = time.time()
    try:
        response = requests.get(url + "api/ping", timeout=5)
        ok = response.status_code == 200
    except requests.RequestException:
        ok = False
    if not ok:
        return _row("phone", name, "bad", tr("{url} antwortet nicht.", url=url),
                    tr("Ist das WLAN des Rahmens verbunden?"))
    text = tr("Läuft unter {url} ({ms} ms).", url=url, ms=int((time.time() - started) * 1000))
    return _row("phone", name, "ok", text, tr("Mit Web Login und strenger Firewall muss der Port dort offen sein."))


def _check_photos():
    name = tr("Selfies verarbeiten")
    if Image is None:
        return _row("photos", name, "bad", tr("Pillow fehlt."), tr("Installiere das Paket noch einmal."))
    if not HEIF:
        return _row("photos", name, "warn", tr("JPEG und PNG gehen, HEIC (iPhone) nicht."),
                    tr("Die Gäste-Seite wandelt Fotos meist schon im Handy um."))
    return _row("photos", name, "ok", tr("JPEG, PNG und HEIC gehen."))


def _check_storage():
    name = tr("Speicher")
    size = 0
    for file in book.photo_dir().glob("*.jpg"):
        try:
            size += file.stat().st_size
        except OSError:
            pass
    free = booklib.free_bytes(DATA_DIR)
    text = tr("Gästebuch {mb} MB, frei {gb} GB.", mb=f"{size / 1048576:.1f}", gb=f"{free / 1073741824:.1f}")
    if free < MIN_FREE:
        return _row("storage", name, "bad", text, tr("Zu wenig frei: neue Einträge werden abgelehnt."))
    if free < 4 * MIN_FREE:
        return _row("storage", name, "warn", text)
    return _row("storage", name, "ok", text)


def _check_clock():
    name = tr("Datum auf dem Rahmen")
    today = datetime.date.today()
    text = tr("Heute ist der {date}.", date=today.strftime("%d.%m.%Y" if settings()["Language"] == "de" else "%d/%m/%Y"))
    if today.year < 2025:
        return _row("clock", name, "bad", text, tr("Das Datum stimmt nicht; Erinnerungen kämen am falschen Tag."))
    try:
        synced = subprocess.run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"], capture_output=True,
                                text=True, timeout=4).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        synced = ""
    if synced == "no":
        return _row("clock", name, "warn", text + " " + tr("Die Uhr ist nicht mit dem Internet abgeglichen."))
    return _row("clock", name, "ok", text)


def check_services(force=False):
    with _services_lock:
        if _services["busy"] or (not force and now() - _services["at"] < SERVICES_EVERY and _services["rows"]):
            return _services["rows"]
        _services["busy"] = True
    try:
        rows = []
        for fn in (_check_engine, _check_scene, _check_takeover, _check_phone, _check_photos, _check_storage,
                   _check_clock):
            try:
                row = fn()
            except Exception as exc:  # noqa: BLE001 - eine kaputte Prüfung soll die anderen nicht aufhalten
                row = _row("error", tr("Prüfung"), "bad", str(exc))
            if row:
                rows.append(row)
        before = {r["key"]: r["state"] for r in _services["rows"]}
        for r in rows:
            if r["state"] == "bad" and before.get(r["key"]) != "bad":
                log(f"{r['name']}: {r['text']}", "warning")
        _services.update(rows=rows, at=now())
        return rows
    finally:
        _services["busy"] = False


def services_payload():
    rows = _services["rows"]
    return {"at": _services["at"] or None, "busy": _services["busy"], "rows": rows,
            "bad": sum(1 for r in rows if r["state"] == "bad"),
            "warn": sum(1 for r in rows if r["state"] == "warn")}


# --------------------------------------------------------------------------
# Playlist für die Szene
# --------------------------------------------------------------------------

OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=PLAYLIST_NAMES.values(),
    name=lambda: PLAYLIST_NAMES.get(settings()["Language"], PLAYLIST_NAMES["en"]),
    description=lambda: tr("Das Gästebuch: Selfies und Grüße eurer Besucher, und was heute vor Jahren war."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
    held=lambda: _takeover["handle"] is not None,
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    t = now()
    event = book.current_event()
    with _takeover_lock:
        note = _takeover["note"]
        reason = _takeover["reason"] if _takeover["handle"] is not None else ""
        wanted = wanted_reason(t)
        until = _want[wanted] if wanted else 0
    memories = book.memories() if values["Memories"] else []
    last = max(book.entries, key=lambda e: e["at"]) if book.entries else None
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": values,
        "title": book_title(values),
        "code": book.code,
        "stats": book.stats(),
        "last": entry_public(last) if last else None,
        "mode": mode(t),
        "sceneVisible": scene_visible(t),
        "phoneUrl": phone_url(),
        "port": PORTS.status(),
        "takeover": reason,
        "takeoverWanted": wanted,
        "takeoverUntil": until,
        "takeoverNote": note if wanted else "",
        "event": dict(event, count=len(book.visible(event["id"]))) if event else None,
        "recap": {"event": _recap["event"], "until": _recap["until"]} if _recap["event"] else None,
        "memories": [{k: v for k, v in m.items() if k != "entries"} for m in memories],
        "services": services_payload(),
        "heif": HEIF,
        "pillow": Image is not None,
        "theme": {"id": theme_id()},
    }


def admin_entries(query):
    which = (query.get("f") or ["all"])[0]
    with book.lock:
        rows = list(book.entries)
    if which == "wait":
        rows = [e for e in rows if e.get("st") == "wait"]
    elif which == "visits":
        rows = [e for e in rows if not e.get("ev")]
    elif which.startswith("ev:"):
        rows = [e for e in rows if e.get("ev") == which[3:]]
    rows = sorted(rows, key=lambda e: -e["at"])
    return {"success": True, "entries": [entry_public(e, admin=True) for e in rows[:600]], "total": len(rows)}


def admin_events():
    return {"success": True, "events": book.event_rows()}


def book_data(query):
    which = (query.get("event") or [""])[0]
    rows = book.visible(which) if which else book.visible()
    rows = sorted(rows, key=lambda e: e["at"])
    event = book.event(which) if which else None
    return {"success": True, "title": book_title(), "event": event, "lang": settings()["Language"],
            "entries": [entry_public(e) for e in rows]}


def make_zip(event_id):
    """Selfies und Grüße als ZIP (in eine Datei, nicht in den Speicher)."""
    if event_id and not book.event(event_id):
        return None, ""
    rows = sorted(book.visible(event_id) if event_id else book.visible(), key=lambda e: e["at"])
    handle = tempfile.NamedTemporaryFile(dir=DATA_DIR, prefix=".zip-", suffix=".zip", delete=False)
    handle.close()
    path = Path(handle.name)
    lines = []
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        for number, row in enumerate(rows, 1):
            who = re.sub(r"[^\w-]+", "-", row.get("name") or "guest").strip("-")[:30] or "guest"
            stem = f"{row['day']}-{number:03d}-{who}"
            source = book.photo_dir() / f"{row['id']}.jpg"
            if row.get("photo") and source.exists():
                archive.write(source, f"{stem}.jpg", compress_type=zipfile.ZIP_STORED)
            stamp = datetime.datetime.fromtimestamp(row["at"]).strftime("%Y-%m-%d %H:%M")
            lines.append(f"{stamp}  {row.get('name')}\n{row.get('text') or ''}\n")
        archive.writestr("guestbook.txt", "\n".join(lines))
    event = book.event(event_id) if event_id else None
    title = re.sub(r"[^\w-]+", "-", (event or {}).get("title") or "guestbook").strip("-")[:40] or "guestbook"
    return path, f"{title}-{time.strftime('%Y-%m-%d')}.zip"


def page_html(name="index.html"):
    html = (PLUGIN_DIR / "studio" / name).read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
    "/print.js": ("studio/print.js", "application/javascript; charset=utf-8"),
    "/print.css": ("studio/print.css", "text/css; charset=utf-8"),
    "/qrcode.js": ("phone/qrcode.js", "application/javascript; charset=utf-8"),
    "/port_block.js": ("studio/port_block.js", "application/javascript; charset=utf-8"),
    "/fonts/Caveat.woff2": ("phone/Caveat.woff2", "font/woff2"),
}
PHONE_FILES = {
    "/phone.css": ("phone/phone.css", "text/css; charset=utf-8"),
    "/phone.js": ("phone/phone.js", "application/javascript; charset=utf-8"),
    "/icon.png": ("icon.png", "image/png"),
    "/Caveat.woff2": ("phone/Caveat.woff2", "font/woff2"),
}


class BaseHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False, extra=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self, limit=1024 * 1024):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(min(length, limit)) if length > 0 else b""
        if length > limit:
            self.close_connection = True

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _photo(self, ident, size, cors=False):
        found = photo_file(ident, size)
        if found is None:
            self._json({"success": False}, 404, cors=cors)
        else:
            self._send(found, "image/jpeg", cache="private, max-age=86400", cors=cors)


class StudioHandler(BaseHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        arg = lambda name, default="": (query.get(name) or [default])[0]  # noqa: E731
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            if path == "/print.html":
                html = (PLUGIN_DIR / "studio" / "print.html").read_text(encoding="utf-8")
                html = html.replace('<html lang="en">', f'<html lang="{settings()["Language"]}">', 1)
                self._send(html.encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                # Die Szene fragt etwa alle zwei Sekunden; daran merkt das Plugin, dass sie zu sehen ist.
                _scene["seen"] = now()
                self._json(scene_state(as_int(arg("since", "-1"), -1)), cors=True)
                return
            if path == "/api/next":
                self._json(next_entry(query), cors=True)
                return
            if path == "/api/photo":
                row = book.find(arg("id"))
                if not row or (row.get("st") != "ok" and arg("admin") != "1"):
                    self._json({"success": False}, 404, cors=True)
                    return
                self._photo(row["id"], arg("s", "f"), cors=True)
                return
            if path == "/api/entries":
                self._json(admin_entries(query))
                return
            if path == "/api/events":
                self._json(admin_events())
                return
            if path == "/api/book":
                self._json(book_data(query))
                return
            if path == "/api/upcoming":
                self._json({"success": True, "days": book.upcoming(int(arg("days", "60") or 60))})
                return
            if path == "/api/services":
                check_services(force=True)
                self._json({"success": True, "services": services_payload()})
                return
            if path == "/api/zip":
                target, name = make_zip(arg("event"))
                if target is None:
                    self._json({"success": False, "error": "Nicht gefunden"}, 404)
                    return
                try:
                    data = target.read_bytes()
                finally:
                    target.unlink(missing_ok=True)
                self._send(data, "application/zip", extra={
                    "Content-Disposition": f"attachment; filename*=UTF-8''{quote(name)}"})
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", arg("m"))[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            body = self._body()
            if path == "/api/port":
                self._json(PORTS.change(body.get("port")))
                return
            if path == "/api/settings":
                changed = save_settings(body)
                if "MakePlaylist" in changed:
                    OWN.changed()
                if "PartyOnTv" in changed and book.current_event():
                    event = book.current_event()
                    left = event["started"] + event.get("hours", 6) * 3600 - now()
                    want("party", left if settings()["PartyOnTv"] else 0)
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/code":
                book.set_meta(code=booklib.new_code())
                self._json({"success": True, "code": book.code})
                return
            if path == "/api/entry/update":
                fields = {k: body[k] for k in ("name", "text", "st", "day") if k in body}
                row = book.update(str(body.get("id") or ""), **fields)
                if row and fields.get("st") == "ok":
                    welcome(row)
                self._json({"success": bool(row)})
                return
            if path == "/api/entry/delete":
                self._json({"success": book.delete(str(body.get("id") or ""))})
                return
            if path == "/api/approve-all":
                waiting = [e for e in book.entries if e.get("st") == "wait"]
                for row in waiting:
                    book.update(row["id"], st="ok")
                if waiting:
                    welcome(waiting[-1])
                self._json({"success": True, "n": len(waiting)})
                return
            if path == "/api/party/start":
                self._json(start_party(body.get("title")))
                return
            if path == "/api/party/end":
                self._json(end_party())
                return
            if path == "/api/event/rename":
                self._json({"success": book.rename_event(str(body.get("id") or ""), body.get("title"))})
                return
            if path == "/api/event/recap":
                self._json(show_recap(str(body.get("id") or "")))
                return
            if path == "/api/event/delete":
                self._json({"success": book.delete_event(str(body.get("id") or ""), as_bool(body.get("entries")))})
                return
            if path == "/api/show":
                want("manual", max(1, min(120, as_int(body.get("minutes"), 5))) * 60)
                self._json({"success": True})
                return
            if path == "/api/memory":
                self._json(show_memory_now())
                return
            if path == "/api/stop":
                stop_recap()
                self._json(stop_all())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


def phone_html():
    html = (PLUGIN_DIR / "phone" / "index.html").read_text(encoding="utf-8")
    lang = settings()["Language"]
    return html.replace('<html lang="en">', f'<html lang="{lang}">', 1)


class PhoneHandler(BaseHandler):
    """Die Seite für die Gäste, im ganzen WLAN erreichbar. Keine Einstellungen."""

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(phone_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = PHONE_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1], cache="public, max-age=3600")
                return
            if path == "/api/ping":
                self._json({"success": True, "plugin": PLUGIN_ID})
                return
            if path == "/api/info":
                self._json(phone_info(query))
                return
            if path == "/api/book":
                self._json(phone_book(query))
                return
            if path == "/api/photo":
                if not code_ok((query.get("c") or [""])[0]):
                    self._json({"success": False}, 404)
                    return
                ident = (query.get("id") or [""])[0]
                row = book.find(ident)
                mine = book.mine(ident, (query.get("dev") or [""])[0])
                if not row or not (mine or (row.get("st") == "ok" and settings()["GuestsSeeBook"])):
                    self._json({"success": False}, 404)
                    return
                self._photo(row["id"], (query.get("s") or ["t"])[0])
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError:
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path == "/api/entry":
                self._entry()
                return
            self._drain_body()
            if path == "/api/edit":
                self._json(phone_edit(self._body()))
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def _entry(self):
        """POST /api/entry: Formular mit c, dev, name, text und optional photo."""
        length = as_int(self.headers.get("Content-Length"), 0)
        if length <= 0 or length > MAX_UPLOAD:
            self._drain_body(0)
            self.close_connection = True
            self._json({"success": False, "error": tr("Das Foto ist zu groß (höchstens {mb} MB).",
                                                      mb=MAX_UPLOAD // 1048576)}, 413)
            return
        data = self.rfile.read(length)
        content_type = self.headers.get("Content-Type") or ""
        if content_type.lower().startswith("multipart/"):
            fields, photo = multipart_fields(content_type, data)
        elif content_type.lower().startswith("application/x-www-form-urlencoded"):
            fields = {k: v[0] for k, v in parse_qs(data.decode("utf-8", "replace")).items()}
            photo = b""
        else:
            self._json({"success": False, "error": "form"}, 400)
            return
        if not code_ok(fields.get("c")):
            self._json({"success": False, "error": "code"}, 403)
            return
        try:
            row = add_entry(fields.get("dev"), fields.get("name"), fields.get("text"), photo)
        except EntryError as exc:
            self._json({"success": False, "error": str(exc)}, 400)
            return
        values = settings()
        self._json({"success": True, "entry": entry_public(row, me_hash=row["dev"]) | {"st": row["st"]},
                    "waiting": row["st"] == "wait",
                    "tv": row["st"] == "ok" and (scene_visible() or (values["WelcomeOnTv"] and
                                                                     takeover_allowed_cached()))})


studio_server = None
PORTS = plugin_ports.PortKeeper(PLUGIN_ID, "Guestbook", DATA_DIR, default=8135, env="GUESTBOOK_PORT",
                                log=lambda text, level="info": log(text, level),
                                language=lambda: settings()["Language"])


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    studio_server.daemon_threads = True
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


def start_phone():
    PORTS.start(lambda port: ThreadingHTTPServer(("0.0.0.0", port), PhoneHandler))
    if PORTS.port:
        log(f"Gäste-Seite: {phone_url()}")


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    global book
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}" + ("" if HEIF else " (ohne HEIC-Unterstützung)"))
    book = booklib.Book(BOOK_DIR)

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("playlist", lambda _context=None: make_playlist())
    plugin.on_action("memory", lambda _context=None: show_memory_now())

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    start_phone()
    event = book.current_event()
    until = float(load_state().get("partyUntil") or 0)
    if event and until > now() + 60 and settings()["PartyOnTv"]:   # nach einem Neustart mitten in der Feier
        with _takeover_lock:
            _want["party"] = until
    threading.Thread(target=loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    threading.Thread(target=check_services, args=(True,), name=f"{PLUGIN_ID}-services", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    end_takeover("gestoppt")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:  # noqa: BLE001
        pass
    PORTS.stop()
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:  # noqa: BLE001
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
