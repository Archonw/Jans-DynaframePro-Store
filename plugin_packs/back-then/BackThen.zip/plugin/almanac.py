"""Was war damals los? Fakten zu einem Jahr bzw. einem Tag.

Die Grundlage ist der mitgelieferte Datensatz data_bundled.json (gebaut mit
tools/back-then/build_data.py aus Wikipedia, Wikidata, Destatis, BLS und
World Bank). Was dort fehlt (z. B. Ereignisse eines Jahres in einer
Sprache), holt das Plugin bei Bedarf selbst von Wikidata und merkt es sich
für immer. Porträts der Regierungschefs kommen von Wikimedia Commons.

Alles hier ist so gebaut, dass ein fehlendes Netz nur Lücken macht, nie
einen Fehler in der Szene.
"""

import datetime
import hashlib
import json
import re
import threading
import time
from pathlib import Path
from urllib.parse import quote

import requests

UA = "BackThen-DynaFrame-plugin (https://github.com/Archonw/Jans-DynaframePro-Store)"
SPARQL_URL = "https://query.wikidata.org/sparql"
COMMONS_FILE = "https://commons.wikimedia.org/wiki/Special:FilePath/{name}?width=320"

COUNTRIES = ("DE", "AT", "CH", "US", "GB", "ES")
DEFAULT_COUNTRY = {"de": "DE", "en": "US", "es": "ES"}
DM_PER_EURO = 1.95583
ATS_PER_EURO = 13.7603
ESP_PER_EURO = 166.386

EVENTS_QUERY = """
SELECT ?item ?label ?desc ?date ?links (GROUP_CONCAT(DISTINCT STRAFTER(STR(?cls), "entity/"); separator=",") AS ?classes) WHERE {
  { ?item wdt:P585 ?date } UNION { ?item wdt:P580 ?date }
  FILTER(?date >= "%(y)04d-01-01T00:00:00Z"^^xsd:dateTime && ?date < "%(n)04d-01-01T00:00:00Z"^^xsd:dateTime)
  ?item wikibase:sitelinks ?links . FILTER(?links >= 12)
  FILTER NOT EXISTS { ?item wdt:P31 wd:Q5 }
  ?article schema:about ?item ; schema:isPartOf <https://%(lang)s.wikipedia.org/> .
  ?item rdfs:label ?label FILTER(LANG(?label) = "%(lang)s")
  OPTIONAL { ?item schema:description ?desc FILTER(LANG(?desc) = "%(lang)s") }
  OPTIONAL { ?item wdt:P31 ?cls }
} GROUP BY ?item ?label ?desc ?date ?links ORDER BY DESC(?links) LIMIT 150"""


def short(exc):
    """Fehlertext ohne lange Adresse."""
    if isinstance(exc, requests.ConnectionError):
        text = str(exc)
        if "403" in text and "proxy" in text.lower():
            return "Proxy 403"
        return "keine Verbindung" if "Name or service" not in text else "Name nicht auflösbar (DNS)"
    if isinstance(exc, requests.Timeout):
        return "Zeitüberschreitung"
    return str(exc)[:120]


def _date(text):
    try:
        return datetime.date.fromisoformat(str(text)[:10])
    except ValueError:
        return None


class Almanac:
    def __init__(self, data_dir, bundled_file, log):
        self.dir = Path(data_dir)
        self.log = log
        self.lock = threading.Lock()
        try:
            self.data = json.loads(Path(bundled_file).read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            log(f"Datensatz fehlt oder ist kaputt: {exc}", "warning")
            self.data = {}
        self.cache_file = self.dir / "wikidata.json"
        try:
            self.cache = json.loads(self.cache_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.cache = {}
        self.failed = {}            # key -> Zeitpunkt des letzten Fehlschlags
        self.last_error = ""
        self.session = requests.Session()
        self.session.headers["User-Agent"] = UA

    # ------------------------------------------------------------------ Grundlagen

    def country(self, code):
        return (self.data.get("countries") or {}).get(code) or {}

    def bundled_range(self):
        years = [int(y) for lang in (self.data.get("events") or {}).values() for y in lang]
        return (min(years), max(years)) if years else (None, None)

    # ------------------------------------------------------------------ Ereignisse

    def _wikidata_events(self, year, lang):
        key = f"events|{lang}|{year}"
        with self.lock:
            if key in self.cache:
                return self.cache[key]
        if time.time() - self.failed.get(key, 0) < 6 * 3600:
            return None
        query = EVENTS_QUERY % {"y": year, "n": year + 1, "lang": lang}
        try:
            response = self.session.get(SPARQL_URL, params={"query": query, "format": "json"},
                                        headers={"Accept": "application/sparql-results+json"}, timeout=(10, 70))
            response.raise_for_status()
            rows = response.json()["results"]["bindings"]
        except (requests.RequestException, ValueError, KeyError) as exc:
            self.failed[key] = time.time()
            self.last_error = f"Wikidata: {short(exc)}"
            self.log(f"Ereignisse {year} ({lang}) von Wikidata: {short(exc)}", "warning")
            return None
        out = clean_events(rows)
        self.last_error = ""
        with self.lock:
            self.cache[key] = out
            self._save()
        return out

    def _save(self):
        try:
            self.dir.mkdir(parents=True, exist_ok=True)
            temp = self.cache_file.with_suffix(".tmp")
            temp.write_text(json.dumps(self.cache, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
            temp.replace(self.cache_file)
        except OSError as exc:
            self.log(f"Konnte wikidata.json nicht speichern: {exc}", "warning")

    def events(self, year, lang, limit=6):
        rows = ((self.data.get("events") or {}).get(lang) or {}).get(str(year))
        if rows is None:
            rows = self._wikidata_events(year, lang)
        if rows is None and lang != "en":       # dann wenigstens englisch
            rows = ((self.data.get("events") or {}).get("en") or {}).get(str(year))
        return [{"date": r[0], "label": r[1], "desc": r[2]} for r in (rows or [])[:limit]]

    def born(self, year, lang, limit=4):
        born = self.data.get("born") or {}
        for other in (lang, "en", "de", "es"):
            rows = (born.get(other) or {}).get(str(year))
            if rows:
                # Namen passen in jeder Sprache, die Beschreibung nur in der eigenen
                return [{"label": r[0], "desc": r[1] if other == lang else ""} for r in rows[:limit]]
        return []

    # ------------------------------------------------------------------ Nummer eins

    def hit_on(self, code, day):
        """Der Nummer-eins-Hit an diesem Tag (Wochencharts) und wie lange er oben war."""
        runs = self.country(code).get("hits") or []
        if not runs or day is None:
            return None
        text = day.isoformat()
        found = None
        for idx, run in enumerate(runs):
            if run[0] <= text:
                found = idx
            else:
                break
        if found is None:
            return None
        run = runs[found]
        start = _date(run[0])
        end = _date(runs[found + 1][0]) if found + 1 < len(runs) else None
        if end is None and start and (day - start).days > 120:
            return None                       # Liste hört vorher auf
        weeks = round(((end or day) - start).days / 7) if start else None
        return {"title": run[1], "artist": run[2], "weeks": weeks if end else None, "since": run[0]}

    def hit_of_year(self, code, year):
        """Der Hit, der in dem Jahr am längsten auf Platz 1 stand."""
        runs = self.country(code).get("hits") or []
        lo, hi = datetime.date(year, 1, 1), datetime.date(year + 1, 1, 1)
        days = {}
        for idx, run in enumerate(runs):
            start = _date(run[0])
            end = _date(runs[idx + 1][0]) if idx + 1 < len(runs) else None
            if start is None:
                continue
            if end is None:
                end = start + datetime.timedelta(days=7)
            a, b = max(start, lo), min(end, hi)
            if b > a:
                key = (run[1], run[2])
                days[key] = days.get(key, 0) + (b - a).days
        if not days:
            return None
        (title, artist), count = max(days.items(), key=lambda item: item[1])
        return {"title": title, "artist": artist, "weeks": round(count / 7)}

    # ------------------------------------------------------------------ Regierung

    def leader(self, code, day, lang, role="gov"):
        rows = (self.country(code).get("leaders") or {}).get(role) or []
        if day is None:
            return None
        text = day.isoformat()
        best = None
        for row in rows:
            start, end = row[0] or "0000", row[1] or "9999"
            if start <= text < end or (start <= text and end == text):
                # bei Überschneidung (Übergabe am selben Tag) gilt der spätere Beginn
                if best is None or start > best[0]:
                    best = row
        if best is None:
            return None
        names = best[3] or {}
        female = len(best) > 5 and best[5]
        titles = self.country(code).get("titles") or {}
        title = (titles.get(role + "F") if female else None) or titles.get(role) or {}
        return {"name": names.get(lang) or names.get("en") or "", "qid": best[2], "image": best[4] or "",
                "since": best[0], "until": best[1], "title": title.get(lang, "")}

    def portrait(self, filename):
        """Porträt von Commons (einmal holen, dann aus dem Cache). Liefert Bytes oder None."""
        if not filename:
            return None
        folder = self.dir / "portraits"
        target = folder / (hashlib.sha1(filename.encode("utf-8")).hexdigest()[:20] + ".jpg")
        if target.is_file():
            return target.read_bytes()
        key = "portrait|" + filename
        if time.time() - self.failed.get(key, 0) < 6 * 3600:
            return None
        url = COMMONS_FILE.format(name=quote(filename.replace(" ", "_")))
        try:
            response = self.session.get(url, timeout=(10, 40))
            kind = response.headers.get("Content-Type", "")
            if response.status_code != 200 or not kind.startswith("image/"):
                raise requests.RequestException(f"HTTP {response.status_code} {kind}")
        except requests.RequestException as exc:
            self.failed[key] = time.time()
            self.last_error = f"Wikimedia Commons: {short(exc)}"
            return None
        folder.mkdir(parents=True, exist_ok=True)
        target.write_bytes(response.content)
        return response.content

    # ------------------------------------------------------------------ Preise

    def prices(self, code, year):
        """Preise damals und zuletzt (je Ding), in der Währung der Zeit."""
        country = self.country(code)
        out = []
        for item, spec in (country.get("prices") or {}).items():
            series = spec.get("series") or {}
            if not series:
                continue
            years = sorted(int(y) for y in series)
            then_year = max((y for y in years if y <= year), default=None)
            if then_year is None or year - then_year > 3:
                continue
            last_year = years[-1]
            then = series[str(then_year)]
            last = series[str(last_year)]
            row = {"item": item, "unit": spec.get("unit", ""), "then": then[0], "cur": then[1],
                   "year": then_year, "now": last[0], "nowCur": last[1], "nowYear": last_year,
                   "exact": spec.get("exact", True)}
            euro = to_euro(then[0], then[1])
            if euro is not None and then[1] != last[1]:
                row["euro"] = euro
            out.append(row)
        return out

    def inflation(self, code, year):
        """Wie viel Geld von damals heute wert ist (Verbraucherpreisindex)."""
        cpi = (self.data.get("cpi") or {}).get(code) or {}
        if str(year) not in cpi or not cpi:
            return None
        last = max(int(y) for y in cpi)
        then, now = cpi[str(year)], cpi[str(last)]
        if not then or not now:
            return None
        return {"factor": round(now / then, 2), "lastYear": last}

    # ------------------------------------------------------------------ alles zusammen

    def facts(self, year, code, lang, days=()):
        """Die Fakten zu einem Jahr, dazu je Fototag Hit und Regierung an genau dem Tag."""
        out = {"year": year, "country": code,
               "events": self.events(year, lang), "born": self.born(year, lang),
               "hitYear": self.hit_of_year(code, year), "prices": self.prices(code, year),
               "inflation": self.inflation(code, year), "days": {}}
        mid = datetime.date(year, 7, 1)
        out["leader"] = self.leader(code, mid, lang, "gov")
        out["state"] = self.leader(code, mid, lang, "state")
        for day in days:
            when = _date(day)
            if when is None:
                continue
            out["days"][day[:10]] = {"hit": self.hit_on(code, when), "leader": self.leader(code, when, lang, "gov")}
        return out


def to_euro(value, currency):
    rate = {"DM": DM_PER_EURO, "ATS": ATS_PER_EURO, "ESP": ESP_PER_EURO}.get(currency)
    return round(value / rate, 2) if rate and value is not None else None


# Klassen, die keine Nachrichten sind (Serien, Währungen, Firmen, Saisons, Listen …)
SKIP_CLASSES = set("""
Q577 Q235690 Q3186692 Q47018901 Q5398426 Q117467246 Q63952888 Q21198342 Q8142 Q4830453 Q43229 Q6881511 Q891723
Q786820 Q59773381 Q13406463 Q18340514 Q2558684 Q18574943 Q11448906 Q196600 Q26132862 Q114609228 Q26213387
Q105543609 Q1154710 Q25391 Q473972 Q341 Q271680 Q272683 Q61697632 Q174713 Q6498959 Q17317604 Q57305 Q725377
Q3297186 Q26742250 Q16848281 Q123724352 Q47345468 Q12708896 Q11424 Q7889 Q482994 Q134556 Q7725634 Q1002697 Q41298
Q11032 Q431289 Q15416 Q1259759 Q526877 Q3464665 Q21191270 Q1667921 Q7058673 Q14406742 Q838795 Q3305213 Q618779
Q4167410 Q27020041 Q1366722 Q3231690 Q15632617 Q3890208 Q24862 Q202444 Q1569167 Q24856 Q1004 Q5185279 Q4022
Q2085381 Q215380 Q5633421 Q3241045 Q10855061 Q1371849 Q1124833 Q17537576 Q22808320 Q105420 Q7397 Q166142 Q17155032
Q63952888 Q1107 Q8274 Q581714 Q3624078 Q6256 Q515 Q15284 Q486972 Q1637706 Q1549591 Q7930989 Q2221906 Q1093829
Q14350 Q1616075 Q4438121 Q1188986 Q100269041 Q1194951 Q1047113 Q2088357 Q17489160 Q19842659 Q5 Q16521 Q190752 Q41487
Q2305295 Q106664582 Q1241568 Q2305029 Q3476533 Q5003624 Q39911 Q1114461 Q19324463 Q58863414 Q35127 Q568765 Q12340140 Q749622 Q978 Q147027 Q17517379 Q113791292 Q116457956 Q36784 Q1110794 Q21191134 Q747699 Q28783456 Q14083 Q2380335 Q55990535 Q4220917 Q15275719 Q107655869 Q1189842 Q2558591 Q28873665 Q134995802 Q42032 Q186516 Q1407393 Q47018478 Q66010139 Q66010158 Q16022392 Q27968055 Q59152282 Q561068 Q23691 Q1225911 Q1478437 Q53945096
""".split())
SKIP_LABEL = re.compile(r"\d{4}\s*[/–-]\s*\d{2,4}|saison|season|temporada|Medaillenspiegel|medal table|medallero|"
                        r"^(Anexo|Liste|List of)|\bin (film|music|sports?|television)\b|Filmjahr|Musikjahr|"
                        r"Qualifikation|qualification|clasificación|Großer Preis|Grand Prix|Gran Premio|/|^Wiki(pedia|proyecto)?:|^\d{4}(er|s)$|^años \d{4}", re.I)


def _cut(text, limit):
    if len(text) <= limit:
        return text
    return text[:limit].rsplit(" ", 1)[0].rstrip(",;:") + "…"


def clean_events(rows):
    best = {}
    for row in rows:
        item = row.get("item", {}).get("value", "")
        label = row.get("label", {}).get("value", "").strip()
        if not label or re.match(r"^\d{4}$", label) or SKIP_LABEL.search(label):
            continue
        classes = set(filter(None, row.get("classes", {}).get("value", "").split(",")))
        if not classes or classes & SKIP_CLASSES:
            continue
        date = row.get("date", {}).get("value", "")[:10]
        links = int(float(row.get("links", {}).get("value", 0) or 0))
        desc = row.get("desc", {}).get("value", "").strip()
        old = best.get(item)
        # das genaueste Datum behalten (01-01 heißt meist: nur Jahr bekannt)
        if old is None or (old[0].endswith("-01-01") and not date.endswith("-01-01")):
            best[item] = [date, label, _cut(desc, 110), links]
    # Nur mit Jahr datiert (01-01) und ohne Jahreszahl im Titel: meist Firmen, Konflikte, Zeiträume
    rows = [r for r in best.values() if not r[0].endswith("-01-01") or r[0][:4] in r[1]]
    rows.sort(key=lambda r: -r[3])
    return rows[:16]


def clean_born(rows):
    out, seen = [], set()
    for row in rows:
        item = row.get("item", {}).get("value", "")
        label = row.get("label", {}).get("value", "").strip()
        if not label or item in seen or re.match(r"^Q\d+$", label):
            continue
        seen.add(item)
        out.append([label, _cut(row.get("desc", {}).get("value", "").strip(), 80)])
    return out[:8]


