"""Live-Werte des Rahmens für die Seitenleisten der Szene.

Liest nur /proc und /sys (kein Zusatzpaket, kein Root): CPU-Last, Speicher,
Netzwerk (Bytes je Sekunde über alle Schnittstellen außer lo), Temperatur,
Last, Laufzeit und Speicherplatz. Ein Thread misst jede Sekunde, solange die
Szene in den letzten fünf Minuten gefragt hat, sonst alle 15 Sekunden.
"""

import os
import shutil
import socket
import threading
import time
from collections import deque

HISTORY = 90          # so viele Messpunkte (Sekunden) gehen an die Szene


def _read(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            return handle.read()
    except OSError:
        return ""


def _cpu_times():
    line = _read("/proc/stat").split("\n", 1)[0].split()
    if not line or line[0] != "cpu":
        return None
    values = [int(v) for v in line[1:9]]
    idle = values[3] + values[4]            # idle + iowait
    return sum(values), idle


def _memory():
    info = {}
    for line in _read("/proc/meminfo").splitlines():
        name, _, rest = line.partition(":")
        parts = rest.split()
        if parts:
            try:
                info[name] = int(parts[0]) * 1024
            except ValueError:
                pass
    total = info.get("MemTotal", 0)
    available = info.get("MemAvailable", info.get("MemFree", 0))
    return {"total": total, "used": max(0, total - available),
            "swapTotal": info.get("SwapTotal", 0), "swapUsed": max(0, info.get("SwapTotal", 0) - info.get("SwapFree", 0))}


def _network():
    rx = tx = 0
    for line in _read("/proc/net/dev").splitlines()[2:]:
        name, _, rest = line.partition(":")
        name = name.strip()
        if not rest or name == "lo" or name.startswith(("docker", "veth", "br-", "virbr")):
            continue
        parts = rest.split()
        if len(parts) >= 9:
            rx += int(parts[0])
            tx += int(parts[8])
    return rx, tx


def _temperature():
    best = None
    base = "/sys/class/thermal"
    try:
        zones = sorted(z for z in os.listdir(base) if z.startswith("thermal_zone"))
    except OSError:
        zones = []
    for zone in zones:
        kind = _read(f"{base}/{zone}/type").strip().lower()
        raw = _read(f"{base}/{zone}/temp").strip()
        try:
            value = int(raw) / 1000.0
        except ValueError:
            continue
        if 0 < value < 130 and (best is None or "cpu" in kind or "soc" in kind):
            best = value
            if "cpu" in kind or "soc" in kind:
                break
    return best


def _ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(("10.255.255.255", 1))     # schickt nichts, wählt nur die Schnittstelle
            return probe.getsockname()[0]
    except OSError:
        return ""


class Telemetry:
    def __init__(self, disk_path="/"):
        self.disk_path = disk_path
        self.lock = threading.Lock()
        self.cpu = deque(maxlen=HISTORY)
        self.rx = deque(maxlen=HISTORY)
        self.tx = deque(maxlen=HISTORY)
        self.mem = deque(maxlen=HISTORY)
        self.last_cpu = None
        self.last_net = None
        self.wanted_at = 0.0
        self.peak = {"rx": 0.0, "tx": 0.0}
        self.ip = ""
        self.ip_at = 0.0
        self.stop = threading.Event()
        self.ok = os.path.exists("/proc/stat")

    def sample(self):
        stamp = time.monotonic()
        cpu = _cpu_times()
        net = _network()
        mem = _memory()
        with self.lock:
            if cpu and self.last_cpu:
                total = cpu[0] - self.last_cpu[0]
                idle = cpu[1] - self.last_cpu[1]
                if total > 0:
                    self.cpu.append(round(max(0.0, min(100.0, 100.0 * (total - idle) / total)), 1))
            if self.last_net:
                seconds = max(0.2, stamp - self.last_net[0])
                rx = max(0, net[0] - self.last_net[1]) / seconds
                tx = max(0, net[1] - self.last_net[2]) / seconds
                self.rx.append(round(rx))
                self.tx.append(round(tx))
                self.peak["rx"] = max(self.peak["rx"] * 0.999, rx)
                self.peak["tx"] = max(self.peak["tx"] * 0.999, tx)
            if mem["total"]:
                self.mem.append(round(100.0 * mem["used"] / mem["total"], 1))
            self.last_cpu = cpu
            self.last_net = (stamp, net[0], net[1])

    def run(self):
        while not self.stop.is_set():
            try:
                self.sample()
            except Exception:   # noqa: BLE001 - Messfehler dürfen den Thread nicht beenden
                pass
            busy = time.time() - self.wanted_at < 300
            if not busy:
                # Ohne Szene nur grob messen; die Lücke soll nicht als Spitze erscheinen.
                self.last_net = None
            self.stop.wait(1.0 if busy else 15.0)

    def start(self):
        threading.Thread(target=self.run, name="PhotoScanner-telemetry", daemon=True).start()

    def snapshot(self):
        self.wanted_at = time.time()
        mem = _memory()
        try:
            disk = shutil.disk_usage(self.disk_path)
            disk = {"total": disk.total, "used": disk.used}
        except OSError:
            disk = None
        load = _read("/proc/loadavg").split()
        uptime = _read("/proc/uptime").split()
        if time.time() - self.ip_at > 300:
            self.ip_at = time.time()
            self.ip = _ip()
        with self.lock:
            return {
                "cpu": list(self.cpu), "mem": mem, "memHistory": list(self.mem),
                "rx": list(self.rx), "tx": list(self.tx),
                "temp": _temperature(),
                "load": [float(v) for v in load[:3]] if len(load) >= 3 else [],
                "uptime": float(uptime[0]) if uptime else 0.0,
                "cores": os.cpu_count() or 1,
                "disk": disk,
                "host": socket.gethostname(),
                "ip": self.ip,
            }
