"use strict";
// Druckseiten: ?what=card (QR-Kärtchen, zwei auf einer Seite) oder ?what=book[&event=<id>] (das Buch).
(function () {
  const T = {
    print: ["Drucken", "Print", "Imprimir"],
    cardKicker: ["Gästebuch", "Guestbook", "Libro de visitas"],
    cardLead: ["Scannt den Code mit dem Handy, macht ein Selfie und schreibt uns ein paar Zeilen.", "Scan the code with your phone, take a selfie and write us a few lines.", "Escanead el código con el móvil, haceos un selfie y escribidnos unas líneas."],
    code: ["Code {code}", "Code {code}", "Código {code}"],
    wifi: ["im WLAN: {url}", "on the Wi-Fi: {url}", "en la wifi: {url}"],
    thanks: ["Schön, dass ihr da seid!", "So glad you're here!", "¡Qué alegría que estéis aquí!"],
    entries: ["{n} Einträge", "{n} entries", "{n} entradas"],
    noPort: ["Die Gäste-Seite läuft gerade nicht, es gibt keinen QR-Code.", "The guest page is not running, so there is no QR code.", "La página de invitados no está en marcha; no hay código QR."],
    empty: ["Noch keine Einträge.", "No entries yet.", "Aún no hay entradas."],
    cardHint: ["Tipp: auf festes Papier drucken und an der Linie ausschneiden.", "Tip: print on card stock and cut along the line.", "Consejo: imprime en cartulina y recorta por la línea."]
  };
  const LANGS = ["de", "en", "es"];
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  let lang = (document.documentElement.lang || "en").slice(0, 2);
  if (!LANGS.includes(lang)) lang = "en";
  const tx = (k, v = {}) => (T[k][LANGS.indexOf(lang)] || T[k][1]).replace(/\{(\w+)\}/g, (_, n) => String(v[n] ?? ""));
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const day = (iso) => new Date(iso + "T12:00:00").toLocaleDateString(LOCALES[lang], { day: "numeric", month: "long", year: "numeric" });
  const params = new URLSearchParams(location.search);
  const sheet = document.getElementById("sheet");
  document.getElementById("printButton").textContent = tx("print");
  document.getElementById("printButton").addEventListener("click", () => print());

  async function card() {
    const state = await (await fetch("./api/state", { cache: "no-store" })).json();
    if (!state.phoneUrl) { sheet.innerHTML = `<p class="empty">${esc(tx("noPort"))}</p>`; return; }
    const link = `${state.phoneUrl}?c=${state.code}`;
    const qr = qrcode(0, "M");
    qr.addData(link);
    qr.make();
    const svg = qr.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
    const one = `<div class="card"><p class="kicker">${esc(tx("cardKicker"))}</p><h1>${esc(state.title)}</h1>
      <p class="lead">${esc(tx("cardLead"))}</p><div class="qr">${svg}</div>
      <p class="code">${esc(tx("code", { code: state.code }))}</p><p class="url">${esc(tx("wifi", { url: state.phoneUrl.replace(/^https?:\/\//, "").replace(/\/$/, "") }))}</p>
      <p class="hand">${esc(tx("thanks"))}</p></div>`;
    sheet.innerHTML = `<div class="cards">${one}${one}${one}${one}</div>`;
    document.getElementById("barNote").textContent = tx("cardHint");
  }

  async function book() {
    const event = params.get("event") || "";
    const data = await (await fetch(`./api/book?event=${encodeURIComponent(event)}`, { cache: "no-store" })).json();
    const rows = data.entries || [];
    const title = data.event ? data.event.title : data.title;
    const sub = data.event ? day(new Date(data.event.started * 1000).toISOString().slice(0, 10)) : "";
    const pages = [`<section class="page title-page"><h1>${esc(title)}</h1><p>${esc([sub, tx("entries", { n: rows.length })].filter(Boolean).join(" · "))}</p></section>`];
    pages.push(`<section class="page">${rows.length ? rows.map((e) => `<article class="entry${e.photo ? "" : " nophoto"}">
      ${e.photo ? `<img src="./api/photo?id=${encodeURIComponent(e.id)}&s=f&admin=1" alt="">` : ""}
      <div>${e.text ? `<p class="hand">${esc(e.text)}</p>` : ""}<p class="who">${esc(e.name)}</p><p class="when">${esc(day(e.day))}</p></div></article>`).join("")
      : `<p class="empty">${esc(tx("empty"))}</p>`}</section>`);
    sheet.innerHTML = pages.join("");
    document.title = title;
  }

  (params.get("what") === "book" ? book() : card()).catch((error) => { sheet.textContent = String(error); });
})();
