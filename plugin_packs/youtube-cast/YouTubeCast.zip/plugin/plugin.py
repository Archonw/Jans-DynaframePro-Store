#!/usr/bin/env python3
"""YouTube Cast - der Plugin-Teil des Pakets.

Macht den Rahmen zu einem Ziel für den "Streamen"-Knopf der YouTube-App,
wie einen Smart-TV:

- Im selben WLAN findet die App den Rahmen von selbst (DIAL, dial.py).
- Mit "Mit TV-Code verknüpfen" geht es auch ohne das Finden.
- Die App steuert danach über den Lounge-Dienst von YouTube (lounge.py):
  Video, Pause, Spulen, Lautstärke, Warteschlange.
- Außerdem nimmt der Rahmen Links an: auf der Plugin-Seite, auf der
  Senden-Seite fürs Handy (http://<rahmen>:8090/) und von einem
  iPhone-Kurzbefehl im Teilen-Menü.

Abgespielt wird in der Szene "youtube-cast" mit dem eingebetteten Player
von YouTube. Das Plugin holt sie dafür über die laufende Playlist
(Display-Takeover) und gibt den Bildschirm zurück, wenn das Video zu Ende
ist oder gestoppt wird. Was gerade laufen soll, weiß nur das Plugin; die
Szene fragt jede halbe Sekunde nach und meldet zurück, wo der Player steht.
"""

import json
import os
import re
import secrets
import sys
import threading
import time
import queue
import uuid
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import dial  # noqa: E402
import lounge  # noqa: E402
import texts  # noqa: E402

try:
    # Umgeht einen Dynaframe-Fehler, der einen Quick Mix nach einem Takeover
    # gestoppt lassen kann (siehe dort). Ohne die Datei läuft alles weiter.
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None

plugin = create_plugin()

PLUGIN_ID = "YouTubeCast"
DISPLAY_NAME = "YouTube Cast"
SCENE_ID = "youtube-cast"           # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen und Zustand; bleibt bei Updates
# Senden-Seite und DIAL. Der erste freie Port gilt; 8090 steht in der Anleitung.
PHONE_PORTS = (8090, 8091, 8092, 8093)
TEST_VIDEO = "aqz-KE-bpKQ"          # Big Buck Bunny, vom Blender-Studio selbst hochgeladen

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        pass
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def as_float(value, default=0.0):
    try:
        number = float(str(value).strip())
    except (TypeError, ValueError):
        return default
    return number if number == number and abs(number) < 1e9 else default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=1, ensure_ascii=False)
    temp.replace(path)


def local_text(epoch):
    if not epoch:
        return ""
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Einstellungen (alle auf der Plugin-Seite; das Manifest deklariert keine)
# --------------------------------------------------------------------------

SETTINGS = {
    "Language":     {"kind": "choice", "default": "de", "options": list(texts.LANGUAGES)},
    # So heißt der Rahmen in der Liste der YouTube-App.
    "DeviceName":   {"kind": "name", "default": "DynaFrame"},
    # Einen ausgeschalteten Bildschirm einschalten, wenn ein Video kommt.
    "WakeScreen":   {"kind": "bool", "default": True},
    # Nach so vielen Minuten Pause geht der Bildschirm zurück an die Playlist.
    "PauseMinutes": {"kind": "number", "default": 10, "min": 1, "max": 240},
    # Mit Ton starten (sonst stumm; manche Rahmen erlauben Ton ohne Tippen nicht).
    "Sound":        {"kind": "bool", "default": True},
}

SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return default
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "number":
        return max(spec["min"], min(spec["max"], as_int(raw, default)))
    if kind == "choice":
        value = str(raw).strip().lower()
        return value if value in spec["options"] else default
    if kind == "name":
        value = re.sub(r"[\x00-\x1f<>&\"]", "", str(raw)).strip()[:40]
        return value or default
    return str(raw)[:200]


def settings():
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
    return {name: coerce(name, stored.get(name)) for name in SETTINGS}


def tr(template, **values):
    """Ein Text in der eingestellten Sprache (siehe texts.py)."""
    return texts.t(settings()["Language"], template, **values)


def save_settings(changes):
    changed = []
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            value = coerce(name, raw)
            if stored.get(name) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, stored)
    return changed


_state_lock = threading.Lock()


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**fields):
    with _state_lock:
        state = read_json(STATE_FILE, {}) or {}
        if all(k in state and state[k] == v for k, v in fields.items()):
            return state  # nichts Neues, also kein Schreiben auf die SD-Karte
        state.update(fields)
        write_json(STATE_FILE, state)
    return state


def stored(key, value=None):
    """Für lounge.py: einen Wert lesen oder (mit value) speichern."""
    if value is None:
        return load_state().get(key)
    save_state(**{key: value})
    return value


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "note": ""}


def find_scene():
    """Die installierte Szene. Ihre numerische id braucht ein Playlist-Eintrag."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else
                      tr("Die Szene YouTube Cast ist auf der Plugins-Seite ausgeschaltet."))
        return row
    _scene.update(dbId=None, note=tr("Die Szene YouTube Cast ist auf diesem Rahmen nicht installiert. "
                                     "Installiere das Paket noch einmal."))
    return None


# --------------------------------------------------------------------------
# Die Takeover-Playlist
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = "YouTube Cast (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Wird vom Plugin YouTube Cast abgespielt, wenn ein Video auf den Rahmen "
                                 "gestreamt wird. Bleibt ausgeschaltet, damit es nicht im Quick Mix landet. "
                                 "Das Plugin legt sie neu an, wenn sie gelöscht wird.")
TAKEOVER_ITEM_SECONDS = 12 * 3600  # das Plugin beendet die Anzeige lange vorher

_playlists = {"at": 0.0, "takeoverId": None, "note": ""}
_playlist_lock = threading.Lock()


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    """Hat irgendetwas den Bildschirm? Die Playlist wird nur angelegt, solange
    nichts ihn hält: der Rahmen baut den Quick Mix nach einem Takeover neu,
    und eine inzwischen angelegte Playlist ändert, was er wiederherstellt."""
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError:
        return False
    return bool(status.get("active"))


def ensure_takeover_playlist():
    """Ein Takeover spielt eine Playlist, keine einzelne Szene. Also: die
    Szene allein, zwölf Stunden, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if i.get("dynamicSceneId") == _scene["dbId"]]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_PLAYLIST_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=TAKEOVER_PLAYLIST_NAME))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    plugin.log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def maintain_playlists(force=False):
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        find_scene()
        if _scene["dbId"] is None:
            _playlists["note"] = _scene["note"]
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc)
            plugin.log(_playlists["note"], level="warning")


# --------------------------------------------------------------------------
# Der Player: was laufen soll und wo er steht
# --------------------------------------------------------------------------

IDLE, PLAYING, PAUSED, LOADING, STOPPED = lounge.IDLE, lounge.PLAYING, lounge.PAUSED, lounge.LOADING, lounge.STOPPED
STATUS_NAMES = {IDLE: "idle", PLAYING: "playing", PAUSED: "paused", LOADING: "loading", STOPPED: "stopped"}
VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")

_player_lock = threading.RLock()
_player = {
    "videoId": "", "title": "", "author": "",
    "status": IDLE, "position": 0.0, "positionAt": 0.0, "duration": 0.0,
    "volume": 100, "muted": False, "cpn": "",
    "queue": [], "index": 0, "listId": "", "ctt": "", "params": "",
    "seq": 0,          # neues Video: die Szene lädt es neu
    "desired": "stop",  # play, pause, stop
    "seekSeq": 0, "seekTo": 0.0, "volSeq": 0,
    "source": "", "sender": "", "error": "", "blocked": False,
    "pausedSince": 0.0, "endedAt": 0.0, "sceneAt": 0.0, "startedAt": 0.0,
}
_recent = []           # die letzten Videos für die Seite


def position_now(p=None):
    p = p or _player
    if p["status"] == PLAYING and p["positionAt"]:
        moved = p["position"] + (now() - p["positionAt"])
        return min(moved, p["duration"]) if p["duration"] else moved
    return p["position"]


def _remember(video_id, title=""):
    for row in _recent:
        if row["videoId"] == video_id:
            if title:
                row["title"] = title
            return
    _recent.insert(0, {"videoId": video_id, "title": title, "at": local_text(now())})
    del _recent[8:]


def load_video(video_id, start=0.0, source="link", sender="", queue_ids=None, index=None, list_id="",
               ctt="", params=""):
    """Ein Video auf den Rahmen. Holt den Bildschirm, falls nötig."""
    if not VIDEO_ID.match(video_id or ""):
        return False
    with _player_lock:
        _player.update(videoId=video_id, title="", author="", status=LOADING, position=max(0.0, float(start)),
                       positionAt=now(), duration=0.0, cpn=secrets.token_urlsafe(12)[:16],
                       seq=_player["seq"] + 1, desired="play", source=source, sender=sender, error="",
                       blocked=False, pausedSince=0.0, endedAt=0.0, startedAt=now())
        if queue_ids is not None:
            _player["queue"] = list(queue_ids)
            _player["index"] = index if index is not None else (queue_ids.index(video_id)
                                                               if video_id in queue_ids else 0)
            _player["listId"], _player["ctt"], _player["params"] = list_id, ctt, params
        elif source != "cast":
            _player.update(queue=[video_id], index=0, listId="", ctt="", params="")
        _remember(video_id)
    plugin.log(f"Video {video_id} ab {int(start)} s ({source}{', ' + sender if sender else ''}).")
    _wake.set()
    return True


def stop_video(reason="gestoppt", tell_app=True):
    with _player_lock:
        if _player["desired"] == "stop" and _player["status"] in (IDLE, STOPPED):
            return
        _player.update(desired="stop", status=STOPPED, position=position_now(), positionAt=now(),
                       endedAt=now(), pausedSince=0.0)
    plugin.log(f"Wiedergabe beendet ({reason}).")
    if tell_app:
        send_state()
    _wake.set()


def set_paused(paused):
    with _player_lock:
        if not _player["videoId"] or _player["desired"] == "stop":
            return False
        _player["desired"] = "pause" if paused else "play"
        if paused and not _player["pausedSince"]:
            _player["pausedSince"] = now()
        if not paused:
            _player["pausedSince"] = 0.0
    _wake.set()
    return True


def seek(seconds):
    with _player_lock:
        if not _player["videoId"]:
            return False
        seconds = max(0.0, float(seconds))
        if _player["duration"]:
            seconds = min(seconds, max(0.0, _player["duration"] - 1))
        _player.update(seekSeq=_player["seekSeq"] + 1, seekTo=seconds, position=seconds, positionAt=now())
    return True


def set_volume(level, muted):
    with _player_lock:
        _player.update(volume=max(0, min(100, int(level))), muted=bool(muted), volSeq=_player["volSeq"] + 1)
    send([("onVolumeChanged", volume_payload())])


def step(delta):
    """Nächstes oder vorheriges Video der Warteschlange."""
    with _player_lock:
        ids, index = _player["queue"], _player["index"] + delta
        if not (0 <= index < len(ids)):
            return False
        target = ids[index]
        source, sender = _player["source"], _player["sender"]
        list_id, ctt, params = _player["listId"], _player["ctt"], _player["params"]
    return load_video(target, 0, source, sender, ids, index, list_id, ctt, params)


def nav_info():
    with _player_lock:
        return {"hasPrevious": _player["index"] > 0 and bool(_player["queue"]),
                "hasNext": _player["index"] + 1 < len(_player["queue"])}


# --------------------------------------------------------------------------
# Rückmeldungen an die YouTube-App
# --------------------------------------------------------------------------

_outbox = queue.Queue()
_lounge = None
_senders = {}          # deviceId -> Name, wer gerade mit der App verbunden ist


def send(messages, aid=None):
    if _lounge is not None and _lounge.status == "ready" and _senders:
        _outbox.put((messages, aid))


def outbox_loop():
    while not _stop_requested.is_set():
        try:
            messages, aid = _outbox.get(timeout=2)
        except queue.Empty:
            continue
        try:
            if _lounge is not None:
                _lounge.send(messages, aid)
        except lounge.LoungeError as exc:
            plugin.log(f"Rückmeldung an die YouTube-App: {exc}", level="warning")


def volume_payload():
    with _player_lock:
        return {"volume": _player["volume"], "muted": _player["muted"]}


def state_message():
    with _player_lock:
        p = dict(_player)
    duration = p["duration"]
    return {"state": p["status"], "currentTime": round(position_now(p), 3), "duration": duration,
            "loadedTime": duration if p["status"] in (PLAYING, PAUSED, LOADING) else 0,
            "seekableStartTime": 0, "seekableEndTime": duration, "cpn": p["cpn"]}


def now_playing_message():
    with _player_lock:
        p = dict(_player)
    if not p["videoId"] or p["status"] in (IDLE,) or p["source"] != "cast" and not p["queue"]:
        return {}
    payload = state_message()
    payload["videoId"] = p["videoId"]
    if p["listId"]:
        payload["listId"] = p["listId"]
        payload["currentIndex"] = p["index"]
    if p["ctt"]:
        payload["ctt"] = p["ctt"]
    if p["params"]:
        payload["params"] = p["params"]
    return payload


def send_state(now_playing=False):
    messages = [("onStateChange", state_message())]
    if now_playing:
        messages += [("nowPlaying", now_playing_message()), ("onHasPreviousNextChanged", nav_info())]
    send(messages)


def on_lounge_message(name, payload, aid):
    """Ein Befehl aus der YouTube-App."""
    data = payload if isinstance(payload, dict) else {}
    if name == "loungeStatus":
        handle_lounge_status(data, aid)
    elif name == "getNowPlaying":
        send([("nowPlaying", now_playing_message())], aid)
    elif name == "setPlaylist":
        video_id = str(data.get("videoId") or "")
        ids = [v for v in str(data.get("videoIds") or video_id).split(",") if VIDEO_ID.match(v)]
        index = as_int(data.get("currentIndex"), ids.index(video_id) if video_id in ids else 0)
        sender = next(iter(_senders.values()), "")
        send([("autoplayUpNext", {})], aid)
        if load_video(video_id, as_float(data.get("currentTime")), "cast", sender, ids or [video_id], index,
                      str(data.get("listId") or ""), str(data.get("ctt") or ""), str(data.get("params") or "")):
            send([("nowPlaying", now_playing_message()), ("onStateChange", state_message()),
                  ("onHasPreviousNextChanged", nav_info())], aid)
    elif name == "updatePlaylist":
        ids = [v for v in str(data.get("videoIds") or "").split(",") if VIDEO_ID.match(v)]
        with _player_lock:
            current = _player["videoId"]
            _player["queue"] = ids
            _player["listId"] = str(data.get("listId") or "")
            if current in ids:
                _player["index"] = ids.index(current)
        if current and current not in ids:
            stop_video("Warteschlange geleert")
        else:
            send([("onHasPreviousNextChanged", nav_info())], aid)
    elif name == "play":
        set_paused(False)
    elif name == "pause":
        set_paused(True)
    elif name == "stopVideo":
        stop_video("in der YouTube-App gestoppt")
    elif name == "seekTo":
        if seek(as_float(data.get("newTime"))):
            send([("onStateChange", state_message())], aid)
    elif name == "setVolume":
        set_volume(as_int(data.get("volume"), _player["volume"]), as_bool(data.get("muted"), False))
    elif name == "getVolume":
        send([("onVolumeChanged", volume_payload())], aid)
    elif name == "next":
        step(1)
    elif name == "previous":
        step(-1)
    elif name == "setAutoplayMode":
        send([("onAutoplayModeChanged", {"autoplayMode": "UNSUPPORTED"})], aid)


def handle_lounge_status(data, aid):
    try:
        devices = json.loads(data.get("devices") or "[]")
    except ValueError:
        devices = []
    remotes = {}
    for device in devices if isinstance(devices, list) else []:
        if isinstance(device, dict) and device.get("type") == "REMOTE_CONTROL" and device.get("id"):
            info = device.get("deviceInfo")
            try:
                info = json.loads(info) if isinstance(info, str) else (info or {})
            except ValueError:
                info = {}
            label = device.get("name") or info.get("clientName") or "YouTube"
            user = device.get("user") or ""
            remotes[str(device["id"])] = f"{label} ({user})" if user else str(label)
    try:
        event = json.loads(data.get("connectionEventDetails") or "null") or {}
    except ValueError:
        event = {}
    before = set(_senders)
    _senders.clear()
    _senders.update(remotes)
    joined = set(remotes) - before
    if joined:
        plugin.log("YouTube-App verbunden: " + ", ".join(remotes[d] for d in joined))
        send([("onHasPreviousNextChanged", nav_info()), ("onAutoplayModeChanged", {"autoplayMode": "UNSUPPORTED"}),
              ("nowPlaying", now_playing_message()), ("onStateChange", state_message()),
              ("onVolumeChanged", volume_payload())], aid)
    left = before - set(remotes)
    if left:
        plugin.log("YouTube-App getrennt.")
        # Nur ein ausdrückliches "Trennen" in der App stoppt das Video; sperrt
        # jemand bloß das Handy, läuft es weiter.
        with _player_lock:
            casting = _player["source"] == "cast" and _player["desired"] != "stop"
        if casting and not remotes and str(event.get("ui", "")).lower() == "true":
            stop_video("in der YouTube-App getrennt", tell_app=False)


def lounge_status_changed(status, error):
    if status == "ready":
        _wake.set()


def on_dial_launch(body):
    """Die App hat den Rahmen im WLAN ausgewählt und schickt ihren Code."""
    values = dial.parse_launch(body)
    code = values.get("pairingCode") or ""
    theme = values.get("theme") or "cl"
    if not code:
        plugin.log("DIAL-Start ohne Kopplungscode.", level="warning")
        return False
    if theme != "cl":
        plugin.log("YouTube Music kann (noch) nicht auf den Rahmen streamen.", level="warning")
        return False
    if _lounge is None or not _lounge.screen_id:
        return False
    try:
        _lounge.register_pairing_code(code)
    except lounge.LoungeError as exc:
        plugin.log(f"Kopplung mit der YouTube-App fehlgeschlagen: {exc}", level="warning")
        return False
    plugin.log("YouTube-App im WLAN gekoppelt.")
    return True


# --------------------------------------------------------------------------
# Links (Seite, Senden-Seite, Kurzbefehl)
# --------------------------------------------------------------------------

URL_IN_TEXT = re.compile(r"https?://\S+|(?:www\.|m\.|music\.)?youtu(?:\.be|be\.com)/\S+", re.I)


def parse_time(value):
    """t=90, t=1m30s, t=1h2m3s, start=90 -> Sekunden."""
    value = str(value or "").strip().lower()
    if not value:
        return 0.0
    if re.fullmatch(r"\d+(\.\d+)?s?", value):
        return float(value.rstrip("s"))
    total, found = 0.0, False
    for amount, unit in re.findall(r"(\d+)\s*([hms])", value):
        total += int(amount) * {"h": 3600, "m": 60, "s": 1}[unit]
        found = True
    return total if found else 0.0


def parse_link(text):
    """(videoId, Startsekunde) aus einem Link oder einem geteilten Text, sonst (None, 0)."""
    text = str(text or "").strip()
    if VIDEO_ID.match(text):
        return text, 0.0
    candidates = URL_IN_TEXT.findall(text) or [text]
    for raw in candidates:
        raw = raw.rstrip(").,;!?\"'»“”")
        if not re.match(r"https?://", raw, re.I):
            raw = "https://" + raw
        parsed = urlparse(raw)
        host = (parsed.hostname or "").lower()
        query = parse_qs(parsed.query)
        start = parse_time((query.get("t") or query.get("start") or [""])[0])
        if not start and parsed.fragment.startswith("t="):
            start = parse_time(parsed.fragment[2:])
        video_id = ""
        if host.endswith("youtu.be"):
            video_id = parsed.path.strip("/").split("/")[0]
        elif host.endswith("youtube.com") or host.endswith("youtube-nocookie.com"):
            if query.get("v"):
                video_id = query["v"][0]
            else:
                parts = [p for p in parsed.path.split("/") if p]
                if len(parts) >= 2 and parts[0] in ("shorts", "live", "embed", "v", "e"):
                    video_id = parts[1]
        if VIDEO_ID.match(video_id or ""):
            return video_id, start or 0.0
    return None, 0.0


def play_link(text, sender=""):
    video_id, start = parse_link(text)
    if not video_id:
        return {"success": False, "error": tr("Das ist kein YouTube-Link zu einem Video.")}
    load_video(video_id, start, "link", sender)
    send_state(now_playing=True)
    return {"success": True, "videoId": video_id,
            "message": tr("Läuft gleich auf dem Rahmen.")}


# --------------------------------------------------------------------------
# Was die Szene meldet
# --------------------------------------------------------------------------

SCENE_STATES = {"playing": PLAYING, "paused": PAUSED, "buffering": LOADING, "unstarted": LOADING,
                "cued": LOADING, "loading": LOADING}


def scene_report(body):
    """Die Szene meldet jede Sekunde und bei jeder Änderung, wo der Player steht."""
    if not isinstance(body, dict):
        return
    with _player_lock:
        _player["sceneAt"] = now()
        if as_int(body.get("seq"), -1) != _player["seq"] or body.get("videoId") != _player["videoId"]:
            return  # gehört zu einem älteren Video
        if _player["desired"] == "stop":
            return
        state = str(body.get("state") or "")
        before = _player["status"]
        if body.get("title"):
            _player["title"] = str(body["title"])[:200]
            _remember(_player["videoId"], _player["title"])
        if body.get("author"):
            _player["author"] = str(body["author"])[:120]
        duration = as_float(body.get("duration"))
        if duration > 0:
            _player["duration"] = duration
        if "time" in body:
            _player["position"] = max(0.0, as_float(body.get("time")))
            _player["positionAt"] = now()
        _player["blocked"] = as_bool(body.get("blocked"))
        if state == "ended":
            ended = True
        elif state == "error":
            _player["error"] = str(body.get("error") or "")
            ended = True
        else:
            ended = False
            new = SCENE_STATES.get(state)
            if new is not None:
                _player["status"] = new
                if new == PAUSED and not _player["pausedSince"]:
                    _player["pausedSince"] = now()
                if new == PLAYING:
                    _player["pausedSince"] = 0.0
        changed = _player["status"] != before
        first_play = changed and _player["status"] == PLAYING and before == LOADING
    if ended:
        error = _player["error"]
        if error:
            plugin.log(f"Der Player meldet Fehler {error} für {_player['videoId']}.", level="warning")
        if not step(1):
            stop_video("Ende" if not error else f"Fehler {error}")
        else:
            send_state(now_playing=True)
        return
    if changed:
        send_state(now_playing=first_play)


def scene_payload():
    values = settings()
    with _player_lock:
        p = dict(_player)
    showing = p["desired"] != "stop"
    return {
        "at": now(), "lang": values["Language"], "name": values["DeviceName"],
        "showing": showing, "seq": p["seq"], "videoId": p["videoId"] if showing else "",
        "position": round(position_now(p), 2), "desired": p["desired"],
        "seekSeq": p["seekSeq"], "seekTo": p["seekTo"],
        "volSeq": p["volSeq"], "volume": p["volume"], "muted": p["muted"] or not values["Sound"],
        "title": p["title"], "sender": p["sender"], "source": p["source"],
        "phoneUrl": _dial.url() if _dial else "",
    }


# --------------------------------------------------------------------------
# Den Bildschirm übernehmen und zurückgeben
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
# So lange am Stück; ein längeres Video holt den Bildschirm danach neu (die
# Szene lädt dann neu und macht an derselben Stelle weiter).
SESSION_SECONDS = (4 * 3600, 3600)
END_GRACE_SECONDS = 4  # nach dem Ende kurz stehen lassen, dann zurück

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "since": None, "limit": 0, "token": 0, "note": "", "retryAt": 0.0, "busy": False}
_stop_requested = threading.Event()
_wake = threading.Event()


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform") or {}
    except EngineError:
        return True  # nicht entscheidbar: der Versuch selbst sagt es dann
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("YouTube Cast ist auf der Plugins-Seite ausgeschaltet.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für YouTube Cast auf der Plugins-Seite aus. Schalte es ein, "
                  "sonst kann kein Video gezeigt werden.")
    return ""


def display_is_off():
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        plugin.log(text)
    return False


def _on_session_state(handle_or_state):
    """Das SDK ruft das mit dem Handle auf, nicht mit dem neuen Zustand."""
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _takeover.update(handle=None, since=None)
        renewing = new_state == "expired"
    plugin.log(f"Der Rahmen hat YouTube Cast beendet: {new_state}.")
    if not renewing:
        # Jemand anderes hat den Bildschirm genommen oder ihn zurückgeholt:
        # das Video ist damit vorbei.
        stop_video(f"Bildschirm {new_state}")
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    _wake.set()


def end_takeover(reason, token=None):
    """Bildschirm zurückgeben. Mehrfach aufrufbar."""
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        _takeover.update(handle=None, since=None)
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:
        plugin.log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", level="warning")
    plugin.log(f"Bildschirm zurückgegeben ({reason}).")
    if reason not in ("gestoppt", "neu"):
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def show_scene():
    """Die Szene über alles legen. True, wenn der Rahmen den Bildschirm hergegeben hat."""
    if not takeover_supported():
        return _note(tr("Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen."))
    if _scene["dbId"] is None:
        find_scene()
    if _scene["dbId"] is None or _scene["note"]:
        return _note(_scene["note"] or tr("Die Szene YouTube Cast wurde nicht gefunden."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("Die Takeover-Playlist ist noch nicht angelegt."))
    wake = settings()["WakeScreen"]
    if not wake and display_is_off():
        return _note(tr("Der Bildschirm ist aus; das Video wird nicht gezeigt."))
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             # Der Player hat seine eigene Anzeige; eine Bildunterschrift stört nur.
             "overlay": {"enabled": False}}
    handle, limit, last_error = None, 0, None
    for seconds in SESSION_SECONDS:
        try:
            _leftover["askedAt"] = time.time()
            handle = plugin.acquire_display_session(
                session_key="video", state=state, display_name=DISPLAY_NAME,
                max_duration_seconds=seconds, wake_if_off=wake)
            limit = seconds
            break
        except Exception as exc:  # manche Rahmen erlauben nur kürzere Sitzungen
            last_error = exc
    if handle is None:
        if last_error is not None:
            return _note(tr("Konnte das Video nicht anzeigen: {exc}", exc=last_error))
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, since=now(), limit=limit, note="")
    try:
        handle.on_state_change(_on_session_state)
    except Exception:
        pass
    try:
        if not handle.wait_until_active(timeout=15):
            end_takeover("fehlgeschlagen", token)
            return _note(tr("Der Rahmen hat das Video nicht rechtzeitig angezeigt."))
    except Exception as exc:
        end_takeover("fehlgeschlagen", token)
        return _note(tr("Konnte das Video nicht anzeigen: {exc}", exc=exc))
    plugin.log("YouTube Cast hat den Bildschirm.")
    return True


def decide_takeover():
    """Soll ein Video laufen und hat das Plugin den Bildschirm nicht: holen.
    Ist es vorbei: zurückgeben."""
    t = now()
    values = settings()
    with _player_lock:
        desired, status = _player["desired"], _player["status"]
        paused_since, ended_at = _player["pausedSince"], _player["endedAt"]
    if desired == "pause" and paused_since and t - paused_since > values["PauseMinutes"] * 60:
        stop_video(f"{values['PauseMinutes']} Minuten Pause")
        desired = "stop"
    with _takeover_lock:
        handle, since, limit = _takeover["handle"], _takeover["since"], _takeover["limit"]
        retry_at, busy = _takeover["retryAt"], _takeover["busy"]
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        if desired == "stop":
            if t - (ended_at or t) >= END_GRACE_SECONDS or status == IDLE:
                end_takeover("fertig")
        elif since and limit and t - since >= limit - 20:
            end_takeover("neu")   # gleich wieder holen, frisch mit voller Zeit
            _wake.set()
        return
    if desired == "stop" or t < retry_at or busy:
        return
    with _takeover_lock:
        _takeover["busy"] = True
    try:
        if not show_scene():
            # Nicht bekommen: in 20 Sekunden noch einmal, solange das Video laufen soll.
            with _takeover_lock:
                _takeover["retryAt"] = t + 20
    finally:
        with _takeover_lock:
            _takeover["busy"] = False


# ---- Takeover-Playlist, die nach dem Zurückgeben weiterläuft ---------------
# Lief vor einem Takeover keine Playlist, stellt die Engine dieses "nichts"
# nicht wieder her, und die Takeover-Playlist läuft einfach weiter (Jans
# Rahmen, 2026-10-24). Jeder Durchlauf hält sie dann mit POST /slideshow/stop
# an: nur wenn sie läuft, niemand den Bildschirm hält und das Plugin nicht
# gerade selbst darum gebeten hat.
_leftover = {"askedAt": 0.0, "failed": False}


def stop_leftover_takeover():
    try:
        playlist_id = _playlists["takeoverId"]
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status", read_timeout=5) or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status", read_timeout=5) or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop", read_timeout=10)
    except Exception as exc:  # noqa: BLE001 - darf die Schleife nie aufhalten
        if not _leftover["failed"]:
            plugin.log(f"The takeover playlist kept running and could not be stopped: {exc}", level="warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    plugin.log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def check_playback_resumed():
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log,
                                                    stop_event=_stop_requested)
        if outcome == "not-requested":
            save_state(playbackStalled="")
            return
    elif _stop_requested.wait(12):
        return
    if _stop_requested.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
    except EngineError:
        return
    if status.get("isRunning") or _takeover["handle"] is not None:
        save_state(playbackStalled="")
        return
    message = tr("Der Rahmen ist nach dem Video nicht zu deiner Playlist zurückgekehrt. Starte sie auf "
                 "der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix "
                 "passiert das nicht.")
    save_state(playbackStalled=message)
    plugin.log(message, level="warning")


# --------------------------------------------------------------------------
# Die Schleife
# --------------------------------------------------------------------------

_loop = {"lastError": "", "heartbeat": 0.0}


def tick():
    try:
        stop_leftover_takeover()
        maintain_playlists()
        decide_takeover()
        # Während ein Video läuft, alle 10 Sekunden die Stelle an die App: so
        # bleibt ihre Zeitleiste genau.
        with _player_lock:
            playing = _player["status"] == PLAYING and _player["desired"] == "play"
        if playing and now() - _loop["heartbeat"] > 10:
            _loop["heartbeat"] = now()
            send([("onStateChange", state_message())])
        _loop["lastError"] = ""
    except Exception as exc:  # pragma: no cover - die Schleife muss weiterlaufen
        _loop["lastError"] = str(exc)
        plugin.log(f"Durchlauf fehlgeschlagen: {exc}", level="error")


def main_loop():
    _stop_requested.wait(1)
    while not _stop_requested.is_set():
        _wake.clear()
        tick()
        busy = _takeover["handle"] is not None or _player["desired"] != "stop"
        _wake.wait(1 if busy else 5)


# --------------------------------------------------------------------------
# Die Seite (auf dem Rahmen und als Senden-Seite fürs Handy) und ihre API
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored_theme = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored_theme, dict):
        return ""
    value = next((str(v) for k, v in stored_theme.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html(phone=False):
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    if phone:
        # Auf dem Handy nur Senden und Fernbedienung; das Einrichten bleibt auf dem Rahmen.
        return html.replace("<html", '<html data-phone="1"', 1)
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
    "/icon.png": ("icon.png", "image/png"),
}

LOUNGE_TEXT = {
    "off": "Aus.", "connecting": "Melde den Rahmen bei YouTube an …",
    "ready": "Bereit: der Rahmen steht im Streamen-Menü der YouTube-App.",
}

_pairing = {"code": "", "at": 0.0}


def pairing_payload(fresh=False):
    if _lounge is None:
        return {"success": False, "error": tr("Noch nicht bei YouTube angemeldet.")}
    if not fresh and _pairing["code"] and now() - _pairing["at"] < 240:
        code = _pairing["code"]
    else:
        try:
            code = _lounge.pairing_code()
        except lounge.LoungeError as exc:
            return {"success": False, "error": tr("Kein TV-Code: {exc}", exc=exc)}
        _pairing.update(code=code, at=now())
    pretty = " ".join(code[i:i + 3] for i in range(0, len(code), 3))
    return {"success": True, "code": pretty}


def state_payload():
    values = settings()
    with _player_lock:
        p = dict(_player)
        recent = list(_recent)
    with _takeover_lock:
        showing = _takeover["handle"] is not None
        note = _takeover["note"]
    status = _lounge.status if _lounge else "off"
    lounge_text = tr(LOUNGE_TEXT.get(status, "")) if status != "error" else \
        tr("Keine Verbindung zu YouTube: {exc}", exc=_lounge.error if _lounge else "")
    return {
        "success": True,
        "version": version(),
        "settings": values,
        "player": {"videoId": p["videoId"] if p["desired"] != "stop" else "", "title": p["title"],
                   "author": p["author"], "status": STATUS_NAMES.get(p["status"], "idle"),
                   "desired": p["desired"], "position": round(position_now(p), 1), "duration": p["duration"],
                   "volume": p["volume"], "muted": p["muted"], "source": p["source"], "sender": p["sender"],
                   "error": p["error"], "blocked": p["blocked"],
                   "sceneSeen": bool(p["sceneAt"] and now() - p["sceneAt"] < 5),
                   "hasNext": nav_info()["hasNext"]},
        "showing": showing,
        "cast": {"state": status, "text": lounge_text, "senders": list(_senders.values()),
                 "wifi": bool(_dial and _dial.ssdp_ok), "wifiError": _dial.ssdp_error if _dial else ""},
        "phoneUrl": _dial.url() if _dial else "",
        "note": note or _playlists["note"] or _scene["note"],
        "permission": takeover_permission_note(),
        "recent": recent,
        "lastError": _loop["lastError"] or load_state().get("playbackStalled") or "",
        "theme": {"id": theme_id()},
    }


def settings_saved(changed):
    if "DeviceName" in changed:
        name = settings()["DeviceName"]
        if _dial:
            _dial.rename(name)
        if _lounge:
            _lounge.restart(name)
        _pairing.update(code="", at=0.0)
    _wake.set()


def control(body):
    action = str(body.get("action") or "")
    if action == "pause":
        ok = set_paused(True)
    elif action == "play":
        ok = set_paused(False)
    elif action == "stop":
        stop_video("auf der Seite gestoppt")
        ok = True
    elif action == "seek":
        ok = seek(as_float(body.get("to")))
        send_state()
    elif action == "skip":
        ok = seek(position_now() + as_float(body.get("by")))
        send_state()
    elif action == "volume":
        set_volume(as_int(body.get("volume"), _player["volume"]), as_bool(body.get("muted"), False))
        ok = True
    elif action == "next":
        ok = step(1)
    elif action == "test":
        ok = load_video(TEST_VIDEO, 0, "link", tr("Probe"))
    else:
        return {"success": False, "error": "Unbekannt"}
    return {"success": bool(ok)}


def sent_page(result):
    """Antwort auf /send aus dem Browser: kurz und lesbar."""
    ok = result.get("success")
    text = result.get("message") if ok else result.get("error")
    color = "#3fb950" if ok else "#f85149"
    body = (f'<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" '
            f'content="width=device-width, initial-scale=1"><title>YouTube Cast</title></head>'
            f'<body style="font:18px system-ui;background:#0d1117;color:#e6edf3;display:grid;'
            f'place-items:center;min-height:90vh;text-align:center"><div><p style="font-size:44px;color:{color};'
            f'margin:0">{"&#10003;" if ok else "&#10007;"}</p><p>{text}</p><p><a style="color:#58a6ff" '
            f'href="/">YouTube Cast</a></p></div></body></html>')
    return body.encode("utf-8")


def api(method, path, query, body, phone=False):
    """Gemeinsame Antworten für die Plugin-Seite (127.0.0.1) und die
    Senden-Seite (Port 8090). (status, content_type, bytes) oder None."""
    def js(payload, status=200):
        return status, "application/json; charset=utf-8", json.dumps(payload, ensure_ascii=False).encode("utf-8")

    if method == "GET":
        if path in ("/", "/index.html"):
            text = (query.get("url") or query.get("text") or [""])[0]
            if text:
                return 200, "text/html; charset=utf-8", sent_page(play_link(text, tr("Handy")))
            return 200, "text/html; charset=utf-8", page_html(phone).encode("utf-8")
        asset = STUDIO_FILES.get(path)
        if asset:
            content_type = asset[1]
            return 200, content_type, (PLUGIN_DIR / asset[0]).read_bytes()
        if path == "/api/state":
            return js(state_payload())
        if path == "/api/scene":
            return js(scene_payload())
        if path == "/api/pairing":
            return js(pairing_payload(fresh=bool(query.get("fresh"))))
        if path in ("/send", "/api/send", "/api/play"):
            text = (query.get("url") or query.get("text") or query.get("v") or [""])[0]
            result = play_link(text, tr("Handy"))
            if path == "/send":
                return (200 if result["success"] else 400), "text/html; charset=utf-8", sent_page(result)
            return js(result, 200 if result["success"] else 400)
        return None

    if method == "POST":
        data = {}
        if body:
            try:
                data = json.loads(body)
            except ValueError:
                # Formular, oder die Szene schickt text/plain mit JSON darin
                data = {k: v[0] for k, v in parse_qs(body).items() if v}
        if not isinstance(data, dict):
            data = {}
        if path == "/api/report":
            scene_report(data)
            return js({"success": True})
        if path in ("/send", "/api/send", "/api/play"):
            text = data.get("url") or data.get("text") or data.get("v") or \
                (query.get("url") or [""])[0] or (body if not data and len(body) < 2000 else "")
            result = play_link(text, tr("Handy"))
            return js(result, 200 if result["success"] else 400)
        if path == "/api/control":
            return js(control(data))
        if path == "/api/settings" and not phone:
            changed = save_settings(data)
            if changed:
                settings_saved(changed)
            return js({"success": True, "changed": changed})
        return None
    return None


def dial_routes(handler, method, path, query, body):
    return api(method, path, query, body, phone=True)


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        # Die Szene kommt vom Port der Engine, diese Seite über :8003.
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        length = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(length).decode("utf-8", "replace") if 0 < length < 65536 else ""

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _route(self, method):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        body = self._body() if method == "POST" else ""
        try:
            answer = api(method, path, parse_qs(parsed.query), body)
        except OSError as exc:
            answer = (500, "application/json", json.dumps(
                {"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}).encode("utf-8"))
        except Exception as exc:  # pragma: no cover
            answer = (500, "application/json", json.dumps({"success": False, "error": str(exc)}).encode("utf-8"))
        if answer is None:
            answer = (404, "application/json", b'{"success": false, "error": "Nicht gefunden"}')
        self._send(answer[2], answer[1], answer[0])

    def do_GET(self):
        self._route("GET")

    def do_POST(self):
        self._route("POST")


studio_server = None
_dial = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    studio_server.daemon_threads = True
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin-Seite unter {url}")
    return url


def start_cast():
    """DIAL, Senden-Seite und die Anmeldung bei YouTube."""
    global _dial, _lounge
    state = load_state()
    dial_uuid = state.get("dialUuid") or str(uuid.uuid4())
    app_pid = state.get("dialPid") or str(uuid.uuid4())
    save_state(dialUuid=dial_uuid, dialPid=app_pid)
    name = settings()["DeviceName"]
    _dial = dial.DialServer(name, dial_uuid, PHONE_PORTS, on_dial_launch, dial_routes,
                            lambda text, level="info": plugin.log(text, level=level), app_pid)
    if _dial.start():
        plugin.log(f"Senden-Seite fürs Handy: {_dial.url()}")
    _lounge = lounge.Lounge(name, stored, lambda text, level="info": plugin.log(text, level=level),
                            on_lounge_message, lounge_status_changed)
    _lounge.start()


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    plugin.log(f"Starte {PLUGIN_ID} {version()}")

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("test", lambda _context=None: control({"action": "test"}))
    plugin.on_action("stop", lambda _context=None: control({"action": "stop"}))

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    threading.Thread(target=outbox_loop, name=f"{PLUGIN_ID}-outbox", daemon=True).start()
    start_cast()
    threading.Thread(target=main_loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    try:
        while not _stop_requested.is_set() and getattr(plugin, "is_running", lambda: True)():
            _stop_requested.wait(5)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    with _player_lock:
        _player["desired"] = "stop"
    end_takeover("gestoppt")
    for part in (_lounge, _dial):
        if part is not None:
            try:
                part.stop()
            except Exception:
                pass
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    plugin.log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
