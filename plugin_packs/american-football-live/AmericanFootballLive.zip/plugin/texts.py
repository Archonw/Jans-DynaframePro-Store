"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

import re

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Die Szene American Football Live ist auf der Plugins-Seite ausgeschaltet.": (
        "The American Football Live scene is switched off on the Plugins page.",
        "La escena American Football Live está desactivada en la página de plugins."),
    "Die Szene American Football Live ist auf diesem Rahmen nicht installiert. Installiere das American-Football-Live-Paket noch einmal.": (
        "The American Football Live scene is not installed on this frame. Install the American Football Live package again.",
        "La escena American Football Live no está instalada en este marco. Vuelve a instalar el paquete American Football Live."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.",
        "El marco no ha creado la lista {name}."),
    "Wartet, bis der Bildschirm wieder frei ist.": (
        "Waiting until the screen is free again.",
        "Esperando a que la pantalla vuelva a estar libre."),
    "Konnte die Takeover-Playlist nicht anlegen: {exc}": (
        "Could not create the takeover playlist: {exc}",
        "No se pudo crear la lista de takeover: {exc}"),
    "Konnte die Playlist American Football Live nicht pflegen: {exc}": (
        "Could not maintain the American Football Live playlist: {exc}",
        "No se pudo mantener la lista American Football Live: {exc}"),
    "Angelegt: die Playlist American Football Live steht unter Playlists.": (
        "Created: the American Football Live playlist is listed under Playlists.",
        "Creada: la lista American Football Live aparece en Playlists."),
    "Noch nicht angelegt; das passiert innerhalb einer Minute.": (
        "Not created yet; this happens within a minute.",
        "Todavía no creada; se creará en menos de un minuto."),
    "Die Playlist wurde gelöscht, deshalb steht das wieder auf Nein.": (
        "The playlist was deleted, so this is set back to No.",
        "La lista se ha borrado, por eso vuelve a estar en No."),
    "Die früher angelegte Playlist steht noch unter Playlists; das Plugin pflegt sie nicht mehr.": (
        "The playlist created earlier is still under Playlists; the plugin no longer maintains it.",
        "La lista creada antes sigue en Playlists; el plugin ya no la mantiene."),
    "American Football Live ist auf der Plugins-Seite ausgeschaltet.": (
        "American Football Live is switched off on the Plugins page.",
        "American Football Live está desactivado en la página de plugins."),
    "„Allow takeover“ ist für American Football Live auf der Plugins-Seite aus, deshalb kann es den Bildschirm nicht übernehmen.": (
        "“Allow takeover” is off for American Football Live on the Plugins page, so it cannot take over the screen.",
        "«Allow takeover» está desactivado para American Football Live en la página de plugins, así que no puede ocupar la pantalla."),
    "Der Rahmen hat die Anzeige beendet ({state}).": (
        "The frame ended the display ({state}).",
        "El marco ha terminado la visualización ({state})."),
    "American Football Live ist schon auf dem Bildschirm.": (
        "American Football Live is already on screen.",
        "American Football Live ya está en pantalla."),
    "Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.": (
        "This frame is too old to hand the screen to a plugin.",
        "Este marco es demasiado antiguo para ceder la pantalla a un plugin."),
    "Die Szene American Football Live wurde nicht gefunden.": (
        "The American Football Live scene was not found.",
        "No se ha encontrado la escena American Football Live."),
    "Die Takeover-Playlist ist noch nicht angelegt.": (
        "The takeover playlist has not been created yet.",
        "La lista de takeover aún no se ha creado."),
    "American Football Live läuft gerade in deiner Playlist; die Anzeige bleibt so.": (
        "American Football Live is currently playing in your playlist; the display stays as it is.",
        "American Football Live se está mostrando en tu lista; la pantalla se queda así."),
    "Der Bildschirm ist aus. American Football Live weckt ihn nicht.": (
        "The screen is off. American Football Live does not wake it.",
        "La pantalla está apagada. American Football Live no la enciende."),
    "Konnte American Football Live nicht anzeigen: {exc}": (
        "Could not show American Football Live: {exc}",
        "No se pudo mostrar American Football Live: {exc}"),
    "Etwas anderes hat gerade den Bildschirm.": (
        "Something else has the screen right now.",
        "Otra cosa está usando la pantalla ahora mismo."),
    "Der Rahmen hat American Football Live nicht rechtzeitig angezeigt.": (
        "The frame did not show American Football Live in time.",
        "El marco no mostró American Football Live a tiempo."),
    "American Football Live hatte den Bildschirm nicht.": (
        "American Football Live did not have the screen.",
        "American Football Live no tenía la pantalla."),
    "Bitte den Rahmen um den Bildschirm.": (
        "Asking the frame for the screen.",
        "Pidiendo la pantalla al marco."),
    "Gebe den Bildschirm zurück.": (
        "Handing the screen back.",
        "Devolviendo la pantalla."),
    "{name} hat nicht geklappt: {exc}": (
        "{name} did not work: {exc}",
        "{name} no ha funcionado: {exc}"),
    "Der Rahmen ist nach American Football Live nicht zu deiner Playlist zurückgekehrt. Starte sie auf der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix passiert das nicht.": (
        "The frame did not return to your playlist after American Football Live. Restart it on the frame's home page. "
        "This does not happen with a saved playlist instead of a Quick Mix.",
        "El marco no volvió a tu lista después de American Football Live. Vuelve a iniciarla en la página principal del marco. "
        "Con una lista guardada en lugar de un Quick Mix esto no pasa."),
    "Regelmäßige Anzeige ist aus.": (
        "Regular display is off.",
        "La visualización periódica está desactivada."),
    "Keine Liga gewählt.": (
        "No league selected.",
        "No hay ninguna liga elegida."),
    "Außerhalb von {start}–{end} Uhr.": (
        "Outside {start}:00–{end}:00.",
        "Fuera del horario {start}:00–{end}:00."),
    "Gerade läuft kein Spiel.": (
        "No match is being played right now.",
        "Ahora mismo no se juega ningún partido."),
    "Heute ist in den gewählten Ligen kein Spieltag.": (
        "No matchday today in the selected leagues.",
        "Hoy no hay jornada en las ligas elegidas."),
    "Nächstes Spiel: {when} {home} – {away}": (
        "Next match: {when} {home} – {away}",
        "Próximo partido: {when} {home} – {away}"),
    "Live: {scores}": (
        "Live: {scores}",
        "En vivo: {scores}"),
    "Keine Spiele": (
        "No matches",
        "Sin partidos"),
    "Lese die Ergebnisse jetzt neu.": (
        "Reading the results again now.",
        "Leyendo los resultados de nuevo."),
    "Konnte die Teams nicht laden: {exc}": (
        "Could not load the teams: {exc}",
        "No se pudieron cargar los equipos: {exc}"),
}

_ROUND = re.compile(r"^\s*(Vorbereitung )?Woche (\d+)\s*$")
_ROUND_NAMES = {"Play-offs": ("Playoffs", "Playoffs"), "Off-Season": ("Off-season", "Pretemporada")}


def language(value):
    value = str(value or "").strip().lower()
    return value if value in LANGUAGES else "de"


def t(lang, template, **values):
    lang = language(lang)
    text = template
    if lang != "de":
        pair = _TEXTS.get(template)
        if pair:
            text = pair[LANGUAGES.index(lang) - 1]
    return text.format(**values) if values else text


def round_name(lang, text):
    """leagues.round_name liefert die Woche auf Deutsch ("Woche 7")."""
    lang = language(lang)
    text = str(text or "")
    if lang == "de":
        return text
    if text in _ROUND_NAMES:
        return _ROUND_NAMES[text][LANGUAGES.index(lang) - 1]
    match = _ROUND.match(text)
    if not match:
        return text
    number = match.group(2)
    if match.group(1):
        return f"Preseason week {number}" if lang == "en" else f"Pretemporada, semana {number}"
    return f"Week {number}" if lang == "en" else f"Semana {number}"
