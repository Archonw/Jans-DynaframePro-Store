/* World Map Live - die Szene.
 *
 * Zeichnet eine ruhige Weltkarte (Miller-Projektion) mit Tag und Nacht und
 * legt die Live-Daten des Plugins World Map Live darüber: Flugzeuge, Schiffe
 * und Blitze. Die Daten kommen über den Proxy der Weboberfläche auf :8003
 * (der Proxy der Engine lehnt lokale Adressen ab).
 *
 * Zwei Canvas: "map" (Meer, Land, Nacht; einmal pro Minute neu) und "live"
 * (Punkte; einmal pro Sekunde, flüssig nur solange ein Blitz aufleuchtet).
 * Flugzeuge und Schiffe werden zwischen zwei Datenständen mit Kurs und
 * Geschwindigkeit weitergerechnet.
 *
 * ?demo=1 zeigt erfundene Daten, ?region=europe einen Ausschnitt, ?lang=en.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "WorldMapLive";
  const POLL_MS = 2000;
  const params = new URLSearchParams(location.search);
  const DEMO = params.has("demo");
  // Die Plugin-Seite ist über den Proxy der Weboberfläche erreichbar. Je nach
  // DynaFrame-Version auf :8003 oder direkt auf Port 80; die Szene probiert der
  // Reihe nach und bleibt bei der Adresse, die antwortet.
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set([
    `${location.protocol}//${location.hostname}:8003${advanced}`,
    `${location.protocol}//${location.hostname}${advanced}`,
    `${location.origin}${advanced}`,
  ])];
  let baseIndex = 0;

  // west, süd, ost, nord - wie REGIONS im Plugin.
  const REGIONS = {
    world: null,
    europe: [-25, 33, 45, 71.5],
    dach: [4.5, 45, 18, 55.5],
    north_america: [-130, 13, -55, 60],
    east_asia: [90, -5, 150, 50],
    oceania: [105, -48, 180, 2],
    south_america: [-92, -56, -32, 13],
  };
  const WORLD = { west: -180, south: -58, east: 180, north: 80, center: 11 };  // Naht in der Beringstraße

  const TEXT = {
    de: { planes: "Flugzeuge", ships: "Schiffe", strikes: "Blitze ({m} Min.)", nokey: "Schiffe: API-Key fehlt",
      offline: "World Map Live antwortet nicht", stale: "Flugdaten von {time} Uhr" },
    en: { planes: "aircraft", ships: "ships", strikes: "lightning ({m} min)", nokey: "Ships: API key missing",
      offline: "World Map Live is not responding", stale: "Flight data from {time}" },
    es: { planes: "aviones", ships: "barcos", strikes: "rayos ({m} min)", nokey: "Barcos: falta la clave API",
      offline: "World Map Live no responde", stale: "Datos de vuelo de las {time}" },
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };

  const RAD = Math.PI / 180;
  const el = (id) => document.getElementById(id);
  const mapCanvas = el("map");
  const liveCanvas = el("live");
  const mapCtx = mapCanvas.getContext("2d");
  const liveCtx = liveCanvas.getContext("2d");

  const state = {
    lang: params.get("lang") || "de",
    region: params.get("region") || "world",
    show: { planes: true, ships: true, lightning: true, night: true, iss: true, legend: true },
    iss: null,                // Bahnelemente der ISS
    minutes: 30,
    skew: 0,                  // Uhr des Plugins minus Uhr der Szene, Sekunden
    planes: null,             // {t, lon, lat, vx, vy, n}
    ships: null,
    planesVer: -1, shipsVer: -1,
    strikes: [],              // {lon, lat, t, show}
    strikeGen: "", strikeLast: 0,
    status: {},
    reachable: true, failures: 0,
  };
  let view = null;
  let dpr = 1;
  let W = 0, H = 0;
  let readySent = false;
  let lastMapDraw = 0;
  let animating = false;

  const tx = (key, values = {}) => ((TEXT[state.lang] || TEXT.de)[key] || key)
    .replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");
  const now = () => Date.now() / 1000 + state.skew;
  const fmt = (n) => n.toLocaleString(LOCALES[state.lang] || "de-DE");

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  // ------------------------------------------------------------ Projektion
  //
  // Querformat und Ausschnitte: Miller-Projektion. Ganze Welt im Hochformat:
  // drei Globen (oben groß Europa/Afrika, unten Amerika und Asien/Pazifik),
  // damit nichts leer bleibt und trotzdem die ganze Welt zu sehen ist.
  //
  // Jede Ansicht ist ein "Projektor": fwd(lon, lat) setzt .x/.y und sagt, ob
  // der Punkt sichtbar ist; inv(x, y) gibt [lat, lon] oder null; clip(ctx)
  // beschränkt das Zeichnen auf die Ansicht; scale ist Pixel je Radiant.

  const MILLER_MAX = miller(85);
  function miller(lat) {
    return 1.25 * Math.log(Math.tan(Math.PI / 4 + 0.4 * lat * RAD));
  }
  function millerInverse(y) {
    return (2.5 * Math.atan(Math.exp(0.8 * y)) - 0.625 * Math.PI) / RAD;
  }

  // lon/lat der Globen im Hochformat: Mitte, Größe relativ.
  const GLOBES = [
    { lon: 15, lat: 30 },      // Europa und Afrika, groß oben
    { lon: -88, lat: 12 },     // Amerika
    { lon: 122, lat: 8 },      // Asien und Pazifik
  ];

  function millerView() {
    const box = REGIONS[state.region];
    const world = !box;
    const center = world ? WORLD.center : (box[0] + box[2]) / 2;
    const west = world ? center - 180 : box[0];
    const east = world ? center + 180 : box[2];
    const south = world ? WORLD.south : box[1];
    const north = world ? WORLD.north : box[3];
    const x0 = (west - center) * RAD, x1 = (east - center) * RAD;
    const y0 = miller(south), y1 = miller(north);
    let scale = Math.min(W / (x1 - x0), H / (y1 - y0));
    if (world && W / H < 1.3) scale = H / (y1 - y0);      // fast quadratisch: Höhe füllen
    let cy = (y0 + y1) / 2;
    const half = H / 2 / scale;
    if (half < MILLER_MAX) cy = Math.max(-MILLER_MAX + half, Math.min(MILLER_MAX - half, cy));
    else cy = 0;
    const v = { kind: "miller", world, center, scale, cy };
    v.fwd = (lon, lat) => {
      const d = ((lon - center + 540) % 360) - 180;
      v.x = W / 2 + d * RAD * scale;
      v.y = H / 2 - (miller(lat) - cy) * scale;
      return true;
    };
    v.raw = (lon, lat) => {   // ohne Wickeln, für Küsten (Kopien links und rechts)
      v.x = W / 2 + (lon - center) * RAD * scale;
      v.y = H / 2 - (miller(lat) - cy) * scale;
    };
    v.inv = (x, y) => [millerInverse((H / 2 - y) / scale + cy), (x - W / 2) / scale / RAD + center];
    v.clip = () => {};
    return v;
  }

  function globeView(cx, cy, R, lon0, lat0) {
    const s0 = Math.sin(lat0 * RAD), c0 = Math.cos(lat0 * RAD);
    const v = { kind: "globe", cx, cy, R, scale: R, lon0, lat0 };
    v.fwd = (lon, lat) => {
      const l = (lon - lon0) * RAD, p = lat * RAD;
      const cp = Math.cos(p), sp = Math.sin(p), cl = Math.cos(l);
      v.x = cx + R * cp * Math.sin(l);
      v.y = cy - R * (c0 * sp - s0 * cp * cl);
      v.front = s0 * sp + c0 * cp * cl;
      return v.front > 0;
    };
    v.raw = (lon, lat) => {   // Rückseite auf den Rand gedrückt, für Flächen
      if (!v.fwd(lon, lat)) {
        const dx = v.x - cx, dy = v.y - cy, d = Math.hypot(dx, dy) || 1;
        v.x = cx + dx / d * R;
        v.y = cy + dy / d * R;
      }
    };
    v.inv = (x, y) => {
      const u = (x - cx) / R, w = (cy - y) / R, rr = u * u + w * w;
      if (rr > 1) return null;
      const z = Math.sqrt(1 - rr);
      const lat = Math.asin(Math.max(-1, Math.min(1, z * s0 + w * c0))) / RAD;
      const lon = lon0 + Math.atan2(u, z * c0 - w * s0) / RAD;
      return [lat, lon];
    };
    v.clip = (ctx) => {
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, 2 * Math.PI);
      ctx.clip();
    };
    return v;
  }

  function computeView() {
    if (state.region === "world" && W / H < 0.9) {
      // Ein großer Globus oben, zwei kleinere darunter; Platz unten für die Legende.
      const top = H * 0.025, bottom = H * 0.12, gap = Math.min(W, H) * 0.025;
      let R1 = W * 0.45, R2 = W * 0.235;
      const need = 2 * R1 + 2 * R2 + gap;
      const avail = H - top - bottom;
      if (need > avail) { R1 *= avail / need; R2 *= avail / need; }
      const y1 = top + (avail - (2 * R1 + 2 * R2 + gap)) / 2 + R1;
      const y2 = y1 + R1 + gap + R2;
      view = { kind: "globes", world: true, views: [
        globeView(W / 2, y1, R1, GLOBES[0].lon, GLOBES[0].lat),
        globeView(W / 2 - R2 - gap / 2, y2, R2, GLOBES[1].lon, GLOBES[1].lat),
        globeView(W / 2 + R2 + gap / 2, y2, R2, GLOBES[2].lon, GLOBES[2].lat),
      ] };
    } else {
      const v = millerView();
      view = { kind: "miller", world: v.world, views: [v] };
    }
  }

  // ------------------------------------------------------------ Karte

  const COLORS = {
    sea: "#0d2340", seaDeep: "#081629", space: "#03070e", land: "#34496a", landEdge: "rgba(175, 205, 240, .55)",
    border: "rgba(175, 205, 240, .28)", grid: "rgba(140, 170, 210, .08)", night: [2, 6, 18], day: [255, 238, 205],
    landLift: "rgba(130, 160, 200, .10)", terminator: "255, 196, 120",
  };

  function ringPath(v, path, flat, shift, open) {
    let lon = flat[0] / 100, lat = flat[1] / 100;
    if (open && v.kind === "globe") {
      // Linien (Grenzen): nur die Vorderseite, an der Kante neu ansetzen.
      let pen = false;
      for (let i = 0; ; i += 2) {
        if (i) { lon += flat[i] / 100; lat += flat[i + 1] / 100; }
        const visible = v.fwd(lon, lat);
        if (visible) { if (pen) path.lineTo(v.x, v.y); else path.moveTo(v.x, v.y); }
        pen = visible;
        if (i + 2 >= flat.length) break;
      }
      return;
    }
    v.raw(lon, lat);
    path.moveTo(v.x + shift, v.y);
    for (let i = 2; i < flat.length; i += 2) {
      lon += flat[i] / 100;
      lat += flat[i + 1] / 100;
      v.raw(lon, lat);
      path.lineTo(v.x + shift, v.y);
    }
    if (!open) path.closePath();
  }

  // Land, Seen und Grenzen als Pfade; gefüllt wird vor der Nacht, die Linien
  // kommen danach noch einmal obendrauf, damit die Küsten auch nachts klar sind.
  function landPaths(v) {
    const data = window.WORLD_MAP || { land: [], lakes: [], borders: [] };
    let shifts = [0];
    if (v.kind === "miller") {
      const span = 2 * Math.PI * v.scale;
      if (v.world || span < W * 3) shifts = [-span, 0, span];
    }
    const land = new Path2D(), lakes = new Path2D(), borders = new Path2D();
    for (const shift of shifts) {
      for (const ring of data.land) ringPath(v, land, ring, shift);
      for (const ring of data.lakes) ringPath(v, lakes, ring, shift);
      for (const line of data.borders || []) ringPath(v, borders, line, shift, true);
    }
    return { land, lakes, borders };
  }

  // Eine Linie aus lon/lat-Punkten; Lücken auf der Rückseite und an der Naht.
  function polyline(v, points, path = new Path2D()) {
    let pen = false, lastX = 0;
    for (const [lon, lat] of points) {
      const visible = v.fwd(lon, lat);
      if (visible && pen && Math.abs(v.x - lastX) < W / 2) path.lineTo(v.x, v.y);
      else if (visible) path.moveTo(v.x, v.y);
      pen = visible;
      lastX = v.x;
    }
    return path;
  }

  function drawGrid(ctx, v) {
    const step = view.world ? 30 : 10;
    const path = new Path2D();
    for (let lat = -90 + step; lat < 90; lat += step) {
      const pts = [];
      for (let lon = -180; lon <= 180; lon += 2) pts.push([lon, lat]);
      if (v.kind === "miller") { v.fwd(0, lat); path.moveTo(0, v.y); path.lineTo(W, v.y); }
      else polyline(v, pts, path);
    }
    for (let lon = -180; lon < 180; lon += step) {
      if (v.kind === "miller") { v.fwd(lon, 0); path.moveTo(v.x, 0); path.lineTo(v.x, H); continue; }
      const pts = [];
      for (let lat = -88; lat <= 88; lat += 2) pts.push([lon, lat]);
      polyline(v, pts, path);
    }
    ctx.strokeStyle = COLORS.grid;
    ctx.lineWidth = 1;
    ctx.stroke(path);
  }

  // Sonnenstand (NOAA-Näherung): Deklination und Länge des Subsolarpunkts.
  function sun(epochSeconds) {
    const d = epochSeconds / 86400 - 10957.5;   // Tage seit J2000
    const g = (357.529 + 0.98560028 * d) * RAD;
    const q = 280.459 + 0.98564736 * d;
    const L = (q + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)) * RAD;
    const e = (23.439 - 0.00000036 * d) * RAD;
    const ra = Math.atan2(Math.cos(e) * Math.sin(L), Math.cos(L)) / RAD;
    const dec = Math.asin(Math.sin(e) * Math.sin(L));
    let eqt = (q - ra) / 15;                         // Zeitgleichung in Stunden
    eqt -= 24 * Math.round(eqt / 24);
    const utcHours = ((epochSeconds / 3600) % 24 + 24) % 24;
    const lon = -15 * (utcHours - 12 + eqt);
    return { dec, lon: ((lon + 540) % 360) - 180 };
  }

  const smooth = (a, b, x) => {
    const f = Math.max(0, Math.min(1, (x - a) / (b - a)));
    return f * f * (3 - 2 * f);
  };

  // Tag und Nacht auf einer kleinen Leinwand rechnen und weich hochskalieren:
  // die Tagseite (Sonne über dem Horizont) leicht aufgehellt, die Nacht dunkel,
  // dazwischen die Dämmerung.
  const nightCanvas = document.createElement("canvas");
  function drawDayNight(ctx, s) {
    const cols = Math.max(64, Math.min(360, Math.round(W / 5)));
    const rows = Math.max(36, Math.round(cols * H / W));
    nightCanvas.width = cols;
    nightCanvas.height = rows;
    const nctx = nightCanvas.getContext("2d");
    const image = nctx.createImageData(cols, rows);
    const sinDec = Math.sin(s.dec), cosDec = Math.cos(s.dec);
    const [nr, ng, nb] = COLORS.night, [dr, dg, db] = COLORS.day;
    for (let j = 0; j < rows; j++) {
      const y = ((j + 0.5) / rows) * H;
      for (let i = 0; i < cols; i++) {
        const x = ((i + 0.5) / cols) * W;
        let ll = null;
        for (const v of view.views) if ((ll = v.inv(x, y))) break;
        if (!ll) continue;
        const lat = ll[0] * RAD;
        const h = (ll[1] - s.lon) * RAD;
        const alt = Math.asin(Math.sin(lat) * sinDec + Math.cos(lat) * cosDec * Math.cos(h)) / RAD;
        const k = (j * cols + i) * 4;
        if (alt > -0.5) {
          image.data[k] = dr; image.data[k + 1] = dg; image.data[k + 2] = db;
          image.data[k + 3] = Math.round(255 * (0.11 + 0.13 * smooth(-0.5, 25, alt)) * smooth(-0.5, 2, alt));
        } else {
          image.data[k] = nr; image.data[k + 1] = ng; image.data[k + 2] = nb;
          image.data[k + 3] = Math.round(255 * 0.7 * smooth(-0.5, -15, alt));
        }
      }
    }
    nctx.putImageData(image, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.drawImage(nightCanvas, 0, 0, W, H);
  }

  // Die Tag-Nacht-Grenze: der Großkreis 90° vom Subsolarpunkt, warm und weich.
  function terminatorPoints(s) {
    const lat0 = s.dec, lon0 = s.lon * RAD;
    const S = [Math.cos(lat0) * Math.cos(lon0), Math.cos(lat0) * Math.sin(lon0), Math.sin(lat0)];
    let U = [-S[1], S[0], 0];
    const n = Math.hypot(U[0], U[1]) || 1;
    U = [U[0] / n, U[1] / n, 0];
    const V = [S[1] * U[2] - S[2] * U[1], S[2] * U[0] - S[0] * U[2], S[0] * U[1] - S[1] * U[0]];
    const pts = [];
    for (let a = 0; a <= 360; a += 1) {
      const c = Math.cos(a * RAD), d = Math.sin(a * RAD);
      const x = c * U[0] + d * V[0], y = c * U[1] + d * V[1], z = c * U[2] + d * V[2];
      pts.push([Math.atan2(y, x) / RAD, Math.asin(Math.max(-1, Math.min(1, z))) / RAD]);
    }
    return pts;
  }

  function drawTerminator(ctx, v, pts) {
    const line = polyline(v, pts);
    const width = Math.max(1.2, Math.min(W, H) / 700);
    ctx.lineJoin = "round";
    ctx.strokeStyle = `rgba(${COLORS.terminator}, .10)`;
    ctx.lineWidth = width * 9;
    ctx.stroke(line);
    ctx.strokeStyle = `rgba(${COLORS.terminator}, .22)`;
    ctx.lineWidth = width * 3.5;
    ctx.stroke(line);
    ctx.strokeStyle = `rgba(${COLORS.terminator}, .75)`;
    ctx.lineWidth = width;
    ctx.stroke(line);
  }

  // Die Sonne selbst, ganz leise.
  function drawSun(ctx, v, s) {
    if (!v.fwd(s.lon, s.dec / RAD)) return;
    const radius = (v.kind === "globe" ? v.R : Math.min(W, H)) * 0.3;
    const glow = ctx.createRadialGradient(v.x, v.y, 0, v.x, v.y, radius);
    glow.addColorStop(0, "rgba(255, 225, 160, .14)");
    glow.addColorStop(1, "rgba(255, 225, 160, 0)");
    ctx.fillStyle = glow;
    ctx.fillRect(v.x - radius, v.y - radius, radius * 2, radius * 2);
  }

  function drawMap() {
    const ctx = mapCtx;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const globes = view.kind === "globes";
    if (globes) {
      const bg = ctx.createLinearGradient(0, 0, 0, H);
      bg.addColorStop(0, "#060d1a");
      bg.addColorStop(1, COLORS.space);
      ctx.fillStyle = bg;
    } else {
      const sea = ctx.createLinearGradient(0, 0, 0, H);
      sea.addColorStop(0, COLORS.seaDeep);
      sea.addColorStop(0.5, COLORS.sea);
      sea.addColorStop(1, COLORS.seaDeep);
      ctx.fillStyle = sea;
    }
    ctx.fillRect(0, 0, W, H);

    const all = view.views.map((v) => ({ v, paths: landPaths(v) }));
    for (const { v, paths } of all) {
      ctx.save();
      v.clip(ctx);
      if (v.kind === "globe") {
        // Leichte Kugel: Meer zur Mitte hin heller.
        const ocean = ctx.createRadialGradient(v.cx - v.R * 0.3, v.cy - v.R * 0.35, v.R * 0.1, v.cx, v.cy, v.R);
        ocean.addColorStop(0, "#14305a");
        ocean.addColorStop(1, COLORS.seaDeep);
        ctx.fillStyle = ocean;
        ctx.fillRect(v.cx - v.R, v.cy - v.R, v.R * 2, v.R * 2);
      }
      drawGrid(ctx, v);
      ctx.fillStyle = COLORS.land;
      ctx.fill(paths.land);
      ctx.fillStyle = COLORS.sea;
      ctx.fill(paths.lakes);
      ctx.restore();
    }

    const s = state.show.night ? sun(now()) : null;
    if (s) drawDayNight(ctx, s);
    const term = s ? terminatorPoints(s) : null;

    for (const { v, paths } of all) {
      ctx.save();
      v.clip(ctx);
      if (s) {
        ctx.fillStyle = COLORS.landLift;
        ctx.fill(paths.land);
      }
      const edge = Math.max(0.7, Math.min(1.6, v.scale / 700));
      ctx.lineJoin = "round";
      ctx.strokeStyle = COLORS.border;
      ctx.lineWidth = edge * 0.8;
      ctx.setLineDash([edge * 3, edge * 2.5]);
      ctx.stroke(paths.borders);
      ctx.setLineDash([]);
      ctx.strokeStyle = COLORS.landEdge;
      ctx.lineWidth = edge;
      ctx.stroke(paths.land);
      ctx.stroke(paths.lakes);
      if (s) {
        drawTerminator(ctx, v, term);
        drawSun(ctx, v, s);
      }
      if (v.kind === "globe") {
        // Rand der Kugel nach innen abdunkeln.
        const limb = ctx.createRadialGradient(v.cx, v.cy, v.R * 0.7, v.cx, v.cy, v.R);
        limb.addColorStop(0, "rgba(3, 7, 14, 0)");
        limb.addColorStop(1, "rgba(3, 7, 14, .45)");
        ctx.fillStyle = limb;
        ctx.fillRect(v.cx - v.R, v.cy - v.R, v.R * 2, v.R * 2);
      }
      ctx.restore();
      if (v.kind === "globe") {
        // Ein Hauch Atmosphäre außen.
        const air = ctx.createRadialGradient(v.cx, v.cy, v.R * 0.98, v.cx, v.cy, v.R * 1.08);
        air.addColorStop(0, "rgba(120, 170, 255, .28)");
        air.addColorStop(1, "rgba(120, 170, 255, 0)");
        ctx.fillStyle = air;
        ctx.beginPath();
        ctx.arc(v.cx, v.cy, v.R * 1.08, 0, 2 * Math.PI);
        ctx.arc(v.cx, v.cy, v.R, 0, 2 * Math.PI, true);
        ctx.fill();
      }
    }

    if (!globes) {
      // Ränder leicht abdunkeln, damit Legende und Uhr ruhig stehen.
      const vignette = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.45, W / 2, H / 2, Math.max(W, H) * 0.75);
      vignette.addColorStop(0, "rgba(3, 7, 14, 0)");
      vignette.addColorStop(1, "rgba(3, 7, 14, .45)");
      ctx.fillStyle = vignette;
      ctx.fillRect(0, 0, W, H);
    }
    lastMapDraw = Date.now();
  }

  // ------------------------------------------------------------ Live-Punkte

  // Flach gespeichert, damit 10 000 Flugzeuge billig bleiben.
  function unpack(data, t, knots) {
    const n = Math.floor((data || []).length / 4);
    const out = { t, n, lon: new Float32Array(n), lat: new Float32Array(n), vx: new Float32Array(n),
      vy: new Float32Array(n), dx: new Float32Array(n), dy: new Float32Array(n), moving: new Uint8Array(n) };
    for (let i = 0; i < n; i++) {
      const lon = data[i * 4], lat = data[i * 4 + 1], course = data[i * 4 + 2] * RAD;
      const speed = data[i * 4 + 3] * (knots ? 0.514444 : 1);         // m/s
      out.lon[i] = lon; out.lat[i] = lat;
      out.dx[i] = Math.sin(course); out.dy[i] = Math.cos(course);
      out.vy[i] = speed * out.dy[i] / 111320;                          // Grad/s
      out.vx[i] = speed * out.dx[i] / (111320 * Math.max(0.05, Math.cos(lat * RAD)));
      out.moving[i] = speed > 0.5 ? 1 : 0;
    }
    return out;
  }

  function glyphSize(v) {
    return Math.max(2.2, Math.min(4.6, v.scale / 280));
  }

  const offscreen = (x, y, m) => x < -m || x > W + m || y < -m || y > H + m;

  // Ein kleines Flugzeug von oben, Nase nach vorn: rechte Hälfte, gespiegelt.
  // Schlank gehalten, damit sich viele Flugzeuge nicht zu einer Fläche verbinden.
  const PLANE_HALF = [[0, -1], [0.07, -0.88], [0.08, -0.25], [0.86, 0.12], [0.86, 0.22], [0.08, 0.08],
    [0.06, 0.62], [0.3, 0.8], [0.3, 0.88], [0, 0.82]];
  const PLANE = [...PLANE_HALF, ...PLANE_HALF.slice(1, -1).reverse().map(([u, w]) => [-u, w])];

  // Ein Schiff von oben: spitzer Bug, gerades Heck.
  const SHIP_HALF = [[0, -1], [0.17, -0.62], [0.24, -0.15], [0.24, 0.82], [0.19, 0.95], [0, 0.95]];
  const SHIP = [...SHIP_HALF, ...SHIP_HALF.slice(1, -1).reverse().map(([u, w]) => [-u, w])];

  // Legt für jedes Objekt die Form in Fahrtrichtung in einen Pfad.
  function glyphs(v, p, dt, shape, L, pick) {
    const globe = v.kind === "globe";
    const path = new Path2D();
    for (let i = 0; i < p.n; i++) {
      if (pick && !pick(i)) continue;
      const lon = p.lon[i] + p.vx[i] * dt, lat = p.lat[i] + p.vy[i] * dt;
      if (!v.fwd(lon, lat)) continue;
      const x = v.x, y = v.y;
      if (offscreen(x, y, 12)) continue;
      // Richtung auf dem Bildschirm; auf dem Globus über einen Punkt kurz voraus.
      let fx = p.dx[i], fy = -p.dy[i];
      if (globe) {
        v.fwd(lon + p.dx[i] * 0.3 / Math.max(0.1, Math.cos(lat * RAD)), lat + p.dy[i] * 0.3);
        const ax = v.x - x, ay = v.y - y, d = Math.hypot(ax, ay);
        if (d > 1e-6) { fx = ax / d; fy = ay / d; }
      }
      const rx = -fy, ry = fx;     // rechts von der Fahrtrichtung
      for (let k = 0; k < shape.length; k++) {
        const [u, w] = shape[k];
        const X = x + (u * rx - w * fx) * L, Y = y + (u * ry - w * fy) * L;
        if (k) path.lineTo(X, Y); else path.moveTo(X, Y);
      }
      path.closePath();
    }
    return path;
  }

  function drawPlanes(ctx, v, t) {
    const p = state.planes;
    if (!p || !p.n) return;
    const dt = Math.max(0, Math.min(1800, t - p.t));
    ctx.fillStyle = "rgba(255, 210, 127, .72)";
    ctx.fill(glyphs(v, p, dt, PLANE, glyphSize(v) * 1.3));
  }

  // Schiffe deckend: zwei Schiffe liegen nie übereinander. Stehende sind dunkler.
  function drawShips(ctx, v, t) {
    const p = state.ships;
    if (!p || !p.n) return;
    const dt = Math.max(0, Math.min(1800, t - p.t));
    const L = glyphSize(v) * 1.15;
    ctx.fillStyle = "rgb(44, 128, 124)";
    ctx.fill(glyphs(v, p, dt, SHIP, L, (i) => !p.moving[i]));
    ctx.fillStyle = "rgb(82, 214, 200)";
    ctx.fill(glyphs(v, p, dt, SHIP, L, (i) => p.moving[i]));
  }

  // Blitze: frisch weiß-gelb, dann orange, dann ein leiser roter Punkt.
  const STRIKE_DELAY = 6;     // Sekunden; so erscheinen sie im echten Abstand
  const PULSE = 1.8;
  const AGE_STEPS = [
    [60, "rgba(255, 246, 200, .95)", 1.25],
    [300, "rgba(255, 200, 90, .85)", 1.0],
    [900, "rgba(255, 140, 60, .6)", 0.85],
    [Infinity, "rgba(240, 80, 60, .38)", 0.75],
  ];

  function pruneStrikes(t) {
    const limit = t - state.minutes * 60;
    if (state.strikes.length && state.strikes[0].show < limit) {
      state.strikes = state.strikes.filter((s) => s.show >= limit);
    }
  }

  function drawStrikes(ctx, v, t) {
    if (!state.strikes.length) return 0;
    const r = Math.max(1.4, glyphSize(v) * 0.6);
    const buckets = AGE_STEPS.map(() => new Path2D());
    const pulses = [];
    for (const s of state.strikes) {
      const age = t - s.show;
      if (age < 0) continue;
      if (!v.fwd(s.lon, s.lat)) continue;
      const x = v.x, y = v.y;
      if (offscreen(x, y, 20)) continue;
      if (age < PULSE) pulses.push([x, y, age / PULSE]);
      let k = 0;
      while (age > AGE_STEPS[k][0]) k++;
      const rr = r * AGE_STEPS[k][2];
      buckets[k].moveTo(x + rr, y);
      buckets[k].arc(x, y, rr, 0, 2 * Math.PI);
    }
    for (let k = AGE_STEPS.length - 1; k >= 0; k--) {
      ctx.fillStyle = AGE_STEPS[k][1];
      ctx.fill(buckets[k]);
    }
    const ring = Math.max(10, glyphSize(v) * 6);
    for (const [x, y, f] of pulses) {
      const a = 1 - f;
      const flash = ctx.createRadialGradient(x, y, 0, x, y, ring * 0.9);
      flash.addColorStop(0, `rgba(255, 255, 235, ${0.85 * a * a})`);
      flash.addColorStop(1, "rgba(255, 255, 235, 0)");
      ctx.fillStyle = flash;
      ctx.beginPath();
      ctx.arc(x, y, ring * 0.9, 0, 2 * Math.PI);
      ctx.fill();
      ctx.strokeStyle = `rgba(255, 236, 160, ${0.8 * a})`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(x, y, 2 + ring * f, 0, 2 * Math.PI);
      ctx.stroke();
    }
    return pulses.length;
  }

  function drawLive() {
    const ctx = liveCtx;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const t = now();
    pruneStrikes(t);
    let pulses = 0;
    for (const v of view.views) {
      ctx.save();
      v.clip(ctx);
      if (state.show.ships) drawShips(ctx, v, t);
      if (state.show.planes) drawPlanes(ctx, v, t);
      if (state.show.iss) drawIss(ctx, v, t);
      if (state.show.lightning) pulses += drawStrikes(ctx, v, t);
      ctx.restore();
    }
    // Läuft noch ein Aufleuchten, oder kommt gleich eins?
    return state.show.lightning &&
      (pulses > 0 || state.strikes.some((s) => s.show > t && s.show - t < 1.2));
  }

  function frame() {
    if (document.hidden) { animating = false; return; }
    const busy = drawLive();
    if (busy) requestAnimationFrame(frame);
    else animating = false;
  }

  function kick() {
    if (!animating && !document.hidden) {
      animating = true;
      requestAnimationFrame(frame);
    }
  }

  // ------------------------------------------------------------ ISS

  function issAt(el, t) {
    const MU = 398600.4418, RE = 6378.137, J2 = 1.08262668e-3;
    const n = el.n * 2 * Math.PI / 86400;
    const dt = t - el.epoch, days = dt / 86400;
    const e = el.e, inc = el.i * RAD;
    const a = Math.cbrt(MU / (n * n));
    const p = a * (1 - e * e);
    const k = 1.5 * J2 * (RE / p) ** 2 * n;
    const raan = el.raan * RAD - k * Math.cos(inc) * dt;
    const argp = el.argp * RAD + k * (2 - 2.5 * Math.sin(inc) ** 2) * dt;
    const M = el.M * RAD + n * dt + 2 * Math.PI * el.ndot * days * days;
    let E = M;
    for (let j = 0; j < 8; j++) E -= (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E));
    const nu = 2 * Math.atan2(Math.sqrt(1 + e) * Math.sin(E / 2), Math.sqrt(1 - e) * Math.cos(E / 2));
    const u = argp + nu;
    const cu = Math.cos(u), su = Math.sin(u), cO = Math.cos(raan), sO = Math.sin(raan), ci = Math.cos(inc);
    const x = cO * cu - sO * su * ci, y = sO * cu + cO * su * ci, z = su * Math.sin(inc);
    const gmst = (280.46061837 + 360.98564736629 * (t / 86400 - 10957.5)) % 360;
    let lon = Math.atan2(y, x) / RAD - gmst;
    lon = ((lon % 360) + 540) % 360 - 180;
    return { lat: Math.atan2(z, Math.hypot(x, y)) / RAD, lon };
  }

  const ISS_PAST = 45 * 60, ISS_AHEAD = 45 * 60, ISS_STEP = 20;

  function issTrack(v, t0, t1) {
    const pts = [];
    for (let t = t0; t <= t1 + 0.1; t += ISS_STEP) {
      const p = issAt(state.iss, Math.min(t, t1));
      pts.push([p.lon, p.lat]);
    }
    return polyline(v, pts);
  }

  function drawIss(ctx, v, t) {
    if (!state.iss) return;
    const width = Math.max(1.2, Math.min(W, H) / 650);
    ctx.lineCap = "round";
    ctx.strokeStyle = "rgba(200, 225, 255, .22)";
    ctx.lineWidth = width;
    ctx.stroke(issTrack(v, t - ISS_PAST, t));
    ctx.setLineDash([width * 4, width * 4]);
    ctx.strokeStyle = "rgba(200, 225, 255, .5)";
    ctx.stroke(issTrack(v, t, t + ISS_AHEAD));
    ctx.setLineDash([]);
    const p = issAt(state.iss, t);
    if (!v.fwd(p.lon, p.lat)) return;
    const x = v.x, y = v.y;
    const s = Math.max(9, Math.min(W, H) / 85) * (v.kind === "globe" ? Math.min(1, v.R / (W * 0.4)) : 1);
    const glow = ctx.createRadialGradient(x, y, 0, x, y, s * 2.6);
    glow.addColorStop(0, "rgba(190, 220, 255, .45)");
    glow.addColorStop(1, "rgba(190, 220, 255, 0)");
    ctx.fillStyle = glow;
    ctx.fillRect(x - s * 3, y - s * 3, s * 6, s * 6);
    // Die Station: Rumpf, Träger, zwei Paar Solarflügel.
    ctx.fillStyle = "#eaf3ff";
    ctx.fillRect(x - s * 0.22, y - s * 0.55, s * 0.44, s * 1.1);
    ctx.fillRect(x - s * 1.25, y - s * 0.07, s * 2.5, s * 0.14);
    ctx.fillStyle = "#8fb8ff";
    for (const dx of [-1.15, -0.7, 0.45, 0.9]) ctx.fillRect(x + dx * s, y - s * 0.6, s * 0.25, s * 1.2);
    ctx.font = `600 ${Math.round(s * 1.15)}px Inter, "Segoe UI", Roboto, Arial, sans-serif`;
    ctx.textBaseline = "middle";
    ctx.fillStyle = "rgba(234, 243, 255, .9)";
    ctx.shadowColor = "rgba(0, 0, 0, .8)";
    ctx.shadowBlur = 4;
    ctx.fillText("ISS", x + s * 1.6, y);
    ctx.shadowBlur = 0;
  }

  // ------------------------------------------------------------ Legende

  function renderLegend() {
    el("legend").classList.toggle("hidden", !state.show.legend);
    el("clockBox").classList.toggle("hidden", !state.show.legend);
    el("rowPlanes").classList.toggle("off", !state.show.planes);
    el("rowShips").classList.toggle("off", !state.show.ships);
    el("rowStrikes").classList.toggle("off", !state.show.lightning);
    el("rowIss").classList.toggle("off", !state.show.iss || !state.iss);
    el("lPlanes").textContent = tx("planes");
    el("lShips").textContent = tx("ships");
    el("lStrikes").textContent = tx("strikes", { m: state.minutes });
    const nokey = state.status.ships === "nokey";
    el("rowShips").classList.toggle("dim", nokey);
    el("nPlanes").textContent = state.planes ? fmt(state.planes.n) : "–";
    el("nShips").textContent = state.ships && !nokey ? fmt(state.ships.n) : "–";
    const t = now();
    el("nStrikes").textContent = fmt(state.strikes.filter((s) => s.show <= t).length);
    const notes = [];
    if (!state.reachable) notes.push(tx("offline"));
    else if (nokey && state.show.ships) notes.push(tx("nokey"));
    if (state.planes && state.show.planes && t - state.planes.t > 1800) {
      notes.push(tx("stale", { time: new Date(state.planes.t * 1000).toLocaleTimeString(LOCALES[state.lang],
        { hour: "2-digit", minute: "2-digit" }) }));
    }
    el("note").textContent = notes.join(" · ");
  }

  function renderClock() {
    const d = new Date(now() * 1000);
    const locale = LOCALES[state.lang] || "de-DE";
    el("clock").textContent = d.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" });
    el("date").textContent = d.toLocaleDateString(locale, { weekday: "long", day: "numeric", month: "long" });
  }

  // ------------------------------------------------------------ Daten

  function apply(payload) {
    state.skew = (payload.now || Date.now() / 1000) - Date.now() / 1000;
    const s = payload.settings || {};
    const before = JSON.stringify([state.region, state.show.night]);
    if (s.Language) state.lang = s.Language;
    if (s.Region && !params.get("region")) state.region = s.Region;
    state.show = { planes: s.ShowPlanes !== false, ships: s.ShowShips !== false, lightning: s.ShowLightning !== false,
      night: s.ShowNight !== false, iss: s.ShowIss !== false, legend: s.ShowLegend !== false };
    if (payload.iss !== undefined) state.iss = payload.iss;
    state.minutes = s.LightningMinutes || 30;
    state.status = payload.status || {};
    if (Array.isArray(payload.credits)) {
      const text = payload.credits.join(" · ");
      if (el("credit").textContent !== text) el("credit").textContent = text;
    }
    if (JSON.stringify([state.region, state.show.night]) !== before) {
      computeView();
      drawMap();
    }
    const planes = payload.planes || {};
    if (planes.data) state.planes = unpack(planes.data, planes.t, false);
    if (planes.ver !== undefined) state.planesVer = planes.ver;
    const ships = payload.ships || {};
    if (ships.data) state.ships = unpack(ships.data, ships.t, true);
    if (ships.ver !== undefined) state.shipsVer = ships.ver;
    const strikes = payload.strikes || {};
    if (strikes.gen !== state.strikeGen) {
      state.strikes = [];
      state.strikeGen = strikes.gen;
    }
    const data = strikes.data || [];
    const t = now();
    const first = state.strikeLast === 0;
    for (let i = 0; i + 2 < data.length; i += 3) {
      const stamp = data[i + 2];
      // Ältere erscheinen sofort und still; neue im Abstand, in dem sie fielen.
      const show = first || stamp + STRIKE_DELAY < t - 30 ? stamp : Math.max(t, stamp + STRIKE_DELAY);
      state.strikes.push({ lon: data[i], lat: data[i + 1], t: stamp, show });
    }
    if (data.length) state.strikes.sort((a, b) => a.show - b.show);
    if (strikes.last !== undefined) state.strikeLast = strikes.last;
  }

  async function poll() {
    if (DEMO) return;
    const url = new URL("api/scene", pluginBases[baseIndex]);
    url.searchParams.set("p", state.planesVer);
    url.searchParams.set("s", state.shipsVer);
    url.searchParams.set("g", state.strikeGen);
    url.searchParams.set("l", state.strikeLast);
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 15000);
    try {
      const response = await fetch(url, { cache: "no-store", signal: abort.signal });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      apply(await response.json());
      state.failures = 0;
      state.reachable = true;
    } catch (_) {
      state.failures += 1;
      baseIndex = (baseIndex + 1) % pluginBases.length;
      if (state.failures >= 2 * pluginBases.length) state.reachable = false;
    } finally {
      clearTimeout(timer);
    }
    renderLegend();
    kick();
  }

  // ------------------------------------------------------------ Demo

  function demo() {
    const rand = (a, b) => a + Math.random() * (b - a);
    const hubs = [[8.6, 50.0], [-0.4, 51.5], [2.5, 49.0], [-73.8, 40.6], [-118.4, 33.9], [139.8, 35.5],
      [103.9, 1.4], [55.4, 25.2], [-46.5, -23.4], [151.2, -33.9], [28.8, 41.3], [116.6, 40.1], [-87.9, 41.9],
      [77.1, 28.6], [-3.6, 40.5], [12.2, 41.8], [-79.6, 43.7], [18.6, -33.9], [-99.1, 19.4], [37.4, 55.9]];
    const planes = [];
    for (let i = 0; i < 11000; i++) {
      const a = hubs[Math.floor(Math.random() * hubs.length)];
      const b = hubs[Math.floor(Math.random() * hubs.length)];
      if (a === b) continue;
      const f = Math.random();
      const lon = a[0] + (b[0] - a[0]) * f + rand(-2, 2), lat = a[1] + (b[1] - a[1]) * f + rand(-1.5, 1.5);
      const course = (Math.atan2(b[0] - a[0], b[1] - a[1]) / RAD + 360) % 360;
      planes.push(+lon.toFixed(3), +lat.toFixed(3), Math.round(course), Math.round(rand(200, 260)));
    }
    const lanes = [[[-5.6, 36], [32, 31.5]], [[32.5, 29.9], [43.4, 12.6]], [[43.4, 12.6], [80, 6]],
      [[80, 6], [103.8, 1.3]], [[103.8, 1.3], [121, 25]], [[121, 25], [139.7, 35]], [[-5, 48.5], [4, 52]],
      [[4, 52], [10, 54.5]], [[-74, 40.5], [-5, 48.5]], [[-80, 25], [-74, 40.5]], [[-79.5, 9], [-118, 33.7]],
      [[18.5, -34.4], [55, -20]], [[-43, -23], [-5, 36]]];
    const ships = [];
    for (let i = 0; i < 3800; i++) {
      const [a, b] = lanes[Math.floor(Math.random() * lanes.length)];
      const f = Math.random();
      ships.push(+(a[0] + (b[0] - a[0]) * f + rand(-1.2, 1.2)).toFixed(3),
        +(a[1] + (b[1] - a[1]) * f + rand(-1.2, 1.2)).toFixed(3), Math.round(rand(0, 359)),
        Math.random() < 0.7 ? +rand(8, 20).toFixed(1) : 0);
    }
    const cells = [[12, 48.5], [-90, 33], [-60, -5], [25, -2], [100, 15], [130, -15], [77, 22]];
    const t = Date.now() / 1000;
    const strikes = [];
    for (let i = 0; i < 1400; i++) {
      const c = cells[i % cells.length];
      const r = Math.sqrt(Math.random()) * 3, a = rand(0, 2 * Math.PI);
      strikes.push(+(c[0] + r * Math.cos(a) * 1.4).toFixed(3), +(c[1] + r * Math.sin(a)).toFixed(3), t - rand(0, 1700));
    }
    apply({ now: t, settings: { Language: state.lang, Region: state.region, LightningMinutes: 30 },
      planes: { ver: 1, t, data: planes }, ships: { ver: 1, t, data: ships },
      strikes: { gen: "demo", last: 1, data: strikes }, status: {},
      iss: { epoch: t - 3 * 3600, ndot: 0.0001, i: 51.64, raan: (t / 600) % 360, e: 0.0006, argp: 80, M: 20, n: 15.5 } });
    setInterval(() => {
      const c = cells[Math.floor(Math.random() * cells.length)];
      const n = Date.now() / 1000;
      apply({ now: n, settings: { Language: state.lang, Region: state.region, LightningMinutes: 30 },
        strikes: { gen: "demo", last: 2, data: [c[0] + rand(-3, 3), c[1] + rand(-2, 2), n - 6] } });
      renderLegend();
      kick();
    }, 900);
  }

  // ------------------------------------------------------------ Start

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = window.innerWidth;
    H = window.innerHeight;
    for (const canvas of [mapCanvas, liveCanvas]) {
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(H * dpr);
    }
    computeView();
    drawMap();
    drawLive();
  }

  window.addEventListener("resize", resize);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { drawMap(); kick(); } });
  resize();
  renderClock();
  renderLegend();
  ready();

  if (DEMO) demo();
  else poll();
  setInterval(() => { if (!DEMO) poll(); }, POLL_MS);
  setInterval(() => {
    renderClock();
    if (Date.now() - lastMapDraw > 60000) drawMap();   // Nachtgrenze wandert
  }, 1000);
  setInterval(() => { renderLegend(); kick(); }, 1000);
})();
