"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/SatelliteSwarm/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["SwitchSeconds", "PlaylistSeconds"];
const GROUP_FIELDS = ["ShowStarlink", "ShowOneweb", "ShowNavigation", "ShowEarth", "ShowStations", "ShowScience", "ShowComms", "ShowOther"];
const GROUP_KEYS = ["starlink", "oneweb", "navigation", "earth", "stations", "science", "comms", "other"];
const CHECK_FIELDS = ["Labels", "Orbits", "Panel", "SkyOnPass", "WakeScreen", "AnnounceIss", "AnnounceCss", "AnnounceHst",
  "AnnounceTrains", ...GROUP_FIELDS];
const SELECT_FIELDS = ["View", "Camera", "DotSize", "MinElevation", "AnnounceWhen", "LeadMinutes", "Takeover"];
const TEXT_FIELDS = ["PlaceName"];
let current = null;
let editing = false;

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["Satellite Swarm", "Satellite Swarm", "Satellite Swarm"],
  lede: ["Alle rund 10.000 aktiven Satelliten live: Aus den offenen Bahndaten von CelesTrak rechnet der Rahmen, wo Starlink-Ketten, Wettersatelliten, GPS und alle anderen gerade sind, als Schwarm um die Erde oder als Himmel über deinem Haus. Fliegt die ISS über dich, sagt die Szene es an. Jede Änderung hier wird sofort gespeichert.",
    "All of the roughly 10,000 active satellites live: from CelesTrak's open orbit data the frame computes where Starlink trains, weather satellites, GPS and all the others are right now, as a swarm around the Earth or as the sky above your home. When the ISS passes over you, the scene announces it. Every change here is saved immediately.",
    "Los aproximadamente 10.000 satélites activos en directo: con los datos orbitales abiertos de CelesTrak el marco calcula dónde están ahora los trenes de Starlink, los satélites meteorológicos, el GPS y todos los demás, como un enjambre alrededor de la Tierra o como el cielo sobre tu casa. Cuando la ISS pasa sobre ti, la escena lo anuncia. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  test: ["Ansage ausprobieren", "Test announcement", "Probar el aviso"],
  refresh: ["Bahndaten jetzt holen", "Fetch orbit data now", "Cargar datos orbitales ahora"],
  factSats: ["Satelliten", "Satellites", "Satélites"],
  factAbove: ["Gerade über dir", "Above you right now", "Sobre ti ahora"],
  factNext: ["Nächster angesagter Überflug", "Next announced pass", "Próximo paso anunciado"],
  factRead: ["Bahndaten geholt", "Orbit data fetched", "Datos orbitales cargados"],
  factVersion: ["Version", "Version", "Versión"],
  passTitle: ["Die nächsten Überflüge über deinem Ort", "The next passes over your place", "Los próximos pasos sobre tu lugar"],
  statusHint: ["Die Bahndaten kommen alle 8 Stunden von CelesTrak (celestrak.org). Wer Pi-hole oder einen anderen Werbeblocker nutzt, muss celestrak.org erlauben, für die Ortssuche auch geocoding-api.open-meteo.com.",
    "The orbit data comes from CelesTrak (celestrak.org) every 8 hours. If you use Pi-hole or another ad blocker, allow celestrak.org, and geocoding-api.open-meteo.com for the place search.",
    "Los datos orbitales llegan de CelesTrak (celestrak.org) cada 8 horas. Si usas Pi-hole u otro bloqueador, permite celestrak.org y, para buscar el lugar, geocoding-api.open-meteo.com."],
  waitData: ["Wartet auf CelesTrak", "Waiting for CelesTrak", "Esperando a CelesTrak"],
  fetching: ["Holt die Bahndaten …", "Fetching the orbit data …", "Cargando los datos orbitales …"],
  errorNote: ["{error} Das Plugin versucht es bald wieder.", "{error} The plugin tries again soon.", "{error} El plugin lo volverá a intentar pronto."],
  noPlaceShort: ["Ort fehlt", "Place missing", "Falta el lugar"],
  noPass: ["Keiner in 36 Stunden", "None in 36 hours", "Ninguno en 36 horas"],
  aboveValue: ["{n} ({lit} in der Sonne)", "{n} ({lit} in sunlight)", "{n} ({lit} al sol)"],
  visible: ["sichtbar", "visible", "visible"],
  notAnnounced: ["wird nicht angesagt", "not announced", "no se anuncia"],
  takeoverBadge: ["über die Playlist", "over the playlist", "sobre la playlist"],
  trainName: ["Starlink-Zug ({n})", "Starlink train ({n})", "Tren Starlink ({n})"],
  passRow: ["{day}{start}–{end}, bis {el}° im {dir}", "{day}{start}–{end}, up to {el}° in the {dir}", "{day}{start}–{end}, hasta {el}° hacia el {dir}"],
  dirs: [["Norden", "Nordosten", "Osten", "Südosten", "Süden", "Südwesten", "Westen", "Nordwesten"],
    ["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"],
    ["norte", "noreste", "este", "sureste", "sur", "suroeste", "oeste", "noroeste"]],
  today: ["heute ", "today ", "hoy "],
  tomorrow: ["morgen ", "tomorrow ", "mañana "],
  oclock: ["{time} Uhr", "{time}", "{time}"],
  placeTitle: ["Dein Ort", "Your place", "Tu lugar"],
  placeHint: ["Für den Himmel über deinem Haus und die Ansagen braucht die Szene deinen Ort. Er bleibt auf dem Rahmen.",
    "The scene needs your place for the sky above your home and for the announcements. It stays on the frame.",
    "La escena necesita tu lugar para el cielo sobre tu casa y para los avisos. Se queda en el marco."],
  placeSearch: ["Ort suchen", "Find a place", "Buscar un lugar"],
  placeSearchHint: ["z. B. Hamburg", "e.g. Hamburg", "p. ej. Madrid"],
  placeFind: ["Suchen", "Search", "Buscar"],
  placeSearching: ["Suche …", "Searching …", "Buscando …"],
  placeNone: ["Nichts gefunden.", "Nothing found.", "No se ha encontrado nada."],
  placeName: ["Name auf dem Bildschirm", "Name on screen", "Nombre en pantalla"],
  lat: ["Breitengrad", "Latitude", "Latitud"],
  lon: ["Längengrad", "Longitude", "Longitud"],
  placeMissing: ["Noch kein Ort eingetragen: Die Szene zeigt nur die Erde und sagt nichts an.",
    "No place entered yet: the scene only shows the Earth and announces nothing.",
    "Aún no hay lugar: la escena solo muestra la Tierra y no anuncia nada."],
  placeSet: ["Ort: {place} ({lat}, {lon})", "Place: {place} ({lat}, {lon})", "Lugar: {place} ({lat}, {lon})"],
  showTitle: ["Was die Szene zeigt", "What the scene shows", "Qué muestra la escena"],
  view: ["Ansicht", "View", "Vista"],
  viewBoth: ["Erde und Himmel im Wechsel", "Earth and sky taking turns", "Tierra y cielo alternando"],
  viewGlobe: ["Schwarm um die Erde", "Swarm around the Earth", "Enjambre alrededor de la Tierra"],
  viewSky: ["Himmel über deinem Haus", "Sky above your home", "Cielo sobre tu casa"],
  switchSeconds: ["Wechsel alle (Sekunden)", "Switch every (seconds)", "Cambiar cada (segundos)"],
  camera: ["Kamera bei der Erde", "Camera at the Earth", "Cámara en la Tierra"],
  camCycle: ["Fährt hinaus bis zum geostationären Ring und zurück", "Moves out to the geostationary ring and back", "Se aleja hasta el anillo geoestacionario y vuelve"],
  camNear: ["Nah: die Schwärme dicht an der Erde", "Close: the swarms near the Earth", "Cerca: los enjambres junto a la Tierra"],
  camFar: ["Weit: mit GPS-Schalen und geostationärem Ring", "Far: with the GPS shells and the geostationary ring", "Lejos: con las capas GPS y el anillo geoestacionario"],
  dotSize: ["Größe der Punkte", "Dot size", "Tamaño de los puntos"],
  dotSmall: ["Klein", "Small", "Pequeño"],
  dotNormal: ["Normal", "Normal", "Normal"],
  dotLarge: ["Groß", "Large", "Grande"],
  labels: ["ISS, Tiangong, Hubble und Starlink-Züge beschriften", "Label the ISS, Tiangong, Hubble and Starlink trains", "Rotular la ISS, Tiangong, Hubble y los trenes Starlink"],
  orbits: ["Bahn der Raumstationen und Starlink-Züge zeigen", "Show the orbit of the space stations and Starlink trains", "Mostrar la órbita de las estaciones y trenes Starlink"],
  panel: ["Seitenleiste mit Uhrzeit, Zahlen und den nächsten Überflügen", "Side panel with time, numbers and the next passes", "Panel lateral con hora, cifras y los próximos pasos"],
  groupsTitle: ["Welche Satelliten", "Which satellites", "Qué satélites"],
  gStarlink: ["Starlink", "Starlink", "Starlink"],
  gOneweb: ["OneWeb", "OneWeb", "OneWeb"],
  gNavigation: ["Navigation (GPS, Galileo, GLONASS, BeiDou)", "Navigation (GPS, Galileo, GLONASS, BeiDou)", "Navegación (GPS, Galileo, GLONASS, BeiDou)"],
  gEarth: ["Wetter & Erdbeobachtung", "Weather & Earth observation", "Meteorología y observación"],
  gStations: ["Raumstationen (ISS, Tiangong)", "Space stations (ISS, Tiangong)", "Estaciones espaciales (ISS, Tiangong)"],
  gScience: ["Wissenschaft (Hubble & Co.)", "Science (Hubble etc.)", "Ciencia (Hubble y otros)"],
  gComms: ["Kommunikation & geostationärer Ring", "Communication & geostationary ring", "Comunicaciones y anillo geoestacionario"],
  gOther: ["Sonstige", "Other", "Otros"],
  showHint: ["Satelliten im Erdschatten leuchten schwächer. Die Erde zeigt Tag und Nacht nach dem echten Sonnenstand; im Himmel über deinem Haus steht Norden oben und Osten links, wie wenn man nach oben schaut.",
    "Satellites in the Earth's shadow glow fainter. The Earth shows day and night by the real position of the sun; in the sky above your home north is at the top and east on the left, as when you look up.",
    "Los satélites en la sombra de la Tierra brillan menos. La Tierra muestra el día y la noche según la posición real del sol; en el cielo sobre tu casa el norte está arriba y el este a la izquierda, como al mirar hacia arriba."],
  announceTitle: ["Überflüge ansagen", "Announce passes", "Anunciar pasos"],
  announceHint: ["Fliegt einer dieser Satelliten über deinen Ort, zeigt die Szene oben eine Ansage, etwa „Jetzt fliegt die ISS über dich – schau nach Südwesten“, vorher eine Vorwarnung.",
    "When one of these satellites passes over your place, the scene shows an announcement at the top, such as “Right now the ISS is passing over you – look south-west”, with a heads-up before.",
    "Cuando uno de estos satélites pasa sobre tu lugar, la escena muestra un aviso arriba, por ejemplo «Ahora pasa la ISS sobre ti – mira hacia el suroeste», con un aviso previo."],
  aIss: ["ISS", "ISS", "ISS"],
  aCss: ["Tiangong (chinesische Raumstation)", "Tiangong (Chinese space station)", "Tiangong (estación espacial china)"],
  aHst: ["Hubble-Teleskop", "Hubble telescope", "Telescopio Hubble"],
  aTrains: ["Frische Starlink-Züge (Perlenkette)", "Fresh Starlink trains (string of pearls)", "Trenes Starlink recién lanzados (collar de perlas)"],
  minEl: ["Nur wenn er mindestens so hoch steigt", "Only if it climbs at least this high", "Solo si sube al menos a esta altura"],
  when: ["Welche Überflüge", "Which passes", "Qué pasos"],
  whenAll: ["Alle, auch am Tag", "All, also in daylight", "Todos, también de día"],
  whenVisible: ["Nur mit bloßem Auge sichtbare", "Only those visible to the naked eye", "Solo los visibles a simple vista"],
  lead: ["Vorwarnung", "Heads-up", "Aviso previo"],
  lead0: ["Keine", "None", "Ninguno"],
  lead2: ["2 Minuten vorher", "2 minutes before", "2 minutos antes"],
  lead5: ["5 Minuten vorher", "5 minutes before", "5 minutos antes"],
  lead10: ["10 Minuten vorher", "10 minutes before", "10 minutos antes"],
  lead15: ["15 Minuten vorher", "15 minutes before", "15 minutos antes"],
  skyOnPass: ["Während eines Überflugs den Himmel über deinem Haus zeigen", "Show the sky above your home during a pass", "Mostrar el cielo sobre tu casa durante un paso"],
  visibleHint: ["Sichtbar ist ein Satellit, wenn er noch in der Sonne steht, während es bei dir schon dunkel ist, also in der Dämmerung und am Abend. Die ISS ist dann heller als fast jeder Stern.",
    "A satellite is visible when it is still in sunlight while it is already dark where you are, so at dusk and in the evening. The ISS is then brighter than almost any star.",
    "Un satélite es visible cuando aún le da el sol mientras donde estás ya es de noche, es decir, al anochecer. La ISS brilla entonces más que casi cualquier estrella."],
  takeoverTitle: ["Über die Playlist legen", "Put over the playlist", "Poner sobre la playlist"],
  takeoverHint: ["Läuft gerade etwas anderes, kann das Plugin einen angesagten Überflug für ein paar Minuten über die Playlist legen und danach zurückgeben. Dafür muss auf der Plugins-Seite bei Satellite Swarm „Übernahme erlauben“ eingeschaltet sein.",
    "If something else is playing, the plugin can put an announced pass over the playlist for a few minutes and then hand the screen back. For that, switch on “Allow takeover” for Satellite Swarm on the Plugins page.",
    "Si se está reproduciendo otra cosa, el plugin puede poner un paso anunciado sobre la playlist unos minutos y luego devolver la pantalla. Para ello activa «Permitir toma de control» para Satellite Swarm en la página de plugins."],
  takeover: ["Überflug über die Playlist legen", "Put a pass over the playlist", "Poner el paso sobre la playlist"],
  toOff: ["Nein", "No", "No"],
  toVisible: ["Nur sichtbare Überflüge", "Only visible passes", "Solo pasos visibles"],
  toAll: ["Alle angesagten Überflüge", "All announced passes", "Todos los pasos anunciados"],
  wake: ["Dafür auch einen ausgeschalteten Bildschirm einschalten", "Also switch on a screen that is off", "Encender también una pantalla apagada"],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una playlist para ello"],
  makePlaylist: ["Playlist „Satellite Swarm“ anlegen", "Create the “Satellite Swarm” playlist", "Crear la playlist «Satellite Swarm»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la playlist (segundos)"],
  playlistHint: ["Die Playlist enthält nur die Szene und ist eingeschaltet. Die Dauer gilt beim Anlegen; danach änderst du sie in der Playlist selbst. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist contains only the scene and is switched on. The duration applies when it is created; after that you change it in the playlist itself. You can also add the scene to any playlist yourself.",
    "La playlist contiene solo la escena y está activada. La duración se aplica al crearla; después la cambias en la propia playlist. También puedes añadir la escena a cualquier playlist."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or wishes?", "¿Problemas, preguntas o deseos?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre un issue en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", ", with plugin name and version.", ", con el nombre y la versión del plugin."],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin is not responding.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status}).", "Error (HTTP {status}).", "Error (HTTP {status})."]
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? row[LANGS.indexOf(lang)] ?? row[0] : key;
  if (typeof text !== "string") return text;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function hhmm(epoch) {
  return new Date(epoch * 1000).toLocaleTimeString(LOCALES[lang], { hour: "2-digit", minute: "2-digit" });
}

function clock(epoch) {
  if (!epoch) return "—";
  const date = new Date(epoch * 1000);
  const time = t("oclock", { time: hhmm(epoch) });
  return date.toDateString() === new Date().toDateString() ? time
    : `${date.toLocaleDateString(LOCALES[lang], { day: "2-digit", month: "2-digit" })} ${time}`;
}

function dayPrefix(epoch) {
  const d = new Date(epoch * 1000), today = new Date();
  if (d.toDateString() === today.toDateString()) return t("today");
  if (d.toDateString() === new Date(today.getTime() + 86400000).toDateString()) return t("tomorrow");
  return d.toLocaleDateString(LOCALES[lang], { weekday: "short", day: "2-digit", month: "2-digit" }) + " ";
}

const esc = (text) => String(text).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang]);
const dirName = (az) => t("dirs")[Math.round(((az % 360) + 360) % 360 / 45) % 8];

function passName(p) {
  return String(p.key).startsWith("train") ? t("trainName", { n: p.train || "" }) : p.name;
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  const hasPlace = s.Lat !== null && s.Lon !== null;
  el("factSats").textContent = state.satellites ? fmt(state.satellites) : (state.busy ? t("fetching") : t("waitData"));
  el("factAbove").textContent = !hasPlace ? t("noPlaceShort")
    : state.above ? t("aboveValue", { n: fmt(state.above.total), lit: fmt(state.above.sunlit) }) : "—";
  const passes = state.passes || [];
  const next = passes.find((p) => p.announce && !p.test);
  el("factNext").textContent = !hasPlace ? t("noPlaceShort") : next
    ? `${passName(next)}, ${dayPrefix(next.start)}${t("oclock", { time: hhmm(next.start) })}` : (state.satellites ? t("noPass") : "—");
  el("factRead").textContent = clock(state.fetchedAt);
  el("factVersion").textContent = state.version;
  if (state.error && !el("statusNote").classList.contains("ok")) setStatus(t("errorNote", { error: state.error }), "bad");
  const rows = passes.filter((p) => !p.test).slice(0, 8);
  el("passBox").hidden = !rows.length;
  el("passList").innerHTML = rows.map((p) => {
    const badges = [p.visible ? t("visible") : "", p.takeover ? t("takeoverBadge") : "", p.announce ? "" : t("notAnnounced")].filter(Boolean).join(" · ");
    return `<li><span>${esc(passName(p))}<span class="w">${esc(t("passRow", { day: dayPrefix(p.start), start: hhmm(p.start), end: hhmm(p.end), el: Math.round(p.maxEl), dir: dirName(p.azMax) }))}</span></span><span class="v${p.visible ? " hi" : ""}">${esc(badges)}</span></li>`;
  }).join("");
  el("placeNote").textContent = hasPlace ? t("placeSet", { place: s.PlaceName || "—", lat: s.Lat, lon: s.Lon }) : t("placeMissing");
  for (let k = 0; k < GROUP_FIELDS.length; k += 1) {
    const n = (state.counts || {})[GROUP_KEYS[k]];
    el("count" + GROUP_FIELDS[k]).textContent = n ? fmt(n) : "";
  }
  el("takeoverNote").textContent = state.takeoverNote || "";
  if (document.activeElement !== el("MakePlaylist")) el("MakePlaylist").value = String(Boolean(s.MakePlaylist));
  el("playlistNote").textContent = state.ownPlaylist || "";
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Satellite Swarm ${state.version}] `);
  if (!editing) {
    for (const name of NUMBER_FIELDS) if (document.activeElement !== el(name)) el(name).value = s[name];
    for (const name of TEXT_FIELDS) if (document.activeElement !== el(name)) el(name).value = s[name] || "";
    for (const name of ["Lat", "Lon"]) if (document.activeElement !== el(name)) el(name).value = s[name] === null ? "" : String(s[name]);
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) if (document.activeElement !== el(name)) el(name).value = String(s[name]);
    el("Language").value = lang;
  }
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

async function findPlace() {
  const q = el("PlaceSearch").value.trim();
  const box = el("PlaceResults");
  if (q.length < 2) return;
  box.hidden = false;
  box.textContent = t("placeSearching");
  try {
    const result = await api("./api/places?q=" + encodeURIComponent(q));
    box.textContent = "";
    if (!result.places.length) { box.textContent = t("placeNone"); return; }
    for (const place of result.places) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "secondary place";
      button.textContent = place.region ? `${place.name} (${place.region})` : place.name;
      button.addEventListener("click", async () => {
        box.hidden = true;
        box.textContent = "";
        el("PlaceSearch").value = "";
        await save({ PlaceName: place.name, Lat: place.lat, Lon: place.lon });
      });
      box.appendChild(button);
    }
  } catch (error) {
    box.textContent = error.message;
  }
}

for (const name of [...NUMBER_FIELDS, ...TEXT_FIELDS, "Lat", "Lon"]) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
  input.addEventListener("change", (e) => {
    const value = e.target.value;
    save({ [name]: NUMBER_FIELDS.includes(name) ? Number(value) : value });
  });
}
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save({ Language: e.target.value });
});
el("placeButton").addEventListener("click", findPlace);
el("PlaceSearch").addEventListener("keydown", (e) => { if (e.key === "Enter") findPlace(); });
for (const [id, path] of [["refreshButton", "./api/refresh"], ["testButton", "./api/test"]]) {
  el(id).addEventListener("click", async () => {
    try {
      const result = await api(path, { method: "POST" });
      setStatus(result.message || "", "busy");
      setTimeout(refresh, 3000);
    } catch (error) {
      setStatus(error.message, "bad");
    }
  });
}
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));

refresh();
setInterval(refresh, 5000);
