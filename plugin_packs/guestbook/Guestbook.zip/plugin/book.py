"""Guestbook: das Buch selbst (Einträge, Feiern, Erinnerungen), ohne HTTP und ohne Engine.

Alles liegt in data/book/:
  meta.json     Code für die Gäste, laufende Nummer (seq), laufende Feier
  entries.json  alle Einträge (Name, Gruß, Selfie ja/nein, Tag, Feier)
  events.json   Feiern im Party-Modus (Name, Beginn, Ende)
  photos/       <eintrag>.jpg (lange Seite 1600) und <eintrag>.t.jpg (Vorschau 400)

Ein Eintrag gehört zu einer Feier, wenn er während der Feier entsteht. Er
bleibt auch nach der Feier im Buch und kommt Jahre später als Erinnerung
wieder („Heute vor 3 Jahren …“).
"""

import datetime
import hashlib
import json
import random
import re
import secrets
import shutil
import threading
import time
from pathlib import Path

MAX_ENTRIES = 20000
COLORS = ("#c2410c", "#0f766e", "#7c3aed", "#be123c", "#1d4ed8", "#a16207", "#15803d", "#9333ea",
          "#b45309", "#0e7490", "#c026d3", "#4d7c0f")
SEPARATORS = re.compile(r"\s*(?:,|&|\+|/|\bund\b|\band\b|\by\b|\be\b)\s*", re.IGNORECASE)


def now():
    return time.time()


def clean_text(value, limit, lines=False):
    text = str(value or "")
    if lines:
        text = re.sub(r"\r\n?", "\n", text)
        text = re.sub(r"[\x00-\x09\x0b-\x1f\x7f<>]", "", text)
        text = "\n".join(re.sub(r"[ \t]+", " ", row).strip() for row in text.split("\n"))
        text = re.sub(r"\n{3,}", "\n\n", text).strip()
        return text[:limit]
    text = re.sub(r"[\x00-\x1f\x7f<>]", "", text)
    return re.sub(r"\s+", " ", text).strip()[:limit]


def name_key(name):
    return re.sub(r"\s+", " ", str(name or "")).strip().casefold()


def people(name):
    """„Anke & Bernd“ -> 2, „Familie Müller“ -> 1 (für war/waren)."""
    parts = [p for p in SEPARATORS.split(str(name or "")) if p and p.strip()]
    return max(1, len(parts))


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


def write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)


def new_code():
    return f"{secrets.randbelow(9000) + 1000}"


def day_of(epoch):
    return datetime.datetime.fromtimestamp(epoch).strftime("%Y-%m-%d")


def device_hash(device):
    device = str(device or "")
    if not re.match(r"^[A-Za-z0-9_-]{8,64}$", device):
        return ""
    return hashlib.sha256(("guestbook:" + device).encode()).hexdigest()[:24]


def free_bytes(folder):
    try:
        return shutil.disk_usage(folder).free
    except OSError:
        return 1 << 40


class Book:
    """Das Gästebuch. Alle Methoden halten self.lock selbst."""

    def __init__(self, folder):
        self.folder = Path(folder)
        self.lock = threading.RLock()
        self.folder.mkdir(parents=True, exist_ok=True)
        (self.folder / "photos").mkdir(exist_ok=True)
        meta = read_json(self.folder / "meta.json", None)
        if not isinstance(meta, dict):
            meta = {"code": new_code(), "seq": 0, "event": ""}
            write_json(self.folder / "meta.json", meta)
        self.meta = meta
        entries = read_json(self.folder / "entries.json", []) or []
        self.entries = [e for e in entries if isinstance(e, dict) and e.get("id")]
        events = read_json(self.folder / "events.json", []) or []
        self.events = [e for e in events if isinstance(e, dict) and e.get("id")]
        self.shown = {}            # Eintrag -> wie oft die Szene ihn seit dem Start gezeigt hat
        self._dirty = 0.0

    # ---- Speichern -------------------------------------------------------

    def save(self, what=("meta", "entries", "events")):
        with self.lock:
            if "meta" in what:
                write_json(self.folder / "meta.json", self.meta)
            if "entries" in what:
                write_json(self.folder / "entries.json", self.entries)
            if "events" in what:
                write_json(self.folder / "events.json", self.events)

    def set_meta(self, **fields):
        with self.lock:
            self.meta.update(fields)
            self.save(("meta",))

    @property
    def code(self):
        return str(self.meta.get("code") or "")

    @property
    def seq(self):
        return int(self.meta.get("seq") or 0)

    def photo_dir(self):
        return self.folder / "photos"

    # ---- Einträge --------------------------------------------------------

    def find(self, ident):
        with self.lock:
            return next((e for e in self.entries if e["id"] == ident), None)

    def visible(self, event=None):
        with self.lock:
            rows = [e for e in self.entries if e.get("st") == "ok"]
            if event is not None:
                rows = [e for e in rows if e.get("ev") == event]
            return rows

    def color_for(self, key):
        digest = hashlib.sha256(key.encode()).digest()
        return COLORS[digest[0] % len(COLORS)]

    def add(self, name, text, device, has_photo, w, h, approved, at=None):
        with self.lock:
            if len(self.entries) >= MAX_ENTRIES:
                raise ValueError("full")
            at = at or now()
            ident = time.strftime("%Y%m%d-%H%M%S-", time.localtime(at)) + secrets.token_hex(3)
            seq = self.seq + 1
            name = clean_text(name, 60)
            key = name_key(name)
            row = {"id": ident, "seq": seq, "at": round(at, 1), "day": day_of(at), "name": name, "key": key,
                   "text": clean_text(text, 400, lines=True), "photo": bool(has_photo), "w": int(w or 0),
                   "h": int(h or 0), "st": "ok" if approved else "wait", "ev": self.meta.get("event") or "",
                   "dev": device_hash(device), "color": self.color_for(key or ident)}
            self.entries.append(row)
            self.meta["seq"] = seq
            self.save(("meta", "entries"))
            return row

    def update(self, ident, **fields):
        with self.lock:
            row = self.find(ident)
            if not row:
                return None
            if "name" in fields:
                row["name"] = clean_text(fields["name"], 60)
                row["key"] = name_key(row["name"])
                row["color"] = self.color_for(row["key"] or ident)
            if "text" in fields:
                row["text"] = clean_text(fields["text"], 400, lines=True)
            if fields.get("st") in ("ok", "wait", "hidden"):
                row["st"] = fields["st"]
                if row["st"] == "ok":
                    # erst jetzt freigegeben: für die Szene ist er neu
                    self.meta["seq"] = self.seq + 1
                    row["seq"] = self.meta["seq"]
            if "day" in fields and re.match(r"^\d{4}-\d{2}-\d{2}$", str(fields["day"] or "")):
                try:
                    old = datetime.datetime.fromtimestamp(row["at"])
                    new = datetime.datetime.strptime(fields["day"], "%Y-%m-%d").replace(
                        hour=old.hour, minute=old.minute, second=old.second)
                    row["at"] = round(new.timestamp(), 1)
                    row["day"] = fields["day"]
                except ValueError:
                    pass
            self.save(("meta", "entries"))
            return row

    def delete(self, ident):
        with self.lock:
            row = self.find(ident)
            if not row:
                return False
            self.entries.remove(row)
            self.save(("entries",))
        for suffix in (".jpg", ".t.jpg"):
            try:
                (self.photo_dir() / f"{ident}{suffix}").unlink()
            except OSError:
                pass
        return True

    def mine(self, ident, device):
        row = self.find(ident)
        digest = device_hash(device)
        return row if row and digest and row.get("dev") == digest else None

    def fresh(self, since):
        with self.lock:
            return [e for e in self.entries if e.get("st") == "ok" and e.get("seq", 0) > since]

    # ---- Namen, Besuche ---------------------------------------------------

    def visit_number(self, row):
        """Der wievielte Besuchstag dieses Namens ist der Tag des Eintrags (1 = erster)."""
        if not row.get("key"):
            return 1
        with self.lock:
            days = sorted({e["day"] for e in self.entries if e.get("key") == row["key"] and e.get("st") != "hidden"})
        return (days.index(row["day"]) + 1) if row["day"] in days else len(days) + 1

    def first_visit(self, row):
        with self.lock:
            days = [e["day"] for e in self.entries if e.get("key") == row.get("key") and e.get("st") != "hidden"]
        return min(days) if days else row.get("day")

    def stats(self, year=None):
        with self.lock:
            rows = [e for e in self.entries if e.get("st") == "ok"]
            year = year or time.strftime("%Y")
            return {
                "entries": len(rows),
                "guests": len({e["key"] for e in rows if e.get("key")}),
                "visitDays": len({e["day"] for e in rows if not e.get("ev")}),
                "year": len({(e["key"], e["day"]) for e in rows if e["day"].startswith(str(year))}),
                "waiting": sum(1 for e in self.entries if e.get("st") == "wait"),
                "photos": sum(1 for e in rows if e.get("photo")),
                "events": len(self.events),
            }

    # ---- Was die Szene als Nächstes zeigt --------------------------------

    def pick(self, exclude=(), event=None):
        rows = [e for e in self.visible(event) if e["id"] not in exclude] or self.visible(event)
        if not rows:
            return None
        newest = max(e["at"] for e in rows)
        weights = []
        for row in rows:
            age_days = max(0.0, (newest - row["at"]) / 86400)
            fresh = 1.0 + 2.0 / (1.0 + age_days / 30)          # neuere etwas öfter
            photo = 1.4 if row.get("photo") else 1.0
            weights.append(fresh * photo / (1 + self.shown.get(row["id"], 0)) ** 1.2)
        row = random.choices(rows, weights=weights, k=1)[0]
        self.shown[row["id"]] = self.shown.get(row["id"], 0) + 1
        return row

    # ---- Erinnerungen ------------------------------------------------------

    def memories(self, today=None):
        """Einträge früherer Jahre am selben Tag, je Jahr gebündelt (neueste Jahre zuerst)."""
        today = today or datetime.date.today()
        days = {today.strftime("%m-%d")}
        if today.month == 2 and today.day == 28 and not is_leap(today.year):
            days.add("02-29")                                  # 29. Februar kommt am 28. wieder
        by_year = {}
        with self.lock:
            for row in self.entries:
                if row.get("st") != "ok" or row["day"][5:] not in days:
                    continue
                year = int(row["day"][:4])
                if year >= today.year:
                    continue
                by_year.setdefault(year, []).append(row)
        out = []
        for year in sorted(by_year, reverse=True):
            rows = sorted(by_year[year], key=lambda e: e["at"])
            events = {}
            visits = []
            for row in rows:
                (events.setdefault(row["ev"], []) if row.get("ev") else visits).append(row)
            for ident, members in events.items():
                event = self.event(ident) or {}
                out.append({"years": today.year - year, "year": year, "kind": "event", "event": ident,
                            "title": event.get("title") or "", "count": len(members),
                            "names": unique_names(members), "entries": members})
            if visits:
                out.append({"years": today.year - year, "year": year, "kind": "visit",
                            "names": unique_names(visits), "people": sum(people(n) for n in unique_names(visits)),
                            "entries": visits})
        return out

    def upcoming(self, days=30, today=None):
        """Für die Plugin-Seite: an welchen der nächsten Tage es Erinnerungen gibt."""
        today = today or datetime.date.today()
        out = []
        for offset in range(1, days + 1):
            day = today + datetime.timedelta(days=offset)
            found = self.memories(day)
            if found:
                out.append({"date": day.isoformat(), "items": [{k: v for k, v in m.items() if k != "entries"}
                                                                  for m in found]})
        return out

    # ---- Feiern (Party-Modus) ------------------------------------------------

    def event(self, ident):
        with self.lock:
            return next((e for e in self.events if e["id"] == ident), None)

    def current_event(self):
        ident = self.meta.get("event") or ""
        return self.event(ident) if ident else None

    def start_event(self, title, hours):
        with self.lock:
            ident = time.strftime("%Y%m%d-%H%M-") + secrets.token_hex(2)
            row = {"id": ident, "title": clean_text(title, 60), "started": round(now()), "ended": 0,
                   "hours": int(hours)}
            self.events.append(row)
            self.meta["event"] = ident
            self.save(("meta", "events"))
            return row

    def end_event(self):
        with self.lock:
            row = self.current_event()
            self.meta["event"] = ""
            if row:
                row["ended"] = round(now())
            self.save(("meta", "events"))
            return row

    def rename_event(self, ident, title):
        with self.lock:
            row = self.event(ident)
            if not row:
                return False
            row["title"] = clean_text(title, 60)
            self.save(("events",))
            return True

    def delete_event(self, ident, with_entries):
        with self.lock:
            row = self.event(ident)
            if not row or ident == self.meta.get("event"):
                return False
            self.events.remove(row)
            members = [e["id"] for e in self.entries if e.get("ev") == ident]
            if not with_entries:
                for entry in self.entries:
                    if entry.get("ev") == ident:
                        entry["ev"] = ""
            self.save(("events", "entries"))
        if with_entries:
            for member in members:
                self.delete(member)
        return True

    def event_rows(self):
        with self.lock:
            out = []
            for event in sorted(self.events, key=lambda e: -e["started"]):
                members = [e for e in self.entries if e.get("ev") == event["id"]]
                out.append(dict(event, count=sum(1 for e in members if e.get("st") == "ok"),
                                waiting=sum(1 for e in members if e.get("st") == "wait"),
                                running=event["id"] == self.meta.get("event")))
            return out


def is_leap(year):
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)


def unique_names(rows):
    seen, names = set(), []
    for row in rows:
        key = row.get("key") or ""
        if key and key not in seen:
            seen.add(key)
            names.append(row["name"])
    return names
