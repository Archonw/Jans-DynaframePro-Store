# YouTube Cast

YouTube Cast macht den Rahmen zu einem Ziel für den **Streamen-Knopf der YouTube-App**, wie einen Fernseher: am Handy auf Streamen tippen, den Rahmen auswählen, und das Video läuft auf dem Rahmen. Die App ist dann die Fernbedienung (Pause, Spulen, Lautstärke, Warteschlange). Ist das Video zu Ende oder gestoppt, läuft die Playlist weiter.

Das Paket besteht aus zwei Teilen:

- **Das Plugin** meldet den Rahmen bei YouTube als Bildschirm an (wie ein Smart-TV), antwortet der App im WLAN (DIAL/SSDP) und nimmt Links an.
- **Die Szene YouTube Cast** spielt das Video mit dem eingebetteten Player von YouTube und wird nur gezeigt, solange ein Video läuft.

## Einrichten

1. Paket installieren (Store oder Plugins > Hochladen).
2. Auf der Plugins-Seite bei YouTube Cast **Allow takeover** einschalten.
3. Fertig. In der YouTube-App (gleiches WLAN) erscheint der Rahmen als **DynaFrame** im Streamen-Menü. Den Namen kann man auf der Plugin-Seite ändern.

Findet die App den Rahmen nicht (z. B. weil das WLAN Multicast blockiert): auf der Plugin-Seite **TV-Code anzeigen** und in der YouTube-App unter *Du → Einstellungen → Auf TV ansehen → Mit TV-Code verknüpfen* eingeben. Danach steht der Rahmen dauerhaft in der Liste.

## Links senden

- Auf der Plugin-Seite einen Link einfügen.
- Auf dem Handy die Senden-Seite `http://<rahmen>:8090/` öffnen (zum Home-Bildschirm hinzufügen).
- iPhone: ein Kurzbefehl im Teilen-Menü (Anleitung auf der Plugin-Seite) schickt den Link per `POST http://<rahmen>:8090/send` mit dem Feld `url`.
- Für eigene Automationen: `GET http://<rahmen>:8090/api/send?url=<link>`.

Eine Startzeit im Link (`t=90`, `t=1m30s`) wird übernommen.

## Grenzen

- Der Rahmen braucht Internet; abgespielt wird über den eingebetteten YouTube-Player. Videos, deren Kanal das Einbetten verbietet (oft Musikvideos), gehen nicht; dann erscheint ein Hinweis.
- Werbung kann vorkommen. YouTube Music wird nicht unterstützt.
- Erlaubt der Rahmen keinen Ton ohne Berührung, startet das Video stumm (Hinweis auf dem Bildschirm).
- Ports: UDP 1900 (SSDP) und TCP 8090 (DIAL und Senden-Seite; ist 8090 belegt, 8091–8093).

Der Cast-Empfänger folgt dem quelloffenen yt-cast-receiver (MIT, Patrick Kan). YouTube ist eine Marke von Google; dieses Plugin ist kein Produkt von Google.
