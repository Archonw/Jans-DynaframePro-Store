#!/usr/bin/env python3
"""Party Wall - der Plugin-Teil des Pakets "party-wall".

Die Szene "party-wall" ist eine Fotowand für Feiern: Auf dem Fernseher steht
ein QR-Code, Gäste öffnen damit eine Seite dieses Plugins im WLAN (Port
8110), laden Fotos vom Abend hoch und reagieren mit Emojis, die über den
Fernseher fliegen. Zwischendurch und am Ende zeigt die Wand die beliebtesten
Fotos (Rückschau).

Dieses Plugin
- nimmt die Fotos der Gäste an (dreht sie richtig, verkleinert sie, wirft die
  Metadaten wie GPS weg) und hebt sie je Party auf,
- zählt die Reaktionen und wählt, welches Foto die Wand gerade zeigt,
- holt die Wand auf Wunsch auf den Fernseher (Takeover) und
- zeigt die Plugin-Seite (Party, Gäste, Fotos freigeben/löschen, ZIP).
"""

import datetime
import io
import json
import os
import re
import socket
import sys
import tempfile
import threading
import time
import zipfile
from email.parser import BytesParser
from email.policy import HTTP
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import own_playlist  # noqa: E402
import party as partylib  # noqa: E402
import texts  # noqa: E402

try:
    import playback_guard  # noqa: E402
except Exception:  # noqa: BLE001 - nur ein Behelf, darf fehlen
    playback_guard = None

try:
    from PIL import Image, ImageOps
except ImportError:  # pragma: no cover - kommt mit requirements.txt
    Image = ImageOps = None

HEIF = False
if Image is not None:
    try:
        from pillow_heif import register_heif_opener  # type: ignore

        register_heif_opener()
        HEIF = True
    except Exception:  # noqa: BLE001 - optional
        HEIF = False

plugin = create_plugin()

PLUGIN_ID = "PartyWall"
SCENE_ID = "party-wall"              # id in scene.dynamic - nie ändern
DISPLAY_NAME = "Party Wall"
PLAYLIST_NAMES = {"de": "Party Wall", "en": "Party Wall", "es": "Party Wall"}
TAKEOVER_PLAYLIST_NAME = "Party Wall (takeover)"
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"       # Einstellungen, Partys; bleibt bei Updates
PARTY_ROOT = DATA_DIR / "parties"

CONNECT_TIMEOUT = 10
PHONE_PORTS = (8110, 8111, 8112, 8113)
SCENE_GONE = 8                       # so lange ohne Frage der Szene: sie ist nicht zu sehen
FULL_EDGE = 1920
THUMB_EDGE = 480
MAX_UPLOAD = 40 * 1024 * 1024
MAX_PHOTOS = 3000
UPLOADS_PER_MINUTE = 40
MIN_FREE = 300 * 1024 * 1024
TOP_SECONDS = 32                     # so lange steht die Hitliste zwischendurch
TOP_MIN = 3                          # so viele Fotos mit Reaktionen braucht sie


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def read_json(path, default):
    return partylib.read_json(path, default)


def write_json(path, payload):
    partylib.write_json(path, payload)


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

SCHEMA = {
    "Language":        {"kind": "choice", "default": "en", "choices": texts.LANGUAGES},
    "Theme":           {"kind": "choice", "default": "party", "choices": ("party", "elegant", "bright")},
    "Style":           {"kind": "choice", "default": "polaroid", "choices": ("polaroid", "full")},
    "SlideSeconds":    {"kind": "int", "default": 10, "min": 4, "max": 60},
    "ShowNames":       {"kind": "bool", "default": True},
    "ShowCaptions":    {"kind": "bool", "default": True},
    "FlyNames":        {"kind": "bool", "default": True},
    "TopEvery":        {"kind": "int", "default": 20, "min": 0, "max": 120},
    "RecapCount":      {"kind": "int", "default": 10, "min": 3, "max": 30},
    "RecapAt":         {"kind": "clock", "default": ""},
    "Uploads":         {"kind": "bool", "default": True},
    "Gallery":         {"kind": "bool", "default": True},
    "Approve":         {"kind": "bool", "default": False},
    "PartyHours":      {"kind": "int", "default": 6, "min": 1, "max": 24},
    "WakeScreen":      {"kind": "bool", "default": True},
    "PlaylistSeconds": {"kind": "int", "default": 3600, "min": 60, "max": 86400},
    "MakePlaylist":    {"kind": "bool", "default": False},
}
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()
_settings_cache = {"at": 0.0, "values": None}


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "choice":
        value = str(raw or "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "clock":
        match = re.match(r"^\s*(\d{1,2})[:.](\d{2})\s*$", str(raw or ""))
        if not match or int(match.group(1)) > 23 or int(match.group(2)) > 59:
            return ""
        return f"{int(match.group(1)):02d}:{match.group(2)}"
    return partylib.clean_text(raw, 80)


def settings():
    # Die Szene und die Handys fragen oft: kurz zwischenspeichern.
    cached = _settings_cache["values"]
    if cached is not None and now() - _settings_cache["at"] < 1.0:
        return dict(cached)
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    values = {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}
    _settings_cache.update(at=now(), values=values)
    return dict(values)


def save_settings(changes):
    with _settings_lock:
        _settings_cache["values"] = None
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        _settings_cache["values"] = None
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 60))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


# --------------------------------------------------------------------------
# Die Party
# --------------------------------------------------------------------------

CURRENT_FILE = DATA_DIR / "current.json"
_party_lock = threading.RLock()
party = None
_scene = {"seen": 0.0}


def load_party():
    global party
    ident = (read_json(CURRENT_FILE, {}) or {}).get("id")
    folder = PARTY_ROOT / str(ident or "-")
    if ident and (folder / "meta.json").exists():
        party = partylib.Party(folder)
    else:
        party = partylib.Party.create(PARTY_ROOT)
        write_json(CURRENT_FILE, {"id": party.ident})
        log(f"Neue Party {party.ident} angelegt.")


def new_party(title):
    global party
    with _party_lock:
        old = party
        if old is not None:
            old.save()
        party = partylib.Party.create(PARTY_ROOT, title)
        write_json(CURRENT_FILE, {"id": party.ident})
    log(f"Neue Party {party.ident} „{party.meta.get('title') or ''}“ begonnen.")
    return {"success": True, "id": party.ident}


def scene_visible(t=None):
    return (t or now()) - _scene["seen"] < SCENE_GONE


# ---- Fotos annehmen -------------------------------------------------------

class PhotoError(Exception):
    pass


IMAGE_BRANDS = (b"heic", b"heix", b"hevc", b"heim", b"heis", b"mif1", b"msf1", b"avif", b"avis")


def sniff(data):
    head = data[:16]
    if head.startswith(b"\xff\xd8\xff"):
        return "jpeg"
    if head.startswith(b"\x89PNG"):
        return "png"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "webp"
    if head[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if head[4:8] == b"ftyp":
        return "heic" if head[8:12] in IMAGE_BRANDS else "video"
    return ""


def prepare(data):
    """Drehen wie aufgenommen, verkleinern, als JPEG ohne Metadaten. (full, thumb, w, h)"""
    kind = sniff(data)
    if kind == "video":
        raise PhotoError(tr("Videos gehen hier nicht, nur Fotos."))
    if not kind:
        raise PhotoError(tr("Das ist kein Foto, das der Rahmen lesen kann."))
    if Image is None:
        raise PhotoError(tr("Auf dem Rahmen fehlt Pillow; installiere das Paket noch einmal."))
    if kind == "heic" and not HEIF:
        raise PhotoError(tr("HEIC-Fotos kann der Rahmen nicht lesen. Stell am iPhone unter Kamera › Formate "
                            "„Maximale Kompatibilität“ ein."))
    try:
        image = Image.open(io.BytesIO(data))
        image.draft("RGB", (FULL_EDGE * 2, FULL_EDGE * 2))     # große JPEGs schneller laden
        image = ImageOps.exif_transpose(image)
        if image.mode not in ("RGB", "L"):
            background = Image.new("RGB", image.size, (0, 0, 0))
            rgba = image.convert("RGBA")
            background.paste(rgba, mask=rgba.split()[3])
            image = background
        image = image.convert("RGB")
        image.thumbnail((FULL_EDGE, FULL_EDGE), Image.LANCZOS)
        width, height = image.size
        full = io.BytesIO()
        image.save(full, "JPEG", quality=88, optimize=True)      # ohne EXIF: kein GPS, kein Gerät
        small = image.copy()
        small.thumbnail((THUMB_EDGE, THUMB_EDGE), Image.LANCZOS)
        thumb = io.BytesIO()
        small.save(thumb, "JPEG", quality=80)
        return full.getvalue(), thumb.getvalue(), width, height
    except PhotoError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise PhotoError(tr("Konnte das Foto nicht lesen: {exc}", exc=exc)) from exc


_uploads = {}          # Gast -> Zeiten der letzten Uploads
_upload_lock = threading.Semaphore(2)   # der Pi soll nicht zehn Fotos gleichzeitig rechnen


def store_upload(guest_id, data, caption):
    values = settings()
    t = now()
    with party.lock:
        if not values["Uploads"]:
            raise PhotoError(tr("Hochladen ist gerade ausgeschaltet."))
        if guest_id not in party.guests:
            raise PhotoError("unknown")
        recent = [x for x in _uploads.get(guest_id, []) if t - x < 60]
        if len(recent) >= UPLOADS_PER_MINUTE:
            raise PhotoError(tr("Langsam! Höchstens {n} Fotos pro Minute.", n=UPLOADS_PER_MINUTE))
        if len(party.photos) >= MAX_PHOTOS:
            raise PhotoError(tr("Die Wand ist voll ({n} Fotos).", n=MAX_PHOTOS))
        recent.append(t)
        _uploads[guest_id] = recent
    if partylib.free_bytes(DATA_DIR) < MIN_FREE:
        raise PhotoError(tr("Auf dem Rahmen ist kein Platz mehr frei."))
    with _upload_lock:
        full, thumb, width, height = prepare(data)
    folder = party.photo_dir()
    folder.mkdir(parents=True, exist_ok=True)
    row = party.add_photo(guest_id, width, height, caption, approved=not values["Approve"])
    (folder / f"{row['id']}.jpg").write_bytes(full)
    (folder / f"{row['id']}.t.jpg").write_bytes(thumb)
    log(f"Foto {row['id']} von {party.guest_name(guest_id)} ({len(data) // 1024} KB"
        f"{', wartet auf Freigabe' if row['st'] == 'wait' else ''}).")
    return row


def multipart_files(content_type, body):
    message = BytesParser(policy=HTTP).parsebytes(
        b"Content-Type: " + content_type.encode("latin-1") + b"\r\n\r\n" + body)
    files = []
    for part in message.iter_parts() if message.is_multipart() else []:
        payload = part.get_payload(decode=True) or b""
        if payload and (part.get_filename() is not None or sniff(payload)):
            files.append(payload)
    return files


def photo_public(photo, me=None, full=False):
    out = {"id": photo["id"], "w": photo["w"], "h": photo["h"], "at": round(photo["at"]),
           "name": party.guest_name(photo.get("g"), tr("Gast {n}")),
           "color": (party.guests.get(photo.get("g")) or {}).get("color", "#fff"),
           "cap": photo.get("cap") or "", "r": dict(photo.get("r") or {}), "score": partylib.score(photo)}
    if me is not None:
        out["mine"] = photo.get("g") == me
        out["myR"] = (photo.get("by") or {}).get(me, 0)
    if full:
        out["st"] = photo.get("st")
        out["shown"] = photo.get("shown", 0)
    return out


def photo_file(photo_id, size, allow_hidden=False, me=None):
    if not re.match(r"^[0-9A-Za-z-]{6,40}$", photo_id or ""):
        return None
    photo = party.find(photo_id)
    if not photo:
        return None
    if photo.get("st") != "ok" and not allow_hidden and not (me and photo.get("g") == me):
        return None
    path = party.photo_dir() / (f"{photo_id}.t.jpg" if size == "t" else f"{photo_id}.jpg")
    try:
        return path.read_bytes()
    except OSError:
        return None


# ---- Was die Wand zeigt --------------------------------------------------

_recap_check = {"at": 0.0}


def recap_due(values, t):
    """Steht unter „Rückschau um“ eine Uhrzeit, kommt sie einmal von selbst."""
    if not values["RecapAt"]:
        return False
    started = party.meta.get("started") or t
    hour, minute = (int(x) for x in values["RecapAt"].split(":"))
    begin = datetime.datetime.fromtimestamp(started)
    target = begin.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if target.timestamp() <= started:
        target += datetime.timedelta(days=1)
    stamp = target.timestamp()
    return t >= stamp and party.meta.get("recapAuto") != stamp and t - stamp < 6 * 3600 and stamp


def set_recap(on, reason=""):
    with party.lock:
        party.set_meta(recap=bool(on), recapStarted=now() if on else 0)
        party.top_until = 0.0
    log(f"Rückschau {'an' if on else 'aus'}{f' ({reason})' if reason else ''}.")
    return {"success": True}


def step():
    """Zweimal je Sekunde: die Wand weiterschalten."""
    t = now()
    values = settings()
    with party.lock:
        stamp = recap_due(values, t)
        if stamp:
            party.set_meta(recapAuto=stamp)
            set_recap(True, values["RecapAt"])
        party.flush()
        if not scene_visible(t) or party.meta.get("recap"):
            return
        if party.top_until:
            if t < party.top_until:
                return
            party.top_until = 0.0
            party.last_top = t
            party.until = 0.0
        if (values["TopEvery"] and t - party.last_top >= values["TopEvery"] * 60
                and len(party.ranking(TOP_MIN)) >= TOP_MIN and not party.fresh()):
            party.top_until = t + TOP_SECONDS
            return
        current_ok = party.current and (party.find(party.current) or {}).get("st") == "ok"
        due = not current_ok or t >= party.until
        # Ein neues Foto wartet nicht, bis das alte ganz durch ist.
        if not due and party.fresh() and t - party.since >= min(5, values["SlideSeconds"]):
            due = True
        if not due and party.requests and t - party.since >= min(6, values["SlideSeconds"]):
            due = True
        if due:
            party.pick_next(t, values["SlideSeconds"])


def wall_loop():
    while not _stop_requested.is_set():
        try:
            step()
            decide_takeover()
        except Exception as exc:  # noqa: BLE001 - der Faden darf nicht sterben
            log(f"Wand: {exc!r}", "warning")
        _stop_requested.wait(0.5)


def phase(t=None):
    t = t or now()
    with party.lock:
        if party.meta.get("recap"):
            return "recap"
        if not party.visible():
            return "welcome"
        if party.top_until and t < party.top_until:
            return "top"
        return "wall"


def wall_state(since):
    """Was die Szene braucht (sie fragt etwa jede Sekunde)."""
    t = now()
    values = settings()
    with party.lock:
        current = phase(t)
        out = {
            "success": True,
            "lang": values["Language"],
            "phase": current,
            "party": party.ident,
            "title": party.meta.get("title") or "",
            "theme": values["Theme"],
            "style": values["Style"],
            "showNames": values["ShowNames"],
            "showCaptions": values["ShowCaptions"],
            "flyNames": values["FlyNames"],
            "uploads": values["Uploads"],
            "url": phone_url(),
            "code": party.code,
            "stats": party.stats(),
            "takeover": _takeover["handle"] is not None,
        }
        events, seq = party.events_since(since)
        out["seq"] = seq
        out["events"] = [{"s": e["s"], "e": e["e"], "p": e["p"], "c": e["c"],
                          "n": party.guest_name(e["g"], tr("Gast {n}")) if values["FlyNames"] else "",
                          "here": e["p"] == party.current} for e in events if t - e["t"] < 8]
        photo = party.find(party.current) if party.current else None
        if current == "wall" and photo and photo.get("st") == "ok":
            row = photo_public(photo)
            row["new"] = photo.get("shown", 0) <= 1 and t - photo["at"] < 600
            row["left"] = round(max(0.0, party.until - t), 1)
            out["photo"] = row
            fresh = party.fresh()
            if fresh:
                out["next"] = min(fresh, key=lambda p: p["at"])["id"]
        if current == "top":
            out["top"] = [photo_public(p) for p in party.ranking(5)]
            out["left"] = round(max(0.0, party.top_until - t), 1)
        if current == "recap":
            ranking = party.ranking(values["RecapCount"])
            visible = party.visible()
            if len(ranking) < 3:   # kaum Reaktionen: die Rückschau zeigt dann einfach Fotos des Abends
                extra = [p for p in visible if p not in ranking]
                ranking += extra[:max(0, min(values["RecapCount"], 6) - len(ranking))]
            collage = sorted(visible, key=lambda p: (-partylib.score(p), p["at"]))[:24]
            out["recap"] = {"id": int(party.meta.get("recapStarted") or 0),
                            "top": [photo_public(p) for p in ranking],
                            "collage": [{"id": p["id"], "w": p["w"], "h": p["h"]} for p in collage],
                            "started": party.meta.get("started") or 0}
        if current == "wall":
            out["hot"] = [photo_public(p) for p in party.ranking(3)]
    return out


# --------------------------------------------------------------------------
# Handy: beitreten, hochladen, reagieren
# --------------------------------------------------------------------------

def phone_join(body):
    if str(body.get("code") or "").strip() != party.code and str(body.get("id") or "") not in party.guests:
        return {"success": False, "error": "code"}
    known = str(body.get("id") or "")
    ident, guest = party.join(body.get("name"), known if known in party.guests else None)
    if not ident:
        return {"success": False, "error": "full"}
    log(f"Gast: {party.guest_name(ident)}")
    return {"success": True, "id": ident, "party": party.ident}


def phone_state(query):
    t = now()
    values = settings()
    me = (query.get("id") or [""])[0]
    party.touch(me, t)
    with party.lock:
        guest = party.guest(me)
        out = {"success": True, "party": party.ident, "title": party.meta.get("title") or "",
               "lang": values["Language"], "known": bool(guest), "uploads": values["Uploads"],
               "gallery": values["Gallery"], "approve": values["Approve"], "phase": phase(t),
               "visible": scene_visible(t), "stats": party.stats()}
        if not guest:
            return out
        out["me"] = {"name": guest.get("name") or "", "label": party.guest_name(me, tr("Gast {n}")),
                     "color": guest.get("color"), "uploads": guest.get("uploads", 0)}
        current = party.find(party.current) if party.current else None
        if out["phase"] == "wall" and current and current.get("st") == "ok" and out["visible"]:
            out["current"] = photo_public(current, me)
        rows = party.photos if values["Gallery"] else [p for p in party.photos if p.get("g") == me]
        rows = [p for p in rows if p.get("st") == "ok" or p.get("g") == me]
        out["photos"] = [dict(photo_public(p, me), st=p.get("st")) for p in sorted(rows, key=lambda p: -p["at"])]
        if out["phase"] in ("recap", "top"):
            out["top"] = [photo_public(p, me) for p in party.ranking(values["RecapCount"])]
    return out


def phone_react(body):
    me = str(body.get("id") or "")
    ok, flies = party.react(me, str(body.get("photo") or ""), str(body.get("emoji") or ""))
    return {"success": ok, "flies": flies}


def phone_request(body):
    me = str(body.get("id") or "")
    if me not in party.guests:
        return {"success": False, "error": "unknown"}
    return {"success": party.request(str(body.get("photo") or ""))}


def phone_delete(body):
    me = str(body.get("id") or "")
    photo = party.find(str(body.get("photo") or ""))
    if not photo or not me or photo.get("g") != me:
        return {"success": False, "error": "mine"}
    party.delete(photo["id"])
    log(f"{party.guest_name(me)} hat das Foto {photo['id']} gelöscht.")
    return {"success": True}


def lan_address():
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("10.255.255.255", 1))     # schickt nichts, sucht nur die Route
        return probe.getsockname()[0]
    except OSError:
        return ""
    finally:
        probe.close()


_lan = {"at": 0.0, "ip": ""}


def phone_url():
    if now() - _lan["at"] > 60:
        _lan.update(at=now(), ip=lan_address())
    if phone_server is None:
        return ""
    port = phone_server.server_address[1]
    host = _lan["ip"] or socket.gethostname()
    return f"http://{host}:{port}/"


# --------------------------------------------------------------------------
# Takeover: die Wand auf den Fernseher holen
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
TAKEOVER_DESCRIPTION = ("Wird vom Plugin Party Wall abgespielt, wenn du die Wand auf der Plugin-Seite auf den "
                        "Fernseher holst. Bleibt ausgeschaltet, damit es nicht im Quick Mix landet. "
                        "Das Plugin legt sie neu an, wenn sie gelöscht wird.")
TAKEOVER_ITEM_SECONDS = 24 * 3600
STATE_FILE = DATA_DIR / "state.json"

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "since": 0.0, "limit": 0, "wanted": False, "until": 0.0,
             "note": "", "retryAt": 0.0, "busy": False, "playlistId": None, "playlistAt": 0.0}
_stop_requested = threading.Event()


def load_state():
    stored = read_json(STATE_FILE, {})
    return stored if isinstance(stored, dict) else {}


def save_state(**fields):
    stored = load_state()
    stored.update(fields)
    write_json(STATE_FILE, stored)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


def ensure_takeover_playlist(scene_db_id):
    """Ein Takeover spielt eine Playlist: die Szene allein, lange, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = None
    if playlist_id:
        try:
            playlist = engine_call("GET", f"/playlists/{playlist_id}")
        except EngineError as exc:
            if exc.status != 404:
                raise
    if not playlist:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist and playlist_id:
        items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
        items = items.get("items") if isinstance(items, dict) else items
        items = [i for i in items or [] if isinstance(i, dict)]
        if len(items) == 1 and str(items[0].get("dynamicSceneId")) == str(scene_db_id):
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=TAKEOVER_PLAYLIST_NAME))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": scene_db_id, "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    enabled = config.get("enabledPluginNames")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Party Wall auf der Plugins-Seite aus. Schalte es ein, "
                  "sonst kann die Wand nicht von hier aus auf den Fernseher.")
    return ""


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        log(text)
    return False


def _on_session_state(handle_or_state):
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _takeover.update(handle=None, since=0.0)
        if new_state != "expired":
            _takeover["wanted"] = False      # jemand anderes hat den Bildschirm genommen
    log(f"Der Rahmen hat die Wand beendet: {new_state}.")
    if new_state != "expired":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason):
    with _takeover_lock:
        handle = _takeover["handle"]
        _takeover.update(handle=None, since=0.0)
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:  # noqa: BLE001
        log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", "warning")
    log(f"Bildschirm zurückgegeben ({reason}).")
    if reason != "neu":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def show_wall():
    scene = find_scene()
    if not scene:
        return _note(tr("Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal."))
    try:
        if not _takeover["playlistId"] or now() - _takeover["playlistAt"] > 600:
            _takeover.update(playlistId=ensure_takeover_playlist(scene["id"]), playlistAt=now())
    except EngineError as exc:
        return _note(tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc))
    playlist_id = _takeover["playlistId"]
    left = max(60, int(_takeover["until"] - now()))
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             "overlay": {"enabled": False}}
    handle, limit, last_error = None, 0, None
    for seconds in sorted({min(left + 60, 12 * 3600), min(left + 60, 4 * 3600), min(left + 60, 3600),
                           min(left + 60, 300)}, reverse=True):
        try:
            _leftover["askedAt"] = time.time()
            handle = plugin.acquire_display_session(
                session_key="party", state=state, display_name=DISPLAY_NAME,
                max_duration_seconds=seconds, wake_if_off=settings()["WakeScreen"])
            limit = seconds
            break
        except Exception as exc:  # noqa: BLE001
            last_error = exc
    if handle is None:
        if last_error is not None:
            return _note(takeover_permission_note() or tr("Konnte die Wand nicht zeigen: {exc}", exc=last_error))
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    with _takeover_lock:
        _takeover.update(handle=handle, since=now(), limit=limit, note="")
    try:
        handle.on_state_change(_on_session_state)
    except Exception:  # noqa: BLE001
        pass
    try:
        if not handle.wait_until_active(timeout=15):
            end_takeover("fehlgeschlagen")
            return _note(tr("Der Rahmen hat die Wand nicht rechtzeitig gezeigt."))
    except Exception as exc:  # noqa: BLE001
        end_takeover("fehlgeschlagen")
        return _note(tr("Konnte die Wand nicht zeigen: {exc}", exc=exc))
    _scene["seen"] = max(_scene["seen"], now())   # Zeit, bis die Szene geladen ist
    log("Party Wall hat den Bildschirm.")
    return True


def decide_takeover():
    t = now()
    with _takeover_lock:
        wanted, until, handle = _takeover["wanted"], _takeover["until"], _takeover["handle"]
        since, limit, retry_at, busy = _takeover["since"], _takeover["limit"], _takeover["retryAt"], _takeover["busy"]
    if wanted and t >= until:
        wanted = False
        _takeover["wanted"] = False
        log("Party-Zeit abgelaufen, die Wand gibt den Bildschirm zurück.")
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        if not wanted:
            end_takeover("fertig")
        elif limit and t - since >= limit - 20:
            end_takeover("neu")
        return
    if not wanted:
        stop_leftover_takeover()
        return
    if t < retry_at or busy:
        return
    _takeover["busy"] = True
    try:
        if not show_wall():
            with _takeover_lock:
                _takeover["retryAt"] = t + 20
    finally:
        _takeover["busy"] = False


def start_takeover():
    values = settings()
    with _takeover_lock:
        _takeover.update(wanted=True, until=now() + values["PartyHours"] * 3600, retryAt=0.0, note="")
    save_state(takeoverUntil=_takeover["until"])
    log(f"Die Wand soll für {values['PartyHours']} h auf den Fernseher.")
    return {"success": True}


def stop_takeover(reason):
    with _takeover_lock:
        _takeover["wanted"] = False
    save_state(takeoverUntil=0)
    end_takeover(reason)
    return {"success": True}


# ---- Takeover-Playlist, die nach dem Zurückgeben weiterläuft ---------------
# Lief vor einem Takeover keine Playlist, stellt die Engine dieses "nichts"
# nicht wieder her, und die Takeover-Playlist läuft einfach weiter (Jans
# Rahmen, 2026-10-24). Dann hält das Plugin sie mit POST /slideshow/stop an:
# nur wenn sie läuft, niemand den Bildschirm hält und das Plugin nicht
# gerade selbst darum gebeten hat.
_leftover = {"askedAt": 0.0, "failed": False, "checkedAt": 0.0}


def stop_leftover_takeover():
    if time.time() - _leftover["checkedAt"] < 15:
        return False
    _leftover["checkedAt"] = time.time()
    try:
        playlist_id = _takeover["playlistId"] or load_state().get("takeoverPlaylistId")
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status") or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status") or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop")
    except Exception as exc:  # noqa: BLE001 - darf die Schleife nie aufhalten
        if not _leftover["failed"]:
            log(f"The takeover playlist kept running and could not be stopped: {exc}", "warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def check_playback_resumed():
    if playback_guard is not None:
        try:
            playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log, stop_event=_stop_requested)
        except Exception as exc:  # noqa: BLE001
            log(f"playback_guard: {exc}", "warning")


# --------------------------------------------------------------------------
# Playlist für die Szene
# --------------------------------------------------------------------------

OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=PLAYLIST_NAMES.values(),
    name=lambda: PLAYLIST_NAMES.get(settings()["Language"], PLAYLIST_NAMES["en"]),
    description=lambda: tr("Die Fotowand für deine Party: Gäste laden Fotos hoch und reagieren mit Emojis."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
    held=lambda: _takeover["handle"] is not None,
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    t = now()
    with _takeover_lock:
        note = _takeover["note"]
        wanted, until = _takeover["wanted"], _takeover["until"]
    with party.lock:
        stats = party.stats()
        out = {
            "ownPlaylist": OWN.text(),
            "success": True,
            "version": version(),
            "settings": values,
            "party": {"id": party.ident, "title": party.meta.get("title") or "", "code": party.code,
                      "started": party.meta.get("started") or 0, "recap": bool(party.meta.get("recap"))},
            "stats": stats,
            "activeGuests": party.active_guests(t),
            "phase": phase(t),
            "sceneVisible": scene_visible(t),
            "phoneUrl": phone_url(),
            "takeover": _takeover["handle"] is not None,
            "takeoverWanted": wanted,
            "takeoverUntil": until if wanted else 0,
            "takeoverNote": note or takeover_permission_note(),
            "heif": HEIF,
            "pillow": Image is not None,
            "theme": {"id": theme_id()},
        }
    return out


def admin_photos():
    with party.lock:
        rows = [photo_public(p, full=True) for p in sorted(party.photos, key=lambda p: -p["at"])]
    return {"success": True, "photos": rows}


def admin_parties():
    rows = partylib.list_parties(PARTY_ROOT)
    for row in rows:
        row["current"] = row["id"] == party.ident
    return {"success": True, "parties": rows}


def party_zip(ident):
    """Alle Fotos einer Party als ZIP (in eine Datei, nicht in den Speicher)."""
    if not re.match(r"^[0-9A-Za-z-]{6,40}$", ident or ""):
        return None, ""
    folder = PARTY_ROOT / ident
    meta = read_json(folder / "meta.json", None)
    if not isinstance(meta, dict):
        return None, ""
    photos = read_json(folder / "photos.json", []) or []
    guests = read_json(folder / "guests.json", {}) or {}
    handle = tempfile.NamedTemporaryFile(dir=DATA_DIR, prefix=".zip-", suffix=".zip", delete=False)
    handle.close()
    path = Path(handle.name)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_STORED) as archive:
        for number, photo in enumerate(sorted(photos, key=lambda p: p.get("at", 0)), 1):
            source = folder / "photos" / f"{photo.get('id')}.jpg"
            if not source.exists():
                continue
            guest = guests.get(photo.get("g")) or {}
            who = re.sub(r"[^\w-]+", "-", guest.get("name") or f"guest-{guest.get('n', 0)}").strip("-")[:24]
            stamp = time.strftime("%H%M", time.localtime(photo.get("at", 0)))
            archive.write(source, f"{number:03d}-{stamp}-{who or 'guest'}.jpg")
    title = re.sub(r"[^\w-]+", "-", meta.get("title") or "party-wall").strip("-")[:40] or "party-wall"
    day = time.strftime("%Y-%m-%d", time.localtime(meta.get("started") or now()))
    return path, f"{title}-{day}.zip"


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
    "/qrcode.js": ("phone/qrcode.js", "application/javascript; charset=utf-8"),
}
PHONE_FILES = {
    "/phone.css": ("phone/phone.css", "text/css; charset=utf-8"),
    "/phone.js": ("phone/phone.js", "application/javascript; charset=utf-8"),
    "/icon.png": ("icon.png", "image/png"),
}


class BaseHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False, extra=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self, limit=1024 * 1024):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(min(length, limit)) if length > 0 else b""
        if length > limit:
            self.close_connection = True

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _photo(self, query, allow_hidden=False, me=None, cors=False):
        photo_id = (query.get("id") or [""])[0]
        size = (query.get("s") or ["f"])[0]
        found = photo_file(photo_id, size, allow_hidden=allow_hidden, me=me)
        if found is None:
            self._json({"success": False}, 404, cors=cors)
        else:
            self._send(found, "image/jpeg", cache="private, max-age=86400", cors=cors)

    def _emoji(self, path, folder):
        name = path.rsplit("/", 1)[1]
        if not re.match(r"^[0-9a-f-]{4,20}\.svg$", name):
            self._json({"success": False}, 404)
            return
        self._send((PLUGIN_DIR / folder / name).read_bytes(), "image/svg+xml", cache="public, max-age=86400")


class StudioHandler(BaseHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path.startswith("/emoji/"):
                self._emoji(path, "phone/emoji")
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/wall":
                # Die Szene fragt etwa jede Sekunde; daran merkt das Plugin, dass sie zu sehen ist.
                _scene["seen"] = now()
                self._json(wall_state(as_int((query.get("since") or ["-1"])[0], -1)), cors=True)
                return
            if path == "/api/photo":
                self._photo(query, allow_hidden=(query.get("admin") or [""])[0] == "1", cors=True)
                return
            if path == "/api/photos":
                self._json(admin_photos())
                return
            if path == "/api/parties":
                self._json(admin_parties())
                return
            if path == "/api/zip":
                target, name = party_zip((query.get("party") or [party.ident])[0])
                if target is None:
                    self._json({"success": False, "error": "Nicht gefunden"}, 404)
                    return
                try:
                    data = target.read_bytes()
                finally:
                    target.unlink(missing_ok=True)
                self._send(data, "application/zip", extra={
                    "Content-Disposition": f"attachment; filename*=UTF-8''{quote(name)}"})
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            body = self._body()
            if path == "/api/settings":
                changed = save_settings(body)
                if "MakePlaylist" in changed:
                    OWN.changed()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/title":
                party.set_meta(title=partylib.clean_text(body.get("title"), 60))
                self._json({"success": True})
                return
            if path == "/api/photo/state":
                ok = party.set_state(str(body.get("id") or ""), str(body.get("st") or ""))
                self._json({"success": ok})
                return
            if path == "/api/photo/delete":
                self._json({"success": party.delete(str(body.get("id") or ""))})
                return
            if path == "/api/photo/approve-all":
                with party.lock:
                    for photo in party.photos:
                        if photo.get("st") == "wait":
                            photo["st"] = "ok"
                    party.save(("photos",))
                self._json({"success": True})
                return
            if path == "/api/recap":
                self._json(set_recap(as_bool(body.get("on")), "Plugin-Seite"))
                return
            if path == "/api/party/new":
                self._json(new_party(body.get("title") or ""))
                return
            if path == "/api/party/delete":
                ident = str(body.get("id") or "")
                if ident == party.ident:
                    self._json({"success": False, "error": tr("Die laufende Party kann man nicht löschen.")})
                    return
                self._json({"success": partylib.remove_party(PARTY_ROOT, ident)})
                return
            if path == "/api/code":
                party.set_meta(code=partylib.new_code())
                self._json({"success": True})
                return
            if path == "/api/start":
                self._json(start_takeover())
                return
            if path == "/api/end":
                self._json(stop_takeover("von der Plugin-Seite beendet"))
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


def phone_html():
    html = (PLUGIN_DIR / "phone" / "index.html").read_text(encoding="utf-8")
    lang = settings()["Language"]
    return html.replace('<html lang="en">', f'<html lang="{lang}">', 1)


class PhoneHandler(BaseHandler):
    """Die Seite für die Gäste, im ganzen WLAN erreichbar. Keine Einstellungen."""

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(phone_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = PHONE_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path.startswith("/emoji/"):
                self._emoji(path, "phone/emoji")
                return
            if path == "/api/state":
                self._json(phone_state(query))
                return
            if path == "/api/photo":
                me = (query.get("me") or [""])[0]
                if not settings()["Gallery"]:
                    photo = party.find((query.get("id") or [""])[0])
                    current = party.current
                    if not photo or (photo.get("g") != me and photo["id"] != current):
                        self._json({"success": False}, 404)
                        return
                self._photo(query, me=me)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError:
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path == "/api/upload":
                self._upload(query)
                return
            self._drain_body()
            body = self._body()
            handlers = {"/api/join": phone_join, "/api/react": phone_react,
                        "/api/show": phone_request, "/api/delete": phone_delete}
            handler = handlers.get(path)
            if handler is None:
                self._json({"success": False, "error": "Nicht gefunden"}, 404)
                return
            self._json(handler(body))
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def _upload(self, query):
        """POST /api/upload?id=<Gast>&cap=<Text>: das Foto als Body (oder ein Formular)."""
        length = as_int(self.headers.get("Content-Length"), 0)
        if length <= 0 or length > MAX_UPLOAD:
            self._drain_body(0)
            self.close_connection = True
            self._json({"success": False, "error": tr("Das Foto ist zu groß (höchstens {mb} MB).",
                                                      mb=MAX_UPLOAD // 1048576) if length else tr("Es kam kein Foto an.")}, 413)
            return
        data = self.rfile.read(length)
        me = (query.get("id") or [""])[0]
        caption = (query.get("cap") or [""])[0]
        content_type = self.headers.get("Content-Type") or ""
        try:
            files = multipart_files(content_type, data) if content_type.lower().startswith("multipart/") else [data]
            if not files:
                raise PhotoError(tr("Es kam kein Foto an."))
            rows = [store_upload(me, item, caption) for item in files]
        except PhotoError as exc:
            message = str(exc)
            self._json({"success": False, "error": message}, 403 if message == "unknown" else 400)
            return
        self._json({"success": True, "photos": [r["id"] for r in rows], "waiting": rows[-1]["st"] == "wait"})


studio_server = None
phone_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    studio_server.daemon_threads = True
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


def start_phone():
    global phone_server
    wanted = os.environ.get("PARTYWALL_PORT")
    for port in ([int(wanted)] if wanted else PHONE_PORTS):
        try:
            phone_server = ThreadingHTTPServer(("0.0.0.0", port), PhoneHandler)
            break
        except OSError as exc:
            log(f"Port {port} ist belegt ({exc}).", "warning")
    if phone_server is None:
        log("Kein freier Port für die Gäste-Seite (8110 bis 8113).", "warning")
        return
    phone_server.daemon_threads = True
    threading.Thread(target=phone_server.serve_forever, name=f"{PLUGIN_ID}-phone", daemon=True).start()
    log(f"Gäste-Seite: {phone_url()}")


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}" + ("" if HEIF else " (ohne HEIC-Unterstützung)"))
    load_party()

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("playlist", lambda _context=None: make_playlist())
    plugin.on_action("recap", lambda _context=None: set_recap(not party.meta.get("recap"), "Aktion"))

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    start_phone()
    until = as_int(load_state().get("takeoverUntil"), 0)
    if until > now() + 60:   # nach einem Neustart mitten in der Party weitermachen
        with _takeover_lock:
            _takeover.update(wanted=True, until=until)
    threading.Thread(target=wall_loop, name=f"{PLUGIN_ID}-wall", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    end_takeover("gestoppt")
    try:
        party.save()
    except Exception:  # noqa: BLE001
        pass
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:  # noqa: BLE001
        pass
    for server in (studio_server, phone_server):
        if server is not None:
            try:
                server.shutdown()
                server.server_close()
            except Exception:  # noqa: BLE001
                pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
