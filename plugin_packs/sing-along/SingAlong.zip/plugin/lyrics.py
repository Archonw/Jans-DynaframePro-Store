"""Liedtexte von LRCLIB (https://lrclib.net), kostenlos und ohne Schlüssel.

- find(): sucht den Text zu Titel/Interpret/Album/Dauer. Erst /api/get mit
  allem, dann ohne Album, dann mit bereinigtem Titel ("- Remastered 2011",
  "(feat. X)" weg), zuletzt /api/search mit Prüfung der Dauer (±4 s).
- parse_lrc(): macht aus einem LRC-Text [{t, text}] (Sekunden), beachtet
  mehrere Zeitstempel pro Zeile, [offset:...] und Wort-Zeitstempel <mm:ss.xx>.
- Gefundenes (auch "nichts gefunden") liegt im Ordner data/lyrics, damit ein
  Lied nur einmal gefragt wird. Höchstens MAX_CACHE Dateien.
"""

import hashlib
import json
import os
import re
import time
from pathlib import Path

import requests

API = os.environ.get("SINGALONG_LRCLIB", "https://lrclib.net/api")   # nur für Tests änderbar
TIMEOUT = (6, 12)
MAX_CACHE = 800
MISS_AGAIN = 3 * 24 * 3600        # "nichts gefunden" nach drei Tagen noch mal fragen
ERROR_AGAIN = 120                 # nach einem Netzfehler in zwei Minuten noch mal


class LyricsError(Exception):
    pass


STAMP = re.compile(r"\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]")
WORD_STAMP = re.compile(r"<\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?>")
OFFSET = re.compile(r"^\[offset:\s*([+-]?\d+)\s*\]", re.I | re.M)
TAG = re.compile(r"^\[[a-z]+:.*\]$", re.I)


def _seconds(m):
    minutes, seconds, frac = int(m.group(1)), int(m.group(2)), m.group(3) or "0"
    return minutes * 60 + seconds + int(frac) / (10 ** len(frac))


def parse_lrc(text):
    """[{t: Sekunden, text: Zeile}] nach Zeit sortiert; leere Zeilen bleiben (Pausen)."""
    if not text:
        return []
    offset = 0.0
    found = OFFSET.search(text)
    if found:
        offset = int(found.group(1)) / 1000.0   # positiv = Text kommt früher
    rows = []
    for raw in str(text).replace("\r", "").split("\n"):
        line = raw.strip()
        stamps = []
        while True:
            m = STAMP.match(line)
            if not m:
                break
            stamps.append(_seconds(m))
            line = line[m.end():].lstrip()
        if not stamps:
            continue
        words = WORD_STAMP.sub("", line).strip()
        words = re.sub(r"\s{2,}", " ", words)
        for stamp in stamps:
            rows.append({"t": round(max(0.0, stamp - offset), 2), "text": words})
    rows.sort(key=lambda r: r["t"])
    # doppelte leere Zeilen zusammenfassen
    out = []
    for row in rows:
        if out and not row["text"] and not out[-1]["text"]:
            continue
        out.append(row)
    return out


def plain_lines(text):
    return [line.strip() for line in str(text or "").replace("\r", "").split("\n")]


# --------------------------------------------------------------------------
# Titel bereinigen
# --------------------------------------------------------------------------

WORDS = (r"remaster\w*|remix\w*|radio edit|single|album version|mono|stereo|live|edit|version|deluxe|bonus|explicit|"
         r"clean|acoustic|demo|instrumental|feat|ft\\.|with|from|aus|mix")
BRACKET = re.compile(r"\s*[\(\[][^\)\]]*\b(?:" + WORDS + r")\b[^\)\]]*[\)\]]\s*$", re.I)
DASH = re.compile(r"\s+[-–—]\s+[^-–—]*\b(?:" + WORDS + r")\b[^-–—]*$", re.I)
FEAT = re.compile(r"\s+(?:feat\.?|ft\.)\s+.*$", re.I)


def clean_title(title):
    text = str(title or "").strip()
    for _ in range(3):
        cleaned = FEAT.sub("", DASH.sub("", BRACKET.sub("", text))).strip(" -–—")
        if not cleaned or cleaned == text:
            break
        text = cleaned
    return text


def main_artist(artist):
    text = str(artist or "").strip()
    for sep in (", ", " & ", " feat. ", " feat ", " ft. ", " x ", " und ", " y ", "; ", " / "):
        if sep in text:
            return text.split(sep, 1)[0].strip()
    return text


# --------------------------------------------------------------------------
# LRCLIB
# --------------------------------------------------------------------------

class Lrclib:
    def __init__(self, cache_dir, user_agent, log=None):
        self.cache_dir = Path(cache_dir)
        self.user_agent = user_agent
        self.log = log or (lambda *_a, **_k: None)
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": user_agent, "Accept": "application/json"})
        self.last_error = ""
        self.last_ok = 0.0

    # ---- Netz ------------------------------------------------------------

    def _get(self, path, params):
        try:
            answer = self.session.get(f"{API}{path}", params=params, timeout=TIMEOUT)
        except requests.RequestException as exc:
            self.last_error = f"unreachable: {exc}"
            raise LyricsError(self.last_error) from exc
        if answer.status_code == 404:
            self.last_ok = time.time()
            return None
        if answer.status_code >= 400:
            self.last_error = f"HTTP {answer.status_code}"
            raise LyricsError(self.last_error)
        self.last_ok = time.time()
        self.last_error = ""
        try:
            return answer.json()
        except ValueError as exc:
            raise LyricsError("format") from exc

    def ping(self):
        """Für die Verbindungs-Karte: antwortet LRCLIB? Gibt Millisekunden zurück."""
        started = time.time()
        self._get("/search", {"track_name": "hello", "artist_name": "adele"})
        return int((time.time() - started) * 1000)

    # ---- Zwischenspeicher --------------------------------------------------

    def _key(self, title, artist, album, duration):
        raw = "|".join([str(title or "").lower().strip(), str(artist or "").lower().strip(),
                        str(album or "").lower().strip(), str(int(round(duration or 0)))])
        return hashlib.sha1(raw.encode("utf-8")).hexdigest()

    def _cache_path(self, key):
        return self.cache_dir / f"{key}.json"

    def _cached(self, key):
        try:
            data = json.loads(self._cache_path(key).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        if not isinstance(data, dict):
            return None
        age = time.time() - float(data.get("at") or 0)
        if data.get("kind") == "none" and age > MISS_AGAIN:
            return None
        return data

    def _store(self, key, data):
        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            tmp = self._cache_path(key).with_suffix(".tmp")
            tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            tmp.replace(self._cache_path(key))
            files = sorted(self.cache_dir.glob("*.json"), key=lambda p: p.stat().st_mtime)
            for old in files[:-MAX_CACHE]:
                old.unlink(missing_ok=True)
        except OSError as exc:
            self.log(f"Could not store lyrics: {exc}", "warning")

    def forget(self, title, artist, album, duration):
        self._cache_path(self._key(title, artist, album, duration)).unlink(missing_ok=True)

    def clear(self):
        count = 0
        for path in self.cache_dir.glob("*.json"):
            path.unlink(missing_ok=True)
            count += 1
        return count

    def cache_count(self):
        try:
            return sum(1 for _ in self.cache_dir.glob("*.json"))
        except OSError:
            return 0

    # ---- Suchen ----------------------------------------------------------

    @staticmethod
    def _pack(row, how):
        synced = parse_lrc(row.get("syncedLyrics") or "")
        plain = row.get("plainLyrics") or ""
        if row.get("instrumental"):
            kind = "instrumental"
        elif synced:
            kind = "synced"
        elif plain.strip():
            kind = "plain"
        else:
            kind = "none"
        return {"kind": kind, "lines": synced, "plain": plain_lines(plain) if kind == "plain" else [],
                "id": row.get("id"), "how": how, "at": time.time(),
                "matched": {"title": row.get("trackName") or "", "artist": row.get("artistName") or "",
                            "album": row.get("albumName") or "", "duration": row.get("duration") or 0}}

    def _try_get(self, title, artist, album, duration):
        params = {"track_name": title, "artist_name": artist}
        if album:
            params["album_name"] = album
        if duration:
            params["duration"] = int(round(duration))
        row = self._get("/get", params)
        return row if isinstance(row, dict) and row.get("id") else None

    def _try_search(self, title, artist, duration):
        rows = self._get("/search", {"track_name": title, "artist_name": artist}) or []
        if not isinstance(rows, list) or not rows:
            rows = self._get("/search", {"q": f"{artist} {title}".strip()}) or []
        if not isinstance(rows, list):
            return None
        best, best_score = None, None
        for row in rows[:20]:
            if not isinstance(row, dict):
                continue
            diff = abs(float(row.get("duration") or 0) - float(duration or 0)) if duration else 0
            if duration and diff > 4:
                continue
            score = (0 if row.get("syncedLyrics") else 1, diff)
            if best_score is None or score < best_score:
                best, best_score = row, score
        return best

    def find(self, title, artist, album="", duration=0):
        """Gibt {kind: synced|plain|instrumental|none, lines, plain, ...} zurück; LyricsError bei Netzfehler."""
        title, artist = str(title or "").strip(), str(artist or "").strip()
        if not title:
            return {"kind": "none", "lines": [], "plain": [], "how": "no title", "at": time.time()}
        key = self._key(title, artist, album, duration)
        cached = self._cached(key)
        if cached:
            cached["fromCache"] = True
            return cached
        tries = []
        short, lead = clean_title(title), main_artist(artist)
        tries.append(("get", (title, artist, album, duration)))
        if album:
            tries.append(("get-no-album", (title, artist, "", duration)))
        if short != title or lead != artist:
            tries.append(("get-clean", (short, lead, "", duration)))
        found = None
        how = ""
        for how, args in tries:
            if not args[1] and how.startswith("get"):
                continue   # /api/get braucht einen Interpreten
            row = self._try_get(*args)
            if row and (row.get("syncedLyrics") or row.get("plainLyrics") or row.get("instrumental")):
                found = row
                break
        if found is None:
            how = "search"
            found = self._try_search(short, lead, duration)
        if found is None:
            data = {"kind": "none", "lines": [], "plain": [], "how": "not found", "at": time.time()}
        else:
            data = self._pack(found, how)
        self._store(key, data)
        return data
