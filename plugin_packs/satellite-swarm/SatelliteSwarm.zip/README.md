# Satellite Swarm

All active satellites live: about 10,000 of them, as a swarm around the Earth or
as the sky above your home.

## What it shows

- **The swarm around the Earth.** Every active satellite as a coloured dot:
  Starlink (with its fresh launches still flying as a "string of pearls"),
  OneWeb, the navigation satellites (GPS, Galileo, GLONASS, BeiDou) in their
  high shells, weather and Earth observation satellites, space stations, science
  satellites and the geostationary ring 36,000 km up. The camera slowly circles
  the Earth and moves out to the geostationary ring and back. The Earth shows day
  and night by the real position of the sun; satellites in the Earth's shadow
  glow fainter. The ISS, Tiangong, Hubble and fresh Starlink trains are labelled,
  with the orbit of the space stations drawn in.
- **The sky above your home.** A round sky chart (north up, east left, as when
  you look up) with every satellite that is above your horizon right now, how
  many there are and how many of them are in sunlight.
- **Announcements.** For the ISS, Tiangong, Hubble and fresh Starlink trains the
  plugin predicts the passes over your place for the next 36 hours. A few
  minutes before, the scene says "In 5 minutes the ISS passes over you", during
  the pass "Right now the ISS is passing over you – look south-west, 45° above
  the horizon", and whether you can see it with the naked eye (the satellite is
  still in sunlight while it is already dark where you are).
- **Over the playlist (optional).** If you switch it on, an announced pass (all,
  or only visible ones) is put over the running playlist for a few minutes and
  the screen is handed back afterwards. Needs "Allow takeover" for Satellite
  Swarm on the Plugins page.

## How it works

The plugin fetches the open orbit data (GP elements) of all active satellites
from [CelesTrak](https://celestrak.org) every 8 hours (CelesTrak asks not to
fetch more often than every 2 hours). It brings all elements to a common time
and hands them to the scene. The graphics chip then computes the position of
every satellite in every frame (Kepler orbit with the main effects of the
Earth's flattening and of air drag), so the Pi itself has little to do. The
pass predictions use the same model in the plugin; compared with SGP4 the
positions differ by about 10 km, so a pass time is off by a second or two.

No LAN port is opened. The scene talks to the plugin through the DynaFrame web
interface.

## Settings (plugin page)

- **Your place**: search by name (Open-Meteo place search) or enter latitude and
  longitude. Needed for the sky and the announcements.
- **What the scene shows**: Earth and sky taking turns, only the Earth or only
  the sky; camera close, far or moving; dot size; labels, orbits, side panel;
  which groups of satellites.
- **Announce passes**: ISS, Tiangong, Hubble, fresh Starlink trains; minimum
  height; all passes or only visible ones; heads-up 0 to 15 minutes before; show
  the sky during a pass.
- **Put over the playlist**: no, only visible passes, or all announced passes;
  optionally wake a screen that is off.
- **A playlist for it**: creates the playlist "Satellite Swarm" with the scene.
- "Test announcement" plays a one-minute test of the ISS announcement (and of
  the takeover, if it is switched on).

Languages: English, German, Spanish.

## Network

- `celestrak.org` (orbit data, every 8 hours, about 1.6 MB)
- `geocoding-api.open-meteo.com` (only when you search for your place)

Pi-hole and other blockers must allow these.

## Credits

Orbit data: CelesTrak (Dr. T.S. Kelso). Coastlines and borders: Natural Earth
(public domain).
