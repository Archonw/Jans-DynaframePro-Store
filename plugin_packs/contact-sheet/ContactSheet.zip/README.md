# Contact Sheet

Deine Fotos auf einem endlosen analogen Filmstreifen: Kleinbild-Bildfelder mit Perforation, kleinen Bildnummern und einer dezenten Randbeschriftung mit Datum und Ort. Der Streifen hält bei einem Bild ein paar Sekunden an, läuft dann langsam an, wird schnell und verschwimmt, bremst ab und hält beim nächsten Bild.

- Fotos: ganze DynaFrame-Mediathek, Ordner, Playlists oder Immich, mit den Filtern „Welche Fotos aus DynaFrame“ und „Welche Fotos aus Immich“.
- Untergrund: Leuchtpult, Kontaktabzug auf Fotopapier, Holztisch oder dunkler Grund. Farb- oder Schwarzweißfilm, Filmkorn, roter Fettstift um das angehaltene Bild.
- Läuft auf der Grafikkarte (WebGL) und zeichnet nur, solange sich der Streifen bewegt: leicht genug für einen Pi 4.

Problem melden: https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=%5BContact%20Sheet%5D%20
