"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/CalendarPage/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["PhotoCount", "PhotoSeconds", "UpcomingDays", "CalendarMinutes", "ShowSeconds", "RefreshHours", "PlaylistSeconds"];
const CHECK_FIELDS = ["PreferLandscape", "ShowTitles", "Animate", "ShowHolidays", "ShowSchool", "BirthdaysImmich",
  "MonthStart", "BirthdayMorning", "WakeScreen"];
const SELECT_FIELDS = ["Style", "WeekStart"];
const BOOL_SELECTS = [];
let albums = null, albumError = "";
const TEXT_FIELDS = ["ServerUrl", "Folders", "HaUrl", "ShowTime"];
const KINDS = ["library", "playlist", "immich_album", "immich_all"];
const MAX_SOURCES = 6;
const MAX_CALENDARS = 8;
const MAX_BIRTHDAYS = 40;
const CAL_COLORS = ["#c0392b", "#2e86c1", "#27ae60", "#8e44ad", "#d68910", "#16a085", "#c2185b", "#5d6d7e"];
let current = null;
let editing = false;
let sources = [];
let rendered = "";
let pendingCommits = 0, lastEdit = 0, lastCommitDone = 0;
let commitChain = Promise.resolve();
let langChangedAt = 0;
const lists = { playlist: null, immich_album: null };
const listErrors = { playlist: "", immich_album: "" };

const I18N = {
  name: ["Calendar Page", "Calendar Page", "Calendar Page"],
  lede: ["Dein Rahmen wird zum Wandkalender: Jeder Monat bekommt ein schönes Blatt mit Fotos aus demselben Monat früherer Jahre, den Terminen der Familie, Geburtstagen mit Foto, Feiertagen und Schulferien. Am Monatsersten erscheint es von selbst. Jede Änderung hier wird sofort gespeichert.",
    "Your frame becomes a wall calendar: every month gets a beautiful page with photos from the same month in earlier years, the family's appointments, birthdays with a photo, public and school holidays. On the first of the month it shows up by itself. Every change here is saved immediately.",
    "Tu marco se convierte en un calendario de pared: cada mes tiene una hoja bonita con fotos del mismo mes de años anteriores, las citas de la familia, cumpleaños con foto, festivos y vacaciones escolares. El día uno del mes aparece sola. Cada cambio aquí se guarda al momento."],
  showNow: ["Blatt jetzt zeigen", "Show the page now", "Mostrar la hoja ahora"],
  refresh: ["Neu einlesen", "Read again", "Volver a leer"],
  factThisMonth: ["Fotos diesen Monat", "Photos this month", "Fotos de este mes"],
  factNextMonth: ["Nächster Monat", "Next month", "Mes siguiente"],
  factEvents: ["Anstehende Termine", "Appointments coming up", "Próximas citas"],
  factBirthdays: ["Anstehende Geburtstage", "Birthdays coming up", "Próximos cumpleaños"],
  monthFact: ["{n} aufs Blatt, aus {years} Jahren", "{n} on the page, from {years} years", "{n} en la hoja, de {years} años"],
  monthNone: ["Keine aus früheren Jahren", "None from earlier years", "Ninguna de años anteriores"],
  inDays: ["{n} in {days} Tagen", "{n} in {days} days", "{n} en {days} días"],
  nowExif: ["Liest das Aufnahmedatum: {done} von {todo} Dateien (nur beim ersten Mal)", "Reading the date taken: {done} of {todo} files (first time only)", "Leyendo la fecha de toma: {done} de {todo} archivos (solo la primera vez)"],
  nowCal: ["Lädt die Kalender …", "Loading the calendars …", "Cargando los calendarios …"],
  nowPhotos: ["Sucht Fotos …", "Looking for photos …", "Buscando fotos …"],
  servicesHint: ["Alles, was Calendar Page braucht. Das Plugin prüft es alle fünf Minuten selbst; rot heißt, dass etwas fehlt, gelb, dass es nur teilweise geht.",
    "Everything Calendar Page needs. The plugin checks it every five minutes by itself; red means something is missing, yellow that it only partly works.",
    "Todo lo que necesita Calendar Page. El plugin lo comprueba solo cada cinco minutos; rojo significa que falta algo, amarillo que solo funciona en parte."],
  svc_ok: ["OK", "OK", "OK"],
  svc_warn: ["Teilweise", "Partly", "En parte"],
  svc_bad: ["Fehlt", "Missing", "Falta"],
  svc_off: ["Aus", "Off", "Apagado"],
  pageTitle: ["Das Blatt", "The page", "La hoja"],
  style: ["Aussehen", "Look", "Aspecto"],
  stylePaper: ["Cremefarbenes Papier an warmer Wand", "Cream paper on a warm wall", "Papel crema en una pared cálida"],
  styleLinen: ["Weißes Papier an dunkler Wand", "White paper on a dark wall", "Papel blanco en una pared oscura"],
  styleNight: ["Dunkles Blatt (für den Abend)", "Dark page (for the evening)", "Hoja oscura (para la noche)"],
  photoCount: ["Fotos pro Monat (eins pro Jahr)", "Photos per month (one per year)", "Fotos por mes (una por año)"],
  photoSeconds: ["Nächstes Foto nach … Sekunden", "Next photo after … seconds", "Siguiente foto tras … segundos"],
  weekStart: ["Die Woche beginnt am", "Week starts on", "La semana empieza el"],
  weekAuto: ["Wie im Land üblich", "As usual in the country", "Como es habitual en el país"],
  weekMon: ["Montag", "Monday", "Lunes"],
  weekSun: ["Sonntag", "Sunday", "Domingo"],
  upcomingDays: ["„Demnächst“ zeigt die nächsten … Tage", "“Coming up” shows the next … days", "«Próximamente» muestra los próximos … días"],
  preferLandscape: ["Querformat-Fotos bevorzugen", "Prefer landscape photos", "Preferir fotos horizontales"],
  showTitles: ["Zeigen, was die Termine sind (aus: nur farbige Punkte und Uhrzeiten)", "Show what the appointments are (off: only coloured dots and times)", "Mostrar qué son las citas (desactivado: solo puntos de color y horas)"],
  animate: ["Animationen (Umblättern, langsamer Zoom)", "Animations (page turn, slow zoom)", "Animaciones (pasar la hoja, zoom lento)"],
  monthPhotosTitle: ["Fotos auf dem Blatt dieses Monats", "Photos on this month's page", "Fotos en la hoja de este mes"],
  monthPhotosHint: ["Für jedes frühere Jahr gewinnt das beste Foto aus diesem Monat (Sterne, Favorit, Querformat). Klick auf ein Foto, das nicht aufs Blatt soll; dann rückt das nächstbeste nach.",
    "For every earlier year the best photo of this month wins (stars, favourite, landscape). Click a photo you don't want on the page; the next best one takes its place.",
    "Para cada año anterior gana la mejor foto de este mes (estrellas, favorita, horizontal). Haz clic en una foto que no quieras en la hoja; la siguiente mejor ocupa su lugar."],
  nextPhotosTitle: ["Nächster Monat", "Next month", "Mes siguiente"],
  useAllAgain: ["Wieder alle Fotos nehmen", "Use all photos again", "Volver a usar todas las fotos"],
  useAllAgainN: ["Wieder alle Fotos nehmen ({n} weggelassen)", "Use all photos again ({n} left out)", "Volver a usar todas las fotos ({n} excluidas)"],
  thumbsNone: ["Noch keine Fotos aus diesem Monat in früheren Jahren.", "No photos from this month in earlier years yet.", "Aún no hay fotos de este mes en años anteriores."],
  thumbsWait: ["Die Fotos werden noch eingelesen …", "The photos are still being read …", "Las fotos aún se están leyendo …"],
  excludeThis: ["Nicht aufs Blatt nehmen", "Don't use on the page", "No usar en la hoja"],
  excluded: ["Weggelassen. Das nächstbeste Foto rückt nach.", "Left out. The next best photo takes its place.", "Excluida. La siguiente mejor foto ocupa su lugar."],
  yearsAgo: ["vor {n} Jahren", "{n} years ago", "hace {n} años"],
  yearAgo: ["vor einem Jahr", "a year ago", "hace un año"],
  holidaysTitle: ["Feiertage und Schulferien", "Public and school holidays", "Festivos y vacaciones escolares"],
  country: ["Land", "Country", "País"],
  region: ["Bundesland oder Region", "State or region", "Comunidad o región"],
  regionAll: ["Ganzes Land", "Whole country", "Todo el país"],
  showHolidays: ["Feiertage (rot auf dem Blatt)", "Public holidays (red on the page)", "Festivos (en rojo en la hoja)"],
  showSchool: ["Schulferien (Band unter den Tagen)", "School holidays (band under the days)", "Vacaciones escolares (banda bajo los días)"],
  holidaysHint: ["Feiertage rechnet der Rahmen selbst aus. Schulferien kommen vom freien Dienst OpenHolidays (vor allem Europa); wähle dein Bundesland, damit die regionalen stimmen.",
    "Public holidays are worked out on the frame itself. School holidays come from the free OpenHolidays service (mainly Europe); pick your state so the regional ones are right.",
    "Los festivos los calcula el propio marco. Las vacaciones escolares vienen del servicio gratuito OpenHolidays (sobre todo Europa); elige tu comunidad para que las regionales sean correctas."],
  noSchool: ["Für dieses Land hat OpenHolidays keine Schulferien.", "OpenHolidays has no school holidays for this country.", "OpenHolidays no tiene vacaciones escolares para este país."],
  pickRegion: ["Wähle dein Bundesland, sonst fehlen die regionalen Ferien.", "Pick your state, otherwise the regional holidays are missing.", "Elige tu comunidad; si no, faltan las vacaciones regionales."],
  nothingSoon: ["In den nächsten Tagen nichts.", "Nothing in the next few days.", "Nada en los próximos días."],
  schoolRow: ["{name}: {from} bis {to}", "{name}: {from} to {to}", "{name}: del {from} al {to}"],
  calTitle: ["Familienkalender", "Family calendars", "Calendarios familiares"],
  calHint: ["Die Termine kommen aus Kalender-Links (iCal/ICS) oder aus Kalendern in Home Assistant. Jeder Kalender bekommt seine Farbe auf dem Blatt. Bis zu acht.",
    "The appointments come from calendar links (iCal/ICS) or from calendars in Home Assistant. Each calendar gets its colour on the page. Up to eight.",
    "Las citas vienen de enlaces de calendario (iCal/ICS) o de calendarios de Home Assistant. Cada calendario tiene su color en la hoja. Hasta ocho."],
  addCalendar: ["Kalender hinzufügen", "Add calendar", "Añadir calendario"],
  calKind: ["Art", "Kind", "Tipo"],
  calKind_ics: ["Link (iCal)", "Link (iCal)", "Enlace (iCal)"],
  calKind_ha: ["Home Assistant", "Home Assistant", "Home Assistant"],
  calLink: ["Link", "Link", "Enlace"],
  calLinkSaved: ["{host} (gespeichert; zum Ändern neuen Link einfügen)", "{host} (saved; paste a new link to change it)", "{host} (guardado; pega un enlace nuevo para cambiarlo)"],
  calEntity: ["Kalender in Home Assistant", "Calendar in Home Assistant", "Calendario en Home Assistant"],
  calHaFirst: ["Erst Home Assistant unten verbinden", "Connect Home Assistant below first", "Conecta primero Home Assistant abajo"],
  calName: ["Name auf dem Blatt", "Name on the page", "Nombre en la hoja"],
  calColor: ["Farbe", "Colour", "Color"],
  calOn: ["Zeigen", "Show", "Mostrar"],
  calOk: ["{n} Termine geladen.", "{n} appointments loaded.", "{n} citas cargadas."],
  calWait: ["Wird geladen …", "Loading …", "Cargando …"],
  calOff: ["Ausgeschaltet.", "Switched off.", "Desactivado."],
  calMax: ["Mehr als acht Kalender gehen nicht.", "No more than eight calendars.", "No caben más de ocho calendarios."],
  calMinutes: ["Kalender neu laden alle … Minuten", "Load the calendars again every … minutes", "Volver a cargar los calendarios cada … minutos"],
  haTitle: ["Home Assistant", "Home Assistant", "Home Assistant"],
  haHint: ["Nur nötig für Kalender aus Home Assistant. Kennen Home Assistant Live oder Moody Frame ihn schon, werden Adresse und Token von dort übernommen.",
    "Only needed for calendars from Home Assistant. If Home Assistant Live or Moody Frame already know it, the address and token are taken from there.",
    "Solo hace falta para calendarios de Home Assistant. Si Home Assistant Live o Moody Frame ya lo conocen, la dirección y el token se toman de ahí."],
  haUrl: ["Adresse", "Address", "Dirección"],
  haToken: ["Langlebiges Zugriffstoken", "Long-lived access token", "Token de acceso de larga duración"],
  icsHow: ["Wo finde ich den Kalender-Link?", "Where do I find the calendar link?", "¿Dónde encuentro el enlace del calendario?"],
  icsHowText: ["<p><b>Google Kalender</b> (am Computer): Einstellungen des Kalenders &gt; „Kalender integrieren“ &gt; <b>Privatadresse im iCal-Format</b>.</p><p><b>Nextcloud</b>: in der Kalender-App die drei Punkte neben dem Kalender &gt; <b>Abonnement-Link kopieren</b> (falls nötig zuerst „Link teilen“).</p><p><b>iCloud</b>: den Kalender als <b>öffentlichen Kalender</b> teilen und den Link kopieren (webcal://… geht).</p><p><b>Outlook.com</b>: Einstellungen &gt; Kalender &gt; Freigegebene Kalender &gt; <b>Kalender veröffentlichen</b> &gt; ICS-Link.</p><p>Der Link bleibt auf dem Rahmen; diese Seite zeigt nur den Servernamen.</p>",
    "<p><b>Google Calendar</b> (on a computer): settings of the calendar &gt; “Integrate calendar” &gt; <b>Secret address in iCal format</b>.</p><p><b>Nextcloud</b>: in the calendar app the three dots next to the calendar &gt; <b>Copy subscription link</b> (if needed, “Share link” first).</p><p><b>iCloud</b>: share the calendar as a <b>public calendar</b> and copy the link (webcal://… works).</p><p><b>Outlook.com</b>: settings &gt; Calendar &gt; Shared calendars &gt; <b>Publish a calendar</b> &gt; ICS link.</p><p>The link stays on the frame; this page only shows the server name.</p>",
    "<p><b>Google Calendar</b> (en un ordenador): configuración del calendario &gt; «Integrar el calendario» &gt; <b>Dirección secreta en formato iCal</b>.</p><p><b>Nextcloud</b>: en la app de calendario, los tres puntos junto al calendario &gt; <b>Copiar enlace de suscripción</b> (si hace falta, primero «Compartir enlace»).</p><p><b>iCloud</b>: comparte el calendario como <b>calendario público</b> y copia el enlace (webcal://… funciona).</p><p><b>Outlook.com</b>: configuración &gt; Calendario &gt; Calendarios compartidos &gt; <b>Publicar un calendario</b> &gt; enlace ICS.</p><p>El enlace se queda en el marco; esta página solo muestra el nombre del servidor.</p>"],
  bdTitle: ["Geburtstage", "Birthdays", "Cumpleaños"],
  bdImmich: ["Geburtstage der Personen in Immich (mit ihrem Gesicht aus Immich)", "Birthdays of the people in Immich (with their face from Immich)", "Cumpleaños de las personas de Immich (con su cara de Immich)"],
  bdImmichHint: ["In Immich kannst du für jede benannte Person ein Geburtsdatum setzen (Personen > die Person > Geburtsdatum festlegen). Dafür braucht es den Immich-Server weiter unten.",
    "In Immich you can set a birth date for each person you named (People > the person > Set date of birth). This needs the Immich server further down.",
    "En Immich puedes poner una fecha de nacimiento a cada persona con nombre (Personas > la persona > Fijar fecha de nacimiento). Hace falta el servidor Immich más abajo."],
  bdOwnTitle: ["Weitere Geburtstage", "More birthdays", "Más cumpleaños"],
  bdOwnHint: ["Für alle anderen, oder um jemandem ein Foto zu geben: Name, Datum (mit Jahr, wenn das Alter dastehen soll) und wahlweise die Person in Immich, deren Gesicht gezeigt wird.",
    "For anyone else, or to give someone a photo: name, date (with the year if you want the age) and optionally the person in Immich whose face is shown.",
    "Para cualquier otra persona, o para darle una foto: nombre, fecha (con el año si quieres la edad) y, si quieres, la persona de Immich cuya cara se muestra."],
  addBirthday: ["Geburtstag hinzufügen", "Add birthday", "Añadir cumpleaños"],
  bdName: ["Name", "Name", "Nombre"],
  bdDay: ["Tag", "Day", "Día"],
  bdMonth: ["Monat", "Month", "Mes"],
  bdYear: ["Jahr (optional)", "Year (optional)", "Año (opcional)"],
  bdPerson: ["Gesicht aus Immich", "Face from Immich", "Cara de Immich"],
  bdNoPerson: ["Kein Foto", "No photo", "Sin foto"],
  bdNextTitle: ["Nächste Geburtstage", "Next birthdays", "Próximos cumpleaños"],
  bdPeople: ["{born} von {count} Personen in Immich haben ein Geburtsdatum.", "{born} of {count} people in Immich have a birth date.", "{born} de {count} personas de Immich tienen fecha de nacimiento."],
  bdAge: ["wird {n}", "turns {n}", "cumple {n}"],
  bdToday: ["heute", "today", "hoy"],
  bdMax: ["Mehr Geburtstage gehen nicht.", "No more birthdays.", "No caben más cumpleaños."],
  showTitle: ["Über die Playlist", "Over the playlist", "Sobre la lista"],
  monthStart: ["Am Monatsersten das neue Blatt über die Playlist legen", "On the first of the month, show the new page over the playlist", "El día uno del mes, mostrar la hoja nueva sobre la lista"],
  birthdayMorning: ["Auch an Geburtstagen", "Also on birthdays", "También en cumpleaños"],
  wakeScreen: ["Dafür auch den Bildschirm wecken", "Also wake the screen for it", "Despertar también la pantalla para ello"],
  showTime: ["Ab … Uhr", "From … o'clock", "Desde las …"],
  showSeconds: ["Für … Sekunden", "For … seconds", "Durante … segundos"],
  showHint: ["Einmal am Tag, ab dieser Uhrzeit bis 22 Uhr, sobald der Bildschirm an ist. Dafür auf der Plugins-Seite des Rahmens bei Calendar Page „Allow takeover“ einschalten. Das Plugin legt dann eine ausgeschaltete Playlist „Calendar Page (takeover)“ an; lass sie so.",
    "Once per day, from that time until 10 pm, as soon as the screen is on. For this, switch on “Allow takeover” for Calendar Page on the frame's Plugins page. The plugin then creates a switched-off playlist “Calendar Page (takeover)”; leave it as it is.",
    "Una vez al día, desde esa hora hasta las 22:00, en cuanto la pantalla esté encendida. Para ello activa «Allow takeover» de Calendar Page en la página Plugins del marco. El plugin crea entonces una lista apagada «Calendar Page (takeover)»; déjala así."],
  showOn: ["Das Blatt ist gerade auf dem Bildschirm.", "The page is on the screen right now.", "La hoja está ahora en la pantalla."],
  showPending: ["Das Blatt wartet auf den Bildschirm.", "The page is waiting for the screen.", "La hoja espera a la pantalla."],
  showShown: ["Zuletzt am Monatsersten gezeigt: {month}.", "Last shown on the first of the month: {month}.", "Mostrada por última vez el día uno: {month}."],
  sourcesHint: ["Woher die Fotos kommen. Mehrere Quellen werden zusammengelegt. Nur Fotos mit Aufnahmedatum können aufs Blatt.",
    "Where the photos come from. Several sources are combined. Only photos with a date taken can go on the page.",
    "De dónde vienen las fotos. Se combinan varias fuentes. Solo las fotos con fecha de toma pueden ir a la hoja."],
  srcOk: ["{dated} von {total} Fotos haben ein Datum.", "{dated} of {total} photos have a date.", "{dated} de {total} fotos tienen fecha."],
  srcImmich: ["{n} Fotos aus Immich.", "{n} photos from Immich.", "{n} fotos de Immich."],
  serverHint: ["Nötig, wenn eine Quelle von Immich kommt, und für Geburtstage aus Immich. Steht der Server schon in Immich Slideshow, Growing Up oder einem anderen Plugin, wird er übernommen.",
    "Needed if a source comes from Immich, and for birthdays from Immich. If the server is already set in Immich Slideshow, Growing Up or another plugin, it is taken from there.",
    "Hace falta si una fuente viene de Immich, y para los cumpleaños de Immich. Si el servidor ya está en Immich Slideshow, Growing Up u otro plugin, se toma de ahí."],
  makePlaylist: ["Playlist „Calendar Page“ anlegen", "Create the playlist “Calendar Page”", "Crear la lista «Calendar Page»"],
  servicesTitle: ["Verbindungen", "Connections", "Conexiones"],
  servicesCheck: ["Jetzt prüfen", "Check now", "Comprobar ahora"],
  servicesWait: ["Wird geprüft …", "Checking …", "Comprobando …"],
  servicesAllOk: ["Alles erreichbar, zuletzt geprüft {time}.", "Everything reachable, last checked {time}.", "Todo accesible, última comprobación {time}."],
  servicesSome: ["Nicht alles in Ordnung, zuletzt geprüft {time}.", "Not everything is fine, last checked {time}.", "No todo está bien, última comprobación {time}."],
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  language: ["Sprache", "Language", "Idioma"],
  factNow: ["Gerade", "Now", "Ahora"],
  factRead: ["Zuletzt eingelesen", "Last read", "Última lectura"],
  factVersion: ["Version", "Version", "Versión"],
  nowList: ["Liest die Mediendatenbank …", "Reading the media library …", "Leyendo la biblioteca …"],
  nowIdle: ["Bereit", "Ready", "Listo"],
  sourcesTitle: ["Fotos", "Photos", "Fotos"],
  add: ["Quelle hinzufügen", "Add source", "Añadir fuente"],
  remove: ["Entfernen", "Remove", "Quitar"],
  kind: ["Fotos aus", "Photos from", "Fotos de"],
  kind_library: ["Allen Fotos in DynaFrame", "All photos in DynaFrame", "Todas las fotos de DynaFrame"],
  kind_playlist: ["Einer Playlist von DynaFrame", "A DynaFrame playlist", "Una lista de DynaFrame"],
  kind_immich_album: ["Einem Immich-Album", "An Immich album", "Un álbum de Immich"],
  kind_immich_all: ["Allen Fotos in Immich", "All photos in Immich", "Todas las fotos de Immich"],
  ref_playlist: ["Playlist", "Playlist", "Lista"],
  ref_immich_album: ["Album", "Album", "Álbum"],
  ref_none: ["Keine Auswahl nötig", "Nothing to pick", "Nada que elegir"],
  pick: ["Bitte wählen …", "Please pick …", "Elige …"],
  loading: ["Lädt …", "Loading …", "Cargando …"],
  label: ["Eigener Name (optional)", "Own name (optional)", "Nombre propio (opcional)"],
  srcBusy: ["Wird eingelesen …", "Reading …", "Leyendo …"],
  srcWait: ["Wartet auf das Einlesen …", "Waiting to be read …", "Esperando la lectura …"],
  max: ["Mehr als sechs Quellen gehen nicht.", "No more than six sources.", "No caben más de seis fuentes."],
  serverTitle: ["Immich-Server", "Immich server", "Servidor Immich"],
  serverUrl: ["Adresse", "Address", "Dirección"],
  apiKey: ["API-Schlüssel", "API key", "Clave API"],
  test: ["Verbindung testen", "Test connection", "Probar conexión"],
  testing: ["Teste …", "Testing …", "Probando …"],
  keySaved: ["gespeichert (leer lassen zum Behalten)", "saved (leave empty to keep)", "guardada (déjala vacía para conservarla)"],
  keyMissing: ["noch keiner", "none yet", "ninguna todavía"],
  keyHow: ["So bekommst du einen API-Schlüssel", "How to get an API key", "Cómo conseguir una clave API"],
  keyHint: ["In Immich oben rechts auf dein Profilbild, dann <b>Kontoeinstellungen &gt; API-Schlüssel &gt; Neuer API-Schlüssel</b>. Als Berechtigung reichen <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code>, <code>person.read</code> und <code>tag.read</code>; mit <b>Alle</b> geht es auch. Der Schlüssel bleibt im Plugin auf dem Rahmen.",
    "In Immich click your profile picture at the top right, then <b>Account Settings &gt; API Keys &gt; New API Key</b>. The permissions <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code>, <code>person.read</code> and <code>tag.read</code> are enough; <b>All</b> works too. The key stays in the plugin on the frame.",
    "En Immich pulsa tu foto de perfil arriba a la derecha y luego <b>Configuración de la cuenta &gt; Claves API &gt; Nueva clave API</b>. Bastan los permisos <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code>, <code>person.read</code> y <code>tag.read</code>; con <b>Todos</b> también funciona. La clave se queda en el plugin del marco."],
  filterTitle: ["Welche Immich-Fotos verwendet werden", "Which Immich photos may be used", "Qué fotos de Immich se usan"],
  filterHint: ["Damit nichts Privates auf den Rahmen kommt: Für die Immich-Quellen nimmt das Plugin nur Fotos, die zu diesen Filtern passen. Nach einer Änderung verschwinden die gezeigten Fotos sofort und werden neu gesucht.",
    "So nothing private ends up on the frame: for the Immich sources the plugin only takes photos that match these filters. After a change the photos on show disappear right away and are looked up again.",
    "Para que no llegue nada privado al marco: en las fuentes de Immich el plugin solo toma fotos que cumplan estos filtros. Tras un cambio, las fotos mostradas desaparecen al instante y se vuelven a buscar."],
  albumsTitle: ["Alben", "Albums", "Álbumes"],
  albumsHint: ["Gilt für „Allen Fotos in Immich“. Keins angehakt: alle Fotos. Sonst nur Fotos aus den angehakten Alben (auch geteilte). Eine Quelle „Einem Immich-Album“ nimmt immer ihr Album; Sterne, Favoriten und Archiv gelten für beide.",
    "Applies to “All photos in Immich”. None ticked: all photos. Otherwise only photos from the ticked albums (shared ones too). A source “An Immich album” always takes its album; stars, favourites and archive apply to both.",
    "Se aplica a «Todas las fotos de Immich». Ninguno marcado: todas las fotos. Si no, solo fotos de los álbumes marcados (también compartidos). Una fuente «Un álbum de Immich» siempre usa su álbum; estrellas, favoritos y archivo se aplican a ambas."],
  albumFilter: ["Album suchen …", "Search album …", "Buscar álbum …"],
  noAlbums: ["In Immich gibt es keine Alben.", "There are no albums in Immich.", "No hay álbumes en Immich."],
  connectFirst: ["Erst den Immich-Server verbinden.", "Connect the Immich server first.", "Conecta primero el servidor Immich."],
  albumsChosen: ["{n} Alben ausgewählt", "{n} albums ticked", "{n} álbumes marcados"],
  albumChosen: ["1 Album ausgewählt", "1 album ticked", "1 álbum marcado"],
  foldersTitle: ["Weitere Ordner auf dem Rahmen", "More folders on the frame", "Más carpetas en el marco"],
  foldersHint: ["Für „Alle Fotos in DynaFrame“: Das Plugin fragt DynaFrame nach seiner Mediendatenbank und den Medienordnern. Liegen Fotos woanders (z. B. ein eingehängtes NAS), trag die Ordner hier ein, einen pro Zeile.",
    "For “All photos in DynaFrame”: the plugin asks DynaFrame for its media database and media folders. If photos are somewhere else (e.g. a mounted NAS), enter those folders here, one per line.",
    "Para «Todas las fotos de DynaFrame»: el plugin pide a DynaFrame su base de datos y sus carpetas. Si hay fotos en otro sitio (p. ej. un NAS montado), escribe aquí esas carpetas, una por línea."],
  refreshHours: ["Neue Fotos suchen alle … Stunden", "Look for new photos every … hours", "Buscar fotos nuevas cada … horas"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la lista (segundos)"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status}).", "Error (HTTP {status}).", "Error (HTTP {status})."],
  oclock: ["{time} Uhr", "{time}", "{time}"],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistHint: ["Die Playlist enthält nur die Szene und ist eingeschaltet. Die Dauer gilt beim Anlegen; danach änderst du sie in der Playlist selbst. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist holds only the scene and is switched on. The duration applies when it is created; after that you change it in the playlist itself. You can also add the scene to any playlist yourself.",
    "La lista contiene solo la escena y está activada. La duración se aplica al crearla; después la cambias en la propia lista. También puedes añadir la escena a cualquier lista."],
  ifAlbumFilter: ["Album suchen …", "Search album …", "Buscar álbum …"],
  ifArchNo: ["Weglassen", "Leave out", "Excluir"],
  ifArchYes: ["Auch verwenden", "Use them too", "Usarlas también"],
  ifArchived: ["Archivierte Fotos", "Archived photos", "Fotos archivadas"],
  ifCameraOnly: ["Nur Fotos aus einer Kamera (ohne Screenshots und gespeicherte Bilder)", "Only photos taken with a camera (skips screenshots and saved images)", "Solo fotos de una cámara (sin capturas ni imágenes guardadas)"],
  ifCity: ["Stadt", "City", "Ciudad"],
  ifCountry: ["Land", "Country", "País"],
  ifDescription: ["Beschreibung enthält", "Description contains", "La descripción contiene"],
  ifFavAll: ["Alle Fotos", "All photos", "Todas las fotos"],
  ifFavOnly: ["Nur Favoriten", "Only favourites", "Solo favoritos"],
  ifFavoritesOnly: ["Favoriten", "Favourites", "Favoritos"],
  ifFileName: ["Dateiname enthält", "File name contains", "El nombre del archivo contiene"],
  ifGrpCamera: ["Kamera", "Camera", "Cámara"],
  ifGrpJunk: ["Aussortieren", "Skip the junk", "Descartar"],
  ifGrpSkip: ["Weglassen", "Leave out", "Excluir"],
  ifGrpText: ["Text", "Text", "Texto"],
  ifGrpWhat: ["Was", "What", "Qué"],
  ifGrpWhere: ["Wo", "Where", "Dónde"],
  ifGrpWho: ["Wer", "Who", "Quién"],
  ifLandscape: ["Querformat", "Landscape", "Horizontal"],
  ifLens: ["Objektiv", "Lens", "Objetivo"],
  ifMake: ["Hersteller", "Make", "Marca"],
  ifMinFileKB: ["Mindestens … KB Dateigröße", "File size at least … KB", "Tamaño de archivo de al menos … KB"],
  ifMinMegapixels: ["Mindestens … Megapixel", "At least … megapixels", "Al menos … megapíxeles"],
  ifMinRating: ["Sterne", "Stars", "Estrellas"],
  ifModel: ["Modell", "Model", "Modelo"],
  ifNoScreenshots: ["Dateinamen weglassen, die nach Bildschirmfoto aussehen", "Skip file names that look like screenshots", "Omitir nombres de archivo que parecen capturas"],
  ifNotInAlbum: ["Nur Fotos, die in keinem Album sind", "Only photos that are not in any album", "Solo fotos que no están en ningún álbum"],
  ifOcrText: ["Text im Bild enthält", "Text in the image contains", "El texto de la imagen contiene"],
  ifOrientation: ["Ausrichtung", "Orientation", "Orientación"],
  ifPeopleFilter: ["Person suchen …", "Search person …", "Buscar persona …"],
  ifPeopleHint: ["Keine angehakt: egal wer. Sonst nur Fotos, auf denen mindestens eine dieser Personen ist (aus der Gesichtserkennung von Immich).", "None ticked: anyone. Otherwise only photos with at least one of these people (from Immich's face recognition).", "Ninguna marcada: cualquiera. Si no, solo fotos con al menos una de estas personas (del reconocimiento facial de Immich)."],
  ifPortrait: ["Hochformat", "Portrait", "Vertical"],
  ifRating1: ["Mindestens 1 Stern", "At least 1 star", "Al menos 1 estrella"],
  ifRating2: ["Mindestens 2 Sterne", "At least 2 stars", "Al menos 2 estrellas"],
  ifRating3: ["Mindestens 3 Sterne", "At least 3 stars", "Al menos 3 estrellas"],
  ifRating4: ["Mindestens 4 Sterne", "At least 4 stars", "Al menos 4 estrellas"],
  ifRating5: ["5 Sterne", "5 stars", "5 estrellas"],
  ifRatingAny: ["Egal", "Any", "Da igual"],
  ifSkipAlbums: ["Alben weglassen", "Albums to leave out", "Álbumes a excluir"],
  ifSkipHint: ["Ein weggelassenes Album lässt alles darin weg, auch wenn es woanders noch vorkommt.", "Leaving out an album leaves out everything in it, wherever else it turns up.", "Excluir un álbum excluye todo lo que contiene, aunque aparezca en otro sitio."],
  ifSkipNames: ["Dateinamen weglassen (mit Komma getrennt)", "File names to leave out (separate with commas)", "Nombres de archivo a excluir (separados por comas)"],
  ifSkipTags: ["Tags weglassen", "Tags to leave out", "Etiquetas a excluir"],
  ifSquareShape: ["Quadratisch", "Square", "Cuadrada"],
  ifState: ["Bundesland", "State or province", "Estado o provincia"],
  ifTagFilter: ["Tag suchen …", "Search tag …", "Buscar etiqueta …"],
  ifWithPeople: ["Nur Fotos mit Personen", "Only photos with people in them", "Solo fotos con personas"],
  ifNothingHere: ["Keine gefunden.", "None found.", "No se encontró ninguno."],
  ifOneChosen: ["1 ausgewählt", "1 ticked", "1 marcado"],
  ifManyChosen: ["{n} ausgewählt", "{n} ticked", "{n} marcados"],
  ifLoading: ["Lädt …", "Loading …", "Cargando …"],
  dfTitle: ["Welche Fotos aus DynaFrame", "Which photos from DynaFrame", "Qué fotos de DynaFrame"],
  dfHint: ["Gilt für Fotos aus DynaFrame (alle Fotos, Ordner, Playlists). Die Daten liest DynaFrame selbst aus den Fotos (EXIF, auch Sterne aus .xmp-Dateien daneben). Fotos, die DynaFrame nicht in seiner Mediendatenbank hat, fallen weg, sobald ein Filter gesetzt ist.", "Applies to photos from DynaFrame (all photos, folders, playlists). DynaFrame reads the data from the photos itself (EXIF, also stars from .xmp files next to them). Photos that are not in DynaFrame's media database are left out as soon as a filter is set.", "Se aplica a las fotos de DynaFrame (todas las fotos, carpetas, listas). DynaFrame lee los datos de las propias fotos (EXIF, también las estrellas de archivos .xmp al lado). Las fotos que no están en la base de datos de DynaFrame se omiten en cuanto hay un filtro."],
  dfCount: ["{n} von {m} Fotos aus DynaFrame passen zu den Filtern.", "{n} of {m} photos from DynaFrame match the filters.", "{n} de {m} fotos de DynaFrame cumplen los filtros."],
  dfCameraOnly: ["Nur Fotos aus einer Kamera (ohne Screenshots und gespeicherte Bilder)", "Only photos taken with a camera (skips screenshots and saved images)", "Solo fotos de una cámara (sin capturas ni imágenes guardadas)"],
  dfPlace: ["Ort enthält", "Place contains", "El lugar contiene"],
  dfText: ["Titel, Beschreibung oder Tags enthalten", "Title, description or tags contain", "Título, descripción o etiquetas contienen"],
  dfFileName: ["Dateiname enthält", "File name contains", "El nombre del archivo contiene"],
  dfGrpCamera: ["Kamera", "Camera", "Cámara"],
  dfGrpJunk: ["Aussortieren", "Skip the junk", "Descartar"],
  dfGrpText: ["Text", "Text", "Texto"],
  dfGrpWhat: ["Was", "What", "Qué"],
  dfGrpWhere: ["Wo", "Where", "Dónde"],
  dfLandscape: ["Querformat", "Landscape", "Horizontal"],
  dfLens: ["Objektiv", "Lens", "Objetivo"],
  dfMake: ["Hersteller", "Make", "Marca"],
  dfMinMegapixels: ["Mindestens … Megapixel", "At least … megapixels", "Al menos … megapíxeles"],
  dfMinRating: ["Sterne", "Stars", "Estrellas"],
  dfModel: ["Modell", "Model", "Modelo"],
  dfNoScreenshots: ["Dateinamen weglassen, die nach Bildschirmfoto aussehen", "Skip file names that look like screenshots", "Omitir nombres de archivo que parecen capturas"],
  dfOrientation: ["Ausrichtung", "Orientation", "Orientación"],
  dfPortrait: ["Hochformat", "Portrait", "Vertical"],
  dfRating1: ["Mindestens 1 Stern", "At least 1 star", "Al menos 1 estrella"],
  dfRating2: ["Mindestens 2 Sterne", "At least 2 stars", "Al menos 2 estrellas"],
  dfRating3: ["Mindestens 3 Sterne", "At least 3 stars", "Al menos 3 estrellas"],
  dfRating4: ["Mindestens 4 Sterne", "At least 4 stars", "Al menos 4 estrellas"],
  dfRating5: ["5 Sterne", "5 stars", "5 estrellas"],
  dfRatingAny: ["Egal", "Any", "Da igual"],
  dfSkipNames: ["Dateinamen weglassen (mit Komma getrennt)", "File names to leave out (separate with commas)", "Nombres de archivo a excluir (separados por comas)"],
  dfSquareShape: ["Quadratisch", "Square", "Cuadrada"],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
  statusTitle: ["Stand", "Status", "Estado"],
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "";

const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[1]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "en";
  if (chosen === lang && document.documentElement.dataset.applied === chosen) return;
  lang = chosen;
  document.documentElement.dataset.applied = lang;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  rendered = "";
  if (current) render(current);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(epoch) {
  if (!epoch) return "—";
  const date = new Date(epoch * 1000);
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang]);
const fmtDate = (iso) => iso ? new Date(`${iso}T12:00:00`).toLocaleDateString(LOCALES[lang], { day: "numeric", month: "short", year: "numeric" }) : "";

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

// ------------------------------------------------------------ Quellen

async function loadList(kind, force = false) {
  if (lists[kind] && !force) return;
  lists[kind] = lists[kind] || [];
  try {
    const result = await api(kind === "playlist" ? "./api/playlists" : "./api/albums");
    lists[kind] = kind === "playlist" ? result.playlists : result.albums;
    listErrors[kind] = "";
  } catch (error) {
    listErrors[kind] = error.message;
    lists[kind] = [];
  }
  rendered = "";
  renderSources();
}

// Änderungen nacheinander speichern; eine Antwort von vorher darf die Auswahl nicht zurückdrehen.
function commit() {
  lastEdit = Date.now();
  pendingCommits++;
  const snapshot = JSON.parse(JSON.stringify(sources));
  commitChain = commitChain.then(async () => {
    try {
      await api("./api/settings", { method: "POST", body: JSON.stringify({ Sources: snapshot }) });
      setStatus(t("saved"), "ok", "sourcesNote");
    } catch (error) {
      setStatus(error.message, "bad", "sourcesNote");
    } finally {
      pendingCommits--;
      lastCommitDone = Date.now();
    }
  });
  commitChain.then(() => { if (!pendingCommits) refresh(); });
}

const needsRef = (kind) => kind === "playlist" || kind === "immich_album";

function statusText(src) {
  const row = (current && current.status[src.id]) || {};
  if (row.state === "busy") return [t("srcBusy"), ""];
  if (row.state === "wait") return [t("srcWait"), ""];
  if (row.state === "error") return [row.error || "?", "bad"];
  if (row.state === "ok" && String(row.kind || src.kind).startsWith("immich")) return [t("srcImmich", { n: fmt(row.total), located: fmt(row.located) }), "ok"];
  if (row.state === "ok") return [t("srcOk", { dated: fmt(row.dated), total: fmt(row.total), located: fmt(row.located) }), "ok"];
  return ["", ""];
}

function fillRef(select, src) {
  const kind = src.kind;
  select.replaceChildren();
  if (!needsRef(kind)) {
    select.disabled = true;
    select.append(new Option(t("ref_none"), ""));
    return;
  }
  select.disabled = false;
  const list = lists[kind];
  if (list === null) {
    select.append(new Option(t("loading"), ""));
    loadList(kind);
    return;
  }
  select.append(new Option(listErrors[kind] || t("pick"), ""));
  for (const row of list) {
    const count = row.count ? ` (${fmt(row.count)})` : "";
    select.append(new Option(`${row.name}${count}`, String(row.id)));
  }
  if (src.ref && !list.some((row) => String(row.id) === src.ref)) select.append(new Option(src.name || src.ref, src.ref));
  select.value = src.ref || "";
}

function renderSources() {
  const key = JSON.stringify([lang, sources.map((s) => [s.id, s.kind]), lists.playlist?.length, lists.immich_album?.length, listErrors]);
  const box = el("sources");
  if (key !== rendered) {
    rendered = key;
    box.replaceChildren();
    sources.forEach((src, index) => {
      const row = document.createElement("div");
      row.className = "source";
      row.dataset.id = src.id;

      const kindField = document.createElement("label");
      kindField.className = "field";
      kindField.innerHTML = `<span>${t("kind")}</span>`;
      const kind = document.createElement("select");
      for (const k of KINDS) kind.append(new Option(t(`kind_${k}`), k));
      kind.value = src.kind;
      kind.addEventListener("change", () => {
        src.kind = kind.value;
        src.ref = "";
        commit();
        renderSources();
      });
      kindField.append(kind);

      const refField = document.createElement("label");
      refField.className = "field";
      refField.innerHTML = `<span>${needsRef(src.kind) ? t(`ref_${src.kind}`) : "&nbsp;"}</span>`;
      const ref = document.createElement("select");
      fillRef(ref, src);
      ref.addEventListener("change", () => {
        src.ref = ref.value;
        commit();
      });
      refField.append(ref);

      const nameField = document.createElement("label");
      nameField.className = "field";
      nameField.innerHTML = `<span>${t("label")}</span>`;
      const name = document.createElement("input");
      name.type = "text";
      name.maxLength = 60;
      name.value = src.name || "";
      name.addEventListener("focus", () => { editing = true; });
      name.addEventListener("blur", () => { editing = false; });
      name.addEventListener("change", () => {
        src.name = name.value;
        commit();
      });
      nameField.append(name);

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "secondary remove";
      remove.textContent = t("remove");
      remove.disabled = sources.length <= 1;
      remove.addEventListener("click", () => {
        sources.splice(index, 1);
        commit();
        renderSources();
      });

      const meta = document.createElement("p");
      meta.className = "meta";
      row.append(kindField, refField, nameField, remove, meta);
      box.append(row);
    });
  }
  for (const src of sources) {
    const meta = box.querySelector(`.source[data-id="${src.id}"] .meta`);
    if (!meta) continue;
    const [text, tone] = statusText(src);
    meta.textContent = text;
    meta.className = `meta${tone ? " " + tone : ""}`;
  }
  el("addSource").disabled = sources.length >= MAX_SOURCES;
}

el("addSource").addEventListener("click", () => {
  if (sources.length >= MAX_SOURCES) { setStatus(t("max"), "bad", "sourcesNote"); return; }
  const used = new Set(sources.map((s) => s.id));
  let n = 1;
  while (used.has(`s${n}`)) n++;
  sources.push({ id: `s${n}`, kind: "playlist", ref: "", name: "" });
  commit();
  renderSources();
});

// ------------------------------------------------------------ Verbindungen

function renderServices(sv) {
  if (!sv || !sv.rows || !sv.rows.length) return;
  el("servicesList").innerHTML = sv.rows.map((r) => `<li class="svc ${esc(r.state)}"><span class="dot"></span>
    <div><b>${esc(r.name)}</b> <span class="tag">${esc(t("svc_" + r.state))}</span><div class="txt">${esc(r.text)}</div>
    ${r.hint && r.state !== "ok" ? `<div class="hint2">${esc(r.hint)}</div>` : ""}</div></li>`).join("");
  if (el("servicesNote").dataset.sticky) return;
  const time = clock(sv.at);
  setStatus(sv.bad || sv.warn ? t("servicesSome", { bad: sv.bad, warn: sv.warn, time }) : t("servicesAllOk", { time }),
    sv.bad ? "bad" : sv.warn ? "" : "ok", "servicesNote");
}
el("servicesButton").addEventListener("click", async () => {
  const button = el("servicesButton");
  button.disabled = true;
  el("servicesNote").dataset.sticky = "1";
  setStatus(t("servicesWait"), "busy", "servicesNote");
  try {
    const result = await api("./api/services");
    delete el("servicesNote").dataset.sticky;
    renderServices(result.services);
  } catch (error) {
    setStatus(error.message, "bad", "servicesNote");
    delete el("servicesNote").dataset.sticky;
  }
  button.disabled = false;
});

// ------------------------------------------------------------ Hilfen

const MONTH_NAMES = () => Array.from({ length: 12 }, (_, i) =>
  new Date(2026, i, 15).toLocaleDateString(LOCALES[lang], { month: "long" }));
const fmtShort = (iso) => iso ? new Date(`${iso.slice(0, 10)}T12:00:00`).toLocaleDateString(LOCALES[lang], { weekday: "short", day: "numeric", month: "short" }) : "";
const fmtMonth = (key) => key ? new Date(`${key.slice(0, 7)}-15T12:00:00`).toLocaleDateString(LOCALES[lang], { month: "long", year: "numeric" }) : "";
const uid = () => Math.random().toString(16).slice(2, 10);
const focusGuard = (node) => {
  node.addEventListener("focus", () => { editing = true; });
  node.addEventListener("blur", () => { editing = false; });
};
function labelled(text, control, extra = "") {
  const field = document.createElement("label");
  field.className = `field${extra ? " " + extra : ""}`;
  const span = document.createElement("span");
  span.textContent = text;
  field.append(span, control);
  return field;
}

// ------------------------------------------------------------ Fotos aufs Blatt

function renderThumbs(box, month, small) {
  const photos = (month && month.photos) || [];
  const thisYear = month ? Number(month.month.slice(0, 4)) : 0;
  let html;
  if (!photos.length) {
    html = `<p class="hint">${esc(current && current.busy && !current.indexAt ? t("thumbsWait") : t("thumbsNone"))}</p>`;
  } else {
    html = photos.map((p) => {
      const year = Number(String(p.t).slice(0, 4));
      const ago = thisYear - year === 1 ? t("yearAgo") : t("yearsAgo", { n: thisYear - year });
      const stars = p.stars ? " " + "★".repeat(Math.min(5, p.stars)) : "";
      return `<button type="button" class="pick" data-id="${esc(p.id)}" title="${esc(t("excludeThis"))}">
        <img src="./api/photo?p=${encodeURIComponent(p.id)}" alt="" loading="lazy">
        <span><b>${esc(year)}</b>${small ? "" : ` · ${esc(ago)}${esc(stars)}`}${p.place && !small ? `<br>${esc(p.place)}` : ""}</span>
        <i aria-hidden="true">×</i></button>`;
    }).join("");
  }
  const key = lang + html;
  if (box.dataset.key !== key) { box.innerHTML = html; box.dataset.key = key; }
}

async function excludePhoto(event) {
  const button = event.target.closest(".pick");
  if (!button) return;
  button.classList.add("gone");
  try {
    await api("./api/exclude", { method: "POST", body: JSON.stringify({ id: button.dataset.id }) });
    setStatus(t("excluded"), "ok", "thumbNote");
    setTimeout(refresh, 1200);
  } catch (error) {
    button.classList.remove("gone");
    setStatus(error.message, "bad", "thumbNote");
  }
}
el("thumbs").addEventListener("click", excludePhoto);
el("thumbsNext").addEventListener("click", excludePhoto);
el("resetExcluded").addEventListener("click", async () => {
  try {
    await api("./api/exclude", { method: "POST", body: JSON.stringify({ reset: true }) });
    setStatus(t("saved"), "ok", "thumbNote");
    setTimeout(refresh, 1200);
  } catch (error) {
    setStatus(error.message, "bad", "thumbNote");
  }
});

// ------------------------------------------------------------ Feiertage

let countries = null, countriesLang = "", schoolCountries = [];

async function loadCountries() {
  countriesLang = lang;
  try {
    const result = await api("./api/countries");
    countries = (result.countries || []).sort((a, b) => a.name.localeCompare(b.name, LOCALES[lang]));
    schoolCountries = result.school || [];
  } catch (error) {
    countries = countries || [];
    setStatus(error.message, "bad", "holidayNote");
  }
  el("HolidayCountry").dataset.key = "";
  if (current) renderHolidays(current);
}

function renderHolidays(state) {
  const s = state.settings;
  if (countries === null || countriesLang !== s.Language) {
    if (countriesLang !== s.Language) { countriesLang = s.Language; loadCountries(); }
    return;
  }
  const countrySel = el("HolidayCountry"), regionSel = el("HolidayRegion");
  const country = countries.find((c) => c.code === s.HolidayCountry);
  const key = JSON.stringify([lang, countries.length, s.HolidayCountry]);
  if (countrySel.dataset.key !== key) {
    countrySel.dataset.key = key;
    countrySel.replaceChildren(...countries.map((c) => new Option(c.name, c.code)));
    if (!country && s.HolidayCountry) countrySel.append(new Option(s.HolidayCountry, s.HolidayCountry));
    regionSel.replaceChildren(new Option(t("regionAll"), ""),
      ...((country && country.regions) || []).slice().sort((a, b) => a.name.localeCompare(b.name, LOCALES[lang]))
        .map((r) => new Option(r.name, r.code)));
    regionSel.disabled = !(country && country.regions.length);
  }
  if (document.activeElement !== countrySel) countrySel.value = s.HolidayCountry;
  if (document.activeElement !== regionSel) regionSel.value = s.HolidayRegion || "";

  const up = state.upcoming || {};
  const rows = [];
  for (const h of (s.ShowHolidays ? up.holidays : []) || []) rows.push(`<li><b class="red">${esc(fmtShort(h.date))}</b> ${esc(h.name)}</li>`);
  for (const r of (s.ShowSchool ? up.school : []) || []) {
    const text = r.start === r.end ? `${r.name}: ${fmtShort(r.start)}` : t("schoolRow", { name: r.name, from: fmtShort(r.start), to: fmtShort(r.end) });
    rows.push(`<li><b class="band"></b> ${esc(text)}</li>`);
  }
  const html = rows.join("") || `<li class="muted">${esc(t("nothingSoon"))}</li>`;
  if (el("holidayList").dataset.html !== html) { el("holidayList").innerHTML = html; el("holidayList").dataset.html = html; }
  if (!el("holidayNote").dataset.sticky) {
    const school = schoolCountries.includes(s.HolidayCountry);
    const regions = country && country.regions.length;
    if (s.ShowSchool && !school) setStatus(t("noSchool"), "", "holidayNote");
    else if (s.ShowSchool && regions && !s.HolidayRegion) setStatus(t("pickRegion"), "bad", "holidayNote");
    else setStatus("", "", "holidayNote");
  }
}

el("HolidayCountry").addEventListener("change", (e) => save({ HolidayCountry: e.target.value, HolidayRegion: "" }));
el("HolidayRegion").addEventListener("change", (e) => save({ HolidayRegion: e.target.value }));

// ------------------------------------------------------------ Kalender

let cals = [];
let calsRendered = "";
let calPending = 0, calEdit = 0, calDone = 0;
let calChain = Promise.resolve();
let haCals = null, haError = "";

function commitCals() {
  calEdit = Date.now();
  calPending++;
  const snapshot = cals.map(({ id, kind, ref, color, name, on }) => ({ id, kind, ref, color, name, on }));
  calChain = calChain.then(async () => {
    try {
      await api("./api/settings", { method: "POST", body: JSON.stringify({ Calendars: snapshot }) });
      setStatus(t("saved"), "ok", "calNote");
    } catch (error) {
      setStatus(error.message, "bad", "calNote");
    } finally {
      calPending--;
      calDone = Date.now();
    }
  });
  calChain.then(() => { if (!calPending) refresh(); });
}

async function loadHaCalendars(force = false) {
  if (haCals !== null && !force) return;
  haCals = haCals || [];
  const s = current && current.settings;
  if (!s || !s.HaUrl || !current.secretsSet.HaToken) {
    haError = t("calHaFirst");
  } else {
    try {
      haCals = (await api("./api/hacalendars")).calendars || [];
      haError = "";
    } catch (error) {
      haError = error.message;
    }
  }
  calsRendered = "";
  renderCalendars();
}

function calStatus(cal) {
  if (!cal.on) return [t("calOff"), ""];
  const stored = ((current && current.settings.Calendars) || []).find((c) => c.id === cal.id);
  const st = stored && stored.status;
  if (!stored || (cal.kind === "ics" && !cal.ref) || (cal.kind === "ha" && !cal.ref)) return ["", ""];
  if (!st) return [current && current.calBusy ? t("calWait") : "", ""];
  if (st.state === "error") return [st.error || "?", "bad"];
  return [t("calOk", { n: fmt(st.count) }), "ok"];
}

function renderCalendars() {
  const key = JSON.stringify([lang, cals.map((c) => [c.id, c.kind]), haCals && haCals.length, haError]);
  const box = el("calendars");
  if (key !== calsRendered) {
    calsRendered = key;
    box.replaceChildren();
    cals.forEach((cal, index) => {
      const row = document.createElement("div");
      row.className = "calendar";
      row.dataset.id = cal.id;

      const kind = document.createElement("select");
      for (const k of ["ics", "ha"]) kind.append(new Option(t(`calKind_${k}`), k));
      kind.value = cal.kind;
      kind.addEventListener("change", () => {
        cal.kind = kind.value;
        cal.ref = "";
        if (cal.kind === "ha") loadHaCalendars();
        commitCals();
        renderCalendars();
      });

      let ref;
      if (cal.kind === "ics") {
        ref = document.createElement("input");
        ref.type = "url";
        ref.spellcheck = false;
        ref.autocomplete = "off";
        ref.placeholder = cal.ref ? t("calLinkSaved", { host: cal.ref.replace(/\/…$/, "") }) : "https://… / webcal://…";
        ref.value = "";
        focusGuard(ref);
        ref.addEventListener("change", () => {
          const value = ref.value.trim();
          if (!value) return;
          cal.ref = value;
          if (!cal.name) {
            try { cal.name = new URL(value.replace(/^webcal:/i, "https:")).hostname.replace(/^www\./, "").slice(0, 40); } catch (_) { /* egal */ }
          }
          commitCals();
          calsRendered = "";
          renderCalendars();
        });
      } else {
        ref = document.createElement("select");
        if (haCals === null) { ref.append(new Option(t("loading"), "")); loadHaCalendars(); }
        else {
          ref.append(new Option(haError || t("pick"), ""));
          for (const c of haCals) ref.append(new Option(c.name || c.entity_id, c.entity_id));
          if (cal.ref && !haCals.some((c) => c.entity_id === cal.ref)) ref.append(new Option(cal.ref, cal.ref));
        }
        ref.value = cal.ref || "";
        ref.addEventListener("change", () => {
          cal.ref = ref.value;
          const found = (haCals || []).find((c) => c.entity_id === ref.value);
          if (!cal.name && found) cal.name = String(found.name || "").slice(0, 40);
          commitCals();
          calsRendered = "";
          renderCalendars();
        });
      }

      const name = document.createElement("input");
      name.type = "text";
      name.maxLength = 40;
      name.value = cal.name || "";
      focusGuard(name);
      name.addEventListener("change", () => { cal.name = name.value.trim(); commitCals(); });

      const color = document.createElement("input");
      color.type = "color";
      color.value = cal.color || CAL_COLORS[index % CAL_COLORS.length];
      color.addEventListener("change", () => { cal.color = color.value; commitCals(); });

      const on = document.createElement("input");
      on.type = "checkbox";
      on.checked = cal.on !== false;
      on.addEventListener("change", () => { cal.on = on.checked; commitCals(); });

      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "secondary remove";
      remove.textContent = t("remove");
      remove.addEventListener("click", () => {
        cals.splice(index, 1);
        commitCals();
        calsRendered = "";
        renderCalendars();
      });

      const meta = document.createElement("p");
      meta.className = "meta";
      row.append(labelled(t("calKind"), kind), labelled(cal.kind === "ics" ? t("calLink") : t("calEntity"), ref, "wide"),
        labelled(t("calName"), name), labelled(t("calColor"), color, "color"), labelled(t("calOn"), on, "check"), remove, meta);
      box.append(row);
    });
  }
  for (const cal of cals) {
    const row = box.querySelector(`.calendar[data-id="${cal.id}"]`);
    if (!row) continue;
    const [text, tone] = calStatus(cal);
    const meta = row.querySelector(".meta");
    meta.textContent = text;
    meta.className = `meta${tone ? " " + tone : ""}`;
    const input = row.querySelector('input[type="url"]');
    if (input && document.activeElement !== input && cal.ref) {
      input.placeholder = t("calLinkSaved", { host: cal.ref.replace(/\/…$/, "") });
    }
    row.style.setProperty("--cal", cal.color || "#888");
  }
  el("addCalendar").disabled = cals.length >= MAX_CALENDARS;
}

el("addCalendar").addEventListener("click", () => {
  if (cals.length >= MAX_CALENDARS) { setStatus(t("calMax"), "bad", "calNote"); return; }
  const used = new Set(cals.map((c) => c.color));
  const color = CAL_COLORS.find((c) => !used.has(c)) || CAL_COLORS[cals.length % CAL_COLORS.length];
  cals.push({ id: uid(), kind: "ics", ref: "", color, name: "", on: true });
  calsRendered = "";
  renderCalendars();
  const inputs = el("calendars").querySelectorAll('input[type="url"]');
  if (inputs.length) inputs[inputs.length - 1].focus();
});

async function saveHa() {
  const changes = { HaUrl: el("HaUrl").value.trim() };
  const token = el("HaToken").value.trim();
  if (token) changes.HaToken = token;
  const changed = await save(changes);
  el("HaToken").value = "";
  if (changed.includes("HaUrl") || changed.includes("HaToken")) await testHa();
}

async function testHa() {
  setStatus(t("testing"), "busy", "haNote");
  try {
    const result = await api("./api/hatest", { method: "POST" });
    setStatus(result.message, result.ok ? "ok" : "bad", "haNote");
    if (result.ok) { haCals = result.calendars || []; haError = ""; calsRendered = ""; renderCalendars(); }
  } catch (error) {
    setStatus(error.message, "bad", "haNote");
  }
}

el("HaUrl").addEventListener("change", saveHa);
el("HaToken").addEventListener("change", saveHa);
el("haTestButton").addEventListener("click", async () => {
  if (el("HaToken").value.trim() || el("HaUrl").value.trim() !== (current?.settings.HaUrl || "")) await saveHa();
  else await testHa();
});

// ------------------------------------------------------------ Geburtstage

let bds = [];
let bdsRendered = "";
let bdPending = 0, bdEdit = 0, bdDone = 0;
let bdChain = Promise.resolve();
let birthPeople = null, birthError = "";

const splitDate = (date) => {
  const m = /^(\d{4}|-)-?(\d{2})-(\d{2})$/.exec(date || "");
  return m ? { year: m[1] === "-" ? "" : m[1], month: Number(m[2]), day: Number(m[3]) } : { year: "", month: 0, day: 0 };
};
const joinDate = (year, month, day) => {
  if (!month || !day) return "";
  const mm = String(month).padStart(2, "0"), dd = String(day).padStart(2, "0");
  return /^\d{4}$/.test(String(year)) ? `${year}-${mm}-${dd}` : `--${mm}-${dd}`;
};
const bdFilled = (b) => Boolean(b.name || b.date);

function commitBirthdays() {
  bdEdit = Date.now();
  bdPending++;
  const snapshot = bds.filter(bdFilled).map(({ id, name, date, person }) => ({ id, name, date, person }));
  bdChain = bdChain.then(async () => {
    try {
      await api("./api/settings", { method: "POST", body: JSON.stringify({ Birthdays: snapshot }) });
      setStatus(t("saved"), "ok", "bdNote");
    } catch (error) {
      setStatus(error.message, "bad", "bdNote");
    } finally {
      bdPending--;
      bdDone = Date.now();
    }
  });
  bdChain.then(() => { if (!bdPending) refresh(); });
}

async function loadBirthPeople(force = false) {
  if (birthPeople !== null && !force) return;
  birthPeople = birthPeople || [];
  try {
    birthPeople = ((await api("./api/birthpeople")).people || []).filter((p) => p.name)
      .sort((a, b) => a.name.localeCompare(b.name));
    birthError = "";
  } catch (error) {
    birthError = error.message;
  }
  bdsRendered = "";
  renderBirthdays();
}

function renderBirthdays() {
  const key = JSON.stringify([lang, bds.map((b) => b.id), birthPeople && birthPeople.length, birthError]);
  const box = el("birthdays");
  if (key === bdsRendered) return;
  bdsRendered = key;
  box.replaceChildren();
  if (birthPeople === null && current && current.settings.ServerUrl && current.secretsSet.ApiKey) loadBirthPeople();
  const months = MONTH_NAMES();
  bds.forEach((bd, index) => {
    const row = document.createElement("div");
    row.className = "birthday";
    const parts = splitDate(bd.date);

    const name = document.createElement("input");
    name.type = "text";
    name.maxLength = 40;
    name.value = bd.name || "";
    focusGuard(name);

    const day = document.createElement("select");
    day.append(new Option("–", ""));
    for (let d = 1; d <= 31; d++) day.append(new Option(String(d), String(d)));
    day.value = parts.day ? String(parts.day) : "";

    const month = document.createElement("select");
    month.append(new Option("–", ""));
    months.forEach((label, i) => month.append(new Option(label, String(i + 1))));
    month.value = parts.month ? String(parts.month) : "";

    const year = document.createElement("input");
    year.type = "number";
    year.min = "1900";
    year.max = String(new Date().getFullYear());
    year.inputMode = "numeric";
    year.value = parts.year;
    focusGuard(year);

    const person = document.createElement("select");
    person.append(new Option(birthError || t("bdNoPerson"), ""));
    for (const p of birthPeople || []) person.append(new Option(p.name, p.id));
    if (bd.person && !(birthPeople || []).some((p) => p.id === bd.person)) person.append(new Option("…", bd.person));
    person.value = bd.person || "";

    const changed = () => {
      bd.name = name.value.trim();
      bd.date = joinDate(year.value.trim(), Number(month.value), Number(day.value));
      if (!bd.name && bd.person) {
        const found = (birthPeople || []).find((p) => p.id === bd.person);
        if (found) { bd.name = found.name; name.value = found.name; }
      }
      if (bdFilled(bd)) commitBirthdays();
    };
    name.addEventListener("change", changed);
    day.addEventListener("change", changed);
    month.addEventListener("change", changed);
    year.addEventListener("change", changed);
    person.addEventListener("change", () => {
      bd.person = person.value;
      const found = (birthPeople || []).find((p) => p.id === bd.person);
      if (found && found.birth && !bd.date) {
        const b = splitDate(found.birth);
        day.value = String(b.day); month.value = String(b.month); year.value = b.year;
      }
      changed();
    });

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "secondary remove";
    remove.textContent = t("remove");
    remove.addEventListener("click", () => {
      const filled = bdFilled(bd);
      bds.splice(index, 1);
      if (filled) commitBirthdays();
      bdsRendered = "";
      renderBirthdays();
    });

    row.append(labelled(t("bdName"), name, "wide"), labelled(t("bdDay"), day, "narrow"), labelled(t("bdMonth"), month),
      labelled(t("bdYear"), year, "narrow"), labelled(t("bdPerson"), person, "person"), remove);
    box.append(row);
  });
  el("addBirthday").disabled = bds.length >= MAX_BIRTHDAYS;
}

el("addBirthday").addEventListener("click", () => {
  if (bds.length >= MAX_BIRTHDAYS) { setStatus(t("bdMax"), "bad", "bdNote"); return; }
  bds.push({ id: uid(), name: "", date: "", person: "" });
  bdsRendered = "";
  renderBirthdays();
  const inputs = el("birthdays").querySelectorAll('input[type="text"]');
  if (inputs.length) inputs[inputs.length - 1].focus();
});

function renderBirthdayList(state) {
  const today = new Date();
  const todayIso = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  const rows = ((state.upcoming && state.upcoming.birthdays) || []).map((b) => {
    const face = b.face ? `<img src="./api/face?f=${encodeURIComponent(b.face)}" alt="">` : `<span class="noface">${esc((b.name || "?").slice(0, 1))}</span>`;
    const when = b.date === todayIso ? t("bdToday") : fmtShort(b.date);
    const age = b.age ? ` · ${esc(t("bdAge", { n: b.age }))}` : "";
    return `<li class="bd">${face}<span><b>${esc(b.name)}</b><br><small>${esc(when)}${age}</small></span></li>`;
  });
  const html = rows.join("") || `<li class="muted">${esc(t("nothingSoon"))}</li>`;
  if (el("bdList").dataset.html !== html) { el("bdList").innerHTML = html; el("bdList").dataset.html = html; }
  const people = state.people || {};
  if (!el("bdNote").dataset.sticky && Date.now() - bdDone > 4000) {
    if (state.settings.BirthdaysImmich && people.error) setStatus(people.error, "bad", "bdNote");
    else if (state.settings.BirthdaysImmich && people.count) setStatus(t("bdPeople", { born: fmt(people.born), count: fmt(people.count) }), "", "bdNote");
    else setStatus("", "", "bdNote");
  }
}

// ------------------------------------------------------------ Über die Playlist

let showSticky = 0;
function renderShow(state) {
  if (Date.now() - showSticky < 8000) return;
  const tk = state.takeover || {};
  let text = "", tone = "";
  if (tk.on) { text = t("showOn"); tone = "ok"; }
  else if (tk.pending) { text = t("showPending"); tone = "busy"; }
  else if (tk.note) { text = tk.note; tone = "bad"; }
  else if (tk.playlistNote) { text = tk.playlistNote; }
  else if (tk.shownMonth) { text = t("showShown", { month: fmtMonth(tk.shownMonth) }); }
  setStatus(text, tone, "showNote");
}

el("showButton").addEventListener("click", async () => {
  const button = el("showButton");
  button.disabled = true;
  try {
    const result = await api("./api/show", { method: "POST" });
    setStatus(result.message || "", "busy");
    showSticky = Date.now();
    setStatus(result.message || "", "busy", "showNote");
  } catch (error) {
    setStatus(error.message, "bad");
  }
  setTimeout(() => { button.disabled = false; refresh(); }, 2500);
});

// ------------------------------------------------------------ Alles zeichnen

function render(state, started = 0) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  // Eine eben gewählte Sprache nicht von einer älteren Antwort zurückdrehen lassen.
  if (Date.now() - langChangedAt > 6000 || s.Language === lang) applyLanguage(s.Language);
  const progress = state.progress || {};
  let now = t("nowIdle");
  let bar = null;
  if (state.busy) {
    now = progress.phase === "exif" && progress.todo ? t("nowExif", { done: fmt(progress.done), todo: fmt(progress.todo) })
      : progress.phase === "list" ? t("nowList") : t("nowPhotos");
    if (progress.phase === "exif" && progress.todo) bar = progress.done / progress.todo;
  } else if (state.calBusy) {
    now = t("nowCal");
  }
  el("factNow").textContent = now;
  el("progress").hidden = bar === null;
  el("progressBar").style.width = bar ? `${bar * 100}%` : "0";
  const [thisMonth, nextMonth] = state.months || [];
  const monthText = (m) => !state.indexAt ? "—" : m && m.photos.length ? t("monthFact", { n: fmt(m.photos.length), years: fmt(m.years) }) : t("monthNone");
  el("factThisMonth").textContent = monthText(thisMonth);
  el("factNextMonth").textContent = monthText(nextMonth);
  const up = state.upcoming || {};
  el("factEvents").textContent = state.calAt || !s.Calendars.length ? t("inDays", { n: fmt(up.events || 0), days: s.UpcomingDays }) : "—";
  el("factBirthdays").textContent = t("inDays", { n: fmt((up.birthdays || []).length), days: s.UpcomingDays });
  el("factRead").textContent = clock(state.indexAt);
  el("factVersion").textContent = state.version;
  if (document.activeElement !== el("MakePlaylist")) el("MakePlaylist").value = String(Boolean(state.settings.MakePlaylist));
  el("playlistNote").textContent = state.ownPlaylist || "";
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Calendar Page ${state.version}] `);
  renderServices(state.services);
  renderThumbs(el("thumbs"), thisMonth, false);
  renderThumbs(el("thumbsNext"), nextMonth, true);
  el("resetExcluded").hidden = !state.excluded;
  el("resetExcluded").textContent = t("useAllAgainN", { n: fmt(state.excluded) });
  renderHolidays(state);
  renderBirthdayList(state);
  renderShow(state);

  if (!editing) {
    for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) el(name).value = String(s[name]);
    for (const name of BOOL_SELECTS) el(name).value = String(Boolean(s[name]));
    el("Language").value = lang;
    if (document.activeElement !== el("ApiKey")) {
      el("ApiKey").placeholder = state.secretsSet.ApiKey ? t("keySaved") : t("keyMissing");
    }
    if (document.activeElement !== el("HaToken")) {
      el("HaToken").placeholder = state.secretsSet.HaToken ? t("keySaved") : t("keyMissing");
    }
    if (!pendingCommits && started > lastCommitDone && started > lastEdit &&
        JSON.stringify(s.Sources) !== JSON.stringify(sources)) {
      sources = JSON.parse(JSON.stringify(s.Sources));
      rendered = "";
    }
    const serverCals = s.Calendars.map(({ id, kind, ref, color, name, on }) => ({ id, kind, ref, color, name, on }));
    if (!calPending && started > calDone && started > calEdit && JSON.stringify(serverCals) !== JSON.stringify(cals) &&
        !cals.some((c) => !s.Calendars.some((x) => x.id === c.id) && !c.ref)) {
      cals = serverCals;
      calsRendered = "";
    }
    if (!bdPending && started > bdDone && started > bdEdit && !bds.some((b) => !bdFilled(b)) &&
        JSON.stringify(s.Birthdays) !== JSON.stringify(bds)) {
      bds = JSON.parse(JSON.stringify(s.Birthdays));
      bdsRendered = "";
    }
  }
  renderSources();
  renderCalendars();
  renderBirthdays();
  if (albums === null && s.ServerUrl && state.secretsSet.ApiKey) loadAlbums();
  renderAlbums();
  ifRender(s);
  dfRender(s, state);
}

// ------------------------------------------------------------ Immich-Alben (Filter)

async function loadAlbums() {
  if (!current || !current.settings.ServerUrl || !current.secretsSet.ApiKey) {
    albums = [];
    albumError = t("connectFirst");
  } else {
    albums = albums || [];
    try {
      albums = (await api("./api/albums")).albums || [];
      albumError = albums.length ? "" : t("noAlbums");
    } catch (error) {
      albums = [];
      albumError = error.message;
    }
  }
  renderAlbums();
}

function renderAlbums() {
  if (!current) return;
  const chosen = new Set(current.settings.Albums || []);
  const query = el("albumFilter").value.trim().toLowerCase();
  const list = albums || [];
  // Angehakte Alben zuerst, damit sie in einer langen Liste sichtbar bleiben.
  const rows = list.filter((a) => !query || a.name.toLowerCase().includes(query))
    .sort((a, b) => (chosen.has(b.id) - chosen.has(a.id)) || a.name.localeCompare(b.name));
  const html = rows.map((a) => `<label><input type="checkbox" value="${esc(a.id)}" ${chosen.has(a.id) ? "checked" : ""}>
      <span>${esc(a.name)}</span><small>${fmt(a.count)}</small></label>`).join("");
  const box = el("albumList");
  if (box.dataset.html !== html) { box.innerHTML = html; box.dataset.html = html; }
  const error = albums !== null && albumError;
  const note = error || (chosen.size === 1 ? t("albumChosen") : chosen.size ? t("albumsChosen", { n: chosen.size }) : "");
  setStatus(note, error ? "bad" : "", "albumNote");
}

el("albumFilter").addEventListener("input", renderAlbums);
el("albumList").addEventListener("change", () => {
  const ticked = [...el("albumList").querySelectorAll("input:checked")].map((box) => box.value);
  // Angehakte Alben behalten, die der Suchfilter gerade ausblendet.
  const hidden = (current.settings.Albums || []).filter((id) => !el("albumList").querySelector(`input[value="${id}"]`));
  const next = [...hidden, ...ticked];
  current.settings.Albums = next;
  save({ Albums: next });
});
for (const name of BOOL_SELECTS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value === "true" }));

// Eine einzelne verlorene Abfrage (Proxy, Funk) nicht gleich als Fehler zeigen.
let refreshFails = 0;
async function refresh() {
  try {
    const started = Date.now();
    render(await api("./api/state"), started);
    if (refreshFails) { refreshFails = 0; if (el("statusNote").classList.contains("bad")) setStatus(""); }
  } catch (error) {
    refreshFails++;
    if (refreshFails >= 2 || !current) setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS, ["ApiKey", "HaToken", "albumFilter"])) focusGuard(el(name));
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
el("Folders").addEventListener("change", (e) => save({ Folders: e.target.value }));
el("ShowTime").addEventListener("change", (e) => { if (e.target.value) save({ ShowTime: e.target.value.slice(0, 5) }); });
el("Language").addEventListener("change", (e) => {
  const chosen = e.target.value;
  langChangedAt = Date.now();
  if (current) current.settings.Language = chosen;
  applyLanguage(chosen);
  save({ Language: chosen });
});

// ------------------------------------------------------------ Immich, Knöpfe

async function saveServer() {
  const changes = { ServerUrl: el("ServerUrl").value };
  const key = el("ApiKey").value.trim();
  if (key) changes.ApiKey = key;
  const changed = await save(changes);
  el("ApiKey").value = "";
  if (changed.includes("ServerUrl") || changed.includes("ApiKey")) await testConnection();
}

async function testConnection() {
  setStatus(t("testing"), "busy", "testNote");
  try {
    const result = await api("./api/test", { method: "POST" });
    setStatus(result.message, result.ok ? "ok" : "bad", "testNote");
    if (result.ok) { loadList("immich_album", true); loadAlbums(); setTimeout(() => loadBirthPeople(true), 2500); }
  } catch (error) {
    setStatus(error.message, "bad", "testNote");
  }
}

el("ServerUrl").addEventListener("change", saveServer);
el("ApiKey").addEventListener("change", saveServer);
el("testButton").addEventListener("click", async () => {
  if (el("ApiKey").value.trim() || el("ServerUrl").value !== (current?.settings.ServerUrl || "")) await saveServer();
  else await testConnection();
});
el("refreshButton").addEventListener("click", async () => {
  try {
    const result = await api("./api/refresh", { method: "POST" });
    setStatus(result.message || "", "busy");
    setTimeout(refresh, 1500);
  } catch (error) {
    setStatus(error.message, "bad");
  }
});
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));

applyLanguage("en");
refresh();
setInterval(refresh, 4000);

// ------------------------------------------------------------ Immich-Filter (wie Photo Mosaic, immich_filters.py)

const IF_TEXT = ["City", "State", "Country", "TakenAfter", "TakenBefore", "Make", "Model", "Lens", "Description", "OcrText", "FileName", "SkipNames"];
const IF_NUMBER = ["LastDays", "MinMegapixels", "MinFileKB"];
const IF_CHECK = ["OnThisDay", "WithPeople", "CameraOnly", "NoScreenshots", "NotInAlbum"];
const IF_BOOL_SELECT = ["FavoritesOnly", "IncludeArchived"];
const IF_PICKERS = { People: ["./api/people", "people"], SkipAlbums: ["./api/albums", "albums"], SkipTags: ["./api/tags", "tags"] };
const ifLists = {};
const ifErrors = {};
const ifEsc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const ifHere = (names) => names.filter((name) => el(name));
let ifSettings = null;

async function ifLoad(name, force = false) {
  if (ifLists[name] && !force) return;
  ifLists[name] = ifLists[name] || [];
  try {
    const result = await api(IF_PICKERS[name][0]);
    if (result.success === false) throw new Error(result.error || "?");
    ifLists[name] = result[IF_PICKERS[name][1]] || [];
    ifErrors[name] = "";
  } catch (error) {
    ifLists[name] = [];
    ifErrors[name] = error.message;
  }
  ifLists[name].loaded = true;
  if (ifSettings) ifRenderPickers(ifSettings);
}

function ifRenderPickers(s) {
  for (const name of Object.keys(IF_PICKERS)) {
    const box = el(name + "List");
    if (!box) continue;
    const items = ifLists[name];
    if (!items || !items.loaded) {
      if (s.ServerUrl && !items) ifLoad(name);
      if (!items) box.innerHTML = s.ServerUrl ? `<p class="hint">${ifEsc(t("ifLoading"))}</p>` : "";
      continue;
    }
    const chosen = new Set((s[name] || "").split(",").filter(Boolean));
    const query = el(name + "Filter").value.trim().toLowerCase();
    // Lange Listen: angehakte und gesuchte zuerst, höchstens 200 zeigen
    const rows = items.filter((a) => chosen.has(String(a.id)) || !query || String(a.name).toLowerCase().includes(query))
      .sort((a, b) => (chosen.has(String(b.id)) - chosen.has(String(a.id))) || String(a.name).localeCompare(String(b.name)))
      .slice(0, Math.max(200, chosen.size));
    const html = rows.map((a) => `<label title="${ifEsc(a.name)}"><input type="checkbox" value="${ifEsc(String(a.id))}" ${chosen.has(String(a.id)) ? "checked" : ""}>
        <span class="name">${ifEsc(a.name)}</span>${a.count != null ? `<span class="count">${fmt(a.count)}</span>` : ""}</label>`).join("");
    if (box.dataset.html !== html) { box.innerHTML = html; box.dataset.html = html; }
    const note = el(name + "Note");
    note.textContent = ifErrors[name] || (!items.length ? t("ifNothingHere") : chosen.size ? t(chosen.size === 1 ? "ifOneChosen" : "ifManyChosen", { n: chosen.size }) : "");
    note.className = "status" + (ifErrors[name] ? " bad" : "");
  }
}

function ifRender(s) {
  if (!el("immichFilters")) return;
  if (ifSettings && ifSettings.ServerUrl !== s.ServerUrl) {
    for (const name of Object.keys(ifLists)) delete ifLists[name];
  }
  ifSettings = s;
  for (const name of ifHere(IF_TEXT.concat(IF_NUMBER))) {
    if (document.activeElement !== el(name)) el(name).value = s[name] ?? "";
  }
  for (const name of ifHere(IF_CHECK)) el(name).checked = Boolean(s[name]);
  for (const name of ifHere(IF_BOOL_SELECT)) el(name).value = String(Boolean(s[name]));
  if (el("MinRating")) el("MinRating").value = String(s.MinRating || 0);
  if (el("Orientation")) el("Orientation").value = s.Orientation || "any";
  ifRenderPickers(s);
}

for (const name of ifHere(IF_TEXT)) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of ifHere(IF_NUMBER)) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) || 0 }));
for (const name of ifHere(IF_CHECK)) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of ifHere(IF_BOOL_SELECT)) el(name).addEventListener("change", (e) => save({ [name]: e.target.value === "true" }));
if (el("MinRating")) el("MinRating").addEventListener("change", (e) => save({ MinRating: Number(e.target.value) }));
if (el("Orientation")) el("Orientation").addEventListener("change", (e) => save({ Orientation: e.target.value }));
for (const name of Object.keys(IF_PICKERS)) {
  if (!el(name + "List")) continue;
  el(name + "Filter").addEventListener("input", () => ifSettings && ifRenderPickers(ifSettings));
  el(name + "List").addEventListener("change", () => {
    const list = el(name + "List");
    const ticked = [...list.querySelectorAll("input:checked")].map((box) => box.value);
    // Angehakte behalten, die der Suchfilter gerade ausblendet
    const hidden = (ifSettings[name] || "").split(",").filter(Boolean)
      .filter((id) => !list.querySelector(`input[value="${CSS.escape(id)}"]`));
    save({ [name]: [...hidden, ...ticked].join(",") });
  });
}
// ------------------------------------------------------------ DynaFrame-Filter (wie Photo Mosaic, dynaframe_filters.py)

const DF_TEXT = ["DfAfter", "DfBefore", "DfPlace", "DfMake", "DfModel", "DfLens", "DfText", "DfFileName", "DfSkipNames"];
const DF_NUMBER = ["DfLastDays", "DfMinMegapixels"];
const DF_CHECK = ["DfOnThisDay", "DfCameraOnly", "DfNoScreenshots"];
const dfHere = (names) => names.filter((name) => el(name));

// render(): dfRender(state.settings, state) aufrufen
function dfRender(s, state) {
  if (!el("dynaframeFilters")) return;
  for (const name of dfHere(DF_TEXT.concat(DF_NUMBER))) {
    if (document.activeElement !== el(name)) el(name).value = s[name] || (DF_NUMBER.includes(name) ? 0 : "");
  }
  for (const name of dfHere(DF_CHECK)) el(name).checked = Boolean(s[name]);
  if (el("DfMinRating")) el("DfMinRating").value = String(s.DfMinRating || 0);
  if (el("DfOrientation")) el("DfOrientation").value = s.DfOrientation || "any";
  const note = el("dfNote");
  const count = state && state.dfCount;
  if (note) {
    note.textContent = count && count.total ? t("dfCount", { n: fmt(count.kept), m: fmt(count.total) }) : "";
    note.className = "status" + (count && count.total && !count.kept ? " bad" : "");
  }
}

for (const name of dfHere(DF_TEXT)) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of dfHere(DF_NUMBER)) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) || 0 }));
for (const name of dfHere(DF_CHECK)) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
if (el("DfMinRating")) el("DfMinRating").addEventListener("change", (e) => save({ DfMinRating: Number(e.target.value) }));
if (el("DfOrientation")) el("DfOrientation").addEventListener("change", (e) => save({ DfOrientation: e.target.value }));

// ---- accordion:start
// ------------------------------------------------------------ Aufklappen (tools/plugin-vorlage/accordion)
// Karten und Abschnitte auf- und zuklappen, damit lange Plugin-Seiten übersichtlich
// bleiben. Gesteuert nur über Attribute im HTML (Anleitung: accordion/README.md):
//   <section class="card" data-fold="immich" data-fold-when="uses:immich"> …
//   <h3 class="sub" data-fold="immichFilter" data-fold-start="closed" data-fold-badge="count">
// Eigene Texte (DE/EN/ES) stehen hier, die Sprache kommt aus <html lang>.
(() => {
  const TEXT = {
    open: ["Aufklappen", "Expand", "Desplegar"],
    close: ["Zuklappen", "Collapse", "Plegar"],
    active: ["{n} aktiv", "{n} active", "{n} activos"],
    none: ["Keine Filter", "No filters", "Sin filtros"],
    set: ["Eingerichtet", "Set up", "Configurado"],
    optional: ["Optional", "Optional", "Opcional"],
    lines: ["{n} eingetragen", "{n} entered", "{n} introducidos"],
    svcOk: ["Alles erreichbar", "All reachable", "Todo accesible"],
    svcBad: ["{n} Problem", "{n} problem", "{n} problema"],
    svcBads: ["{n} Probleme", "{n} problems", "{n} problemas"],
    svcWarn: ["Teilweise", "Partly", "Parcial"],
    svcWait: ["Wird geprüft", "Checking", "Comprobando"],
    "off:immich": ["Nur mit Immich als Quelle nötig", "Only needed with Immich as source", "Solo con Immich como fuente"],
    "off:dynaframe": ["Nur mit Fotos aus DynaFrame nötig", "Only needed with photos from DynaFrame", "Solo con fotos de DynaFrame"],
    "off:library": ["Nur mit „Alle Fotos in DynaFrame“ nötig", "Only needed with “All photos in DynaFrame”", "Solo con «Todas las fotos de DynaFrame»"],
    off: ["Gerade nicht gebraucht", "Not needed right now", "No se necesita ahora"],
  };
  const LANGS = ["de", "en", "es"];
  const say = (key, n) => {
    const row = TEXT[key] || TEXT.off;
    const i = Math.max(0, LANGS.indexOf(document.documentElement.lang));
    return (row[i] ?? row[0]).replace("{n}", String(n));
  };
  const store = (() => {
    try { return window.localStorage; } catch (_) { return null; }
  })();
  const keyOf = (id) => `fold:${location.pathname}:${id}`;
  const remembered = (id) => {
    try { return JSON.parse(store?.getItem(keyOf(id)) || "null"); } catch (_) { return null; }
  };
  const remember = (id, value) => {
    try { store?.setItem(keyOf(id), JSON.stringify(value)); } catch (_) { /* privat */ }
  };

  // Quellen-Auswahl: jedes <select>, das eine Immich-Option hat (auch Quellen-Zeilen, die studio.js erst später baut)
  const DF_KINDS = ["library", "folders", "playlist", "same"];
  function sourceValues() {
    const values = [];
    for (const select of document.querySelectorAll("select")) {
      if ([...select.options].some((o) => o.value.startsWith("immich"))) values.push(select.value);
    }
    return values;
  }
  function holds(rule) {
    // "uses:immich", "uses:dynaframe", "uses:library" oder "Feld=wert1,wert2", mehrere mit "|"
    return rule.split("|").some((part) => {
      part = part.trim();
      if (part.startsWith("uses:")) {
        const values = sourceValues();
        if (!values.length) return true; // keine Quellen-Auswahl auf der Seite: immer gebraucht
        const what = part.slice(5);
        if (what === "immich") return values.some((v) => v.startsWith("immich"));
        if (what === "dynaframe") return values.some((v) => DF_KINDS.includes(v));
        return values.includes(what);
      }
      const [id, list] = part.split("=");
      const field = document.getElementById(id);
      if (!field) return true;
      const value = field.type === "checkbox" ? String(field.checked) : field.value;
      return (list || "").split(",").map((v) => v.trim()).includes(value);
    });
  }

  // Wie viele Einstellungen in einem Bereich vom Standard abweichen (Felder mit Wert, Häkchen, Auswahl ≠ erste Option)
  function activeCount(nodes) {
    let n = 0;
    for (const node of nodes) {
      for (const field of node.querySelectorAll("input, select, textarea")) {
        if (field.closest(".checks") || field.type === "password" || field.type === "button") continue;
        if (field.type === "checkbox") n += field.checked ? 1 : 0;
        else if (field.tagName === "SELECT") n += field.selectedIndex > 0 ? 1 : 0;
        else n += field.value.trim() && field.value.trim() !== "0" ? 1 : 0;
      }
      for (const list of node.querySelectorAll(".checks")) n += list.querySelector("input:checked") ? 1 : 0;
    }
    return n;
  }

  function badgeFor(fold) {
    if (!fold.needed) return [say(`off:${fold.rule.replace(/^uses:/, "").split("|")[0]}`), "off"];
    const nodes = fold.body();
    switch (fold.badge) {
      case "count": {
        const n = activeCount(nodes);
        return n ? [say("active", n), "on"] : [say("none"), ""];
      }
      case "filled": {
        const filled = nodes.some((node) => [...node.querySelectorAll('input[type="url"], input[type="text"]')].some((f) => f.value.trim()));
        return filled ? [say("set"), "on"] : [say("optional"), ""];
      }
      case "lines": {
        const n = nodes.reduce((sum, node) => sum + [...node.querySelectorAll("textarea")]
          .reduce((s, area) => s + area.value.split("\n").filter((line) => line.trim()).length, 0), 0);
        return n ? [say("lines", n), "on"] : [say("optional"), ""];
      }
      case "services": {
        const bad = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.bad").length, 0);
        const warn = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.warn").length, 0);
        const ok = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.ok").length, 0);
        if (bad) return [say(bad === 1 ? "svcBad" : "svcBads", bad), "bad"];
        if (warn) return [say("svcWarn"), "warn"];
        return ok ? [say("svcOk"), "ok"] : [say("svcWait"), ""];
      }
      default:
        return ["", ""];
    }
  }

  const folds = [];

  function setup(head, id, isCard) {
    const host = isCard ? head : head.parentElement;
    const title = isCard ? (head.querySelector(":scope > .card-head") || head.querySelector(":scope > h2")) : head;
    if (!title) return;
    const bar = document.createElement("div");
    bar.className = "fold-bar" + (isCard ? " fold-bar-card" : " fold-bar-sub");
    bar.setAttribute("role", "button");
    bar.tabIndex = 0;
    title.replaceWith(bar);
    bar.append(title);
    const badge = document.createElement("span");
    badge.className = "fold-badge";
    const chevron = document.createElement("span");
    chevron.className = "fold-chevron";
    chevron.setAttribute("aria-hidden", "true");
    bar.append(badge, chevron);
    let body = null;
    if (!isCard) {
      // Unterabschnitt: alles bis zum nächsten h3.sub / <details> / Kartenende
      body = document.createElement("div");
      body.className = "fold-body";
      let next = bar.nextElementSibling;
      while (next && !(next.matches("h3.sub, .fold-bar, details"))) {
        const after = next.nextElementSibling;
        body.append(next);
        next = after;
      }
      bar.after(body);
    }
    const src = head;
    const fold = {
      id, host, bar, body: () => (isCard ? [...host.children].filter((c) => c !== bar) : [body]),
      rule: src.dataset.foldWhen || "",
      startClosed: src.dataset.foldStart === "closed",
      badge: src.dataset.foldBadge || "", badgeEl: badge,
      needed: true, open: true, isCard, sub: body,
    };
    const toggle = (e) => {
      if (e.type === "click" && e.target.closest("button, a, input, select, textarea, label")) return;
      if (e.type === "keydown" && (e.target !== bar || (e.key !== "Enter" && e.key !== " "))) return;
      if (e.type === "keydown") e.preventDefault();
      show(fold, !fold.open);
      remember(id, { open: fold.open, needed: fold.needed });
    };
    bar.addEventListener("click", toggle);
    bar.addEventListener("keydown", toggle);
    folds.push(fold);
    if (fold.rule) show(fold, false); // erst entscheiden, wenn studio.js den Stand gesetzt hat
    else start(fold);
  }

  function start(fold) {
    const saved = remembered(fold.id);
    fold.needed = fold.rule ? holds(fold.rule) : true;
    fold.wasNeeded = fold.needed;
    fold.started = true;
    show(fold, saved && saved.needed === fold.needed ? saved.open : wanted(fold));
  }

  function wanted(fold) {
    if (!fold.needed) return false;
    if (fold.badge === "services") {
      const [, tone] = badgeFor(fold);
      if (tone === "bad") return true;
    }
    return !fold.startClosed;
  }

  function show(fold, open) {
    fold.open = open;
    fold.host.classList.toggle("fold-closed", fold.isCard && !open);
    if (fold.sub) fold.sub.hidden = !open;
    fold.bar.setAttribute("aria-expanded", String(open));
    fold.bar.title = say(open ? "close" : "open");
  }

  // Bereit, sobald studio.js den ersten Stand gezeigt hat (Version steht da) oder nach 5 s
  const born = Date.now();
  function stateShown() {
    const version = document.getElementById("factVersion");
    return !version || /\d/.test(version.textContent) || Date.now() - born > 5000;
  }

  function refresh() {
    const ready = stateShown();
    for (const fold of folds) {
      if (!fold.started) {
        if (!ready) continue;
        start(fold);
      }
      fold.needed = fold.rule ? holds(fold.rule) : true;
      if (fold.needed !== fold.wasNeeded) {
        // Quelle gewechselt: Karte auf- bzw. zuklappen, eigene Wahl vergessen
        fold.wasNeeded = fold.needed;
        remember(fold.id, null);
        show(fold, wanted(fold));
      }
      fold.host.classList.toggle("fold-unused", fold.isCard && !fold.needed);
      const [text, tone] = badgeFor(fold);
      // Verbindungen: bei einem neuen Problem von selbst aufklappen
      if (fold.badge === "services" && tone === "bad" && fold.lastTone !== "bad") show(fold, true);
      fold.lastTone = tone;
      if (fold.badgeEl.textContent !== text) fold.badgeEl.textContent = text;
      fold.badgeEl.className = "fold-badge" + (tone ? ` ${tone}` : "");
      fold.badgeEl.hidden = !text;
      fold.bar.title = say(fold.open ? "close" : "open");
    }
  }

  function init() {
    for (const card of document.querySelectorAll(".card[data-fold]")) setup(card, card.dataset.fold, true);
    for (const head of document.querySelectorAll("h3.sub[data-fold]")) setup(head, head.dataset.fold, false);
    refresh();
    document.addEventListener("change", refresh);
    document.addEventListener("input", refresh);
    setInterval(refresh, 1000); // studio.js setzt Werte beim Abfragen des Stands
  }

  window.Fold = { refresh, open: (id, value = true) => { const f = folds.find((x) => x.id === id); if (f) show(f, value); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
// ---- accordion:end
