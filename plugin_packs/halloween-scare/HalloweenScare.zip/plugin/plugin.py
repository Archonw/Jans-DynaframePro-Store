#!/usr/bin/env python3
"""Halloween Scare - der Plugin-Teil des Pakets.

Der Rahmen zeigt ganz normal Fotos. Meldet ein Bewegungsmelder in Home
Assistant Bewegung (oder klingelt es an der Tür, oder feuert eine Automation
das Ereignis halloween_scare), holt das Plugin die Szene "halloween-scare"
über die Playlist und spielt einen von vier Schrecks:

- portrait: ein altes Ölporträt, dessen Augen dich finden und das dann
  kreischend zur Fratze wird,
- ghost: im gerade gezeigten Foto steht kurz eine blasse Gestalt, dann
  springt sie dich an,
- static: das Bild rauscht wie ein alter Fernseher, eine Gestalt kommt bei
  jeder Störung näher,
- monster: Klauen an der Bildkante, Glutaugen, dann brüllt ein Monster
  ("Süßes oder Saures!").

Jeden gibt es auch sanft für Kinder (zwinkern, Bettlaken-Geist, niedliches
Monster). Die Geräusche spielt das Plugin selbst auf dem Rahmen, auf
Zuruf der Szene (api/cue), damit sie genau zum Bild passen.

Die Szene erreicht die Seite dieses Plugins über den Proxy der Weboberfläche
(:80 bzw. :8003), wie Home Assistant Live.
"""

import json
import os
import random
import re
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import ha  # noqa: E402
import texts  # noqa: E402

try:
    # Umgeht einen Dynaframe-Fehler, der einen Quick Mix nach einem Takeover
    # gestoppt lassen kann (siehe dort). Ohne die Datei läuft alles weiter.
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None

plugin = create_plugin()

PLUGIN_ID = "HalloweenScare"
DISPLAY_NAME = "Halloween Scare"
SCENE_ID = "halloween-scare"        # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen und Zustand; bleibt bei Updates
SOUNDS = PLUGIN_DIR / "sounds"

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30

MODES = ("portrait", "ghost", "static", "monster")
VARIANTS = ("lady", "captain", "child")
# Wie lange ein Schreck nach dem Anschleichen dauert (wie in scene.js).
TAIL_SECONDS = {("portrait", False): 7.5, ("portrait", True): 5.5, ("ghost", False): 5, ("ghost", True): 5,
                ("static", False): 4.8, ("static", True): 4.8, ("monster", False): 6.5, ("monster", True): 6.5}
LOAD_MARGIN = 15      # Zeit für den Wechsel zur Szene und das Laden des Fotos
CUES = {"ambient", "scream", "whisper", "shriek", "static", "bang", "growl", "roar", "giggle", "boo"}


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        pass
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Could not read {path.name}: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=1, ensure_ascii=False)
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält das Token
        except OSError:
            pass


def local_text(epoch):
    if not epoch:
        return ""
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


ENTITY_ID = re.compile(r"^[a-z_]+\.[a-z0-9_]+$")


def entity(raw):
    value = str(raw or "").strip().lower()
    return value if ENTITY_ID.match(value) else ""


# --------------------------------------------------------------------------
# Einstellungen (alle auf der Plugin-Seite; das Manifest deklariert keine)
# --------------------------------------------------------------------------

SETTINGS = {
    "Language":      {"kind": "choice", "default": "en", "options": list(texts.LANGUAGES)},
    "Armed":         {"kind": "bool", "default": True},
    "Url":           {"kind": "url", "default": ""},
    "Token":         {"kind": "secret", "default": ""},
    # Auslöser
    "Motion":        {"kind": "entities", "default": []},
    "MotionMode":    {"kind": "choice", "default": "portrait", "options": ["random", *MODES]},
    "Doorbell":      {"kind": "entity", "default": ""},
    "DoorbellMode":  {"kind": "choice", "default": "monster", "options": ["random", *MODES]},
    # Der Schreck
    "Variant":       {"kind": "choice", "default": "random", "options": ["random", *VARIANTS]},
    "Intensity":     {"kind": "choice", "default": "scary", "options": ["scary", "gentle"]},
    "Lurk":          {"kind": "number", "default": 5, "min": 2, "max": 20},
    "MonsterText":   {"kind": "text", "default": ""},
    "Cooldown":      {"kind": "number", "default": 3, "min": 0, "max": 240},
    "Chance":        {"kind": "number", "default": 100, "min": 5, "max": 100},
    # Ton
    "Sound":         {"kind": "bool", "default": True},
    "Volume":        {"kind": "number", "default": 80, "min": 0, "max": 100},
    # Wann
    "SeasonOnly":    {"kind": "bool", "default": False},
    "QuietEnabled":  {"kind": "bool", "default": False},
    "QuietFrom":     {"kind": "number", "default": 22, "min": 0, "max": 23},
    "QuietTo":       {"kind": "number", "default": 7, "min": 0, "max": 23},
    "WakeScreen":    {"kind": "bool", "default": False},
}

SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return list(default) if isinstance(default, list) else default
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "number":
        return max(spec["min"], min(spec["max"], as_int(raw, default)))
    if kind == "choice":
        value = str(raw).strip().lower()
        return value if value in spec["options"] else default
    if kind == "url":
        return ha.normalize_url(raw)[:300]
    if kind == "secret":
        return re.sub(r"\s+", "", str(raw))[:1000]
    if kind == "entity":
        return entity(raw)
    if kind == "entities":
        items = raw if isinstance(raw, list) else str(raw).split(",")
        return sorted({entity(i) for i in items} - {""})[:100]
    if kind == "text":
        return re.sub(r"\s+", " ", str(raw)).strip()[:60]
    return str(raw)[:200]


def settings():
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
    return {name: coerce(name, stored.get(name)) for name in SETTINGS}


def tr(template, **values):
    """Ein Text in der eingestellten Sprache (siehe texts.py)."""
    return texts.t(settings()["Language"], template, **values)


def save_settings(changes):
    changed = []
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            value = coerce(name, raw)
            if stored.get(name) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, stored)
    return changed


_state_lock = threading.Lock()


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**fields):
    with _state_lock:
        state = read_json(STATE_FILE, {}) or {}
        if all(k in state and state[k] == v for k, v in fields.items()):
            return state  # nichts Neues, also kein Schreiben auf die SD-Karte
        state.update(fields)
        write_json(STATE_FILE, state)
    return state


def in_quiet_hours(values, moment=None):
    if not values["QuietEnabled"]:
        return False
    hour = (moment or datetime.now()).hour
    start, end = values["QuietFrom"], values["QuietTo"]
    if start == end:
        return False
    if start < end:
        return start <= hour < end
    return hour >= start or hour < end  # über Mitternacht, z.B. 22 bis 7


def in_season(moment=None):
    """1. Oktober bis 2. November."""
    day = moment or datetime.now()
    return day.month == 10 or (day.month == 11 and day.day <= 2)


# --------------------------------------------------------------------------
# Home Assistant: was es gibt, und die Liste für die Plugin-Seite
# --------------------------------------------------------------------------

MOTION_CLASSES = {"motion", "occupancy", "presence", "moving", "vibration"}
MOTION_WORDS = re.compile(r"bewegung|motion|pir|präsenz|praesenz|presence|occupancy|movimiento|presencia", re.I)
DOORBELL_WORDS = re.compile(r"klingel|doorbell|door_bell|ring|timbre|bell|läut", re.I)
OPENING_CLASSES = {"door", "window", "garage_door", "opening"}


def rest(values=None):
    values = values or settings()
    return ha.Rest(values["Url"], values["Token"])


def friendly(row):
    attrs = row.get("attributes") or row.get("a") or {}
    return str(attrs.get("friendly_name") or row.get("entity_id") or "")


def is_motion(row):
    attrs = row.get("attributes") or {}
    if not row["entity_id"].startswith("binary_sensor."):
        return False
    return attrs.get("device_class") in MOTION_CLASSES or \
        bool(MOTION_WORDS.search(row["entity_id"] + " " + friendly(row)))


def is_doorbell(row):
    attrs = row.get("attributes") or {}
    domain = row["entity_id"].split(".", 1)[0]
    if domain == "event" and attrs.get("device_class") == "doorbell":
        return True
    return domain in {"binary_sensor", "event", "input_boolean", "switch", "button", "input_button"} and \
        bool(DOORBELL_WORDS.search(row["entity_id"] + " " + friendly(row))) and \
        attrs.get("device_class") not in OPENING_CLASSES


_catalog = {"at": 0.0, "rows": [], "error": "", "config": {}}
_catalog_lock = threading.Lock()


def catalog(force=False):
    """Alle Entitäten aus /api/states, eine Minute lang zwischengespeichert."""
    with _catalog_lock:
        if not force and _catalog["rows"] and now() - _catalog["at"] < 60:
            return _catalog["rows"]
        values = settings()
        if not values["Url"] or not values["Token"]:
            _catalog.update(rows=[], error="", at=0.0)
            return []
        try:
            client = rest(values)
            _catalog["config"] = client.config() or {}
            rows = client.states()
            _catalog.update(rows=rows, error="", at=now())
        except ha.HaError as exc:
            _catalog.update(error=str(exc), at=now())
            return _catalog["rows"]
        return rows


def entities_payload():
    rows = catalog(force=True)
    if _catalog["error"] and not rows:
        return {"success": False, "error": error_text(_catalog["error"])}

    def item(row):
        attrs = row.get("attributes") or {}
        out = {"id": row["entity_id"], "name": friendly(row), "state": row.get("state")}
        if attrs.get("device_class"):
            out["class"] = attrs["device_class"]
        return out

    by_name = sorted(rows, key=lambda r: friendly(r).lower())
    motion = [item(r) for r in by_name if is_motion(r)]
    motion_ids = {m["id"] for m in motion}
    return {
        "success": True,
        "motion": motion,
        # Alles, was an/aus kann, für Bewegungsmelder mit ungewöhnlichem Namen
        "binary": [item(r) for r in by_name if r["entity_id"].startswith(("binary_sensor.", "input_boolean.", "switch.", "light."))
                   and r["entity_id"] not in motion_ids][:600],
        "doorbells": [item(r) for r in by_name if is_doorbell(r)],
        "triggers": [item(r) for r in by_name
                     if r["entity_id"].split(".", 1)[0] in {"binary_sensor", "event", "input_boolean", "input_button",
                                                            "button", "switch", "light"} and not is_doorbell(r)][:600],
    }


def auto_setup():
    """Beim ersten Verbinden das Offensichtliche selbst eintragen: alle
    Bewegungsmelder (bis acht) und die einzige Klingel."""
    if load_state().get("autoSetupDone"):
        return []
    rows = catalog(force=True)
    if not rows:
        return []
    values = settings()
    found, changes = [], {}
    motion = [r for r in rows if is_motion(r) and (r.get("attributes") or {}).get("device_class") in MOTION_CLASSES]
    if not values["Motion"] and 0 < len(motion) <= 8:
        changes["Motion"] = [r["entity_id"] for r in motion]
        found.extend(friendly(r) for r in motion)
    bells = [r for r in rows if is_doorbell(r)]
    events = [r for r in bells if r["entity_id"].startswith("event.")]
    bells = events or bells
    if not values["Doorbell"] and len(bells) == 1:
        changes["Doorbell"] = bells[0]["entity_id"]
        found.append(friendly(bells[0]))
    if changes:
        save_settings(changes)
    save_state(autoSetupDone=True, autoFound=found)
    if found:
        plugin.log("Filled in automatically: " + ", ".join(found))
    return found


ERRORS = {
    "no-url": "Enter the address of your Home Assistant first.",
    "no-token": "Enter a long-lived access token first.",
    "token": "Home Assistant rejects the access token. Create a new one and paste it here.",
    "not-found": "No Home Assistant answers at this address. Is the port right (usually 8123)?",
    "no-websocket-client": "The websocket-client package is missing. Install Halloween Scare again.",
}


def error_text(code):
    code = str(code or "")
    if code in ERRORS:
        return tr(ERRORS[code])
    if code.startswith("ssl:"):
        return tr("Home Assistant's certificate is not accepted. Use the local address with http:// and port 8123, "
                  "e.g. http://192.168.1.20:8123.")
    if code.startswith("unreachable:"):
        return tr("Home Assistant cannot be reached at this address. Check the address and port.")
    if code.startswith("http:"):
        return tr("Home Assistant answers with error {code}.", code=code[5:])
    return code


# --------------------------------------------------------------------------
# Der Schreck
# --------------------------------------------------------------------------

_event_lock = threading.Lock()
_event = {"current": None}       # der laufende oder zuletzt ausgelöste Schreck
_counter = {"n": int(now()) % 100000}
_history = []                    # die letzten Auslöser für die Plugin-Seite
_last = {"scareAt": 0.0}


def remember(source, mode, result, detail=""):
    _history.insert(0, {"at": now(), "source": source, "mode": mode, "result": result, "detail": detail})
    del _history[12:]


def pick(value, options):
    return random.choice(options) if value == "random" else value


def scare_duration(mode, gentle, lurk):
    return lurk + TAIL_SECONDS[(mode, gentle)]


def trigger(source, detail="", mode=None, variant=None, intensity=None, lurk=None, text=None, force=False):
    """Einen Schreck auslösen. force: ohne Pause, Zufall, Ruhezeit und
    Scharfschalten (Probe von der Plugin-Seite, Aktion "Scare now")."""
    values = settings()
    t = now()
    mode_setting = values["DoorbellMode"] if source == "doorbell" else values["MotionMode"]
    if mode == "random":
        mode = random.choice(MODES)
    elif mode not in MODES:
        mode = pick(mode_setting, list(MODES))
    if not force:
        reason = ""
        if not values["Armed"]:
            reason = tr("switched off")
        elif values["SeasonOnly"] and not in_season():
            reason = tr("not Halloween season")
        elif in_quiet_hours(values):
            reason = tr("quiet hours")
        elif t - _last["scareAt"] < values["Cooldown"] * 60:
            reason = tr("pause after the last scare")
        elif values["Chance"] < 100 and random.uniform(0, 100) > values["Chance"]:
            reason = tr("chance said no")
        if reason:
            plugin.log(f"Trigger from {source} ({detail}) ignored: {reason}.")
            remember(source, mode, "skipped", reason)
            return None
    with _event_lock:
        current = _event["current"]
        if current and current["until"] > t and not force:
            remember(source, mode, "skipped", tr("a scare is already running"))
            return None
    gentle = (intensity or values["Intensity"]) == "gentle"
    lurk = max(2, min(20, as_int(lurk, values["Lurk"]))) if lurk is not None else values["Lurk"]
    if source == "doorbell" and lurk > 4:
        lurk = 4   # an der Tür wartet niemand lange
    variant = variant if variant in VARIANTS else pick(values["Variant"], list(VARIANTS))
    _counter["n"] += 1
    event = {"id": _counter["n"], "mode": mode, "variant": variant, "intensity": "gentle" if gentle else "scary",
             "lurk": lurk, "text": (text or values["MonsterText"] or "")[:60], "source": source, "detail": detail,
             "at": t, "until": t + scare_duration(mode, gentle, lurk) + LOAD_MARGIN, "started": 0.0,
             "photo": None, "cues": set(), "force": force}
    # Das Foto, das gerade läuft, merken, bevor die Szene es verdeckt.
    if mode != "portrait":
        event["photo"] = current_photo()
    with _event_lock:
        _event["current"] = event
    _last["scareAt"] = t
    save_state(lastScareAt=t)
    remember(source, mode, "shown", detail)
    plugin.log(f"Scare {event['id']}: {mode} ({event['intensity']}, {variant}) from {source}"
               + (f" ({detail})" if detail else "") + (", with the current photo" if event["photo"] else ""))
    _wake.set()
    return event


def active_event(t=None):
    t = t or now()
    with _event_lock:
        event = _event["current"]
        return event if event and event["until"] > t else None


def finish_event(event_id=None):
    with _event_lock:
        event = _event["current"]
        if event and (event_id is None or str(event["id"]) == str(event_id)):
            event["until"] = min(event["until"], now())
    _wake.set()


def attributes_of(entity_id):
    row = stream.states.get(entity_id) or {}
    return row.get("a") or {}


def name_of(entity_id):
    name = attributes_of(entity_id).get("friendly_name")
    if not name:
        row = next((r for r in _catalog["rows"] if r["entity_id"] == entity_id), None)
        name = friendly(row) if row else ""
    return str(name or entity_id)


def watched_entities(values=None):
    values = values or settings()
    ids = set(values["Motion"])
    if values["Doorbell"]:
        ids.add(values["Doorbell"])
    return ids


_seen_values = {}


def on_change(entity_id, old, new, attrs, fresh=True):
    """Vom Websocket für jede Zustandsänderung einer beobachteten Entität."""
    values = settings()
    domain = entity_id.split(".", 1)[0]
    name = str(attrs.get("friendly_name") or name_of(entity_id))
    before = None
    if domain == "event" and new not in ha.INVALID:
        before = _seen_values.get(entity_id)
        _seen_values[entity_id] = new
    if not fresh:
        return
    plugin.log(f"Home Assistant: {name} ({entity_id}) {old} -> {new}")
    if domain != "event" or new not in ha.INVALID:
        # Für die Plugin-Seite: kommt die Änderung überhaupt an?
        remember("ha", "", "seen", f"{name}: {old} → {new}")
    if values["Doorbell"] == entity_id and doorbell_rang(domain, old, new, before):
        threading.Thread(target=trigger, args=("doorbell", name), daemon=True).start()
        return
    if entity_id in values["Motion"] and old == "off" and new == "on":
        threading.Thread(target=trigger, args=("motion", name), daemon=True).start()


def doorbell_rang(domain, old, new, before):
    if new in ha.INVALID:
        return False
    if domain == "event":
        # Der Zustand ist der Zeitpunkt des letzten Drückens. Nach einem
        # Neustart von HA kommt derselbe Zeitpunkt wieder; der zählt nicht.
        if new == before:
            return False
        if before is None:
            try:
                pressed = datetime.fromisoformat(str(new).replace("Z", "+00:00")).timestamp()
            except ValueError:
                return False
            return now() - pressed < 60
        return True
    if domain in {"button", "input_button"}:
        return old not in ha.INVALID
    return old == "off" and new == "on"


def on_custom(data):
    """Das Ereignis halloween_scare aus einer Automation in Home Assistant.
    Alles freiwillig: mode, variant, intensity, lurk, text, force."""
    if not isinstance(data, dict):
        data = {}
    mode = str(data.get("mode") or "").strip().lower() or None
    variant = str(data.get("variant") or "").strip().lower() or None
    intensity = str(data.get("intensity") or "").strip().lower() or None
    if intensity not in (None, "scary", "gentle"):
        intensity = None
    threading.Thread(target=trigger, kwargs={
        "source": "automation", "detail": "halloween_scare", "mode": mode if mode in (*MODES, "random") else None,
        "variant": variant, "intensity": intensity,
        "lurk": data.get("lurk"), "text": str(data.get("text") or "")[:60] or None,
        "force": as_bool(data.get("force"))}, daemon=True).start()


def on_ws_status(state, error):
    if state == "connected":
        plugin.log("Connected to Home Assistant.")
        save_state(lastConnectedAt=now())
    elif state == "error":
        plugin.log(f"Home Assistant: {error_text(error)} ({error})", level="warning")


stream = ha.Stream(plugin.log, on_change, on_custom, on_ws_status)


def reconnect():
    values = settings()
    stream.configure(values["Url"], values["Token"], watched_entities(values))


# --------------------------------------------------------------------------
# Die Engine auf diesem Rahmen
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} returned HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "note": ""}


def find_scene():
    """Die installierte Szene. Ihre numerische id braucht ein Playlist-Eintrag."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else
                      tr("The Halloween Scare scene is switched off on the Plugins page."))
        return row
    _scene.update(dbId=None, note=tr("The Halloween Scare scene is not installed on this frame. "
                                     "Install the package again."))
    return None


# --------------------------------------------------------------------------
# Das Foto, das gerade läuft (für Geist, Störsignal und Monster)
# --------------------------------------------------------------------------

PATH_KEYS = ("filePath", "path", "fullPath", "localPath", "mediaPath", "sourcePath")
ID_KEYS = ("mediaId", "mediaItemId", "mediaFileId", "id")
SHOWABLE = (".jpg", ".jpeg", ".jpe", ".png", ".webp", ".gif", ".bmp", ".avif")
PHOTO_MAX = 25 * 1024 * 1024
_photos = {}            # event id -> (bytes, content type)
_photo_note = {"logged": False}


def first_key(row, keys):
    if not isinstance(row, dict):
        return None
    for key in keys:
        if row.get(key) not in (None, ""):
            return row[key]
    for inner in ("media", "mediaItem", "item", "file"):
        value = row.get(inner)
        if isinstance(value, dict):
            found = first_key(value, keys)
            if found not in (None, ""):
                return found
    return None


def engine_thumbnail(media_id, path):
    candidates = []
    if path:
        candidates += [("/media/thumbnail", {"path": path, "purpose": "preview"}), ("/media/thumbnail", {"path": path})]
    if media_id:
        candidates += [(f"/media/thumbnail/{media_id}", {"purpose": "preview"}), (f"/media/thumbnail/{media_id}", None)]
    for route, params in candidates:
        try:
            response = requests.get(engine_base() + route, params=params, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 20))
        except requests.RequestException:
            continue
        kind = response.headers.get("Content-Type", "").split(";")[0]
        if response.status_code == 200 and kind.startswith("image/"):
            return response.content, kind
    return None


def current_photo():
    """(bytes, content type) des Fotos, das der Rahmen gerade zeigt, oder None
    (Video, Szene, nichts läuft): dann nimmt die Szene ihren gemalten Flur."""
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", read_timeout=5) or {}
    except EngineError:
        return None
    item = status.get("currentItem") or {}
    if not status.get("isRunning") or not item or item.get("dynamicSceneId"):
        return None
    path = str(first_key(item, PATH_KEYS) or "")
    media_id = first_key(item, ID_KEYS)
    if not _photo_note["logged"]:
        _photo_note["logged"] = True
        plugin.log(f"Current item keys: {sorted(item.keys())[:30]}")
    kind = {".png": "image/png", ".webp": "image/webp", ".gif": "image/gif", ".bmp": "image/bmp",
            ".avif": "image/avif"}.get(Path(path).suffix.lower(), "image/jpeg")
    if path.lower().endswith(SHOWABLE) and os.path.isfile(path):
        try:
            if os.path.getsize(path) <= PHOTO_MAX:
                return Path(path).read_bytes(), kind
        except OSError:
            pass
    if path and not path.lower().endswith(SHOWABLE + (".heic", ".heif", ".dng", ".cr2", ".nef", ".arw")):
        return None   # ein Video
    cached = webdav_cached(path, item.get("fileSize"))
    if cached:
        try:
            return cached.read_bytes(), kind
        except OSError:
            pass
    return engine_thumbnail(media_id, path)


def webdav_dirs():
    seen = []
    for home in (Path.home(), Path("/home/pi")):
        folder = home / ".local/share/dfr/webdav-cache"
        if folder not in seen and folder.is_dir():
            seen.append(folder)
    return seen


def webdav_cached(path, size):
    """Fotos aus WebDAV (/webdav-media/<Quelle>/...) liest DynaFrame nicht
    direkt, die Engine liefert davon nur ein Vorschaubild mit 512 Pixeln.
    Das Original legt DynaFrame aber in webdav-cache ab, als
    <Quelle>-<Hash>.<Endung>. Den Hash kennen wir nicht, also: gleiche Quelle,
    gleiche Endung, gleiche Dateigröße; bei mehreren die neueste."""
    if not path.startswith("/webdav-media/"):
        return None
    try:
        size = int(size)
    except (TypeError, ValueError):
        return None
    if size <= 0 or size > PHOTO_MAX:
        return None
    source = path.split("/")[2] if len(path.split("/")) > 2 else ""
    suffix = Path(path).suffix.lower()
    best = None
    for folder in webdav_dirs():
        try:
            entries = list(os.scandir(folder))
        except OSError:
            continue
        for entry in entries:
            name = entry.name
            if source and not name.startswith(source + "-"):
                continue
            if suffix and not name.lower().endswith(suffix):
                continue
            try:
                info = entry.stat()
            except OSError:
                continue
            if info.st_size == size and (best is None or info.st_mtime > best[0]):
                best = (info.st_mtime, Path(entry.path))
    return best[1] if best else None


# --------------------------------------------------------------------------
# Die Takeover-Playlist
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = "Halloween Scare (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Played by the Halloween Scare plugin when it takes over the screen. Stays "
                                 "switched off so it does not end up in a Quick Mix. The plugin creates it again "
                                 "if it is deleted.")
TAKEOVER_ITEM_SECONDS = 6 * 3600  # das Plugin beendet die Anzeige lange vorher

_playlists = {"at": 0.0, "takeoverId": None, "note": ""}
_playlist_lock = threading.Lock()


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError:
        return False
    return bool(status.get("active"))


def ensure_takeover_playlist():
    """Ein Takeover spielt eine Playlist, keine einzelne Szene. Also: die
    Szene allein, sechs Stunden, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if i.get("dynamicSceneId") == _scene["dbId"]]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_PLAYLIST_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("The frame did not create the playlist {name}.", name=TAKEOVER_PLAYLIST_NAME))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    plugin.log(f"Created the playlist {TAKEOVER_PLAYLIST_NAME} ({playlist_id}).")
    return playlist_id


def maintain_playlists(force=False):
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        find_scene()
        if _scene["dbId"] is None:
            _playlists["note"] = _scene["note"]
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Could not create the takeover playlist: {exc}", exc=exc)
            plugin.log(_playlists["note"], level="warning")


# --------------------------------------------------------------------------
# Den Bildschirm übernehmen und zurückgeben
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
MAX_SESSION_SECONDS = 120

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "since": None, "token": 0, "note": "", "eventId": None}
_stop_requested = threading.Event()
_wake = threading.Event()


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform") or {}
    except EngineError:
        return True
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Halloween Scare is switched off on the Plugins page.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("“Allow takeover” is off for Halloween Scare on the Plugins page. Switch it on, otherwise "
                  "nothing can be shown.")
    return ""


def display_is_off():
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def scene_in_playlist():
    """Läuft die Szene gerade ganz normal in einer Playlist? Dann spielt sie
    den Schreck selbst, ohne Takeover (das Porträt hängt schon da)."""
    if _scene["dbId"] is None:
        return False
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", read_timeout=5) or {}
    except EngineError:
        return False
    item = status.get("currentItem") or {}
    return bool(status.get("isRunning") and item.get("dynamicSceneId") == _scene["dbId"]
                and not same_id(status.get("activePlaylistId"), _playlists["takeoverId"]))


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        plugin.log(text)
    return False


def _on_session_state(handle_or_state):
    """Das SDK ruft das mit dem Handle auf, nicht mit dem neuen Zustand."""
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _takeover.update(handle=None, since=None, eventId=None)
    plugin.log(f"The frame ended Halloween Scare: {new_state}.")
    finish_event()
    threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason, token=None):
    """Bildschirm zurückgeben. Mehrfach aufrufbar."""
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        _takeover.update(handle=None, since=None, eventId=None)
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:
        plugin.log(f"Could not hand back the screen: {exc}", level="warning")
    plugin.log(f"Screen handed back ({reason}).")
    if reason != "stopped":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def show_scene(event):
    """Die Szene über alles legen. True, wenn der Rahmen den Bildschirm hergab."""
    if not takeover_supported():
        return _note(tr("This frame is too old to let a plugin take over the screen."))
    if _scene["dbId"] is None:
        find_scene()
    if _scene["dbId"] is None or _scene["note"]:
        return _note(_scene["note"] or tr("The Halloween Scare scene was not found."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("The takeover playlist has not been created yet."))
    wake = settings()["WakeScreen"] or event.get("force")
    if not wake and display_is_off():
        finish_event(event["id"])
        return _note(tr("The screen is off; the scare is not shown."))
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             "overlay": {"enabled": False}}
    try:
        _leftover["askedAt"] = time.time()
        handle = plugin.acquire_display_session(
            session_key="scare", state=state, display_name=DISPLAY_NAME,
            max_duration_seconds=MAX_SESSION_SECONDS, wake_if_off=bool(wake))
    except Exception as exc:
        return _note(tr("Could not show the scare: {exc}", exc=exc))
    if handle is None:
        return _note(takeover_permission_note() or tr("Something else has the screen right now."))
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, since=now(), note="", eventId=event["id"])
    try:
        handle.on_state_change(_on_session_state)
    except Exception:
        pass
    try:
        if not handle.wait_until_active(timeout=10):
            end_takeover("failed", token)
            return _note(tr("The frame did not show the scare in time."))
    except Exception as exc:
        end_takeover("failed", token)
        return _note(tr("Could not show the scare: {exc}", exc=exc))
    plugin.log(f"Halloween Scare on screen ({event['mode']}).")
    return True


def decide_takeover():
    t = now()
    event = active_event(t)
    with _takeover_lock:
        handle = _takeover["handle"]
        held_for = _takeover["eventId"]
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        if event is None or event["id"] != held_for:
            end_takeover("done")
        return
    if event is None or event.get("tried"):
        return
    event["tried"] = True
    if scene_in_playlist():
        plugin.log("The scene is already on screen in a playlist; it plays the scare by itself.")
        return
    if not show_scene(event):
        finish_event(event["id"])


def cancel_scare():
    finish_event()
    end_takeover("cancelled")
    stop_sounds()


def test_scare(mode=None, intensity=None, variant=None):
    mode = mode if mode in (*MODES, "random") else settings()["MotionMode"]
    if mode == "random":
        mode = random.choice(MODES)
    event = trigger("test", "", mode=mode, intensity=intensity if intensity in ("scary", "gentle") else None,
                    variant=variant, force=True)
    if event is None:
        return {"success": False, "error": tr("Could not start the scare.")}
    return {"success": True, "message": tr("Asking the frame for the screen …")}


# ---- Takeover-Playlist, die nach dem Zurückgeben weiterläuft ---------------
# Lief vor einem Takeover keine Playlist, stellt die Engine dieses "nichts"
# nicht wieder her, und die Takeover-Playlist läuft einfach weiter (Jans
# Rahmen, 2026-10-24). Jeder Durchlauf hält sie dann mit POST /slideshow/stop
# an: nur wenn sie läuft, niemand den Bildschirm hält und das Plugin nicht
# gerade selbst darum gebeten hat.
_leftover = {"askedAt": 0.0, "failed": False}


def stop_leftover_takeover():
    try:
        playlist_id = _playlists["takeoverId"]
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status", read_timeout=5) or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status", read_timeout=5) or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop", read_timeout=10)
    except Exception as exc:  # noqa: BLE001 - darf die Schleife nie aufhalten
        if not _leftover["failed"]:
            plugin.log(f"The takeover playlist kept running and could not be stopped: {exc}", level="warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    plugin.log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def check_playback_resumed():
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log,
                                                    stop_event=_stop_requested)
        if outcome == "not-requested":
            save_state(playbackStalled="")
            return
    elif _stop_requested.wait(12):
        return
    if _stop_requested.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
    except EngineError:
        return
    if status.get("isRunning") or _takeover["handle"] is not None:
        save_state(playbackStalled="")
        return
    message = tr("The frame did not return to your playlist after the scare. Start it again on the frame's "
                 "home page. This does not happen with a saved playlist instead of a Quick Mix.")
    save_state(playbackStalled=message)
    plugin.log(message, level="warning")


# --------------------------------------------------------------------------
# Ton
# --------------------------------------------------------------------------

_audio_lock = threading.Lock()
_audio = {"active": 0, "saved": False, "restoreTimer": None, "processes": [], "note": ""}
SINK = "@DEFAULT_AUDIO_SINK@"


def sound_environment():
    """Der Rahmen startet Plugins ohne XDG_RUNTIME_DIR; ohne finden pw-play
    und paplay den Tondienst nicht (gemessen von FireWatch)."""
    env = dict(os.environ)
    env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
    return env


def player_commands(path):
    options = [("pw-play", []), ("paplay", []), ("aplay", ["-q"]),
               ("ffplay", ["-nodisp", "-autoexit", "-loglevel", "error"]), ("mpv", ["--no-video", "--really-quiet"])]
    commands = []
    for name, args in options:
        tool = shutil.which(name)
        if tool:
            commands.append([tool, *args, str(path)])
    return commands


def run_player(path):
    """Eine Datei mit dem ersten Spieler, der es schafft. "" oder der Fehler."""
    said = tr("No audio player found on the frame.")
    for command in player_commands(path):
        try:
            process = subprocess.Popen(command, env=sound_environment(),
                                       stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        except OSError as exc:
            said = f"{Path(command[0]).name}: {exc}"
            continue
        with _audio_lock:
            _audio["processes"].append(process)
        try:
            _, errors = process.communicate(timeout=60)
        except subprocess.TimeoutExpired:
            process.kill()
            _, errors = process.communicate()
        finally:
            with _audio_lock:
                if process in _audio["processes"]:
                    _audio["processes"].remove(process)
        if process.returncode == 0 or process.returncode < 0:
            return ""
        said = f"{Path(command[0]).name}: " + \
            ((errors or b"").decode("utf-8", "replace").strip()[:160] or str(process.returncode))
    return said


def stop_sounds():
    with _audio_lock:
        processes = list(_audio["processes"])
    for process in processes:
        try:
            process.terminate()
        except OSError:
            pass


def sink_state():
    tool = shutil.which("wpctl")
    if not tool:
        return None
    try:
        done = subprocess.run([tool, "get-volume", SINK], env=sound_environment(),
                              capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return None
    match = re.search(r"Volume:\s*([0-9.]+)", done.stdout or "")
    if done.returncode != 0 or not match:
        return None
    return float(match.group(1)), "MUTED" in done.stdout


def set_sink(volume=None, muted=None):
    tool = shutil.which("wpctl")
    if not tool:
        return
    commands = []
    if volume is not None:
        commands.append([tool, "set-volume", SINK, f"{max(0.0, min(1.0, volume)):.2f}"])
    if muted is not None:
        commands.append([tool, "set-mute", SINK, "1" if muted else "0"])
    for command in commands:
        try:
            subprocess.run(command, env=sound_environment(), capture_output=True, timeout=10)
        except (OSError, subprocess.TimeoutExpired) as exc:
            plugin.log(f"wpctl failed: {exc}", level="warning")


def frame_volume():
    try:
        body = engine_call("GET", "/api/v1/system/volume", read_timeout=10) or {}
    except EngineError:
        return None, None
    if not isinstance(body, dict):
        return None, None
    level = next((body[k] for k in ("value", "volume", "level") if isinstance(body.get(k), (int, float))), None)
    muted = next((body[k] for k in ("muted", "isMuted", "mute") if isinstance(body.get(k), bool)), None)
    return level, muted


def raise_volume():
    """Vor dem ersten Geräusch eines Schrecks: Lautstärke merken und setzen."""
    values = settings()
    try:
        if values["Volume"] > 0:
            level, muted = frame_volume()
            if level is not None:
                save_state(volumeBefore={"volume": level, "muted": muted, "set": values["Volume"]})
                engine_call("POST", "/api/v1/system/volume", {"value": values["Volume"]}, read_timeout=10)
                if muted:
                    engine_call("POST", "/api/v1/system/mute", {"value": False}, read_timeout=10)
        sink = sink_state()
        if sink is not None:
            save_state(sinkBefore={"volume": sink[0], "muted": sink[1]})
            set_sink(volume=values["Volume"] / 100 if values["Volume"] > 0 else None, muted=False)
    except EngineError as exc:
        plugin.log(f"Could not set the volume: {exc}", level="warning")


def restore_volume():
    """Lautstärke zurück, wie sie vor dem Schreck war (auch nach einem
    Neustart mitten im Schreck)."""
    state = load_state()
    saved = state.get("volumeBefore")
    if isinstance(saved, dict):
        level, muted = frame_volume()
        try:
            if level is not None and int(level) == int(saved.get("set", -1)) and saved.get("volume") is not None:
                engine_call("POST", "/api/v1/system/volume", {"value": int(saved["volume"])}, read_timeout=10)
            if saved.get("muted") is True and muted is False:
                engine_call("POST", "/api/v1/system/mute", {"value": True}, read_timeout=10)
        except EngineError as exc:
            plugin.log(f"Could not restore the volume: {exc}", level="warning")
        save_state(volumeBefore=None)
    sink = state.get("sinkBefore")
    if isinstance(sink, dict):
        set_sink(volume=sink.get("volume"), muted=bool(sink.get("muted")))
        save_state(sinkBefore=None)
    with _audio_lock:
        _audio["saved"] = False


def _restore_if_quiet():
    with _audio_lock:
        if _audio["active"] > 0:
            return
        _audio["restoreTimer"] = None
    restore_volume()


def play_cue(name):
    """Ein Geräusch abspielen, ohne zu warten. Mehrere dürfen sich überlagern."""
    path = SOUNDS / f"{name}.wav"
    if not path.is_file():
        return False

    def run():
        with _audio_lock:
            first = not _audio["saved"]
            _audio["saved"] = True
            _audio["active"] += 1
            if _audio["restoreTimer"] is not None:
                _audio["restoreTimer"].cancel()
                _audio["restoreTimer"] = None
        try:
            if first:
                raise_volume()
            problem = run_player(path)
            _audio["note"] = tr("Could not play the sound ({problem}).", problem=problem) if problem else ""
            if problem:
                plugin.log(_audio["note"], level="warning")
        finally:
            with _audio_lock:
                _audio["active"] -= 1
                if _audio["active"] == 0:
                    timer = threading.Timer(4.0, _restore_if_quiet)
                    timer.daemon = True
                    _audio["restoreTimer"] = timer
                    timer.start()

    threading.Thread(target=run, name=f"{PLUGIN_ID}-sound", daemon=True).start()
    return True


def scene_cue(event_id, cue):
    if cue not in CUES or not settings()["Sound"]:
        return False
    with _event_lock:
        event = _event["current"]
        if not event or str(event["id"]) != str(event_id):
            return False
        if cue == "static":
            # Das Rauschen darf dreimal kommen, jedes andere Geräusch einmal.
            count = sum(1 for c in event["cues"] if c.startswith("static"))
            if count >= 3:
                return False
            event["cues"].add(f"static:{count}")
        else:
            if cue in event["cues"]:
                return False
            event["cues"].add(cue)
    return play_cue(cue)


def test_sound(name):
    if name not in CUES:
        return {"success": False, "error": "?"}
    play_cue(name)
    return {"success": True, "message": tr("Playing the sound on the frame.")}


# --------------------------------------------------------------------------
# Die Schleife
# --------------------------------------------------------------------------

_loop = {"lastError": "", "watchAt": 0.0}


def tick():
    try:
        stop_leftover_takeover()
        maintain_playlists()
        decide_takeover()
        if now() - _loop["watchAt"] > 600:
            _loop["watchAt"] = now()
            reconnect()
        _loop["lastError"] = ""
    except Exception as exc:  # pragma: no cover - die Schleife muss weiterlaufen
        _loop["lastError"] = str(exc)
        plugin.log(f"Loop failed: {exc}", level="error")


def main_loop():
    _stop_requested.wait(2)
    while not _stop_requested.is_set():
        _wake.clear()
        tick()
        _wake.wait(1 if _takeover["handle"] is not None or active_event() else 5)


# --------------------------------------------------------------------------
# Die Plugin-Seite und die Daten für die Szene
# --------------------------------------------------------------------------

def scene_payload():
    values = settings()
    event = active_event()
    payload = {"at": now(), "lang": values["Language"],
               "idleVariant": values["Variant"] if values["Variant"] in VARIANTS else "lady", "event": None}
    if event:
        payload["event"] = {"id": event["id"], "mode": event["mode"], "variant": event["variant"],
                            "intensity": event["intensity"], "lurk": event["lurk"], "text": event["text"],
                            "photo": f"api/photo/{event['id']}" if event["photo"] else ""}
    return payload


def photo_of(event_id):
    with _event_lock:
        event = _event["current"]
        if event and str(event["id"]) == str(event_id):
            return event["photo"]
    return None


DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


def connection_payload(values):
    status = stream.status
    config = _catalog["config"] or {}
    if not values["Url"] or not values["Token"]:
        return {"state": "setup", "text": tr("Not set up yet.")}
    if status["state"] == "connected":
        name = config.get("location_name") or "Home Assistant"
        return {"state": "ok", "text": tr("Connected to {name}", name=name) +
                (f" (Home Assistant {config['version']})" if config.get("version") else ""),
                "watching": len(watched_entities(values))}
    if status["state"] in {"connecting", "off"}:
        return {"state": "busy", "text": tr("Connecting …")}
    return {"state": "bad", "text": error_text(status["error"])}


def state_payload():
    values = settings()
    state = load_state()
    with _takeover_lock:
        showing = _takeover["handle"] is not None
        note = _takeover["note"]
    public = dict(values)
    public["Token"] = ""
    t = now()
    cooldown_left = max(0, int(values["Cooldown"] * 60 - (t - _last["scareAt"])))
    return {
        "success": True,
        "version": version(),
        "settings": public,
        "tokenSet": bool(values["Token"]),
        "connection": connection_payload(values),
        "showing": showing or bool(active_event(t)),
        "note": note or _playlists["note"] or _scene["note"] or _audio["note"],
        "permission": takeover_permission_note(),
        "recent": [{"at": local_text(h["at"]), "source": h["source"], "mode": h["mode"], "result": h["result"],
                    "detail": h["detail"]} for h in _history],
        "autoFound": state.get("autoFound") or [],
        "quietNow": in_quiet_hours(values),
        "seasonNow": in_season(),
        "cooldownLeft": cooldown_left,
        "lastScare": local_text(state.get("lastScareAt")),
        "lastError": _loop["lastError"] or state.get("playbackStalled") or "",
        "theme": {"id": theme_id()},
    }


def connect_now():
    values = settings()
    try:
        config = rest(values).config()
    except ha.HaError as exc:
        reconnect()
        return {"success": False, "error": error_text(str(exc))}
    _catalog["config"] = config or {}
    found = auto_setup()
    catalog(force=True)
    reconnect()
    name = (config or {}).get("location_name") or "Home Assistant"
    message = tr("Connected to {name}.", name=name)
    if found:
        message += " " + tr("Filled in right away: {names}.", names=", ".join(found))
    return {"success": True, "message": message}


def settings_saved(changed):
    if set(changed) & {"Url", "Token"}:
        _catalog.update(rows=[], at=0.0, config={})
    reconnect()
    _wake.set()


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/entities":
                self._json(entities_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(), cors=True)
                return
            if path.startswith("/api/photo/"):
                found = photo_of(path.rsplit("/", 1)[-1])
                if found is None:
                    self._json({"success": False, "error": "No photo"}, 404, cors=True)
                else:
                    self._send(found[0], found[1], cache="private, max-age=600", cors=True)
                return
            self._json({"success": False, "error": "Not found"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Could not read a plugin file: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            body = self._body()
            if path == "/api/cue":
                self._json({"success": True, "played": scene_cue(body.get("id"), str(body.get("cue") or ""))},
                           cors=True)
                return
            if path == "/api/started":
                with _event_lock:
                    event = _event["current"]
                    if event and str(event["id"]) == str(body.get("id")) and not event["started"]:
                        event["started"] = now()
                        # Ab jetzt läuft die Uhr der Szene: Ende = Dauer + etwas Luft.
                        event["until"] = min(event["until"], now() + scare_duration(
                            event["mode"], event["intensity"] == "gentle", event["lurk"]) + 4)
                self._json({"success": True}, cors=True)
                return
            if path == "/api/done":
                finish_event(body.get("id"))
                self._json({"success": True}, cors=True)
                return
            if path == "/api/settings":
                if "Token" in body and not str(body["Token"] or "").strip():
                    body.pop("Token")  # ein leeres Feld heißt: das alte behalten
                changed = save_settings(body)
                if changed:
                    settings_saved(changed)
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/connect":
                if not str(body.get("Token") or "").strip():
                    body.pop("Token", None)
                changed = save_settings({k: v for k, v in body.items() if k in ("Url", "Token")})
                if changed:
                    settings_saved(changed)
                self._json(connect_now())
                return
            if path == "/api/test":
                self._json(test_scare(body.get("mode"), body.get("intensity"), body.get("variant")))
                return
            if path == "/api/sound":
                self._json(test_sound(str(body.get("name") or "")))
                return
            if path == "/api/cancel":
                cancel_scare()
                self._json({"success": True, "message": tr("Handing the screen back.")})
                return
            self._json({"success": False, "error": "Not found"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin page at {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def set_armed(on):
    save_settings({"Armed": on})
    return {"success": True}


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    plugin.log(f"Starting {PLUGIN_ID} {version()}")
    _last["scareAt"] = float(load_state().get("lastScareAt") or 0)

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("scare", lambda _context=None: test_scare())
    plugin.on_action("cancel", lambda _context=None: (cancel_scare(), {"success": True})[1])
    plugin.on_action("arm", lambda _context=None: set_armed(True))
    plugin.on_action("disarm", lambda _context=None: set_armed(False))

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    restore_volume()   # falls der letzte Lauf mitten im Schreck endete
    reconnect()
    threading.Thread(target=main_loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    stream.stop()
    stop_sounds()
    end_takeover("stopped")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    plugin.log(f"{PLUGIN_ID} stopped.")


if __name__ == "__main__":
    main()
