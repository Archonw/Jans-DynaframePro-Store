/* Contact Sheet - die Szene.
 *
 * Deine Fotos auf einem endlosen Kleinbild-Filmstreifen: Bildfelder 36 x 24,
 * Perforation oben und unten, kleine Bildnummern und eine dezente
 * Randbeschriftung (Datum, Ort). Der Streifen hält bei einem Bild an (optional
 * mit rotem Fettstift markiert), läuft dann langsam an, wird schnell und
 * verschwimmt, bremst ab und hält beim nächsten Bild.
 *
 * Gezeichnet wird mit WebGL in zwei Schritten: (1) die Bildfelder (je eine
 * Textur, in Canvas 2D gemalt) in einen Zwischenspeicher, (2) daraus mit
 * waagrechter Bewegungsunschärfe und Filmkorn auf den Bildschirm. Ist der
 * Streifen schnell, wird Schritt 1 waagrecht mit weniger Pixeln gerechnet
 * (die Unschärfe verdeckt das), so bleibt die Last auf dem Pi 4 klein.
 * Gezeichnet wird nur, solange sich der Streifen bewegt.
 *
 * Zum Ausprobieren: ?plugin=<URL der Plugin-Seite> &lang=de|en|es &speed=2
 * &demo=1 (Fotos aus ?photos=a.jpg,b.jpg oder gemalt, ohne Plugin)
 * &size=small|medium|large &look=lighttable|paper|wood|dark &film=color|bw
 * &hold=10 &dist=mixed|next|few|far &pace=calm|normal|fast &blur=strong|subtle|off
 * &portrait=crop|rotate &marker=0|1 &grain=0|1 &captions=edge|note|none
 * &pose=hold|move (Standbild für Store-Bilder, bei move &at=1.5) &seed=3 &nogl=1
 */
(function () {
  "use strict";

  const PLUGIN_ID = "ContactSheet";
  const params = new URLSearchParams(location.search);
  const SPEED = Math.max(0.1, Number(params.get("speed")) || 1);
  const DEMO = params.get("demo") === "1";
  const POSE = params.get("pose") || "";
  const NOGL = params.get("nogl") === "1";
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  // Über die Weboberfläche (Port 80/443, z. B. RemoteFrame mit HTTPS) nur derselbe
  // Ursprung: DynaFrames Firewall verwirft :8003 dann still, jede Anfrage hinge
  // bis zum Zeitlimit (https-scene-fetch-fix.md, 15.11.2026).
  const viaWebUi = location.port === "" || location.port === "80" || location.port === "443";
  const pluginBases = params.get("plugin") ? [params.get("plugin").replace(/\/?$/, "/")]
    : viaWebUi ? [`${location.origin}${advanced}`]
    : [...new Set([
      `${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`,
      `${location.origin}${advanced}`,
      `${location.protocol}//${location.hostname || "localhost"}${advanced}`
    ])];
  let baseIndex = 0, baseFound = false;

  const TEXT = {
    de: {
      wait: "Contact Sheet liest die Fotos …", none: "Contact Sheet findet keine Fotos. Wähle auf der Plugin-Seite eine Quelle.",
      unreachable: "Contact Sheet antwortet nicht.", login: "Bitte zuerst im Browser beim Rahmen anmelden.",
      months: ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"],
      short: ["JAN", "FEB", "MÄR", "APR", "MAI", "JUN", "JUL", "AUG", "SEP", "OKT", "NOV", "DEZ"]
    },
    en: {
      wait: "Contact Sheet is reading the photos …", none: "Contact Sheet finds no photos. Pick a source on the plugin page.",
      unreachable: "Contact Sheet is not responding.", login: "Please sign in to the frame in the browser first.",
      months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
      short: ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]
    },
    es: {
      wait: "Contact Sheet está leyendo las fotos …", none: "Contact Sheet no encuentra fotos. Elige una fuente en la página del plugin.",
      unreachable: "Contact Sheet no responde.", login: "Inicia sesión primero en el marco desde el navegador.",
      months: ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"],
      short: ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN", "JUL", "AGO", "SEP", "OCT", "NOV", "DIC"]
    }
  };
  let lang = params.get("lang") || "en";
  const tx = (key) => (TEXT[lang] || TEXT.en)[key] ?? TEXT.en[key] ?? key;

  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms / SPEED));

  // Zufall, mit ?seed= wiederholbar (für Store-Bilder)
  let seed = Number(params.get("seed")) || 0;
  const rand = seed ? () => {
    seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  } : Math.random;

  // ------------------------------------------------------------ Plugin

  // Mit Zeitlimit: hängt die Verbindung (DynaFrame-HTTPS/Login, Plugin neu
  // gestartet), steht die Szene nicht still, sondern versucht es wieder.
  async function fetchTimed(target, ms) {
    const control = typeof AbortController === "function" ? new AbortController() : null;
    const timer = control ? setTimeout(() => control.abort(), ms) : 0;
    try {
      return await fetch(target, { cache: "no-store", credentials: "same-origin", signal: control ? control.signal : undefined });
    } finally {
      clearTimeout(timer);
    }
  }

  // Eine Adresse je Aufruf. Weitergeschaltet wird nur, solange noch keine
  // Adresse funktioniert hat und nur, wenn dieser Aufruf die aktuelle benutzt hat
  // (sonst springen gleichzeitige Aufrufe hin und her).
  async function api(path) {
    const used = baseIndex;
    try {
      const response = await fetchTimed(pluginBases[used] + path, 12000);
      if (response.redirected && /login/i.test(response.url)) throw new Error("login");
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const body = await response.json();
      baseFound = true;
      return body;
    } catch (error) {
      if (!baseFound && pluginBases.length > 1 && used === baseIndex) baseIndex = (baseIndex + 1) % pluginBases.length;
      throw error;
    }
  }
  const url = (path) => pluginBases[baseIndex] + path;

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = "anonymous";     // als WebGL-Textur nur mit CORS
      img.decoding = "async";
      const timer = setTimeout(() => { img.src = ""; reject(new Error("image timeout")); }, 30000);
      img.onload = () => { clearTimeout(timer); resolve(img); };
      img.onerror = () => { clearTimeout(timer); reject(new Error("image")); };
      img.src = src;
    });
  }

  function report(message) {
    if (!DEMO) api("api/report?m=" + encodeURIComponent(String(message).slice(0, 180))).catch(() => {});
  }

  // DynaFrame wartet, bis die Szene meldet, dass sie steht; sonst bricht der
  // Fernseher nach einer Frist ab ("scene readiness deadline expired").
  let readySent = false;
  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 8000);

  const note = document.getElementById("note");
  function showNote(text) {
    note.textContent = text || "";
    note.hidden = !text;
  }

  // ------------------------------------------------------------ Einstellungen

  const pBool = (key, dflt) => (params.has(key) ? params.get(key) !== "0" : dflt);
  const cfg = {
    Size: params.get("size") || "medium", Look: params.get("look") || "lighttable", Film: params.get("film") || "color",
    HoldSeconds: Number(params.get("hold")) || 10, Distance: params.get("dist") || "mixed", Pace: params.get("pace") || "normal",
    Blur: params.get("blur") || "strong", Portrait: params.get("portrait") || "crop", Marker: pBool("marker", true),
    Grain: pBool("grain", true), Captions: params.get("captions") || "edge", Direction: params.get("dir") || "horizontal"
  };
  const KEYMAP = { Size: "size", Look: "look", Film: "film", HoldSeconds: "hold", Distance: "dist", Pace: "pace", Blur: "blur",
                   Portrait: "portrait", Marker: "marker", Grain: "grain", Captions: "captions",
                   Direction: "dir" };
  // Was ein neues Malen der Bildfelder braucht
  const REPAINT = ["Size", "Look", "Film", "Portrait", "Captions", "Direction"];

  const SIZES = { small: 0.46, medium: 0.62, large: 0.8 };
  const SIZES_V = { small: 0.55, medium: 0.75, large: 0.95 };   // senkrecht: Breite des Streifens / Höhe
  // Fahrt: Anlaufen (ta s), Vollgas (V Bilder/s), Abbremsen (td s). Kurze Fahrten
  // erreichen V nicht, lange spulen eine Weile mit voller Geschwindigkeit durch.
  const PACES = { calm: { V: 6, ta: 1.7, td: 2.3 }, normal: { V: 10, ta: 1.4, td: 2.0 }, fast: { V: 15, ta: 1.1, td: 1.6 } };
  // „Belichtungszeit“ der Unschärfe in Sekunden
  const SHUTTER = { strong: 0.06, subtle: 0.025, off: 0 };
  const BLUR_MAX = { strong: 1.1, subtle: 0.45, off: 0 };   // höchstens so viele Bildbreiten
  const LOOKS = {
    lighttable: { bg: "#eef1f4", baseAlpha: 0.93, note: "rgba(38,40,46,.78)", shadow: 0 },
    paper:      { bg: "#efe9dc", baseAlpha: 1, note: "rgba(70,58,46,.82)", shadow: 0.18 },
    wood:       { bg: "#4a3020", baseAlpha: 1, note: "rgba(250,240,222,.88)", shadow: 0.55 },
    dark:       { bg: "#1b1d21", baseAlpha: 1, note: "rgba(236,232,224,.86)", shadow: 0.6 }
  };
  const look = () => LOOKS[cfg.Look] || LOOKS.lighttable;

  function applySettings(s) {
    if (!s) return;
    if (s.Language && !params.get("lang")) lang = s.Language;
    let repaint = false;
    for (const key of Object.keys(cfg)) {
      if (s[key] === undefined || params.has(KEYMAP[key])) continue;
      if (cfg[key] !== s[key] && REPAINT.includes(key)) repaint = true;
      cfg[key] = s[key];
    }
    cfg.HoldSeconds = clamp(Number(cfg.HoldSeconds) || 10, 3, 600);
    document.documentElement.lang = lang;
    if (repaint && laidOut) relayout();
  }

  // ------------------------------------------------------------ Maße

  const bgCanvas = document.getElementById("bg");
  const stage = document.getElementById("stage");
  const ink = document.getElementById("ink");
  let W = window.innerWidth, H = window.innerHeight;
  let renderScale = 1;
  try {
    const stored = Number(localStorage.getItem("cs-scale"));
    if (stored >= 0.5 && stored <= 1) renderScale = stored;
  } catch (_) { /* kein Speicher */ }
  const dpr = () => Math.min(window.devicePixelRatio || 1, 1.5) * renderScale;

  // Waagrecht: Kleinbildfilm in Millimetern, 35 breit, Bildfeld 36 x 24, Abstand 38,
  // 8 Perforationslöcher je Bild (Teilung 4,75), Randschrift außen.
  // Senkrecht (von oben nach unten): Kinofilm, Bildfeld 24,9 breit x 18,7 hoch,
  // Abstand 19, 4 Löcher je Bild. Gemalt und gerechnet wird immer in
  // Streifen-Koordinaten (u längs, v quer); erst der letzte Schritt dreht.
  const FRAMES = {
    still: { pitch: 38, perfs: 8, ix: 1, iy: 5.5, iw: 36, ih: 24 },
    cine: { pitch: 19, perfs: 4, ix: 0.15, iy: 5.05, iw: 18.7, ih: 24.9 }
  };
  const vertical = () => cfg.Direction === "vertical";
  const G = { Sh: 0, mm: 0, pitch: 0, top: 0, left: 0, len: 0, F: FRAMES.still };
  function geometry() {
    if (vertical()) {
      G.F = FRAMES.cine;
      const Sh = Math.min(H * (SIZES_V[cfg.Size] || SIZES_V.medium), W * 0.62);
      G.Sh = Math.round(Sh);
      G.len = H;
      G.top = 0;
      G.left = Math.round((W - G.Sh) / 2);
    } else {
      G.F = FRAMES.still;
      const noteRoom = cfg.Captions === "note" ? H * 0.05 : 0;
      const Sh = Math.min(H * (SIZES[cfg.Size] || SIZES.medium), W * 0.8 * 35 / 38, H - noteRoom * 2.4);
      G.Sh = Math.round(Sh);
      G.len = W;
      G.left = 0;
      G.top = Math.round((H - G.Sh) / 2 - noteRoom);
    }
    G.mm = G.Sh / 35;
    G.pitch = G.F.pitch * G.mm;
  }
  // Bildfeld in Streifen-Koordinaten (Zelle beginnt bei left)
  const imageRect = (left) => ({ x: left + G.F.ix * G.mm, y: G.F.iy * G.mm, w: G.F.iw * G.mm, h: G.F.ih * G.mm });
  // Bildfeld des Bildes in der Mitte, auf dem Bildschirm (aufrecht)
  function screenImage() {
    const r = imageRect(G.len / 2 - G.pitch / 2);
    if (!vertical()) return { x: r.x, y: G.top + r.y, w: r.w, h: r.h };
    // Streifen um 90° gegen den Uhrzeiger: u läuft von unten nach oben, v von links nach rechts
    return { x: G.left + r.y, y: H - (r.x + r.w), w: r.h, h: r.w };
  }

  // ------------------------------------------------------------ WebGL

  let gl = null, ctx2 = null, isGL2 = false;
  let progCell = null, progComp = null, fbo = null, fboTex = null, fboW = 0, fboH = 0;
  const locCell = {}, locComp = {};
  const VS_CELL = `
    attribute vec2 aPos;
    uniform vec4 uRect;
    uniform vec2 uView;
    varying vec2 vUV;
    void main() {
      vec2 p = uRect.xy + aPos * uRect.zw;
      vec2 c = p / uView * 2.0 - 1.0;
      gl_Position = vec4(c.x, -c.y, 0.0, 1.0);
      vUV = aPos;
    }`;
  const FS_CELL = `
    precision mediump float;
    uniform sampler2D uTex;
    varying vec2 vUV;
    void main() { gl_FragColor = texture2D(uTex, vUV); }`;
  const VS_COMP = `
    attribute vec2 aPos;
    varying vec2 vUV;
    void main() { gl_Position = vec4(aPos * 2.0 - 1.0, 0.0, 1.0); vUV = aPos; }`;
  const FS_COMP = `
    #ifdef GL_FRAGMENT_PRECISION_HIGH
    precision highp float;
    #else
    precision mediump float;
    #endif
    uniform sampler2D uTex;
    uniform float uScaleX, uMaxX, uStep, uGrain, uOff, uVert;
    uniform int uTaps;
    varying vec2 vUV;
    float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
    void main() {
      vec2 a = uVert > 0.5 ? vec2(vUV.y, 1.0 - vUV.x) : vUV;
      vec2 uv = vec2(a.x * uScaleX, a.y);
      float n = float(uTaps);
      vec4 acc = vec4(0.0);
      for (int i = 0; i < 16; i++) {
        if (i >= uTaps) break;
        float o = (float(i) - (n - 1.0) * 0.5) * uStep;
        acc += texture2D(uTex, vec2(clamp(uv.x + o, 0.0, uMaxX), uv.y));
      }
      acc /= n;
      if (uGrain > 0.0) {
        vec2 fc = uVert > 0.5 ? gl_FragCoord.yx : gl_FragCoord.xy;
        float g = hash(floor(vec2(mod(fc.x + uOff, 8192.0), fc.y) / 1.4)) - 0.5;
        acc.rgb = clamp(acc.rgb + g * uGrain * acc.a, 0.0, 1.0);
        acc.rgb = min(acc.rgb, vec3(acc.a));
      }
      gl_FragColor = acc;
    }`;

  function setupGL() {
    if (NOGL) return false;
    const opts = { alpha: true, premultipliedAlpha: true, antialias: false, depth: false, preserveDrawingBuffer: !!POSE };
    try {
      gl = stage.getContext("webgl2", opts);
      isGL2 = !!gl;
      if (!gl) gl = stage.getContext("webgl", opts) || stage.getContext("experimental-webgl", opts);
    } catch (_) {
      gl = null;
    }
    if (!gl) return false;
    try {
      const compile = (type, source) => {
        const shader = gl.createShader(type);
        gl.shaderSource(shader, source);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader));
        return shader;
      };
      const link = (vs, fs, names, into) => {
        const p = gl.createProgram();
        gl.attachShader(p, compile(gl.VERTEX_SHADER, vs));
        gl.attachShader(p, compile(gl.FRAGMENT_SHADER, fs));
        gl.bindAttribLocation(p, 0, "aPos");
        gl.linkProgram(p);
        if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
        for (const name of names) into[name] = gl.getUniformLocation(p, name);
        return p;
      };
      progCell = link(VS_CELL, FS_CELL, ["uRect", "uView", "uTex"], locCell);
      progComp = link(VS_COMP, FS_COMP, ["uTex", "uScaleX", "uMaxX", "uStep", "uGrain", "uOff", "uTaps", "uVert"], locComp);
      const buffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0, 0, 1, 0, 0, 1, 1, 1]), gl.STATIC_DRAW);
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
      gl.activeTexture(gl.TEXTURE0);
      stage.addEventListener("webglcontextlost", (event) => { event.preventDefault(); report("WebGL: Kontext verloren"); });
      stage.addEventListener("webglcontextrestored", () => location.reload());
      return true;
    } catch (error) {
      report(`WebGL: ${error.message}`);
      gl = null;
      return false;
    }
  }
  if (!setupGL()) ctx2 = stage.getContext("2d");

  function makeTexture(source) {
    if (!gl) return { src: source };
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
    if (isGL2) gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, isGL2 ? gl.LINEAR_MIPMAP_LINEAR : gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return { tex };
  }
  function freeTexture(t) {
    if (t && t.tex && gl) gl.deleteTexture(t.tex);
  }

  function setupFbo() {
    if (!gl) return;
    const [SL, SA] = vertical() ? [stage.height, stage.width] : [stage.width, stage.height];
    if (fbo && fboW === SL && fboH === SA) return;
    if (fbo) { gl.deleteFramebuffer(fbo); gl.deleteTexture(fboTex); }
    fboW = SL;
    fboH = SA;
    fboTex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, fboTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, fboW, fboH, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    fbo = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, fboTex, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  // ------------------------------------------------------------ Untergrund

  function noisePattern(g, size, strength, warm) {
    const n = document.createElement("canvas");
    n.width = n.height = size;
    const c = n.getContext("2d");
    const data = c.createImageData(size, size);
    for (let i = 0; i < data.data.length; i += 4) {
      const v = Math.random();
      data.data[i] = 255 * v;
      data.data[i + 1] = 255 * v * (warm ? 0.92 : 1);
      data.data[i + 2] = 255 * v * (warm ? 0.8 : 1);
      data.data[i + 3] = 255 * strength * Math.abs(v - 0.5) * 2;
    }
    c.putImageData(data, 0, 0);
    return g.createPattern(n, "repeat");
  }

  function vignette(g, w, h, strength, color = "0,0,0") {
    const v = g.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.hypot(w, h) * 0.62);
    v.addColorStop(0, `rgba(${color},0)`);
    v.addColorStop(1, `rgba(${color},${strength})`);
    g.fillStyle = v;
    g.fillRect(0, 0, w, h);
  }

  function paintLighttable(g, w, h) {
    // Milchglas, von unten beleuchtet: in der Mitte am hellsten
    const base = g.createRadialGradient(w * 0.5, h * 0.48, 0, w * 0.5, h * 0.48, Math.hypot(w, h) * 0.62);
    base.addColorStop(0, "#fbfcfd");
    base.addColorStop(0.55, "#eef1f5");
    base.addColorStop(1, "#d5dae1");
    g.fillStyle = base;
    g.fillRect(0, 0, w, h);
    // die Leuchtstoffröhren darunter, ganz schwach
    for (let i = 1; i <= 3; i += 1) {
      const y = (h * i) / 4;
      const tube = g.createLinearGradient(0, y - h * 0.12, 0, y + h * 0.12);
      tube.addColorStop(0, "rgba(255,255,255,0)");
      tube.addColorStop(0.5, "rgba(255,255,255,.22)");
      tube.addColorStop(1, "rgba(255,255,255,0)");
      g.fillStyle = tube;
      g.fillRect(0, y - h * 0.12, w, h * 0.24);
    }
    g.fillStyle = noisePattern(g, 192, 0.05, false);
    g.fillRect(0, 0, w, h);
    // Rahmen des Pults an den Rändern
    const edge = Math.max(6, Math.min(w, h) * 0.018);
    g.fillStyle = "rgba(60,66,76,.22)";
    g.fillRect(0, 0, w, edge * 0.5);
    g.fillRect(0, h - edge * 0.5, w, edge * 0.5);
    vignette(g, w, h, 0.18, "40,48,60");
  }

  function paintPaper(g, w, h) {
    // Fotopapier (Baryt, leicht warm) für einen Kontaktabzug
    const base = g.createLinearGradient(0, 0, w * 0.3, h);
    base.addColorStop(0, "#f4efe4");
    base.addColorStop(1, "#e8e1d2");
    g.fillStyle = base;
    g.fillRect(0, 0, w, h);
    g.fillStyle = noisePattern(g, 256, 0.06, true);
    g.fillRect(0, 0, w, h);
    for (let i = 0; i < 18; i += 1) {
      const x = Math.random() * w, y = Math.random() * h, r = 80 + Math.random() * 240;
      const spot = g.createRadialGradient(x, y, 0, x, y, r);
      spot.addColorStop(0, Math.random() < 0.5 ? "rgba(120,100,70,.03)" : "rgba(255,255,255,.07)");
      spot.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = spot;
      g.fillRect(x - r, y - r, r * 2, r * 2);
    }
    vignette(g, w, h, 0.22, "70,55,35");
  }

  function paintWood(g, w, h) {
    const planks = Math.max(4, Math.round(h / 190));
    const ph = h / planks;
    const tones = ["#6b4528", "#5f3c22", "#704a2b", "#5a391f", "#664226"];
    for (let i = 0; i < planks; i += 1) {
      const y0 = i * ph;
      const base = g.createLinearGradient(0, y0, 0, y0 + ph);
      const tone = tones[(i * 3 + 1) % tones.length];
      base.addColorStop(0, tone);
      base.addColorStop(0.5, tones[(i * 2) % tones.length]);
      base.addColorStop(1, tone);
      g.fillStyle = base;
      g.fillRect(0, y0, w, ph);
      const lines = Math.round(ph / 3.2);
      for (let k = 0; k < lines; k += 1) {
        const y = y0 + (k + Math.random()) * (ph / lines);
        const amp = 1 + Math.random() * 5, freq = 0.002 + Math.random() * 0.006, phase = Math.random() * 7;
        g.strokeStyle = Math.random() < 0.5 ? `rgba(30,15,5,${0.06 + Math.random() * 0.16})` : `rgba(160,110,70,${0.04 + Math.random() * 0.08})`;
        g.lineWidth = 0.6 + Math.random() * 2.2;
        g.beginPath();
        for (let x = -10; x <= w + 34; x += 24) {
          const yy = y + Math.sin(x * freq + phase) * amp + Math.sin(x * freq * 3.1 + phase) * amp * 0.3;
          if (x < 0) g.moveTo(x, yy); else g.lineTo(x, yy);
        }
        g.stroke();
      }
      g.fillStyle = "rgba(20,10,4,.55)";
      g.fillRect(0, y0 + ph - 2, w, 2);
      g.fillStyle = "rgba(190,140,95,.12)";
      g.fillRect(0, y0, w, 1);
    }
    g.fillStyle = noisePattern(g, 192, 0.18, true);
    g.fillRect(0, 0, w, h);
    const light = g.createRadialGradient(w * 0.25, h * 0.1, 0, w * 0.25, h * 0.1, Math.hypot(w, h) * 0.8);
    light.addColorStop(0, "rgba(255,214,160,.16)");
    light.addColorStop(1, "rgba(255,214,160,0)");
    g.fillStyle = light;
    g.fillRect(0, 0, w, h);
    vignette(g, w, h, 0.55);
  }

  function paintDark(g, w, h) {
    const base = g.createRadialGradient(w * 0.5, h * 0.45, 0, w * 0.5, h * 0.45, Math.hypot(w, h) * 0.7);
    base.addColorStop(0, "#3a3e46");
    base.addColorStop(1, "#16171a");
    g.fillStyle = base;
    g.fillRect(0, 0, w, h);
    g.fillStyle = noisePattern(g, 192, 0.14, false);
    g.fillRect(0, 0, w, h);
    vignette(g, w, h, 0.5);
  }

  function buildBackground() {
    const scale = Math.min(1, 1920 / Math.max(W, H)) * Math.min(dpr(), 1.25);
    bgCanvas.width = Math.max(320, Math.round(W * scale));
    bgCanvas.height = Math.max(240, Math.round(H * scale));
    const g = bgCanvas.getContext("2d");
    g.setTransform(bgCanvas.width / W, 0, 0, bgCanvas.height / H, 0, 0);
    ({ lighttable: paintLighttable, paper: paintPaper, wood: paintWood, dark: paintDark }[cfg.Look] || paintLighttable)(g, W, H);
    // weicher Schatten unter dem Streifen (nur der Schatten: Rechteck außerhalb, Schatten verschoben)
    const strength = look().shadow;
    if (strength > 0) {
      g.save();
      g.shadowColor = `rgba(0,0,0,${strength})`;
      const sx = bgCanvas.width / W;
      g.shadowBlur = G.Sh * 0.09 * sx;
      g.fillStyle = "#000";
      if (vertical()) {
        g.shadowOffsetX = (G.Sh * 0.02 + W * 4) * sx;
        g.shadowOffsetY = G.Sh * 0.025 * sx;
        g.fillRect(G.left + G.mm * 0.8 - W * 4, -H, G.Sh - G.mm * 1.6, H * 3);
      } else {
        g.shadowOffsetX = 0;
        g.shadowOffsetY = (G.Sh * 0.03 + H * 4) * sx;
        g.fillRect(-W, G.top + G.mm * 0.8 - H * 4, W * 3, G.Sh - G.mm * 1.6);
      }
      g.restore();
    }
    document.body.style.background = look().bg;
  }

  // ------------------------------------------------------------ Bildfelder malen

  const HAND = (size) => `700 ${size}px Hand, "Segoe Print", "Comic Sans MS", cursive`;
  const MONO = (size) => `700 ${size}px "DejaVu Sans Mono", "Liberation Mono", "Courier New", monospace`;
  const COND = (size) => `600 ${size}px "DejaVu Sans Condensed", "Arial Narrow", "Roboto Condensed", sans-serif`;

  function dateText(taken, long) {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(taken || "");
    if (!m) return "";
    const day = Number(m[3]);
    if (!long) return `${String(day).padStart(2, "0")} ${tx("short")[Number(m[2]) - 1] || ""} ${m[1]}`;
    const month = tx("months")[Number(m[2]) - 1] || "";
    if (lang === "de") return `${day}. ${month} ${m[1]}`;
    if (lang === "es") return `${day} de ${month} de ${m[1]}`;
    return `${day} ${month} ${m[1]}`;
  }
  const shortPlace = (place) => String(place || "").split(",")[0].trim();
  const frameNo = (i) => (((i % 36) + 36) % 36) + 1;

  function roundRect(g, x, y, w, h, r) {
    g.beginPath();
    g.moveTo(x + r, y);
    g.arcTo(x + w, y, x + w, y + h, r);
    g.arcTo(x + w, y + h, x, y + h, r);
    g.arcTo(x, y + h, x, y, r);
    g.arcTo(x, y, x + w, y, r);
    g.closePath();
  }

  function fitText(g, text, maxWidth) {
    if (g.measureText(text).width <= maxWidth) return text;
    let s = text;
    while (s.length > 1 && g.measureText(s + "…").width > maxWidth) s = s.slice(0, -1);
    return s.trimEnd() + "…";
  }

  // Ein Bildfeld des Streifens: Filmträger, Löcher (durchsichtig), Foto, Randschrift
  function paintCell(i, entry) {
    const d = dpr();
    const { mm, pitch, Sh } = G;
    const c = document.createElement("canvas");
    c.width = Math.max(2, Math.ceil(pitch * d));
    c.height = Math.max(2, Math.ceil(Sh * d));
    const g = c.getContext("2d");
    g.scale(c.width / pitch, c.height / Sh);
    const bw = cfg.Film === "bw";
    // Filmträger: entwickelter Diafilm ist am Rand fast schwarz
    const base = g.createLinearGradient(0, 0, 0, Sh);
    base.addColorStop(0, bw ? "#141414" : "#1b1511");
    base.addColorStop(0.5, bw ? "#0d0d0d" : "#120e0b");
    base.addColorStop(1, bw ? "#141414" : "#1b1511");
    g.globalAlpha = look().baseAlpha;
    g.fillStyle = base;
    g.fillRect(0, 0, pitch, Sh);
    g.globalAlpha = 1;
    // leichter Glanz entlang der Kanten
    g.fillStyle = "rgba(255,255,255,.06)";
    g.fillRect(0, 0.15 * mm, pitch, 0.12 * mm);
    g.fillRect(0, Sh - 0.27 * mm, pitch, 0.12 * mm);
    // Perforation
    g.globalCompositeOperation = "destination-out";
    g.fillStyle = "#000";
    for (let k = 0; k < G.F.perfs; k += 1) {
      const x = (k + 0.5) * 4.75 * mm - 0.99 * mm;
      roundRect(g, x, 2.05 * mm, 1.98 * mm, 2.79 * mm, 0.45 * mm);
      g.fill();
      roundRect(g, x, Sh - 2.05 * mm - 2.79 * mm, 1.98 * mm, 2.79 * mm, 0.45 * mm);
      g.fill();
    }
    g.globalCompositeOperation = "source-over";
    // Bildfeld
    const r = imageRect(0);
    g.save();
    roundRect(g, r.x, r.y, r.w, r.h, 0.5 * mm);
    g.clip();
    if (entry && entry.img) {
      const img = entry.img;
      const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
      const rotate = cfg.Portrait === "rotate" && ih > iw * 1.05;
      const vert = vertical();
      // aufrechte Maße des Bildfelds (senkrecht ist die Zelle gedreht)
      const uw = vert ? r.h : r.w, uh = vert ? r.w : r.h;
      const sw = rotate ? ih : iw, sh = rotate ? iw : ih;
      const s = Math.max(uw / sw, uh / sh);
      g.filter = bw ? "grayscale(1) contrast(1.12) brightness(1.02)" : "saturate(1.06) contrast(1.04)";
      g.translate(r.x + r.w / 2, r.y + r.h / 2);
      if (vert) g.rotate(Math.PI / 2);
      if (rotate) g.rotate(-Math.PI / 2);
      g.drawImage(img, (-iw * s) / 2, (-ih * s) / 2, iw * s, ih * s);
      g.filter = "none";
      g.setTransform(c.width / pitch, 0, 0, c.height / Sh, 0, 0);
      // Lichtabfall zu den Ecken
      const v = g.createRadialGradient(r.x + r.w / 2, r.y + r.h / 2, Math.min(r.w, r.h) * 0.4, r.x + r.w / 2, r.y + r.h / 2, Math.max(r.w, r.h) * 0.62);
      v.addColorStop(0, "rgba(0,0,0,0)");
      v.addColorStop(1, "rgba(0,0,0,.22)");
      g.fillStyle = v;
      g.fillRect(r.x, r.y, r.w, r.h);
    } else {
      // unbelichtet (Vorspann oder Foto fehlt)
      g.fillStyle = "#070605";
      g.fillRect(r.x, r.y, r.w, r.h);
    }
    g.restore();
    // feine dunkle Kante ums Bild
    g.strokeStyle = "rgba(0,0,0,.55)";
    g.lineWidth = 0.18 * mm;
    roundRect(g, r.x, r.y, r.w, r.h, 0.5 * mm);
    g.stroke();
    // Randschrift: oben Film und Strichcode, unten Bildnummern, Datum, Ort
    const inkColor = bw ? "rgba(214,214,208,.78)" : "rgba(236,168,70,.86)";
    const n = frameNo(i);
    g.fillStyle = inkColor;
    g.textBaseline = "middle";
    const topY = 1.02 * mm, botY = Sh - 1.0 * mm;
    const caption = cfg.Captions !== "none" && entry && entry.info
      ? [dateText(entry.info.taken, false), shortPlace(entry.info.place)].filter(Boolean).join(" · ").toUpperCase() : "";
    if (vertical()) {
      // Kinofilm, 19 mm je Bild: oben Film oder Nummer, unten Nummer und Datum/Ort
      g.font = MONO(1.3 * mm);
      g.fillText(n % 2 === 0 ? (bw ? "DF 400 B&W" : "DF 400") : `▸${n}A`, 1.5 * mm, topY);
      g.font = MONO(1.35 * mm);
      g.fillText(String(n), 1.2 * mm, botY);
      if (caption) {
        g.font = COND(1.15 * mm);
        g.fillText(fitText(g, caption, 14.2 * mm), 4.4 * mm, botY);
      }
      return c;
    }
    g.font = MONO(1.3 * mm);
    g.fillText(bw ? "DF 400 B&W" : "DF 400 COLOR", 2.2 * mm, topY);
    if (n % 2 === 0) {
      // DX-Strichcode, nur als Zierde
      let x = 22 * mm;
      for (let k = 0; k < 12; k += 1) {
        const wide = ((n * 7 + k * 5) % 3) === 0;
        g.fillRect(x, topY - 0.55 * mm, (wide ? 0.55 : 0.28) * mm, 1.1 * mm);
        x += (wide ? 0.9 : 0.62) * mm;
      }
    } else {
      g.fillText("◂", 30 * mm, topY);
    }
    g.font = MONO(1.35 * mm);
    g.fillText(String(n), 1.4 * mm, botY);
    g.fillText(`▸${n}A`, 6.6 * mm, botY);
    if (caption) {
      g.font = COND(1.25 * mm);
      g.fillText(fitText(g, caption, 23 * mm), 14 * mm, botY);
    }
    return c;
  }

  // ------------------------------------------------------------ Der Streifen

  const cells = new Map();       // Index -> { i, img, info, tex }
  let blankTex = null;
  let pos = 0;                   // Bildindex in der Mitte (ganzzahlig = steht)
  let blurPx = 0;                // aktuelle Unschärfe in CSS-Pixeln
  let dirty = true;
  let laidOut = false;
  let motion = null;             // laufende Fahrt

  const reach = () => Math.ceil(G.len / 2 / G.pitch + 0.6);
  const cellLeft = (i, at = pos) => G.len / 2 + (i - at) * G.pitch - G.pitch / 2;

  function textureFor(i) {
    const cell = cells.get(i);
    if (cell && cell.tex) return cell.tex;
    if (!blankTex) blankTex = makeTexture(paintCell(0, null));
    return blankTex;
  }

  function setCell(i, entry) {
    const old = cells.get(i);
    if (old && old.tex && !old.shared) freeTexture(old.tex);
    const cell = { i, img: entry ? entry.img : null, info: entry ? entry.info : null };
    cell.tex = makeTexture(paintCell(i, cell));
    cells.set(i, cell);
    dirty = true;
    return cell;
  }

  // Beim weiten Vorspulen rauschen in der Mitte der Fahrt Bilder vorbei, die
  // ohnehin nur verwischt zu sehen sind: dafür nimmt die Szene Texturen schon
  // gezeigter Bilder wieder (pool), statt Dutzende Fotos neu zu laden.
  const pool = [];
  const POOL_MAX = 12;
  function dropCells() {
    const lo = Math.floor(pos) - reach() - 1;
    for (const [i, cell] of cells) {
      if (i >= lo) continue;
      cells.delete(i);
      if (!cell.shared && cell.tex) pool.push(cell.tex);
    }
    if (pool.length > POOL_MAX) {
      const used = new Set([...cells.values()].map((c) => c.tex));
      while (pool.length > POOL_MAX) {
        const k = pool.findIndex((t) => !used.has(t));
        if (k < 0) break;
        freeTexture(pool.splice(k, 1)[0]);
      }
    }
  }
  function borrow(i, n) {
    const real = [...cells.values()].filter((c) => !c.shared && c.tex).map((c) => c.tex);
    const choice = pool.concat(real);
    if (!choice.length) return false;
    cells.set(i, { i, tex: choice[(n * 7 + 3) % choice.length], img: null, info: null, shared: true });
    return true;
  }

  function draw() {
    const d = dpr();
    const vert = vertical();
    const [cw, ch] = vert ? [stage.height, stage.width] : [stage.width, stage.height];   // längs, quer
    const lo = Math.floor(pos - G.len / 2 / G.pitch - 1), hi = Math.ceil(pos + G.len / 2 / G.pitch + 1);
    if (!gl) {
      ctx2.setTransform(1, 0, 0, 1, 0, 0);
      ctx2.clearRect(0, 0, stage.width, stage.height);
      if (vert) ctx2.setTransform(0, -1, 1, 0, 0, stage.height);
      for (let i = lo; i <= hi; i += 1) {
        const t = textureFor(i);
        ctx2.drawImage(t.src, cellLeft(i) * d, 0, G.pitch * d, ch);
      }
      return;
    }
    setupFbo();
    const blurDev = blurPx * d;
    const k = Math.max(1, blurDev / 7);                 // waagrecht weniger Pixel, solange es verschwimmt
    const vw = Math.max(1, Math.ceil(cw / k));
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    gl.viewport(0, 0, vw, ch);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.useProgram(progCell);
    gl.uniform2f(locCell.uView, vw, ch);
    gl.uniform1i(locCell.uTex, 0);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    for (let i = lo; i <= hi; i += 1) {
      gl.bindTexture(gl.TEXTURE_2D, textureFor(i).tex);
      gl.uniform4f(locCell.uRect, (cellLeft(i) * d) / k, 0, (G.pitch * d) / k, ch);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }
    gl.disable(gl.BLEND);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, stage.width, stage.height);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.useProgram(progComp);
    gl.uniform1f(locComp.uVert, vert ? 1 : 0);
    gl.bindTexture(gl.TEXTURE_2D, fboTex);
    const span = blurDev / k;                           // Unschärfe in Pixeln des Zwischenspeichers
    const taps = span < 1.2 ? 1 : Math.min(16, Math.ceil(span / 1.1) + 1);
    gl.uniform1i(locComp.uTex, 0);
    gl.uniform1f(locComp.uScaleX, (cw / k) / fboW);
    gl.uniform1f(locComp.uMaxX, (vw - 0.5) / fboW);
    gl.uniform1f(locComp.uStep, taps > 1 ? span / (taps - 1) / fboW : 0);
    gl.uniform1i(locComp.uTaps, taps);
    const grain = cfg.Grain ? (cfg.Film === "bw" ? 0.09 : 0.055) * clamp(1 - blurPx / 25) : 0;
    gl.uniform1f(locComp.uGrain, grain);
    gl.uniform1f(locComp.uOff, (((-pos * G.pitch * d) % 8192) + 8192) % 8192);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  }

  // ------------------------------------------------------------ Fettstift und Notiz (Canvas über dem Streifen)

  const inkG = ink.getContext("2d");
  let marker = null;            // { i, k, path, star, note }

  // Fettstift: viele Strichführungen und Zeichen, die sich nicht direkt wiederholen.
  // Alles sind Linienzüge (Punktlisten), die nacheinander gezogen werden.
  const recent = { style: [], doodle: [] };
  function pickFresh(list, memory, keep) {
    const fresh = list.filter((x) => !memory.includes(x.id));
    const pick = (fresh.length ? fresh : list)[Math.floor(rand() * (fresh.length || list.length))];
    memory.push(pick.id);
    while (memory.length > keep) memory.shift();
    return pick;
  }
  const jit = (v) => (rand() - 0.5) * 2 * v;

  // Rundum-Schleife als Superellipse: p klein = Oval, groß = Rechteck mit runden Ecken
  function loop(box, o = {}) {
    const cx = box.x + box.w / 2 + (o.dx || 0), cy = box.y + box.h / 2 + (o.dy || 0);
    const a = (box.w / 2) * (o.sx || 1), b = (box.h / 2) * (o.sy || 1);
    const p = o.p || 7, turns = o.turns || 1.08, grow = o.grow ?? 0.03, wob = o.wob ?? 1;
    const start = o.start ?? -Math.PI * (0.55 + rand() * 0.25);
    const ph1 = rand() * 6, ph2 = rand() * 6, ph3 = rand() * 6, tilt = o.tilt ?? jit(0.012);
    const egg = o.egg || 0;
    const pts = [], steps = Math.round(200 * turns);
    for (let s = 0; s <= steps; s += 1) {
      const u = s / steps;
      const th = start + u * Math.PI * 2 * turns;
      const c = Math.cos(th), sn = Math.sin(th);
      const w = 1 + wob * (0.012 * Math.sin(3 * th + ph1) + 0.008 * Math.sin(7 * th + ph2) + 0.004 * Math.sin(13 * th + ph3)) + grow * u * u;
      let x = a * Math.sign(c) * Math.pow(Math.abs(c), 2 / p) * w;
      let y = b * Math.sign(sn) * Math.pow(Math.abs(sn), 2 / p) * w;
      if (egg) x *= 1 + egg * (y / b);
      pts.push([cx + x * Math.cos(tilt) - y * Math.sin(tilt), cy + x * Math.sin(tilt) + y * Math.cos(tilt)]);
    }
    return pts;
  }
  // gerade, leicht zittrige Linie
  function line(x0, y0, x1, y1, wob = 0.004) {
    const pts = [], n = 24, len = Math.hypot(x1 - x0, y1 - y0), nx = -(y1 - y0) / (len || 1), ny = (x1 - x0) / (len || 1);
    const ph = rand() * 6, bow = jit(len * 0.012);
    for (let s = 0; s <= n; s += 1) {
      const u = s / n, off = Math.sin(u * Math.PI) * bow + Math.sin(u * 9 + ph) * len * wob;
      pts.push([x0 + (x1 - x0) * u + nx * off, y0 + (y1 - y0) * u + ny * off]);
    }
    return pts;
  }
  function poly(points) {          // Ecken eines Zeichens, mit kleinen Ausrutschern
    return points.map(([x, y]) => [x, y]);
  }

  const MARKS = [
    { id: "round", make: (b) => [loop(b, { p: 9 })] },
    { id: "oval", make: (b) => [loop(b, { p: 2.4, sx: 1.12, sy: 1.18 })] },
    { id: "double", make: (b) => [loop(b, { p: 6, turns: 1.9, grow: 0.06 })] },
    { id: "open", make: (b) => [loop(b, { p: 8, turns: 0.9, grow: 0 })] },
    { id: "tilted", make: (b) => [loop(b, { p: 12, tilt: jit(0.05) || 0.03, sx: 1.03 })] },
    { id: "egg", make: (b) => [loop(b, { p: 3.2, egg: 0.08, sx: 1.08, sy: 1.12 })] },
    { id: "shaky", make: (b) => [loop(b, { p: 7, wob: 2.6, turns: 1.12 })] },
    { id: "overshoot", make: (b) => [loop(b, { p: 10, turns: 1.22, grow: 0.07 })] },
    { id: "twice", make: (b) => [loop(b, { p: 9, turns: 1.02 }), loop(b, { p: 7, turns: 1.0, sx: 1.025, sy: 1.04, dx: b.w * 0.006 })] },
    { id: "brackets", make: (b) => {
      const l = Math.min(b.w, b.h) * 0.22, out = [];
      for (const [x, y, sx, sy] of [[b.x, b.y, 1, 1], [b.x + b.w, b.y, -1, 1], [b.x + b.w, b.y + b.h, -1, -1], [b.x, b.y + b.h, 1, -1]]) {
        out.push(line(x + sx * l, y + jit(l * 0.04), x + jit(l * 0.03), y, 0.006).concat(line(x, y, x + jit(l * 0.04), y + sy * l, 0.006)));
      }
      return out;
    } },
    { id: "box", make: (b) => {
      const e = Math.min(b.w, b.h) * 0.05;
      return [line(b.x - e, b.y + jit(e * 0.4), b.x + b.w + e, b.y + jit(e * 0.4)),
        line(b.x + b.w + jit(e * 0.4), b.y - e, b.x + b.w + jit(e * 0.4), b.y + b.h + e),
        line(b.x + b.w + e, b.y + b.h + jit(e * 0.4), b.x - e, b.y + b.h + jit(e * 0.4)),
        line(b.x + jit(e * 0.4), b.y + b.h + e, b.x + jit(e * 0.4), b.y - e)];
    } },
    { id: "thick", make: (b) => [loop(b, { p: 8, turns: 1.05 })], lw: 1.45 },
    { id: "quick", make: (b) => [loop(b, { p: 5, turns: 1.14, wob: 0.6, sx: 1.04, sy: 1.08 })], lw: 0.7 },
    { id: "underline", make: (b) => {
      const y = b.y + b.h + Math.min(b.w, b.h) * 0.04;
      return [line(b.x + b.w * 0.04, y, b.x + b.w * 0.96, y + jit(b.h * 0.02), 0.003),
        line(b.x + b.w * 0.1, y + b.h * 0.045, b.x + b.w * 0.8, y + b.h * 0.05, 0.003)];
    } },
    { id: "corners-loop", make: (b) => [loop(b, { p: 16, turns: 1.04, wob: 0.5 })] }
  ];

  // Zeichen in der Ecke; Mittelpunkt (cx, cy), Größe r
  const DOODLES = [
    { id: "star", make: (cx, cy, r) => [poly([0, 1, 2, 3, 4, 5].map((s) => {
      const th = -Math.PI / 2 + (s * 4 * Math.PI) / 5;
      return [cx + r * Math.cos(th) + jit(r * 0.06), cy + r * Math.sin(th) + jit(r * 0.06)];
    }))] },
    { id: "heart", make: (cx, cy, r) => {
      const pts = [];
      for (let s = 0; s <= 60; s += 1) {
        const t = (s / 60) * Math.PI * 2;
        const x = 16 * Math.pow(Math.sin(t), 3), y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
        pts.push([cx + (x / 17) * r, cy - (y / 17) * r]);
      }
      return [pts];
    } },
    { id: "check", make: (cx, cy, r) => [line(cx - r, cy, cx - r * 0.25, cy + r * 0.75).concat(line(cx - r * 0.25, cy + r * 0.75, cx + r * 1.1, cy - r, 0.003))] },
    { id: "exclaim", make: (cx, cy, r) => [line(cx - r * 0.15, cy - r, cx, cy + r * 0.4), line(cx + r * 0.32, cy - r, cx + r * 0.42, cy + r * 0.4),
      loop({ x: cx - r * 0.06, y: cy + r * 0.72, w: r * 0.14, h: r * 0.14 }, { p: 2, turns: 1, grow: 0 }), loop({ x: cx + r * 0.38, y: cy + r * 0.72, w: r * 0.14, h: r * 0.14 }, { p: 2, turns: 1, grow: 0 })] },
    { id: "arrow", make: (cx, cy, r) => [line(cx + r * 1.2, cy - r * 0.9, cx - r * 0.6, cy + r * 0.5),
      line(cx - r * 0.6, cy + r * 0.5, cx - r * 0.55, cy - r * 0.1).concat(line(cx - r * 0.55, cy - r * 0.1, cx - r * 0.6, cy + r * 0.5)).concat(line(cx - r * 0.6, cy + r * 0.5, cx + r * 0.05, cy + r * 0.48))] },
    { id: "smile", make: (cx, cy, r) => [loop({ x: cx - r, y: cy - r, w: 2 * r, h: 2 * r }, { p: 2, turns: 1.05, grow: 0 }),
      line(cx - r * 0.35, cy - r * 0.35, cx - r * 0.33, cy - r * 0.15), line(cx + r * 0.35, cy - r * 0.35, cx + r * 0.33, cy - r * 0.15),
      [0, 1, 2, 3, 4, 5, 6, 7, 8].map((s) => { const t = Math.PI * (0.15 + 0.7 * s / 8); return [cx + Math.cos(t) * r * 0.55, cy + r * 0.05 + Math.sin(t) * r * 0.45]; })] },
    { id: "bolt", make: (cx, cy, r) => [poly([[cx + r * 0.3, cy - r], [cx - r * 0.45, cy + r * 0.1], [cx + r * 0.1, cy + r * 0.05], [cx - r * 0.3, cy + r], [cx + r * 0.55, cy - r * 0.15], [cx - r * 0.02, cy - r * 0.1], [cx + r * 0.3, cy - r]])] },
    { id: "spiral", make: (cx, cy, r) => {
      const pts = [];
      for (let s = 0; s <= 90; s += 1) { const t = (s / 90) * Math.PI * 5; const rr = (r * s) / 90; pts.push([cx + Math.cos(t) * rr, cy + Math.sin(t) * rr]); }
      return [pts];
    } },
    { id: "sun", make: (cx, cy, r) => {
      const out = [loop({ x: cx - r * 0.45, y: cy - r * 0.45, w: r * 0.9, h: r * 0.9 }, { p: 2, turns: 1.05, grow: 0 })];
      for (let s = 0; s < 8; s += 1) { const t = (s / 8) * Math.PI * 2 + jit(0.1); out.push(line(cx + Math.cos(t) * r * 0.65, cy + Math.sin(t) * r * 0.65, cx + Math.cos(t) * r * 1.05, cy + Math.sin(t) * r * 1.05)); }
      return out;
    } },
    { id: "asterisk", make: (cx, cy, r) => [0, 1, 2].map((s) => { const t = (s / 3) * Math.PI + jit(0.1); return line(cx - Math.cos(t) * r, cy - Math.sin(t) * r, cx + Math.cos(t) * r, cy + Math.sin(t) * r); }) },
    { id: "two-stars", make: (cx, cy, r) => [0, 1].map((k) => poly([0, 1, 2, 3, 4, 5].map((s) => {
      const th = -Math.PI / 2 + (s * 4 * Math.PI) / 5, rr = r * (k ? 0.55 : 0.75), ox = k ? r * 1.1 : -r * 0.3, oy = k ? -r * 0.5 : r * 0.2;
      return [cx + ox + rr * Math.cos(th) + jit(rr * 0.06), cy + oy + rr * Math.sin(th) + jit(rr * 0.06)];
    }))) },
    { id: "word", text: true }
  ];
  const WORDS = { de: ["Top!", "ja!", "schön", "das!", "♥", "OK", "!!"], en: ["yes!", "nice", "this!", "keep", "OK", "!!", "♥"], es: ["¡sí!", "top", "¡esta!", "bonita", "OK", "!!", "♥"] };

  function makeMarker(box, rating) {
    const style = pickFresh(MARKS, recent.style, 6);
    const paths = style.make(box);
    let doodle = null, word = "";
    // ein Zeichen in einer Ecke: bei 4+ Sternen immer, sonst oft
    if (rating >= 4 || rand() < 0.55) {
      const d = pickFresh(DOODLES, recent.doodle, 5);
      const r = 2.1 * G.mm * (0.85 + rand() * 0.35);
      const corners = [[box.x + box.w + r * 0.9, box.y - r * 0.2], [box.x - r * 0.9, box.y - r * 0.2], [box.x + box.w + r * 0.9, box.y + box.h + r * 0.1], [box.x + box.w * 0.85, box.y - r * 1.2]];
      const [cx, cy] = corners[Math.floor(rand() * corners.length)];
      if (d.text) {
        const list = WORDS[lang] || WORDS.en;
        word = list[Math.floor(rand() * list.length)];
        doodle = { word, x: cx, y: cy, size: r * 1.5, rot: jit(0.18) };
      } else {
        doodle = { paths: d.make(cx, cy, r) };
      }
    }
    return { paths, doodle, lw: style.lw || 1 };
  }

  function strokePart(pts, k) {
    if (k <= 0 || pts.length < 2) return;
    const lens = [0];
    for (let s = 1; s < pts.length; s += 1) lens.push(lens[s - 1] + Math.hypot(pts[s][0] - pts[s - 1][0], pts[s][1] - pts[s - 1][1]));
    const want = lens[lens.length - 1] * clamp(k);
    inkG.beginPath();
    inkG.moveTo(pts[0][0], pts[0][1]);
    for (let s = 1; s < pts.length; s += 1) {
      if (lens[s] > want) {
        const f = (want - lens[s - 1]) / Math.max(1e-6, lens[s] - lens[s - 1]);
        inkG.lineTo(pts[s - 1][0] + (pts[s][0] - pts[s - 1][0]) * f, pts[s - 1][1] + (pts[s][1] - pts[s - 1][1]) * f);
        break;
      }
      inkG.lineTo(pts[s][0], pts[s][1]);
    }
    inkG.stroke();
  }

  let crayon = null;
  function drawInk() {
    const d = Math.min(dpr(), 1.25);
    inkG.setTransform(d, 0, 0, d, 0, 0);
    inkG.clearRect(0, 0, W, H);
    if (!marker) return;
    if (marker.mark) {
      const m = marker.mark;
      const lw = Math.max(3, G.mm * 0.62) * m.lw;
      inkG.lineCap = "round";
      inkG.lineJoin = "round";
      // Rahmen in der ersten Sekunde, Zeichen danach; mehrere Züge nacheinander
      const drawAll = (paths, k, extra) => {
        const n = paths.length;
        paths.forEach((p, idx) => strokePart(p, k * n - idx));
        if (extra) extra();
      };
      for (const pass of [0, 1]) {
        inkG.save();
        if (pass) {
          inkG.strokeStyle = "rgba(240,70,55,.35)";
          inkG.lineWidth = lw * 0.45;
          inkG.translate(lw * 0.18, -lw * 0.12);
        } else {
          inkG.strokeStyle = "rgba(205,34,28,.86)";
          inkG.lineWidth = lw;
        }
        drawAll(m.paths, marker.k);
        if (m.doodle && m.doodle.paths) {
          inkG.lineWidth = (pass ? 0.45 : 1) * Math.max(2.5, G.mm * 0.5);
          drawAll(m.doodle.paths, (marker.k - 1) / 0.28);
        }
        inkG.restore();
      }
      if (m.doodle && m.doodle.word && marker.k > 1) {
        inkG.save();
        inkG.font = HAND(m.doodle.size);
        inkG.textAlign = "center";
        inkG.textBaseline = "middle";
        inkG.fillStyle = "rgba(205,34,28,.88)";
        inkG.globalAlpha = clamp((marker.k - 1) / 0.25);
        inkG.translate(m.doodle.x, m.doodle.y);
        inkG.rotate(m.doodle.rot);
        inkG.fillText(m.doodle.word, 0, 0);
        inkG.restore();
      }
      // wachsige Struktur: feine Lücken im Strich
      if (!crayon) crayon = noisePattern(inkG, 128, 0.9, false);
      inkG.save();
      inkG.globalCompositeOperation = "destination-out";
      inkG.globalAlpha = 0.38;
      inkG.fillStyle = crayon;
      inkG.fillRect(0, 0, W, H);
      inkG.restore();
    }
    if (marker.note && vertical()) {
      // senkrecht: Notiz rechts neben dem Streifen, Datum und Ort untereinander
      const room = W - G.left - G.Sh;
      const size = clamp(Math.min(H * 0.046, room * 0.09), 16, 70);
      inkG.font = HAND(size);
      inkG.textAlign = "center";
      inkG.textBaseline = "middle";
      inkG.fillStyle = look().note;
      inkG.globalAlpha = clamp(marker.k * 1.5 - 0.3);
      inkG.save();
      inkG.translate(G.left + G.Sh + room / 2, H / 2);
      inkG.rotate(-0.02);
      marker.note.split(" · ").forEach((text, idx, all) => {
        inkG.fillText(fitText(inkG, text, room * 0.85), 0, (idx - (all.length - 1) / 2) * size * 1.25);
      });
      inkG.restore();
      inkG.globalAlpha = 1;
    } else if (marker.note) {
      const size = clamp(H * 0.046, 18, 70);
      inkG.font = HAND(size);
      inkG.textAlign = "center";
      inkG.textBaseline = "middle";
      inkG.fillStyle = look().note;
      inkG.globalAlpha = clamp(marker.k * 1.5 - 0.3);
      inkG.save();
      inkG.translate(W / 2, G.top + G.Sh + Math.min(H * 0.055, (H - G.top - G.Sh) * 0.5));
      inkG.rotate(-0.012);
      inkG.fillText(fitText(inkG, marker.note, W * 0.8), 0, 0);
      inkG.restore();
      inkG.globalAlpha = 1;
    }
  }

  function resizeInk() {
    const d = Math.min(dpr(), 1.25);
    ink.width = Math.max(2, Math.round(W * d));
    ink.height = Math.max(2, Math.round(H * d));
  }

  function startMarker(i) {
    const cell = cells.get(i);
    if (!cell || !cell.img) return;
    const wantNote = cfg.Captions === "note" && cell.info;
    if (!cfg.Marker && !wantNote) return;
    ink.classList.remove("out");
    const r = screenImage();
    const pad = (1.1 + rand() * 0.7) * G.mm;
    const box = { x: r.x - pad, y: r.y - pad, w: r.w + pad * 2, h: r.h + pad * 2 };
    const rating = cell.info ? Number(cell.info.rating) || 0 : 0;
    marker = {
      i, k: 0,
      mark: cfg.Marker ? makeMarker(box, rating) : null,
      note: wantNote ? [dateText(cell.info.taken, true), shortPlace(cell.info.place)].filter(Boolean).join(" · ") : ""
    };
  }

  async function hideMarker() {
    if (!marker) return;
    ink.classList.add("out");
    await new Promise((r) => setTimeout(r, 380));
    marker = null;
    drawInk();
  }

  // ------------------------------------------------------------ Bewegung

  // Geschwindigkeitsprofil mit weichen Rampen (halbe Kosinuswelle):
  // Anlaufen 0 -> V in ta, Vollgas tc, Abbremsen V -> 0 in td.
  function profile(D) {
    const p = PACES[cfg.Pace] || PACES.normal;
    let V = p.V;
    const ta = p.ta, td = p.td;
    const ramps = (V * (ta + td)) / 2;
    let tc = 0;
    if (D >= ramps) tc = (D - ramps) / V;
    else V = (2 * D) / (ta + td);
    return { V, ta, tc, td, T: ta + tc + td, D };
  }
  // Weg (Bilder) und Geschwindigkeit (Bilder/s) nach t Sekunden
  function along(pr, t) {
    const { V, ta, tc, td, T, D } = pr;
    if (t <= 0) return [0, 0];
    if (t < ta) return [V * (t / 2 - (ta / (2 * Math.PI)) * Math.sin((Math.PI * t) / ta)), V * (1 - Math.cos((Math.PI * t) / ta)) / 2];
    if (t < ta + tc) return [(V * ta) / 2 + V * (t - ta), V];
    if (t < T) {
      const r = T - t;   // gespiegelt vom Ende her
      return [D - V * (r / 2 - (td / (2 * Math.PI)) * Math.sin((Math.PI * r) / td)), V * (1 - Math.cos((Math.PI * r) / td)) / 2];
    }
    return [D, 0];
  }
  function pickDistance() {
    const r = rand();
    const spool = () => 10 + Math.floor(rand() * 21);           // 10 bis 30 Bilder
    switch (cfg.Distance) {
      case "next": return 1;
      case "few": return 2 + Math.floor(r * 3);
      case "far": return spool();
      default: return r < 0.25 ? 1 : r < 0.45 ? 2 + Math.floor(rand() * 3) : spool();
    }
  }
  function blurFor(cellsPerSecond) {
    const key = SHUTTER[cfg.Blur] !== undefined ? cfg.Blur : "strong";
    return Math.min(G.pitch * BLUR_MAX[key], Math.abs(cellsPerSecond) * G.pitch * SHUTTER[key]);
  }

  function travel(D) {
    return new Promise((resolve) => {
      motion = { from: pos, pr: profile(D), t0: 0, resolve };
    });
  }

  function stepMotion(now) {
    if (!motion) return;
    if (!motion.t0) motion.t0 = now;
    const t = ((now - motion.t0) * SPEED) / 1000;
    const [x, v] = along(motion.pr, t);
    pos = motion.from + x;
    blurPx = blurFor(v);
    if (t >= motion.pr.T) {
      pos = motion.from + motion.pr.D;
      blurPx = 0;
      const done = motion.resolve;
      motion = null;
      done();
    }
    dirty = true;
  }

  // ------------------------------------------------------------ Bildrate

  const perf = { frames: 0, since: 0, slow: 0 };
  function watchPerf(now) {
    if (!motion || document.hidden) { perf.frames = 0; perf.since = now; return; }
    perf.frames += 1;
    if (now - perf.since < 3000) return;
    const fps = (perf.frames * 1000) / (now - perf.since);
    perf.frames = 0;
    perf.since = now;
    if (fps < 24) perf.slow += 1; else perf.slow = 0;
    if (perf.slow >= 2 && renderScale > 0.6) {
      perf.slow = 0;
      renderScale = Math.max(0.6, renderScale * 0.8);
      try { localStorage.setItem("cs-scale", String(renderScale)); } catch (_) { /* kein Speicher */ }
      report(`Bildrate ${fps.toFixed(0)} fps: weniger Pixel (${Math.round(renderScale * 100)} %)`);
      sizeStage();
    }
  }

  let markerT0 = 0;
  const stats = { frames: 0, drawn: 0 };
  window.__contactSheet = stats;   // für Tests
  function frame(now) {
    stats.frames += 1;
    stepMotion(now);
    if (dirty) {
      draw();
      stats.drawn += 1;
      dirty = false;
    }
    if (marker && marker.k < 1.3) {
      if (!markerT0) markerT0 = now;
      marker.k = Math.min(1.3, ((now - markerT0) * SPEED) / 1100);
      drawInk();
    } else if (!marker) {
      markerT0 = 0;
    }
    watchPerf(now);
    requestAnimationFrame(frame);
  }

  function sizeStage() {
    const d = dpr();
    const [w, h] = vertical() ? [G.Sh, H] : [W, G.Sh];
    stage.style.left = `${G.left}px`;
    stage.style.top = `${G.top}px`;
    stage.style.width = `${w}px`;
    stage.style.height = `${h}px`;
    stage.width = Math.max(2, Math.round(w * d));
    stage.height = Math.max(2, Math.round(h * d));
    resizeInk();
    for (const [i, cell] of cells) if (cell.shared) cells.delete(i);
    for (const t of pool.splice(0)) freeTexture(t);
    for (const cell of cells.values()) {
      freeTexture(cell.tex);
      cell.tex = makeTexture(paintCell(cell.i, cell));
    }
    freeTexture(blankTex);
    blankTex = null;
    dirty = true;
  }

  function relayout() {
    geometry();
    buildBackground();
    sizeStage();
    if (marker) {
      const i = marker.i;
      marker = null;
      startMarker(i);
      if (marker) marker.k = 1.3;
    }
    drawInk();
    laidOut = true;
  }

  let resizeTimer = 0;
  window.addEventListener("resize", () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      W = window.innerWidth;
      H = window.innerHeight;
      relayout();
    }, 300);
  });

  // ------------------------------------------------------------ Fotos holen

  function requestSize() {
    const ratio = Math.min(window.devicePixelRatio || 1, 1.5);
    const upright = vertical() ? G.F.ih : G.F.iw;      // Breite des Bildfelds, aufrecht
    const w = Math.min(1800, Math.round(upright * G.mm * ratio * 1.05));
    return [w, Math.min(2400, Math.round(w * 1.5))];
  }

  let failures = 0;
  async function fetchNext() {
    if (DEMO) return demoPhoto();
    const [w, h] = requestSize();
    const info = await api(`api/next?w=${w}&h=${h}`);
    if (!info || !info.success) {
      throw new Error(info && info.error === "empty" ? (info.busy ? "wait" : "none") : "photo");
    }
    const img = await loadImage(url(`api/photo?id=${info.id}`));
    try { await img.decode(); } catch (_) { /* schon dekodiert */ }
    return { img, info };
  }

  // Füllt die Bildfelder (der Reihe nach) mit neuen Fotos
  async function ensureCells(indices) {
    for (const i of indices) {
      if (cells.has(i) && cells.get(i).img) continue;
      let entry = null;
      for (let attempt = 0; attempt < 3 && !entry; attempt += 1) {
        try {
          entry = await fetchNext();
          failures = 0;
          if (note.textContent && note.textContent !== tx("none")) showNote("");
        } catch (error) {
          failures += 1;
          if (error.message === "wait" || error.message === "none") {
            showNote(tx(error.message));
            ready();
            return false;
          }
          if (failures > 1) showNote(error.message === "login" ? tx("login") : tx("unreachable"));
          ready();
          await sleep(2500);
        }
      }
      if (!entry) return false;
      setCell(i, entry);
    }
    return true;
  }

  async function poll() {
    if (DEMO) return { count: 1 };
    try {
      const data = await api("api/scene");
      applySettings(data.settings);
      if (!data.count) showNote(data.busy || data.status === "" ? tx("wait") : tx("none"));
      else if ([tx("wait"), tx("none"), tx("unreachable"), tx("login")].includes(note.textContent)) showNote("");
      return data;
    } catch (error) {
      if (!cells.size) showNote(error.message === "login" ? tx("login") : tx("unreachable"));
      ready();
      return null;
    }
  }

  async function pollLoop() {
    while (true) {
      await sleep(20000);
      await poll();
    }
  }

  // ------------------------------------------------------------ Regie

  function around(center, r) {
    const list = [center];
    for (let s = 1; s <= r; s += 1) list.push(center + s, center - s);
    return list;
  }

  async function director() {
    // Erst die Mitte, dann nach außen; der Streifen blendet ein, sobald die Mitte steht
    while (!(await ensureCells([0]))) await sleep(8000);
    stage.classList.add("on");
    await ensureCells(around(0, reach()).slice(1));
    while (true) {
      const here = Math.round(pos);
      if (!cells.get(here) || !cells.get(here).img) await ensureCells([here]);
      startMarker(here);
      const D = pickDistance();
      const pr = profile(D);
      // echte Fotos am Anfang (noch langsam) und am Ziel, dazwischen Vorbeirauschendes
      const headEnd = here + reach() + Math.ceil((pr.V * pr.ta) / 2) + 1;
      const tailStart = here + D - reach() - Math.ceil((pr.V * pr.td) / 2) - 1;
      const wanted = [];
      for (let i = here + 1, n = 0; i <= here + D + reach(); i += 1, n += 1) {
        if (i <= headEnd || i >= tailStart || !borrow(i, n)) wanted.push(i);
      }
      const loading = ensureCells(wanted);
      await sleep(cfg.HoldSeconds * 1000);
      // langsame Quelle: noch etwas warten, dann fährt er trotzdem (fehlende Felder bleiben schwarz)
      await Promise.race([loading, sleep(30000)]);
      await hideMarker();
      await travel(D);
      dropCells();
    }
  }

  // ------------------------------------------------------------ Ohne Plugin (?demo=1)

  let demoIndex = 0;
  const demoList = (params.get("photos") || "").split(",").filter(Boolean);
  function paintDemo(i) {
    const c = document.createElement("canvas");
    c.width = i % 3 === 1 ? 800 : 1200; c.height = i % 3 === 1 ? 1100 : 800;
    const g = c.getContext("2d");
    const sky = g.createLinearGradient(0, 0, 0, c.height);
    const themes = [["#1d3b72", "#f08a4b", "#ffd27a"], ["#7fb7e6", "#cfe8f7", "#f7f3e8"], ["#2b1844", "#8e3b6b", "#f2a65a"], ["#3c7a5a", "#a9d18e", "#f0f4d8"]];
    const th = themes[i % themes.length];
    sky.addColorStop(0, th[0]); sky.addColorStop(0.6, th[1]); sky.addColorStop(1, th[2]);
    g.fillStyle = sky; g.fillRect(0, 0, c.width, c.height);
    g.fillStyle = "rgba(255,240,200,.9)";
    g.beginPath(); g.arc(200 + 250 * (i % 3), 260, 70, 0, Math.PI * 2); g.fill();
    g.fillStyle = "#2a2f3a";
    g.beginPath(); g.moveTo(0, c.height * 0.75);
    for (let x = 0; x <= c.width; x += 100) g.lineTo(x, c.height * 0.65 + 60 * Math.sin(x / 140 + i));
    g.lineTo(c.width, c.height); g.lineTo(0, c.height); g.fill();
    return c.toDataURL("image/jpeg", 0.9);
  }
  async function demoPhoto() {
    const i = demoIndex;
    demoIndex += 1;
    const src = demoList.length ? demoList[i % demoList.length] : paintDemo(i);
    const img = await loadImage(src);
    try { await img.decode(); } catch (_) { /* schon dekodiert */ }
    const places = ["Lisbon, Portugal", "Garmisch-Partenkirchen, Germany", "Rome, Italy", "", "Gran Canaria, Spain", "Stockholm, Sweden"];
    return { img, info: { taken: `20${18 + (i % 7)}-0${1 + (i % 9)}-1${i % 9}T12:00:00`, place: places[i % places.length], rating: i % 6 } };
  }

  // ------------------------------------------------------------ Standbild (?pose=) für Store-Bilder

  async function posed() {
    const at = Number(params.get("at")) || 1.5;
    const list = [];
    for (let i = -reach(); i <= (POSE === "move" ? Math.ceil(at) : 0) + reach() + 1; i += 1) list.push(i);
    await ensureCells(list);
    stage.style.transition = "none";
    stage.classList.add("on");
    if (POSE === "move") {
      pos = at;
      blurPx = blurFor(profile(20).V);
    } else {
      startMarker(0);
      if (marker) marker.k = 1.3;
      drawInk();
    }
    draw();
    ready();
    document.body.dataset.shot = "ready";
  }

  // ------------------------------------------------------------ Start

  async function start() {
    geometry();
    if (!DEMO) await poll();
    try { await document.fonts.load(HAND(40)); } catch (_) { /* ohne Handschrift */ }
    relayout();
    ready();        // der Untergrund steht, der Streifen kommt gleich
    if (POSE) {
      posed();
      return;
    }
    requestAnimationFrame(frame);
    pollLoop();
    director();
  }
  start();
})();
