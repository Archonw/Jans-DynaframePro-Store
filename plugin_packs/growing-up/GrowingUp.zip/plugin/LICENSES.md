# Licences

- Growing Up: by Jan, for DynaFrame.
- Pillow (HPND licence), installed from PyPI for cutting out the portraits.
- requests (Apache 2.0).
