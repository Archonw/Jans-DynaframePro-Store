# Third-party notes

- Weather data by Open-Meteo.com (https://open-meteo.com), licensed under CC BY 4.0; historical data from the ERA5 reanalysis (Copernicus Climate Change Service).
- Place names from OpenStreetMap via Nominatim, © OpenStreetMap contributors, ODbL.
- The scene bundles the fonts Fraunces and Inter under the SIL Open Font License 1.1 (see `dynamic/fonts/OFL-*.txt`).
- `exif_gps.py` is shared with the Travel Map plugin (own code).
