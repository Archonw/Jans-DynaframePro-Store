"""Musik auf dem Rahmen selbst abspielen.

Ein Stück läuft so: ffmpeg macht aus der Quelle (Datei, Radio-Stream,
Jellyfin-Adresse) rohe 16-Bit-Stereo-Daten, dieses Modul rechnet die
Lautstärke hinein (für Ein- und Ausblenden, Leiserstellen, Pause) und gibt
sie an einen Tonausgang weiter (pacat, pw-cat, ffmpeg -f pulse, aplay).
Die Lautstärke des Rahmens selbst bleibt dabei unangetastet: das Plugin
regelt nur seinen eigenen Ton.

Nur ffmpeg und ein Ausgang müssen auf dem Rahmen sein; was es gibt, sucht
find_tools() einmal heraus.
"""

import os
import random
import shutil
import signal
import subprocess
import sys
import threading
import time
from array import array

RATE = 48000
CHANNELS = 2
FRAME_BYTES = 2 * CHANNELS
CHUNK_FRAMES = 2048                      # ~43 ms je Block
CHUNK = CHUNK_FRAMES * FRAME_BYTES
SILENCE = bytes(CHUNK)
FADE_STEP_PER_SECOND = 1.0               # Grundtempo, wird je Wechsel gesetzt


def sound_environment():
    """Der Rahmen startet Plugins ohne XDG_RUNTIME_DIR; ohne finden pacat und
    pw-cat den Tondienst nicht (gemessen von FireWatch)."""
    env = dict(os.environ)
    env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
    return env


def _sink_commands():
    """Mögliche Tonausgänge, die rohe Daten von stdin lesen, beste zuerst."""
    raw = ["--format=s16le", f"--rate={RATE}", f"--channels={CHANNELS}"]
    options = []
    if shutil.which("pacat"):
        options.append(("pacat", [shutil.which("pacat"), "--playback", "--client-name=DynaFrame",
                                  "--stream-name=Playlist-Musik", "--latency-msec=200", *raw]))
    if shutil.which("pw-cat"):
        options.append(("pw-cat", [shutil.which("pw-cat"), "--playback", "--raw", "--format", "s16",
                                   "--rate", str(RATE), "--channels", str(CHANNELS), "-"]))
    ffmpeg = shutil.which("ffmpeg")
    if ffmpeg:
        options.append(("ffmpeg-pulse", [ffmpeg, "-hide_banner", "-loglevel", "error", "-f", "s16le",
                                         "-ar", str(RATE), "-ac", str(CHANNELS), "-i", "-",
                                         "-f", "pulse", "-name", "DynaFrame", "Playlist-Musik"]))
    if shutil.which("aplay"):
        options.append(("aplay", [shutil.which("aplay"), "-q", "-t", "raw", "-f", "S16_LE",
                                  "-r", str(RATE), "-c", str(CHANNELS), "-"]))
    if ffmpeg:
        options.append(("ffmpeg-alsa", [ffmpeg, "-hide_banner", "-loglevel", "error", "-f", "s16le",
                                        "-ar", str(RATE), "-ac", str(CHANNELS), "-i", "-",
                                        "-f", "alsa", "default"]))
    return options


_tools = {"checked": 0.0, "decoder": None, "sink": None, "sinkName": "", "note": ""}
_tools_lock = threading.Lock()


def find_tools(force=False):
    """ffmpeg zum Lesen und den ersten Tonausgang, der eine kurze Stille annimmt."""
    with _tools_lock:
        if not force and _tools["checked"] and time.time() - _tools["checked"] < 600:
            return dict(_tools)
        test_sink = os.environ.get("PLAYLISTMUSIC_SINK")   # nur für Tests: Befehl als Text
        _tools.update(checked=time.time(), decoder=shutil.which("ffmpeg"), sink=None, sinkName="", note="")
        if test_sink:
            _tools.update(sink=test_sink.split(), sinkName="test")
            return dict(_tools)
        errors = []
        for name, command in _sink_commands():
            try:
                process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                                           stderr=subprocess.PIPE, env=sound_environment())
                _, err = process.communicate(bytes(RATE // 5 * FRAME_BYTES), timeout=8)
            except (OSError, subprocess.TimeoutExpired) as exc:
                try:
                    process.kill()
                except Exception:
                    pass
                errors.append(f"{name}: {exc}")
                continue
            if process.returncode == 0:
                _tools.update(sink=command, sinkName=name)
                break
            errors.append(f"{name}: " + ((err or b"").decode("utf-8", "replace").strip()[:120] or str(process.returncode)))
        _tools["note"] = "; ".join(errors)
        return dict(_tools)


def _scale(block, gain):
    if gain >= 0.999:
        return block
    if gain <= 0.001:
        return bytes(len(block))
    samples = array("h")
    samples.frombytes(block[: len(block) - len(block) % 2])
    if sys.byteorder != "little":
        samples.byteswap()
    scaled = array("h", [int(s * gain) for s in samples])
    if sys.byteorder != "little":
        scaled.byteswap()
    return scaled.tobytes()


class FramePlayer:
    """Spielt eine Liste von Adressen/Dateien (oder einen Stream) auf dem Rahmen.

    tracks: Funktion, die eine Liste von Quellen liefert (wird neu gefragt,
    wenn die Liste durch ist). live=True: ein endloser Stream (Radio), der
    bei Abbruch neu verbunden wird.
    """

    def __init__(self, tracks, live=False, shuffle=False, log=None, on_title=None):
        self._tracks = tracks
        self.live = live
        self.shuffle = shuffle
        self.log = log or (lambda text, level="info": None)
        self.on_title = on_title or (lambda title: None)
        self.volume = 1.0          # Lautstärke der Regel (0..1)
        self.gain = 0.0            # aktuelle Blende (0..1), läuft zu target
        self.target = 1.0
        self.fade_per_second = 1.0 / 3
        self.paused = False
        self.problem = ""
        self.title = ""
        self._stop = threading.Event()
        self._skip = threading.Event()
        self._decoder = None
        self._sink = None
        self._thread = None

    # ---- Steuerung -------------------------------------------------------

    def start(self, fade_seconds=2.0):
        self.gain = 0.0
        self.fade_to(1.0, fade_seconds)
        self._thread = threading.Thread(target=self._run, name="PlaylistMusic-frame", daemon=True)
        self._thread.start()

    def fade_to(self, target, seconds):
        self.target = max(0.0, min(1.0, target))
        distance = abs(self.target - self.gain) or 1.0
        self.fade_per_second = distance / max(0.05, seconds)

    def stop(self, fade_seconds=0.0, wait=True):
        """Ausblenden (blockiert so lange, wenn wait) und beenden."""
        if fade_seconds > 0 and not self.paused and self.running():
            self.fade_to(0.0, fade_seconds)
            end = time.time() + fade_seconds + 1.5
            while wait and self.gain > 0.002 and time.time() < end and self.running():
                time.sleep(0.05)
        self._stop.set()
        self._kill()
        if wait and self._thread is not None:
            self._thread.join(timeout=5)

    def pause(self):
        self.paused = True

    def resume(self, fade_seconds=1.5):
        if self.paused:
            self.gain = 0.0
            self.paused = False
            self.fade_to(self.target if self.target > 0 else 1.0, fade_seconds)

    def running(self):
        return self._thread is not None and self._thread.is_alive() and not self._stop.is_set()

    def skip(self):
        self._skip.set()
        self._kill_decoder()

    # ---- Innenleben ------------------------------------------------------

    def _kill_decoder(self):
        process, self._decoder = self._decoder, None
        if process is not None:
            try:
                process.kill()
            except OSError:
                pass

    def _kill(self):
        self._kill_decoder()
        process, self._sink = self._sink, None
        if process is not None:
            try:
                process.stdin.close()
            except Exception:
                pass
            try:
                process.terminate()
                process.wait(timeout=3)
            except Exception:
                try:
                    process.kill()
                except Exception:
                    pass

    def _open_sink(self):
        tools = find_tools()
        if not tools["sink"]:
            raise OSError("kein Tonausgang")
        self._sink = subprocess.Popen(tools["sink"], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                                      stderr=subprocess.DEVNULL, env=sound_environment(),
                                      start_new_session=True)

    def _open_decoder(self, source):
        ffmpeg = find_tools()["decoder"]
        if not ffmpeg:
            raise OSError("ffmpeg fehlt")
        command = [ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin"]
        if str(source).startswith(("http://", "https://")):
            command += ["-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_delay_max", "10",
                        "-user_agent", "DynaFrame-PlaylistMusic/0.1"]
        command += ["-i", str(source), "-vn", "-f", "s16le", "-ar", str(RATE), "-ac", str(CHANNELS), "-"]
        self._decoder = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                         stdin=subprocess.DEVNULL, start_new_session=True)
        return self._decoder

    def _write(self, block):
        sink = self._sink
        if sink is None or sink.poll() is not None:
            self._open_sink()
            sink = self._sink
        sink.stdin.write(block)

    def _step_gain(self, seconds):
        if self.gain < self.target:
            self.gain = min(self.target, self.gain + self.fade_per_second * seconds)
        elif self.gain > self.target:
            self.gain = max(self.target, self.gain - self.fade_per_second * seconds)

    def _play_one(self, source):
        """Ein Stück bis zum Ende. True = normal zu Ende, False = Fehler."""
        decoder = self._open_decoder(source)
        block_seconds = CHUNK_FRAMES / RATE
        got_audio = False
        while not self._stop.is_set():
            if self.paused:
                if self.live:
                    data = decoder.stdout.read(CHUNK)   # Radio läuft weiter, nur stumm
                    if not data:
                        break
                self._write(SILENCE)
                continue
            data = decoder.stdout.read(CHUNK)
            if not data:
                break
            got_audio = True
            self._step_gain(block_seconds)
            self._write(_scale(data, self.gain * self.volume))
        if self._stop.is_set() or self._skip.is_set():
            return True
        code = decoder.wait()
        if code not in (0, None) and not got_audio:
            err = (decoder.stderr.read() or b"").decode("utf-8", "replace").strip()
            self.problem = err.splitlines()[-1][:200] if err else f"ffmpeg {code}"
            return False
        return True

    def _run(self):
        failures = 0
        queue = []
        while not self._stop.is_set():
            if not queue:
                try:
                    queue = list(self._tracks() or [])
                except Exception as exc:   # Quelle nicht erreichbar
                    self.problem = str(exc)[:200]
                    queue = []
                if self.shuffle and not self.live:
                    random.shuffle(queue)
                if not queue:
                    if self._stop.wait(min(60, 5 * (failures + 1))):
                        break
                    failures += 1
                    continue
            item = queue.pop(0)
            source, title = (item if isinstance(item, tuple) else (item, ""))
            self.title = title
            self.on_title(title)
            self._skip.clear()
            try:
                ok = self._play_one(source)
            except (OSError, ValueError, BrokenPipeError) as exc:
                ok = False
                self.problem = str(exc)[:200]
                self._kill()
            if self._stop.is_set():
                break
            if ok:
                failures = 0
                self.problem = ""
            else:
                failures += 1
                self.log(f"Konnte nicht abspielen: {self.problem}", "warning")
                if self.live:
                    queue = [item]
                if failures >= 5:
                    # Lange Fehlerserie: langsamer weiter versuchen
                    if self._stop.wait(min(300, 20 * failures)):
                        break
            if self.live and not queue:
                queue = [item]
        self._kill()


def kill_process_group(pid):
    try:
        os.killpg(pid, signal.SIGTERM)
    except (OSError, ProcessLookupError):
        pass
