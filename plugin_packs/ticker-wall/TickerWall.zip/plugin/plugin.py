#!/usr/bin/env python3
"""Ticker Wall - the plugin part of the Ticker Wall package.

A news-channel / trading-floor wall: news feeds, stock prices, crypto,
currencies, weather and earthquakes, all scrolling at once. The plugin
gathers the data (sources.py), works out what is going on (analysis.py:
topic radar, breaking news, news pace, market mood, movers) and hands it to
the scene "ticker-wall".

What a scene can't do, this plugin does:
- read many feeds and markets without CORS trouble and keep a 48 hour
  headline memory, so trends exist;
- watch for alerts (keywords, breaking news, price rules, big index moves,
  market opening bells, strong earthquakes) and then put the scene over the
  playlist (display takeover) with the alert in front;
- keep all settings on its own page (Plugins > Open Ticker Wall).

The scene reaches this plugin via the WebUI proxy on :8003 or port 80.
"""

import json
import os
import re
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover - Python < 3.9
    ZoneInfo = None

import requests

# DynaFrame puts the shared SDK one folder above every plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import analysis  # noqa: E402
import presets  # noqa: E402
import sources  # noqa: E402
import texts  # noqa: E402

try:
    # Works around a DynaFrame bug that can leave a Quick Mix stopped after a
    # takeover (see there). Without the file everything else keeps working.
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None

plugin = create_plugin()

PLUGIN_ID = "TickerWall"
DISPLAY_NAME = "Ticker Wall"
SCENE_ID = "ticker-wall"         # id in scene.dynamic - never change
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"   # settings, state, headline memory; survives updates
CACHE_DIR = PLUGIN_DIR / "cache"  # last market data; may be deleted

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30
SERVICE_STATUS = f"{PLUGIN_ID}.Status"

EVENT_ALERT = "tickerwall_alert"
EVENT_STARTED = "tickerwall_display_started"
EVENT_ENDED = "tickerwall_display_ended"


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        pass
    try:
        return int(float(str(value).strip().replace(",", ".")))
    except (TypeError, ValueError):
        return default


def as_num(value, default=0.0):
    try:
        return float(str(value).strip().replace(",", "."))
    except (TypeError, ValueError):
        return default


def ensure_dirs():
    for folder in (DATA_DIR, CACHE_DIR):
        folder.mkdir(parents=True, exist_ok=True)


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Could not read {path.name}: {exc}", level="warning")
        return default


def write_json(path, payload, indent=None):
    """Atomic, so a power cut never leaves half a file."""
    ensure_dirs()
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=indent, ensure_ascii=False, separators=None if indent else (",", ":"))
    temp.replace(path)


def local_text(epoch):
    if not epoch:
        return ""
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Settings (all on the plugin page; the manifest declares none)
# --------------------------------------------------------------------------

_DEFAULTS = presets.preset("intl")

SETTINGS = {
    "Language":       {"kind": "choice", "default": "en", "options": list(texts.LANGUAGES)},
    "Region":         {"kind": "choice", "default": "intl", "options": list(presets.REGIONS)},
    "Look":           {"kind": "choice", "default": "news", "options": ["news", "terminal", "auto"]},
    "Feeds":          {"kind": "lines", "default": _DEFAULTS["Feeds"]},
    "Watchlist":      {"kind": "lines", "default": _DEFAULTS["Watchlist"]},
    "Coins":          {"kind": "text", "default": _DEFAULTS["Coins"]},
    "CoinCurrency":   {"kind": "choice", "default": _DEFAULTS["CoinCurrency"],
                       "options": ["usd", "eur", "gbp", "chf", "jpy"]},
    "Cities":         {"kind": "lines", "default": _DEFAULTS["Cities"]},
    "ShowWeather":    {"kind": "bool", "default": True},
    "ShowQuakes":     {"kind": "bool", "default": True},
    "ShowImages":     {"kind": "bool", "default": True},
    "TickerSpeed":    {"kind": "number", "default": 100, "min": 40, "max": 250},
    "NewsMinutes":    {"kind": "number", "default": 5, "min": 2, "max": 60},
    "MarketMinutes":  {"kind": "number", "default": 5, "min": 2, "max": 60},
    "FinnhubKey":     {"kind": "secret", "default": ""},
    # Alerts that put the wall over the playlist.
    "AlertKeywords":  {"kind": "lines", "default": ""},
    "AlertBreaking":  {"kind": "choice", "default": "off", "options": ["off", "marker", "cluster", "both"]},
    "BreakingSources": {"kind": "number", "default": 3, "min": 2, "max": 10},
    "AlertRules":     {"kind": "lines", "default": ""},
    "MovePct":        {"kind": "decimal", "default": 0, "min": 0, "max": 50},
    "MainIndex":      {"kind": "text", "default": _DEFAULTS["MainIndex"]},
    "IndexPct":       {"kind": "decimal", "default": 0, "min": 0, "max": 20},
    "Bells":          {"kind": "list", "default": [], "options": list(presets.EXCHANGES)},
    "QuakeMag":       {"kind": "decimal", "default": 0, "min": 0, "max": 9.5},
    "AlertSeconds":   {"kind": "number", "default": 60, "min": 10, "max": 900},
    "CooldownMinutes": {"kind": "number", "default": 10, "min": 0, "max": 240},
    # Regularly over the playlist.
    "AutoMode":       {"kind": "choice", "default": "off", "options": ["off", "always"]},
    "EveryMinutes":   {"kind": "number", "default": 60, "min": 5, "max": 1440},
    "ShowForSeconds": {"kind": "number", "default": 90, "min": 10, "max": 3600},
    "ActiveFrom":     {"kind": "number", "default": 7, "min": 0, "max": 23},
    "ActiveTo":       {"kind": "number", "default": 23, "min": 1, "max": 24},
    "MakePlaylist":   {"kind": "bool", "default": False},
}

SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
HEADLINES_FILE = DATA_DIR / "headlines.json"
MARKETS_FILE = CACHE_DIR / "markets.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return list(default) if isinstance(default, list) else default
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "number":
        return max(spec["min"], min(spec["max"], as_int(raw, default)))
    if kind == "decimal":
        value = max(spec["min"], min(spec["max"], as_num(raw, default)))
        return int(value) if value == int(value) else round(value, 2)
    if kind == "choice":
        value = str(raw).strip().lower()
        return value if value in spec["options"] else default
    if kind == "list":
        items = raw if isinstance(raw, list) else str(raw).split(",")
        chosen = {str(i).strip().lower() for i in items}
        return [o for o in spec["options"] if o in chosen]
    if kind == "lines":
        return str(raw).replace("\r", "")[:20000]
    if kind == "secret":
        return re.sub(r"\s+", "", str(raw))[:200]
    return str(raw).strip()[:2000]


def settings():
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
    return {name: coerce(name, stored.get(name)) for name in SETTINGS}


def tr(template, **values):
    """A text in the chosen language (see texts.py)."""
    return texts.t(settings()["Language"], template, **values)


def save_settings(changes):
    changed = []
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            value = coerce(name, raw)
            if stored.get(name, SETTINGS[name]["default"]) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, stored, indent=1)
    return changed


_state_lock = threading.Lock()


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**fields):
    with _state_lock:
        state = read_json(STATE_FILE, {}) or {}
        if all(k in state and state[k] == v for k, v in fields.items()):
            return state  # nothing new, so no write to the SD card
        state.update(fields)
        write_json(STATE_FILE, state, indent=1)
    return state


def feed_list(values):
    out = []
    for name, address in presets.parse_lines(values["Feeds"], 2):
        if not address and name.startswith("http"):
            name, address = urlparse(name).netloc, name
        if address.startswith(("http://", "https://")):
            out.append((name[:40] or urlparse(address).netloc, address))
    return out[:40]


def watch_list(values):
    """[(symbol, name, kind)] from 'Symbol | Name | kind' lines."""
    out, seen = [], set()
    for symbol, name, kind in presets.parse_lines(values["Watchlist"], 3):
        symbol = symbol.strip().upper()
        if symbol and symbol not in seen and re.match(r"^[A-Z0-9^=.:\-]{1,20}$", symbol):
            seen.add(symbol)
            out.append((symbol, name[:30], presets.kind_of(symbol, kind)))
    return out[:50]


def coin_list(values):
    return [c.strip().lower() for c in re.split(r"[,\s]+", values["Coins"]) if re.match(r"^[a-z0-9\-]{2,60}$", c.strip().lower())][:15]


def city_list(values):
    out = []
    for name, lat, lon, tz in presets.parse_lines(values["Cities"], 4):
        try:
            out.append({"name": name[:30], "lat": float(lat), "lon": float(lon), "tz": tz or "UTC"})
        except ValueError:
            continue
    return out[:8]


# --------------------------------------------------------------------------
# The engine on this frame
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} returned HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "note": ""}


def find_scene():
    """The installed scene. A playlist item needs its numeric id."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else
                      tr("Die Szene Ticker Wall ist auf der Plugins-Seite ausgeschaltet."))
        return row
    _scene.update(dbId=None, note=tr("Die Szene Ticker Wall ist auf diesem Rahmen nicht installiert. "
                                     "Installiere das Ticker-Wall-Paket noch einmal."))
    return None


# --------------------------------------------------------------------------
# Data: headlines, markets, crypto, weather, earthquakes
# --------------------------------------------------------------------------

_data_lock = threading.Lock()
_items = {}          # id -> headline (with "seen")
_feeds = {}          # name -> {"ok", "count", "error", "at"}
_quotes = {}         # symbol -> quote
_quote_errors = {}   # symbol -> error text
_crypto = []
_weather = []
_quakes = []
_errors = {}         # "crypto"/"weather"/"quakes" -> text
_version = {"n": 0}
_analysis = {"key": None, "result": None}
_due = {}
_first_news = {"done": False, "watching": False}

KEEP_SECONDS = 48 * 3600
KEEP_MAX = 4000


def bump():
    with _data_lock:
        _version["n"] += 1


def due(name, minutes, force=False):
    if not force and now() < _due.get(name, 0):
        return False
    _due[name] = now() + minutes * 60
    return True


def read_news(values, force=False):
    feeds = feed_list(values)
    if not feeds or not due("news", values["NewsMinutes"], force):
        return
    results = {}

    def one(feed):
        name, address = feed
        try:
            results[name] = ("ok", sources.read_feed(name, address))
        except sources.SourceError as exc:
            results[name] = ("error", str(exc))
        except Exception as exc:  # pragma: no cover - odd documents
            results[name] = ("error", f"{name}: {exc.__class__.__name__}")

    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(one, feeds))
    t = now()
    fresh = []
    with _data_lock:
        had_items = bool(_items)
        for name, (status, payload) in results.items():
            if status == "error":
                _feeds[name] = dict(_feeds.get(name) or {}, ok=False, error=payload, at=t)
                continue
            known_feed = bool((_feeds.get(name) or {}).get("ok"))
            _feeds[name] = {"ok": True, "count": len(payload), "error": "", "at": t}
            for item in payload:
                if item["id"] in _items:
                    continue
                item["seen"] = t
                if not known_feed:
                    item["quiet"] = True  # first read of this feed: what it has is not news
                _items[item["id"]] = item
                fresh.append(item)
        names = {n for n, _ in feeds}
        for name in [n for n in _feeds if n not in names]:
            del _feeds[name]
        cutoff = t - KEEP_SECONDS
        for key in [k for k, v in _items.items() if analysis.item_time(v) < cutoff or v["source"] not in names]:
            del _items[key]
        if len(_items) > KEEP_MAX:
            for key, _ in sorted(_items.items(), key=lambda kv: analysis.item_time(kv[1]))[:len(_items) - KEEP_MAX]:
                del _items[key]
    bad = [n for n, (s, _) in results.items() if s == "error"]
    plugin.log(f"News: {len(fresh)} new headlines from {len(feeds) - len(bad)} feeds"
               + (f", failed: {', '.join(bad)}" if bad else "") + ".")
    # Only headlines that came in while the wall was watching are news for alerts.
    if had_items or _first_news["done"]:
        _first_news["watching"] = True
        check_keyword_alerts(values, [i for i in fresh if now() - analysis.item_time(i) < 3600 and not i.get("quiet")])
    _first_news["done"] = True
    save_headlines()
    bump()


_curves = {}         # symbol -> {"previous": prev close, "points": [prices of this session]}
_market_note = {"text": "", "until": 0.0}


def note_curve(symbol, quote):
    """Finnhub's free plan has no day charts, so the wall draws its own from every read."""
    entry = _curves.get(symbol)
    if entry is None or entry.get("previous") != quote.get("previous"):
        entry = {"previous": quote.get("previous"), "points": [quote["previous"]] if quote.get("previous") else []}
        _curves[symbol] = entry
    points = entry["points"]
    if not points or points[-1] != quote["price"] or len(points) < 3:
        points.append(quote["price"])
    del points[:-120]
    return list(points)


def read_markets(values, force=False):
    rows = watch_list(values)
    if not rows or not due("markets", values["MarketMinutes"], force):
        return
    if now() < _market_note["until"] and not force:
        return
    got, failed = {}, {}
    names = {s: n for s, n, _ in rows}
    # Currencies: the ECB's daily rates.
    by_base = {}
    for symbol, _name, kind in rows:
        match = re.match(r"^([A-Z]{3})([A-Z]{3})=X$", symbol)
        if match:
            by_base.setdefault(match.group(1), []).append(match.group(2))
        elif kind == "fx":
            failed[symbol] = tr("{symbol}: Devisen bitte als EURUSD=X schreiben", symbol=symbol)
    for base, targets in by_base.items():
        try:
            for row in sources.read_ecb(base, targets):
                symbol = f"{row['symbol']}=X"
                row.update(symbol=symbol, name=names.get(symbol) or row["name"])
                got[symbol] = row
        except sources.SourceError as exc:
            for target in targets:
                failed[f"{base}{target}=X"] = str(exc)
    # Stocks and ETFs: Finnhub, one call per symbol, at most one a second (free plan: 60 a minute).
    stocks = [r for r in rows if r[2] != "fx"]
    key = values["FinnhubKey"]
    note = ""
    if stocks and not key:
        note = tr("Für Aktienkurse fehlt noch der kostenlose Finnhub-Schlüssel.")
    for n, (symbol, name, kind) in enumerate(stocks if key else []):
        if _stop_requested.is_set():
            return
        if n:
            time.sleep(1.1)
        try:
            quote = sources.read_finnhub(symbol, key)
        except sources.RateLimited as exc:
            note = str(exc)
            _market_note["until"] = now() + 300
            break
        except sources.AuthError as exc:
            note = str(exc)
            break
        except sources.SourceError as exc:
            failed[symbol] = str(exc)
            continue
        with _data_lock:
            curve = note_curve(symbol, quote)
        got[symbol] = dict(quote, symbol=symbol, name=name or symbol, kind=kind, curve=curve)
    with _data_lock:
        wanted = {s for s, _, _ in rows}
        for symbol in [s for s in _quotes if s not in wanted]:
            del _quotes[symbol]
        for symbol in [s for s in _curves if s not in wanted]:
            del _curves[symbol]
        _quotes.update(got)
        _quote_errors.clear()
        _quote_errors.update(failed)
        _errors["markets"] = note
    if failed or note:
        plugin.log(f"Markets: {len(got)} read, {len(failed)} failed. {note}".strip(), level="warning")
    check_market_alerts(values)
    bump()


def read_crypto(values, force=False):
    coins = coin_list(values)
    if not coins:
        with _data_lock:
            _crypto.clear()
        return
    if not due("crypto", max(3, values["MarketMinutes"]), force):
        return
    try:
        rows = sources.read_crypto(coins, values["CoinCurrency"])
        error = ""
    except sources.SourceError as exc:
        rows, error = None, str(exc)
        plugin.log(f"Crypto: {exc}", level="warning")
    with _data_lock:
        if rows is not None:
            _crypto[:] = rows
        _errors["crypto"] = error
    if rows is not None:
        check_market_alerts(values, crypto=True)
    bump()


def read_weather(values, force=False):
    cities = city_list(values)
    if not values["ShowWeather"] or not cities:
        with _data_lock:
            _weather.clear()
        return
    if not due("weather", 20, force):
        return
    try:
        rows = sources.read_weather(cities)
        error = ""
    except sources.SourceError as exc:
        rows, error = None, str(exc)
    with _data_lock:
        if rows is not None:
            _weather[:] = rows
        _errors["weather"] = error
    bump()


def read_quakes(values, force=False):
    if not values["ShowQuakes"] and not values["QuakeMag"]:
        with _data_lock:
            _quakes.clear()
        return
    if not due("quakes", 10, force):
        return
    try:
        rows = sources.read_quakes()
        error = ""
    except sources.SourceError as exc:
        rows, error = None, str(exc)
    with _data_lock:
        if rows is not None:
            _quakes[:] = rows
        _errors["quakes"] = error
    if rows:
        check_quake_alerts(values, rows)
    bump()


def refresh_data(force=False):
    values = settings()
    for step in (read_news, read_markets, read_crypto, read_weather, read_quakes):
        if _stop_requested.is_set():
            return
        try:
            step(values, force)
        except Exception as exc:  # pragma: no cover - one source must not stop the others
            plugin.log(f"{step.__name__} failed: {exc!r}", level="error")
    save_markets()


def save_headlines():
    with _data_lock:
        payload = list(_items.values())
    try:
        write_json(HEADLINES_FILE, payload)
    except OSError as exc:
        plugin.log(f"Could not save the headlines: {exc}", level="warning")


def save_markets():
    with _data_lock:
        payload = {"quotes": _quotes, "curves": _curves, "crypto": _crypto, "weather": _weather, "quakes": _quakes,
                   "at": now()}
        payload = json.loads(json.dumps(payload))
    try:
        write_json(MARKETS_FILE, payload)
    except OSError as exc:
        plugin.log(f"Could not cache the market data: {exc}", level="warning")


def load_cache():
    """The last data, so the wall is full right after a restart."""
    with _data_lock:
        for item in read_json(HEADLINES_FILE, []) or []:
            if isinstance(item, dict) and item.get("id") and item.get("title"):
                _items[item["id"]] = item
        cached = read_json(MARKETS_FILE, {}) or {}
        _quotes.update(cached.get("quotes") or {})
        _curves.update(cached.get("curves") or {})
        _crypto[:] = cached.get("crypto") or []
        _weather[:] = cached.get("weather") or []
        _quakes[:] = cached.get("quakes") or []


def emit(event, **data):
    try:
        plugin.emit_event(event, {key: str(value) for key, value in data.items()})
    except Exception as exc:  # pragma: no cover
        plugin.log(f"Could not send the event {event}: {exc}", level="warning")


# --------------------------------------------------------------------------
# Alerts
# --------------------------------------------------------------------------

_alerts = []          # waiting alerts, best first when picked
_alert_log = []       # last alerts for the plugin page and the scene
_fired = {}           # key -> time; one alert per thing
_alert_lock = threading.Lock()

PRIORITY = {"breaking": 1, "keyword": 2, "index": 3, "rule": 4, "move": 5, "quake": 6, "bell": 7, "test": 0}


def fmt_pct(value):
    return f"{'+' if value >= 0 else '−'}{abs(value):.1f} %".replace(".", "," if settings()["Language"] == "de" else ".")


def fmt_price(value):
    text = f"{value:,.2f}" if value < 10000 else f"{value:,.0f}"
    if settings()["Language"] in ("de", "es"):
        text = text.replace(",", "_").replace(".", ",").replace("_", ".")
    return text


def raise_alert(kind, key, label, title, detail="", source="", symbol=""):
    """Queue an alert once. `key` makes it unique (per day for prices)."""
    t = now()
    with _alert_lock:
        if key in _fired:
            return False
        _fired[key] = t
        for old in [k for k, v in _fired.items() if t - v > 3 * 86400]:
            del _fired[old]
        alert = {"kind": kind, "key": key, "label": label, "title": title, "detail": detail,
                 "source": source, "symbol": symbol, "at": t}
        _alerts.append(alert)
        del _alerts[:-20]
        _alert_log.insert(0, alert)
        del _alert_log[12:]
    save_state(fired=dict(_fired))
    plugin.log(f"Alert ({kind}): {label} {title} {detail}".strip())
    emit(EVENT_ALERT, kind=kind, label=label, title=title, detail=detail, source=source, symbol=symbol)
    _wake.set()
    return True


def today_key():
    return datetime.now().strftime("%Y-%m-%d")


def check_keyword_alerts(values, fresh):
    keywords = analysis.keyword_list(values["AlertKeywords"])
    if not keywords:
        return
    for item in sorted(fresh, key=analysis.item_time):
        hit = analysis.keyword_hit(keywords, item)
        if hit:
            raise_alert("keyword", f"kw:{item['id']}", tr("SCHLAGWORT: {word}", word=hit.upper()),
                        item["title"], source=item["source"])


def check_breaking(values):
    mode = values["AlertBreaking"]
    # Right after installing, everything of the last hour looks new: not news.
    if mode == "off" or not _first_news["watching"]:
        return
    with _data_lock:
        items = list(_items.values())
    for row in analysis.breaking(items, min_sources=values["BreakingSources"]):
        if mode in (row["kind"], "both"):
            label = tr("EILMELDUNG") if row["kind"] == "marker" else tr("EILMELDUNG: {term}", term=row["term"].upper())
            detail = "" if row["kind"] == "marker" else tr("{n} Quellen melden das gerade", n=row["sources"])
            raise_alert("breaking", f"brk:{row['id']}", label, row["title"], detail, row["source"])


def check_market_alerts(values, crypto=False):
    with _data_lock:
        quotes = {q["symbol"]: q for q in (_crypto if crypto else _quotes.values())}
    if crypto:
        quotes = {q["symbol"].upper(): q for q in quotes.values()}
    day = today_key()
    for rule in analysis.parse_rules(values["AlertRules"]):
        quote = quotes.get(rule["symbol"])
        if quote and analysis.rule_hit(rule, quote):
            name = quote.get("name") or quote["symbol"]
            if rule["op"] == "move":
                detail = tr("Kurs {price} {cur} ({rule})", price=fmt_price(quote["price"]),
                            cur=quote.get("currency", ""), rule=rule["text"])
            else:
                detail = tr("Kurs {price} {cur} ({rule})", price=fmt_price(quote["price"]),
                            cur=quote.get("currency", ""), rule=rule["text"])
            raise_alert("rule", f"rule:{rule['text']}:{day}", tr("KURSALARM"),
                        f"{name} {fmt_pct(quote['pct']) if quote.get('pct') is not None else ''}".strip(),
                        detail, symbol=quote["symbol"])
    if values["MovePct"] and not crypto:
        for quote in quotes.values():
            if quote.get("kind") == "stock" and quote.get("pct") is not None and abs(quote["pct"]) >= values["MovePct"]:
                up = quote["pct"] > 0
                raise_alert("move", f"move:{quote['symbol']}:{'u' if up else 'd'}:{day}",
                            tr("KURSSPRUNG") if up else tr("KURSRUTSCH"),
                            f"{quote['name']} {fmt_pct(quote['pct'])}",
                            tr("Kurs {price} {cur}", price=fmt_price(quote["price"]), cur=quote.get("currency", "")),
                            symbol=quote["symbol"])
    index = quotes.get(values["MainIndex"].strip().upper()) if not crypto else None
    if values["IndexPct"] and index and index.get("pct") is not None and abs(index["pct"]) >= values["IndexPct"]:
        up = index["pct"] > 0
        raise_alert("index", f"index:{index['symbol']}:{'u' if up else 'd'}:{day}",
                    tr("RALLYE") if up else tr("CRASH-ALARM"),
                    f"{index['name']} {fmt_pct(index['pct'])}",
                    tr("Stand {price}", price=fmt_price(index["price"])), symbol=index["symbol"])


def check_quake_alerts(values, quakes):
    if not values["QuakeMag"]:
        return
    for quake in quakes:
        if now() - quake["at"] > 3600:
            continue
        if quake["mag"] >= values["QuakeMag"] or (quake.get("tsunami") and quake["mag"] >= 6):
            detail = tr("Tsunami-Hinweis") if quake.get("tsunami") else ""
            raise_alert("quake", f"quake:{quake['place']}:{int(quake['at'])}",
                        tr("ERDBEBEN M{mag}", mag=f"{quake['mag']:.1f}"), quake["place"], detail, "USGS")


def check_bells(values):
    if not values["Bells"] or ZoneInfo is None:
        return
    for exchange in values["Bells"]:
        name, opening, zone = presets.EXCHANGES[exchange]
        try:
            moment = datetime.now(ZoneInfo(zone))
        except Exception:  # pragma: no cover - no time zone data
            continue
        hour, minute = (int(p) for p in opening.split(":"))
        start = moment.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if moment.weekday() >= 5 or not (start - timedelta(seconds=20) <= moment < start + timedelta(minutes=3)):
            continue
        raise_alert("bell", f"bell:{exchange}:{moment.strftime('%Y-%m-%d')}", tr("BÖRSENSTART"),
                    tr("{name} eröffnet den Handel", name=name), moment.strftime("%H:%M") + " " + zone.split("/")[-1].replace("_", " "))


def restore_fired():
    stored = load_state().get("fired") or {}
    with _alert_lock:
        _fired.update({k: v for k, v in stored.items() if isinstance(v, (int, float)) and now() - v < 3 * 86400})


def next_alert():
    """The most important waiting alert; what waited ten minutes is old news."""
    t = now()
    with _alert_lock:
        _alerts[:] = [a for a in _alerts if t - a["at"] < 600]
        if not _alerts:
            return None
        _alerts.sort(key=lambda a: (PRIORITY.get(a["kind"], 9), -a["at"]))
        return _alerts.pop(0)


# --------------------------------------------------------------------------
# What the scene gets
# --------------------------------------------------------------------------

def slim_item(item):
    return {"id": item["id"], "title": item["title"], "source": item["source"], "at": analysis.item_time(item),
            "image": item.get("image") or "", "summary": (item.get("summary") or "")[:220]}


def unique_headlines(items, most):
    """The same story from several feeds once, with the first source."""
    out, seen = [], set()
    for item in items:
        key = re.sub(r"\W+", " ", item["title"].lower()).strip()
        if key in seen:
            continue
        seen.add(key)
        out.append(slim_item(item))
        if len(out) >= most:
            break
    return out


def analyse():
    values = settings()
    with _data_lock:
        key = (_version["n"], int(now() // 60))
        if _analysis["key"] == key and _analysis["result"] is not None:
            return _analysis["result"]
        items = list(_items.values())
        quotes = list(_quotes.values())
        crypto = list(_crypto)
    radar = analysis.topic_radar(items)
    items.sort(key=analysis.item_time, reverse=True)
    # Lead stories: the newest headline of each top topic, with a picture if one exists.
    leads, used = [], set()
    for row in radar[:8]:
        matches = [i for i in items if row["key"] in analysis.terms(i["title"]) and i["id"] not in used]
        if not matches:
            continue
        pick = next((i for i in matches[:6] if i.get("image")), matches[0])
        used.add(pick["id"])
        leads.append(dict(slim_item(pick), topic=row["term"], sources=row["sources"]))
    for item in items:
        if len(leads) >= 6:
            break
        if item["id"] not in used:
            used.add(item["id"])
            leads.append(dict(slim_item(item), topic="", sources=1))
    result = {
        "radar": radar,
        "breaking": analysis.breaking(items, min_sources=values["BreakingSources"]),
        "pace": analysis.news_pace(items),
        "mood": analysis.market_mood(quotes + crypto),
        "movers": analysis.movers(quotes + crypto),
        "activity": analysis.source_activity(items),
        "headlines": unique_headlines(items, 70),
        "leads": leads,
    }
    with _data_lock:
        _analysis.update(key=key, result=result)
    return result


def snapshot():
    """Everything the scene needs. Served at /api/scene."""
    values = settings()
    result = analyse()
    with _takeover_lock:
        focus = _takeover["focus"] if (_takeover["handle"] is not None or _takeover["asking"]) else None
    order = [s for s, _, _ in watch_list(values)]
    with _data_lock:
        markets = [_quotes[s] for s in order if s in _quotes]
        crypto = list(_crypto)
        weather = {w["city"]: w for w in _weather}
        quakes = list(_quakes) if values["ShowQuakes"] else []
        feeds_ok = sum(1 for f in _feeds.values() if f.get("ok"))
        version_n = _version["n"]
    clocks = [dict(c, **{k: v for k, v in (weather.get(c["name"]) or {}).items() if k != "city"})
              for c in city_list(values)]
    with _alert_lock:
        recent_alerts = [dict(a) for a in _alert_log[:6]]
    return {"version": version_n, "at": now(), "lang": values["Language"], "look": values["Look"],
            "speed": values["TickerSpeed"], "images": values["ShowImages"], "region": values["Region"],
            "clocks": clocks, "markets": markets, "crypto": crypto, "quakes": quakes,
            "feeds": {"ok": feeds_ok, "total": len(feed_list(values))},
            "focus": focus, "alerts": recent_alerts, **result}


# --------------------------------------------------------------------------
# Playlists: the takeover playlist and, if wanted, one for the owner
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = "Ticker Wall (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Played by the Ticker Wall plugin when it takes over the screen. Stays "
                                 "switched off so it doesn't end up in the Quick Mix. The plugin creates it "
                                 "again if it is deleted.")
OWNER_PLAYLIST_NAME = "Ticker Wall"
OWNER_PLAYLIST_DESCRIPTION = "Created by the Ticker Wall plugin. Switch off, schedule or delete like any playlist."
TAKEOVER_ITEM_SECONDS = 6 * 3600  # the plugin ends the display long before
SCENE_SECONDS = 120               # recommendedDurationSec in scene.dynamic

_playlists = {"at": 0.0, "takeoverId": None, "note": "", "ownerNote": ""}
_playlist_lock = threading.Lock()


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    """Does anything hold the screen? Playlists are only created while nothing
    does: the frame rebuilds the Quick Mix after a takeover, and a playlist
    created meanwhile changes what it restores."""
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError as exc:
        return exc.status != 404
    return bool(status.get("active"))


def create_playlist(name, description, seconds, enabled):
    created = engine_call("POST", "/playlists", {"name": name, "description": description}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=name))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": seconds})
    if not enabled:
        engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    return playlist_id


def ensure_takeover_playlist():
    """A takeover plays a playlist, not a single scene. So: the scene alone,
    six hours, switched off."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if i.get("dynamicSceneId") == _scene["dbId"]]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    playlist_id = create_playlist(TAKEOVER_PLAYLIST_NAME, TAKEOVER_PLAYLIST_DESCRIPTION,
                                  TAKEOVER_ITEM_SECONDS, enabled=False)
    save_state(takeoverPlaylistId=playlist_id)
    plugin.log(f"Created playlist {TAKEOVER_PLAYLIST_NAME} ({playlist_id}).")
    return playlist_id


def maintain_owner_playlist(values):
    state = load_state()
    playlist_id = state.get("ownerPlaylistId")
    if playlist_id:
        if get_playlist(playlist_id) is None:
            save_state(ownerPlaylistId=None, ownerPlaylistDeleted=bool(values["MakePlaylist"]))
            if values["MakePlaylist"]:
                save_settings({"MakePlaylist": False})
                plugin.log("The Ticker Wall playlist was deleted; it is not created again.")
        return ""
    if not values["MakePlaylist"]:
        return ""
    if screen_held():
        return tr("Wartet, bis der Bildschirm wieder frei ist.")
    playlist_id = create_playlist(OWNER_PLAYLIST_NAME, OWNER_PLAYLIST_DESCRIPTION, SCENE_SECONDS, enabled=True)
    save_state(ownerPlaylistId=playlist_id, ownerPlaylistDeleted=False)
    plugin.log(f"Created playlist {OWNER_PLAYLIST_NAME} ({playlist_id}), switched on.")
    return ""


def maintain_playlists(force=False):
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        find_scene()
        if _scene["dbId"] is None:
            _playlists.update(note=_scene["note"], ownerNote=_scene["note"])
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc)
            plugin.log(_playlists["note"], level="warning")
        try:
            _playlists["ownerNote"] = maintain_owner_playlist(settings())
        except EngineError as exc:
            _playlists["ownerNote"] = tr("Konnte die Playlist Ticker Wall nicht pflegen: {exc}", exc=exc)


def owner_playlist_text(values, state):
    if values["MakePlaylist"]:
        if state.get("ownerPlaylistId"):
            return tr("Angelegt: die Playlist Ticker Wall steht unter Playlists.")
        return _playlists["ownerNote"] or tr("Noch nicht angelegt; das passiert innerhalb einer Minute.")
    if state.get("ownerPlaylistDeleted"):
        return tr("Die Playlist wurde gelöscht, deshalb steht das wieder auf Nein.")
    if state.get("ownerPlaylistId"):
        return tr("Die früher angelegte Playlist steht noch unter Playlists; das Plugin pflegt sie nicht mehr.")
    return ""


# --------------------------------------------------------------------------
# Taking over the screen and handing it back
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
ENDED_REASON = {"released": "cancelled", "expired": "expired", "failed": "failed", "preempted": "displaced"}

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "reason": None, "since": None, "until": None, "started": False,
             "token": 0, "note": "", "focus": None, "asking": False}
_schedule = {"nextAt": 0.0, "lastAt": 0.0, "alertAt": 0.0}
_stop_requested = threading.Event()
_wake = threading.Event()


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform") or {}
    except EngineError:
        return True  # can't tell: the attempt itself will say
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Ticker Wall ist auf der Plugins-Seite ausgeschaltet.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Ticker Wall auf der Plugins-Seite aus, deshalb kann es "
                  "den Bildschirm nicht übernehmen.")
    return ""


def display_is_off():
    """Only true when the frame says the screen is off. Ticker Wall never wakes a screen."""
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def scene_turn_on_screen():
    """Is the scene playing as a normal playlist item right now? A takeover
    on top leaves the frame stopped afterwards (known bug), and the stats are
    on screen anyway."""
    if _scene["dbId"] is None:
        return False
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", read_timeout=5) or {}
    except EngineError:
        return False
    item = status.get("currentItem") or {}
    return bool(status.get("isRunning") and item.get("dynamicSceneId") == _scene["dbId"]
                and not same_id(status.get("activePlaylistId"), _playlists["takeoverId"]))


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        plugin.log(text)
    return False


def _on_session_state(handle_or_state):
    """The SDK calls this with the handle, not with the new state."""
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        started = _takeover["started"]
        _takeover.update(handle=None, reason=None, since=None, until=None, started=False, focus=None,
                         note=tr("Der Rahmen hat die Anzeige beendet ({state}).", state=new_state))
    plugin.log(f"The frame ended Ticker Wall: {new_state}.")
    if started:
        emit(EVENT_ENDED, reason=ENDED_REASON.get(new_state, new_state))
    publish_status()
    threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason, token=None):
    """Hand the screen back. Safe to call more than once."""
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        started = _takeover["started"]
        _takeover.update(handle=None, reason=None, since=None, until=None, started=False, focus=None, note="")
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:
        plugin.log(f"Could not hand the screen back: {exc}", level="warning")
    plugin.log(f"Screen handed back ({reason}).")
    if started:
        emit(EVENT_ENDED, reason=reason)
    publish_status()
    if reason != "stopped":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def _release_after(seconds, token):
    if _stop_requested.wait(max(1, int(seconds))):
        return
    end_takeover("done", token)


def show_scene(reason="show", seconds=None, focus=None):
    """Put the scene over everything for `seconds`. True if the frame gave up the screen."""
    if _takeover["handle"] is not None:
        return _note(tr("Ticker Wall ist schon auf dem Bildschirm."))
    if not takeover_supported():
        return _note(tr("Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen."))
    if _scene["dbId"] is None:
        find_scene()
    if _scene["dbId"] is None or _scene["note"]:
        return _note(_scene["note"] or tr("Die Szene Ticker Wall wurde nicht gefunden."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("Die Takeover-Playlist ist noch nicht angelegt."))
    if scene_turn_on_screen():
        return _note(tr("Ticker Wall läuft gerade in deiner Playlist; die Anzeige bleibt so."))
    if display_is_off():
        return _note(tr("Der Bildschirm ist aus. Ticker Wall weckt ihn nicht."))
    seconds = int(seconds or settings()["ShowForSeconds"])
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             "overlay": {"enabled": False}}
    # The scene loads and polls before acquire returns: set the focus first.
    with _takeover_lock:
        _takeover.update(focus=focus, asking=True)
    try:
        _leftover["askedAt"] = time.time()
        handle = plugin.acquire_display_session(
            session_key=reason, state=state, display_name=DISPLAY_NAME,
            # A bit longer than wanted: the timer below is the proper end, the
            # engine limit only matters if the plugin dies.
            max_duration_seconds=seconds + 10, wake_if_off=False)
    except Exception as exc:
        handle = None
        error = exc
    else:
        error = None
    finally:
        with _takeover_lock:
            _takeover["asking"] = False
    if error is not None:
        return _note(tr("Konnte Ticker Wall nicht anzeigen: {exc}", exc=error))
    if handle is None:
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    t = now()
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, reason=reason, since=t, until=t + seconds, started=False,
                         note="", focus=focus)
    try:
        handle.on_state_change(_on_session_state)
    except Exception:
        pass
    try:
        if not handle.wait_until_active(timeout=10):
            end_takeover("failed", token)
            return _note(tr("Der Rahmen hat Ticker Wall nicht rechtzeitig angezeigt."))
    except Exception as exc:
        end_takeover("failed", token)
        return _note(tr("Konnte Ticker Wall nicht anzeigen: {exc}", exc=exc))
    with _takeover_lock:
        if _takeover["token"] != token or _takeover["handle"] is None:
            return False
        _takeover["started"] = True
    emit(EVENT_STARTED, reason=reason)
    plugin.log(f"Ticker Wall on screen for {seconds} seconds ({reason}).")
    publish_status()
    threading.Thread(target=_release_after, args=(seconds, token),
                     name=f"{PLUGIN_ID}-timer", daemon=True).start()
    return True


def cancel_scene():
    if not end_takeover("cancelled"):
        _note(tr("Ticker Wall hatte den Bildschirm nicht."))


def toggle_scene():
    if _takeover["handle"] is not None:
        cancel_scene()
    else:
        show_scene("show")


_action_lock = threading.Lock()


def run_action(name):
    """Show, Cancel and Toggle answer right away and work in a thread."""
    work = {"show": lambda: show_scene("show"), "cancel": cancel_scene, "toggle": toggle_scene}[name]
    showing = _takeover["handle"] is not None
    asking, returning = tr("Bitte den Rahmen um den Bildschirm."), tr("Gebe den Bildschirm zurück.")
    message = {"show": asking, "cancel": returning, "toggle": returning if showing else asking}[name]

    def run():
        with _action_lock:
            try:
                work()
            except Exception as exc:  # pragma: no cover
                _note(tr("{name} hat nicht geklappt: {exc}", name=name, exc=exc))
    threading.Thread(target=run, name=f"{PLUGIN_ID}-{name}", daemon=True).start()
    return {"success": True, "message": message}


# ---- Takeover playlist that keeps running after the release ---------------
# If nothing played before a takeover, the engine doesn't restore that
# "nothing" and the takeover playlist keeps running (Jan's frame, 2026-10-24).
# Every round stops it with POST /slideshow/stop: only when it runs, nobody
# holds the screen and the plugin didn't just ask for it itself.
_leftover = {"askedAt": 0.0, "failed": False}


def stop_leftover_takeover():
    try:
        playlist_id = _playlists["takeoverId"]
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status", read_timeout=5) or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status", read_timeout=5) or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop", read_timeout=10)
    except Exception as exc:  # noqa: BLE001 - must never stop the loop
        if not _leftover["failed"]:
            plugin.log(f"The takeover playlist kept running and could not be stopped: {exc}", level="warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    plugin.log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def check_playback_resumed():
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log,
                                                    stop_event=_stop_requested)
        if outcome == "not-requested":
            save_state(playbackStalled="")
            return
    elif _stop_requested.wait(12):
        return
    if _stop_requested.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
    except EngineError:
        return
    if status.get("isRunning") or _takeover["handle"] is not None:
        save_state(playbackStalled="")
        return
    message = tr("Der Rahmen ist nach Ticker Wall nicht zu deiner Playlist zurückgekehrt. Starte sie auf "
                 "der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix "
                 "passiert das nicht.")
    save_state(playbackStalled=message)
    plugin.log(message, level="warning")


# ---- The schedule -----------------------------------------------------------

def in_active_hours(values, moment=None):
    hour = (moment or datetime.now()).hour
    start, end = values["ActiveFrom"], values["ActiveTo"]
    if start == end:
        return True
    if start < end:
        return start <= hour < end
    return hour >= start or hour < end  # past midnight, e.g. 18 to 2


def auto_wanted(values):
    if values["AutoMode"] == "off":
        return False, tr("Regelmäßige Anzeige ist aus.")
    if not in_active_hours(values):
        return False, tr("Außerhalb von {start}–{end} Uhr.", start=values["ActiveFrom"], end=values["ActiveTo"])
    return True, ""


_auto = {"note": ""}



def decide_takeover():
    values = settings()
    if _takeover["handle"] is not None:
        with _takeover_lock:
            handle = _takeover["handle"]
        if handle is not None and str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        # Already on screen: a new alert simply moves to the front.
        alert = next_alert()
        if alert is not None:
            with _takeover_lock:
                if _takeover["handle"] is not None:
                    _takeover["focus"] = alert
        return
    t = now()
    cooldown = values["CooldownMinutes"] * 60
    if t - _schedule["alertAt"] >= cooldown or any(a["kind"] == "test" for a in _alerts):
        alert = next_alert()
        if alert is not None:
            if not in_active_hours(values) and alert["kind"] != "test":
                plugin.log(f"Alert outside {values['ActiveFrom']}-{values['ActiveTo']} h, not shown: {alert['label']}")
            elif show_scene("alert", values["AlertSeconds"], focus=alert):
                _schedule["lastAt"] = _schedule["alertAt"] = t
                return
    wanted, why = auto_wanted(values)
    _auto["note"] = why
    if not wanted:
        _schedule["nextAt"] = 0.0
        return
    if not _schedule["nextAt"]:
        _schedule["nextAt"] = max(t + 60, _schedule["lastAt"] + values["EveryMinutes"] * 60)
    if t < _schedule["nextAt"]:
        return
    if show_scene("schedule"):
        _schedule["lastAt"] = t
        _schedule["nextAt"] = t + values["EveryMinutes"] * 60
    else:
        _schedule["nextAt"] = t + 120



# --------------------------------------------------------------------------
# Overlay text
# --------------------------------------------------------------------------

_overlay = {"text": None}


def status_line():
    result = analyse()
    with _takeover_lock:
        focus = _takeover["focus"] if _takeover["handle"] is not None else None
    if focus:
        return f"{focus['label']}: {focus['title']}"
    if not result["headlines"]:
        return tr("Noch keine Schlagzeilen")
    top = result["leads"][0] if result["leads"] else result["headlines"][0]
    return f"{top['source']}: {top['title']}"


def publish_status():
    try:
        text = status_line()
    except Exception:  # pragma: no cover
        return
    if _overlay["text"] == text:
        return
    _overlay["text"] = text
    try:
        plugin.update_overlay_text(SERVICE_STATUS, text)
    except Exception:
        pass


# --------------------------------------------------------------------------
# The loop
# --------------------------------------------------------------------------

TICK_SECONDS = 15
_loop = {"lastCheckAt": None, "lastError": "", "force": False}
_data_running = threading.Lock()


def data_round(force):
    """Reading dozens of feeds and symbols takes a while: own thread."""
    if not _data_running.acquire(blocking=False):
        return
    try:
        refresh_data(force)
        check_breaking(settings())
    except Exception as exc:  # pragma: no cover
        _loop["lastError"] = str(exc)
        plugin.log(f"Reading the sources failed: {exc!r}", level="error")
    finally:
        _data_running.release()
    publish_status()


def tick(force=False):
    try:
        stop_leftover_takeover()
        maintain_playlists(force)
        threading.Thread(target=data_round, args=(force,), name=f"{PLUGIN_ID}-data", daemon=True).start()
        check_bells(settings())
        decide_takeover()
        _loop.update(lastCheckAt=local_text(now()), lastError="")
    except Exception as exc:  # pragma: no cover - the loop must keep running
        _loop["lastError"] = str(exc)
        plugin.log(f"Round failed: {exc}", level="error")
    publish_status()


def main_loop():
    _stop_requested.wait(3)
    while not _stop_requested.is_set():
        _wake.clear()
        force, _loop["force"] = _loop["force"], False
        tick(force)
        _wake.wait(TICK_SECONDS)


def check_now():
    _loop["force"] = True
    _wake.set()
    return {"success": True, "message": tr("Lese alle Quellen jetzt neu.")}


def test_alert():
    raise_alert("test", f"test:{now()}", tr("TESTALARM"), tr("So sieht ein Alarm auf der Ticker Wall aus"),
                tr("Ausgelöst auf der Plugin-Seite"), "Ticker Wall")
    return {"success": True, "message": tr("Testalarm ausgelöst.")}


DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


def state_payload():
    values = settings()
    state = load_state()
    with _takeover_lock:
        takeover = {"active": _takeover["handle"] is not None, "reason": _takeover["reason"],
                    "until": local_text(_takeover["until"]), "note": _takeover["note"]}
    with _data_lock:
        feeds = [{"name": n, "ok": bool(f.get("ok")), "count": f.get("count") or 0, "error": f.get("error") or "",
                  "at": local_text(f.get("at"))} for n, f in _feeds.items()]
        quote_errors = dict(_quote_errors)
        quotes_ok = len(_quotes)
        headlines = len(_items)
        errors = {k: v for k, v in _errors.items() if v}
    with _alert_lock:
        alerts = [{"label": a["label"], "title": a["title"], "at": local_text(a["at"])} for a in _alert_log[:8]]
    result = analyse()
    return {
        "success": True,
        "version": version(),
        "settings": dict(values, FinnhubKey=""),
        "finnhubKey": {"set": bool(values["FinnhubKey"]),
                       "hint": ("…" + values["FinnhubKey"][-4:]) if len(values["FinnhubKey"]) >= 8 else ""},
        "presets": {r: presets.preset(r) for r in presets.REGIONS},
        "exchanges": {k: v[0] for k, v in presets.EXCHANGES.items()},
        "feeds": feeds,
        "quotesOk": quotes_ok,
        "quoteErrors": quote_errors,
        "sourceErrors": errors,
        "headlines": headlines,
        "radar": [r["term"] for r in result["radar"][:8]],
        "rules": [r["text"] for r in analysis.parse_rules(values["AlertRules"])],
        "alerts": alerts,
        "status": status_line(),
        "scene": {"found": _scene["dbId"] is not None, "note": _scene["note"]},
        "takeover": takeover,
        "permission": takeover_permission_note(),
        "next": local_text(_schedule["nextAt"]) if _schedule["nextAt"] else "",
        "autoNote": _auto["note"],
        "ownerPlaylist": owner_playlist_text(values, state),
        "lastCheckAt": _loop["lastCheckAt"],
        "lastError": _loop["lastError"] or state.get("playbackStalled") or "",
        "theme": {"id": theme_id()},
    }


def settings_saved(changed):
    touched = set(changed)
    if "MakePlaylist" in touched:
        if settings()["MakePlaylist"]:
            save_state(ownerPlaylistDeleted=False)
        threading.Thread(target=maintain_playlists, kwargs={"force": True}, daemon=True).start()
    if "FinnhubKey" in touched:
        _market_note["until"] = 0.0
    for name, sources_due in (("Feeds", "news"), ("NewsMinutes", "news"), ("Watchlist", "markets"), ("FinnhubKey", "markets"),
                              ("MarketMinutes", "markets"), ("Coins", "crypto"), ("CoinCurrency", "crypto"),
                              ("Cities", "weather"), ("ShowWeather", "weather"), ("ShowQuakes", "quakes"),
                              ("QuakeMag", "quakes")):
        if name in touched:
            _due.pop(sources_due, None)
    if touched & {"AutoMode", "EveryMinutes", "ActiveFrom", "ActiveTo"}:
        _schedule["nextAt"] = 0.0
    bump()
    publish_status()
    _wake.set()


def apply_region(region):
    if region not in presets.REGIONS:
        return {"success": False, "error": "Unknown region"}
    changes = dict(presets.preset(region), Region=region)
    changed = save_settings(changes)
    if changed:
        settings_saved(changed)
    return {"success": True, "changed": changed}


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, because the WebUI proxy keeps connections open.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """The plugin log is the log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # The scene comes from the engine's port, this page via :8003.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        """Read the whole body: unread bytes on an open connection would
        become the start of the next request."""
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(snapshot(), cors=True)
                return
            self._json({"success": False, "error": "Not found"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Could not read a plugin file: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                # An empty key field means "keep", not "delete".
                if "FinnhubKey" in body and not str(body.get("FinnhubKey") or "").strip():
                    body.pop("FinnhubKey")
                changed = save_settings(body)
                if changed:
                    settings_saved(changed)
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/remove-key":
                save_settings({"FinnhubKey": ""})
                settings_saved(["FinnhubKey"])
                self._json({"success": True})
                return
            if path == "/api/region":
                self._json(apply_region(str(self._body().get("region") or "")))
                return
            if path == "/api/test-alert":
                self._json(test_alert())
                return
            if path == "/api/refresh":
                self._json(check_now())
                return
            if path in ("/api/show", "/api/cancel", "/api/toggle"):
                self._json(run_action(path.rsplit("/", 1)[-1]))
                return
            self._json({"success": False, "error": "Not found"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """The page on loopback; tell the host the port actually bound."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin page at {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    ensure_dirs()
    plugin.log(f"Starting {PLUGIN_ID} {version()}")
    load_cache()
    restore_fired()

    # Everything the host can call must exist before ready().
    plugin.on_action("refresh", lambda _context=None: check_now())
    plugin.on_action("show", lambda _context=None: run_action("show"))
    plugin.on_action("cancel", lambda _context=None: run_action("cancel"))
    plugin.on_action("toggle", lambda _context=None: run_action("toggle"))
    plugin.on_action("test-alert", lambda _context=None: test_alert())

    start_studio()
    publish_status()
    plugin.connect_sse()
    plugin.ready()

    threading.Thread(target=main_loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    end_takeover("stopped")
    save_headlines()
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    plugin.log(f"{PLUGIN_ID} stopped.")


if __name__ == "__main__":
    main()
