/* Calendar Page – die Szene.
 *
 * Ein Wandkalender-Blatt mit Ringbindung: links (hochkant oben) ein Foto aus
 * demselben Monat in einem früheren Jahr, im Wechsel eins je Jahr, mit Datum,
 * Ort und „vor N Jahren“; rechts der Monat mit Feiertagen (rot), Schulferien
 * (Band unter den Tagen), Terminen (Punkte in der Farbe des Kalenders) und
 * Geburtstagen (rundes Gesicht im Tag); darunter, was als Nächstes kommt.
 * Hat heute jemand Geburtstag, steht ein Gruß mit Foto auf dem Bild.
 * Die Daten kommen vom Plugin CalendarPage über den Proxy der Weboberfläche.
 *
 * ?plugin=<url> nimmt ein anderes Plugin (Tests), ?lang=, ?month=YYYY-MM,
 * ?style=paper|linen|night, ?portrait=1, ?still=1, ?focus=month|birthday, ?photo=N.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "CalendarPage";
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set([
    `${location.protocol}//${location.hostname}:8003${advanced}`,
    `${location.protocol}//${location.hostname}${advanced}`,
    `${location.origin}${advanced}`,
  ])];
  // Kommt die Szene über Port 80/443 (RemoteFrame, Web Login), zuerst denselben Ursprung fragen.
  if (!params.get("plugin") && (location.port === "" || location.port === "80" || location.port === "443")) {
    pluginBases.sort((a, b) => (b.startsWith(location.origin) ? 1 : 0) - (a.startsWith(location.origin) ? 1 : 0));
  }
  let baseIndex = 0;
  const base = () => pluginBases[baseIndex];

  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const TEXT = {
    de: {
      upcoming: "Demnächst", today: "Heute", tomorrow: "Morgen", allDay: "ganztägig",
      ago: "vor {n} Jahren", ago1: "vor einem Jahr", ago0: "dieses Jahr",
      bdTitle: "Alles Gute, {name}!", bdAge: "{n} Jahre heute", bdNoAge: "hat heute Geburtstag",
      bdList: "{name} wird {n}", bdListNoAge: "{name} hat Geburtstag",
      schoolUntil: "bis {date}", schoolFrom: "{name}", schoolLegend: "Schulferien",
      nothing: "In den nächsten {n} Tagen steht nichts an.",
      busyTitle: "Einen Moment …", busy: "Die Fotos werden gelesen.",
      offline: "Calendar Page antwortet nicht", offlineText: "Läuft das Plugin? Schau auf der Plugins-Seite nach.",
    },
    en: {
      upcoming: "Coming up", today: "Today", tomorrow: "Tomorrow", allDay: "all day",
      ago: "{n} years ago", ago1: "a year ago", ago0: "this year",
      bdTitle: "Happy birthday, {name}!", bdAge: "{n} today", bdNoAge: "has a birthday today",
      bdList: "{name} turns {n}", bdListNoAge: "{name}'s birthday",
      schoolUntil: "until {date}", schoolFrom: "{name}", schoolLegend: "School holidays",
      nothing: "Nothing coming up in the next {n} days.",
      busyTitle: "One moment …", busy: "Reading the photos.",
      offline: "Calendar Page does not answer", offlineText: "Is the plugin running? Have a look at the Plugins page.",
    },
    es: {
      upcoming: "Próximamente", today: "Hoy", tomorrow: "Mañana", allDay: "todo el día",
      ago: "hace {n} años", ago1: "hace un año", ago0: "este año",
      bdTitle: "¡Feliz cumpleaños, {name}!", bdAge: "cumple {n} hoy", bdNoAge: "cumple años hoy",
      bdList: "{name} cumple {n}", bdListNoAge: "cumpleaños de {name}",
      schoolUntil: "hasta el {date}", schoolFrom: "{name}", schoolLegend: "Vacaciones escolares",
      nothing: "Nada previsto en los próximos {n} días.",
      busyTitle: "Un momento …", busy: "Leyendo las fotos.",
      offline: "Calendar Page no responde", offlineText: "¿Está en marcha el plugin? Mira la página de plugins.",
    },
  };

  const el = (id) => document.getElementById(id);
  const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const still = params.get("still") === "1";
  const state = { data: null, key: "", photoKey: "", photos: [], index: -1, timer: 0, failures: 0, lang: "en", first: true };

  let readySent = false;
  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(() => { if (!readySent) ready(); }, 8000);

  function report(text) {
    try { fetch(`${base()}api/report?m=${encodeURIComponent(String(text).slice(0, 200))}`, { cache: "no-store" }).catch(() => {}); } catch (_) { /* egal */ }
  }
  window.addEventListener("error", (event) => report(`JS: ${event.message} @${event.lineno}`));

  function L() { return TEXT[state.lang] || TEXT.en; }
  function t(key, values = {}) {
    return String(L()[key] ?? TEXT.en[key] ?? key).replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
  }
  const locale = () => LOCALES[state.lang] || "en-GB";
  const parseDay = (iso) => new Date(`${iso.slice(0, 10)}T12:00:00`);
  const isoDay = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  const addDays = (iso, n) => { const d = parseDay(iso); d.setDate(d.getDate() + n); return isoDay(d); };

  // ------------------------------------------------------------ Größe

  function layout() {
    const w = window.innerWidth, h = window.innerHeight;
    const portrait = params.get("portrait") === "1" || h > w * 1.05;
    document.documentElement.style.setProperty("--u", `${Math.min(w, h) / 100}px`);
    document.body.classList.toggle("portrait", portrait);
    buildRings();
    if (state.data) fitGrid();
  }
  window.addEventListener("resize", layout);

  function buildRings() {
    const box = el("rings");
    const u = Math.min(window.innerWidth, window.innerHeight) / 100;
    const width = box.clientWidth || window.innerWidth;
    const count = Math.max(8, Math.round(width / (u * 5.2)));
    if (box.childElementCount === count) return;
    box.replaceChildren();
    for (let i = 0; i < count; i++) {
      const ring = document.createElement("i");
      ring.className = "ring";
      if (Math.abs(i - (count - 1) / 2) < 1.6) ring.classList.add("gap");    // Platz für den Aufhänger
      box.append(ring);
    }
  }

  // ------------------------------------------------------------ Daten

  async function load() {
    const month = params.get("month");
    const query = month ? `?month=${encodeURIComponent(month)}` : "";
    for (let attempt = 0; attempt < pluginBases.length; attempt++) {
      try {
        // Ohne Zeitlimit blieb das Blatt leer, wenn die Anfrage hing (Jan, 15.11.2026).
        const abort = new AbortController();
        const timer = setTimeout(() => abort.abort(), 12000);
        let response;
        try {
          response = await fetch(`${base()}api/scene${query}`, { cache: "no-store", signal: abort.signal });
        } finally {
          clearTimeout(timer);
        }
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();
        state.failures = 0;
        return data;
      } catch (error) {
        if (pluginBases.length > 1 && !state.data) baseIndex = (baseIndex + 1) % pluginBases.length;
        else break;
      }
    }
    state.failures++;
    return null;
  }

  const CACHE_KEY = "calendar-page-last";
  function remember(data) {
    try { localStorage.setItem(CACHE_KEY, JSON.stringify(data)); } catch (_) { /* egal */ }
  }
  // Ohne Antwort vom Plugin trotzdem ein Blatt zeigen: das letzte bekannte (gleicher
  // Monat) oder nur den Kalender dieses Monats.
  function fallbackData() {
    const now = new Date();
    const today = isoDay(now);
    const month = params.get("month") || today.slice(0, 7);
    try {
      const old = JSON.parse(localStorage.getItem(CACHE_KEY) || "null");
      if (old && old.month === month && old.settings) return Object.assign(old, { today, photos: [], offline: true });
    } catch (_) { /* egal */ }
    const first = new Date(Number(month.slice(0, 4)), Number(month.slice(5, 7)) - 1, 1);
    const last = new Date(first.getFullYear(), first.getMonth() + 1, 0);
    const guess = (params.get("lang") || navigator.language || "en").slice(0, 2);
    return {
      offline: true, today, month, first: isoDay(first), last: isoDay(last), until: isoDay(last),
      settings: { Language: ["de", "en", "es"].includes(guess) ? guess : "en", Style: "paper", WeekStart: "mon",
                  UpcomingDays: 14, ShowTitles: true, ShowHolidays: true, ShowSchool: true, Animate: true },
      photos: [], holidays: [], school: [], events: [], birthdays: [],
    };
  }

  async function tick() {
    let data = await load();
    if (!data) {
      if (!state.data) {
        data = fallbackData();
      } else {
        if (state.failures > 3) showMessage(t("offline"), t("offlineText"));
        ready();
        setTimeout(tick, 15000);
        return;
      }
    } else {
      remember(data);
    }
    const first = !state.data;
    state.data = data;
    state.lang = params.get("lang") || data.settings.Language || "en";
    document.documentElement.lang = state.lang;
    const style = params.get("style") || data.settings.Style || "paper";
    document.body.className = document.body.className.replace(/\bstyle-\S+/g, "").trim() + ` style-${style}`;
    document.body.classList.toggle("animate", data.settings.Animate !== false && !still);
    const focus = params.get("focus") || data.focus || "";
    document.body.classList.toggle("focus-birthday", focus === "birthday");
    if (data.offline) {
      if (state.failures > 3) showMessage(t("offline"), t("offlineText"));
    } else {
      hideMessage();
    }
    const key = JSON.stringify([data.today, data.month, data.settings, data.holidays, data.school, data.events, data.birthdays, state.lang]);
    if (key !== state.key) {
      state.key = key;
      renderCalendar(data);
    }
    const photoKey = JSON.stringify([data.month, data.photos.map((p) => p.id), state.lang]);
    if (photoKey !== state.photoKey) {
      state.photoKey = photoKey;
      setPhotos(data.photos);
    }
    renderBirthday(data);
    if (first && !state.introDone) { state.introDone = true; intro(focus, data); }
    if (data.busy && !data.photos.length && !data.indexed) showMessage(t("busyTitle"), t("busy"));
    if (data.offline) {
      state.data = null;           // nächste Antwort wie das erste Mal behandeln
      ready();
      setTimeout(tick, 15000);
      return;
    }
    setTimeout(tick, data.busy ? 10000 : 60000);
  }

  function showMessage(title, text) {
    el("msgTitle").textContent = title;
    el("msgText").textContent = text;
    el("message").hidden = false;
  }
  function hideMessage() { el("message").hidden = true; }

  // ------------------------------------------------------------ Umblättern

  function intro(focus, data) {
    const sheet = el("sheet");
    if (still || data.settings.Animate === false) return;
    if (focus === "month" || params.get("focus") === "month") {
      // Das alte Blatt fällt, das neue klappt herunter.
      const rect = sheet.getBoundingClientRect();
      const old = document.createElement("div");
      old.className = "oldpage";
      Object.assign(old.style, { left: `${rect.left}px`, top: `${rect.top}px`, width: `${rect.width}px`, height: `${rect.height}px` });
      const prev = parseDay(data.first); prev.setDate(0);
      old.textContent = prev.toLocaleDateString(locale(), { month: "long" });
      document.body.append(old);
      setTimeout(() => old.remove(), 2600);
      sheet.classList.add("flipbig");
    } else {
      sheet.classList.add("flip");
    }
  }

  // ------------------------------------------------------------ Kalender

  function weekdayNames(sundayFirst) {
    const names = [];
    const monday = new Date(2024, 0, 1, 12);          // ein Montag
    for (let i = 0; i < 7; i++) {
      const d = new Date(monday); d.setDate(monday.getDate() + i);
      let name = d.toLocaleDateString(locale(), { weekday: "short" }).replace(".", "");
      if (state.lang !== "en") name = name.slice(0, 2);
      names.push({ name, weekend: i >= 5 });
    }
    if (sundayFirst) names.unshift(names.pop());
    return names;
  }

  function dayInfo(data) {
    const info = {};
    const at = (iso) => (info[iso] = info[iso] || { holidays: [], school: [], events: [], birthdays: [] });
    for (const h of data.holidays) at(h.date).holidays.push(h);
    for (const s of data.school) {
      for (let d = s.start; d <= s.end && d <= data.until; d = addDays(d, 1)) {
        if (d >= data.first) at(d).school.push(s);
      }
    }
    for (const e of data.events) {
      const startDay = e.start.slice(0, 10);
      let endDay = (e.end || e.start).slice(0, 10);
      if (e.allDay && endDay > startDay) endDay = addDays(endDay, -1);         // ICS: Ende exklusiv
      if (!e.allDay && e.end && e.end.slice(11) === "00:00" && endDay > startDay) endDay = addDays(endDay, -1);
      for (let d = startDay; d <= endDay && d <= data.until; d = addDays(d, 1)) {
        if (d >= data.first) at(d).events.push(e);
        if (d > addDays(startDay, 62)) break;
      }
    }
    for (const b of data.birthdays) at(b.date).birthdays.push(b);
    return info;
  }

  function faceStyle(b) {
    return b.face ? ` style="background-image:url('${base()}api/face?f=${encodeURIComponent(b.face)}')"` : "";
  }

  function renderCalendar(data) {
    const firstDay = parseDay(data.first);
    el("monthName").textContent = firstDay.toLocaleDateString(locale(), { month: "long" });
    el("yearNum").textContent = String(firstDay.getFullYear());
    const sundayFirst = data.settings.WeekStart === "sun";
    const info = dayInfo(data);
    state.info = info;
    const grid = el("grid");
    const cells = [];
    for (const wd of weekdayNames(sundayFirst)) cells.push(`<div class="wd${wd.weekend ? " we" : ""}">${esc(wd.name)}</div>`);
    const offset = (firstDay.getDay() + (sundayFirst ? 0 : 6)) % 7;
    const days = parseDay(data.last).getDate();
    const rows = Math.ceil((offset + days) / 7);
    state.rows = rows;
    for (let i = 0; i < offset; i++) cells.push('<div class="day out"></div>');
    for (let n = 1; n <= days; n++) {
      const iso = `${data.month}-${String(n).padStart(2, "0")}`;
      const d = parseDay(iso);
      const dow = d.getDay();
      const day = info[iso] || { holidays: [], school: [], events: [], birthdays: [] };
      const cls = ["day"];
      if (dow === 0 || dow === 6) cls.push("we");
      if (day.holidays.length) cls.push("hol");
      if (iso === data.today) cls.push("today");
      if (iso < data.today) cls.push("past");
      if (day.school.length) {
        cls.push("school");
        const prev = info[addDays(iso, -1)], next = info[addDays(iso, 1)];
        const col = (offset + n - 1) % 7;
        if (!prev || !prev.school.length || col === 0 || n === 1) cls.push("s-first");
        if (!next || !next.school.length || col === 6 || n === days) cls.push("s-last");
      }
      const marks = [];
      for (const b of day.birthdays.slice(0, 2)) marks.push(`<span class="face"${faceStyle(b)}>${b.face ? "" : "🎂"}</span>`);
      const colors = [];
      for (const e of day.events) {
        if (e.birthday && !day.birthdays.length) { if (!marks.length) marks.push('<span class="face">🎂</span>'); continue; }
        if (!e.birthday && !colors.includes(e.color) && colors.length < 3) colors.push(e.color);
      }
      for (const c of colors) marks.push(`<span class="dot" style="--c:${esc(c)}"></span>`);
      const extra = day.events.filter((e) => !e.birthday).length - colors.length;
      if (extra > 0 && day.events.length > 3) marks.push(`<span class="more">+${day.events.length - colors.length}</span>`);
      const hname = day.holidays.length ? `<div class="hname">${esc(day.holidays[0].name)}</div>` : "";
      cells.push(`<div class="${cls.join(" ")}" data-day="${iso}"><span class="num">${n}</span><div class="marks">${marks.join("")}</div>${hname}</div>`);
    }
    const tail = (7 - ((offset + days) % 7)) % 7;
    for (let i = 0; i < tail; i++) cells.push('<div class="day out"></div>');
    grid.innerHTML = cells.join("");

    // Legende: Schulferien in diesem Monat
    const names = [...new Set(data.school.filter((s) => s.end >= data.first && s.start <= data.last).map((s) => s.name).filter(Boolean))];
    el("legend").innerHTML = names.length ? `<span><i class="sw"></i>${esc(names.join(", "))}</span>` : "";

    renderUpcoming(data, info);
    fitGrid();
  }

  function fitGrid() {
    const side = document.querySelector(".cal-side");
    const head = document.querySelector(".month-head");
    const u = Math.min(window.innerWidth, window.innerHeight) / 100;
    const nophoto = document.body.classList.contains("nophoto");
    const portrait = document.body.classList.contains("portrait");
    const share = nophoto && !portrait ? 0.82 : portrait ? 0.56 : 0.6;
    const avail = side.clientHeight * share - head.offsetHeight - 4 * u;
    const width = el("grid").clientWidth / 7;
    let cell = (avail / (state.rows || 5)) / u;
    cell = Math.max(4.2, Math.min(cell, (width / u) * 0.95, 10));
    document.documentElement.style.setProperty("--cell", cell.toFixed(2));
    trimUpcoming();
  }

  function whenLabel(iso, today) {
    const d = parseDay(iso);
    const day = d.toLocaleDateString(locale(), { day: "numeric" }) + (state.lang === "de" ? "." : "");
    let small = d.toLocaleDateString(locale(), { weekday: "short" }).replace(".", "");
    if (iso === today) small = t("today");
    else if (iso === addDays(today, 1)) small = t("tomorrow");
    const month = d.getMonth() !== parseDay(today).getMonth() ? " " + d.toLocaleDateString(locale(), { month: "short" }).replace(".", "") : "";
    return `<span class="when"><b>${esc(day)}${esc(month)}</b><small>${esc(small)}</small></span>`;
  }

  function timeOf(e) {
    if (e.allDay) return "";
    const d = new Date(e.start);
    return d.toLocaleTimeString(locale(), { hour: "2-digit", minute: "2-digit" });
  }

  function renderUpcoming(data, info) {
    el("upTitle").textContent = t("upcoming");
    // Für eine Vorschau auf einen späteren Monat ab dessen Erstem zählen.
    const today = data.first && data.first > data.today ? data.first : data.today;
    const until = addDays(today, Number(data.settings.UpcomingDays || 14));
    const items = [];
    const inWindow = (iso) => iso >= today && iso <= until;
    for (const b of data.birthdays) {
      if (!inWindow(b.date)) continue;
      const text = b.age ? t("bdList", { name: b.name, n: b.age }) : t("bdListNoAge", { name: b.name });
      items.push({ day: b.date, sort: "0", html: `<span class="ico${b.face ? " face" : ""}"${faceStyle(b)}>${b.face ? "" : "🎂"}</span><span class="what">${esc(text)}</span>` });
    }
    for (const h of data.holidays) {
      if (!inWindow(h.date)) continue;
      items.push({ day: h.date, sort: "1", html: `<span class="ico hol">✦</span><span class="what">${esc(h.name)}</span>` });
    }
    for (const s of data.school) {
      if (s.end < today || s.start > until) continue;
      const day = s.start < today ? today : s.start;
      const endText = s.end === s.start ? "" : t("schoolUntil", { date: parseDay(s.end).toLocaleDateString(locale(), { day: "numeric", month: "short" }) });
      items.push({ day, sort: "2", html: `<span class="ico school"></span><span class="what">${esc(s.name || t("schoolLegend"))}<small>${esc(endText)}</small></span>` });
    }
    for (const e of data.events) {
      const startDay = e.start.slice(0, 10);
      let endDay = (e.end || e.start).slice(0, 10);
      if (e.allDay && endDay > startDay) endDay = addDays(endDay, -1);
      if (endDay < today || startDay > until) continue;
      const day = startDay < today ? today : startDay;
      const title = e.title || "";
      if (e.birthday) {
        items.push({ day, sort: "0", html: `<span class="ico">🎂</span><span class="what">${esc(title)}</span>` });
        continue;
      }
      const where = e.location && data.settings.ShowTitles ? `<small>${esc(e.location)}</small>` : "";
      items.push({ day, sort: `3${e.allDay ? "0" : "1"}${e.start}`, html: `<span class="ico dot" style="--c:${esc(e.color)}"></span><span class="what">${esc(title || "•")}${where}</span><span class="time">${esc(timeOf(e) || t("allDay"))}</span>` });
    }
    items.sort((a, b) => (a.day + a.sort).localeCompare(b.day + b.sort));
    const list = el("upList");
    if (!items.length) {
      list.innerHTML = `<li class="empty">${esc(t("nothing", { n: data.settings.UpcomingDays || 14 }))}</li>`;
      return;
    }
    let lastDay = "";
    list.innerHTML = items.map((item) => {
      const label = item.day !== lastDay ? whenLabel(item.day, today) : '<span class="when"></span>';
      const cls = item.day === today ? ' class="today"' : "";
      lastDay = item.day;
      return `<li${cls}>${label}${item.html}</li>`;
    }).join("");
  }

  function trimUpcoming() {
    const list = el("upList");
    for (const li of list.children) li.hidden = false;
    const bottom = list.getBoundingClientRect().bottom;
    let cut = false;
    for (const li of list.children) {
      if (cut || li.getBoundingClientRect().bottom > bottom + 1) { li.hidden = true; cut = true; }
    }
  }

  // ------------------------------------------------------------ Geburtstag heute

  function renderBirthday(data) {
    const todays = data.birthdays.filter((b) => b.date === data.today);
    const box = el("birthday");
    if (!todays.length) { box.hidden = true; return; }
    const b = todays[Math.floor(Date.now() / 20000) % todays.length];
    el("bdTitle").textContent = t("bdTitle", { name: b.name });
    el("bdSub").textContent = b.age ? t("bdAge", { n: b.age }) : t("bdNoAge");
    const face = el("bdFace");
    face.style.backgroundImage = b.face ? `url('${base()}api/face?f=${encodeURIComponent(b.face)}')` : "";
    face.textContent = b.face ? "" : "🎂";
    box.hidden = false;
  }

  // ------------------------------------------------------------ Fotos

  function setPhotos(photos) {
    state.photos = photos || [];
    state.index = -1;
    clearTimeout(state.timer);
    document.body.classList.toggle("nophoto", !state.photos.length);
    el("dots").innerHTML = state.photos.length > 1 ? state.photos.map(() => "<i></i>").join("") : "";
    el("frame").replaceChildren();
    if (!state.photos.length) {
      el("capWhen").textContent = ""; el("capPlace").textContent = ""; el("capAgo").textContent = "";
      ready();
      if (state.data) fitGrid();
      return;
    }
    // Neuere Jahre zuerst zeigen ist hübsch, aber der Wechsel läuft der Reihe nach.
    // Mit dem jüngsten Foto beginnen (?photo=N für Vorschauen: das N-te).
    const startAt = Number(params.get("photo"));
    state.index = startAt > 0 ? Math.min(startAt, state.photos.length) - 2 : state.photos.length - 2;
    next();
    if (state.data) fitGrid();
  }

  function next() {
    if (!state.photos.length) return;
    state.index = (state.index + 1) % state.photos.length;
    const photo = state.photos[state.index];
    const img = new Image();
    img.onload = () => { show(photo, img); schedule(); };
    img.onerror = () => { report(`Foto ${photo.id} lädt nicht`); schedule(); ready(); };
    img.src = `${base()}api/photo?p=${encodeURIComponent(photo.id)}`;
  }

  function schedule() {
    clearTimeout(state.timer);
    if (still || state.photos.length < 2) return;
    const seconds = Math.max(5, Number(state.data?.settings.PhotoSeconds || 12));
    state.timer = setTimeout(next, seconds * 1000);
  }

  function show(photo, img) {
    const frame = el("frame");
    const box = frame.getBoundingClientRect();
    const ratio = img.naturalWidth / Math.max(1, img.naturalHeight);
    const frameRatio = box.width / Math.max(1, box.height);
    const fit = Math.abs(Math.log(ratio / frameRatio)) > 0.38;      // stark anderes Format: ganz zeigen
    const layers = [];
    if (fit) {
      const blur = document.createElement("div");
      blur.className = "shot blur";
      blur.style.backgroundImage = `url("${img.src}")`;
      layers.push(blur);
    }
    const shot = document.createElement("div");
    shot.className = `shot${fit ? " fit" : " drift"}`;
    shot.style.backgroundImage = `url("${img.src}")`;
    shot.style.setProperty("--dx", `${(Math.random() - 0.5) * 2}%`);
    shot.style.setProperty("--dy", `${(Math.random() - 0.5) * 2}%`);
    shot.style.setProperty("--drift", `${Number(state.data?.settings.PhotoSeconds || 12) + 2}s`);
    layers.push(shot);
    const old = [...frame.children];
    frame.append(...layers);
    requestAnimationFrame(() => requestAnimationFrame(() => {
      for (const layer of layers) layer.classList.add("on");
      for (const layer of old) layer.classList.remove("on");
    }));
    setTimeout(() => old.forEach((layer) => layer.remove()), 2200);

    const taken = parseDay(photo.t);
    el("capWhen").textContent = taken.toLocaleDateString(locale(), { day: "numeric", month: "long", year: "numeric" });
    el("capPlace").textContent = photo.place || "";
    const years = parseDay(state.data.today).getFullYear() - taken.getFullYear();
    el("capAgo").textContent = years <= 0 ? t("ago0") : years === 1 ? t("ago1") : t("ago", { n: years });
    [...el("dots").children].forEach((dot, i) => dot.classList.toggle("on", i === state.index));
    ready();
  }

  // ------------------------------------------------------------ Start

  async function start() {
    layout();
    try { await document.fonts.ready; } catch (_) { /* egal */ }
    tick();
    // Um Mitternacht beginnt ein neuer Tag (und vielleicht ein neuer Monat).
    setInterval(() => { if (state.data && isoDay(new Date()) !== state.data.today) { state.key = ""; } }, 30000);
  }
  start();
})();
