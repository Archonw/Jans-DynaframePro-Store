#!/usr/bin/env python3
"""Dynaframe's Magic Mirror - der Plugin-Teil des Pakets.

Wie MagicMirror, nur auf dem DynaFrame: eine Szene mit Regionen (oben, unten,
links, rechts, Mitte), in die du auf der Plugin-Seite Module setzt. Jedes
Modul kann mehrmals vorkommen und hat eigene Einstellungen. Was ein Modul ist,
steht in modules.py; neue Module kommen mit Updates dazu.

Das Plugin holt die Daten für alle Module (Wetter, Termine, Abfahrten,
Nachrichten, Home Assistant ...) und reicht sie an die Szene weiter. Die
Szene fragt alle 10 Sekunden über den Proxy der Weboberfläche (:8003 oder
Port 80) nach, wie Weltkarte Live und Pendler-Cockpit.

Die Szene läuft wie ein Bild in einer Playlist. Für einen Spiegel, der immer
dasselbe zeigt: die Playlist „Dynaframe's Magic Mirror“ anlegen und allein laufen lassen.
Oder das Plugin legt die Szene nach Zeitplan über die laufende Playlist
(Takeover): alle N Minuten für eine
Weile oder durchgehend in einem Zeitfenster.
"""

import base64
import json
import os
import re
import secrets
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

try:
    # Umgeht einen Dynaframe-Fehler, der einen Quick Mix nach einem Takeover
    # gestoppt zurücklässt; ohne die Datei läuft das Plugin genauso.
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None
import addons  # noqa: E402
import modules  # noqa: E402
import sources  # noqa: E402

plugin = create_plugin()

PLUGIN_ID = "MagicFrame"
DISPLAY_NAME = "Dynaframe's Magic Mirror"
SCENE_ID = "magic-frame"            # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen; bleibt bei Updates
SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"       # was das Plugin sich selbst merkt (Takeover-Playlist)

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30
VISIBLE_SECONDS = 90                # so lange gilt die Szene nach ihrer letzten Frage als sichtbar


def now():
    return time.time()


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=1, ensure_ascii=False)
    temp.replace(path)
    try:
        os.chmod(path, 0o600)  # enthält Passwörter und Tokens
    except OSError:
        pass


def local_text(epoch):
    if not epoch:
        return ""
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Texte (die Seite übersetzt sich selbst; hier nur, was das Plugin sagt)
# --------------------------------------------------------------------------

TEXTS = {
    "no-place": ("Stell oben auf der Seite deinen Ort ein.", "Set your location at the top of the page.",
                 "Indica tu ubicación arriba en la página."),
    "no-url": ("Trag einen Link ein.", "Enter a link.", "Introduce un enlace."),
    "bg-too-big": ("Das Bild ist zu groß (höchstens 15 MB).", "The image is too large (15 MB at most).",
                   "La imagen es demasiado grande (15 MB como máximo)."),
    "bg-not-image": ("Das ist kein JPG-, PNG-, WebP- oder GIF-Bild.", "That is not a JPG, PNG, WebP or GIF image.",
                     "No es una imagen JPG, PNG, WebP o GIF."),
    "no-stop": ("Wähle eine Haltestelle.", "Choose a stop.", "Elige una parada."),
    "no-entities": ("Trag mindestens eine Entität ein.", "Enter at least one entity.", "Introduce al menos una entidad."),
    "no-key": ("Trag Adresse und Token ein.", "Enter address and token.", "Introduce dirección y token."),
    "ha-none": ("Home Assistant kennt keine dieser Entitäten.", "Home Assistant knows none of these entities.",
                "Home Assistant no conoce ninguna de estas entidades."),
    "login": ("Der Dienst verlangt eine Anmeldung. Prüfe Benutzername, Passwort oder Token.",
              "The service wants a login. Check user name, password or token.",
              "El servicio pide inicio de sesión. Revisa usuario, contraseña o token."),
    "key": ("Der Dienst lehnt die Anmeldung ab. Prüfe Passwort oder Token.",
            "The service refuses the login. Check password or token.",
            "El servicio rechaza el acceso. Revisa contraseña o token."),
    "not-found": ("Unter diesem Link gibt es nichts. Prüfe den Link.", "Nothing at this link. Check the link.",
                  "No hay nada en este enlace. Revisa el enlace."),
    "not-ics": ("Unter diesem Link liegt kein Kalender.", "There is no calendar at this link.",
                "No hay ningún calendario en este enlace."),
    "missing-lib": ("Ein Baustein fehlt. Installiere das Paket noch einmal.",
                    "A component is missing. Install the package again.", "Falta un componente. Instala el paquete otra vez."),
    "unreachable": ("Der Dienst ist gerade nicht erreichbar.", "The service can't be reached right now.",
                    "El servicio no está disponible ahora."),
    "quota": ("Zu viele Anfragen; es geht gleich von selbst weiter.", "Too many requests; it will continue shortly.",
              "Demasiadas solicitudes; seguirá enseguida."),
    "format": ("Der Dienst hat etwas Unerwartetes geschickt.", "The service sent something unexpected.",
               "El servicio envió algo inesperado."),
    "ssl": ("Die sichere Verbindung ist fehlgeschlagen. Stimmt die Uhrzeit des Rahmens?",
            "The secure connection failed. Is the frame's clock right?",
            "Falló la conexión segura. ¿Está bien la hora del marco?"),
    "http": ("Der Dienst antwortet mit Fehler {code}.", "The service answers with error {code}.",
             "El servicio responde con el error {code}."),
    "no-address": ("Trag einen Ort ein.", "Enter a place.", "Introduce un lugar."),
    "place-not-found": ("Diesen Ort gibt es bei OpenStreetMap nicht. Versuch es mit Ort und Land.",
                        "OpenStreetMap doesn't know this place. Try town and country.",
                        "OpenStreetMap no conoce este lugar. Prueba con ciudad y país."),
    "place-saved": ("Ort gespeichert: {name}", "Location saved: {name}", "Ubicación guardada: {name}"),
    "no-scene": ("Die Szene Dynaframe's Magic Mirror ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.",
                 "The scene Dynaframe's Magic Mirror is not installed on this frame. Install the package again.",
                 "La escena Dynaframe's Magic Mirror no está instalada en este marco. Instala el paquete otra vez."),
    "scene-off": ("Die Szene Dynaframe's Magic Mirror ist auf der Plugins-Seite ausgeschaltet.",
                  "The scene Dynaframe's Magic Mirror is switched off on the Plugins page.",
                  "La escena Dynaframe's Magic Mirror está desactivada en la página de plugins."),
    "addon-installed": ("Zusatzmodul „{name}“ installiert. Du findest es jetzt unter „Modul hinzufügen“.",
                        "Add-on module “{name}” installed. It is now listed under “Add module”.",
                        "Módulo adicional «{name}» instalado. Ya aparece en «Añadir módulo»."),
    "addon-bad": ("Das ist kein gültiges Magic-Mirror-Modul: {exc}", "This is not a valid Dynaframe's Magic Mirror module: {exc}",
                  "No es un módulo válido de Dynaframe's Magic Mirror: {exc}"),
    "playlist-exists": ("Die Playlist {name} gibt es schon.", "The playlist {name} already exists.",
                        "La lista {name} ya existe."),
    "playlist-made": ("Playlist {name} angelegt. Starte sie auf der Startseite des Rahmens.",
                      "Playlist {name} created. Start it on the frame's home page.",
                      "Lista {name} creada. Iníciala en la página principal del marco."),
    "playlist-failed": ("Konnte die Playlist nicht anlegen: {exc}", "Couldn't create the playlist: {exc}",
                        "No se pudo crear la lista: {exc}"),
    "screen-held": ("Gerade hält etwas den Bildschirm. Versuch es gleich noch einmal.",
                    "Something is holding the screen right now. Try again in a moment.",
                    "Algo ocupa la pantalla ahora. Inténtalo de nuevo enseguida."),
    # Takeover
    "to-off": ("Automatische Anzeige ist aus.", "Automatic display is off.", "La visualización automática está desactivada."),
    "to-window": ("Außerhalb des Zeitfensters ({start}–{end} Uhr).", "Outside the time window ({start}–{end}).",
                  "Fuera del horario ({start}–{end})."),
    "to-next": ("Nächste Anzeige um {time} Uhr.", "Next display at {time}.", "Próxima visualización a las {time}."),
    "to-showing": ("Gerade auf dem Bildschirm, bis {time} Uhr.", "On screen now, until {time}.",
                   "En pantalla ahora, hasta las {time}."),
    "to-already": ("Der Magic Mirror ist schon auf dem Bildschirm.", "The Magic Mirror is already on screen.",
                   "El Magic Mirror ya está en pantalla."),
    "to-old": ("Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.",
               "This frame is too old to hand the screen to a plugin.",
               "Este marco es demasiado antiguo para ceder la pantalla a un plugin."),
    "to-no-playlist": ("Die Takeover-Playlist ist noch nicht angelegt.", "The takeover playlist has not been created yet.",
                       "La lista de takeover aún no está creada."),
    "to-playlist-failed": ("Konnte die Takeover-Playlist nicht anlegen: {exc}", "Couldn't create the takeover playlist: {exc}",
                           "No se pudo crear la lista de takeover: {exc}"),
    "to-in-playlist": ("Der Magic Mirror läuft gerade in deiner Playlist; die Anzeige bleibt so.",
                       "The Magic Mirror is playing in your playlist right now; nothing changes.",
                       "El Magic Mirror ya se está reproduciendo en tu lista; no cambia nada."),
    "to-screen-off": ("Der Bildschirm ist aus. Der Magic Mirror weckt ihn nicht.",
                      "The screen is off. The Magic Mirror does not wake it.",
                      "La pantalla está apagada. El Magic Mirror no la enciende."),
    "to-failed": ("Konnte den Magic Mirror nicht anzeigen: {exc}", "Couldn't show the Magic Mirror: {exc}",
                  "No se pudo mostrar el Magic Mirror: {exc}"),
    "to-busy": ("Etwas anderes hat gerade den Bildschirm.", "Something else has the screen right now.",
                "Otra cosa ocupa la pantalla ahora."),
    "to-late": ("Der Rahmen hat den Magic Mirror nicht rechtzeitig angezeigt.",
                "The frame didn't show the Magic Mirror in time.", "El marco no mostró el Magic Mirror a tiempo."),
    "to-plugin-off": ("Dynaframe's Magic Mirror ist auf der Plugins-Seite ausgeschaltet.",
                      "Dynaframe's Magic Mirror is switched off on the Plugins page.",
                      "Dynaframe's Magic Mirror está desactivado en la página de plugins."),
    "to-permission": ("„Allow takeover“ ist für Dynaframe's Magic Mirror auf der Plugins-Seite aus. Schalte es ein, "
                      "sonst kommt die Szene nicht von selbst auf den Bildschirm.",
                      "“Allow takeover” is off for Dynaframe's Magic Mirror on the Plugins page. Switch it on, "
                      "or the scene can't come on screen by itself.",
                      "«Allow takeover» está desactivado para Dynaframe's Magic Mirror en la página de plugins. "
                      "Actívalo; si no, la escena no puede aparecer sola."),
    "to-asking": ("Bitte den Rahmen um den Bildschirm …", "Asking the frame for the screen …", "Pidiendo la pantalla al marco …"),
    "to-not-held": ("Der Magic Mirror hatte den Bildschirm nicht.", "The Magic Mirror didn't have the screen.",
                    "El Magic Mirror no tenía la pantalla."),
    "to-stopped": ("Bildschirm zurückgegeben.", "Screen handed back.", "Pantalla devuelta."),
    "to-stalled": ("Der Rahmen ist nach dem Magic Mirror nicht zu deiner Playlist zurückgekehrt. Starte sie auf der "
                   "Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix passiert das nicht.",
                   "The frame didn't return to your playlist after the Magic Mirror. Restart it on the frame's home page. "
                   "With a saved playlist instead of a Quick Mix this doesn't happen.",
                   "El marco no volvió a tu lista después del Magic Mirror. Iníciala de nuevo en la página principal. "
                   "Con una lista guardada en lugar de un Quick Mix no pasa."),
}


def lang():
    value = settings().get("Language")
    return value if value in modules.LANGS else "de"


def tr(key, **values):
    row = TEXTS.get(key)
    if not row:
        return key
    return row[modules.LANGS.index(lang())].format(**values)


def error_text(code):
    code = str(code or "")
    if not code:
        return ""
    if code.startswith("http:"):
        return tr("http", code=code[5:])
    return tr(code) if code in TEXTS else code


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

GLOBAL_DEFAULTS = {
    "Language": "de",
    "Place": "",
    "Lat": None,
    "Lon": None,
    "PlaceName": "",
    "Units": "metric",          # metric | imperial
    "Background": "black",      # black | night | color | image
    "BackgroundColor": "#1b2430",
    "BackgroundImage": "",      # Link (http/https) oder "upload:<Zeitstempel>" für ein hochgeladenes Bild
    "BackgroundDim": 55,        # Abdunkeln des Bildes in Prozent, damit die Schrift lesbar bleibt
    "Scale": 100,               # Schriftgröße in Prozent
    "Clock24": True,
    "ModuleCatalogs": "",       # weitere Modul-Kataloge, ein Link pro Zeile
    # Über die laufende Playlist legen (Takeover)
    "ShowMode": "off",          # off | every | always
    "ShowDays": [0, 1, 2, 3, 4, 5, 6],   # Montag = 0
    "ShowFrom": "06:00",
    "ShowTo": "22:00",
    "EveryMinutes": 30,
    "ShowForSeconds": 60,
    "Modules": None,            # None = noch nie gespeichert -> Startaufstellung
}

_settings_lock = threading.Lock()
BACKGROUNDS = ("black", "night", "color", "image")
BACKGROUND_TYPES = {b"\xff\xd8\xff": (".jpg", "image/jpeg"), b"\x89PNG": (".png", "image/png"),
                    b"RIFF": (".webp", "image/webp"), b"GIF8": (".gif", "image/gif")}
BACKGROUND_MAX = 15 * 1024 * 1024


def new_id():
    return "m" + secrets.token_hex(4)


def instance(module_type, region=None, **config):
    return {"id": new_id(), "type": module_type, "region": region or modules.MODULES[module_type]["region"],
            "config": modules.coerce(module_type, config)}


def starter_modules(language):
    """Die Startaufstellung, angelehnt an die Standardkonfiguration von MagicMirror."""
    header = {"de": ("Termine", "Wettervorhersage"), "en": ("Calendar", "Weather forecast"),
              "es": ("Calendario", "Previsión")}.get(language, ("Termine", "Wettervorhersage"))
    return [
        instance("clock", "top_left"),
        instance("calendar", "top_left", header=header[0]),
        instance("weather", "top_right"),
        instance("forecast", "top_right", header=header[1]),
        instance("compliments", "middle_center"),
        instance("news", "bottom_bar", feed={"en": "bbc", "es": "elpais"}.get(language, "tagesschau")),
    ]


def settings():
    stored = read_json(SETTINGS_FILE, {}) or {}
    values = dict(GLOBAL_DEFAULTS)
    values.update({k: v for k, v in stored.items() if k in GLOBAL_DEFAULTS})
    if values["Modules"] is None:
        values["Modules"] = starter_modules(values["Language"])
    return values


def clean_modules(rows, previous):
    """Was die Seite schickt, geprüft. Ein leeres Geheimnis heißt: das alte behalten."""
    old = {m["id"]: m for m in previous or [] if isinstance(m, dict) and m.get("id")}
    out = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        if not modules.known(row.get("type")):
            # Zusatzmodul gerade nicht installiert: unverändert aufheben, damit
            # seine Einstellungen nach einer Neuinstallation wieder da sind.
            if row.get("id") in old and old[row["id"]].get("type") == row.get("type"):
                out.append(old[row["id"]])
            continue
        module_type = row["type"]
        module_id = str(row.get("id") or "")
        if not re.match(r"^[a-z0-9]{2,16}$", module_id):
            module_id = new_id()
        config = dict(row.get("config") or {})
        before = old.get(module_id)
        for key in modules.secret_keys(module_type):
            if not str(config.get(key) or "").strip() and not config.get(f"forget_{key}"):
                config[key] = ((before or {}).get("config") or {}).get(key, "") if before and \
                    before.get("type") == module_type else ""
        region = row.get("region") if row.get("region") in modules.REGION_IDS else modules.get(module_type)["region"]
        out.append({"id": module_id, "type": module_type, "region": region,
                    "config": modules.coerce(module_type, config)})
        if len(out) >= 40:
            break
    return out


def save_settings(changes):
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        current = settings()
        changed = []
        for key, raw in changes.items():
            if key not in GLOBAL_DEFAULTS:
                continue
            if key == "Modules":
                value = clean_modules(raw, current["Modules"])
            elif key == "Language":
                value = raw if raw in modules.LANGS else "de"
            elif key == "Units":
                value = "imperial" if raw == "imperial" else "metric"
            elif key == "Background":
                value = raw if raw in BACKGROUNDS else "black"
            elif key == "BackgroundColor":
                value = str(raw or "").strip().lower()
                if not re.match(r"^#[0-9a-f]{6}$", value):
                    continue
            elif key == "BackgroundImage":
                value = str(raw or "").strip()[:1000]
                if value and not re.match(r"^(https?://\S+|upload:\d+)$", value):
                    continue
            elif key == "BackgroundDim":
                try:
                    value = max(0, min(90, int(float(raw))))
                except (TypeError, ValueError):
                    continue
            elif key == "Scale":
                try:
                    value = max(50, min(200, int(float(raw))))
                except (TypeError, ValueError):
                    continue
            elif key == "ShowMode":
                value = raw if raw in ("off", "every", "always") else "off"
            elif key == "ShowDays":
                if not isinstance(raw, list):
                    continue
                value = sorted({int(d) for d in raw if str(d).isdigit() and 0 <= int(d) <= 6})
            elif key in ("ShowFrom", "ShowTo"):
                value = str(raw or "").strip()
                if minutes_of(value) is None:
                    continue
            elif key in ("EveryMinutes", "ShowForSeconds"):
                low, high = (2, 720) if key == "EveryMinutes" else (10, 3600)
                try:
                    value = max(low, min(high, int(float(raw))))
                except (TypeError, ValueError):
                    continue
            elif key == "Clock24":
                value = raw is True or str(raw).lower() in ("1", "true", "on")
            elif key == "ModuleCatalogs":
                value = "\n".join(line.strip() for line in str(raw or "").splitlines()
                                  if re.match(r"^https?://", line.strip()))[:2000]
            elif key in ("Lat", "Lon"):
                value = float(raw) if isinstance(raw, (int, float)) else None
            else:
                value = str(raw or "").strip()[:300]
            if current.get(key) != value:
                stored[key] = value
                changed.append(key)
        if "Modules" not in stored:
            stored["Modules"] = current["Modules"]  # die Startaufstellung festschreiben
        if changed or not SETTINGS_FILE.exists():
            write_json(SETTINGS_FILE, stored)
        return changed


def minutes_of(text):
    match = re.match(r"^(\d{1,2}):(\d{2})$", str(text or "").strip())
    if not match or int(match.group(1)) > 24 or int(match.group(2)) > 59:
        return None
    return min(24 * 60, int(match.group(1)) * 60 + int(match.group(2)))


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**changes):
    state = load_state()
    state.update(changes)
    write_json(STATE_FILE, state)


def public_module(row):
    """Eine Modul-Instanz ohne Geheimnisse, für Seite und Szene."""
    config = dict(row.get("config") or {})
    for key in modules.secret_keys(row["type"]):
        config[f"has_{key}"] = bool(config.get(key))
        config[key] = ""
    return {"id": row["id"], "type": row["type"], "region": row["region"], "config": config,
            "missing": not modules.known(row["type"])}


# --------------------------------------------------------------------------
# Daten holen: je Modul-Instanz in ihrem eigenen Takt
# --------------------------------------------------------------------------

_data = {}                     # id -> {"at", "error", "value", "next", "busy", "sig"}
_data_lock = threading.Lock()
_wake = threading.Event()
_stop_requested = threading.Event()
_pool = ThreadPoolExecutor(max_workers=3, thread_name_prefix=f"{PLUGIN_ID}-fetch")
_scene_seen = {"at": 0.0}


def scene_visible():
    return now() - _scene_seen["at"] < VISIBLE_SECONDS


def context(values):
    # Zusatzmodule bekommen dazu die Werkzeuge, mit denen auch die eingebauten
    # Module Daten holen (User-Agent, Zeitlimits, Fehlercodes).
    return {"lat": values.get("Lat"), "lon": values.get("Lon"), "lang": values["Language"],
            "imperial": values.get("Units") == "imperial", "get": sources._get, "SourceError": sources.SourceError,
            "log": plugin.log}


def signature(row, values):
    """Ändert sich eine Einstellung, die die Daten betrifft, wird neu geholt."""
    spec = modules.get(row["type"])
    place = (values.get("Lat"), values.get("Lon"), values.get("Units"), values.get("Language")) if spec.get("place") \
        else values.get("Language")
    return json.dumps([row["type"], row["config"], place], sort_keys=True, default=str)


def run_fetch(row, values):
    spec = modules.get(row["type"])
    started = now()
    try:
        value, error = spec["fetch"](row["config"], context(values)), ""
    except sources.SourceError as exc:
        value, error = None, exc.code
        if exc.code not in ("no-place", "no-url", "no-stop", "no-entities", "no-key"):
            plugin.log(f"{row['type']} {row['id']}: {exc}", level="warning")
    except Exception as exc:  # ein kaputtes Modul darf die anderen nicht stören
        value, error = None, "format"
        plugin.log(f"{row['type']} {row['id']}: {exc!r}", level="warning")
    with _data_lock:
        slot = _data.setdefault(row["id"], {})
        slot["busy"] = False
        if error:
            slot["error"] = error
            # Fehler: bald wieder versuchen, aber nicht häufiger als jede Minute
            slot["next"] = started + max(60, min(spec["every"], 300))
        else:
            slot.update(value=value, error="", at=now(), next=started + spec["every"])
    return error


def due_fetches():
    values = settings()
    visible = scene_visible()
    wanted = []
    with _data_lock:
        known = {row["id"] for row in values["Modules"]}
        for gone in [k for k in _data if k not in known]:
            _data.pop(gone, None)
        for row in values["Modules"]:
            spec = modules.get(row["type"])
            if not spec or not spec.get("fetch"):
                continue
            slot = _data.setdefault(row["id"], {"at": 0.0, "error": "", "value": None, "next": 0.0, "busy": False})
            sig = signature(row, values)
            if slot.get("sig") != sig:
                slot.update(sig=sig, next=0.0, value=None, error="", at=0.0)
            if slot["busy"] or now() < slot["next"]:
                continue
            if spec.get("visibleOnly") and not visible:
                continue
            slot["busy"] = True
            wanted.append(row)
    for row in wanted:
        _pool.submit(run_fetch, row, values)


def scan_addons(force=False):
    modules.EXTRA = addons.scan(PLUGIN_DIR, lambda text, level="info": plugin.log(text, level=level), force)


def data_loop():
    while not _stop_requested.is_set():
        try:
            scan_addons()
            due_fetches()
        except Exception as exc:  # pragma: no cover
            plugin.log(f"Datenschleife: {exc!r}", level="warning")
        _wake.wait(3)
        _wake.clear()


def fetch_now(module_id):
    values = settings()
    row = next((m for m in values["Modules"] if m["id"] == module_id), None)
    if row is None:
        return {"success": False, "error": "?"}
    if not (modules.get(row["type"]) or {}).get("fetch"):
        return {"success": True}
    with _data_lock:
        _data.setdefault(row["id"], {"at": 0.0, "value": None, "next": 0.0})["busy"] = True
        _data[row["id"]]["sig"] = signature(row, values)
    error = run_fetch(row, values)
    return {"success": not error, "error": error_text(error)}


# --------------------------------------------------------------------------
# Die Engine auf diesem Rahmen
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def find_scene():
    """Die installierte Szene: (numerische id, Hinweis)."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row["id"], "" if row.get("isEnabled", True) else tr("scene-off")
    return None, tr("no-scene")


PLAYLIST_SECONDS = 600


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def screen_held():
    """Hält gerade ein anderes Plugin den Bildschirm? Dann keine Playlist
    anlegen: der Rahmen baut den Quick Mix danach neu."""
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError as exc:
        return exc.status != 404
    return bool(status.get("active"))


def make_playlist():
    scene_id, note = find_scene()
    if scene_id is None:
        return {"success": False, "error": note}
    try:
        if next((p for p in all_playlists() if p.get("name") == DISPLAY_NAME), None):
            return {"success": True, "message": tr("playlist-exists", name=DISPLAY_NAME)}
        if screen_held():
            return {"success": False, "error": tr("screen-held")}
        created = engine_call("POST", "/playlists", {"name": DISPLAY_NAME, "description": "Dynaframe's Magic Mirror"}) or {}
        playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
        if not playlist_id:
            raise EngineError("keine id")
        engine_call("POST", f"/playlists/{playlist_id}/items",
                    {"dynamicSceneId": scene_id, "customDurationSeconds": PLAYLIST_SECONDS})
    except EngineError as exc:
        plugin.log(f"Playlist: {exc}", level="warning")
        return {"success": False, "error": tr("playlist-failed", exc=exc)}
    plugin.log(f"Playlist {DISPLAY_NAME} angelegt ({playlist_id}).")
    return {"success": True, "message": tr("playlist-made", name=DISPLAY_NAME)}


# --------------------------------------------------------------------------
# Über die laufende Playlist legen (Takeover). Gebaut wie bei Pendler-Cockpit:
# Ein Takeover spielt eine Playlist, also hält das Plugin eine ausgeschaltete
# Playlist „Dynaframe's Magic Mirror (takeover)“ mit nur der Szene bereit.
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = f"{DISPLAY_NAME} (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Wird vom Plugin Dynaframe's Magic Mirror abgespielt, wenn es den Bildschirm "
                                 "übernimmt. Bleibt ausgeschaltet, damit es nicht im Quick Mix landet. "
                                 "Das Plugin legt sie neu an, wenn sie gelöscht wird.")
TAKEOVER_ITEM_SECONDS = 6 * 3600   # das Plugin beendet die Anzeige lange vorher
TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
MAX_SESSION_SECONDS = 3600         # durchgehend: höchstens eine Stunde am Stück, dann neu

_playlists = {"at": 0.0, "takeoverId": None, "note": ""}
_playlist_lock = threading.Lock()
_takeover_lock = threading.Lock()
_takeover = {"handle": None, "reason": None, "since": None, "until": None, "token": 0, "note": ""}
_schedule = {"nextAt": 0.0, "lastAt": 0.0, "note": "", "retryAt": 0.0}


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def ensure_takeover_playlist(scene_id):
    """Die Szene allein, sechs Stunden, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if same_id(i.get("dynamicSceneId"), scene_id)]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_PLAYLIST_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError("keine id")
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": scene_id, "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    plugin.log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def maintain_playlists(force=False):
    """Erst anlegen, wenn die Anzeige gebraucht wird, und nur, solange nichts
    den Bildschirm hält (der Rahmen baut den Quick Mix nach einem Takeover neu)."""
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        scene_id, note = find_scene()
        if scene_id is None:
            _playlists["note"] = note
            return
        try:
            if _takeover["handle"] is None and not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(scene_id), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("to-playlist-failed", exc=exc)
            plugin.log(_playlists["note"], level="warning")


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform") or {}
    except EngineError:
        return True  # nicht entscheidbar: der Versuch selbst sagt es dann
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("to-plugin-off")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("to-permission")
    return ""


def display_is_off():
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def scene_in_playlist(scene_id):
    """Läuft die Szene gerade als normaler Playlist-Eintrag? Dann ist sie
    ohnehin zu sehen, und ein Takeover darüber kann den Rahmen danach
    gestoppt zurücklassen (bekannter Fehler)."""
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", read_timeout=5) or {}
    except EngineError:
        return False
    item = status.get("currentItem") or {}
    return bool(status.get("isRunning") and same_id(item.get("dynamicSceneId"), scene_id)
                and not same_id(status.get("activePlaylistId"), _playlists["takeoverId"]))


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        plugin.log(text)
    return False


def _clear_takeover():
    _takeover.update(handle=None, reason=None, since=None, until=None)


def _on_session_state(handle_or_state):
    """Das SDK ruft das mit dem Handle auf, nicht mit dem neuen Zustand."""
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _clear_takeover()
        if new_state == "preempted":
            # Etwas Wichtigeres hat den Bildschirm: nicht gleich wieder dagegen drücken.
            _schedule["retryAt"] = now() + 120
    plugin.log(f"Der Rahmen hat den Magic Mirror beendet: {new_state}.")
    _takeover_wake.set()
    threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason, token=None):
    """Bildschirm zurückgeben. Mehrfach aufrufbar."""
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        _clear_takeover()
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:
        plugin.log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", level="warning")
    plugin.log(f"Bildschirm zurückgegeben ({reason}).")
    _takeover_wake.set()
    if reason != "gestoppt":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def _release_after(seconds, token):
    if _stop_requested.wait(max(1, int(seconds))):
        return
    end_takeover("fertig", token)


def show_scene(reason, seconds):
    """Die Szene für `seconds` über alles legen. True, wenn der Rahmen den
    Bildschirm hergegeben hat."""
    if _takeover["handle"] is not None:
        return _note(tr("to-already"))
    if not takeover_supported():
        return _note(tr("to-old"))
    scene_id, note = find_scene()
    if scene_id is None or note:
        return _note(note)
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("to-no-playlist"))
    if reason != "test" and scene_in_playlist(scene_id):
        return _note(tr("to-in-playlist"))
    if display_is_off():
        return _note(tr("to-screen-off"))
    seconds = int(seconds)
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             # Die Szene hat ihre eigene Schrift; eine Bildunterschrift stört nur.
             "overlay": {"enabled": False}}
    try:
        handle = plugin.acquire_display_session(
            session_key=reason, state=state, display_name=DISPLAY_NAME,
            # Etwas länger als gewünscht: der Timer unten ist das ordentliche
            # Ende, die Grenze der Engine greift nur, wenn das Plugin stirbt.
            max_duration_seconds=seconds + 10, wake_if_off=False)
    except Exception as exc:
        return _note(tr("to-failed", exc=exc))
    if handle is None:
        return _note(takeover_permission_note() or tr("to-busy"))
    t = now()
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, reason=reason, since=t, until=t + seconds, note="")
    try:
        handle.on_state_change(_on_session_state)
    except Exception:
        pass
    try:
        if not handle.wait_until_active(timeout=10):
            end_takeover("fehlgeschlagen", token)
            return _note(tr("to-late"))
    except Exception as exc:
        end_takeover("fehlgeschlagen", token)
        return _note(tr("to-failed", exc=exc))
    plugin.log(f"Magic Mirror für {seconds} Sekunden auf dem Bildschirm ({reason}).")
    threading.Thread(target=_release_after, args=(seconds, token), name=f"{PLUGIN_ID}-timer", daemon=True).start()
    _scene_seen["at"] = now()   # gleich frische Daten für Module, die nur bei sichtbarer Szene holen
    _wake.set()
    return True


def check_playback_resumed():
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log,
                                                    stop_event=_stop_requested)
        if outcome == "not-requested":
            save_state(playbackStalled="")
            return
    elif _stop_requested.wait(12):
        return
    if _stop_requested.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
    except EngineError:
        return
    if status.get("isRunning") or _takeover["handle"] is not None:
        save_state(playbackStalled="")
        return
    save_state(playbackStalled=tr("to-stalled"))
    plugin.log(tr("to-stalled"), level="warning")


def in_window(values, moment=None):
    moment = moment or datetime.now()
    start, end = minutes_of(values["ShowFrom"]), minutes_of(values["ShowTo"])
    if start is None or end is None:
        return False
    minute = moment.hour * 60 + moment.minute
    if start == end:
        return moment.weekday() in values["ShowDays"]       # ganzer Tag
    if start < end:
        return moment.weekday() in values["ShowDays"] and start <= minute < end
    # Über Mitternacht, z. B. 21:00 bis 01:00: der Tag, an dem es anfängt, zählt.
    if minute >= start:
        return moment.weekday() in values["ShowDays"]
    return minute < end and (moment - timedelta(days=1)).weekday() in values["ShowDays"]


def window_end(values, moment=None):
    """Epoche, zu der das laufende Zeitfenster endet."""
    moment = moment or datetime.now()
    start, end = minutes_of(values["ShowFrom"]), minutes_of(values["ShowTo"]) or 0
    if start == end:
        stop = (moment + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        stop = moment.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(minutes=end)
        if stop <= moment:
            stop += timedelta(days=1)
    return stop.timestamp()


def decide_takeover():
    values = settings()
    t = now()
    with _takeover_lock:
        handle = _takeover["handle"]
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
        elif _takeover["reason"] == "zeitfenster" and (values["ShowMode"] != "always" or not in_window(values)):
            end_takeover("zeitfenster vorbei")
        return
    mode = values["ShowMode"]
    if mode == "off":
        _schedule.update(note=tr("to-off"), nextAt=0.0)
        return
    if not in_window(values):
        _schedule.update(note=tr("to-window", start=values["ShowFrom"], end=values["ShowTo"]), nextAt=0.0)
        return
    _schedule["note"] = ""
    if t < _schedule["retryAt"]:
        return
    maintain_playlists()
    if mode == "always":
        seconds = int(min(MAX_SESSION_SECONDS, window_end(values) - t))
        if seconds >= 20 and not show_scene("zeitfenster", seconds):
            _schedule["retryAt"] = t + 60
        return
    if not _schedule["nextAt"]:
        # Erste Runde im Zeitfenster: nach einer Minute, dann im Takt.
        _schedule["nextAt"] = max(t + 60, _schedule["lastAt"] + values["EveryMinutes"] * 60)
    if t < _schedule["nextAt"]:
        return
    if show_scene("zeitplan", values["ShowForSeconds"]):
        _schedule["lastAt"] = t
        _schedule["nextAt"] = t + values["EveryMinutes"] * 60
    else:
        # Nicht bekommen (Bildschirm aus, anderes Plugin, läuft schon in der Playlist):
        # in zwei Minuten noch einmal.
        _schedule["nextAt"] = t + 120


_takeover_wake = threading.Event()


def takeover_loop():
    _stop_requested.wait(5)
    while not _stop_requested.is_set():
        _takeover_wake.clear()
        try:
            decide_takeover()
        except Exception as exc:  # pragma: no cover - die Schleife muss weiterlaufen
            plugin.log(f"Takeover-Schleife: {exc!r}", level="warning")
        _takeover_wake.wait(5)


def show_now():
    """Sofort zeigen, für die eingestellte Anzeigedauer (Knopf und Aktion)."""
    _note(tr("to-asking"))
    threading.Thread(target=lambda: show_scene("test", settings()["ShowForSeconds"]),
                     name=f"{PLUGIN_ID}-show", daemon=True).start()
    return {"success": True, "message": tr("to-asking")}


def stop_now():
    if not end_takeover("abgebrochen"):
        return {"success": False, "error": tr("to-not-held")}
    _note(tr("to-stopped"))
    return {"success": True, "message": tr("to-stopped")}


def takeover_status():
    values = settings()
    with _takeover_lock:
        until, note = _takeover["until"] if _takeover["handle"] is not None else None, _takeover["note"]
        if until and _takeover["reason"] == "zeitfenster":
            until = window_end(values)   # wird stündlich erneuert; zählt das Ende des Fensters
    if until:
        line = tr("to-showing", time=datetime.fromtimestamp(until).strftime("%H:%M"))
    elif values["ShowMode"] == "every" and _schedule["nextAt"] and not _schedule["note"]:
        line = tr("to-next", time=datetime.fromtimestamp(_schedule["nextAt"]).strftime("%H:%M"))
    else:
        line = _schedule["note"] or ("" if values["ShowMode"] == "off" else "")
    problem = ""
    if values["ShowMode"] != "off":
        problem = takeover_permission_note() or _playlists["note"]
    return {"line": line, "note": note if note != line else "", "problem": problem,
            "showing": bool(until), "stalled": load_state().get("playbackStalled") or ""}


# --------------------------------------------------------------------------
# Was Szene und Seite bekommen
# --------------------------------------------------------------------------

# --------------------------------------------------------------------------
# Hintergrundbild: ein Link oder ein auf der Plugin-Seite hochgeladenes Bild
# --------------------------------------------------------------------------

def background_file():
    return next((p for p in sorted(DATA_DIR.glob("background.*")) if p.is_file()), None)


def background_url(value):
    """Für die Szene: ein Link bleibt, wie er ist; ein hochgeladenes Bild liegt
    relativ zur Plugin-Adresse unter background (Zeitstempel gegen den Cache)."""
    if value.startswith("upload:"):
        return f"background?v={value[7:]}" if background_file() else ""
    return value


def upload_background(data_url):
    raw = str(data_url or "")
    if "," in raw:
        raw = raw.split(",", 1)[1]
    if len(raw) > BACKGROUND_MAX * 4 // 3 + 4:
        return {"success": False, "error": tr("bg-too-big")}
    try:
        data = base64.b64decode(raw, validate=False)
    except ValueError:
        data = b""
    kind = next((v for k, v in BACKGROUND_TYPES.items() if data.startswith(k)), None)
    if not kind or (kind[0] == ".webp" and data[8:12] != b"WEBP"):
        return {"success": False, "error": tr("bg-not-image")}
    for old in DATA_DIR.glob("background.*"):
        old.unlink(missing_ok=True)
    (DATA_DIR / f"background{kind[0]}").write_bytes(data)
    stamp = str(int(time.time()))
    save_settings({"BackgroundImage": f"upload:{stamp}", "Background": "image"})
    _wake.set()
    return {"success": True, "BackgroundImage": f"upload:{stamp}"}


def remove_background():
    for old in DATA_DIR.glob("background.*"):
        old.unlink(missing_ok=True)
    if settings()["BackgroundImage"].startswith("upload:"):
        save_settings({"BackgroundImage": ""})
    _wake.set()
    return {"success": True}


def scene_payload():
    _scene_seen["at"] = now()
    values = settings()
    with _data_lock:
        data = {k: {"at": v.get("at") or 0, "error": error_text(v.get("error")), "value": v.get("value")}
                for k, v in _data.items()}
    rows = [public_module(row) for row in values["Modules"]]
    used = {row["type"] for row in rows}
    extra = []
    for module_type, spec in sorted(modules.EXTRA.items()):
        if module_type in used:
            addon = spec["addon"]
            extra.append({"type": module_type, "version": addon["version"],
                          "script": f"addons/{module_type}/{addon['script']}",
                          "style": f"addons/{module_type}/{addon['style']}" if addon["style"] else ""})
    return {
        "success": True,
        "version": version(),
        "lang": values["Language"],
        "scale": values["Scale"],
        "background": values["Background"],
        "backgroundColor": values["BackgroundColor"],
        "backgroundImage": background_url(values["BackgroundImage"]),
        "backgroundDim": values["BackgroundDim"],
        "clock24": values["Clock24"],
        "place": values["PlaceName"].split(",")[0] if values["PlaceName"] else "",
        "modules": rows,
        "data": {row["id"]: data.get(row["id"]) for row in rows if row["id"] in data},
        "addons": extra,
        "compliments": modules.COMPLIMENTS.get(values["Language"], modules.COMPLIMENTS["de"]),
        "now": now(),
    }


def state_payload():
    values = settings()
    with _data_lock:
        status = {k: {"at": local_text(v.get("at")), "error": error_text(v.get("error")), "busy": bool(v.get("busy"))}
                  for k, v in _data.items()}
    scene_id, note = find_scene()
    public = {k: v for k, v in values.items() if k != "Modules"}
    return {
        "success": True,
        "version": version(),
        "settings": public,
        "modules": [public_module(row) for row in values["Modules"]],
        "status": status,
        "catalog": modules.catalog(),
        "addonProblems": addons.problems(),
        "sceneSeen": local_text(_scene_seen["at"]),
        "visible": scene_visible(),
        "note": note,
        "takeover": takeover_status(),
        "theme": {"id": theme_id()},
    }


def set_place(text):
    try:
        found = sources.geocode(text, lang())
    except sources.SourceError as exc:
        if exc.code in ("not-found", "no-address"):
            return {"success": False, "error": tr("place-not-found" if exc.code == "not-found" else "no-address")}
        return {"success": False, "error": error_text(exc.code)}
    save_settings({"Place": text, "Lat": found["lat"], "Lon": found["lon"], "PlaceName": found["name"]})
    _wake.set()
    return {"success": True, "message": tr("place-saved", name=found["name"]), "name": found["name"]}


def install_addon(url):
    try:
        module_type, spec = addons.install_from_url(url, PLUGIN_DIR)
    except sources.SourceError as exc:
        return {"success": False, "error": error_text(exc.code)}
    except Exception as exc:
        return {"success": False, "error": tr("addon-bad", exc=str(exc)[:200])}
    scan_addons(force=True)
    plugin.log(f"Zusatzmodul {module_type} aus {url} installiert.")
    return {"success": True, "type": module_type,
            "message": tr("addon-installed", name=spec["name"][modules.LANGS.index(lang())])}


def module_catalog(force=False):
    extra = [line for line in settings()["ModuleCatalogs"].splitlines() if line.strip()]
    found = addons.catalogs(extra, force)
    rows = []
    for item in found["modules"]:
        spec = modules.EXTRA.get(item["type"])
        addon = (spec or {}).get("addon") or {}
        builtin = item["type"] in modules.MODULES
        rows.append(dict(item, installed=addon.get("version") if spec else None, origin=addon.get("origin"),
                         update=bool(spec) and addons.version_key(item["version"]) > addons.version_key(addon.get("version")),
                         builtin=builtin))
    return {"success": True, "modules": rows, "errors": found["errors"]}


def remove_addon(module_type):
    removed = addons.remove(module_type, PLUGIN_DIR)
    scan_addons(force=True)
    return {"success": removed}


def ha_entities(body):
    """Alle Entitäten aus Home Assistant für die Auswahl. Ohne neu getipptes
    Token nimmt es das gespeicherte des Moduls."""
    row = next((m for m in settings()["Modules"] if m["id"] == str(body.get("id") or "")), None)
    config = (row or {}).get("config") or {}
    url = str(body.get("url") or config.get("url") or "").strip()
    token = str(body.get("token") or "").strip() or config.get("token") or ""
    try:
        entities = sources.ha_all(url, token)
    except sources.SourceError as exc:
        return {"success": False, "error": error_text(exc.code)}
    return {"success": True, "entities": entities[:5000]}


def search_stops(query):
    values = settings()
    try:
        if query:
            stops = sources.transitous_search(query, values.get("Lat"), values.get("Lon"))
        elif values.get("Lat") is not None:
            stops = sources.transitous_nearby(values["Lat"], values["Lon"])
        else:
            stops = []
    except sources.SourceError as exc:
        return {"success": False, "error": error_text(exc.code), "stops": []}
    return {"success": True, "stops": stops}


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        """Den ganzen Body lesen: ungelesene Bytes würden auf einer offenen
        Verbindung zum Anfang der nächsten Anfrage."""
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/module-catalog":
                self._json(module_catalog(force="refresh" in (urlparse(self.path).query or "")))
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path.startswith("/addons/"):
                parts = path.split("/")
                spec = modules.EXTRA.get(parts[2]) if len(parts) == 4 else None
                target = addons.file_of(spec, parts[3]) if spec else None
                if target is None or not target.is_file():
                    self._json({"success": False, "error": "Nicht gefunden"}, 404, cors=True)
                    return
                kind = "text/css" if target.suffix == ".css" else "application/javascript"
                self._send(target.read_bytes(), f"{kind}; charset=utf-8", cache="no-cache", cors=True)
                return
            if path == "/api/scene":
                self._json(scene_payload(), cors=True)
                return
            if path == "/background":
                target = background_file()
                if target is None:
                    self._json({"success": False, "error": "Nicht gefunden"}, 404, cors=True)
                    return
                kind = next((v[1] for v in BACKGROUND_TYPES.values() if v[0] == target.suffix), "image/jpeg")
                self._send(target.read_bytes(), kind, cache="max-age=86400", cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            body = self._body()
            if path == "/api/settings":
                for name in ("Lat", "Lon", "PlaceName", "Place"):
                    body.pop(name, None)  # setzt nur die Ortssuche
                changed = save_settings(body)
                if changed:
                    _wake.set()
                if any(k.startswith("Show") or k == "EveryMinutes" for k in changed):
                    _schedule.update(nextAt=0.0, retryAt=0.0)
                    _takeover_wake.set()
                self._json({"success": True, "changed": changed,
                            "modules": [public_module(r) for r in settings()["Modules"]]})
                return
            if path == "/api/place":
                self._json(set_place(str(body.get("Place") or "").strip()[:200]))
                return
            if path == "/api/stop-search":
                self._json(search_stops(str(body.get("q") or "").strip()[:80]))
                return
            if path == "/api/ha-entities":
                self._json(ha_entities(body))
                return
            if path == "/api/fetch":
                self._json(fetch_now(str(body.get("id") or "")))
                return
            if path == "/api/addon-install":
                self._json(install_addon(str(body.get("url") or "").strip()[:500]))
                return
            if path == "/api/addon-remove":
                self._json(remove_addon(str(body.get("type") or "")))
                return
            if path == "/api/addon-rescan":
                scan_addons(force=True)
                self._json({"success": True})
                return
            if path == "/api/background-upload":
                self._json(upload_background(body.get("data")))
                return
            if path == "/api/background-remove":
                self._json(remove_background())
                return
            if path == "/api/show":
                self._json(show_now())
                return
            if path == "/api/stop":
                self._json(stop_now())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    plugin.log(f"Starte {PLUGIN_ID} {version()}")
    plugin.on_action("playlist", lambda _context=None: make_playlist())
    plugin.on_action("show", lambda _context=None: show_now())
    plugin.on_action("cancel", lambda _context=None: stop_now())

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    scan_addons(force=True)
    save_settings({})  # legt beim ersten Start die Startaufstellung an
    threading.Thread(target=data_loop, name=f"{PLUGIN_ID}-data", daemon=True).start()
    threading.Thread(target=takeover_loop, name=f"{PLUGIN_ID}-takeover", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _wake.set()
    _takeover_wake.set()
    end_takeover("gestoppt")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    _pool.shutdown(wait=False, cancel_futures=True)
    plugin.log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
