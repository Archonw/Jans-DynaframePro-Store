#!/usr/bin/env python3
"""Back Then - der Plugin-Teil des Pakets "Back Then".

Die Szene "back-then" zeigt ein paar alte Fotos aus einem Jahr und daneben,
was in diesem Jahr in der Welt los war: wichtige Ereignisse, der
Nummer-eins-Hit am Tag des Fotos, wer regiert hat, was Brot, Milch und
Benzin gekostet haben, wer in dem Jahr geboren wurde und wie alt die
eigenen Leute damals waren.

Dieses Plugin
- sammelt die datierten Fotos: aus einer Playlist von DynaFrame, der ganzen
  Mediendatenbank (und eingehängten Ordnern) oder von Immich,
- wählt je Besuch der Szene ein Jahr (lange nicht gezeigte zuerst) und ein
  paar Fotos daraus (verschiedene Tage, Favoriten und Sterne zuerst),
- holt die Fakten aus dem mitgelieferten Datensatz (Wikipedia, Wikidata,
  Statistikämter) und, wo der nichts hat, live von Wikidata,
- verkleinert die Fotos für die Szene.
"""

import datetime
import hashlib
import io
import json
import os
import random
import re
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import almanac  # noqa: E402
import exif_gps  # noqa: E402
import dynaframe_filters  # noqa: E402
import immich_filters  # noqa: E402
import sources  # noqa: E402
import own_playlist  # noqa: E402
import texts  # noqa: E402

try:
    from PIL import Image, ImageOps
except ImportError:  # pragma: no cover - kommt mit requirements.txt
    Image = ImageOps = None

HEIF = False
if Image is not None:
    try:
        from pillow_heif import register_heif_opener  # type: ignore

        register_heif_opener()
        HEIF = True
    except Exception:  # noqa: BLE001 - optional
        HEIF = False

plugin = create_plugin()

PLUGIN_ID = "BackThen"
SCENE_ID = "back-then"             # id in scene.dynamic - nie ändern
PLAYLIST_NAME = "Back Then"        # in allen Sprachen englisch (Jans Regel, 12.11.2026)
OLD_PLAYLIST_NAMES = ()
PLAYLIST_NAMES = {"de": PLAYLIST_NAME, "en": PLAYLIST_NAME, "es": PLAYLIST_NAME}
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen, Caches; bleibt bei Updates
PHOTO_DIR = DATA_DIR / "photos"

CONNECT_TIMEOUT = 10
MAX_SOURCES = 6
PHOTO_EDGE = 1920                   # lange Seite der Fotos für die Szene
BURST_SECONDS = 600                 # Fotos so dicht beieinander gelten als Serie

KINDS = ("library", "playlist", "immich_all", "immich_album")
LAYOUTS = ("panel", "paper")


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def as_float(value, default=None):
    try:
        number = float(str(value).strip().replace(",", "."))
    except (TypeError, ValueError):
        return default
    return default if number != number else number


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält den API-Schlüssel
        except OSError:
            pass


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

def default_sources():
    return [{"id": "s1", "kind": "library", "ref": "", "name": ""}]


SCHEMA = {
    "Language":        {"kind": "choice", "default": "en", "choices": texts.LANGUAGES},
    "ServerUrl":       {"kind": "url", "default": ""},
    "ApiKey":          {"kind": "secret", "default": ""},
    "Sources":         {"kind": "sources", "default": None},
    "Folders":         {"kind": "folders", "default": ""},
    # Welche Immich-Fotos überhaupt (wie Growing Up)
    "Albums":          {"kind": "albums", "default": []},
    # Immich-Filter wie Photo Mosaic (ohne „Wann“: das Plugin wählt die Jahre selbst)
    **immich_filters.schema(without=immich_filters.WHEN),
    # DynaFrame-Filter wie Photo Mosaic (Sterne, Kamera … aus der Mediendatenbank; die Jahre wählt das Plugin)
    **dynaframe_filters.schema(without=dynaframe_filters.WHEN),
    "Country":         {"kind": "choice", "default": "auto", "choices": ("auto",) + almanac.COUNTRIES},
    "Layout":          {"kind": "choice", "default": "panel", "choices": LAYOUTS},
    "MinYearsAgo":     {"kind": "int", "default": 10, "min": 1, "max": 80},
    "PerVisit":        {"kind": "int", "default": 4, "min": 1, "max": 12},
    "SameSeason":      {"kind": "bool", "default": False},
    "PhotoSeconds":    {"kind": "float", "default": 15.0, "min": 4.0, "max": 300.0},
    "FadeSeconds":     {"kind": "float", "default": 1.5, "min": 0.0, "max": 6.0},
    "KenBurns":        {"kind": "bool", "default": True},
    "ShowPlace":       {"kind": "bool", "default": True},
    "ShowEvents":      {"kind": "bool", "default": True},
    "EventCount":      {"kind": "int", "default": 4, "min": 1, "max": 6},
    "ShowHit":         {"kind": "bool", "default": True},
    "ShowLeader":      {"kind": "bool", "default": True},
    "ShowPrices":      {"kind": "bool", "default": True},
    "ShowBorn":        {"kind": "bool", "default": True},
    "ShowAges":        {"kind": "bool", "default": True},
    "People":          {"kind": "people", "default": ""},
    "RefreshHours":    {"kind": "int", "default": 12, "min": 1, "max": 168},
    "PlaylistSeconds": {"kind": "int", "default": 180, "min": 10, "max": 86400},
    "MakePlaylist":        {"kind": "bool", "default": False},
}
SECRETS = [name for name, spec in SCHEMA.items() if spec["kind"] == "secret"]
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()


def coerce_sources(raw):
    if raw is None:
        return default_sources()
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return default_sources()
    out, ids = [], set()
    for row in raw if isinstance(raw, list) else []:
        if not isinstance(row, dict) or len(out) >= MAX_SOURCES:
            continue
        ident = re.sub(r"[^A-Za-z0-9]", "", str(row.get("id") or ""))[:16] or uuid.uuid4().hex[:8]
        while ident in ids:
            ident = uuid.uuid4().hex[:8]
        ids.add(ident)
        out.append({
            "id": ident,
            "kind": row.get("kind") if row.get("kind") in KINDS else "library",
            "ref": re.sub(r"[^A-Za-z0-9_-]", "", str(row.get("ref") or ""))[:64],
            "name": re.sub(r"\s+", " ", str(row.get("name") or "")).strip()[:60],
        })
    return out


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind in ("ref", "date", "name"):
        return immich_filters.coerce(spec, raw)
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "float":
        return round(max(spec["min"], min(spec["max"], as_float(raw, spec["default"]))), 1)
    if kind == "coord":
        value = as_float(raw, None)
        return None if value is None or abs(value) > 180 else round(value, 4)
    if kind == "choice":
        value = str(raw or "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "sources":
        return coerce_sources(raw)
    if kind == "albums":
        if isinstance(raw, str):
            raw = [part for part in raw.split(",") if part]
        ids = []
        for item in raw if isinstance(raw, list) else []:
            ident = re.sub(r"[^A-Za-z0-9_-]", "", str(item or ""))[:64]
            if ident and ident not in ids:
                ids.append(ident)
        return ids[:50]
    if kind == "url":
        return sources.normalize_url(raw)[:300]
    if kind == "text":
        return re.sub(r"\s+", " ", str(raw or "")).strip()[:80]
    if kind == "people":
        lines = [re.sub(r"\s+", " ", line).strip() for line in str(raw or "").replace(";", "\n").splitlines()]
        return "\n".join(line[:60] for line in lines if line)[:600]
    if kind == "folders":
        lines = [line.strip() for line in str(raw or "").replace(";", "\n").splitlines()]
        return "\n".join(line for line in lines if line.startswith("/"))[:2000]
    return re.sub(r"\s+", "", str(raw or ""))[:400]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


def adopt_immich():
    """Server und Schlüssel aus einem anderen Immich-Plugin übernehmen, wenn hier keiner steht."""
    values = settings()
    if values["ServerUrl"] and values["ApiKey"]:
        return ""
    for name, title in (("ImmichSlideshow", "Immich Slideshow"), ("GrowingUp", "Growing Up"),
                        ("ColorCalendar", "Colour Calendar"), ("PhotoMosaic", "Photo Mosaic")):
        other = read_json(PLUGIN_DIR.parent / name / "data" / "settings.json", {}) or {}
        if not isinstance(other, dict):
            continue
        url, key = sources.normalize_url(other.get("ServerUrl")), str(other.get("ApiKey") or "").strip()
        if url and key:
            save_settings({"ServerUrl": url, "ApiKey": key})
            log(f"Immich-Server und API-Schlüssel aus {title} übernommen.")
            return title
    return ""


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 120))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def engine_image(media_id, path=""):
    """Das Vorschaubild, das die Engine für die Weboberfläche erzeugt (auf Jans Rahmen 512 Pixel)."""
    candidates = []
    if path:
        candidates += [("/media/thumbnail", {"path": path, "purpose": "preview"}),
                       ("/media/thumbnail", {"path": path})]
    if media_id:
        candidates += [(f"/media/thumbnail/{media_id}", {"purpose": "preview"}),
                       (f"/media/thumbnail/{media_id}", None)]
    failures = []
    for route, params in candidates:
        try:
            response = requests.get(f"{engine_base()}{route}", params=params, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 60))
        except requests.RequestException as exc:
            failures.append(f"{route}: {exc}")
            continue
        kind = response.headers.get("Content-Type", "").split(";")[0]
        if response.status_code == 200 and kind.startswith("image/"):
            return response.content
        failures.append(f"{route}{'?path' if params and 'path' in params else ''}: HTTP {response.status_code} {kind}")
    raise sources.SourceError(f"Vorschaubild {media_id}: " + "; ".join(failures))


# --------------------------------------------------------------------------
# Index der DynaFrame-Fotos (Datum + GPS), mit Cache für Dateien
# --------------------------------------------------------------------------

immich = sources.Immich(tr)
dynaframe = sources.DynaFrame(engine_call, EngineError, log)
almanac_db = almanac.Almanac(DATA_DIR, PLUGIN_DIR / "data_bundled.json", log)

EXIF_FILE = DATA_DIR / "exif.json"
_exif = {"data": None, "dirty": 0}
_exif_lock = threading.Lock()


def exif_lookup(path, stamp):
    """(taken, lat, lon) aus der Datei, mit Cache (key = Pfad, Stempel muss passen)."""
    with _exif_lock:
        if _exif["data"] is None:
            stored = read_json(EXIF_FILE, {})
            _exif["data"] = stored if isinstance(stored, dict) else {}
        row = _exif["data"].get(path)
    if isinstance(row, list) and len(row) == 4 and row[0] == stamp:
        return row[1], row[2], row[3]
    lat, lon, taken = exif_gps.read(path)
    taken = sources.clean_taken(taken)
    with _exif_lock:
        _exif["data"][path] = [stamp, taken, lat, lon]
        _exif["dirty"] += 1
    return taken, lat, lon


def exif_save(keep=None):
    with _exif_lock:
        if _exif["data"] is None:
            return
        if keep is not None:
            for key in [k for k in _exif["data"] if k not in keep]:
                del _exif["data"][key]
                _exif["dirty"] += 1
        if _exif["dirty"]:
            write_json(EXIF_FILE, _exif["data"])
            _exif["dirty"] = 0


def key_path(key):
    if key.startswith("d:"):
        return key.partition("|")[2]
    if key.startswith("f:"):
        return key[2:]
    return ""


_stop_requested = threading.Event()
_work_stop = threading.Event()
_wake = threading.Event()
_index_lock = threading.Lock()
_index = {"rows": [], "status": {}, "at": 0.0, "signature": "", "busy": False,
          "progress": {"done": 0, "todo": 0, "phase": ""}, "undated": 0, "total": 0}


def index_signature(values):
    wanted = [(s["id"], s["kind"], s["ref"]) for s in values["Sources"] if not s["kind"].startswith("immich")]
    return json.dumps([wanted, values["Folders"], dynaframe_filters.signature(values), version()], sort_keys=True)


def build_index(reason=""):
    """Alle DynaFrame-Quellen einlesen: Datum und GPS jedes Fotos."""
    values = settings()
    wanted = [s for s in values["Sources"] if not s["kind"].startswith("immich")]
    with _index_lock:
        if _index["busy"]:
            return
        _index["busy"] = True
    started = now()
    status, rows = {}, {}
    match = None
    if wanted and dynaframe_filters.active(values):
        match = dynaframe_filters.Matcher(values, lambda: dynaframe.library_rows(_work_stop),
                                          cache_file=str(DATA_DIR / "file_meta.json"), log=log)
    try:
        if wanted:
            log(f"Lese die DynaFrame-Fotos ein{' - ' + reason if reason else ''}.")
        _index["progress"] = {"done": 0, "todo": 0, "phase": "list"}
        for source in wanted:
            sid = source["id"]
            _index["status"][sid] = dict(_index["status"].get(sid) or {}, state="busy")
            try:
                if source["kind"] == "playlist":
                    if not source["ref"]:
                        raise sources.SourceError(tr("Wähle eine Playlist."))
                    try:
                        found, total = dynaframe.playlist(source["ref"], _work_stop)
                    except EngineError as exc:
                        if exc.status == 404:
                            raise sources.SourceError(tr("Die Playlist gibt es nicht mehr.")) from exc
                        raise
                else:
                    folders = [f for f in values["Folders"].splitlines() if f]
                    found, total = dynaframe.library(folders, _work_stop)
                if match is not None:
                    found = [row for row in found if match.keep(row["k"])]
                for row in found:
                    row["src"] = sid
                    rows.setdefault(row["k"], row)
                status[sid] = {"state": "ok", "total": total, "dated": 0, "located": 0, "error": "", "at": now()}
            except EngineError as exc:
                status[sid] = {"state": "error", "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except sources.SourceError as exc:
                status[sid] = {"state": "error", "error": str(exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except Exception as exc:  # pragma: no cover - darf den Durchlauf nicht beenden
                status[sid] = {"state": "error", "error": str(exc)[:200], "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc!r}", "warning")
            _index["status"][sid] = status[sid]
            if _work_stop.is_set() or _stop_requested.is_set():
                return

        if match is not None:
            match.save()
        _index["dfCount"] = match.counts() if match is not None else None
        # Datum/GPS aus den Dateien, wo die Engine keins mitliefert
        todo = [r for r in rows.values() if (not r["t"] or r["lat"] is None) and os.path.isfile(key_path(r["k"]))]
        _index["progress"] = {"done": 0, "todo": len(todo), "phase": "exif"}
        for count, row in enumerate(todo, 1):
            if _work_stop.is_set() or _stop_requested.is_set():
                exif_save()
                return
            taken, lat, lon = exif_lookup(key_path(row["k"]), row["stamp"])
            row["t"] = row["t"] or taken
            if row["lat"] is None and lat is not None and lon is not None:
                row["lat"], row["lon"] = lat, lon
            _index["progress"]["done"] = count
            if count % 200 == 0:
                time.sleep(0.05)
        exif_save(keep={key_path(r["k"]) for r in rows.values() if key_path(r["k"])})
        dated = [r for r in rows.values() if len(r["t"]) >= 10]
        for sid, row in status.items():
            if row.get("state") == "ok":
                mine = [r for r in rows.values() if r.get("src") == sid]
                row["dated"] = sum(1 for r in mine if len(r["t"]) >= 10)
                row["located"] = sum(1 for r in mine if r["lat"] is not None)
        with _index_lock:
            _index.update(rows=dated, status=dict(_index["status"], **status), at=now(),
                          signature=index_signature(values), undated=len(rows) - len(dated), total=len(rows))
        if wanted:
            log(f"{len(dated)} DynaFrame-Fotos mit Datum ({len(rows) - len(dated)} ohne), {now() - started:.0f} s.")
    finally:
        _index["progress"] = {"done": 0, "todo": 0, "phase": ""}
        with _index_lock:
            _index["busy"] = False


# --------------------------------------------------------------------------
# Ein Besuch: ein Jahr, ein paar Fotos daraus und was damals los war
# --------------------------------------------------------------------------

HISTORY_FILE = DATA_DIR / "history.json"
_visit_lock = threading.Lock()
_visits = {"current": None, "upcoming": None, "byId": {}, "busy": False, "signature": "", "error": "",
           "years": {}, "immichYears": None}
_immich_cache = {}          # (signature, year) -> (time, rows)


def visit_signature(values):
    keep = ("Sources", "ServerUrl", "ApiKey", "Albums", *immich_filters.SCHEMA.keys(), "MinYearsAgo",
            "PerVisit", "SameSeason", "Country", "Language", "People", "ShowPlace")
    return json.dumps([{k: values[k] for k in keep if k in values}, _index["signature"], _index["at"], version()],
                      sort_keys=True, default=str)


def country_of(values):
    code = values["Country"]
    return code if code in almanac.COUNTRIES else almanac.DEFAULT_COUNTRY.get(values["Language"], "US")


def history():
    stored = read_json(HISTORY_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {"years": [as_int(y) for y in stored.get("years") or []][-20:],
            "keys": [str(k) for k in stored.get("keys") or []][-600:]}


def remember(visit):
    past = history()
    past["years"] = (past["years"] + [visit["year"]])[-20:]
    past["keys"] = (past["keys"] + [p["k"] for p in visit["source"]])[-600:]
    write_json(HISTORY_FILE, past)


def cutoff_year(values):
    return datetime.date.today().year - values["MinYearsAgo"]


def dynaframe_years(values):
    """Jahr -> Fotos aus den DynaFrame-Quellen (nur alte genug)."""
    last = cutoff_year(values)
    years = {}
    for row in _index["rows"]:
        year = as_int(row["t"][:4], 0)
        if 1826 <= year <= last:
            years.setdefault(year, []).append(row)
    return years


def immich_sources(values):
    return [s for s in values["Sources"] if s["kind"].startswith("immich")]


def immich_first_year(values):
    """Das erste Jahr mit Fotos in Immich (einmal je Einstellung)."""
    signature = json.dumps([values["ServerUrl"], values["Albums"], immich_filters.signature(values),
                            [(s["kind"], s["ref"]) for s in immich_sources(values)]], sort_keys=True)
    cached = _visits.get("immichYears")
    if cached and cached[0] == signature and now() - cached[2] < 86400:
        return cached[1]
    immich.configure(values["ServerUrl"], values["ApiKey"])
    first = None
    f = immich_filters.from_settings(values)
    for source in immich_sources(values):
        albums = [source["ref"]] if source["kind"] == "immich_album" else list(values["Albums"])
        if source["kind"] == "immich_album" and not source["ref"]:
            continue
        try:
            year = immich.first_year(albums, _work_stop, f)
        except sources.SourceError as exc:
            _visits["error"] = str(exc)
            continue
        first = year if first is None else min(first, year)
    _visits["immichYears"] = (signature, first, now())
    return first


def immich_year_rows(values, year):
    """Fotos eines Jahres von Immich (alle Immich-Quellen), mit Cache für sechs Stunden."""
    out = []
    f = immich_filters.from_settings(values)
    immich.configure(values["ServerUrl"], values["ApiKey"])
    for source in immich_sources(values):
        if source["kind"] == "immich_album":
            if not source["ref"]:
                continue
            albums = [source["ref"]]
        else:
            albums = list(values["Albums"])
        key = json.dumps([values["ServerUrl"], albums, f, year], sort_keys=True, default=str)
        hit = _immich_cache.get(key)
        if hit and now() - hit[0] < 6 * 3600:
            rows = hit[1]
        else:
            extra = {"withExif": True, "takenAfter": f"{year - 1}-12-31T00:00:00.000Z",
                     "takenBefore": f"{year + 1}-01-02T00:00:00.000Z"}
            try:
                found = immich_filters.search(immich, _work_stop, f, albums, extra, limit=800)
            except sources.SourceError as exc:
                _visits["error"] = str(exc)
                log(f"Immich {year}: {exc}", "warning")
                continue
            rows = [r for r in (immich._row(item) for item in found) if r and r["t"][:4] == str(year)]
            if len(_immich_cache) > 60:
                _immich_cache.clear()
            _immich_cache[key] = (now(), rows)
        for row in rows:
            out.append(dict(row, src=source["id"]))
    return out


def season_distance(taken, today):
    try:
        shot = datetime.date(today.year, int(taken[5:7]), min(28, int(taken[8:10])))
    except ValueError:
        return 400
    diff = abs((shot - today).days)
    return min(diff, 365 - diff)


def pick_photos(rows, count, values, recent):
    """Bis zu count Fotos eines Jahres: verschiedene Tage, Favoriten/Sterne zuerst,
    nichts, was gerade erst lief, keine Serienbilder."""
    today = datetime.date.today()
    pool = [r for r in rows if r["k"] not in recent] or list(rows)
    if values["SameSeason"]:
        near = [r for r in pool if season_distance(r["t"], today) <= 45]
        pool = near or pool
    random.shuffle(pool)
    pool.sort(key=lambda r: (-(as_int(r.get("stars"), 0) + (2 if r.get("fav") else 0))))
    # Die besten zuerst, aber nicht nur: aus der oberen Hälfte zufällig
    top = pool[:max(count * 4, 12)]
    random.shuffle(top)
    chosen, days = [], set()
    for row in top + pool:
        if len(chosen) >= count:
            break
        if row in chosen or row["t"][:10] in days:
            continue
        chosen.append(row)
        days.add(row["t"][:10])
    for row in pool:                     # zu wenige Tage? Dann mehrere vom selben Tag
        if len(chosen) >= count:
            break
        if row not in chosen and all(abs(stamp_seconds(row) - stamp_seconds(c)) >= BURST_SECONDS for c in chosen):
            chosen.append(row)
    chosen.sort(key=lambda r: r["t"])
    return chosen


def stamp_seconds(row):
    try:
        moment = datetime.datetime.fromisoformat(row["t"][:19])
    except ValueError:
        return 0
    return moment.timestamp()


PERSON_LINE = re.compile(r"^(.+?)[\s,;:]+(\d{1,2}\.\d{1,2}\.\d{4}|\d{4}-\d{2}-\d{2}|\d{4})$")


def people(values):
    """„Name 1980“ / „Name 14.05.1980“ / „Name 1980-05-14“, eine Person je Zeile."""
    out = []
    for line in values["People"].splitlines():
        match = PERSON_LINE.match(line.strip())
        if not match:
            continue
        name, born = match.group(1).strip(), match.group(2)
        if re.match(r"^\d{1,2}\.\d{1,2}\.\d{4}$", born):
            d, m, y = born.split(".")
            born = f"{y}-{int(m):02d}-{int(d):02d}"
        out.append((name[:30], born))
    return out[:8]


def ages(values, taken):
    out = []
    try:
        shot = datetime.date.fromisoformat(taken[:10])
    except ValueError:
        return out
    for name, born in people(values):
        if len(born) == 4:
            year = int(born)
            if year > shot.year:
                out.append({"name": name, "unborn": year - shot.year})
            else:
                out.append({"name": name, "age": shot.year - year, "approx": True})
            continue
        try:
            birth = datetime.date.fromisoformat(born)
        except ValueError:
            continue
        if birth > shot:
            out.append({"name": name, "unborn": max(1, birth.year - shot.year), "days": (birth - shot).days})
        else:
            age = shot.year - birth.year - ((shot.month, shot.day) < (birth.month, birth.day))
            out.append({"name": name, "age": age})
    return out


def make_visit(values, avoid_year=None):
    """Ein Jahr wählen (lange nicht gezeigte zuerst), Fotos daraus, Fakten dazu."""
    past = history()
    recent_years = set(past["years"][-max(3, min(12, len(past["years"]))):])
    recent_keys = set(past["keys"])
    local = dynaframe_years(values)
    years = set(local)
    first = immich_first_year(values) if immich_sources(values) else None
    if first:
        years |= set(range(max(1900, first), cutoff_year(values) + 1))
    if not years:
        return None
    order = list(years)
    random.shuffle(order)
    # zuerst Jahre, die zuletzt nicht dran waren und nicht das gerade laufende
    order.sort(key=lambda y: (y == avoid_year, y in recent_years))
    for year in order[:8]:
        if _stop_requested.is_set():
            return None
        rows = list(local.get(year, []))
        if first and year >= first:
            rows += immich_year_rows(values, year)
        seen, unique = set(), []
        for row in rows:
            if row["k"] not in seen:
                seen.add(row["k"])
                unique.append(row)
        if not unique:
            continue
        chosen = pick_photos(unique, values["PerVisit"], values, recent_keys)
        if chosen:
            return describe(values, year, chosen, len(unique))
    return None


def describe(values, year, chosen, total):
    lang = values["Language"]
    code = country_of(values)
    facts = almanac_db.facts(year, code, lang, days=[r["t"][:10] for r in chosen])
    photos = []
    for idx, row in enumerate(chosen):
        day = facts["days"].get(row["t"][:10]) or {}
        leader = day.get("leader")
        if leader and leader.get("image"):
            leader = dict(leader, portrait=f"./api/portrait?f={quote(leader['image'])}")
        photos.append({"i": idx, "t": row["t"], "place": (row.get("place") or "") if values["ShowPlace"] else "",
                       "w": row.get("w"), "h": row.get("h"), "hit": day.get("hit"), "leader": leader,
                       "ages": ages(values, row["t"])})
    if facts.get("leader") and facts["leader"].get("image"):
        facts["leader"]["portrait"] = f"./api/portrait?f={quote(facts['leader']['image'])}"
    facts.pop("days", None)
    ident = uuid.uuid4().hex[:10]
    return {"id": ident, "year": year, "ago": datetime.date.today().year - year, "total": total,
            "country": code, "lang": lang, "photos": photos, "facts": facts,
            "source": [{"k": r["k"], "stamp": r.get("stamp") or ""} for r in chosen], "at": now()}


def store_visit(visit):
    with _visit_lock:
        _visits["byId"][visit["id"]] = visit
        keep = {v["id"] for v in (_visits["current"], _visits["upcoming"], visit) if v}
        for ident in [i for i in _visits["byId"] if i not in keep]:
            if len(_visits["byId"]) > 6:
                del _visits["byId"][ident]


def fill_visits(reason=""):
    values = settings()
    with _visit_lock:
        if _visits["busy"]:
            return
        _visits["busy"] = True
    try:
        _visits["error"] = ""
        signature = visit_signature(values)
        if _visits["signature"] != signature:
            with _visit_lock:
                _visits.update(current=None, upcoming=None, signature=signature)
        if _visits["current"] is None:
            visit = make_visit(values)
            if visit:
                store_visit(visit)
                _visits["current"] = visit
                remember(visit)
                log(f"Jetzt: {visit['year']} mit {len(visit['photos'])} Fotos{' - ' + reason if reason else ''}.")
                threading.Thread(target=prepare_visit, args=(visit,), daemon=True).start()
        if _visits["current"] is not None and _visits["upcoming"] is None:
            visit = make_visit(values, avoid_year=_visits["current"]["year"])
            if visit:
                store_visit(visit)
                _visits["upcoming"] = visit
                threading.Thread(target=prepare_visit, args=(visit,), daemon=True).start()
    finally:
        with _visit_lock:
            _visits["busy"] = False


def advance(seen_id):
    """Die Szene ist mit dem Jahr fertig: das nächste vorbereitete Jahr wird das aktuelle."""
    with _visit_lock:
        current = _visits["current"]
        if current is None or current["id"] != seen_id or _visits["upcoming"] is None:
            return False
        _visits["current"], _visits["upcoming"] = _visits["upcoming"], None
        remember(_visits["current"])
    _wake.set()
    return True


def prepare_visit(visit):
    for item in visit["source"]:
        if _stop_requested.is_set():
            return
        try:
            prepare(item)
        except Exception as exc:  # noqa: BLE001 - ein Foto darf den Rest nicht aufhalten
            log(f"Foto für die Szene ({item['k'][:100]}): {exc}", "warning")
    for photo in visit["photos"]:
        image = (photo.get("leader") or {}).get("image")
        if image:
            almanac_db.portrait(image)
    clean_photo_cache()


def clean_photo_cache():
    keep = set()
    for visit in list(_visits["byId"].values()):
        keep |= {photo_file(item).name for item in visit["source"]}
    try:
        for entry in os.scandir(PHOTO_DIR):
            if entry.name not in keep and now() - entry.stat().st_mtime > 2 * 86400:
                os.unlink(entry.path)
    except OSError:
        pass


def photo_bytes(query):
    ident = (query.get("v") or [""])[0]
    idx = as_int((query.get("i") or ["-1"])[0], -1)
    visit = _visits["byId"].get(ident)
    if not visit or not 0 <= idx < len(visit["source"]):
        return None
    try:
        return prepare(visit["source"][idx]).read_bytes()
    except Exception as exc:  # noqa: BLE001
        log(f"Foto für die Szene: {exc}", "warning")
        return None


# --------------------------------------------------------------------------
# Der Arbeitsfaden
# --------------------------------------------------------------------------

def work_loop():
    while not _stop_requested.is_set():
        values = settings()
        try:
            due = now() - _index["at"] >= values["RefreshHours"] * 3600
            if due or _index["signature"] != index_signature(values):
                build_index("geplant" if due and _index["at"] else "Einstellungen")
            _work_stop.clear()
            fill_visits()
        except Exception as exc:  # noqa: BLE001 - der Faden darf nicht sterben
            log(f"Fehler: {exc!r}", "warning")
        _wake.wait(30)
        _wake.clear()


def reload_now():
    _work_stop.set()
    _index["at"] = 0.0
    _visits["signature"] = ""
    _visits["immichYears"] = None
    _immich_cache.clear()

    def later():
        time.sleep(1)
        _work_stop.clear()
        _wake.set()

    threading.Thread(target=later, daemon=True).start()
    return {"success": True, "message": tr("Die Fotos werden neu eingelesen.")}


def next_year():
    """Aktion „Anderes Jahr“: sofort ein neues Jahr zeigen."""
    with _visit_lock:
        _visits["current"] = _visits["upcoming"]
        _visits["upcoming"] = None
    _wake.set()
    return {"success": True, "message": tr("Gleich kommt ein anderes Jahr.")}


# --------------------------------------------------------------------------
# Fotos für die Szene
# --------------------------------------------------------------------------

PHOTO_MAX = 40 * 1024 * 1024
SHOWABLE = (".jpg", ".jpeg", ".jpe", ".png", ".webp", ".gif", ".bmp", ".tif", ".tiff")


def webdav_dirs():
    seen = []
    for home in (Path.home(), Path("/home/pi")):
        folder = home / ".local/share/dfr/webdav-cache"
        if folder not in seen and folder.is_dir():
            seen.append(folder)
    return seen


def webdav_cached(path, size):
    """Fotos aus WebDAV (/webdav-media/<Quelle>/...) liefert die Engine nur als
    512-Pixel-Vorschau. Das Original legt DynaFrame aber in webdav-cache ab,
    als <Quelle>-<Hash>.<Endung>. Den Hash kennen wir nicht, also: gleiche
    Quelle, gleiche Endung, gleiche Dateigröße (wie bei Halloween Scare)."""
    if not path.startswith("/webdav-media/"):
        return None
    size = as_int(size, 0)
    if size <= 0 or size > PHOTO_MAX:
        return None
    parts = path.split("/")
    source = parts[2] if len(parts) > 2 else ""
    suffix = Path(path).suffix.lower()
    best = None
    for folder in webdav_dirs():
        try:
            entries = list(os.scandir(folder))
        except OSError:
            continue
        for entry in entries:
            name = entry.name
            if source and not name.startswith(source + "-"):
                continue
            if suffix and not name.lower().endswith(suffix):
                continue
            try:
                info = entry.stat()
            except OSError:
                continue
            if info.st_size == size and (best is None or info.st_mtime > best[0]):
                best = (info.st_mtime, Path(entry.path))
    return best[1] if best else None


def shrink(source):
    """Bild (Pfad oder Bytes) gedreht nach Exif und verkleinert als JPEG-Bytes, dazu (w, h)."""
    if Image is None:
        raise sources.SourceError("Pillow fehlt")
    handle = io.BytesIO(source) if isinstance(source, (bytes, bytearray)) else source
    with Image.open(handle) as image:
        try:
            image.draft("RGB", (PHOTO_EDGE, PHOTO_EDGE))
        except Exception:  # noqa: BLE001 - nur JPEG kennt draft
            pass
        image = ImageOps.exif_transpose(image)
        image = image.convert("RGB")
        image.thumbnail((PHOTO_EDGE, PHOTO_EDGE), Image.LANCZOS)
        out = io.BytesIO()
        image.save(out, "JPEG", quality=86, optimize=True, progressive=True)
        return out.getvalue(), image.size


def photo_file(item):
    name = hashlib.sha1(f"{item['k']}|{item.get('stamp') or ''}".encode("utf-8")).hexdigest()[:20]
    return PHOTO_DIR / f"{name}.jpg"


def prepare(item):
    """Das Foto als JPEG im Cache ablegen; liefert den Pfad."""
    target = photo_file(item)
    if target.is_file():
        return target
    key = item["k"]
    data = None
    if key.startswith("i:"):
        values = settings()
        immich.configure(values["ServerUrl"], values["ApiKey"])
        raw, _kind = immich.photo(key[2:], size="preview")
        try:
            data, _size = shrink(raw)
        except Exception:  # noqa: BLE001 - dann so, wie Immich es schickt
            data = raw
    else:
        path = key_path(key)
        local = path and os.path.isfile(path)
        if local and (path.lower().endswith(SHOWABLE) or HEIF):
            try:
                data, _size = shrink(path)
            except Exception as exc:  # noqa: BLE001 - kaputte Datei: über die Engine
                log(f"Foto {path}: {exc}", "warning")
        if data is None and path.startswith("/webdav-media/"):
            cached = webdav_cached(path, str(item.get("stamp") or "").split(":")[0])
            if cached:
                try:
                    data, _size = shrink(str(cached))
                except Exception:  # noqa: BLE001
                    data = None
        if data is None and key.startswith("d:"):
            raw = engine_image(key[2:].partition("|")[0], path)
            try:
                data, _size = shrink(raw)
            except Exception:  # noqa: BLE001
                data = raw
        if data is None:
            raise sources.SourceError("Foto nicht gefunden")
    PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(f".{threading.get_ident()}.tmp")
    temp.write_bytes(data)
    temp.replace(target)
    return target



# --------------------------------------------------------------------------
# Playlist für die Szene
# --------------------------------------------------------------------------

def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=(PLAYLIST_NAME,) + OLD_PLAYLIST_NAMES,
    name=lambda: PLAYLIST_NAMES.get(settings()["Language"], PLAYLIST_NAMES["en"]),
    description=lambda: tr("Alte Fotos und was in dem Jahr in der Welt los war."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()



# --------------------------------------------------------------------------
# Was die Szene bekommt
# --------------------------------------------------------------------------

SCENE_SETTINGS = ("Language", "Layout", "PhotoSeconds", "FadeSeconds", "KenBurns", "ShowPlace", "ShowEvents",
                  "ShowHit", "ShowLeader", "ShowPrices", "ShowBorn", "ShowAges", "EventCount")


def public_visit(visit):
    if not visit:
        return None
    return {k: visit[k] for k in ("id", "year", "ago", "total", "country", "lang", "photos", "facts")}


def scene_payload(query):
    values = settings()
    done = (query.get("done") or [""])[0]
    if done:
        advance(done)
    current = _visits["current"]
    return {
        "success": True,
        "settings": {k: values[k] for k in SCENE_SETTINGS},
        "busy": _visits["busy"] or _index["busy"],
        "visit": public_visit(current),
        "upcoming": bool(_visits["upcoming"]),
        "sources": len(values["Sources"]),
        "minYears": values["MinYearsAgo"],
        "today": datetime.date.today().isoformat(),
    }


def portrait_bytes(query):
    name = (query.get("f") or [""])[0]
    allowed = {(p.get("leader") or {}).get("image") for v in list(_visits["byId"].values()) for p in v["photos"]}
    allowed |= {((v["facts"].get("leader") or {}).get("image")) for v in list(_visits["byId"].values())}
    if not name or name not in allowed:
        return None
    return almanac_db.portrait(name)


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    status = {}
    for source in values["Sources"]:
        row = dict(_index["status"].get(source["id"]) or {})
        if source["kind"].startswith("immich") and not row:
            row = {"state": "error", "error": _visits["error"]} if _visits["error"] else {"state": "ok"}
        if (_index["busy"] or _visits["busy"]) and not row:
            row = {"state": "wait"}
        row["kind"] = source["kind"]
        status[source["id"]] = row
    current, upcoming = _visits["current"], _visits["upcoming"]
    years = sorted(dynaframe_years(values))
    preview = None
    if current:
        facts = current["facts"]
        preview = {"id": current["id"], "year": current["year"], "photos": len(current["photos"]),
                   "events": len(facts.get("events") or []), "hit": bool(facts.get("hitYear")),
                   "leader": (facts.get("leader") or {}).get("name") or "",
                   "prices": len(facts.get("prices") or [])}
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "status": status,
        "busy": _index["busy"] or _visits["busy"],
        "progress": _index["progress"],
        "indexAt": _index["at"],
        "indexed": len(_index["rows"]),
        "dfCount": _index.get("dfCount"),
        "undated": _index["undated"],
        "oldYears": len(years),
        "firstYear": years[0] if years else None,
        "current": preview,
        "upcoming": upcoming["year"] if upcoming else None,
        "country": country_of(values),
        "dataError": almanac_db.last_error,
        "heif": HEIF,
        "theme": {"id": theme_id()},
    }

def test_immich():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        info = immich.test()
    except sources.SourceError as exc:
        return {"success": True, "ok": False, "message": str(exc)}
    return {"success": True, "ok": True,
            "message": tr("Verbunden als {user} (Immich {version}).", user=info["user"] or "?",
                          version=info["version"] or "?")}


def list_albums():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, "albums": immich.albums()}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_immich(what):
    """Personen bzw. Tags für die Immich-Filter."""
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, what: getattr(immich_filters, what)(immich)}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_playlists():
    try:
        rows = [p for p in dynaframe.playlists() if p["name"] not in (PLAYLIST_NAME,) + OLD_PLAYLIST_NAMES]
        return {"success": True, "playlists": sorted(rows, key=lambda p: str(p["name"]).lower())}
    except EngineError as exc:
        return {"success": False, "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc)}


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(query), cors=True)
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            if path == "/api/photo":
                found = photo_bytes(query)
                if found is None:
                    self._json({"success": False}, 404, cors=True)
                else:
                    self._send(found, "image/jpeg", cache="private, max-age=86400", cors=True)
                return
            if path == "/api/albums":
                self._json(list_albums())
                return
            if path in ("/api/people", "/api/tags"):
                self._json(list_immich(path.rsplit("/", 1)[1]))
                return
            if path == "/api/playlists":
                self._json(list_playlists())
                return
            if path == "/api/portrait":
                found = portrait_bytes(query)
                if found is None:
                    self._json({"success": False}, 404, cors=True)
                else:
                    self._send(found, "image/jpeg", cache="private, max-age=604800", cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                for name in SECRETS:
                    # Ein leeres Feld heißt: das alte behalten. Löschen geht mit "-".
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)
                    elif name in body and str(body[name]).strip() == "-":
                        body[name] = ""
                changed = save_settings(body)
                if "MakePlaylist" in changed:
                    OWN.changed()
                if changed:
                    if any(n in changed for n in ("Albums", *immich_filters.SCHEMA)):
                        _immich_cache.clear()
                        _visits["immichYears"] = None
                    _wake.set()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(reload_now())
                return
            if path == "/api/test":
                self._json(test_immich())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            if path == "/api/next":
                self._json(next_year())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}" + ("" if HEIF else " (ohne HEIC-Unterstützung, HEIC über die Engine)"))

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: reload_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())
    plugin.on_action("next", lambda _context=None: next_year())

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    adopt_immich()
    try:
        os.nice(5)   # das Einlesen soll die Wiedergabe nicht stören
    except OSError:
        pass
    threading.Thread(target=work_loop, name=f"{PLUGIN_ID}-work", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _work_stop.set()
    _wake.set()
    try:
        exif_save()
    except Exception:
        pass
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
