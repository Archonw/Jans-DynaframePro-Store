"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/WikipediaBreathes/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["PlaylistSeconds"];
const CHECK_FIELDS = ["Ticker", "Panel", "LanguageLabels"];
const SELECT_FIELDS = ["Region", "Bots", "Pages", "PerSecond", "Glow"];
let current = null;
let editing = false;

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["Wikipedia Breathes", "Wikipedia Breathes", "Wikipedia Breathes"],
  lede: ["Jede Änderung an Wikipedia weltweit kommt live als Datenstrom, viele pro Sekunde. Die Szene macht aus jeder Änderung einen Lichtpunkt am Ort ihrer Sprache: groß bei viel Text, rot, wenn Text entfernt oder eine Seite gelöscht wurde, mit goldenem Ring bei neuen Artikeln. Unten läuft die Zeile „Gerade bearbeitet: …“ mit. Jede Änderung hier wird sofort gespeichert.",
    "Every change to Wikipedia worldwide arrives live as a stream, many per second. The scene turns each change into a point of light where its language is spoken: big for much text, red when text was removed or a page was deleted, with a golden ring for new articles. Below, the line “Being edited now: …” runs along. Every change here is saved immediately.",
    "Cada cambio en Wikipedia en todo el mundo llega en directo como un flujo de datos, muchos por segundo. La escena convierte cada cambio en un punto de luz donde se habla su idioma: grande si hay mucho texto, rojo si se quitó texto o se borró una página, con un anillo dorado para los artículos nuevos. Abajo corre la línea «Editando ahora: …». Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  test: ["Datenstrom testen", "Test the live stream", "Probar la transmisión"],
  testing: ["Verbindet sich für eine Minute mit dem Datenstrom …", "Connecting to the live stream for one minute …", "Conectando con la transmisión durante un minuto …"],
  factStream: ["Datenstrom", "Live stream", "Transmisión"],
  factPerMin: ["Änderungen pro Minute", "Changes per minute", "Cambios por minuto"],
  factLangs: ["Sprachen gerade aktiv", "Languages active now", "Idiomas activos ahora"],
  factNew: ["Neue Artikel", "New articles", "Artículos nuevos"],
  factVersion: ["Version", "Version", "Versión"],
  stLive: ["Verbunden", "Connected", "Conectada"],
  stConnecting: ["Verbindet …", "Connecting …", "Conectando …"],
  stPaused: ["Pausiert (Szene nicht zu sehen)", "Paused (scene not on screen)", "En pausa (la escena no está en pantalla)"],
  stError: ["Gestört", "Disrupted", "Interrumpida"],
  sinceMin: ["{n} seit {time}", "{n} since {time}", "{n} desde las {time}"],
  errorNote: ["Der Datenstrom von Wikipedia ist gerade nicht erreichbar ({error}). Das Plugin versucht es weiter. Mit Pi-hole: stream.wikimedia.org freigeben.",
    "The Wikipedia live stream cannot be reached right now ({error}). The plugin keeps trying. Using Pi-hole? Allow stream.wikimedia.org.",
    "No se puede acceder a la transmisión de Wikipedia ahora mismo ({error}). El plugin lo sigue intentando. ¿Usas Pi-hole? Permite stream.wikimedia.org."],
  streamHint: ["Das Plugin liest den Datenstrom nur, solange die Szene zu sehen ist (oder eine Minute nach „Datenstrom testen“). Rund um die Uhr wären das mehrere Gigabyte am Tag. Wer Pi-hole oder einen anderen Werbeblocker nutzt, muss stream.wikimedia.org freigeben.",
    "The plugin only reads the live stream while the scene is on screen (or for one minute after “Test the live stream”). Around the clock that would be several gigabytes a day. If you use Pi-hole or another ad blocker, allow stream.wikimedia.org.",
    "El plugin solo lee la transmisión mientras la escena está en pantalla (o un minuto después de «Probar la transmisión»). Todo el día serían varios gigabytes. Si usas Pi-hole u otro bloqueador, permite stream.wikimedia.org."],
  topTitle: ["Die fleißigsten Sprachen der letzten 5 Minuten", "The busiest languages of the last 5 minutes", "Los idiomas más activos de los últimos 5 minutos"],
  perMinShort: ["{n} pro Minute", "{n} per minute", "{n} por minuto"],
  showTitle: ["Was die Szene zeigt", "What the scene shows", "Qué muestra la escena"],
  region: ["Kartenausschnitt", "Map area", "Zona del mapa"],
  regionWorld: ["Ganze Welt", "Whole world", "Todo el mundo"],
  regionEurope: ["Europa", "Europe", "Europa"],
  regionAmericas: ["Amerika", "Americas", "América"],
  regionAsia: ["Asien", "Asia", "Asia"],
  regionAfrica: ["Afrika und Nahost", "Africa and Middle East", "África y Oriente Medio"],
  bots: ["Änderungen von Bots", "Changes by bots", "Cambios de bots"],
  botsShow: ["Normal zeigen", "Show normally", "Mostrar normal"],
  botsDim: ["Blass zeigen", "Show faintly", "Mostrar tenue"],
  botsHide: ["Weglassen", "Leave out", "Omitir"],
  pages: ["Welche Seiten", "Which pages", "Qué páginas"],
  pagesAll: ["Alle (auch Diskussionen, Benutzerseiten …)", "All (also talk pages, user pages …)", "Todas (también discusiones, páginas de usuario …)"],
  pagesArticles: ["Nur Artikel", "Articles only", "Solo artículos"],
  perSecond: ["Lichtpunkte pro Sekunde höchstens", "Points of light per second at most", "Puntos de luz por segundo como máximo"],
  ps10: ["10 (ruhig, schont den Pi)", "10 (calm, easy on the Pi)", "10 (tranquilo, cuida la Pi)"],
  ps20: ["20", "20", "20"],
  ps40: ["40", "40", "40"],
  ps80: ["80 (jede Änderung, nur für schnelle Rahmen)", "80 (every change, fast frames only)", "80 (cada cambio, solo marcos rápidos)"],
  glow: ["Wie lange ein Punkt nachleuchtet", "How long a point keeps glowing", "Cuánto brilla un punto"],
  glow4: ["4 Sekunden", "4 seconds", "4 segundos"],
  glow8: ["8 Sekunden", "8 seconds", "8 segundos"],
  glow15: ["15 Sekunden", "15 seconds", "15 segundos"],
  glow30: ["30 Sekunden", "30 seconds", "30 segundos"],
  showHint: ["Kommen mehr Änderungen, als Lichtpunkte erlaubt sind, behält das Plugin die großen, die neuen Artikel und die Löschungen und dünnt den Rest gleichmäßig aus. Gezählt wird trotzdem jede Änderung. Der Ort ist der Sprachraum, nicht der Ort der Person, die bearbeitet: Englisch leuchtet in den USA, Großbritannien, Indien und Australien, Spanisch in Spanien und Lateinamerika.",
    "If more changes arrive than points of light are allowed, the plugin keeps the big ones, new articles and deletions and thins out the rest evenly. Every change is still counted. The place is where the language is spoken, not where the editor is: English lights up in the US, the UK, India and Australia, Spanish in Spain and Latin America.",
    "Si llegan más cambios de los puntos permitidos, el plugin conserva los grandes, los artículos nuevos y los borrados, y reduce el resto de forma uniforme. Aun así se cuenta cada cambio. El lugar es donde se habla el idioma, no donde está quien edita: el inglés brilla en EE. UU., Reino Unido, India y Australia; el español en España y Latinoamérica."],
  lookTitle: ["Einblendungen", "Overlays", "Elementos en pantalla"],
  ticker: ["Laufzeile „Gerade bearbeitet: …“ mit Artikelnamen", "Ticker “Being edited now: …” with article names", "Línea «Editando ahora: …» con nombres de artículos"],
  panel: ["Seitenleiste mit Änderungen pro Minute, Atemkurve und den fleißigsten Sprachen", "Side panel with changes per minute, breathing curve and the busiest languages", "Panel lateral con cambios por minuto, curva de respiración y los idiomas más activos"],
  languageLabels: ["Die aktivsten Sprachen auf der Karte beschriften", "Label the most active languages on the map", "Rotular en el mapa los idiomas más activos"],
  lookHint: ["Die Laufzeile zeigt nur Artikel, keine Bots, und bevorzugt große Änderungen und neue Artikel. Artikelnamen kommen ungefiltert aus Wikipedia.",
    "The ticker only shows articles, no bots, and prefers big changes and new articles. Article names come unfiltered from Wikipedia.",
    "La línea solo muestra artículos, sin bots, y prefiere cambios grandes y artículos nuevos. Los nombres vienen de Wikipedia sin filtrar."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  oclock: ["{time} Uhr", "{time}", "{time}"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „Wikipedia Breathes“ anlegen", "Create the playlist “Wikipedia Breathes”", "Crear la lista «Wikipedia Breathes»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la lista (segundos)"],
  playlistHint: ["Die Playlist enthält nur die Szene und ist eingeschaltet. Die Dauer gilt beim Anlegen; danach änderst du sie in der Playlist selbst. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist holds only the scene and is switched on. The duration applies when it is created; after that you change it in the playlist itself. You can also add the scene to any playlist yourself.",
    "La lista contiene solo la escena y está activada. La duración se aplica al crearla; después la cambias en la propia lista. También puedes añadir la escena a cualquier lista."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(epoch) {
  if (!epoch) return "—";
  const date = new Date(epoch * 1000);
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

const esc = (text) => String(text).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang]);

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

let names = null;
function langName(code) {
  try {
    if (!names || names.lang !== lang) names = { lang, dn: new Intl.DisplayNames([LOCALES[lang]], { type: "language" }) };
    const alias = { "zh-yue": "yue", "zh-min-nan": "nan", "zh-classical": "lzh", simple: "en", als: "gsw" }[code] || code;
    const name = names.dn.of(alias);
    const text = name && name !== alias ? name.charAt(0).toLocaleUpperCase(LOCALES[lang]) + name.slice(1) : code;
    return code === "simple" ? text + " (Simple)" : text;
  } catch (_) {
    return code;
  }
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  const st = state.stats || {};
  const live = Boolean(st.liveFor);
  el("factStream").textContent = t({ live: "stLive", connecting: "stConnecting", error: "stError" }[state.state] || "stPaused");
  el("factPerMin").textContent = live ? fmt(st.perMin) : "—";
  el("factLangs").textContent = live ? fmt(st.langCount) : "—";
  const since = live ? clock(Date.now() / 1000 - st.liveFor) : "";
  el("factNew").textContent = live ? t("sinceMin", { n: fmt(st.newPages), time: since }) : "—";
  el("factVersion").textContent = state.version;
  if (state.state === "error" && state.error) setStatus(t("errorNote", { error: state.error }), "bad");
  else if (el("statusNote").classList.contains("bad")) setStatus("");
  const top = live ? (st.langs || []).slice(0, 8) : [];
  const minutes = Math.min(5, Math.max(1 / 6, st.liveFor / 60));
  el("topBox").hidden = !top.length;
  el("topList").innerHTML = top.map(([code, n]) =>
    `<li><span>${esc(langName(code))}<span class="w">${esc(code)}.wikipedia.org</span></span><span class="v">${esc(t("perMinShort", { n: fmt(Math.round(n / minutes)) }))}</span></li>`).join("");
  if (document.activeElement !== el("MakePlaylist")) el("MakePlaylist").value = String(Boolean(s.MakePlaylist));
  el("playlistNote").textContent = state.ownPlaylist || "";
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Wikipedia Breathes ${state.version}] `);
  if (!editing) {
    for (const name of NUMBER_FIELDS) if (document.activeElement !== el(name)) el(name).value = s[name];
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) if (document.activeElement !== el(name)) el(name).value = String(s[name]);
    el("Language").value = lang;
  }
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
  input.addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
}
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save({ Language: e.target.value });
});
el("testButton").addEventListener("click", async () => {
  try {
    await api("./api/test", { method: "POST" });
    setStatus(t("testing"), "busy");
    setTimeout(refresh, 3000);
  } catch (error) {
    setStatus(error.message, "bad");
  }
});
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));

refresh();
setInterval(refresh, 4000);
