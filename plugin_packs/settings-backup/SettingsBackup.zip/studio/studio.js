"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/SettingsBackup/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
let current = null;
let overview = null;

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  title: ["Einstellungen sichern", "Settings Backup", "Copia de ajustes"],
  lede: ["Sichert die Einstellungen aller Plugins und Szenen in eine Datei. Mit dieser Datei stellst du sie später wieder her oder überträgst sie auf einen anderen Rahmen.",
    "Saves the settings of all plugins and scenes to a file. Use that file to restore them later or to move them to another frame.",
    "Guarda los ajustes de todos los plugins y escenas en un archivo. Con ese archivo los restauras más tarde o los pasas a otro marco."],
  language: ["Sprache", "Language", "Idioma"],
  loading: ["Lade …", "Loading …", "Cargando …"],
  exportTitle: ["Sichern", "Back up", "Guardar"],
  selectAll: ["Alle", "All", "Todos"],
  selectNone: ["Keine", "None", "Ninguno"],
  exportHint: ["Wähle, was in die Datei soll. Dinge, die nur zu diesem Rahmen gehören (Takeover-Playlists, Zwischenspeicher, Fotos, gekoppelte Handys), bleiben weg; die Plugins legen sie auf dem neuen Rahmen selbst an.",
    "Choose what goes into the file. Things that only belong to this frame (takeover playlists, caches, photos, paired phones) are left out; the plugins create them again on the new frame.",
    "Elige qué va en el archivo. Lo que solo pertenece a este marco (listas de takeover, cachés, fotos, móviles vinculados) se queda fuera; los plugins lo vuelven a crear en el marco nuevo."],
  noPlugins: ["Keine anderen Plugins installiert.", "No other plugins installed.", "No hay otros plugins instalados."],
  pluginSub: ["Version {version} · {settings} Einstellungen auf der Plugins-Seite · {files} Dateien", "Version {version} · {settings} settings on the Plugins page · {files} files", "Versión {version} · {settings} ajustes en la página Plugins · {files} archivos"],
  secretsBadge: ["{n} Zugangsdaten", "{n} secrets", "{n} credenciales"],
  offBadge: ["aus", "off", "apagado"],
  skippedSummary: ["{n} Dateien bleiben auf diesem Rahmen", "{n} files stay on this frame", "{n} archivos se quedan en este marco"],
  reason_frame: ["gehört zu diesem Rahmen", "belongs to this frame", "pertenece a este marco"],
  reason_runtime: ["Zwischenspeicher", "cache", "caché"],
  reason_media: ["Bild/Video/Datenbank", "picture/video/database", "imagen/vídeo/base de datos"],
  reason_large: ["zu groß", "too large", "demasiado grande"],
  scenes: ["Einstellungen der Szenen ({n})", "Scene settings ({n})", "Ajustes de las escenas ({n})"],
  password: ["Passwort (freiwillig)", "Password (optional)", "Contraseña (opcional)"],
  password2: ["Passwort wiederholen", "Repeat password", "Repetir contraseña"],
  hintWithPw: ["Mit Passwort: Die Datei wird verschlüsselt und enthält auch API-Schlüssel, Passwörter und Tokens. Ohne das Passwort lässt sie sich nicht öffnen – gut merken.",
    "With a password: the file is encrypted and also holds API keys, passwords and tokens. It cannot be opened without the password, so keep it safe.",
    "Con contraseña: el archivo se cifra e incluye también claves API, contraseñas y tokens. No se puede abrir sin la contraseña; guárdala bien."],
  hintNoPw: ["Ohne Passwort fehlen API-Schlüssel, Passwörter und Tokens ({n} Stück); die trägst du auf dem neuen Rahmen neu ein. Mit Passwort sind sie verschlüsselt dabei.",
    "Without a password, API keys, passwords and tokens ({n}) are left out; you enter them again on the new frame. With a password they are included, encrypted.",
    "Sin contraseña faltan claves API, contraseñas y tokens ({n}); los vuelves a introducir en el marco nuevo. Con contraseña van incluidos, cifrados."],
  exportButton: ["Sicherung herunterladen", "Download backup", "Descargar copia"],
  pwMismatch: ["Die beiden Passwörter sind nicht gleich.", "The two passwords do not match.", "Las dos contraseñas no coinciden."],
  nothingChosen: ["Nichts ausgewählt.", "Nothing selected.", "Nada seleccionado."],
  exporting: ["Sicherung wird erstellt …", "Creating backup …", "Creando la copia …"],
  exported: ["Fertig: {plugins} Plugins, {scenes} Szenen, {size}{enc}.", "Done: {plugins} plugins, {scenes} scenes, {size}{enc}.", "Listo: {plugins} plugins, {scenes} escenas, {size}{enc}."],
  encrypted: [", verschlüsselt", ", encrypted", ", cifrado"],
  importTitle: ["Zurückspielen", "Restore", "Restaurar"],
  importHint: ["Installiere auf dem neuen Rahmen zuerst die Plugins aus dem Store und dieses Plugin. Plugins, die aus keinem Store kommen, installiert es selbst. Dann hier die Datei öffnen und übernehmen.",
    "On the new frame, first install the plugins from the Store and this plugin. Plugins that did not come from a store are installed by this plugin. Then open the file here and apply it.",
    "En el marco nuevo instala primero los plugins desde la Store y este plugin. Los plugins que no vienen de una Store los instala este plugin. Después abre aquí el archivo y aplícalo."],
  file: ["Sicherungsdatei", "Backup file", "Archivo de copia"],
  importPassword: ["Passwort der Datei", "Password of the file", "Contraseña del archivo"],
  openButton: ["Datei öffnen", "Open file", "Abrir archivo"],
  noFile: ["Bitte zuerst eine Datei wählen.", "Choose a file first.", "Elige primero un archivo."],
  opening: ["Datei wird gelesen …", "Reading file …", "Leyendo archivo …"],
  pendingHead: ["Sicherung von „{frame}“ vom {date}", "Backup of “{frame}” from {date}", "Copia de «{frame}» del {date}"],
  sameFrame: [" (dieser Rahmen)", " (this frame)", " (este marco)"],
  pendingSecretsYes: ["Mit Zugangsdaten.", "Includes secrets.", "Incluye credenciales."],
  pendingSecretsNo: ["Ohne Zugangsdaten: API-Schlüssel und Passwörter, die hier schon eingetragen sind, bleiben stehen.",
    "Without secrets: API keys and passwords already entered here are kept.",
    "Sin credenciales: las claves API y contraseñas ya introducidas aquí se mantienen."],
  installedBadge: ["installiert {version}", "installed {version}", "instalado {version}"],
  otherVersion: ["(Sicherung: {version})", "(backup: {version})", "(copia: {version})"],
  missingBadge: ["fehlt hier", "not installed here", "no instalado aquí"],
  missingHint: ["Zuerst im Store installieren: „{title}“{store}. Danach diese Seite neu laden und übernehmen.",
    "Install it from the Store first: “{title}”{store}. Then reload this page and apply.",
    "Instálalo primero desde la Store: «{title}»{store}. Después recarga esta página y aplica."],
  fromStore: [" aus {store}", " from {store}", " de {store}"],
  missingNoStore: ["Dieses Plugin ist hier nicht installiert.", "This plugin is not installed here.", "Este plugin no está instalado aquí."],
  importSub: ["{settings} Einstellungen · {files} Dateien", "{settings} settings · {files} files", "{settings} ajustes · {files} archivos"],
  sceneMissing: ["Szene fehlt hier", "scene not installed here", "escena no instalada aquí"],
  sceneRow: ["Szene", "Scene", "Escena"],
  setEnabled: ["Plugins so ein- und ausschalten wie auf dem alten Rahmen", "Switch plugins on and off as on the old frame", "Encender y apagar los plugins como en el marco anterior"],
  applyButton: ["Übernehmen", "Apply", "Aplicar"],
  discardButton: ["Datei schließen", "Close file", "Cerrar archivo"],
  applying: ["Wird übernommen …", "Applying …", "Aplicando …"],
  confirmApply: ["Die gewählten Einstellungen auf diesem Rahmen überschreiben? Mit „Rückgängig“ kommt der jetzige Stand zurück.",
    "Overwrite the chosen settings on this frame? “Undo” brings back the current state.",
    "¿Sobrescribir los ajustes elegidos en este marco? «Deshacer» recupera el estado actual."],
  resultTitle: ["Ergebnis", "Result", "Resultado"],
  resultDone: ["{name}: übernommen ({files} Dateien, {settings} Werte der Plugins-Seite)", "{name}: applied ({files} files, {settings} Plugins page values)", "{name}: aplicado ({files} archivos, {settings} valores de la página Plugins)"],
  resultKept: [", {n} Zugangsdaten unverändert", ", {n} secrets unchanged", ", {n} credenciales sin cambios"],
  resultMissing: ["{name}: nicht installiert, übersprungen", "{name}: not installed, skipped", "{name}: no instalado, omitido"],
  resultError: ["{name}: Fehler – {error}", "{name}: error – {error}", "{name}: error – {error}"],
  sceneDone: ["Szene {name}: übernommen", "Scene {name}: applied", "Escena {name}: aplicada"],
  sceneMissingResult: ["Szene {name}: nicht installiert, übersprungen", "Scene {name}: not installed, skipped", "Escena {name}: no instalada, omitida"],
  sceneError: ["Szene {name}: die Engine hat die Einstellungen nicht angenommen", "Scene {name}: the Engine did not accept the settings", "Escena {name}: el Engine no aceptó los ajustes"],
  packsTitle: ["Fehlende Stores und Store-Pakete", "Missing stores and store packs", "Stores y paquetes que faltan"],
  storeRow: ["Store", "Store", "Store"],
  storeOff: ["auf dem alten Rahmen ausgeschaltet", "switched off on the old frame", "apagada en el marco anterior"],
  packsHint: ["Diese Stores und Pakete gab es auf dem alten Rahmen, hier fehlen sie. Stores kommen in die Store-Liste, Pakete werden aus ihrem Store installiert (in der Version, die er heute anbietet; fehlt ihr Store hier, wird er mit angelegt). Danach unten die Einstellungen übernehmen.",
    "These stores and packs were on the old frame and are missing here. Stores are added to the store list, packs are installed from their store (the version it offers today; a missing store is added along the way). Then apply the settings below.",
    "Estas Stores y paquetes estaban en el marco anterior y faltan aquí. Las Stores se añaden a la lista, los paquetes se instalan desde su Store (la versión que ofrece hoy; si falta la Store, se añade). Después aplica los ajustes abajo."],
  pluginsTitle: ["Einstellungen", "Settings", "Ajustes"],
  installPacks: ["Ausgewählte installieren", "Install selected", "Instalar lo elegido"],
  packSub: ["{type} · Sicherung: {version} · aus {store}", "{type} · backup: {version} · from {store}", "{type} · copia: {version} · de {store}"],
  packUnsupported: ["Diesen Pakettyp kann das Plugin nicht installieren; bitte im Store installieren.", "This plugin cannot install this kind of pack; please install it in the Store.", "Este plugin no puede instalar este tipo de paquete; instálalo en la Store."],
  packsNoStore: ["Die Store-Liste dieses Rahmens war nicht zu erreichen; fehlende Pakete bitte im Store installieren.", "This frame's store list could not be reached; please install missing packs in the Store.", "No se pudo acceder a la lista de la Store de este marco; instala los paquetes que faltan en la Store."],
  packsRunning: ["Installiere {n} von {total}: {title} … (kann ein paar Minuten dauern)", "Installing {n} of {total}: {title} … (can take a few minutes)", "Instalando {n} de {total}: {title} … (puede tardar unos minutos)"],
  packsDone: ["Fertig: {ok} installiert{failed}. Jetzt unten „Übernehmen“.", "Done: {ok} installed{failed}. Now press “Apply” below.", "Listo: {ok} instalados{failed}. Ahora pulsa «Aplicar» abajo."],
  packsFailed: [", {n} fehlgeschlagen ({list})", ", {n} failed ({list})", ", {n} fallidos ({list})"],
  missingFromStore: ["Fehlt hier; oben bei „Fehlende Stores und Store-Pakete“ installieren.", "Missing here; install it above under “Missing stores and store packs”.", "Falta aquí; instálalo arriba en «Stores y paquetes que faltan»."],
  err_busy: ["Es läuft schon eine Installation.", "An installation is already running.", "Ya hay una instalación en curso."],
  err_no_store: ["Der Store dieses Rahmens antwortet nicht.", "This frame's store does not answer.", "La Store de este marco no responde."],
  err_nothing: ["Nichts ausgewählt.", "Nothing selected.", "Nada seleccionado."],
  liveHint: ["Fertig. Die Einstellungen sind übernommen und die betroffenen Plugins neu gestartet. Neu installierte Plugins richten sich im Hintergrund ein (das kann ein paar Minuten dauern).",
    "Done. The settings are applied and the affected plugins restarted. Newly installed plugins set themselves up in the background (this can take a few minutes).",
    "Listo. Los ajustes están aplicados y los plugins afectados reiniciados. Los plugins recién instalados se preparan en segundo plano (puede tardar unos minutos)."],
  codeLabel: ["Plugins, die aus keinem Store kommen, samt Programm mitnehmen ({names})", "Include plugins that did not come from a store, with their program ({names})", "Incluir los plugins que no vienen de una Store, con su programa ({names})"],
  noStoreBadge: ["ohne Store · Programm {size}", "no store · program {size}", "sin Store · programa {size}"],
  installBadge: ["wird installiert", "will be installed", "se instalará"],
  installHint: ["Kommt aus keinem Store; das Programm ist in der Sicherung und wird hier installiert.", "Did not come from a store; the program is in the backup and will be installed here.", "No viene de una Store; el programa está en la copia y se instalará aquí."],
  resultInstalled: ["{name}: installiert und eingerichtet ({files} Dateien)", "{name}: installed and set up ({files} files)", "{name}: instalado y configurado ({files} archivos)"],
  restartHint: ["Starte DynaFrame jetzt neu (oder den Rahmen), damit alle Plugins die übernommenen Einstellungen laden.",
    "Now restart DynaFrame (or the frame) so all plugins load the applied settings.",
    "Reinicia ahora DynaFrame (o el marco) para que todos los plugins carguen los ajustes aplicados."],
  undoText: ["Vor dem letzten Übernehmen ({date}) wurde der alte Stand gemerkt.", "The previous state was kept before the last restore ({date}).", "Se guardó el estado anterior antes de la última restauración ({date})."],
  undoButton: ["Rückgängig", "Undo", "Deshacer"],
  confirmUndo: ["Den Stand von vor dem letzten Übernehmen wiederherstellen?", "Bring back the state from before the last restore?", "¿Recuperar el estado anterior a la última restauración?"],
  undone: ["Alter Stand wiederhergestellt ({n} Dateien/Szenen/Plugins).", "Previous state restored ({n} files/scenes/plugins).", "Estado anterior restaurado ({n} archivos/escenas/plugins)."],
  err_bad_file: ["Das ist keine Sicherung dieses Plugins.", "This is not a backup made by this plugin.", "Esto no es una copia de este plugin."],
  err_need_password: ["Die Datei ist verschlüsselt. Bitte das Passwort eingeben.", "The file is encrypted. Please enter the password.", "El archivo está cifrado. Introduce la contraseña."],
  err_wrong_password: ["Falsches Passwort.", "Wrong password.", "Contraseña incorrecta."],
  err_too_new: ["Die Datei stammt von einer neueren Version dieses Plugins. Bitte zuerst aktualisieren.", "The file comes from a newer version of this plugin. Please update first.", "El archivo es de una versión más nueva de este plugin. Actualiza primero."],
  err_too_large: ["Die Datei ist zu groß.", "The file is too large.", "El archivo es demasiado grande."],
  err_no_pending: ["Keine Datei geöffnet.", "No file opened.", "Ningún archivo abierto."],
  err_no_undo: ["Es gibt nichts rückgängig zu machen.", "There is nothing to undo.", "No hay nada que deshacer."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}). Gleich noch einmal versuchen.", "The plugin is restarting (HTTP {status}). Try again in a moment.", "El plugin se está reiniciando (HTTP {status}). Inténtalo de nuevo en un momento."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or wishes?", "¿Problemas, preguntas o deseos?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre un issue en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", ", with plugin name and version.", ", con el nombre y la versión del plugin."],
};

const LANGS = ["de", "en", "es"];
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([502, 503, 504].includes(response.status)) {
    throw new Error(t("restarted", { status: response.status }));
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) {
    const key = payload.code ? "err_" + payload.code.replace(/-/g, "_") : "";
    throw new Error(key && I18N[key] ? t(key) : payload.error || t("error", { status: response.status }));
  }
  return payload;
}

function post(path, body) {
  return api(path, { method: "POST", body: JSON.stringify(body || {}) });
}

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

function make(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function badge(text, tone = "") {
  return make("span", `badge${tone ? " " + tone : ""}`, text);
}

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function formatDate(iso) {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso || "—";
  return date.toLocaleString(lang === "en" ? "en-GB" : lang, { dateStyle: "medium", timeStyle: "short" });
}

// --------------------------------------------------------------------------
// Sichern
// --------------------------------------------------------------------------

function chosenExport() {
  return [...document.querySelectorAll("#exportList input[type=checkbox]")].filter((box) => box.checked).map((box) => box.value);
}

function updateSecretHint() {
  if (!overview) return;
  const chosen = new Set(chosenExport());
  const count = overview.plugins.filter((p) => chosen.has(p.name)).reduce((sum, p) => sum + (p.secretCount || 0), 0);
  const noStore = overview.plugins.filter((p) => chosen.has(p.name) && p.code);
  el("codeRow").hidden = !noStore.length;
  el("codeLabel").textContent = t("codeLabel", { names: noStore.map((p) => p.displayName).join(", ") });
  el("secretHint").textContent = el("exportPassword").value ? t("hintWithPw") : t("hintNoPw", { n: count });
}

function renderOverview() {
  const list = el("exportList");
  list.textContent = "";
  if (!overview) return;
  if (!overview.plugins.length) list.appendChild(make("p", "hint", t("noPlugins")));
  for (const p of overview.plugins) {
    const row = make("label", "pick");
    const box = document.createElement("input");
    box.type = "checkbox";
    box.value = p.name;
    box.checked = true;
    box.addEventListener("change", updateSecretHint);
    row.appendChild(box);
    const main = make("div", "pick-main");
    const title = make("div", "pick-title", p.displayName);
    if (!p.enabled) title.appendChild(badge(t("offBadge")));
    if (p.secretCount) title.appendChild(badge(t("secretsBadge", { n: p.secretCount }), "warn"));
    if (p.code) title.appendChild(badge(t("noStoreBadge", { size: formatSize(p.code.bytes) })));
    main.appendChild(title);
    const sub = make("div", "pick-sub", t("pluginSub", { version: p.version || "—", settings: p.settingCount, files: p.files.length }));
    if (p.skipped.length) {
      const details = make("details");
      details.appendChild(make("summary", "", t("skippedSummary", { n: p.skipped.length })));
      const ul = make("ul");
      for (const s of p.skipped) ul.appendChild(make("li", "", `${s.path} – ${t("reason_" + s.reason)}`));
      details.appendChild(ul);
      sub.appendChild(details);
    }
    main.appendChild(sub);
    row.appendChild(main);
    list.appendChild(row);
  }
  el("scenesRow").hidden = !overview.scenes.length;
  el("scenesLabel").textContent = t("scenes", { n: overview.scenes.length });
  updateSecretHint();
}

async function loadOverview() {
  try {
    overview = await api("./api/overview");
    renderOverview();
  } catch (error) {
    el("exportList").textContent = "";
    setStatus(error.message, "bad", "exportNote");
  }
}

function setAll(on) {
  for (const box of document.querySelectorAll("#exportList input[type=checkbox]")) box.checked = on;
  updateSecretHint();
}

el("selectAll").addEventListener("click", () => setAll(true));
el("selectNone").addEventListener("click", () => setAll(false));
el("exportPassword").addEventListener("input", updateSecretHint);

el("exportButton").addEventListener("click", async () => {
  const password = el("exportPassword").value;
  if (password !== el("exportPassword2").value) {
    setStatus(t("pwMismatch"), "bad", "exportNote");
    return;
  }
  const plugins = chosenExport();
  const scenes = !el("scenesRow").hidden && el("exportScenes").checked;
  if (!plugins.length && !scenes) {
    setStatus(t("nothingChosen"), "bad", "exportNote");
    return;
  }
  setStatus(t("exporting"), "busy", "exportNote");
  el("exportButton").disabled = true;
  try {
    const code = !el("codeRow").hidden && el("exportCode").checked;
    const result = await post("./api/export", { password, plugins, scenes, code });
    const blob = new Blob([result.text], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = result.filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(link.href), 10000);
    setStatus(t("exported", { plugins: result.plugins, scenes: result.scenes, size: formatSize(result.bytes),
      enc: result.encrypted ? t("encrypted") : "" }), "ok", "exportNote");
  } catch (error) {
    setStatus(error.message, "bad", "exportNote");
  } finally {
    el("exportButton").disabled = false;
  }
});

// --------------------------------------------------------------------------
// Zurückspielen
// --------------------------------------------------------------------------

function renderPending(pending) {
  el("pendingBox").hidden = !pending;
  if (!pending) return;
  el("pendingHead").textContent = t("pendingHead", { frame: pending.frame || "?", date: formatDate(pending.createdAt) })
    + (pending.sameFrame ? t("sameFrame") : "");
  el("pendingSecrets").textContent = pending.secretsIncluded ? t("pendingSecretsYes") : t("pendingSecretsNo");
  const list = el("importList");
  const before = new Map([...list.querySelectorAll("input[type=checkbox]")].map((box) => [box.value, box.checked]));
  list.textContent = "";
  for (const p of pending.plugins) {
    const usable = p.installed || p.hasCode;
    const row = make("label", `pick${usable ? "" : " off"}`);
    const box = document.createElement("input");
    box.type = "checkbox";
    box.value = p.name;
    box.disabled = !usable;
    box.checked = usable && (before.has(p.name) ? before.get(p.name) : true);
    row.appendChild(box);
    const main = make("div", "pick-main");
    const title = make("div", "pick-title", p.displayName);
    if (p.installed) {
      title.appendChild(badge(t("installedBadge", { version: p.versionHere }), "ok"));
    } else if (p.hasCode) {
      title.appendChild(badge(t("installBadge"), "warn"));
    } else {
      title.appendChild(badge(t("missingBadge"), "bad"));
    }
    main.appendChild(title);
    let subText = t("importSub", { settings: p.settingCount, files: p.fileCount });
    if (p.installed && p.version && p.version !== p.versionHere) subText += " " + t("otherVersion", { version: p.version });
    const sub = make("div", "pick-sub", subText);
    if (!p.installed && p.hasCode) {
      sub.appendChild(document.createElement("br"));
      sub.appendChild(document.createTextNode(t("installHint")));
    } else if (!p.installed && packListed(pending, p.store && p.store.packId)) {
      sub.appendChild(document.createElement("br"));
      sub.appendChild(document.createTextNode(t("missingFromStore")));
    } else if (!p.installed) {
      const store = p.store || null;
      sub.appendChild(document.createElement("br"));
      sub.appendChild(document.createTextNode(store
        ? t("missingHint", { title: store.title || p.displayName, store: store.sourceStore ? t("fromStore", { store: store.sourceStore }) : "" })
        : t("missingNoStore")));
    }
    main.appendChild(sub);
    row.appendChild(main);
    list.appendChild(row);
  }
  const scenes = el("sceneList");
  scenes.textContent = "";
  for (const s of pending.scenes || []) {
    const row = make("label", `pick${s.installed ? "" : " off"}`);
    const box = document.createElement("input");
    box.type = "checkbox";
    box.value = s.id;
    box.disabled = !s.installed;
    box.checked = s.installed;
    row.appendChild(box);
    const main = make("div", "pick-main");
    const title = make("div", "pick-title", `${t("sceneRow")}: ${s.name}`);
    if (!s.installed) title.appendChild(badge(t("sceneMissing"), "bad"));
    main.appendChild(title);
    if (!s.installed && packListed(pending, s.packageId || s.id)) main.appendChild(make("div", "pick-sub", t("missingFromStore")));
    row.appendChild(main);
    scenes.appendChild(row);
  }
}

function packListed(pending, packId) {
  if (!packId || !pending || !Array.isArray(pending.packs)) return false;
  return pending.packs.some((x) => x.packId.toLowerCase() === String(packId).toLowerCase());
}

function renderPacks(pending, job) {
  const box = el("packsBox");
  const packs = pending ? pending.packs : [];
  const missingStores = (pending && pending.stores) || [];
  const running = job && job.running;
  box.hidden = !(packs === null || (packs && packs.length) || missingStores.length || running || (job && job.done && job.done.length));
  if (box.hidden) return;
  const list = el("packList");
  const before = new Map([...list.querySelectorAll("input[type=checkbox]")].map((b) => [b.value, b.checked]));
  list.textContent = "";
  if (packs === null) {
    setStatus(t("packsNoStore"), "bad", "packsNote");
    el("installPacksButton").hidden = true;
    return;
  }
  el("installPacksButton").hidden = !packs.length && !missingStores.length;
  for (const s of missingStores) {
    const value = "store:" + s.manifestUrl;
    const row = make("label", "pick");
    const box3 = document.createElement("input");
    box3.type = "checkbox";
    box3.value = value;
    box3.disabled = running;
    box3.checked = before.has(value) ? before.get(value) : true;
    row.appendChild(box3);
    const main = make("div", "pick-main");
    main.appendChild(make("div", "pick-title", `${t("storeRow")}: ${s.name}`));
    main.appendChild(make("div", "pick-sub", s.manifestUrl + (s.isEnabled ? "" : " · " + t("storeOff"))));
    row.appendChild(main);
    list.appendChild(row);
  }
  for (const p of packs || []) {
    const row = make("label", `pick${p.supported ? "" : " off"}`);
    const box2 = document.createElement("input");
    box2.type = "checkbox";
    box2.value = p.packId;
    box2.disabled = !p.supported || running;
    box2.checked = p.supported && (before.has(p.packId) ? before.get(p.packId) : true);
    row.appendChild(box2);
    const main = make("div", "pick-main");
    main.appendChild(make("div", "pick-title", p.title));
    const sub = make("div", "pick-sub", t("packSub", { type: p.type, version: p.version || "—", store: p.storeName || p.sourceStore || "?" }));
    if (!p.supported) {
      sub.appendChild(document.createElement("br"));
      sub.appendChild(document.createTextNode(t("packUnsupported")));
    }
    main.appendChild(sub);
    row.appendChild(main);
    list.appendChild(row);
  }
  el("installPacksButton").disabled = running;
  if (running) {
    const n = Math.min(job.done.length + 1, job.total);
    setStatus(t("packsRunning", { n, total: job.total, title: job.current }), "busy", "packsNote");
  } else if (job && job.done && job.done.length) {
    const failed = job.done.filter((d) => !d.ok);
    setStatus(t("packsDone", { ok: job.done.length - failed.length,
      failed: failed.length ? t("packsFailed", { n: failed.length, list: failed.map((d) => `${d.title}: ${d.error}`).join("; ") }) : "" }),
      failed.length ? "bad" : "ok", "packsNote");
  }
}

let packTimer = null;

function watchPacks(job) {
  if (job && job.running && !packTimer) {
    packTimer = setInterval(async () => {
      await refresh();
      if (!current || !current.packJob || !current.packJob.running) {
        clearInterval(packTimer);
        packTimer = null;
      }
    }, 3000);
  }
}

el("installPacksButton").addEventListener("click", async () => {
  const chosen = [...document.querySelectorAll("#packList input[type=checkbox]")].filter((b) => b.checked).map((b) => b.value);
  const stores = chosen.filter((v) => v.startsWith("store:")).map((v) => v.slice(6));
  const packs = chosen.filter((v) => !v.startsWith("store:"));
  if (!packs.length && !stores.length) {
    setStatus(t("nothingChosen"), "bad", "packsNote");
    return;
  }
  try {
    await post("./api/install-packs", { packs, stores });
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad", "packsNote");
  }
});

function nameOf(id) {
  const p = current && current.pending && current.pending.plugins.find((x) => x.name === id);
  if (p) return p.displayName;
  const s = current && current.pending && (current.pending.scenes || []).find((x) => x.id === id);
  return s ? s.name : id;
}

function renderResult(result) {
  el("resultBox").hidden = !result;
  if (!result) return;
  const list = el("resultList");
  list.textContent = "";
  for (const r of result.plugins || []) {
    const name = nameOf(r.name);
    if (r.status === "installed") {
      list.appendChild(make("li", "", t("resultInstalled", { name, files: r.files })));
    } else if (r.status === "done") {
      list.appendChild(make("li", "", t("resultDone", { name, files: r.files, settings: r.settings }) + (r.kept ? t("resultKept", { n: r.kept }) : "")));
    } else if (r.status === "missing") {
      list.appendChild(make("li", "warn", t("resultMissing", { name })));
    } else {
      list.appendChild(make("li", "bad", t("resultError", { name, error: r.error })));
    }
  }
  el("resultHint").textContent = result.restartNeeded ? t("restartHint") : t("liveHint");
  for (const s of result.scenes || []) {
    const name = nameOf(s.id);
    const key = s.status === "done" ? "sceneDone" : s.status === "missing" ? "sceneMissingResult" : "sceneError";
    list.appendChild(make("li", s.status === "done" ? "" : s.status === "missing" ? "warn" : "bad", t(key, { name })));
  }
}

function renderUndo(at) {
  el("undoBox").hidden = !at;
  if (at) el("undoText").textContent = t("undoText", { date: formatDate(at) });
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  el("Language").value = state.settings.Language;
  applyLanguage(state.settings.Language);
  renderPending(state.pending);
  renderPacks(state.pending, state.packJob);
  watchPacks(state.packJob);
  renderResult(state.lastResult);
  renderUndo(state.undoAt);
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

function readFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(reader.error || new Error("read failed"));
    reader.readAsText(file);
  });
}

el("openButton").addEventListener("click", async () => {
  const file = el("importFile").files[0];
  if (!file) {
    setStatus(t("noFile"), "bad", "importNote");
    return;
  }
  setStatus(t("opening"), "busy", "importNote");
  try {
    const content = await readFile(file);
    await post("./api/inspect", { content, password: el("importPassword").value });
    el("importPassword").value = "";
    el("importList").textContent = "";
    setStatus("", "", "importNote");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad", "importNote");
  }
});

el("applyButton").addEventListener("click", async () => {
  const plugins = [...document.querySelectorAll("#importList input[type=checkbox]")].filter((b) => b.checked).map((b) => b.value);
  const scenes = [...document.querySelectorAll("#sceneList input[type=checkbox]")].filter((b) => b.checked).map((b) => b.value);
  if (!plugins.length && !scenes.length) {
    setStatus(t("nothingChosen"), "bad", "applyNote");
    return;
  }
  if (!window.confirm(t("confirmApply"))) return;
  setStatus(t("applying"), "busy", "applyNote");
  el("applyButton").disabled = true;
  try {
    await post("./api/apply", { plugins, scenes, setEnabled: el("setEnabled").checked });
    setStatus("", "", "applyNote");
    await refresh();
    el("resultBox").scrollIntoView({ behavior: "smooth", block: "nearest" });
  } catch (error) {
    setStatus(error.message, "bad", "applyNote");
  } finally {
    el("applyButton").disabled = false;
  }
});

el("discardButton").addEventListener("click", async () => {
  try {
    await post("./api/discard");
    el("importFile").value = "";
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad", "applyNote");
  }
});

el("undoButton").addEventListener("click", async () => {
  if (!window.confirm(t("confirmUndo"))) return;
  try {
    const result = await post("./api/undo");
    await refresh();
    setStatus(t("undone", { n: result.restored }), "ok", "statusNote");
  } catch (error) {
    setStatus(error.message, "bad", "undoNote");
  }
});

el("Language").addEventListener("change", async (e) => {
  applyLanguage(e.target.value);
  renderOverview();
  if (current) render({ ...current, settings: { Language: e.target.value } });
  try {
    await post("./api/settings", { Language: e.target.value });
  } catch (error) {
    setStatus(error.message, "bad");
  }
});

refresh().then(loadOverview);
