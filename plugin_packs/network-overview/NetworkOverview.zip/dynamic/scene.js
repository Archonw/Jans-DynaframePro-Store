/* Network Overview (ex Netzwerk-Lagebild) - die Szene.
 *
 * Ein lebendiger Netzplan: oben das Internet, in der Mitte die Fritzbox,
 * daneben Pi-hole(s) und Server, rundherum alle Geräte, gruppiert nach LAN,
 * WLAN und Gästen. Punkte wandern über die Leitungen, so viele, wie gerade
 * los ist: Download und Upload am Internet, DNS-Anfragen an den Geräten,
 * rote Funken an der Pi-hole für jede geblockte Anfrage.
 *
 * Rechts (im Hochformat unten) die Karten Internet, Pi-hole, Server und das
 * Lagebild, das das Plugin auswertet. Die Daten kommen über den Proxy der
 * Weboberfläche auf :8003, wie bei Weltkarte Live.
 *
 * ?plugin=<url> nimmt eine andere Plugin-Adresse (zum Testen), ?lang=en.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "NetworkOverview";
  const POLL_MS = 5000;
  const FPS = 30;
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set([
    `${location.protocol}//${location.hostname}:8003${advanced}`,
    `${location.protocol}//${location.hostname}${advanced}`,
    `${location.origin}${advanced}`,
  ])];
  let baseIndex = 0;

  const COLORS = {
    lan: "#5fb3ff", wlan: "#63e0c0", guest: "#f4b860", other: "#a99cff",
    internet: "#9ad0ff", block: "#ff5d73", ok: "#5fd68a", warn: "#f3c04f", bad: "#ff6b6b",
    text: "#e8eef7", muted: "#8c9bb1", faint: "#5a6a80", node: "#0f1a2c",
  };

  // ------------------------------------------------------------ Texte

  const I18N = {
    de: {
      title: "Network Overview", online: "Geräte online", online1: "Gerät online", internet: "Internet",
      blockedToday: "heute geblockt", of: "{pct} % von {n} Anfragen", today: "Heute", since: "online seit {d}",
      insights: "Lagebild", lan: "LAN", wlan: "WLAN", guest: "Gäste", other: "Sonstige", router: "Router",
      newTag: "NEU", active: "aktiv", sleeping: "schläft", docker: "Docker", ofTotal: "{used} von {total} belegt",
      serverUp: "läuft seit {d}", days: "{n} Tagen", hours: "{n} Std.", oneDay: "1 Tag",
      topBlocked: "Top: {d}", notBlocking: "Blockiert nicht!", nothing: "Noch nichts eingerichtet",
      nothingText: "Trag auf der Plugin-Seite Network Overview deine Pi-hole, Fritzbox und deinen Server ein.",
      noAnswer: "Network Overview antwortet nicht", noAnswerText: "Läuft das Plugin? Es kann nach dem Start eine Minute dauern.",
      weekdays: ["So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"], disconnected: "getrennt", frame: "dieser Rahmen",
      blockedLine: "{n} geblockt", noReply: "antwortet nicht",
    },
    en: {
      title: "Network Overview", online: "devices online", online1: "device online", internet: "Internet",
      blockedToday: "blocked today", of: "{pct} % of {n} queries", today: "Today", since: "online for {d}",
      insights: "What stands out", lan: "LAN", wlan: "Wi-Fi", guest: "Guests", other: "Other", router: "Router",
      newTag: "NEW", active: "active", sleeping: "asleep", docker: "Docker", ofTotal: "{used} of {total} used",
      serverUp: "up for {d}", days: "{n} days", hours: "{n} h", oneDay: "1 day",
      topBlocked: "Top: {d}", notBlocking: "Not blocking!", nothing: "Nothing set up yet",
      nothingText: "Enter your Pi-hole, FRITZ!Box and server on the Network Overview plugin page.",
      noAnswer: "Network Overview does not answer", noAnswerText: "Is the plugin running? It can take a minute after starting.",
      weekdays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], disconnected: "disconnected", frame: "this frame",
      blockedLine: "{n} blocked", noReply: "no answer",
    },
    es: {
      title: "Network Overview", online: "dispositivos en línea", online1: "dispositivo en línea", internet: "Internet",
      blockedToday: "bloqueadas hoy", of: "{pct} % de {n} consultas", today: "Hoy", since: "en línea desde hace {d}",
      insights: "Lo destacado", lan: "LAN", wlan: "Wi-Fi", guest: "Invitados", other: "Otros", router: "Router",
      newTag: "NUEVO", active: "activo", sleeping: "en reposo", docker: "Docker", ofTotal: "{used} de {total} ocupados",
      serverUp: "en marcha desde hace {d}", days: "{n} días", hours: "{n} h", oneDay: "1 día",
      topBlocked: "Top: {d}", notBlocking: "¡No bloquea!", nothing: "Aún sin configurar",
      nothingText: "Introduce tu Pi-hole, FRITZ!Box y servidor en la página del plugin Network Overview.",
      noAnswer: "Network Overview no responde", noAnswerText: "¿Está en marcha el plugin? Puede tardar un minuto tras iniciarse.",
      weekdays: ["dom", "lun", "mar", "mié", "jue", "vie", "sáb"], disconnected: "desconectado", frame: "este marco",
      blockedLine: "{n} bloqueadas", noReply: "no responde",
    },
  };
  let lang = I18N[params.get("lang")] ? params.get("lang") : "de";
  const t = (key, values = {}) => String((I18N[lang] || I18N.de)[key] ?? I18N.de[key] ?? key)
    .replace(/\{(\w+)\}/g, (_, k) => String(values[k] ?? ""));
  const locale = () => ({ de: "de-DE", en: "en-GB", es: "es-ES" }[lang]);
  const num = (n) => Math.round(n || 0).toLocaleString(locale());
  const dec = (n, d = 1) => (n || 0).toLocaleString(locale(), { minimumFractionDigits: d, maximumFractionDigits: d });

  function rateParts(bps) {
    bps = bps || 0;
    if (bps >= 1e9) return [dec(bps / 1e9), "Gbit/s"];
    if (bps >= 1e6) return [dec(bps / 1e6, bps < 1e8 ? 1 : 0), "Mbit/s"];
    return [dec(bps / 1e3, 0), "kbit/s"];
  }
  function size(bytes) {
    bytes = bytes || 0;
    for (const [unit, f] of [["TB", 1e12], ["GB", 1e9], ["MB", 1e6], ["kB", 1e3]]) {
      if (bytes >= f) return `${dec(bytes / f, bytes / f < 100 ? 1 : 0)} ${unit}`;
    }
    return `${Math.round(bytes)} B`;
  }
  function duration(seconds) {
    const days = Math.floor(seconds / 86400);
    if (days >= 2) return t("days", { n: days });
    if (days === 1) return t("oneDay");
    return t("hours", { n: Math.max(1, Math.round(seconds / 3600)) });
  }

  // ------------------------------------------------------------ Zustand

  const canvas = document.getElementById("map");
  const ctx = canvas.getContext("2d");
  const el = (id) => document.getElementById(id);
  const state = {
    insights: [], insightOffset: 0, insightsRotate: false,
    data: null, reachable: true, failures: 0, layout: null, nodes: new Map(), particles: [], sparks: [],
    w: 0, h: 0, dpr: 1, portrait: false, lastFrame: 0, last: performance.now(),
  };

  // ------------------------------------------------------------ Abfrage

  async function poll() {
    const url = new URL("api/scene", pluginBases[baseIndex]);
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 12000);
    try {
      const response = await fetch(url, { cache: "no-store", signal: abort.signal });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      state.data = data;
      state.failures = 0;
      state.reachable = true;
      if (data.settings && I18N[data.settings.Language] && !params.get("lang")) lang = data.settings.Language;
      relayout();
      renderCards();
    } catch (_) {
      state.failures += 1;
      baseIndex = (baseIndex + 1) % pluginBases.length;
      if (state.failures >= 2 * pluginBases.length) {
        state.reachable = false;
        renderCards();
      }
    } finally {
      clearTimeout(timer);
    }
  }

  // ------------------------------------------------------------ Aufteilung

  function resize() {
    state.dpr = Math.min(2, window.devicePixelRatio || 1);
    state.w = window.innerWidth;
    state.h = window.innerHeight;
    canvas.width = Math.round(state.w * state.dpr);
    canvas.height = Math.round(state.h * state.dpr);
    state.portrait = state.h > state.w * 1.05;
    document.body.classList.toggle("portrait", state.portrait);
    relayout();
  }

  /** Wo der Plan liegt: links neben den Karten, im Hochformat darüber. */
  function mapBox() {
    const { w, h } = state;
    const vmin = Math.min(w, h) / 100;
    if (state.portrait) {
      const cards = el("cards").getBoundingClientRect();
      const bottom = cards.height ? cards.top : h * 0.55;
      return { x: 0, y: 11 * vmin, w, h: bottom - 11 * vmin - 1 * vmin };
    }
    const cardsLeft = w - 3 * vmin - w * 0.34;
    return { x: 0, y: 10 * vmin, w: cardsLeft - 1 * vmin, h: h - 12 * vmin };
  }

  const GROUPS = ["lan", "wlan", "guest", "other"];

  function relayout() {
    const data = state.data;
    if (!data || !state.w) return;
    const box = mapBox();
    const vmin = Math.min(state.w, state.h) / 100;
    const cx = box.x + box.w / 2;
    const R = Math.min(box.w / 2 - 9 * vmin, (box.h - 13 * vmin) / 2);
    const cy = box.y + box.h / 2 + 2.5 * vmin;
    const settings = data.settings || {};
    const all = (data.devices || []).filter((d) => d.role !== "pihole" || !(data.pihole && data.pihole.instances || []).length);
    let devices = all.filter((d) => settings.ShowOffline !== false || d.online);
    // Pi-holes und Server stehen innen; die Geräte-Einträge dafür nicht doppelt zeigen.
    const infraIps = new Set(((data.pihole && data.pihole.instances) || []).map((i) => i.ip).filter(Boolean));
    const infraNames = new Set(((data.pihole && data.pihole.instances) || []).map((i) => (i.name || "").toLowerCase()));
    devices = devices.filter((d) => !infraIps.has(d.ip) && !infraNames.has(d.name.toLowerCase()) && d.role !== "server" &&
      !(d.role === "pihole" && infraIps.size));
    devices.sort((a, b) => GROUPS.indexOf(a.conn) - GROUPS.indexOf(b.conn) || a.name.localeCompare(b.name));
    const counts = devices.map((d) => d.count || 0).sort((a, b) => b - a);
    const labelLimit = settings.Labels === "all" ? Infinity : settings.Labels === "none" ? 0 : 14;
    const labelFloor = counts[Math.min(labelLimit, counts.length) - 1] ?? Infinity;

    // Die Geräte im Bogen um die Fritzbox; oben bleibt Platz fürs Internet.
    const gap = 0.55; // halbe Lücke oben, in Radiant
    const start = -Math.PI / 2 + gap, span = 2 * Math.PI - 2 * gap;
    const n = devices.length;
    const twoRings = n > 22;
    const nodes = new Map();
    const groups = {};
    const maxShare = Math.max(0.0001, ...devices.map((d) => d.share || 0));
    devices.forEach((d, i) => {
      const a = start + span * (n === 1 ? 0.5 : i / (n - 1));
      const ring = twoRings && i % 2 ? 0.74 : 1;
      const r = R * ring;
      const size = vmin * (0.9 + 1.5 * Math.sqrt((d.share || 0) / maxShare));
      const labelled = d.new || (labelLimit > 0 && d.online && (d.count || 0) >= labelFloor && (d.count || labelLimit === Infinity));
      nodes.set(d.key, { ...d, x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r, a, r: d.online ? size : vmin * 0.6,
        labelled, outer: ring === 1 });
      (groups[d.conn] = groups[d.conn] || []).push(a);
    });

    // Pi-holes links oben, Server rechts oben, zwischen Fritzbox und Internet.
    const infra = [];
    const instances = (data.pihole && data.pihole.instances) || [];
    if (data.pihole) {
      const list = instances.length ? instances : [{ name: "Pi-hole", active: true, blocking: data.pihole.blocking }];
      list.forEach((p, i) => {
        const a = -Math.PI / 2 - 0.62 - i * 0.62;
        infra.push({ key: `pihole-${i}`, kind: "pihole", name: p.name || "Pi-hole", down: Boolean(p.down),
          active: !p.down && (p.active || list.length === 1),
          blocking: p.blocking !== false, x: cx + Math.cos(a) * R * 0.48, y: cy + Math.sin(a) * R * 0.48, r: vmin * 2.1 });
      });
    }
    if (data.server) {
      const a = -Math.PI / 2 + 0.62;
      infra.push({ key: "server", kind: "server", name: data.server.name || "Server", x: cx + Math.cos(a) * R * 0.48,
        y: cy + Math.sin(a) * R * 0.48, r: vmin * 2.3, used: data.server.total ? data.server.used / data.server.total : 0 });
    }
    state.layout = {
      cx, cy, R, vmin, box, infra, groups,
      router: { x: cx, y: cy, r: vmin * 3.4 },
      internet: { x: cx, y: Math.max(box.y + 5 * vmin, cy - R * 1.02), r: vmin * 2.6 },
    };
    state.nodes = nodes;
  }

  // ------------------------------------------------------------ Teilchen

  function spawn(from, to, color, speed, size = 1) {
    if (state.particles.length > 420) return;
    state.particles.push({ from, to, color, p: 0, speed: speed * (0.8 + Math.random() * 0.4), size });
  }

  function emit(dt) {
    const L = state.layout, data = state.data;
    if (!L || !data) return;
    const internet = data.internet;
    if (internet && internet.connection !== "Disconnected") {
      // Download: bis zu ~14 Punkte pro Sekunde bei voller Leitung, Upload eigen gerechnet.
      const down = internet.maxDown ? Math.min(1, internet.down / internet.maxDown) : Math.min(1, internet.down / 2e8);
      const up = internet.maxUp ? Math.min(1, internet.up / internet.maxUp) : Math.min(1, internet.up / 4e7);
      if (Math.random() < dt * (0.6 + 14 * Math.sqrt(down))) spawn(L.internet, L.router, COLORS.internet, 0.9, 1.3);
      if (Math.random() < dt * (0.3 + 8 * Math.sqrt(up))) spawn(L.router, L.internet, COLORS.wlan, 0.9, 1.1);
    }
    // DNS-Anfragen: ein Punkt pro Gerät etwa so oft, wie es fragt (gedämpft).
    for (const node of state.nodes.values()) {
      if (!node.online) continue;
      const perSecond = (node.count || 0) / 86400;
      if (Math.random() < dt * Math.min(3, 0.05 + perSecond * 1.6)) {
        spawn(node, L.router, COLORS[node.conn] || COLORS.other, 0.55);
      }
    }
    const pi = data.pihole;
    if (pi && L.infra.length) {
      const holes = L.infra.filter((n) => n.kind === "pihole");
      const target = holes.find((h) => h.active) || holes.find((h) => !h.down);
      if (target) {
        if (Math.random() < dt * Math.min(6, 0.2 + (pi.perMinute || 0) / 25)) spawn(L.router, target, "#d7e4f5", 0.8, 0.9);
        if (Math.random() < dt * Math.min(4, 0.05 + (pi.blockedPerMinute || 0) / 8)) {
          state.sparks.push({ x: target.x, y: target.y, t: 0, a: Math.random() * Math.PI * 2 });
        }
      }
    }
  }

  // ------------------------------------------------------------ Zeichnen

  function line(a, b, color, width, dash) {
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.setLineDash(dash || []);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  /** Kleine Symbole, mit Linien gezeichnet, Größe s = Radius des Knotens. */
  function icon(kind, x, y, s, color) {
    ctx.save();
    ctx.translate(x, y);
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = Math.max(1, s * 0.13);
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    const k = s * 0.55;
    switch (kind) {
      case "phone": roundRect(-k * 0.5, -k * 0.85, k, k * 1.7, k * 0.2); ctx.stroke(); break;
      case "tablet": roundRect(-k * 0.75, -k * 0.9, k * 1.5, k * 1.8, k * 0.2); ctx.stroke(); break;
      case "watch": roundRect(-k * 0.5, -k * 0.6, k, k * 1.2, k * 0.3); ctx.stroke(); line({ x: 0, y: -k }, { x: 0, y: -k * 0.6 }, color, ctx.lineWidth); line({ x: 0, y: k * 0.6 }, { x: 0, y: k }, color, ctx.lineWidth); break;
      case "laptop": roundRect(-k * 0.75, -k * 0.65, k * 1.5, k * 1.0, k * 0.1); ctx.stroke(); line({ x: -k, y: k * 0.55 }, { x: k, y: k * 0.55 }, color, ctx.lineWidth); break;
      case "computer": roundRect(-k * 0.85, -k * 0.75, k * 1.7, k * 1.15, k * 0.1); ctx.stroke(); line({ x: 0, y: k * 0.4 }, { x: 0, y: k * 0.8 }, color, ctx.lineWidth); line({ x: -k * 0.4, y: k * 0.8 }, { x: k * 0.4, y: k * 0.8 }, color, ctx.lineWidth); break;
      case "tv": roundRect(-k * 0.95, -k * 0.65, k * 1.9, k * 1.15, k * 0.1); ctx.stroke(); line({ x: -k * 0.4, y: k * 0.8 }, { x: k * 0.4, y: k * 0.8 }, color, ctx.lineWidth); break;
      case "speaker": roundRect(-k * 0.6, -k * 0.85, k * 1.2, k * 1.7, k * 0.25); ctx.stroke(); ctx.beginPath(); ctx.arc(0, k * 0.2, k * 0.35, 0, Math.PI * 2); ctx.stroke(); break;
      case "console": roundRect(-k * 0.95, -k * 0.45, k * 1.9, k * 0.95, k * 0.45); ctx.stroke(); ctx.beginPath(); ctx.arc(k * 0.45, 0, k * 0.12, 0, Math.PI * 2); ctx.fill(); line({ x: -k * 0.65, y: 0 }, { x: -k * 0.25, y: 0 }, color, ctx.lineWidth); line({ x: -k * 0.45, y: -k * 0.2 }, { x: -k * 0.45, y: k * 0.2 }, color, ctx.lineWidth); break;
      case "printer": roundRect(-k * 0.9, -k * 0.3, k * 1.8, k * 0.9, k * 0.1); ctx.stroke(); ctx.strokeRect(-k * 0.5, -k * 0.85, k, k * 0.55); break;
      case "camera": roundRect(-k * 0.9, -k * 0.5, k * 1.8, k * 1.1, k * 0.2); ctx.stroke(); ctx.beginPath(); ctx.arc(0, k * 0.05, k * 0.33, 0, Math.PI * 2); ctx.stroke(); break;
      case "smarthome": ctx.beginPath(); ctx.moveTo(-k * 0.85, -k * 0.05); ctx.lineTo(0, -k * 0.85); ctx.lineTo(k * 0.85, -k * 0.05); ctx.moveTo(-k * 0.6, -k * 0.25); ctx.lineTo(-k * 0.6, k * 0.75); ctx.lineTo(k * 0.6, k * 0.75); ctx.lineTo(k * 0.6, -k * 0.25); ctx.stroke(); break;
      case "server": for (let i = -1; i <= 1; i++) { roundRect(-k * 0.8, i * k * 0.6 - k * 0.25, k * 1.6, k * 0.5, k * 0.1); ctx.stroke(); } break;
      case "board": roundRect(-k * 0.7, -k * 0.7, k * 1.4, k * 1.4, k * 0.15); ctx.stroke(); ctx.fillRect(-k * 0.25, -k * 0.25, k * 0.5, k * 0.5); break;
      case "frame": ctx.strokeRect(-k * 0.85, -k * 0.65, k * 1.7, k * 1.3); ctx.beginPath(); ctx.moveTo(-k * 0.6, k * 0.4); ctx.lineTo(-k * 0.1, -k * 0.15); ctx.lineTo(k * 0.2, k * 0.15); ctx.lineTo(k * 0.6, -k * 0.3); ctx.stroke(); break;
      case "network": for (let i = 1; i <= 3; i++) { ctx.beginPath(); ctx.arc(0, k * 0.6, k * 0.4 * i, -Math.PI * 0.78, -Math.PI * 0.22); ctx.stroke(); } break;
      case "pihole": ctx.beginPath(); ctx.moveTo(0, -k); ctx.lineTo(k * 0.85, -k * 0.6); ctx.quadraticCurveTo(k * 0.8, k * 0.6, 0, k); ctx.quadraticCurveTo(-k * 0.8, k * 0.6, -k * 0.85, -k * 0.6); ctx.closePath(); ctx.stroke(); break;
      case "router": roundRect(-k * 1.0, -k * 0.2, k * 2.0, k * 0.8, k * 0.2); ctx.stroke(); line({ x: -k * 0.6, y: -k * 0.2 }, { x: -k * 0.8, y: -k * 0.9 }, color, ctx.lineWidth); line({ x: k * 0.6, y: -k * 0.2 }, { x: k * 0.8, y: -k * 0.9 }, color, ctx.lineWidth); break;
      case "globe": ctx.beginPath(); ctx.arc(0, 0, k, 0, Math.PI * 2); ctx.stroke(); ctx.beginPath(); ctx.ellipse(0, 0, k * 0.45, k, 0, 0, Math.PI * 2); ctx.stroke(); line({ x: -k, y: 0 }, { x: k, y: 0 }, color, ctx.lineWidth); break;
      default: ctx.beginPath(); ctx.arc(0, 0, k * 0.35, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }

  function label(text, x, y, size, color, weight = 400, align = "center") {
    ctx.font = `${weight} ${size}px Inter, "Segoe UI", Roboto, Arial, sans-serif`;
    ctx.textAlign = align;
    ctx.textBaseline = "top";
    ctx.lineWidth = size * 0.35;
    ctx.strokeStyle = "rgba(7,13,24,.85)";
    ctx.strokeText(text, x, y);
    ctx.fillStyle = color;
    ctx.fillText(text, x, y);
  }

  function short(text, max = 18) {
    return text.length > max ? text.slice(0, max - 1) + "…" : text;
  }

  function drawBackground() {
    const L = state.layout;
    const g = ctx.createRadialGradient(L.cx, L.cy, 0, L.cx, L.cy, L.R * 1.4);
    g.addColorStop(0, "rgba(40,80,140,.20)");
    g.addColorStop(1, "rgba(7,13,24,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, state.w, state.h);
    // feine Ringe wie auf einem Radar
    ctx.strokeStyle = "rgba(140,170,210,.06)";
    ctx.lineWidth = 1;
    for (const f of [0.45, 0.74, 1]) {
      ctx.beginPath();
      ctx.arc(L.cx, L.cy, L.R * f, 0, Math.PI * 2);
      ctx.stroke();
    }
    // Gruppen als Bögen mit Namen außen
    for (const [group, angles] of Object.entries(L.groups)) {
      if (!angles.length) continue;
      const a0 = Math.min(...angles) - 0.06, a1 = Math.max(...angles) + 0.06;
      ctx.strokeStyle = (COLORS[group] || COLORS.other) + "55";
      ctx.lineWidth = L.vmin * 0.35;
      ctx.beginPath();
      ctx.arc(L.cx, L.cy, L.R + L.vmin * 4.6, a0, a1);
      ctx.stroke();
      const mid = (a0 + a1) / 2;
      const lx = L.cx + Math.cos(mid) * (L.R + L.vmin * 6.4), ly = L.cy + Math.sin(mid) * (L.R + L.vmin * 6.4);
      label(t(group).toUpperCase(), lx, ly - L.vmin * 0.8, L.vmin * 1.45, COLORS[group] || COLORS.other, 600);
    }
  }

  function draw(now) {
    const L = state.layout, data = state.data;
    ctx.setTransform(state.dpr, 0, 0, state.dpr, 0, 0);
    ctx.clearRect(0, 0, state.w, state.h);
    if (!L || !data) return;
    const v = L.vmin;
    const pulse = (Math.sin(now / 600) + 1) / 2;
    drawBackground();

    // Leitungen
    const internetDown = data.internet && data.internet.connection && data.internet.connection !== "Connected";
    if (data.internet) line(L.internet, L.router, internetDown ? COLORS.bad + "aa" : "rgba(154,208,255,.45)", v * 0.35, internetDown ? [v, v] : null);
    for (const node of L.infra) line(node, L.router, node.down ? "rgba(120,140,170,.12)" : node.kind === "pihole" ? "rgba(255,255,255,.22)" : "rgba(180,155,255,.35)", v * 0.22);
    for (const node of state.nodes.values()) {
      const color = COLORS[node.conn] || COLORS.other;
      if (node.online) line(node, L.router, color + "40", v * 0.14, node.conn === "wlan" || node.conn === "guest" ? [v * 0.5, v * 0.4] : null);
      else line(node, L.router, "rgba(120,140,170,.08)", 1, [2, 4]);
    }

    // Teilchen
    for (const p of state.particles) {
      const x = p.from.x + (p.to.x - p.from.x) * p.p, y = p.from.y + (p.to.y - p.from.y) * p.p;
      ctx.fillStyle = p.color;
      ctx.globalAlpha = Math.min(1, Math.sin(p.p * Math.PI) * 1.6);
      ctx.beginPath();
      ctx.arc(x, y, v * 0.28 * p.size, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    // Geräte
    for (const node of state.nodes.values()) {
      const color = COLORS[node.conn] || COLORS.other;
      if (!node.online) {
        ctx.fillStyle = "rgba(90,106,128,.35)";
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.r, 0, Math.PI * 2);
        ctx.fill();
        continue;
      }
      const glow = ctx.createRadialGradient(node.x, node.y, 0, node.x, node.y, node.r * 2.6);
      glow.addColorStop(0, color + "55");
      glow.addColorStop(1, color + "00");
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(node.x, node.y, node.r * 2.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = COLORS.node;
      ctx.strokeStyle = color;
      ctx.lineWidth = v * 0.2;
      ctx.beginPath();
      ctx.arc(node.x, node.y, node.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      if (node.r > v * 1.25) icon(node.kind, node.x, node.y, node.r, color);
      if (node.new) {
        ctx.strokeStyle = COLORS.warn;
        ctx.globalAlpha = 0.4 + 0.6 * pulse;
        ctx.lineWidth = v * 0.25;
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.r + v * (0.6 + 0.5 * pulse), 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
      if (node.labelled) {
        const below = Math.sin(node.a) > -0.2;
        const ly = below ? node.y + node.r + v * 0.6 : node.y - node.r - v * 2.4;
        const name = node.role === "frame" ? `${short(node.name, 14)} · ${t("frame")}` : short(node.name);
        label(name, node.x, ly, v * 1.35, node.new ? COLORS.warn : COLORS.text, node.new ? 600 : 400);
        if (node.new) label(t("newTag"), node.x, ly + v * 1.6, v * 1.1, COLORS.warn, 700);
      }
    }

    // Pi-holes und Server
    for (const node of L.infra) {
      const color = node.down ? COLORS.faint : node.kind === "pihole" ? (node.blocking ? COLORS.block : COLORS.warn) : "#b49bff";
      const dim = node.kind === "pihole" && !node.active;
      ctx.fillStyle = COLORS.node;
      ctx.strokeStyle = dim ? color + "88" : color;
      ctx.lineWidth = v * 0.3;
      ctx.beginPath();
      ctx.arc(node.x, node.y, node.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      if (node.kind === "server" && node.used) {
        ctx.strokeStyle = node.used > 0.9 ? COLORS.warn : "#b49bff";
        ctx.lineWidth = v * 0.45;
        ctx.beginPath();
        ctx.arc(node.x, node.y, node.r + v * 0.6, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * node.used);
        ctx.stroke();
      }
      icon(node.kind, node.x, node.y, node.r, dim ? color + "99" : color);
      label(short(node.name, 16), node.x, node.y + node.r + v * 1.1, v * 1.4, dim ? COLORS.muted : COLORS.text, 500);
      if (node.kind === "pihole" && (node.active || !node.blocking || node.down)) {
        const tag = node.down ? t("noReply") : node.blocking ? t("active") : t("notBlocking");
        label(tag, node.x, node.y + node.r + v * 2.8, v * 1.15, node.down ? COLORS.muted : node.blocking ? COLORS.block : COLORS.warn, 600);
      }
    }

    // Funken: geblockte Anfragen springen an der Pi-hole ab
    for (const s of state.sparks) {
      const d = v * (2.2 + s.t * 5);
      ctx.fillStyle = COLORS.block;
      ctx.globalAlpha = Math.max(0, 1 - s.t);
      ctx.beginPath();
      ctx.arc(s.x + Math.cos(s.a) * d, s.y + Math.sin(s.a) * d, v * 0.3 * (1 - s.t * 0.5), 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;

    // Fritzbox
    const r = L.router;
    const rg = ctx.createRadialGradient(r.x, r.y, 0, r.x, r.y, r.r * 2.4);
    rg.addColorStop(0, "rgba(95,179,255,.35)");
    rg.addColorStop(1, "rgba(95,179,255,0)");
    ctx.fillStyle = rg;
    ctx.beginPath();
    ctx.arc(r.x, r.y, r.r * 2.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#13233b";
    ctx.strokeStyle = "#9ad0ff";
    ctx.lineWidth = v * 0.3;
    roundRect(r.x - r.r, r.y - r.r * 0.8, r.r * 2, r.r * 1.6, v);
    ctx.fill();
    ctx.stroke();
    icon("router", r.x, r.y + r.r * 0.05, r.r * 0.9, "#cfe6ff");
    const model = (data.internet && data.internet.model) || t("router");
    label(model.replace(/^FRITZ!Box\s*/, "FRITZ!Box "), r.x, r.y + r.r * 0.8 + v * 0.8, v * 1.45, COLORS.text, 600);

    // Internet
    if (data.internet) {
      const i = L.internet;
      ctx.fillStyle = COLORS.node;
      ctx.strokeStyle = internetDown ? COLORS.bad : COLORS.internet;
      ctx.lineWidth = v * 0.3;
      ctx.beginPath();
      ctx.arc(i.x, i.y, i.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      icon("globe", i.x, i.y, i.r * 1.1, internetDown ? COLORS.bad : COLORS.internet);
      const text = internetDown ? `${t("internet")} · ${t("disconnected")}` : t("internet");
      label(text, i.x + i.r + v * 1.2, i.y - v * 0.9, v * 1.5, internetDown ? COLORS.bad : COLORS.text, 600, "left");
    }
  }

  function frame(now) {
    requestAnimationFrame(frame);
    if (now - state.lastFrame < 1000 / FPS - 2) return;
    state.lastFrame = now;
    const dt = Math.min(0.2, (now - state.last) / 1000);
    state.last = now;
    if (state.layout && state.data) {
      emit(dt);
      for (const p of state.particles) p.p += dt * p.speed;
      state.particles = state.particles.filter((p) => p.p < 1);
      for (const s of state.sparks) s.t += dt * 1.4;
      state.sparks = state.sparks.filter((s) => s.t < 1);
    }
    draw(now);
  }

  // ------------------------------------------------------------ Karten

  function setTone(id, tone) {
    const card = el(id);
    card.classList.remove("ok", "warn", "bad");
    if (tone) card.classList.add(tone);
  }

  function renderCards() {
    const data = state.data;
    document.documentElement.lang = lang;
    el("eyebrow").textContent = t("title");
    el("tInsights").textContent = t("insights");
    el("tBlockedToday").textContent = t("blockedToday");
    const empty = el("empty");
    if (!state.reachable || !data) {
      empty.classList.remove("hidden");
      el("emptyTitle").textContent = t("noAnswer");
      el("emptyText").textContent = t("noAnswerText");
      el("cards").classList.add("hidden");
      return;
    }
    const configured = data.internet || data.pihole || data.server || (data.devices || []).length;
    empty.classList.toggle("hidden", Boolean(configured));
    el("cards").classList.toggle("hidden", !configured);
    if (!configured) {
      el("emptyTitle").textContent = t("nothing");
      el("emptyText").textContent = t("nothingText");
    }
    const online = (data.devices || []).filter((d) => d.online).length;
    el("onlineCount").textContent = num(online);
    el("onlineLabel").textContent = online === 1 ? t("online1") : t("online");

    // Internet
    const inet = data.internet;
    el("cardInternet").classList.toggle("hidden", !inet);
    if (inet) {
      el("tInternet").textContent = t("internet");
      el("routerModel").textContent = inet.model || "";
      const [dn, du] = rateParts(inet.down), [un, uu] = rateParts(inet.up);
      el("rateDown").textContent = dn; el("unitDown").textContent = du;
      el("rateUp").textContent = un; el("unitUp").textContent = uu;
      el("lineBar").style.width = `${inet.maxDown ? Math.min(100, inet.down / inet.maxDown * 100) : 0}%`;
      const parts = [`${t("today")} ${size(inet.todayDown)} ↓ · ${size(inet.todayUp)} ↑`];
      if (inet.uptime) parts.push(t("since", { d: duration(inet.uptime) }));
      el("internetFoot").textContent = parts.join(" · ");
      setTone("cardInternet", inet.connection && inet.connection !== "Connected" ? "bad" : "ok");
    }

    // Pi-hole
    const pi = data.pihole;
    el("cardPihole").classList.toggle("hidden", !pi);
    if (pi) {
      el("blockedToday").textContent = num(pi.todayBlocked);
      el("blockedPct").textContent = t("of", { pct: dec(pi.todayTotal ? pi.todayBlocked / pi.todayTotal * 100 : 0),
        n: num(pi.todayTotal) });
      const list = pi.instances || [];
      el("piholeSub").textContent = list.length > 1 ? list.map((i) => i.name + (i.active ? " ●" : i.down ? " ✕" : "")).join(" · ") : "";
      el("topBlocked").textContent = pi.topBlocked && pi.topBlocked[0] ? t("topBlocked", { d: pi.topBlocked[0].domain }) : "";
      setTone("cardPihole", pi.blocking ? "ok" : "warn");
      drawSpark(pi.series || []);
      renderWeek(data.week || []);
    }

    // Server
    const server = data.server;
    el("cardServer").classList.toggle("hidden", !server);
    if (server) {
      el("serverName").textContent = server.name || "Server";
      el("serverSub").textContent = server.boot ? t("serverUp", { d: duration(data.now - server.boot) }) : "";
      const share = server.total ? server.used / server.total : 0;
      el("arrayBar").style.width = `${Math.round(share * 100)}%`;
      el("arrayBar").classList.toggle("warn", share > 0.9);
      el("arrayText").textContent = server.total ? t("ofTotal", { used: size(server.used), total: size(server.total) }) : "";
      const hot = (data.settings && data.settings.HotDisk) || 45;
      el("disks").innerHTML = "";
      for (const disk of server.disks || []) {
        const chip = document.createElement("div");
        const temp = disk.temp;
        chip.className = "disk " + (!disk.spinning || temp == null ? "sleep" : temp >= hot + 10 ? "hot" : temp >= hot ? "warm" : "cool");
        const name = document.createElement("span");
        name.textContent = disk.name;
        const value = document.createElement("b");
        value.textContent = !disk.spinning || temp == null ? t("sleeping") : `${Math.round(temp)} °C`;
        chip.append(name, value);
        el("disks").append(chip);
      }
      el("cpuBar").style.width = `${Math.round(server.cpu || 0)}%`;
      el("cpuText").textContent = server.cpu == null ? "–" : `${Math.round(server.cpu)} %`;
      el("memBar").style.width = `${Math.round(server.mem || 0)}%`;
      el("memText").textContent = server.mem == null ? "–" : `${Math.round(server.mem)} %`;
      const c = server.containers || {};
      el("dockerText").textContent = c.total ? `${c.running}/${c.total}` : "–";
      const anyHot = (server.disks || []).some((d) => d.temp != null && d.temp >= hot);
      setTone("cardServer", server.state && server.state !== "STARTED" ? "bad" : anyHot || share > 0.9 ? "warn" : "ok");
    }

    // Lagebild: Warnungen bleiben stehen, der Rest wechselt durch, wenn nicht alles passt.
    const items = data.insights || [];
    state.insights = items;
    renderInsights();
    const worst = items.find((i) => i.tone === "bad") ? "bad" : items.find((i) => i.tone === "warn") ? "warn" : "ok";
    setTone("cardInsights", worst);
  }

  function renderInsights() {
    const items = state.insights || [];
    const list = el("insights");
    const pinned = items.filter((i) => i.tone === "bad" || i.tone === "warn");
    const rest = items.filter((i) => !pinned.includes(i));
    const offset = rest.length ? state.insightOffset % rest.length : 0;
    const ordered = [...pinned, ...rest.slice(offset), ...rest.slice(0, offset)];
    list.innerHTML = "";
    for (const item of ordered) {
      const li = document.createElement("li");
      li.className = item.tone;
      const dot = document.createElement("i");
      const title = document.createElement("b");
      title.textContent = item.title;
      const text = document.createElement("span");
      text.textContent = item.text || "";
      li.append(dot, title, text);
      list.append(li);
    }
    // Was nicht ganz in die Karte passt, weglassen statt anschneiden.
    const limit = list.parentElement.getBoundingClientRect().bottom - 4;
    let fits = 0;
    for (const li of [...list.children]) {
      if (li.getBoundingClientRect().bottom > limit) li.remove();
      else fits += 1;
    }
    state.insightsRotate = fits < ordered.length && rest.length > 0;
  }

  function drawSpark(series) {
    const c = el("spark");
    const w = c.clientWidth, h = c.clientHeight;
    if (!w || !h) return;
    const dpr = state.dpr;
    c.width = Math.round(w * dpr);
    c.height = Math.round(h * dpr);
    const g = c.getContext("2d");
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, w, h);
    if (series.length < 2) return;
    const max = Math.max(1, ...series.map((r) => r[1]));
    const x = (i) => i / (series.length - 1) * w;
    const y = (v) => h - 2 - v / max * (h - 4);
    for (const [idx, color] of [[1, "rgba(154,208,255,.30)"], [2, "rgba(255,93,115,.85)"]]) {
      g.beginPath();
      g.moveTo(0, h);
      series.forEach((r, i) => g.lineTo(x(i), y(r[idx])));
      g.lineTo(w, h);
      g.closePath();
      g.fillStyle = color;
      g.fill();
    }
  }

  function renderWeek(week) {
    const box = el("week");
    box.innerHTML = "";
    const max = Math.max(1, ...week.map((d) => d.blocked || 0));
    week.forEach((d, i) => {
      const col = document.createElement("div");
      if (i === week.length - 1) col.className = "today";
      const bar = document.createElement("i");
      bar.style.height = `${Math.round((d.blocked || 0) / max * 100 * 0.78)}%`;
      bar.title = t("blockedLine", { n: num(d.blocked) });
      const day = document.createElement("span");
      day.textContent = (I18N[lang] || I18N.de).weekdays[new Date(d.day + "T12:00:00").getDay()];
      col.append(bar, day);
      box.append(col);
    });
  }

  function tick() {
    const now = new Date();
    el("clock").textContent = now.toLocaleTimeString(locale(), { hour: "2-digit", minute: "2-digit" });
    el("date").textContent = now.toLocaleDateString(locale(), { weekday: "long", day: "numeric", month: "long" });
  }

  window.addEventListener("resize", () => { resize(); renderCards(); });
  resize();
  tick();
  setInterval(tick, 10000);
  setInterval(() => {
    if (!state.insightsRotate) return;
    state.insightOffset += 1;
    renderInsights();
  }, 9000);
  poll();
  setInterval(poll, POLL_MS);
  requestAnimationFrame(frame);
})();
