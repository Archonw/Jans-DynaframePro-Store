"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt nur die übergebenen Platzhalter; fehlt eine
Übersetzung, bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Auf dem Rahmen fehlt Pillow; installiere das Paket noch einmal.": (
        "Pillow is missing on the frame; install the pack again.",
        "Falta Pillow en el marco; vuelve a instalar el paquete."),
    "Auf dem Rahmen ist kein Platz mehr frei.": (
        "There is no space left on the frame.", "No queda espacio libre en el marco."),
    "Bitte mach ein Selfie für das Gästebuch.": (
        "Please take a selfie for the guestbook.", "Hazte un selfie para el libro de visitas, por favor."),
    "Bitte schreib deinen Namen dazu.": ("Please add your name.", "Escribe tu nombre, por favor."),
    "Das Datum stimmt nicht; Erinnerungen kämen am falschen Tag.": (
        "The date is wrong; memories would come on the wrong day.",
        "La fecha no es correcta; los recuerdos llegarían el día equivocado."),
    "Das Foto ist zu groß (höchstens {mb} MB).": (
        "The photo is too large (at most {mb} MB).", "La foto es demasiado grande (como máximo {mb} MB)."),
    "Das Gästebuch ist voll.": ("The guestbook is full.", "El libro de visitas está lleno."),
    "Das Gästebuch: Selfies und Grüße eurer Besucher, und was heute vor Jahren war.": (
        "The guestbook: your visitors' selfies and greetings, and what happened on this day years ago.",
        "El libro de visitas: selfies y saludos de vuestros visitantes, y lo que pasó tal día como hoy hace años."),
    "Das ist kein Foto, das der Rahmen lesen kann.": (
        "That is not a photo the frame can read.", "Eso no es una foto que el marco pueda leer."),
    "Das sind genug Einträge von diesem Handy für den Moment.": (
        "That is enough entries from this phone for now.", "Ya hay suficientes entradas desde este móvil por ahora."),
    "Datum auf dem Rahmen": ("Date on the frame", "Fecha en el marco"),
    "Der Rahmen hat das Gästebuch nicht rechtzeitig gezeigt.": (
        "The frame did not show the guestbook in time.", "El marco no ha mostrado el libro de visitas a tiempo."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.", "El marco no ha creado la lista {name}."),
    "Die Gäste-Seite wandelt Fotos meist schon im Handy um.": (
        "The guest page usually converts photos on the phone already.",
        "La página de invitados suele convertir las fotos ya en el móvil."),
    "Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The scene is not installed on this frame. Install the pack again.",
        "La escena no está instalada en este marco. Vuelve a instalar el paquete."),
    "Die Uhr ist nicht mit dem Internet abgeglichen.": (
        "The clock is not synchronised with the internet.", "El reloj no está sincronizado con internet."),
    "Diese Feier gibt es nicht mehr.": ("This party no longer exists.", "Esta fiesta ya no existe."),
    "Diesen Eintrag kannst du nicht mehr ändern.": (
        "You can no longer change this entry.", "Ya no puedes cambiar esta entrada."),
    "DynaFrame auf diesem Rahmen": ("DynaFrame on this frame", "DynaFrame en este marco"),
    "Erlaubt.": ("Allowed.", "Permitido."),
    "Erreichbar ({ms} ms).": ("Reachable ({ms} ms).", "Accesible ({ms} ms)."),
    "Es läuft gerade keine Feier.": ("No party is running right now.", "No hay ninguna fiesta en marcha."),
    "Es läuft schon eine Feier.": ("A party is already running.", "Ya hay una fiesta en marcha."),
    "Etwas anderes hat gerade den Bildschirm.": (
        "Something else has the screen right now.", "Otra cosa está usando la pantalla ahora."),
    "Gib der Feier einen Namen.": ("Give the party a name.", "Ponle un nombre a la fiesta."),
    "Gästebuch {mb} MB, frei {gb} GB.": ("Guestbook {mb} MB, free {gb} GB.", "Libro {mb} MB, libre {gb} GB."),
    "HEIC-Fotos kann der Rahmen nicht lesen. Stell am iPhone unter Kamera › Formate „Maximale Kompatibilität“ ein.": (
        "The frame cannot read HEIC photos. On the iPhone, set Camera › Formats to “Most Compatible”.",
        "El marco no puede leer fotos HEIC. En el iPhone, elige Cámara › Formatos «Más compatible»."),
    "Heute gibt es keine Erinnerung aus früheren Jahren.": (
        "There is no memory from earlier years today.", "Hoy no hay ningún recuerdo de años anteriores."),
    "Heute ist der {date}.": ("Today is {date}.", "Hoy es {date}."),
    "Installiere das Paket noch einmal.": ("Install the pack again.", "Vuelve a instalar el paquete."),
    "Installiert.": ("Installed.", "Instalada."),
    "Ist das WLAN des Rahmens verbunden?": ("Is the frame's Wi-Fi connected?", "¿Está conectada la wifi del marco?"),
    "JPEG und PNG gehen, HEIC (iPhone) nicht.": (
        "JPEG and PNG work, HEIC (iPhone) does not.", "JPEG y PNG funcionan, HEIC (iPhone) no."),
    "JPEG, PNG und HEIC gehen.": ("JPEG, PNG and HEIC work.", "JPEG, PNG y HEIC funcionan."),
    "Kein freier Port gefunden.": ("No free port found.", "No se encontró ningún puerto libre."),
    "Konnte das Foto nicht lesen: {exc}": ("Could not read the photo: {exc}", "No se pudo leer la foto: {exc}"),
    "Konnte das Gästebuch nicht zeigen: {exc}": (
        "Could not show the guestbook: {exc}", "No se pudo mostrar el libro de visitas: {exc}"),
    "Konnte die Takeover-Playlist nicht anlegen: {exc}": (
        "Could not create the takeover playlist: {exc}", "No se pudo crear la lista de takeover: {exc}"),
    "Läuft unter {url} ({ms} ms).": ("Running at {url} ({ms} ms).", "Funciona en {url} ({ms} ms)."),
    "Mit Web Login und strenger Firewall muss der Port dort offen sein.": (
        "With Web Login and a strict firewall, the port must be open there.",
        "Con Web Login y un cortafuegos estricto, el puerto debe estar abierto allí."),
    "Nicht erreichbar: {exc}": ("Not reachable: {exc}", "No accesible: {exc}"),
    "Nicht installiert.": ("Not installed.", "No instalada."),
    "Ohne das zeigt der Fernseher neue Einträge, Erinnerungen und Feiern nur, wenn die Playlist „Guestbook“ läuft. Einschalten auf der Plugins-Seite.": (
        "Without it the TV shows new entries, memories and parties only while the playlist “Guestbook” runs. "
        "Switch it on on the Plugins page.",
        "Sin ello, la tele solo muestra entradas nuevas, recuerdos y fiestas mientras suena la lista «Guestbook». "
        "Actívalo en la página de plugins."),
    "Pillow fehlt.": ("Pillow is missing.", "Falta Pillow."),
    "Prüfung": ("Check", "Comprobación"),
    "Schreib einen Gruß oder mach ein Selfie.": (
        "Write a greeting or take a selfie.", "Escribe un saludo o hazte un selfie."),
    "Seite für die Gäste": ("Page for the guests", "Página para los invitados"),
    "Selfies verarbeiten": ("Processing selfies", "Procesar selfies"),
    "Speicher": ("Storage", "Almacenamiento"),
    "Starte den Rahmen neu, wenn das rot bleibt.": (
        "Restart the frame if this stays red.", "Reinicia el marco si esto sigue en rojo."),
    "Szene „Guestbook“": ("Scene “Guestbook”", "Escena «Guestbook»"),
    "Trag unten einen freien Port ein.": ("Enter a free port below.", "Indica abajo un puerto libre."),
    "Unser Gästebuch": ("Our guestbook", "Nuestro libro de visitas"),
    "Videos gehen hier nicht, nur Fotos.": ("Videos do not work here, only photos.", "Aquí no van vídeos, solo fotos."),
    "Von selbst auf den Fernseher": ("Onto the TV by itself", "A la tele por sí solo"),
    "Zu wenig frei: neue Einträge werden abgelehnt.": (
        "Too little free space: new entries are refused.", "Poco espacio libre: se rechazan las entradas nuevas."),
    "{url} antwortet nicht.": ("{url} does not answer.", "{url} no responde."),
    "„Allow takeover“ ist aus.": ("“Allow takeover” is off.", "«Allow takeover» está desactivado."),
    "„Allow takeover“ ist für Guestbook auf der Plugins-Seite aus. Schalte es ein, sonst kann das Gästebuch nicht von selbst auf den Fernseher.": (
        "“Allow takeover” is off for Guestbook on the Plugins page. Switch it on, otherwise the guestbook "
        "cannot come onto the TV by itself.",
        "«Allow takeover» está desactivado para Guestbook en la página de plugins. Actívalo; si no, el libro "
        "de visitas no puede salir solo en la tele."),
}


def t(lang, template, **values):
    row = _TEXTS.get(template)
    text = template
    if row and lang in LANGUAGES[1:]:
        text = row[LANGUAGES.index(lang) - 1] or template
    for key, value in values.items():
        text = text.replace("{" + key + "}", str(value))
    return text
