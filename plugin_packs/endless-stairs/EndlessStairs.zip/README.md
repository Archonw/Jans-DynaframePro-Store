# Endless Stairs

Du gehst langsam eine endlose Treppe hoch. Links an der Wand hängen deine Fotos in ganz verschiedenen Bilderrahmen, wie in einem Wohnhaus: schwarz, weiß, Eiche, Nussbaum, Silber und Gold, klein und groß, manchmal zwei übereinander. Die rechte Wand ist geschlossen und hat einen einfachen Handlauf. Nach etwa zehn Bildern kommt ein Absatz, die Treppe biegt nach rechts ab und geht weiter hoch, ohne Ende. Ab und zu bleibst du vor einem Bild stehen.

Zwei Treppenhäuser: hell (modern, grauer Putz, Eichenstufen) und dunkel (grüne Streifentapete, Teppichläufer, Bilderleuchten).

Fotos aus der ganzen DynaFrame-Mediathek, aus Ordnern, Playlists oder von einem Immich-Server, mit den Filtern aus Photo Mosaic. Gezeichnet in 3D auf der Grafikkarte (WebGL, three.js).

Einstellungen: Plugins → Endless Stairs → „Open Endless Stairs“. Dort kannst du auch eine Playlist „Endless Stairs“ anlegen lassen.

Problem melden: https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=%5BEndless%20Stairs%5D%20
