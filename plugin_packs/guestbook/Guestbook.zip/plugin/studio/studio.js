"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/Guestbook/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["SlideSeconds", "PartyHours", "RecapMinutes", "MemoryMinutes", "PlaylistSeconds"];
const CHECK_FIELDS = ["RequirePhoto", "Approve", "GuestsSeeBook", "WelcomeOnTv", "Memories", "MemoryOnTv", "PartyOnTv",
  "WakeScreen", "ShowQr", "ShowDates"];
const SELECT_FIELDS = ["Theme"];
const TEXT_FIELDS = ["BookTitle", "MemoryTime"];
let current = null;
let editing = false;
let langChangedAt = 0;

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["Guestbook", "Guestbook", "Guestbook"],
  lede: ["Euer Gästebuch auf dem Rahmen: Besucher scannen den QR-Code, machen ein Selfie und schreiben einen Gruß. Der Fernseher blättert durchs Buch, begrüßt neue Einträge sofort und erinnert sich Jahre später: „Heute vor 3 Jahren war Tante Anke zu Besuch.“ Für eine Feier macht der Party-Modus daraus eine Gästewand. Jede Änderung hier wird sofort gespeichert.",
    "Your guestbook on the frame: visitors scan the QR code, take a selfie and write a greeting. The TV leafs through the book, welcomes new entries right away and remembers years later: “3 years ago today, Aunt Anne came to visit.” For a party, party mode turns it into a live guest wall. Every change here is saved immediately.",
    "Vuestro libro de visitas en el marco: los visitantes escanean el código QR, se hacen un selfie y escriben un saludo. La tele hojea el libro, da la bienvenida a cada entrada nueva y años después recuerda: «Hoy hace 3 años vino de visita la tía Ana». Para una fiesta, el modo fiesta lo convierte en un muro de invitados. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  statusTitle: ["Das Gästebuch", "The guestbook", "El libro de visitas"],
  showNow: ["5 Minuten auf den Fernseher", "Show on the TV for 5 minutes", "5 minutos en la tele"],
  stopNow: ["Fernseher zurückgeben", "Give the TV back", "Devolver la tele"],
  factNow: ["Gerade", "Now", "Ahora"],
  factEntries: ["Einträge", "Entries", "Entradas"],
  factGuests: ["Gäste", "Guests", "Invitados"],
  factYear: ["Besuche dieses Jahr", "Visits this year", "Visitas este año"],
  factLast: ["Letzter Eintrag", "Last entry", "Última entrada"],
  factVersion: ["Version", "Version", "Versión"],
  nowOff: ["nicht auf dem Fernseher", "not on the TV", "no está en la tele"],
  nowBook: ["blättert im Buch", "leafing through the book", "hojeando el libro"],
  nowParty: ["Gästewand der Feier", "party guest wall", "muro de la fiesta"],
  nowRecap: ["Rückblick der Feier", "party recap", "resumen de la fiesta"],
  reason_welcome: [" · zeigt gerade einen neuen Eintrag", " · showing a new entry", " · mostrando una entrada nueva"],
  reason_memory: [" · zeigt die Erinnerung des Tages", " · showing the memory of the day", " · mostrando el recuerdo del día"],
  reason_manual: [" · auf den Fernseher geholt bis {time}", " · on the TV until {time}", " · en la tele hasta las {time}"],
  reason_party: [" · Feier auf dem Fernseher bis {time}", " · party on the TV until {time}", " · fiesta en la tele hasta las {time}"],
  reason_recap: [" · Rückblick auf dem Fernseher bis {time}", " · recap on the TV until {time}", " · resumen en la tele hasta las {time}"],
  waitTv: [" · kommt gleich auf den Fernseher …", " · coming to the TV …", " · llega enseguida a la tele …"],
  waitingLine: ["{n} ({w} warten auf Freigabe)", "{n} ({w} waiting for approval)", "{n} ({w} pendientes)"],
  todayLine: ["„{title}“ · Code {code}", "“{title}” · code {code}", "«{title}» · código {code}"],
  servicesTitle: ["Verbindungen", "Connections", "Conexiones"],
  servicesCheck: ["Jetzt prüfen", "Check now", "Comprobar ahora"],
  servicesHint: ["Alles, was Guestbook braucht. Das Plugin prüft es alle fünf Minuten selbst; rot heißt, dass etwas fehlt, gelb, dass es nur teilweise geht.",
    "Everything Guestbook needs. The plugin checks it by itself every five minutes; red means something is missing, yellow that it only partly works.",
    "Todo lo que necesita Guestbook. El plugin lo comprueba solo cada cinco minutos; rojo significa que falta algo, amarillo que solo funciona en parte."],
  servicesWait: ["Wird geprüft …", "Checking …", "Comprobando …"],
  servicesAllOk: ["Alles in Ordnung, zuletzt geprüft {time}.", "Everything fine, last checked {time}.", "Todo bien, última comprobación {time}."],
  servicesSome: ["Nicht alles in Ordnung, zuletzt geprüft {time}.", "Not everything is fine, last checked {time}.", "No todo está bien, última comprobación {time}."],
  svc_ok: ["in Ordnung", "fine", "bien"],
  svc_warn: ["teilweise", "partly", "en parte"],
  svc_bad: ["fehlt", "missing", "falta"],
  svc_off: ["aus", "off", "apagado"],
  guestsTitle: ["Eintragen mit dem Handy", "Signing in with the phone", "Firmar con el móvil"],
  printCard: ["QR-Kärtchen drucken", "Print a QR card", "Imprimir tarjeta QR"],
  newCode: ["Neuer Code", "New code", "Nuevo código"],
  phoneCode: ["Code für die Gäste: {code} (steht schon im QR-Code)", "Code for the guests: {code} (already in the QR code)", "Código para los invitados: {code} (ya va en el código QR)"],
  phoneNoPort: ["Die Gäste-Seite hat keinen freien Port gefunden. Trag unten einen freien Port ein.", "The guest page found no free port. Enter a free port below.", "La página de invitados no encontró ningún puerto libre. Indica abajo un puerto libre."],
  noPillow: ["Auf dem Rahmen fehlt Pillow, Selfies können nicht angenommen werden. Installiere das Paket noch einmal.", "Pillow is missing on the frame, so selfies cannot be accepted. Install the pack again.", "Falta Pillow en el marco; no se pueden recibir selfies. Vuelve a instalar el paquete."],
  bookTitle: ["Titel des Gästebuchs (auf dem Fernseher und den Handys)", "Title of the guestbook (on the TV and the phones)", "Título del libro de visitas (en la tele y los móviles)"],
  bookTitlePh: ["Unser Gästebuch", "Our guestbook", "Nuestro libro de visitas"],
  requirePhoto: ["Ein Selfie gehört dazu (Pflicht)", "A selfie is required", "El selfie es obligatorio"],
  approve: ["Ich gebe jeden Eintrag frei, bevor er erscheint", "I approve every entry before it appears", "Apruebo cada entrada antes de que aparezca"],
  seeBook: ["Gäste können auf dem Handy im Buch blättern", "Guests can look through the book on their phone", "Los invitados pueden hojear el libro en el móvil"],
  guestsHint: ["Der QR-Code (auf dem Fernseher oder als ausgedrucktes Kärtchen im Flur) öffnet eine Seite dieses Plugins auf Port <b>8135</b> in deinem WLAN, der Code steht schon drin. Gäste machen ein Selfie mit der Frontkamera, schreiben ihren Namen und ein paar Zeilen und können ihren Eintrag auf demselben Handy zwei Tage lang ändern oder löschen. Fotos liegen mit 1600 Pixeln ohne Ort und Kameradaten auf dem Rahmen. Mit „Neuer Code“ gehen alte Kärtchen und Lesezeichen nicht mehr. Wenn du <b>Web Login</b> nutzt, gib dort Port 8135 frei.",
    "The QR code (on the TV, or printed as a card for the hallway) opens a page of this plugin on port <b>8135</b> in your Wi-Fi, with the code already filled in. Guests take a selfie with the front camera, write their name and a few lines, and can change or delete their entry on the same phone for two days. Photos are stored on the frame at 1600 pixels without location or camera data. With “New code”, old cards and bookmarks stop working. If you use <b>Web Login</b>, allow port 8135 there.",
    "El código QR (en la tele o impreso como tarjeta para la entrada) abre una página de este plugin en el puerto <b>8135</b> de tu wifi, con el código ya puesto. Los invitados se hacen un selfie con la cámara frontal, escriben su nombre y unas líneas, y pueden cambiar o borrar su entrada en el mismo móvil durante dos días. Las fotos se guardan en el marco a 1600 píxeles sin ubicación ni datos de cámara. Con «Nuevo código», las tarjetas y marcadores antiguos dejan de funcionar. Si usas <b>Web Login</b>, abre allí el puerto 8135."],
  partyTitle: ["Party-Modus", "Party mode", "Modo fiesta"],
  partyHint: ["Für eine Feier wird das Gästebuch zur Gästewand: Jeder neue Eintrag kommt groß mit einem Willkommen, danach wandert er in die Wand aller Gäste des Abends, daneben steht der QR-Code. Beim Beenden zeigt ein Rückblick alle Einträge des Abends. Die Einträge bleiben im Buch und kommen Jahre später als Erinnerung wieder.",
    "For a party the guestbook becomes a guest wall: every new entry comes up big with a welcome, then joins the wall of all guests of the evening, with the QR code next to it. When you end the party, a recap shows every entry of the evening. The entries stay in the book and come back years later as a memory.",
    "Para una fiesta, el libro se convierte en un muro de invitados: cada entrada nueva aparece en grande con una bienvenida y luego pasa al muro con todos los invitados de la noche, con el código QR al lado. Al terminar, un resumen muestra todas las entradas de la noche. Las entradas se quedan en el libro y vuelven años después como recuerdo."],
  partyName: ["Name der Feier", "Name of the party", "Nombre de la fiesta"],
  partyNamePh: ["z. B. Annas 40. Geburtstag", "e.g. Anna's 40th birthday", "p. ej. 40 cumpleaños de Ana"],
  partyGo: ["Die Gäste kommen?", "Guests are arriving?", "¿Llegan los invitados?"],
  partyStart: ["Feier beginnen", "Start the party", "Empezar la fiesta"],
  partyEnd: ["Feier beenden und Rückblick zeigen", "End the party and show the recap", "Terminar la fiesta y mostrar el resumen"],
  partyEndSure: ["Wirklich beenden?", "Really end it?", "¿Seguro que la terminas?"],
  partyLine: ["„{title}“ läuft seit {time} · {n} Einträge · endet von selbst um {end}", "“{title}” running since {time} · {n} entries · ends by itself at {end}", "«{title}» desde las {time} · {n} entradas · termina sola a las {end}"],
  partyNeedName: ["Gib der Feier einen Namen.", "Give the party a name.", "Ponle un nombre a la fiesta."],
  partyHours: ["Die Feier dauert … Stunden (dann endet sie von selbst)", "The party lasts … hours (then it ends by itself)", "La fiesta dura … horas (luego termina sola)"],
  recapMinutes: ["Rückblick … Minuten auf dem Fernseher (0 = nicht)", "Show the recap on the TV for … minutes (0 = not)", "Mostrar el resumen … minutos en la tele (0 = no)"],
  partyOnTv: ["Gästewand die ganze Feier über auf dem Fernseher", "Put the guest wall on the TV for the whole party", "Poner el muro en la tele durante toda la fiesta"],
  eventsTitle: ["Frühere Feiern", "Earlier parties", "Fiestas anteriores"],
  noEvents: ["Noch keine Feier.", "No party yet.", "Aún no hay fiestas."],
  eventRow: ["{date} · {n} Einträge", "{date} · {n} entries", "{date} · {n} entradas"],
  running: ["läuft gerade", "running", "en marcha"],
  recap: ["Rückblick", "Recap", "Resumen"],
  print: ["Drucken", "Print", "Imprimir"],
  delEvent: ["Löschen", "Delete", "Borrar"],
  delEventSure: ["Mit allen Einträgen löschen?", "Delete with all entries?", "¿Borrar con todas las entradas?"],
  recapStarted: ["Der Rückblick kommt gleich auf den Fernseher.", "The recap is coming to the TV.", "El resumen llega enseguida a la tele."],
  memTitle: ["Erinnerungen", "Memories", "Recuerdos"],
  memories: ["„Heute vor … Jahren“ zwischen den Seiten zeigen", "Show “On this day years ago” between the pages", "Mostrar «Hoy hace … años» entre las páginas"],
  memoryOnTv: ["Die Erinnerung des Tages von selbst auf den Fernseher holen", "Bring the memory of the day onto the TV by itself", "Llevar solo el recuerdo del día a la tele"],
  welcomeOnTv: ["Neue Einträge sofort auf den Fernseher holen", "Bring new entries onto the TV right away", "Llevar las entradas nuevas a la tele al instante"],
  memoryTime: ["Erinnerung des Tages um (Uhrzeit)", "Memory of the day at (time)", "Recuerdo del día a las (hora)"],
  memoryMinutes: ["Für … Minuten", "For … minutes", "Durante … minutos"],
  wakeScreen: ["Bildschirm dafür einschalten", "Switch the screen on for it", "Encender la pantalla para ello"],
  memoryTest: ["Erinnerung von heute jetzt zeigen", "Show today's memory now", "Mostrar ahora el recuerdo de hoy"],
  upcomingTitle: ["Demnächst", "Coming up", "Próximamente"],
  noUpcoming: ["In den nächsten 60 Tagen gibt es keine Erinnerung.", "No memories in the next 60 days.", "No hay recuerdos en los próximos 60 días."],
  memTodayNone: ["Heute gibt es keine Erinnerung aus früheren Jahren.", "No memory from earlier years today.", "Hoy no hay ningún recuerdo de años anteriores."],
  memToday: ["Heute: {list}", "Today: {list}", "Hoy: {list}"],
  memHint: ["An dem Tag, an dem ein Gast vor einem, zwei oder zehn Jahren da war, sagt es der Rahmen: „Heute vor 3 Jahren war Tante Anke zu Besuch.“, mit den Selfies und dem Gruß von damals. Bei einer Feier: „Heute vor 2 Jahren: Annas 40. Geburtstag“ mit allen Gästen. Von selbst auf den Fernseher holen und neue Einträge sofort zeigen braucht „Allow takeover“ für Guestbook auf der Plugins-Seite; sonst kommt beides, wenn die Playlist läuft.",
    "On the day a guest visited one, two or ten years ago, the frame says so: “3 years ago today, Aunt Anne came to visit.”, with the selfies and the greeting of that day. For a party: “2 years ago today: Anna's 40th birthday” with all guests. Bringing it onto the TV by itself or welcoming new entries right away needs “Allow takeover” for Guestbook on the Plugins page; otherwise both appear when the playlist runs.",
    "El día en que un invitado vino hace uno, dos o diez años, el marco lo dice: «Hoy hace 3 años vino de visita la tía Ana», con los selfies y el saludo de aquel día. Para una fiesta: «Hoy hace 2 años: 40 cumpleaños de Ana» con todos los invitados. Llevarlo solo a la tele o mostrar al instante las entradas nuevas necesita «Allow takeover» para Guestbook en la página de plugins; si no, ambos aparecen cuando suena la lista."],
  memVisit: ["vor {y} J. {names}", "{y} yrs ago {names}", "hace {y} años {names}"],
  memEvent: ["vor {y} J. „{title}“ ({n} Gäste)", "{y} yrs ago “{title}” ({n} guests)", "hace {y} años «{title}» ({n} invitados)"],
  lookTitle: ["Auf dem Fernseher", "On the TV", "En la tele"],
  theme: ["Aussehen", "Look", "Aspecto"],
  themePaper: ["Papier (creme und terrakotta)", "Paper (cream and terracotta)", "Papel (crema y terracota)"],
  themeEvening: ["Abend (dunkelgrün und gold)", "Evening (dark green and gold)", "Noche (verde oscuro y oro)"],
  themeParty: ["Party (lila und pink)", "Party (purple and pink)", "Fiesta (lila y rosa)"],
  slideSeconds: ["Sekunden je Seite", "Seconds per page", "Segundos por página"],
  showQr: ["QR-Code in der Ecke zeigen", "Show the QR code in the corner", "Mostrar el código QR en la esquina"],
  showDates: ["Datum jedes Eintrags zeigen", "Show the date of each entry", "Mostrar la fecha de cada entrada"],
  entriesTitle: ["Einträge", "Entries", "Entradas"],
  approveAll: ["Alle wartenden freigeben", "Approve all waiting", "Aprobar todas las pendientes"],
  printBook: ["Als Buch drucken", "Print as a book", "Imprimir como libro"],
  zip: ["Als ZIP laden", "Download as ZIP", "Descargar en ZIP"],
  filter: ["Zeigen", "Show", "Mostrar"],
  fAll: ["Alle Einträge", "All entries", "Todas las entradas"],
  fWait: ["Warten auf Freigabe", "Waiting for approval", "Pendientes de aprobación"],
  fVisits: ["Besuche (ohne Feiern)", "Visits (no parties)", "Visitas (sin fiestas)"],
  fEvent: ["Feier: {title}", "Party: {title}", "Fiesta: {title}"],
  entriesHint: ["Die neuesten zuerst. Ausgeblendete Einträge bleiben auf dem Rahmen, erscheinen aber nicht mehr auf dem Fernseher und den Handys; Löschen entfernt sie endgültig. Name, Gruß und Datum lassen sich bei jedem Eintrag korrigieren.",
    "Newest first. Hidden entries stay on the frame but no longer appear on the TV or the phones; deleting removes them for good. You can correct the name, greeting and date of any entry.",
    "Las más nuevas primero. Las entradas ocultas siguen en el marco, pero ya no aparecen en la tele ni en los móviles; borrar las elimina para siempre. Puedes corregir el nombre, el saludo y la fecha de cualquier entrada."],
  noEntries: ["Noch keine Einträge.", "No entries yet.", "Aún no hay entradas."],
  moreEntries: ["{n} von {total} gezeigt.", "Showing {n} of {total}.", "Se muestran {n} de {total}."],
  waiting: ["wartet auf Freigabe", "waiting for approval", "pendiente de aprobación"],
  hiddenFlag: ["ausgeblendet", "hidden", "oculta"],
  approveOne: ["Freigeben", "Approve", "Aprobar"],
  hide: ["Ausblenden", "Hide", "Ocultar"],
  unhide: ["Zeigen", "Show", "Mostrar"],
  edit: ["Ändern", "Edit", "Editar"],
  save: ["Speichern", "Save", "Guardar"],
  cancel: ["Abbrechen", "Cancel", "Cancelar"],
  del: ["Löschen", "Delete", "Borrar"],
  sure: ["Wirklich?", "Sure?", "¿Seguro?"],
  visitNo: ["{n}. Besuch", "visit no. {n}", "visita n.º {n}"],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „Guestbook“ anlegen", "Create the playlist “Guestbook”", "Crear la lista «Guestbook»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la lista (segundos)"],
  playlistHint: ["Die Playlist enthält nur die Szene und ist eingeschaltet. Die Dauer gilt beim Anlegen; danach änderst du sie in der Playlist selbst. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist holds only the scene and is switched on. The duration applies when it is created; after that you change it in the playlist itself. You can also add the scene to any playlist yourself.",
    "La lista contiene solo la escena y está activada. La duración se aplica al crearla; después la cambias en la propia lista. También puedes añadir la escena a cualquier lista."],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status}).", "Error (HTTP {status}).", "Error (HTTP {status})."],
  oclock: ["{time} Uhr", "{time}", "{time}"],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."]
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "";

const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[1]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "en";
  if (chosen === lang && document.documentElement.dataset.applied === chosen) return;
  lang = chosen;
  document.documentElement.dataset.applied = lang;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  entriesKey = "";
  eventsKey = "";
  upcomingKey = "";
  if (current) render(current);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}
const post = (path, body = {}) => api(path, { method: "POST", body: JSON.stringify(body) });

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(epoch) {
  if (!epoch) return "—";
  const date = new Date(epoch * 1000);
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}
const dayText = (iso) => new Date(iso + "T12:00:00").toLocaleDateString(LOCALES[lang], { day: "numeric", month: "short", year: "numeric" });
const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang]);

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await post("./api/settings", changes);
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

// Knöpfe, die etwas Endgültiges tun: erst „Wirklich?“, dann noch einmal tippen.
function confirmClick(button, action) {
  if (button.classList.contains("confirm")) {
    button.classList.remove("confirm");
    action();
    return;
  }
  const label = button.textContent;
  button.classList.add("confirm");
  button.textContent = button.dataset.sure ? t(button.dataset.sure) : t("sure");
  setTimeout(() => {
    if (!button.isConnected || !button.classList.contains("confirm")) return;
    button.classList.remove("confirm");
    button.textContent = label;
  }, 4000);
}

// ------------------------------------------------------------ Verbindungen

function renderServices(sv) {
  if (!sv || !sv.rows || !sv.rows.length) return;
  el("servicesList").innerHTML = sv.rows.map((r) => `<li class="svc ${esc(r.state)}"><span class="dot"></span>
    <div><b>${esc(r.name)}</b> <span class="tag">${esc(t("svc_" + r.state))}</span><div class="txt">${esc(r.text)}</div>
    ${r.hint && r.state !== "ok" ? `<div class="hint2">${esc(r.hint)}</div>` : ""}</div></li>`).join("");
  if (el("servicesNote").dataset.sticky) return;
  const time = clock(sv.at);
  setStatus(sv.bad || sv.warn ? t("servicesSome", { time }) : t("servicesAllOk", { time }),
    sv.bad ? "bad" : sv.warn ? "" : "ok", "servicesNote");
}
el("servicesButton").addEventListener("click", async () => {
  const button = el("servicesButton");
  button.disabled = true;
  el("servicesNote").dataset.sticky = "1";
  setStatus(t("servicesWait"), "busy", "servicesNote");
  try {
    const result = await api("./api/services");
    delete el("servicesNote").dataset.sticky;
    renderServices(result.services);
  } catch (error) {
    delete el("servicesNote").dataset.sticky;
    setStatus(error.message, "bad", "servicesNote");
  }
  button.disabled = false;
});

// ------------------------------------------------------------ Handy

let qrFor = "";
function renderPhone(state) {
  const url = state.phoneUrl;
  el("phoneBox").hidden = !url;
  if (url) {
    const link = `${url}?c=${state.code}`;
    el("phoneUrl").href = link;
    el("phoneUrl").textContent = url.replace(/^https?:\/\//, "").replace(/\/$/, "");
    el("phoneCode").textContent = t("phoneCode", { code: state.code });
    if (link !== qrFor && typeof qrcode === "function") {
      qrFor = link;
      const qr = qrcode(0, "M");
      qr.addData(link);
      qr.make();
      el("phoneQr").innerHTML = qr.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
    }
  }
  const note = !url ? t("phoneNoPort") : !state.pillow ? t("noPillow") : "";
  setStatus(note, note ? "bad" : "", "phoneNote");
}

// ------------------------------------------------------------ Einträge

let entriesKey = "";
let entriesAt = 0;
let editingEntry = "";
async function loadEntries(force = false) {
  if (editingEntry || (!force && Date.now() - entriesAt < 8000)) return;
  entriesAt = Date.now();
  try {
    const result = await api(`./api/entries?f=${encodeURIComponent(el("filter").value || "all")}`);
    renderEntries(result.entries || [], result.total || 0);
  } catch (error) {
    setStatus(error.message, "bad", "entriesNote");
  }
}

function renderEntries(rows, total) {
  const key = lang + el("filter").value + JSON.stringify(rows.map((e) => [e.id, e.st, e.name, e.text, e.day]));
  el("approveAll").hidden = !(current && current.stats && current.stats.waiting);
  if (key === entriesKey) return;
  entriesKey = key;
  if (!rows.length) {
    el("tiles").innerHTML = "";
    setStatus(t("noEntries"), "", "entriesNote");
    return;
  }
  setStatus(rows.length < total ? t("moreEntries", { n: fmt(rows.length), total: fmt(total) }) : "", "", "entriesNote");
  el("tiles").innerHTML = rows.map((e) => {
    const flag = e.st === "wait" ? `<span class="flag">${esc(t("waiting"))}</span>` : e.st === "hidden" ? `<span class="flag">${esc(t("hiddenFlag"))}</span>` : "";
    const first = e.st === "wait" ? ["ok", "approveOne"] : e.st === "hidden" ? ["ok", "unhide"] : ["hidden", "hide"];
    const pic = e.photo ? `<img loading="lazy" src="./api/photo?id=${encodeURIComponent(e.id)}&s=t&admin=1" alt="">`
      : `<div class="mono" style="background:${esc(e.color)}">${esc((e.name || "?").slice(0, 1).toUpperCase())}</div>`;
    const bits = [dayText(e.day)];
    if (e.visit > 1) bits.push(t("visitNo", { n: e.visit }));
    if (e.event) bits.push(e.event);
    return `<div class="tile ${e.st === "wait" ? "wait" : e.st === "hidden" ? "hidden" : ""}" data-entry="${esc(e.id)}">${pic}
      <div class="meta"><b>${esc(e.name)}</b>${e.text ? `<span class="greet">${esc(e.text)}</span>` : ""}
        <span>${esc(bits.join(" · "))}</span>${flag}</div>
      <div class="acts"><button type="button" class="secondary" data-st="${first[0]}" data-id="${esc(e.id)}">${esc(t(first[1]))}</button>
        <button type="button" class="secondary" data-edit="${esc(e.id)}">${esc(t("edit"))}</button>
        <button type="button" class="secondary danger" data-del="${esc(e.id)}">${esc(t("del"))}</button></div></div>`;
  }).join("");
  el("tiles").dataset.rows = JSON.stringify(rows.map((e) => ({ id: e.id, name: e.name, text: e.text, day: e.day })));
}

el("tiles").addEventListener("click", async (event) => {
  const button = event.target.closest("button");
  if (!button) return;
  try {
    if (button.dataset.st) {
      await post("./api/entry/update", { id: button.dataset.id, st: button.dataset.st });
      loadEntries(true);
      refresh();
    } else if (button.dataset.del) {
      confirmClick(button, async () => {
        await post("./api/entry/delete", { id: button.dataset.del }).catch((e) => setStatus(e.message, "bad", "entriesNote"));
        loadEntries(true);
        refresh();
      });
    } else if (button.dataset.edit) {
      const rows = JSON.parse(el("tiles").dataset.rows || "[]");
      const row = rows.find((r) => r.id === button.dataset.edit);
      const tile = button.closest(".tile");
      if (!row || !tile) return;
      editingEntry = row.id;
      tile.querySelector(".acts").hidden = true;
      tile.querySelector(".meta").hidden = true;
      const form = document.createElement("form");
      form.className = "edit";
      form.innerHTML = `<input name="name" maxlength="60" value="${esc(row.name)}">
        <textarea name="text" rows="4" maxlength="400">${esc(row.text)}</textarea>
        <input name="day" type="date" value="${esc(row.day)}">
        <div class="acts"><button type="submit">${esc(t("save"))}</button><button type="button" class="secondary" data-cancel="1">${esc(t("cancel"))}</button></div>`;
      tile.appendChild(form);
    } else if (button.dataset.cancel) {
      editingEntry = "";
      entriesKey = "";
      loadEntries(true);
    }
  } catch (error) {
    setStatus(error.message, "bad", "entriesNote");
  }
});
el("tiles").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.target;
  const id = form.closest(".tile").dataset.entry;
  try {
    await post("./api/entry/update", { id, name: form.name.value, text: form.text.value, day: form.day.value });
    setStatus(t("saved"), "ok", "entriesNote");
  } catch (error) {
    setStatus(error.message, "bad", "entriesNote");
  }
  editingEntry = "";
  entriesKey = "";
  loadEntries(true);
});
el("approveAll").addEventListener("click", async () => {
  await post("./api/approve-all").catch((e) => setStatus(e.message, "bad", "entriesNote"));
  loadEntries(true);
  refresh();
});
el("filter").addEventListener("change", () => {
  entriesKey = "";
  loadEntries(true);
  const value = el("filter").value;
  const event = value.startsWith("ev:") ? value.slice(3) : "";
  el("zipLink").href = event ? `./api/zip?event=${encodeURIComponent(event)}` : "./api/zip";
  el("printBook").href = event ? `./print.html?what=book&event=${encodeURIComponent(event)}` : "./print.html?what=book";
});

function renderFilter(events) {
  const select = el("filter");
  const value = select.value || "all";
  const options = [["all", t("fAll")], ["wait", t("fWait")], ["visits", t("fVisits")]]
    .concat(events.map((e) => [`ev:${e.id}`, t("fEvent", { title: e.title })]));
  select.innerHTML = options.map(([v, label]) => `<option value="${esc(v)}">${esc(label)}</option>`).join("");
  select.value = options.some(([v]) => v === value) ? value : "all";
}

// ------------------------------------------------------------ Feiern

let eventsKey = "";
let eventsAt = 0;
async function loadEvents(force = false) {
  if (!force && Date.now() - eventsAt < 15000) return;
  eventsAt = Date.now();
  try {
    const result = await api("./api/events");
    const rows = result.events || [];
    const key = lang + JSON.stringify(rows);
    if (key === eventsKey) return;
    eventsKey = key;
    renderFilter(rows);
    el("events").innerHTML = rows.length ? rows.map((e) => {
      const date = new Date(e.started * 1000).toLocaleDateString(LOCALES[lang], { day: "numeric", month: "short", year: "numeric" });
      return `<div class="player party-row"><span><b>${esc(e.title)}</b>
        <small>${esc(t("eventRow", { date, n: fmt(e.count) }))}${e.running ? " · " + esc(t("running")) : ""}</small></span>
        <span class="acts">${e.count ? `<button type="button" class="secondary" data-recap="${esc(e.id)}">${esc(t("recap"))}</button>
          <a class="button secondary" href="./print.html?what=book&event=${encodeURIComponent(e.id)}" target="_blank" rel="noopener">${esc(t("print"))}</a>
          <a class="button secondary" href="./api/zip?event=${encodeURIComponent(e.id)}" download>ZIP</a>` : ""}
        ${e.running ? "" : `<button type="button" class="secondary danger" data-del-event="${esc(e.id)}">${esc(t("delEvent"))}</button>`}</span></div>`;
    }).join("") : `<p class="hint">${esc(t("noEvents"))}</p>`;
  } catch (error) {
    setStatus(error.message, "bad", "eventsNote");
  }
}

el("events").addEventListener("click", (event) => {
  const button = event.target.closest("button");
  if (!button) return;
  if (button.dataset.recap) {
    post("./api/event/recap", { id: button.dataset.recap })
      .then(() => { setStatus(t("recapStarted"), "ok", "eventsNote"); refresh(); })
      .catch((e) => setStatus(e.message, "bad", "eventsNote"));
  } else if (button.dataset.delEvent) {
    button.dataset.sure = "delEventSure";
    confirmClick(button, async () => {
      await post("./api/event/delete", { id: button.dataset.delEvent, entries: true }).catch((e) => setStatus(e.message, "bad", "eventsNote"));
      loadEvents(true);
      loadEntries(true);
      refresh();
    });
  }
});

el("partyStart").addEventListener("click", async () => {
  const title = el("partyName").value.trim();
  if (!title) {
    setStatus(t("partyNeedName"), "bad", "partyNote");
    el("partyName").focus();
    return;
  }
  try {
    await post("./api/party/start", { title });
    el("partyName").value = "";
    setStatus("", "", "partyNote");
    await refresh();
    loadEvents(true);
  } catch (error) {
    setStatus(error.message, "bad", "partyNote");
  }
});
el("partyEnd").dataset.sure = "partyEndSure";
el("partyEnd").addEventListener("click", () => confirmClick(el("partyEnd"), async () => {
  try {
    await post("./api/party/end");
    el("partyEnd").textContent = t("partyEnd");
    await refresh();
    loadEvents(true);
  } catch (error) {
    setStatus(error.message, "bad", "partyNote");
  }
}));

// ------------------------------------------------------------ Erinnerungen

let upcomingKey = "";
let upcomingAt = 0;
function memoryText(m) {
  return m.kind === "event" ? t("memEvent", { y: m.years, title: m.title, n: fmt(m.count) })
    : t("memVisit", { y: m.years, names: (m.names || []).join(", ") });
}
async function loadUpcoming(force = false) {
  if (!force && Date.now() - upcomingAt < 300000) return;
  upcomingAt = Date.now();
  try {
    const result = await api("./api/upcoming?days=60");
    const days = result.days || [];
    const key = lang + JSON.stringify(days);
    if (key === upcomingKey) return;
    upcomingKey = key;
    el("upcoming").innerHTML = days.length ? days.slice(0, 12).map((d) => `<li><b>${esc(dayText(d.date))}</b>: ${esc(d.items.map(memoryText).join(" · "))}</li>`).join("")
      : `<li>${esc(t("noUpcoming"))}</li>`;
  } catch (_) { /* nicht schlimm */ }
}

el("memoryButton").addEventListener("click", () => post("./api/memory").then(refresh).catch((e) => setStatus(e.message, "bad", "memNote")));

// ------------------------------------------------------------ Darstellen

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  // Eine eben gewählte Sprache nicht von einer älteren Antwort zurückdrehen lassen.
  if (Date.now() - langChangedAt > 6000 || s.Language === lang) applyLanguage(s.Language);
  if (window.PortBlock) PortBlock.render(state.port, lang);
  const stats = state.stats || {};
  const modeKey = { book: "nowBook", party: "nowParty", recap: "nowRecap" }[state.mode] || "nowBook";
  let now = state.sceneVisible ? t(modeKey) : t("nowOff");
  if (state.takeover) now += t("reason_" + state.takeover, { time: clock(state.takeoverUntil) });
  else if (state.takeoverWanted) now += t("waitTv");
  el("factNow").textContent = now;
  el("factEntries").textContent = stats.waiting ? t("waitingLine", { n: fmt(stats.entries), w: fmt(stats.waiting) }) : fmt(stats.entries);
  el("factGuests").textContent = fmt(stats.guests);
  el("factYear").textContent = fmt(stats.year);
  el("factLast").textContent = state.last ? `${state.last.name} · ${clock(state.last.at)}` : "—";
  el("factVersion").textContent = state.version;
  el("todayLine").textContent = t("todayLine", { title: state.title, code: state.code });
  el("showButton").hidden = Boolean(state.takeover || state.takeoverWanted);
  el("stopButton").hidden = !(state.takeover || state.takeoverWanted);
  setStatus(state.takeoverNote || "", state.takeoverNote ? "bad" : "");
  renderServices(state.services);

  const event = state.event;
  el("partyForm").hidden = Boolean(event);
  el("partyEnd").hidden = !event;
  el("partyLine").hidden = !event;
  if (event) {
    el("partyLine").textContent = t("partyLine", { title: event.title, time: clock(event.started), n: fmt(event.count),
      end: clock(event.started + event.hours * 3600) });
  }

  const mems = state.memories || [];
  el("memToday").textContent = mems.length ? t("memToday", { list: mems.map(memoryText).join(" · ") }) : t("memTodayNone");
  el("memoryButton").hidden = !mems.length;

  if (document.activeElement !== el("MakePlaylist")) el("MakePlaylist").value = String(Boolean(s.MakePlaylist));
  el("playlistNote").textContent = state.ownPlaylist || "";
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Guestbook ${state.version}] `);
  renderPhone(state);

  if (!editing) {
    for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) el(name).value = String(s[name]);
    el("Language").value = lang;
  }
  el("MemoryTime").disabled = !s.MemoryOnTv || !s.Memories;
  el("MemoryMinutes").disabled = !s.MemoryOnTv || !s.Memories;
  loadEvents();
  loadEntries();
  loadUpcoming();
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS, ["partyName"])) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
}
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
for (const name of TEXT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));
el("Language").addEventListener("change", (e) => {
  const chosen = e.target.value;
  langChangedAt = Date.now();
  if (current) current.settings.Language = chosen;
  applyLanguage(chosen);
  save({ Language: chosen });
});

async function action(path, body) {
  try {
    await post(path, body);
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}
el("showButton").addEventListener("click", () => action("./api/show", { minutes: 5 }));
el("stopButton").addEventListener("click", () => action("./api/stop"));
el("codeButton").addEventListener("click", () => action("./api/code"));

renderFilter([]);
applyLanguage(document.documentElement.lang);
refresh();
setInterval(refresh, 4000);

// ---- accordion:start
// ------------------------------------------------------------ Aufklappen (tools/plugin-vorlage/accordion)
// Karten und Abschnitte auf- und zuklappen, damit lange Plugin-Seiten übersichtlich
// bleiben. Gesteuert nur über Attribute im HTML (Anleitung: accordion/README.md):
//   <section class="card" data-fold="immich" data-fold-when="uses:immich"> …
//   <h3 class="sub" data-fold="immichFilter" data-fold-start="closed" data-fold-badge="count">
// Eigene Texte (DE/EN/ES) stehen hier, die Sprache kommt aus <html lang>.
(() => {
  const TEXT = {
    open: ["Aufklappen", "Expand", "Desplegar"],
    close: ["Zuklappen", "Collapse", "Plegar"],
    active: ["{n} aktiv", "{n} active", "{n} activos"],
    none: ["Keine Filter", "No filters", "Sin filtros"],
    set: ["Eingerichtet", "Set up", "Configurado"],
    optional: ["Optional", "Optional", "Opcional"],
    lines: ["{n} eingetragen", "{n} entered", "{n} introducidos"],
    svcOk: ["Alles erreichbar", "All reachable", "Todo accesible"],
    svcBad: ["{n} Problem", "{n} problem", "{n} problema"],
    svcBads: ["{n} Probleme", "{n} problems", "{n} problemas"],
    svcWarn: ["Teilweise", "Partly", "Parcial"],
    svcWait: ["Wird geprüft", "Checking", "Comprobando"],
    "off:immich": ["Nur mit Immich als Quelle nötig", "Only needed with Immich as source", "Solo con Immich como fuente"],
    "off:dynaframe": ["Nur mit Fotos aus DynaFrame nötig", "Only needed with photos from DynaFrame", "Solo con fotos de DynaFrame"],
    "off:library": ["Nur mit „Alle Fotos in DynaFrame“ nötig", "Only needed with “All photos in DynaFrame”", "Solo con «Todas las fotos de DynaFrame»"],
    off: ["Gerade nicht gebraucht", "Not needed right now", "No se necesita ahora"],
  };
  const LANGS = ["de", "en", "es"];
  const say = (key, n) => {
    const row = TEXT[key] || TEXT.off;
    const i = Math.max(0, LANGS.indexOf(document.documentElement.lang));
    return (row[i] ?? row[0]).replace("{n}", String(n));
  };
  const store = (() => {
    try { return window.localStorage; } catch (_) { return null; }
  })();
  const keyOf = (id) => `fold:${location.pathname}:${id}`;
  const remembered = (id) => {
    try { return JSON.parse(store?.getItem(keyOf(id)) || "null"); } catch (_) { return null; }
  };
  const remember = (id, value) => {
    try { store?.setItem(keyOf(id), JSON.stringify(value)); } catch (_) { /* privat */ }
  };

  // Quellen-Auswahl: jedes <select>, das eine Immich-Option hat (auch Quellen-Zeilen, die studio.js erst später baut)
  const DF_KINDS = ["library", "folders", "playlist", "same"];
  function sourceValues() {
    const values = [];
    for (const select of document.querySelectorAll("select")) {
      if ([...select.options].some((o) => o.value.startsWith("immich"))) values.push(select.value);
    }
    return values;
  }
  function holds(rule) {
    // "uses:immich", "uses:dynaframe", "uses:library" oder "Feld=wert1,wert2", mehrere mit "|"
    return rule.split("|").some((part) => {
      part = part.trim();
      if (part.startsWith("uses:")) {
        const values = sourceValues();
        if (!values.length) return true; // keine Quellen-Auswahl auf der Seite: immer gebraucht
        const what = part.slice(5);
        if (what === "immich") return values.some((v) => v.startsWith("immich"));
        if (what === "dynaframe") return values.some((v) => DF_KINDS.includes(v));
        return values.includes(what);
      }
      const [id, list] = part.split("=");
      const field = document.getElementById(id);
      if (!field) return true;
      const value = field.type === "checkbox" ? String(field.checked) : field.value;
      return (list || "").split(",").map((v) => v.trim()).includes(value);
    });
  }

  // Wie viele Einstellungen in einem Bereich vom Standard abweichen (Felder mit Wert, Häkchen, Auswahl ≠ erste Option)
  function activeCount(nodes) {
    let n = 0;
    for (const node of nodes) {
      for (const field of node.querySelectorAll("input, select, textarea")) {
        if (field.closest(".checks") || field.type === "password" || field.type === "button") continue;
        if (field.type === "checkbox") n += field.checked ? 1 : 0;
        else if (field.tagName === "SELECT") n += field.selectedIndex > 0 ? 1 : 0;
        else n += field.value.trim() && field.value.trim() !== "0" ? 1 : 0;
      }
      for (const list of node.querySelectorAll(".checks")) n += list.querySelector("input:checked") ? 1 : 0;
    }
    return n;
  }

  function badgeFor(fold) {
    if (!fold.needed) return [say(`off:${fold.rule.replace(/^uses:/, "").split("|")[0]}`), "off"];
    const nodes = fold.body();
    switch (fold.badge) {
      case "count": {
        const n = activeCount(nodes);
        return n ? [say("active", n), "on"] : [say("none"), ""];
      }
      case "filled": {
        const filled = nodes.some((node) => [...node.querySelectorAll('input[type="url"], input[type="text"]')].some((f) => f.value.trim()));
        return filled ? [say("set"), "on"] : [say("optional"), ""];
      }
      case "lines": {
        const n = nodes.reduce((sum, node) => sum + [...node.querySelectorAll("textarea")]
          .reduce((s, area) => s + area.value.split("\n").filter((line) => line.trim()).length, 0), 0);
        return n ? [say("lines", n), "on"] : [say("optional"), ""];
      }
      case "services": {
        const bad = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.bad").length, 0);
        const warn = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.warn").length, 0);
        const ok = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.ok").length, 0);
        if (bad) return [say(bad === 1 ? "svcBad" : "svcBads", bad), "bad"];
        if (warn) return [say("svcWarn"), "warn"];
        return ok ? [say("svcOk"), "ok"] : [say("svcWait"), ""];
      }
      default:
        return ["", ""];
    }
  }

  const folds = [];

  function setup(head, id, isCard) {
    const host = isCard ? head : head.parentElement;
    const title = isCard ? (head.querySelector(":scope > .card-head") || head.querySelector(":scope > h2")) : head;
    if (!title) return;
    const bar = document.createElement("div");
    bar.className = "fold-bar" + (isCard ? " fold-bar-card" : " fold-bar-sub");
    bar.setAttribute("role", "button");
    bar.tabIndex = 0;
    title.replaceWith(bar);
    bar.append(title);
    const badge = document.createElement("span");
    badge.className = "fold-badge";
    const chevron = document.createElement("span");
    chevron.className = "fold-chevron";
    chevron.setAttribute("aria-hidden", "true");
    bar.append(badge, chevron);
    let body = null;
    if (!isCard) {
      // Unterabschnitt: alles bis zum nächsten h3.sub / <details> / Kartenende
      body = document.createElement("div");
      body.className = "fold-body";
      let next = bar.nextElementSibling;
      while (next && !(next.matches("h3.sub, .fold-bar, details"))) {
        const after = next.nextElementSibling;
        body.append(next);
        next = after;
      }
      bar.after(body);
    }
    const src = head;
    const fold = {
      id, host, bar, body: () => (isCard ? [...host.children].filter((c) => c !== bar) : [body]),
      rule: src.dataset.foldWhen || "",
      startClosed: src.dataset.foldStart === "closed",
      badge: src.dataset.foldBadge || "", badgeEl: badge,
      needed: true, open: true, isCard, sub: body,
    };
    const toggle = (e) => {
      if (e.type === "click" && e.target.closest("button, a, input, select, textarea, label")) return;
      if (e.type === "keydown" && (e.target !== bar || (e.key !== "Enter" && e.key !== " "))) return;
      if (e.type === "keydown") e.preventDefault();
      show(fold, !fold.open);
      remember(id, { open: fold.open, needed: fold.needed });
    };
    bar.addEventListener("click", toggle);
    bar.addEventListener("keydown", toggle);
    folds.push(fold);
    if (fold.rule) show(fold, false); // erst entscheiden, wenn studio.js den Stand gesetzt hat
    else start(fold);
  }

  function start(fold) {
    const saved = remembered(fold.id);
    fold.needed = fold.rule ? holds(fold.rule) : true;
    fold.wasNeeded = fold.needed;
    fold.started = true;
    show(fold, saved && saved.needed === fold.needed ? saved.open : wanted(fold));
  }

  function wanted(fold) {
    if (!fold.needed) return false;
    if (fold.badge === "services") {
      const [, tone] = badgeFor(fold);
      if (tone === "bad") return true;
    }
    return !fold.startClosed;
  }

  function show(fold, open) {
    fold.open = open;
    fold.host.classList.toggle("fold-closed", fold.isCard && !open);
    if (fold.sub) fold.sub.hidden = !open;
    fold.bar.setAttribute("aria-expanded", String(open));
    fold.bar.title = say(open ? "close" : "open");
  }

  // Bereit, sobald studio.js den ersten Stand gezeigt hat (Version steht da) oder nach 5 s
  const born = Date.now();
  function stateShown() {
    const version = document.getElementById("factVersion");
    return !version || /\d/.test(version.textContent) || Date.now() - born > 5000;
  }

  function refresh() {
    const ready = stateShown();
    for (const fold of folds) {
      if (!fold.started) {
        if (!ready) continue;
        start(fold);
      }
      fold.needed = fold.rule ? holds(fold.rule) : true;
      if (fold.needed !== fold.wasNeeded) {
        // Quelle gewechselt: Karte auf- bzw. zuklappen, eigene Wahl vergessen
        fold.wasNeeded = fold.needed;
        remember(fold.id, null);
        show(fold, wanted(fold));
      }
      fold.host.classList.toggle("fold-unused", fold.isCard && !fold.needed);
      const [text, tone] = badgeFor(fold);
      // Verbindungen: bei einem neuen Problem von selbst aufklappen
      if (fold.badge === "services" && tone === "bad" && fold.lastTone !== "bad") show(fold, true);
      fold.lastTone = tone;
      if (fold.badgeEl.textContent !== text) fold.badgeEl.textContent = text;
      fold.badgeEl.className = "fold-badge" + (tone ? ` ${tone}` : "");
      fold.badgeEl.hidden = !text;
      fold.bar.title = say(fold.open ? "close" : "open");
    }
  }

  function init() {
    for (const card of document.querySelectorAll(".card[data-fold]")) setup(card, card.dataset.fold, true);
    for (const head of document.querySelectorAll("h3.sub[data-fold]")) setup(head, head.dataset.fold, false);
    refresh();
    document.addEventListener("change", refresh);
    document.addEventListener("input", refresh);
    setInterval(refresh, 1000); // studio.js setzt Werte beim Abfragen des Stands
  }

  window.Fold = { refresh, open: (id, value = true) => { const f = folds.find((x) => x.id === id); if (f) show(f, value); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
// ---- accordion:end
