# Color Reveal

Black and white turns to colour. Every photo starts in black and white and slowly fills with colour within a few seconds. Used with restraint, it looks lovely.

How the colour comes in:

- **Evenly**: the whole photo, gently
- **From the light**: highlights first, the shadows last
- **From the colour**: from the most colourful spot of the photo outwards, very soft
- **Like a brush stroke**: a soft, uneven wash across the photo
- or **changing** with every photo

Duration of the reveal (2 to 30 seconds), pause before it starts, how much colour at the end (40 to 100 %), black-and-white look (neutral, rich contrast, warm like a silver print), back to black and white before the next photo, photos that are already black and white left out. Full screen, whole photo, or in a gallery frame with mat like a print on the wall; optional very slow zoom and date taken.

Photos come from a DynaFrame playlist, the whole DynaFrame library (WebDAV too, plus extra folders) or an Immich server, with the same filters as Photo Mosaic. The plugin prepares each photo in the size of the screen while the previous one is shown; the scene does the colour with the graphics chip (WebGL), so it stays smooth on a Raspberry Pi 4.

Settings: Plugins > Color Reveal > Open Color Reveal. English, German or Spanish.

Problems or ideas: https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=%5BColor%20Reveal%5D%20
