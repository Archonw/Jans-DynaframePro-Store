#!/usr/bin/env python3
"""Calendar Page - der Plugin-Teil des Pakets "Calendar Page".

Die Szene "calendar-page" zeigt ein Kalenderblatt wie ein schöner
Wandkalender: groß ein Foto aus demselben Monat in einem früheren Jahr (im
Wechsel mehrere, je Jahr eins), daneben der Monat mit Feiertagen,
Schulferien, Terminen aus dem Familienkalender und Geburtstagen mit Foto,
darunter, was als Nächstes kommt.

Dieses Plugin
- liest alle Fotos mit Datum aus einer Playlist von DynaFrame, der ganzen
  Mediendatenbank (und eingehängten Ordnern) oder von Immich (sources.py,
  wie Hall of Records) und wählt je Monat die Fotos (picks.py),
- holt Termine aus ICS-Adressen und Kalendern von Home Assistant
  (calendars.py),
- rechnet Feiertage aus und holt Schulferien (days_off.py),
- kennt Geburtstage aus Immich (Personen mit Geburtsdatum, mit Gesichtsfoto)
  und aus einer eigenen Liste,
- legt das Blatt am Monatsersten (und auf Wunsch an Geburtstagen) morgens
  einmal über die laufende Playlist.
"""

import datetime
import hashlib
import io
import json
import os
import re
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import calendars  # noqa: E402
import days_off  # noqa: E402
import dynaframe_filters  # noqa: E402
import exif_gps  # noqa: E402
import immich_filters  # noqa: E402
import own_playlist  # noqa: E402
import picks  # noqa: E402
import sources  # noqa: E402
import texts  # noqa: E402

try:
    import playback_guard  # noqa: E402  (Umgehung eines Quick-Mix-Fehlers nach Takeovers)
except ImportError:  # pragma: no cover
    playback_guard = None

try:
    from PIL import Image, ImageOps
except ImportError:  # pragma: no cover - kommt mit requirements.txt
    Image = ImageOps = None

HEIF = False
if Image is not None:
    try:
        from pillow_heif import register_heif_opener  # type: ignore

        register_heif_opener()
        HEIF = True
    except Exception:  # noqa: BLE001 - optional
        HEIF = False

plugin = create_plugin()

PLUGIN_ID = "CalendarPage"
DISPLAY_NAME = "Calendar Page"
SCENE_ID = "calendar-page"            # id in scene.dynamic - nie ändern
PLAYLIST_NAME = "Calendar Page"       # in allen Sprachen englisch (Jans Regel, 12.11.2026)
TAKEOVER_PLAYLIST_NAME = "Calendar Page (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Used by the Calendar Page plugin to show the new month's page between your photos. "
                                 "Leave it switched off.")
TAKEOVER_ITEM_SECONDS = 21600
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"        # Einstellungen, Caches; bleibt bei Updates
PHOTO_DIR = DATA_DIR / "photos"
FACE_DIR = DATA_DIR / "faces"

CONNECT_TIMEOUT = 10
MAX_SOURCES = 6
MAX_CALENDARS = 8
MAX_BIRTHDAYS = 60
PHOTO_EDGE = 1600                     # lange Seite der Abzüge für die Szene
FACE_EDGE = 320
KINDS = ("library", "playlist", "immich_all", "immich_album")
CAL_KINDS = ("ics", "ha")
COLORS = ("#c0392b", "#2e86c1", "#27ae60", "#8e44ad", "#d68910", "#16a085", "#c2185b", "#5d6d7e")


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


PRIVATE_FILES = ("settings.json", "events.json", "people.json")


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    if path.name in PRIVATE_FILES:
        try:
            os.chmod(temp, 0o600)  # Schlüssel, Kalenderadressen, Termine
        except OSError:
            pass
    temp.replace(path)


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


def sha(text):
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


def today():
    return datetime.date.today()


def month_key(day):
    return f"{day.year}-{day.month:02d}"


def first_of(day, add=0):
    month = day.month - 1 + add
    return datetime.date(day.year + month // 12, month % 12 + 1, 1)


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

def default_sources():
    return [{"id": "s1", "kind": "library", "ref": "", "name": ""}]


SCHEMA = {
    "Language":        {"kind": "choice", "default": "en", "choices": texts.LANGUAGES},
    "ServerUrl":       {"kind": "url", "default": ""},
    "ApiKey":          {"kind": "secret", "default": ""},
    "Sources":         {"kind": "sources", "default": None},
    "Folders":         {"kind": "folders", "default": ""},
    "Albums":          {"kind": "albums", "default": []},
    # Immich- und DynaFrame-Filter wie Photo Mosaic (ohne „Wann“: das Plugin wählt den Monat selbst)
    **immich_filters.schema(without=immich_filters.WHEN),
    **dynaframe_filters.schema(without=dynaframe_filters.WHEN),
    # Das Blatt
    "Style":           {"kind": "choice", "default": "paper", "choices": ("paper", "linen", "night")},
    "PhotoCount":      {"kind": "int", "default": 6, "min": 1, "max": 12},
    "PhotoSeconds":    {"kind": "int", "default": 12, "min": 5, "max": 120},
    "PreferLandscape": {"kind": "bool", "default": True},
    "WeekStart":       {"kind": "choice", "default": "auto", "choices": ("auto", "mon", "sun")},
    "UpcomingDays":    {"kind": "int", "default": 14, "min": 3, "max": 60},
    "ShowTitles":      {"kind": "bool", "default": True},
    "Animate":         {"kind": "bool", "default": True},
    # Feiertage und Ferien
    "HolidayCountry":  {"kind": "code", "default": "DE"},
    "HolidayRegion":   {"kind": "code", "default": ""},
    "ShowHolidays":    {"kind": "bool", "default": True},
    "ShowSchool":      {"kind": "bool", "default": True},
    # Termine
    "Calendars":       {"kind": "calendars", "default": []},
    "HaUrl":           {"kind": "haurl", "default": ""},
    "HaToken":         {"kind": "secret", "default": ""},
    "CalendarMinutes": {"kind": "int", "default": 30, "min": 10, "max": 720},
    # Geburtstage
    "BirthdaysImmich": {"kind": "bool", "default": True},
    "Birthdays":       {"kind": "birthdays", "default": []},
    # Über die Playlist legen
    "MonthStart":      {"kind": "bool", "default": True},
    "BirthdayMorning": {"kind": "bool", "default": True},
    "ShowTime":        {"kind": "time", "default": "08:00"},
    "ShowSeconds":     {"kind": "int", "default": 60, "min": 15, "max": 600},
    "WakeScreen":      {"kind": "bool", "default": False},
    # Rest
    "RefreshHours":    {"kind": "int", "default": 12, "min": 1, "max": 168},
    "PlaylistSeconds": {"kind": "int", "default": 120, "min": 10, "max": 86400},
    "MakePlaylist":    {"kind": "bool", "default": False},
}
SECRETS = [name for name, spec in SCHEMA.items() if spec["kind"] == "secret"]
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()


def clean_id(value):
    return re.sub(r"[^A-Za-z0-9]", "", str(value or ""))[:16] or uuid.uuid4().hex[:8]


def coerce_sources(raw):
    if raw is None:
        return default_sources()
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return default_sources()
    out, ids = [], set()
    for row in raw if isinstance(raw, list) else []:
        if not isinstance(row, dict) or len(out) >= MAX_SOURCES:
            continue
        ident = clean_id(row.get("id"))
        while ident in ids:
            ident = uuid.uuid4().hex[:8]
        ids.add(ident)
        out.append({
            "id": ident,
            "kind": row.get("kind") if row.get("kind") in KINDS else "library",
            "ref": re.sub(r"[^A-Za-z0-9_-]", "", str(row.get("ref") or ""))[:64],
            "name": re.sub(r"\s+", " ", str(row.get("name") or "")).strip()[:60],
        })
    return out


def coerce_calendars(raw):
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            raw = []
    out, ids = [], set()
    for row in raw if isinstance(raw, list) else []:
        if not isinstance(row, dict) or len(out) >= MAX_CALENDARS:
            continue
        ident = clean_id(row.get("id"))
        while ident in ids:
            ident = uuid.uuid4().hex[:8]
        ids.add(ident)
        kind = row.get("kind") if row.get("kind") in CAL_KINDS else "ics"
        ref = str(row.get("ref") or "").strip()
        if kind == "ics":
            ref = calendars.normalize_ics_url(ref) if ref else ""
        else:
            ref = re.sub(r"[^a-z0-9_.]", "", ref.lower())[:120]
        color = str(row.get("color") or "")
        if not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
            color = COLORS[len(out) % len(COLORS)]
        out.append({"id": ident, "kind": kind, "ref": ref, "color": color.lower(),
                     "name": re.sub(r"\s+", " ", str(row.get("name") or "")).strip()[:40],
                     "on": as_bool(row.get("on"), True)})
    return out


def coerce_birthday_date(raw):
    text = str(raw or "").strip()
    match = re.fullmatch(r"(\d{4}|-?-?)-?(\d{1,2})-(\d{1,2})", text)
    if not match:
        match = re.fullmatch(r"(\d{1,2})\.(\d{1,2})\.(\d{4})?", text)
        if not match:
            return ""
        day, month, year = int(match.group(1)), int(match.group(2)), match.group(3)
    else:
        year, month, day = match.group(1).strip("-"), int(match.group(2)), int(match.group(3))
    try:
        datetime.date(2000, month, day)
    except ValueError:
        return ""
    if year and 1900 <= int(year) <= today().year:
        return f"{int(year):04d}-{month:02d}-{day:02d}"
    return f"--{month:02d}-{day:02d}"


def coerce_birthdays(raw):
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            raw = []
    out, ids = [], set()
    for row in raw if isinstance(raw, list) else []:
        if not isinstance(row, dict) or len(out) >= MAX_BIRTHDAYS:
            continue
        name = re.sub(r"\s+", " ", str(row.get("name") or "")).strip()[:40]
        date = coerce_birthday_date(row.get("date"))
        if not name and not date:
            continue
        ident = clean_id(row.get("id"))
        while ident in ids:
            ident = uuid.uuid4().hex[:8]
        ids.add(ident)
        out.append({"id": ident, "name": name, "date": date,
                    "person": re.sub(r"[^A-Za-z0-9_-]", "", str(row.get("person") or ""))[:64]})
    return out


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind in ("ref", "date", "name"):
        return immich_filters.coerce(spec, raw)
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "choice":
        value = str(raw or "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "sources":
        return coerce_sources(raw)
    if kind == "calendars":
        return coerce_calendars(raw)
    if kind == "birthdays":
        return coerce_birthdays(raw)
    if kind == "albums":
        if isinstance(raw, str):
            raw = [part for part in raw.split(",") if part]
        ids = []
        for item in raw if isinstance(raw, list) else []:
            ident = re.sub(r"[^A-Za-z0-9_-]", "", str(item or ""))[:64]
            if ident and ident not in ids:
                ids.append(ident)
        return ids[:50]
    if kind == "url":
        return sources.normalize_url(raw)[:300]
    if kind == "haurl":
        return calendars.normalize_ha_url(raw)
    if kind == "code":
        return re.sub(r"[^A-Za-z0-9-]", "", str(raw if raw is not None else spec["default"])).upper()[:8]
    if kind == "time":
        match = re.fullmatch(r"(\d{1,2})[:.](\d{2})", str(raw or "").strip())
        if match and int(match.group(1)) < 24 and int(match.group(2)) < 60:
            return f"{int(match.group(1)):02d}:{match.group(2)}"
        return spec["default"]
    if kind == "folders":
        lines = [line.strip() for line in str(raw or "").replace(";", "\n").splitlines()]
        return "\n".join(line for line in lines if line.startswith("/"))[:2000]
    return re.sub(r"\s+", "", str(raw or ""))[:400]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            if name == "Calendars":
                raw = keep_calendar_urls(raw, values["Calendars"])
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def keep_calendar_urls(raw, old):
    """Die Seite bekommt ICS-Adressen nur gekürzt: leer oder gekürzt = alte Adresse behalten."""
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return old
    known = {c["id"]: c for c in old}
    out = []
    for row in raw if isinstance(raw, list) else []:
        if not isinstance(row, dict):
            continue
        row = dict(row)
        before = known.get(str(row.get("id") or ""))
        ref = str(row.get("ref") or "").strip()
        if before and row.get("kind", before["kind"]) == before["kind"] == "ics" \
                and (not ref or ref == calendars.mask_url(before["ref"])):
            row["ref"] = before["ref"]
        out.append(row)
    return out


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


def adopt_connections():
    """Immich-Server und Home Assistant aus anderen Plugins übernehmen, wenn hier keiner steht."""
    values = settings()
    taken = []
    if not (values["ServerUrl"] and values["ApiKey"]):
        for name, title in (("ImmichSlideshow", "Immich Slideshow"), ("GrowingUp", "Growing Up"),
                            ("OnThisDay", "On This Day"), ("HallOfRecords", "Hall of Records"),
                            ("PhotoMosaic", "Photo Mosaic"), ("TravelMap", "Travel Map")):
            other = read_json(PLUGIN_DIR.parent / name / "data" / "settings.json", {}) or {}
            if not isinstance(other, dict):
                continue
            url, key = sources.normalize_url(other.get("ServerUrl")), str(other.get("ApiKey") or "").strip()
            if url and key:
                save_settings({"ServerUrl": url, "ApiKey": key})
                log(f"Immich-Server und API-Schlüssel aus {title} übernommen.")
                taken.append(title)
                break
    if not (values["HaUrl"] and values["HaToken"]):
        for name, title in (("HomeAssistantLive", "Home Assistant Live"), ("MoodyFrame", "Moody Frame"),
                            ("HalloweenScare", "Halloween Scare")):
            other = read_json(PLUGIN_DIR.parent / name / "data" / "settings.json", {}) or {}
            if isinstance(other, dict) and other.get("Url") and other.get("Token"):
                save_settings({"HaUrl": other["Url"], "HaToken": other["Token"]})
                log(f"Home-Assistant-Adresse und Token aus {title} übernommen.")
                taken.append(title)
                break
    return taken


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=120):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def engine_image(media_id, path=""):
    """Das Vorschaubild, das die Engine für die Weboberfläche erzeugt (auf Jans Rahmen 512 Pixel)."""
    candidates = []
    if path:
        candidates += [("/media/thumbnail", {"path": path, "purpose": "preview"}),
                       ("/media/thumbnail", {"path": path})]
    if media_id:
        candidates += [(f"/media/thumbnail/{media_id}", {"purpose": "preview"}),
                       (f"/media/thumbnail/{media_id}", None)]
    failures = []
    for route, params in candidates:
        try:
            response = requests.get(f"{engine_base()}{route}", params=params, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 60))
        except requests.RequestException as exc:
            failures.append(f"{route}: {exc}")
            continue
        kind = response.headers.get("Content-Type", "").split(";")[0]
        if response.status_code == 200 and kind.startswith("image/"):
            return response.content
        failures.append(f"{route}: HTTP {response.status_code} {kind}")
    raise sources.SourceError(f"Vorschaubild {media_id}: " + "; ".join(failures))


# --------------------------------------------------------------------------
# Alle Fotos mit Datum (DynaFrame und Immich), mit Cache für Dateien
# --------------------------------------------------------------------------

immich = sources.Immich(tr)
dynaframe = sources.DynaFrame(engine_call, EngineError, log)
ha = calendars.HomeAssistant()
school = days_off.School(DATA_DIR, log)

EXIF_FILE = DATA_DIR / "exif.json"
_exif = {"data": None, "dirty": 0}
_exif_lock = threading.Lock()


def exif_lookup(path, stamp):
    """(taken, lat, lon) aus der Datei, mit Cache (key = Pfad, Stempel muss passen)."""
    with _exif_lock:
        if _exif["data"] is None:
            stored = read_json(EXIF_FILE, {})
            _exif["data"] = stored if isinstance(stored, dict) else {}
        row = _exif["data"].get(path)
    if isinstance(row, list) and len(row) == 4 and row[0] == stamp:
        return row[1], row[2], row[3]
    lat, lon, taken = exif_gps.read(path)
    taken = sources.clean_taken(taken)
    with _exif_lock:
        _exif["data"][path] = [stamp, taken, lat, lon]
        _exif["dirty"] += 1
    return taken, lat, lon


def exif_save(keep=None):
    with _exif_lock:
        if _exif["data"] is None:
            return
        if keep is not None:
            for key in [k for k in _exif["data"] if k not in keep]:
                del _exif["data"][key]
                _exif["dirty"] += 1
        if _exif["dirty"]:
            write_json(EXIF_FILE, _exif["data"])
            _exif["dirty"] = 0


def key_path(key):
    if key.startswith("d:"):
        return key.partition("|")[2]
    if key.startswith("f:"):
        return key[2:]
    return ""


_stop_requested = threading.Event()
_work_stop = threading.Event()
_wake = threading.Event()
_index_lock = threading.Lock()
_index = {"rows": [], "status": {}, "at": 0.0, "signature": "", "busy": False, "failed": False,
          "progress": {"done": 0, "todo": 0, "phase": ""}, "undated": 0, "total": 0}


def index_signature(values):
    keep = [(s["id"], s["kind"], s["ref"]) for s in values["Sources"]]
    immich_part = [values["ServerUrl"], values["ApiKey"], values["Albums"], immich_filters.signature(values)] \
        if any(s["kind"].startswith("immich") for s in values["Sources"]) else []
    month = month_key(today()) if dynaframe_filters.active(values) else ""
    return sha(json.dumps([keep, values["Folders"], dynaframe_filters.signature(values), immich_part, version(), month],
                          sort_keys=True, default=str))


def read_immich(values, source, status):
    sid = source["id"]
    immich.configure(values["ServerUrl"], values["ApiKey"])
    if source["kind"] == "immich_album":
        if not source["ref"]:
            raise sources.SourceError(tr("Wähle ein Album."))
        albums = [source["ref"]]
    else:
        albums = list(values["Albums"])      # leer = alle Fotos

    def progress(count):
        _index["progress"] = {"done": count, "todo": 0, "phase": "immich"}

    rows = immich.all_rows(albums, _work_stop, immich_filters.from_settings(values), progress)
    status[sid] = {"state": "ok", "total": len(rows), "dated": len(rows), "error": "", "at": now()}
    return rows


def stamp_month(stamp):
    """Monat der letzten Änderung aus dem Stempel einer Zeile (0, wenn unbekannt).
    Datenbank: „größe:2024-11-03T…“, Ordner: „mtime:größe“."""
    text = str(stamp or "")
    found = re.search(r"(19[89]\d|20\d\d)-(\d\d)-\d\d", text)
    if found:
        return int(found.group(2))
    try:
        seconds = int(text.split(":")[0])
        if 315532800 < seconds < 4102444800:      # 1980 … 2100
            return datetime.datetime.fromtimestamp(seconds).month
    except (ValueError, OSError, OverflowError):
        pass
    return 0


def taken_month(row):
    text = row.get("t") or ""
    return int(text[5:7]) if len(text) >= 7 and text[5:7].isdigit() else 0


def publish_partial(rows, match=None, values=None, months=()):
    """Während des ersten langen Einlesens schon ein Blatt mit dem bauen, was da ist
    (mit DynaFrame-Filtern nur, was sie durchlassen)."""
    dated = []
    for row in list(rows.values()):
        if match is not None and not row["k"].startswith("i:"):
            if taken_month(row) not in months:
                continue
            meta = match.meta(row["k"])
            if not meta or not dynaframe_filters.passes(meta, values):
                continue
        if len(row.get("t") or "") >= 10:
            row["pid"] = photo_id(row)
            dated.append({k: row.get(k) for k in ("k", "t", "pid", "stamp", "place", "w", "h", "stars",
                                                  "fav", "cam", "src")})
    if len(dated) <= len(_index["rows"]):
        return
    with _index_lock:
        _index["rows"] = dated
    log(f"Zwischenstand: {len(dated)} Fotos mit Datum.")
    compute_picks("Zwischenstand")


def build_index(reason=""):
    """Alle Quellen einlesen: Datum, Sterne, Format jedes Fotos."""
    values = settings()
    wanted = list(values["Sources"])
    with _index_lock:
        if _index["busy"]:
            return False
        _index["busy"] = True
    started = now()
    status, rows = {}, {}
    match = None
    if any(not s["kind"].startswith("immich") for s in wanted) and dynaframe_filters.active(values):
        match = dynaframe_filters.Matcher(values, lambda: dynaframe.library_rows(_work_stop),
                                          cache_file=str(DATA_DIR / "file_meta.json"), log=log)
    failed = False
    try:
        log(f"Lese die Fotos ein{' - ' + reason if reason else ''}.")
        _index["progress"] = {"done": 0, "todo": 0, "phase": "list"}
        for source in wanted:
            sid = source["id"]
            _index["status"][sid] = dict(_index["status"].get(sid) or {}, state="busy")
            try:
                if source["kind"].startswith("immich"):
                    found = read_immich(values, source, status)
                else:
                    if source["kind"] == "playlist":
                        if not source["ref"]:
                            raise sources.SourceError(tr("Wähle eine Playlist."))
                        try:
                            found, total = dynaframe.playlist(source["ref"], _work_stop)
                        except EngineError as exc:
                            if exc.status == 404:
                                raise sources.SourceError(tr("Die Playlist gibt es nicht mehr.")) from exc
                            raise
                    else:
                        folders = [f for f in values["Folders"].splitlines() if f]
                        found, total = dynaframe.library(folders, _work_stop)
                    status[sid] = {"state": "ok", "total": total, "dated": 0, "error": "", "at": now()}
                for row in found:
                    row["src"] = sid
                    rows.setdefault(row["k"], row)
            except EngineError as exc:
                failed = True
                status[sid] = {"state": "error", "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except sources.SourceError as exc:
                failed = True
                status[sid] = {"state": "error", "error": str(exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except Exception as exc:  # pragma: no cover - darf den Durchlauf nicht beenden
                failed = True
                status[sid] = {"state": "error", "error": str(exc)[:200], "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc!r}", "warning")
            _index["status"][sid] = status[sid]
            if _work_stop.is_set() or _stop_requested.is_set():
                return False

        # Datum aus den Dateien, wo die Engine keins mitliefert. Das kann beim ersten Mal
        # dauern (Jan, 15.11.2026): zuerst die Dateien, die nach ihrem Änderungsdatum zu
        # diesem oder dem nächsten Monat passen, und zwischendurch schon ein Blatt bauen.
        todo = [r for r in rows.values() if not r["t"] and os.path.isfile(key_path(r["k"]))]
        wanted_months = {first_of(today(), add).month for add in (0, 1)}
        immich_sources = {s["id"] for s in wanted if s["kind"].startswith("immich")}
        todo.sort(key=lambda r: stamp_month(r.get("stamp")) not in wanted_months)
        _index["progress"] = {"done": 0, "todo": len(todo), "phase": "exif"}
        shown_at = time.time()
        priority = sum(1 for r in todo if stamp_month(r.get("stamp")) in wanted_months)
        for count, row in enumerate(todo, 1):
            if _work_stop.is_set() or _stop_requested.is_set():
                exif_save()
                return False
            taken, _lat, _lon = exif_lookup(key_path(row["k"]), row["stamp"])
            row["t"] = row["t"] or taken
            _index["progress"]["done"] = count
            if count % 200 == 0:
                time.sleep(0.05)
            if count % 1000 == 0:
                exif_save()             # nach einem Neustart nicht von vorn
            if count == priority or (count % 500 == 0 and time.time() - shown_at > 60):
                shown_at = time.time()
                publish_partial(rows, match, values, wanted_months)
        exif_save(keep={key_path(r["k"]) for r in rows.values() if key_path(r["k"])})
        if match is not None:
            # Die DynaFrame-Filter erst jetzt und nur für die Monate des Blatts: Fotos, die
            # DynaFrame nicht kennt (Ordner-Playlist auf dem NAS), muss der Filter aus der
            # Datei lesen. Für 46 000 Dateien übers Netz dauerte das Stunden (Jan, 15.11.2026).
            kept = {}
            for key, row in rows.items():
                if _work_stop.is_set() or _stop_requested.is_set():
                    match.save()
                    return False
                if row.get("src") in immich_sources or (taken_month(row) in wanted_months and match.keep(key)):
                    kept[key] = row
            match.save()
            rows = kept
        _index["dfCount"] = match.counts() if match is not None else None
        dated = []
        for row in rows.values():
            if len(row["t"]) >= 10:
                row["pid"] = photo_id(row)
                # nur das, was das Blatt braucht (50 000 Fotos auf dem Pi)
                dated.append({k: row.get(k) for k in ("k", "t", "pid", "stamp", "place", "w", "h", "stars",
                                                      "fav", "cam", "src")})
        immich_ids = {s["id"] for s in wanted if s["kind"].startswith("immich")}
        for sid, row in status.items():
            if row.get("state") == "ok" and sid not in immich_ids:
                row["dated"] = sum(1 for r in dated if r.get("src") == sid)
        with _index_lock:
            _index.update(rows=dated, status=dict(_index["status"], **status), at=now(), failed=failed,
                          signature=index_signature(values), undated=len(rows) - len(dated), total=len(rows))
        log(f"{len(dated)} Fotos mit Datum ({len(rows) - len(dated)} ohne), {now() - started:.0f} s.")
        return True
    finally:
        _index["progress"] = {"done": 0, "todo": 0, "phase": ""}
        with _index_lock:
            _index["busy"] = False


def photo_id(row):
    return hashlib.sha1(f"{row['k']}|{row.get('stamp') or ''}".encode("utf-8")).hexdigest()[:20]


# --------------------------------------------------------------------------
# Die Fotos des Monats
# --------------------------------------------------------------------------

EXCLUDED_FILE = DATA_DIR / "excluded.json"
_picks_lock = threading.RLock()
_picks = {"months": {}, "photos": {}, "signature": "", "ver": 0}


def load_excluded():
    stored = read_json(EXCLUDED_FILE, [])
    return [str(x)[:20] for x in stored][:2000] if isinstance(stored, list) else []


def picks_signature(values, day=None):
    day = day or today()
    return sha(json.dumps([_index["at"], _index["signature"], month_key(day), values["PhotoCount"],
                           values["PreferLandscape"], load_excluded(), version()], default=str))


def compute_picks(reason=""):
    values = settings()
    day = today()
    rows = list(_index["rows"])
    excluded = load_excluded()
    months, photos = {}, {}
    for add in (0, 1):
        first = first_of(day, add)
        chosen = picks.pick(rows, first.year, first.month, values["PhotoCount"], excluded,
                            prefer_landscape=values["PreferLandscape"])
        listed = []
        for row in chosen:
            photos[row["pid"]] = {"k": row["k"], "stamp": row.get("stamp") or ""}
            listed.append({"id": row["pid"], "t": row["t"], "place": row.get("place") or "",
                           "w": row.get("w"), "h": row.get("h"), "stars": row.get("stars") or 0})
        months[month_key(first)] = {"photos": listed, **picks.month_stats(rows, first.month)}
    with _picks_lock:
        _picks.update(months=months, photos=photos, signature=picks_signature(values, day), ver=_picks["ver"] + 1)
    save_last()
    log(f"Fotos fürs Blatt{' - ' + reason if reason else ''}: " +
        ", ".join(f"{k}: {len(v['photos'])}" for k, v in months.items()))
    threading.Thread(target=prefetch, name=f"{PLUGIN_ID}-prefetch", daemon=True).start()


def exclude(body):
    """Ein Foto nicht mehr aufs Blatt nehmen (oder alle wieder zulassen)."""
    stored = load_excluded()
    if body.get("reset"):
        stored = []
    else:
        pid = re.sub(r"[^0-9a-f]", "", str(body.get("id") or ""))[:20]
        if not pid:
            return {"success": False, "error": "id"}
        if pid not in stored:
            stored.append(pid)
    write_json(EXCLUDED_FILE, stored[-2000:])
    threading.Thread(target=compute_picks, args=("nicht nehmen",), daemon=True).start()
    return {"success": True}


PHOTO_MAX = 40 * 1024 * 1024
SHOWABLE = (".jpg", ".jpeg", ".jpe", ".png", ".webp", ".gif", ".bmp", ".tif", ".tiff")


def webdav_dirs():
    seen = []
    for home in (Path.home(), Path("/home/pi")):
        folder = home / ".local/share/dfr/webdav-cache"
        if folder not in seen and folder.is_dir():
            seen.append(folder)
    return seen


def webdav_cached(path, size):
    """Fotos aus WebDAV (/webdav-media/<Quelle>/...) liefert die Engine nur als
    512-Pixel-Vorschau; das Original liegt oft in webdav-cache (wie Halloween Scare)."""
    if not path.startswith("/webdav-media/"):
        return None
    size = as_int(size, 0)
    if size <= 0 or size > PHOTO_MAX:
        return None
    parts = path.split("/")
    source = parts[2] if len(parts) > 2 else ""
    suffix = Path(path).suffix.lower()
    best = None
    for folder in webdav_dirs():
        try:
            entries = list(os.scandir(folder))
        except OSError:
            continue
        for entry in entries:
            name = entry.name
            if source and not name.startswith(source + "-"):
                continue
            if suffix and not name.lower().endswith(suffix):
                continue
            try:
                info = entry.stat()
            except OSError:
                continue
            if info.st_size == size and (best is None or info.st_mtime > best[0]):
                best = (info.st_mtime, Path(entry.path))
    return best[1] if best else None


def shrink(source, edge=PHOTO_EDGE):
    """Bild (Pfad oder Bytes) gedreht nach Exif und verkleinert als JPEG-Bytes."""
    if Image is None:
        raise sources.SourceError("Pillow fehlt")
    handle = io.BytesIO(source) if isinstance(source, (bytes, bytearray)) else source
    with Image.open(handle) as image:
        try:
            image.draft("RGB", (edge, edge))
        except Exception:  # noqa: BLE001 - nur JPEG kennt draft
            pass
        image = ImageOps.exif_transpose(image)
        image = image.convert("RGB")
        image.thumbnail((edge, edge), Image.LANCZOS)
        out = io.BytesIO()
        image.save(out, "JPEG", quality=85, optimize=True, progressive=True)
        return out.getvalue()


def photo_file(pid):
    return PHOTO_DIR / f"{pid}.jpg"


def prepare(pid):
    """Den Abzug als JPEG im Cache ablegen; liefert den Pfad."""
    target = photo_file(pid)
    if target.is_file():
        return target
    item = _picks["photos"].get(pid)
    if not item:
        raise sources.SourceError("unbekanntes Foto")
    key = item["k"]
    data = None
    if key.startswith("i:"):
        values = settings()
        immich.configure(values["ServerUrl"], values["ApiKey"])
        raw, _kind = immich.photo(key[2:], size="preview")
        try:
            data = shrink(raw)
        except Exception:  # noqa: BLE001 - dann so, wie Immich es schickt
            data = raw
    else:
        path = key_path(key)
        local = path and os.path.isfile(path)
        if local and (path.lower().endswith(SHOWABLE) or HEIF):
            try:
                data = shrink(path)
            except Exception as exc:  # noqa: BLE001 - kaputte Datei: über die Engine
                log(f"Foto {path}: {exc}", "warning")
        if data is None and path.startswith("/webdav-media/"):
            cached = webdav_cached(path, str(item.get("stamp") or "").split(":")[0])
            if cached:
                try:
                    data = shrink(str(cached))
                except Exception:  # noqa: BLE001
                    data = None
        if data is None and key.startswith("d:"):
            raw = engine_image(key[2:].partition("|")[0], path)
            try:
                data = shrink(raw)
            except Exception:  # noqa: BLE001
                data = raw
        if data is None:
            raise sources.SourceError("Foto nicht gefunden")
    PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(f".{threading.get_ident()}.tmp")
    temp.write_bytes(data)
    temp.replace(target)
    return target


_prepare_lock = threading.Lock()


def prefetch():
    """Die Abzüge dieses und des nächsten Monats vorbereiten; alte löschen."""
    with _prepare_lock:
        wanted = set(_picks["photos"])
        failed = 0
        for pid in list(wanted):
            if _stop_requested.is_set():
                return
            try:
                prepare(pid)
            except Exception as exc:  # noqa: BLE001
                failed += 1
                if failed <= 3:
                    log(f"Abzug für die Szene: {exc}", "warning")
        try:
            for entry in os.scandir(PHOTO_DIR):
                if entry.name.endswith(".jpg") and entry.name[:-4] not in wanted:
                    os.unlink(entry.path)
        except OSError:
            pass


def photo_bytes(query):
    pid = re.sub(r"[^0-9a-f]", "", (query.get("p") or [""])[0])[:20]
    if not pid or pid not in _picks["photos"]:
        return None
    try:
        return prepare(pid).read_bytes()
    except Exception as exc:  # noqa: BLE001
        log(f"Abzug für die Szene: {exc}", "warning")
        return None


# --------------------------------------------------------------------------
# Geburtstage (Immich-Personen mit Geburtsdatum und eigene Liste)
# --------------------------------------------------------------------------

PEOPLE_FILE = DATA_DIR / "people.json"
_people = {"rows": None, "at": 0.0, "error": "", "busy": False}


def load_people():
    if _people["rows"] is None:
        stored = read_json(PEOPLE_FILE, {})
        _people["rows"] = stored.get("rows") or [] if isinstance(stored, dict) else []
        _people["at"] = (stored.get("at") or 0.0) if isinstance(stored, dict) else 0.0
    return _people["rows"]


def immich_ready(values=None):
    values = values or settings()
    return bool(values["ServerUrl"] and values["ApiKey"])


def fetch_people(force=False):
    """Alle benannten Immich-Personen (für Geburtstage und die Auswahl auf der Seite)."""
    values = settings()
    load_people()
    if not immich_ready(values) or _people["busy"]:
        return
    if not force and now() - _people["at"] < values["RefreshHours"] * 3600:
        return
    _people["busy"] = True
    try:
        immich.configure(values["ServerUrl"], values["ApiKey"])
        data = immich.call("GET", "/people", params={"withHidden": "false", "size": 1000}) or {}
        rows = data.get("people") if isinstance(data, dict) else data
        out = []
        for row in rows or []:
            if isinstance(row, dict) and row.get("id") and row.get("name"):
                birth = str(row.get("birthDate") or "")[:10]
                out.append({"id": str(row["id"]), "name": str(row["name"])[:40],
                            "birth": birth if re.fullmatch(r"\d{4}-\d{2}-\d{2}", birth) else ""})
        out.sort(key=lambda r: r["name"].lower())
        _people.update(rows=out, at=now(), error="")
        write_json(PEOPLE_FILE, {"rows": out, "at": _people["at"]})
        log(f"{len(out)} Personen aus Immich, {sum(1 for r in out if r['birth'])} mit Geburtsdatum.")
    except sources.SourceError as exc:
        _people.update(error=str(exc), at=now())
        log(f"Personen aus Immich: {exc}", "warning")
    finally:
        _people["busy"] = False


def face_id(person):
    return "p" + re.sub(r"[^A-Za-z0-9]", "", person)[:40]


def face_bytes(query):
    fid = re.sub(r"[^A-Za-z0-9]", "", (query.get("f") or [""])[0])[:41]
    if not fid.startswith("p"):
        return None
    target = FACE_DIR / f"{fid}.jpg"
    if target.is_file() and now() - target.stat().st_mtime < 14 * 86400:
        return target.read_bytes()
    person = next((r["id"] for r in load_people() if face_id(r["id"]) == fid), None)
    if not person:
        return target.read_bytes() if target.is_file() else None
    values = settings()
    try:
        immich.configure(values["ServerUrl"], values["ApiKey"])
        raw = immich.call("GET", f"/people/{person}/thumbnail", raw=True, timeout=30).content
        try:
            data = shrink(raw, FACE_EDGE)
        except Exception:  # noqa: BLE001
            data = raw
    except sources.SourceError as exc:
        log(f"Gesicht {person}: {exc}", "warning")
        return target.read_bytes() if target.is_file() else None
    FACE_DIR.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(f".{threading.get_ident()}.tmp")
    temp.write_bytes(data)
    temp.replace(target)
    return data


def occurrence(md, year):
    """--MM-DD bzw. YYYY-MM-DD im Jahr `year` (29.2. -> 28.2. in anderen Jahren)."""
    month, day = int(md[-5:-3]), int(md[-2:])
    try:
        return datetime.date(year, month, day)
    except ValueError:
        return datetime.date(year, 2, 28)


def birthdays(start, end, values=None):
    """Geburtstage zwischen start und end (inklusive): [{id, name, date, age, face}]."""
    values = values or settings()
    people = {r["id"]: r for r in load_people()}
    entries = []
    seen = set()
    for row in values["Birthdays"]:
        if not row["date"]:
            continue
        person = people.get(row["person"]) if row["person"] else None
        entries.append({"id": "b" + row["id"], "name": row["name"] or (person or {}).get("name", "?"),
                        "date": row["date"], "face": face_id(row["person"]) if person else ""})
        if row["person"]:
            seen.add(row["person"])
    if values["BirthdaysImmich"] and immich_ready(values):
        for person in people.values():
            if person["birth"] and person["id"] not in seen:
                entries.append({"id": "i" + person["id"][:12], "name": person["name"], "date": person["birth"],
                                "face": face_id(person["id"])})
    out = []
    for entry in entries:
        for year in range(start.year, end.year + 1):
            day = occurrence(entry["date"], year)
            if start <= day <= end:
                born = entry["date"][:4]
                age = year - int(born) if born.isdigit() and int(born) < year else None
                out.append({"id": entry["id"], "name": entry["name"], "date": day.isoformat(), "age": age,
                            "face": entry["face"]})
    return sorted(out, key=lambda b: (b["date"], b["name"].lower()))


# --------------------------------------------------------------------------
# Termine
# --------------------------------------------------------------------------

EVENTS_FILE = DATA_DIR / "events.json"
_cal = {"events": {}, "status": {}, "at": 0.0, "busy": False, "signature": "", "window": ["", ""]}
_cal_lock = threading.Lock()


def cal_window(values=None):
    values = values or settings()
    day = today()
    start = first_of(day) - datetime.timedelta(days=7)
    end = max(first_of(day, 2), day + datetime.timedelta(days=values["UpcomingDays"] + 1))
    return start, end


def cal_signature(values):
    return sha(json.dumps([[(c["id"], c["kind"], c["ref"], c["on"]) for c in values["Calendars"]],
                           values["HaUrl"], values["HaToken"], cal_window(values)[0].isoformat()], default=str))


def fetch_calendars(reason=""):
    values = settings()
    with _cal_lock:
        if _cal["busy"]:
            return
        _cal["busy"] = True
    try:
        start, end = cal_window(values)
        events, status = {}, {}
        ha.configure(values["HaUrl"], values["HaToken"])
        for cal in values["Calendars"]:
            if not cal["on"]:
                continue
            started = now()
            try:
                if not cal["ref"]:
                    raise calendars.CalendarError("", "no-ref")
                if cal["kind"] == "ics":
                    rows = calendars.parse_ics(calendars.fetch_ics(cal["ref"]), start, end)
                else:
                    rows = ha.events(cal["ref"], start, end)
                events[cal["id"]] = rows
                status[cal["id"]] = {"state": "ok", "count": len(rows), "ms": int((now() - started) * 1000),
                                     "at": now(), "error": ""}
            except calendars.CalendarError as exc:
                old = (_cal["events"] or {}).get(cal["id"])
                if old is not None:
                    events[cal["id"]] = old            # die alten Termine weiter zeigen
                status[cal["id"]] = {"state": "error", "error": cal_error_text(exc, cal), "code": exc.code,
                                     "at": now(), "count": len(old or [])}
                log(f"Kalender {cal['name'] or cal['kind']}: {exc.code} {exc}", "warning")
        with _cal_lock:
            _cal.update(events=events, status=status, at=now(), signature=cal_signature(values),
                        window=[start.isoformat(), end.isoformat()])
        write_json(EVENTS_FILE, {"events": events, "at": _cal["at"], "window": _cal["window"]})
        log(f"Termine{' - ' + reason if reason else ''}: " +
            ", ".join(f"{k}={len(v)}" for k, v in events.items()) if events else "Keine Kalender eingetragen.")
        with _picks_lock:
            _picks["ver"] += 1
    finally:
        with _cal_lock:
            _cal["busy"] = False


def cal_error_text(exc, cal):
    code = exc.code
    if code == "no-ref":
        return tr("Trag die Adresse des Kalenders ein.") if cal["kind"] == "ics" else tr("Wähle einen Kalender aus Home Assistant.")
    if code == "no-url":
        return tr("Trag die Adresse von Home Assistant ein.")
    if code == "no-token":
        return tr("Trag einen Token von Home Assistant ein.")
    if code == "token":
        return tr("Home Assistant lehnt den Token ab.")
    if code == "denied":
        return tr("Der Server verweigert den Kalender ({exc}). Ist es die geheime Adresse im iCal-Format?", exc=exc)
    if code == "not-found":
        return tr("Diesen Kalender gibt es nicht (mehr).")
    if code == "not-ics":
        return tr("Unter dieser Adresse liegt kein Kalender im iCal-Format.")
    if code == "too-big":
        return tr("Der Kalender ist größer als 15 MB.")
    if code == "missing-lib":
        return tr("Dem Plugin fehlt ein Baustein (icalendar). Installiere das Paket noch einmal.")
    if code == "ssl" and "wrong version" in str(exc):
        return tr("Der Server spricht kein HTTPS. Versuch die Adresse mit http:// statt https:// bzw. webcal://.")
    if code == "ssl":
        return tr("Das Zertifikat des Servers passt nicht: {exc}", exc=exc)
    return tr("Nicht erreichbar: {exc}", exc=exc)


def load_events():
    stored = read_json(EVENTS_FILE, {})
    if isinstance(stored, dict) and isinstance(stored.get("events"), dict):
        _cal.update(events=stored["events"], window=stored.get("window") or ["", ""])


def events_between(start, end, values=None):
    """Alle Termine, die zwischen start und end (date, inklusive) liegen, mit Farbe."""
    values = values or settings()
    first, last = start.isoformat(), (end + datetime.timedelta(days=1)).isoformat()
    out = []
    for cal in values["Calendars"]:
        if not cal["on"]:
            continue
        for event in (_cal["events"] or {}).get(cal["id"]) or []:
            begin = event["start"][:10]
            finish = event["end"][:10] if event.get("end") else begin
            if begin >= last or (finish < first if event["allDay"] else finish < first):
                continue
            out.append(dict(event, cal=cal["id"], color=cal["color"], calName=cal["name"]))
    out.sort(key=lambda e: (e["start"][:10], not e["allDay"], e["start"], e["title"].lower()))
    return out


# --------------------------------------------------------------------------
# Feiertage und Ferien
# --------------------------------------------------------------------------

def week_start(values):
    if values["WeekStart"] != "auto":
        return values["WeekStart"]
    return "sun" if days_off.week_starts_sunday(values["HolidayCountry"]) else "mon"


def holidays_between(start, end, values, allow_fetch=False):
    lang = values["Language"]
    out_public, out_school = [], []
    for year in range(start.year, end.year + 1):
        if values["ShowHolidays"]:
            try:
                out_public += days_off.public(values["HolidayCountry"], values["HolidayRegion"], year, lang)
            except Exception as exc:  # noqa: BLE001
                log(f"Feiertage {values['Country']}: {exc}", "warning")
        if values["ShowSchool"]:
            out_school += school.periods(values["HolidayCountry"], values["HolidayRegion"], year, lang, allow_fetch=allow_fetch)
    first, last = start.isoformat(), end.isoformat()
    public = [h for h in out_public if first <= h["date"] <= last]
    seen, school_rows = set(), []
    for row in out_school:
        key = (row["start"], row["end"], row["name"])
        if key not in seen and row["end"] >= first and row["start"] <= last:
            seen.add(key)
            school_rows.append(row)
    return public, sorted(school_rows, key=lambda r: r["start"])


def fetch_school():
    values = settings()
    if not values["ShowSchool"] or values["HolidayCountry"] not in days_off.SCHOOL_COUNTRIES:
        return
    start, end = cal_window(values)
    for year in range(start.year, end.year + 1):
        school.periods(values["HolidayCountry"], values["HolidayRegion"], year, values["Language"], allow_fetch=True)


# --------------------------------------------------------------------------
# Über die Playlist legen: Monatserster und Geburtstage
# --------------------------------------------------------------------------

STATE_FILE = DATA_DIR / "state.json"


def load_state():
    stored = read_json(STATE_FILE, {})
    return stored if isinstance(stored, dict) else {}


def save_state(**fields):
    state = load_state()
    state.update(fields)
    write_json(STATE_FILE, state)


TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
_takeover_lock = threading.Lock()
_takeover = {"handle": None, "since": None, "until": 0.0, "token": 0, "note": "", "focus": "", "pending": None}
_scene = {"dbId": None, "note": ""}
_playlists = {"at": 0.0, "takeoverId": None, "note": ""}
_playlist_lock = threading.Lock()


def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}", read_timeout=15)
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else
                      tr("Die Szene Calendar Page ist auf der Plugins-Seite ausgeschaltet."))
        return row
    _scene.update(dbId=None, note=tr("Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal."))
    return None


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    data = engine_call("GET", "/playlists") or []
    if isinstance(data, dict):
        data = data.get("playlists") or data.get("items") or []
    return [p for p in data if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError:
        return False
    return bool(status.get("active"))


def takeover_wanted(values=None):
    values = values or settings()
    return values["MonthStart"] or values["BirthdayMorning"]


def ensure_takeover_playlist():
    """Ein Takeover spielt eine Playlist: die Szene allein, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if same_id(i.get("dynamicSceneId"), _scene["dbId"])]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_PLAYLIST_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=TAKEOVER_PLAYLIST_NAME))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def maintain_playlists(force=False):
    if not takeover_wanted() and not load_state().get("takeoverPlaylistId"):
        return
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 120:
            return
        _playlists["at"] = now()
        find_scene()
        if _scene["dbId"] is None:
            _playlists["note"] = _scene["note"]
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc)
            log(_playlists["note"], "warning")


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform", read_timeout=10) or {}
    except EngineError:
        return True
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover", read_timeout=10) or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Calendar Page ist auf der Plugins-Seite ausgeschaltet.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Calendar Page auf der Plugins-Seite aus. Schalte es ein, sonst kann "
                  "das Blatt nicht über die Playlist gelegt werden.")
    return ""


def display_is_off():
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        log(text)
    return False


def _on_session_state(handle_or_state):
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _takeover.update(handle=None, since=None, until=0.0, focus="")
    log(f"Der Rahmen hat das Blatt beendet: {new_state}.")
    threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason, token=None):
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        _takeover.update(handle=None, since=None, until=0.0, focus="")
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:  # noqa: BLE001
        log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", "warning")
    log(f"Bildschirm zurückgegeben ({reason}).")
    if reason != "stopped":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def show_sheet(pending):
    if not takeover_supported():
        return _note(tr("Dieser Rahmen ist zu alt, um ein Plugin den Bildschirm übernehmen zu lassen."))
    find_scene()
    if _scene["dbId"] is None or _scene["note"]:
        return _note(_scene["note"] or tr("Die Szene wurde nicht gefunden."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("Die Takeover-Playlist ist noch nicht angelegt."))
    values = settings()
    wake = values["WakeScreen"]
    if not wake and display_is_off():
        return _note(tr("Der Bildschirm ist aus; das Blatt wartet, bis er wieder an ist."))
    seconds = values["ShowSeconds"]
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             "overlay": {"enabled": False}}
    with _takeover_lock:
        _takeover["focus"] = pending["kind"]      # die Szene fragt schon während acquire
    try:
        _leftover["askedAt"] = time.time()
        handle = plugin.acquire_display_session(
            session_key=pending["kind"], state=state, display_name=DISPLAY_NAME,
            max_duration_seconds=seconds + 30, wake_if_off=bool(wake))
    except Exception as exc:  # noqa: BLE001
        return _note(tr("Konnte das Blatt nicht zeigen: {exc}", exc=exc))
    if handle is None:
        return _note(takeover_permission_note() or tr("Gerade hat etwas anderes den Bildschirm."))
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, since=now(), until=now() + seconds, note="")
    try:
        handle.on_state_change(_on_session_state)
    except Exception:  # noqa: BLE001
        pass
    try:
        if not handle.wait_until_active(timeout=10):
            end_takeover("failed", token)
            return _note(tr("Der Rahmen hat das Blatt nicht rechtzeitig gezeigt."))
    except Exception as exc:  # noqa: BLE001
        end_takeover("failed", token)
        return _note(tr("Konnte das Blatt nicht zeigen: {exc}", exc=exc))
    log(f"Kalenderblatt auf dem Bildschirm ({pending['kind']}, {seconds} s).")
    return True


def show_time_reached(values):
    hour, minute = (int(x) for x in values["ShowTime"].split(":"))
    moment = datetime.datetime.now()
    return (moment.hour, moment.minute) >= (hour, minute) and moment.hour < 22


def due_takeover(values):
    """Was heute fällig ist: ('month', key) am Monatsersten, ('birthday', key) an Geburtstagen."""
    day = today()
    if not show_time_reached(values):
        return None
    state = load_state()
    if values["MonthStart"] and day.day == 1 and state.get("shownMonth") != month_key(day):
        return {"kind": "month", "key": month_key(day)}
    if values["BirthdayMorning"] and state.get("shownBirthday") != day.isoformat() and birthdays(day, day, values):
        return {"kind": "birthday", "key": day.isoformat()}
    return None


def mark_shown(pending):
    if pending["kind"] == "month":
        save_state(shownMonth=pending["key"])
    elif pending["kind"] == "birthday":
        save_state(shownBirthday=pending["key"])


def decide_takeover():
    with _takeover_lock:
        handle = _takeover["handle"]
        until = _takeover["until"]
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
        elif now() >= until:
            end_takeover("fertig")
        return
    values = settings()
    pending = _takeover["pending"]
    if pending is None or pending.get("kind") != "test":
        due = due_takeover(values)
        if due is None:
            _takeover["pending"] = None
            return
        if pending is None or pending.get("key") != due["key"] or pending.get("kind") != due["kind"]:
            pending = _takeover["pending"] = dict(due, tries=0, triedAt=0.0)
    if pending["tries"] >= 30 and pending["kind"] != "test":
        mark_shown(pending)                     # heute nicht mehr
        _takeover["pending"] = None
        return
    if now() - pending.get("triedAt", 0) < 60:
        return
    pending["tries"] += 1
    pending["triedAt"] = now()
    if show_sheet(pending):
        if pending["kind"] != "test":
            mark_shown(pending)
        _takeover["pending"] = None
    elif pending["kind"] == "test" and pending["tries"] >= 2:
        _takeover["pending"] = None


def show_now():
    """Knopf „Jetzt zeigen“: das Blatt gleich über die Playlist legen."""
    _takeover["pending"] = {"kind": "test", "key": "", "tries": 0, "triedAt": 0.0}
    _playlists["at"] = 0.0
    return {"success": True, "message": tr("Das Blatt kommt gleich auf den Bildschirm.")}


# Lief vor einem Takeover keine Playlist, läuft die Takeover-Playlist danach
# weiter (Jans Rahmen, 2026-10-24): dann mit POST /slideshow/stop anhalten.
_leftover = {"askedAt": 0.0, "failed": False}


def stop_leftover_takeover():
    try:
        playlist_id = _playlists["takeoverId"]
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status", read_timeout=5) or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status", read_timeout=5) or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop", read_timeout=10)
    except Exception as exc:  # noqa: BLE001 - darf die Schleife nie aufhalten
        if not _leftover["failed"]:
            log(f"Die Takeover-Playlist lief weiter und ließ sich nicht anhalten: {exc}", "warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    log("Vor dem Blatt lief nichts, darum wurde die weiterlaufende Takeover-Playlist angehalten.")
    return True


def check_playback_resumed():
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, log, stop_event=_stop_requested)
        if outcome == "not-requested":
            return
    elif _stop_requested.wait(12):
        return


# --------------------------------------------------------------------------
# Verbindungen prüfen (Karte auf der Einstellungsseite)
# --------------------------------------------------------------------------

SERVICES_EVERY = 5 * 60
_services = {"at": 0.0, "rows": [], "busy": False}
_services_lock = threading.Lock()


def _row(key, name, state, text, hint=""):
    return {"key": key, "name": name, "state": state, "text": text, "hint": hint}


def _check_engine():
    started = time.time()
    try:
        engine_call("GET", "/plugins/platform", read_timeout=8)
    except EngineError as exc:
        return _row("engine", tr("DynaFrame auf diesem Rahmen"), "bad", tr("Nicht erreichbar: {exc}", exc=exc),
                    tr("Starte den Rahmen neu, wenn das rot bleibt."))
    ms = int((time.time() - started) * 1000)
    return _row("engine", tr("DynaFrame auf diesem Rahmen"), "ok", tr("Erreichbar ({ms} ms).", ms=ms))


def _check_photos(values):
    name = tr("Deine Fotos")
    if _index["busy"] and not _index["at"]:
        progress = _index["progress"] or {}
        if progress.get("phase") == "exif" and progress.get("todo"):
            return _row("photos", name, "warn", tr("Werden zum ersten Mal eingelesen: {done} von {todo} Dateien, {n} Fotos mit Datum bisher.",
                                                    done=progress.get("done", 0), todo=progress["todo"], n=len(_index["rows"])),
                        tr("Das erste Einlesen liest das Aufnahmedatum aus jeder Datei, die DynaFrame ohne Datum liefert. Danach geht es schnell."))
        return _row("photos", name, "warn", tr("Werden gerade zum ersten Mal eingelesen …"))
    bad = [s for s in values["Sources"] if (_index["status"].get(s["id"]) or {}).get("state") == "error"]
    if bad:
        first = _index["status"][bad[0]["id"]]
        return _row("photos", name, "bad", tr("{n} Quelle(n) mit Fehler: {exc}", n=len(bad), exc=first.get("error")),
                    tr("Sieh in der Karte „Fotos“ nach."))
    if not _index["at"]:
        return _row("photos", name, "warn", tr("Noch nicht eingelesen."))
    if not _index["rows"]:
        return _row("photos", name, "bad", tr("Keine Fotos mit Datum gefunden."), tr("Prüfe die Quellen und Filter."))
    month = (_picks["months"] or {}).get(month_key(today())) or {}
    text = tr("{n} Fotos mit Datum; für diesen Monat {m} aus {y} Jahren.", n=len(_index["rows"]),
              m=month.get("count", 0), y=month.get("years", 0))
    if not month.get("years"):
        return _row("photos", name, "warn", text, tr("Ohne Fotos aus diesem Monat zeigt das Blatt nur den Kalender."))
    return _row("photos", name, "ok", text)


def _check_immich(values):
    uses = any(s["kind"].startswith("immich") for s in values["Sources"])
    if not uses and not (values["BirthdaysImmich"] and immich_ready(values)):
        return None
    name = "Immich"
    if not immich_ready(values):
        return _row("immich", name, "bad", tr("Adresse oder API-Schlüssel fehlt."), tr("Trag sie in der Karte „Immich-Server“ ein."))
    started = time.time()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        info = immich.test()
    except sources.SourceError as exc:
        return _row("immich", name, "bad", str(exc))
    ms = int((time.time() - started) * 1000)
    text = tr("Erreichbar ({ms} ms), Immich {version}.", ms=ms, version=info["version"] or "?")
    if values["BirthdaysImmich"]:
        born = sum(1 for r in load_people() if r["birth"])
        text += " " + tr("{n} Personen mit Geburtsdatum.", n=born)
    return _row("immich", name, "ok", text)


def _check_ha(values):
    if not any(c["kind"] == "ha" and c["on"] for c in values["Calendars"]):
        return None
    name = "Home Assistant"
    ha.configure(values["HaUrl"], values["HaToken"])
    started = time.time()
    try:
        info = ha.test()
    except calendars.CalendarError as exc:
        return _row("ha", name, "bad", cal_error_text(exc, {"kind": "ha"}))
    ms = int((time.time() - started) * 1000)
    return _row("ha", name, "ok", tr("Erreichbar ({ms} ms), Home Assistant {version}.", ms=ms, version=info["version"] or "?"))


def _check_calendars(values):
    rows = []
    for cal in values["Calendars"]:
        if not cal["on"]:
            continue
        label = cal["name"] or (calendars.mask_url(cal["ref"]) if cal["kind"] == "ics" else cal["ref"]) or "?"
        name = tr("Kalender „{name}“", name=label)
        status = _cal["status"].get(cal["id"])
        if not status:
            rows.append(_row("cal-" + cal["id"], name, "warn", tr("Noch nicht geladen.")))
        elif status["state"] == "error":
            rows.append(_row("cal-" + cal["id"], name, "bad", status["error"],
                             tr("Steht ein Werbeblocker wie Pi-hole dazwischen? Dann {host} erlauben.",
                                host=calendars.mask_url(cal["ref"]).rstrip("/…")) if status.get("code") == "unreachable"
                             and cal["kind"] == "ics" else ""))
        else:
            rows.append(_row("cal-" + cal["id"], name, "ok",
                             tr("{n} Termine geladen ({ms} ms).", n=status["count"], ms=status.get("ms", 0))))
    return rows


def _check_school(values):
    if not values["ShowSchool"]:
        return None
    name = tr("Schulferien (OpenHolidays)")
    if values["HolidayCountry"] not in days_off.SCHOOL_COUNTRIES:
        return _row("school", name, "warn", tr("Für dieses Land gibt es keine Schulferien bei OpenHolidays."))
    ok, ms, error = school.probe()
    if not ok:
        return _row("school", name, "bad", tr("{host} ist nicht erreichbar: {exc}", host="openholidaysapi.org", exc=error),
                    tr("Steht ein Werbeblocker wie Pi-hole dazwischen? Dann {host} erlauben.", host="openholidaysapi.org"))
    start, end = cal_window(values)
    _public, rows = holidays_between(start, end, values)
    if not values["HolidayRegion"]:
        return _row("school", name, "warn", tr("Erreichbar ({ms} ms).", ms=ms) + " " +
                    tr("Wähle dein Bundesland oder deine Region, sonst fehlen die regionalen Ferien."))
    return _row("school", name, "ok", tr("Erreichbar ({ms} ms).", ms=ms) + " " +
                tr("{n} Ferienzeiten in den nächsten Wochen.", n=len(rows)))


def _check_takeover(values):
    if not takeover_wanted(values):
        return None
    name = tr("Blatt über die Playlist legen")
    if not takeover_supported():
        return _row("takeover", name, "bad", tr("Dieser Rahmen ist zu alt, um ein Plugin den Bildschirm übernehmen zu lassen."))
    note = takeover_permission_note()
    if note:
        return _row("takeover", name, "bad", note)
    find_scene()
    if _scene["note"]:
        return _row("takeover", name, "bad", _scene["note"])
    return _row("takeover", name, "ok", tr("Erlaubt, die Szene ist installiert."))


def check_services(force=False):
    with _services_lock:
        if _services["busy"] or (not force and now() - _services["at"] < SERVICES_EVERY and _services["rows"]):
            return _services["rows"]
        _services["busy"] = True
    try:
        values = settings()
        rows = []
        for fn in (_check_engine, lambda: _check_photos(values), lambda: _check_immich(values),
                   lambda: _check_ha(values), lambda: _check_calendars(values), lambda: _check_school(values),
                   lambda: _check_takeover(values)):
            try:
                row = fn()
            except Exception as exc:  # noqa: BLE001 - eine kaputte Prüfung soll die anderen nicht aufhalten
                row = _row("error", tr("Prüfung"), "bad", str(exc)[:200])
            if isinstance(row, list):
                rows.extend(row)
            elif row:
                rows.append(row)
        before = {r["key"]: r["state"] for r in _services["rows"]}
        for r in rows:
            if r["state"] == "bad" and before.get(r["key"]) != "bad":
                log(f"{r['name']}: {r['text']}", "warning")
        _services.update(rows=rows, at=now())
        return rows
    finally:
        _services["busy"] = False


def services_payload():
    rows = _services["rows"]
    return {"at": _services["at"] or None, "busy": _services["busy"], "rows": rows,
            "bad": sum(1 for r in rows if r["state"] == "bad"),
            "warn": sum(1 for r in rows if r["state"] == "warn")}


# --------------------------------------------------------------------------
# Die Fäden
# --------------------------------------------------------------------------

def work_loop():
    """Fotos einlesen, Fotos des Monats wählen, Personen aus Immich."""
    while not _stop_requested.is_set():
        values = settings()
        try:
            due = now() - _index["at"] >= values["RefreshHours"] * 3600
            if due or _index["signature"] != index_signature(values):
                if build_index("geplant" if due and _index["at"] else "Einstellungen"):
                    compute_picks("eingelesen")
            elif _index["at"] and _picks["signature"] != picks_signature(values):
                compute_picks("Monat oder Einstellungen")
            fetch_people()
        except Exception as exc:  # noqa: BLE001 - der Faden darf nicht sterben
            log(f"Fehler: {exc!r}", "warning")
        _wake.wait(30)
        _wake.clear()


_cal_wake = threading.Event()


def calendar_loop():
    """Termine und Schulferien holen."""
    _stop_requested.wait(2)
    while not _stop_requested.is_set():
        values = settings()
        try:
            if now() - _cal["at"] >= values["CalendarMinutes"] * 60 or _cal["signature"] != cal_signature(values):
                fetch_calendars()
            fetch_school()
        except Exception as exc:  # noqa: BLE001
            log(f"Termine: {exc!r}", "warning")
        _cal_wake.wait(60)
        _cal_wake.clear()


def screen_loop():
    """Blatt über die Playlist legen, Takeover-Playlist pflegen, Verbindungen prüfen."""
    _stop_requested.wait(3)
    while not _stop_requested.is_set():
        try:
            stop_leftover_takeover()
            maintain_playlists()
            decide_takeover()
            if now() - _services["at"] > SERVICES_EVERY and not _services["busy"]:
                _services["at"] = now()
                threading.Thread(target=check_services, args=(True,), name=f"{PLUGIN_ID}-services",
                                 daemon=True).start()
        except Exception as exc:  # noqa: BLE001
            log(f"Schleife: {exc!r}", "warning")
        _stop_requested.wait(2 if _takeover["handle"] is not None else 5)


def reload_now():
    _work_stop.set()
    _index["at"] = 0.0
    _cal["at"] = 0.0
    _people["at"] = 0.0

    def later():
        time.sleep(1)
        _work_stop.clear()
        _wake.set()
        _cal_wake.set()

    threading.Thread(target=later, daemon=True).start()
    return {"success": True, "message": tr("Fotos und Termine werden neu eingelesen.")}


# --------------------------------------------------------------------------
# Die eigene Playlist
# --------------------------------------------------------------------------

OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=(PLAYLIST_NAME,),
    name=lambda: PLAYLIST_NAME,
    description=lambda: tr("Das Kalenderblatt des Monats mit einem Foto von früher."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
    held=screen_held,
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()


# --------------------------------------------------------------------------
# Was die Szene bekommt
# --------------------------------------------------------------------------

SCENE_SETTINGS = ("Language", "Style", "PhotoSeconds", "UpcomingDays", "ShowTitles", "ShowHolidays",
                  "ShowSchool", "Animate", "HolidayCountry")


def month_payload(first, values, upcoming=True):
    """Alles für ein Blatt: Fotos, Feiertage, Ferien, Termine, Geburtstage."""
    day = today()
    last = first_of(first, 1) - datetime.timedelta(days=1)
    end = last
    if upcoming and first <= day <= last:
        end = max(last, day + datetime.timedelta(days=values["UpcomingDays"]))
    public, school_rows = holidays_between(first, end, values)
    events = events_between(first, end, values)
    if not values["ShowTitles"]:
        events = [dict(e, title="", location="") for e in events]
    month = (_picks["months"] or {}).get(month_key(first)) or {}
    return {
        "month": month_key(first),
        "first": first.isoformat(), "last": last.isoformat(), "until": end.isoformat(),
        "photos": month.get("photos") or [],
        "holidays": public,
        "school": school_rows,
        "events": [{k: e.get(k) for k in ("uid", "title", "start", "end", "allDay", "location", "color", "birthday")}
                   for e in events][:400],
        "birthdays": birthdays(first, end, values),
    }


def scene_payload(query):
    values = settings()
    day = today()
    wanted = (query.get("month") or [""])[0]
    first = first_of(day)
    if re.fullmatch(r"\d{4}-\d{2}", wanted or ""):
        try:
            first = datetime.date(int(wanted[:4]), int(wanted[5:7]), 1)
        except ValueError:
            pass
    with _takeover_lock:
        asking = _takeover["focus"] and now() - _leftover["askedAt"] < 30
        focus = _takeover["focus"] if _takeover["handle"] is not None or asking else ""
    payload = {
        "success": True,
        "ver": _picks["ver"],
        "today": day.isoformat(),
        "settings": dict({k: values[k] for k in SCENE_SETTINGS}, WeekStart=week_start(values)),
        "busy": _index["busy"] and not _index["at"],
        "indexed": len(_index["rows"]),
        "calendars": sum(1 for c in values["Calendars"] if c["on"]),
        "focus": focus,
    }
    payload.update(month_payload(first, values))
    return payload


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def public_calendars(values):
    out = []
    for cal in values["Calendars"]:
        row = dict(cal)
        if cal["kind"] == "ics":
            row["ref"] = calendars.mask_url(cal["ref"]) if cal["ref"] else ""
        row["status"] = _cal["status"].get(cal["id"]) or None
        out.append(row)
    return out


def state_payload():
    values = settings()
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    public["Calendars"] = public_calendars(values)
    status = {}
    for source in values["Sources"]:
        row = dict(_index["status"].get(source["id"]) or {})
        if _index["busy"] and not row:
            row = {"state": "wait"}
        row["kind"] = source["kind"]
        status[source["id"]] = row
    day = today()
    months = []
    for add in (0, 1):
        first = first_of(day, add)
        month = (_picks["months"] or {}).get(month_key(first)) or {}
        months.append({"month": month_key(first), "photos": month.get("photos") or [],
                       "count": month.get("count", 0), "years": month.get("years", 0)})
    start, end = day, day + datetime.timedelta(days=values["UpcomingDays"])
    public_days, school_rows = holidays_between(first_of(day), end, values)
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "status": status,
        "busy": _index["busy"],
        "progress": _index["progress"],
        "indexAt": _index["at"],
        "indexed": len(_index["rows"]),
        "dfCount": _index.get("dfCount"),
        "undated": _index["undated"],
        "months": months,
        "excluded": len(load_excluded()),
        "calAt": _cal["at"],
        "calBusy": _cal["busy"],
        "upcoming": {
            "events": len(events_between(start, end, values)),
            "birthdays": birthdays(start, end, values)[:8],
            "holidays": [h for h in public_days if h["date"] >= day.isoformat()][:6],
            "school": [s for s in school_rows if s["end"] >= day.isoformat()][:4],
        },
        "people": {"count": len(load_people()), "born": sum(1 for r in load_people() if r["birth"]),
                   "error": _people["error"]},
        "weekStart": week_start(values),
        "takeover": {"note": _takeover["note"], "pending": bool(_takeover["pending"]),
                     "on": _takeover["handle"] is not None, "playlistNote": _playlists["note"],
                     "shownMonth": load_state().get("shownMonth") or ""},
        "services": services_payload(),
        "heif": HEIF,
        "theme": {"id": theme_id()},
    }


def test_immich():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        info = immich.test()
    except sources.SourceError as exc:
        return {"success": True, "ok": False, "message": str(exc)}
    threading.Thread(target=fetch_people, args=(True,), daemon=True).start()
    return {"success": True, "ok": True,
            "message": tr("Verbunden als {user} (Immich {version}).", user=info["user"] or "?",
                          version=info["version"] or "?")}


def test_ha():
    values = settings()
    ha.configure(values["HaUrl"], values["HaToken"])
    try:
        info = ha.test()
        found = ha.calendars()
    except calendars.CalendarError as exc:
        return {"success": True, "ok": False, "message": cal_error_text(exc, {"kind": "ha"})}
    return {"success": True, "ok": True, "calendars": found,
            "message": tr("Verbunden mit {name} (Home Assistant {version}), {n} Kalender.",
                          name=info["name"] or "Home Assistant", version=info["version"] or "?", n=len(found))}


def list_ha_calendars():
    values = settings()
    ha.configure(values["HaUrl"], values["HaToken"])
    try:
        return {"success": True, "calendars": ha.calendars()}
    except calendars.CalendarError as exc:
        return {"success": False, "error": cal_error_text(exc, {"kind": "ha"})}


def list_albums():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, "albums": immich.albums()}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_immich(what):
    """Personen bzw. Tags für die Immich-Filter."""
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, what: getattr(immich_filters, what)(immich)}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_birth_people():
    """Personen für die Geburtstagsliste (mit Geburtsdatum aus Immich)."""
    if not immich_ready():
        return {"success": True, "people": []}
    fetch_people(force=not load_people())
    if _people["error"] and not load_people():
        return {"success": False, "error": _people["error"]}
    return {"success": True, "people": load_people()}


def list_playlists():
    try:
        rows = [p for p in dynaframe.playlists() if p["name"] not in (PLAYLIST_NAME, TAKEOVER_PLAYLIST_NAME)]
        return {"success": True, "playlists": sorted(rows, key=lambda p: str(p["name"]).lower())}
    except EngineError as exc:
        return {"success": False, "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc)}


def list_countries():
    return {"success": True, "countries": days_off.countries(settings()["Language"]),
            "school": sorted(days_off.SCHOOL_COUNTRIES)}


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}

# Einstellungen, nach denen die Fotos neu eingelesen werden müssen
SOURCE_SETTINGS = ("Albums", "Sources", "Folders", "ServerUrl", "ApiKey",
                   *immich_filters.SCHEMA, *dynaframe_filters.SCHEMA)
CAL_SETTINGS = ("Calendars", "HaUrl", "HaToken")


def settings_saved(changed):
    if "MakePlaylist" in changed:
        OWN.changed()
    if any(n in changed for n in ("MonthStart", "BirthdayMorning")):
        _playlists["at"] = 0.0
        _services["at"] = 0.0
    if any(n in changed for n in SOURCE_SETTINGS):
        with _picks_lock:
            _picks.update(ver=_picks["ver"] + 1, months={}, photos={}, signature="")
        reload_now()
    elif any(n in changed for n in ("PhotoCount", "PreferLandscape")):
        threading.Thread(target=compute_picks, args=("Einstellungen",), daemon=True).start()
    if any(n in changed for n in CAL_SETTINGS + ("Language",)):   # Fehlertexte in der neuen Sprache
        _cal["at"] = 0.0
        _cal_wake.set()
        _services["at"] = 0.0
    if any(n in changed for n in ("HolidayCountry", "HolidayRegion", "ShowSchool", "Language")):
        _cal_wake.set()
        _services["at"] = 0.0
    if any(n in changed for n in ("ServerUrl", "ApiKey", "BirthdaysImmich")):
        _people["at"] = 0.0
    with _picks_lock:
        _picks["ver"] += 1
    _wake.set()


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(query), cors=True)
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            if path in ("/api/photo", "/api/face"):
                found = photo_bytes(query) if path == "/api/photo" else face_bytes(query)
                if found is None:
                    self._json({"success": False}, 404, cors=True)
                else:
                    self._send(found, "image/jpeg", cache="private, max-age=86400", cors=True)
                return
            if path == "/api/albums":
                self._json(list_albums())
                return
            if path in ("/api/people", "/api/tags"):
                self._json(list_immich(path.rsplit("/", 1)[1]))
                return
            if path == "/api/birthpeople":
                self._json(list_birth_people())
                return
            if path == "/api/playlists":
                self._json(list_playlists())
                return
            if path == "/api/countries":
                self._json(list_countries())
                return
            if path == "/api/hacalendars":
                self._json(list_ha_calendars())
                return
            if path == "/api/services":
                check_services(force=True)
                self._json({"success": True, "services": services_payload()})
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                for name in SECRETS:
                    # Ein leeres Feld heißt: das alte behalten. Löschen geht mit "-".
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)
                    elif name in body and str(body[name]).strip() == "-":
                        body[name] = ""
                changed = save_settings(body)
                if changed:
                    settings_saved(changed)
                if "Language" in changed:
                    # Die Texte der Verbindungen in der neuen Sprache.
                    threading.Thread(target=check_services, kwargs={"force": True}, daemon=True).start()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/exclude":
                self._json(exclude(self._body()))
                return
            if path == "/api/show":
                self._json(show_now())
                return
            if path == "/api/refresh":
                self._json(reload_now())
                return
            if path == "/api/test":
                self._json(test_immich())
                return
            if path == "/api/hatest":
                self._json(test_ha())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def load_last():
    """Beim Start die Fotos vom letzten Mal zeigen, bis neu eingelesen ist."""
    stored = read_json(DATA_DIR / "last.json", {})
    if isinstance(stored, dict) and isinstance(stored.get("months"), dict):
        with _picks_lock:
            _picks.update(months=stored["months"], photos=stored.get("photos") or {}, ver=1)
        log(f"Fotos vom letzten Mal: {', '.join(stored['months'])}.")


def save_last():
    with _picks_lock:
        payload = {"months": _picks["months"], "photos": _picks["photos"]}
    write_json(DATA_DIR / "last.json", payload)


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}" + ("" if HEIF else " (ohne HEIC-Unterstützung, HEIC über die Engine)"))
    if calendars.icalendar is None:
        log("icalendar/recurring_ical_events fehlen: ICS-Kalender gehen nicht.", "warning")
    if days_off.holidays_lib is None:
        log("holidays fehlt: keine Feiertage.", "warning")

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: reload_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())
    plugin.on_action("show", lambda _context=None: show_now())

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    adopt_connections()
    load_last()
    load_events()
    load_people()
    _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
    try:
        os.nice(5)   # das Einlesen soll die Wiedergabe nicht stören
    except OSError:
        pass
    threading.Thread(target=work_loop, name=f"{PLUGIN_ID}-work", daemon=True).start()
    threading.Thread(target=calendar_loop, name=f"{PLUGIN_ID}-calendars", daemon=True).start()
    threading.Thread(target=screen_loop, name=f"{PLUGIN_ID}-screen", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _work_stop.set()
    _wake.set()
    _cal_wake.set()
    end_takeover("stopped")
    try:
        exif_save()
        save_last()
    except Exception:  # noqa: BLE001
        pass
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:  # noqa: BLE001
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:  # noqa: BLE001
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
