"""Growing Up - finding, picking and cutting out the faces.

Pure functions without the plugin around them, so they can be tested alone:

- candidate(): what one Immich asset says about the face of one person
  (bounding box, size, how good it is for a portrait);
- select(): one face per period (month, quarter, half year, year), the best
  one in each, at most max_frames, evenly thinned out;
- crop(): a square portrait around the face from Immich's preview image,
  plus where the face sits in it, so the scene can line the faces up.

Immich's face boxes are in the pixels of the image the faces were detected
on (imageWidth x imageHeight, the preview); they are scaled to whatever
image is cut.
"""

import io
from datetime import date

try:
    from PIL import Image
except ImportError:  # pragma: no cover - the plugin says so on its page
    Image = None

CROP_SIZE = 640
ZOOMS = {"tight": 1.75, "normal": 2.35, "wide": 3.2}
STEPS = {"month": 1, "quarter": 3, "half": 6, "year": 12}


def parse_date(text):
    text = str(text or "")[:10]
    try:
        return date.fromisoformat(text)
    except ValueError:
        return None


def months_between(born, day):
    """Full months from born to day (negative before born)."""
    months = (day.year - born.year) * 12 + (day.month - born.month)
    if day.day < born.day:
        months -= 1
    return months


def taken_date(asset):
    for key in ("localDateTime", "fileCreatedAt", "createdAt"):
        found = parse_date(asset.get(key))
        if found:
            return found
    exif = asset.get("exifInfo") or {}
    return parse_date(exif.get("dateTimeOriginal"))


def faces_of(asset, person_id):
    """The faces of one person in an asset (search with withPeople)."""
    found = []
    for person in asset.get("people") or []:
        if isinstance(person, dict) and person.get("id") == person_id:
            found.extend(f for f in person.get("faces") or [] if isinstance(f, dict))
    return found


def face_box(face):
    try:
        x1, y1 = float(face["boundingBoxX1"]), float(face["boundingBoxY1"])
        x2, y2 = float(face["boundingBoxX2"]), float(face["boundingBoxY2"])
        width, height = float(face.get("imageWidth") or 0), float(face.get("imageHeight") or 0)
    except (KeyError, TypeError, ValueError):
        return None
    if x2 <= x1 or y2 <= y1 or width <= 0 or height <= 0:
        return None
    return [round(x1, 1), round(y1, 1), round(x2, 1), round(y2, 1), int(width), int(height)]


def score(box, favorite=False, rating=0):
    """How good a face is for the portrait series: big, whole, frontal."""
    x1, y1, x2, y2, width, height = box
    fw, fh = x2 - x1, y2 - y1
    size = min(fw, fh)
    share = fw * fh / float(width * height)
    margin = min(x1, y1, width - x2, height - y2) / max(size, 1.0)
    ratio = fw / max(fh, 1.0)
    value = 0.55 * min(size / 320.0, 1.0) + 0.25 * min(share / 0.06, 1.0)
    if margin < 0.12:
        value -= 0.30          # cut off at the edge of the photo
    elif margin < 0.4:
        value -= 0.10
    if ratio < 0.62:
        value -= 0.20          # narrow box: mostly a profile
    if favorite:
        value += 0.15
    value += 0.03 * max(0, min(5, int(rating or 0)))
    return round(value, 4)


def candidate(asset, person_id, faces=None):
    """One compact row per asset, or None if it can't be used."""
    if not isinstance(asset, dict) or not asset.get("id"):
        return None
    if str(asset.get("type") or "IMAGE").upper() != "IMAGE" or asset.get("isTrashed"):
        return None
    day = taken_date(asset)
    if not day:
        return None
    boxes = [b for b in (face_box(f) for f in (faces if faces is not None else faces_of(asset, person_id))) if b]
    row = {"id": asset["id"], "d": day.isoformat(), "fav": bool(asset.get("isFavorite")),
           "r": int(((asset.get("exifInfo") or {}).get("rating")) or 0)}
    if not boxes:
        row["box"] = None
        return row
    box = max(boxes, key=lambda b: (b[2] - b[0]) * (b[3] - b[1]))
    row["box"] = box
    row["s"] = score(box, row["fav"], row["r"])
    return row


def face_size(row):
    box = row.get("box")
    return min(box[2] - box[0], box[3] - box[1]) if box else 0


def auto_step(age_months):
    if age_months < 12:
        return 1
    if age_months < 36:
        return 3
    if age_months < 72:
        return 6
    return 12


def bucket_key(day, born, interval, span_years):
    if born:
        age = months_between(born, day)
        if age < 0:
            return None
        step = auto_step(age) if interval == "auto" else STEPS[interval]
        return (step, age // step)
    if interval == "auto":
        interval = "quarter" if span_years <= 4 else "year"
    step = STEPS[interval]
    return (step, (day.year * 12 + day.month - 1) // step)


def thin_out(rows, limit):
    """At most `limit` rows, evenly over the time; first and last stay."""
    if limit <= 0 or len(rows) <= limit:
        return rows
    if limit == 1:
        return [rows[-1]]
    picked, last = [], -1
    for i in range(limit):
        index = round(i * (len(rows) - 1) / (limit - 1))
        if index != last:
            picked.append(rows[index])
            last = index
    return picked


def select(rows, born=None, interval="auto", max_frames=48, min_face=80, excluded=()):
    """The portrait series: per period the best face, oldest first.

    Faces smaller than min_face (in pixels of the detection image) only count
    when a period has nothing better."""
    excluded = set(excluded or ())
    usable = [r for r in rows if r.get("box") and r["id"] not in excluded]
    if not usable:
        return []
    days = [parse_date(r["d"]) for r in usable]
    span = (max(days) - min(days)).days / 365.25
    buckets = {}
    for row, day in zip(usable, days):
        key = bucket_key(day, born, interval, span)
        if key is None:
            continue
        big = face_size(row) >= min_face
        rank = (big, row["s"])
        best = buckets.get(key)
        if best is None or rank > best[0]:
            buckets[key] = (rank, row)
    chosen = [entry[1] for entry in buckets.values()]
    chosen.sort(key=lambda r: (r["d"], r["id"]))
    return thin_out(chosen, max_frames)


def age_of(born, day):
    if not born or not day:
        return None
    months = months_between(born, day)
    if months < 0:
        return None
    return {"months": months, "days": (day - born).days}


# --------------------------------------------------------------------------
# Cutting out
# --------------------------------------------------------------------------

class CropError(Exception):
    pass


def crop_box(box, image_size, zoom):
    """Square crop (left, top, side) in the pixels of image_size around the
    face, and the face centre and size inside it (0..1)."""
    x1, y1, x2, y2, width, height = box
    iw, ih = image_size
    sx, sy = iw / float(width), ih / float(height)
    if abs(sx - sy) / max(sx, sy) > 0.04:
        raise CropError("image and face box don't match (rotated?)")
    fx1, fy1, fx2, fy2 = x1 * sx, y1 * sy, x2 * sx, y2 * sy
    fw, fh = fx2 - fx1, fy2 - fy1
    face = max(fw, fh)
    cx = (fx1 + fx2) / 2.0
    cy = (fy1 + fy2) / 2.0 + 0.10 * fh    # a little room above, chin and neck below
    side = min(face * ZOOMS.get(zoom, ZOOMS["normal"]), iw, ih)
    left = min(max(cx - side / 2.0, 0.0), iw - side)
    top = min(max(cy - side / 2.0, 0.0), ih - side)
    face_cx = ((fx1 + fx2) / 2.0 - left) / side
    face_cy = ((fy1 + fy2) / 2.0 - top) / side
    return (left, top, side), [round(face_cx, 4), round(face_cy, 4), round(face / side, 4)]


def needs_bigger_image(box, image_size):
    """Is the face so small in this image that the original would be sharper?"""
    x1, y1, x2, y2, width, height = box
    scale = image_size[0] / float(width)
    return max(x2 - x1, y2 - y1) * scale * ZOOMS["normal"] < CROP_SIZE * 0.85


def open_image(data):
    if Image is None:
        raise CropError("Pillow is missing")
    try:
        image = Image.open(io.BytesIO(data))
        image.load()
    except Exception as exc:  # noqa: BLE001 - any broken image
        raise CropError(f"not an image: {exc}") from exc
    return image


def crop(data, box, zoom="normal", size=CROP_SIZE):
    """JPEG bytes of the square portrait and the face position in it."""
    # Immich previews are already upright and the face boxes belong to them,
    # so no EXIF turning here.
    image = open_image(data)
    (left, top, side), face = crop_box(box, image.size, zoom)
    region = image.convert("RGB").crop((int(round(left)), int(round(top)),
                                        int(round(left + side)), int(round(top + side))))
    if region.size[0] != size:
        region = region.resize((size, size), Image.LANCZOS)
    out = io.BytesIO()
    region.save(out, "JPEG", quality=86, optimize=True, progressive=True)
    return out.getvalue(), face


def size_of(data):
    return open_image(data).size


def age_years_float(age):
    return None if age is None else age["days"] / 365.25


def nearest(frames, target_months, tolerance):
    """The frame closest to an age (months), if within tolerance."""
    best = None
    for frame in frames:
        age = frame.get("age")
        if not age:
            continue
        diff = abs(age["months"] - target_months)
        if diff <= tolerance and (best is None or diff < best[0]):
            best = (diff, frame)
    return best[1] if best else None


def common_ages(people):
    """Ages (whole years, plus 6 and 18 months) at which every person with a
    birthday has a portrait - for the page 'at the same age'."""
    with_ages = [p for p in people if any(f.get("age") for f in p.get("frames") or [])]
    if len(with_ages) < 2:
        return []
    targets = [6, 18] + [12 * y for y in range(1, 100)]
    found = []
    for months in sorted(targets):
        tolerance = 2 if months < 24 else (4 if months < 72 else 7)
        picks = [nearest(p["frames"], months, tolerance) for p in with_ages]
        if sum(1 for x in picks if x) >= 2:
            found.append(months)
    return found
