# Calendar Page

Your frame becomes a wall calendar. Every month gets a beautiful page with photos from the same month in earlier years, the family's appointments, birthdays with a photo, public and school holidays. On the first of the month it shows up by itself.

## The page

- **Photos from back then:** for every earlier year the best photo of this month (stars, favourite, landscape) goes on the page, one after the other with the date, the place and "N years ago". Click a photo on the plugin page to leave it out; the next best one takes its place.
- **The month:** a calendar grid with today circled, weekends tinted, public holidays in red with their name and school holidays as a band under the days. The week starts on Monday or Sunday, as usual in your country, or as you choose.
- **Appointments:** coloured dots and times in the grid and a "Coming up" list. They come from calendar links (iCal/ICS: Google, Nextcloud, iCloud, Outlook and others, also `webcal://`) or from calendars in Home Assistant; up to eight, each with its own colour. Recurring appointments and cancellations are handled. Switch off "Show what the appointments are" if only dots and times should be on the frame.
- **Birthdays:** from the people in Immich who have a birth date (with their face from Immich) and from your own list (name, date, optionally the Immich person whose face is shown). The age is shown when the year is known.
- **Looks:** cream paper on a warm wall, white paper on a dark wall, or a dark page for the evening. Portrait screens get their own layout.

## Over the playlist

On the first of the month (from a time you choose until 10 pm, as soon as the screen is on) the new page is shown over the playlist; optionally also on birthdays, and optionally the screen is woken for it. This needs **Allow takeover** for Calendar Page on the frame's Plugins page. "Show the page now" on the plugin page tests it. The scene can also simply run in any playlist; "A playlist for it" creates one.

## Plugin page

Status, connections (DynaFrame, photos, Immich, Home Assistant, each calendar, school holidays, takeover), the page (look, timing, photos of this and next month), public and school holidays (country and state), family calendars, Home Assistant, birthdays, over the playlist, photo sources (DynaFrame library, playlists, Immich album or all of Immich) with filters, and "A playlist for it". German, English and Spanish.

Calendar links and tokens stay on the frame; the plugin page only shows the server name.

## Network

Public holidays are worked out on the frame itself (Python package `holidays`). School holidays come from the free [OpenHolidays API](https://www.openholidaysapi.org) (mainly Europe). If you use an ad blocker like Pi-hole, allow `openholidaysapi.org` and the servers of your calendar links (for Google Calendar `calendar.google.com`).
