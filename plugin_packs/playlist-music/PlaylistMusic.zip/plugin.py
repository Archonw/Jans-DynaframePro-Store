#!/usr/bin/env python3
"""Playlist-Musik: spielt Musik, solange bestimmte Playlists laufen.

Das Plugin fragt alle zwei Sekunden die Engine, welche Playlist läuft
(/slideshow/status), und sucht dazu die Musik, die auf der Plugin-Seite
eingestellt ist. Jede Playlist kann ihre eigene Musik haben, dazu eine
für „alle anderen“.

Wo die Musik herkommt: Internetradio, Jellyfin, ein Ordner auf dem Rahmen,
Spotify oder Music Assistant. Wo sie herauskommt: am Rahmen (Tonausgang,
den DynaFrame eingestellt hat), auf einem Spotify-Connect-Gerät oder einem
Lautsprecher von Music Assistant.

Regeln: Ende der Playlist = ausblenden (oder weiterlaufen lassen), nicht
starten, wenn dort schon Musik läuft, nur zu bestimmten Uhrzeiten, bei
Videos und wenn ein anderes Plugin den Bildschirm übernimmt pausieren oder
leiser werden. Schläft der Rahmen oder stoppt die Wiedergabe, endet die
Musik immer.
"""

import json
import os
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import audio  # noqa: E402
import services  # noqa: E402
import texts  # noqa: E402
from services import SourceError  # noqa: E402

plugin = create_plugin()

PLUGIN_ID = "PlaylistMusic"
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"
SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
SELECTION_FILE = DFR_DATA_DIR / "playback_selection_state.json"
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
POLL_SECONDS = 2.0
VIDEO_EXT = (".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi", ".mts", ".3gp")
SOURCES = ("radio", "url", "jellyfin", "folder", "spotify", "ma")


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def log(text, level="info"):
    plugin.log(text, level=level)


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        log(f"Konnte {path.name} nicht lesen: {exc}", "warning")
        return default


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, indent=1)
    os.chmod(temp, 0o600)   # enthält Schlüssel
    temp.replace(path)


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

SCHEMA = {
    "Language":       {"kind": "choice", "default": "de", "choices": texts.LANGUAGES},
    "Enabled":        {"kind": "bool", "default": True},
    "EndMode":        {"kind": "choice", "default": "fade", "choices": ("fade", "continue")},
    "FadeSeconds":    {"kind": "int", "default": 4, "min": 0, "max": 30},
    "SkipIfBusy":     {"kind": "bool", "default": True},
    "TimeFrom":       {"kind": "time", "default": ""},
    "TimeTo":         {"kind": "time", "default": ""},
    "OnVideo":        {"kind": "choice", "default": "pause", "choices": ("pause", "quieter", "ignore")},
    "OnTakeover":     {"kind": "choice", "default": "pause", "choices": ("pause", "quieter", "ignore")},
    "QuietPercent":   {"kind": "int", "default": 25, "min": 5, "max": 80},
    "JellyfinUrl":    {"kind": "url", "default": ""},
    "JellyfinKey":    {"kind": "secret", "default": ""},
    "JellyfinUser":   {"kind": "name", "default": ""},
    "MaUrl":          {"kind": "url", "default": ""},
    "MaToken":        {"kind": "secret", "default": ""},
    "SpotifyEnabled": {"kind": "bool", "default": False},
    "SpotifyName":    {"kind": "name", "default": "DynaFrame"},
    "SpotifyDiscoverable": {"kind": "bool", "default": True},
    "Rules":          {"kind": "rules", "default": {}},
}
SECRETS = [name for name, spec in SCHEMA.items() if spec["kind"] == "secret"]
_settings_lock = threading.Lock()


def coerce_rule(raw):
    raw = raw if isinstance(raw, dict) else {}
    source = str(raw.get("source") or "")
    return {
        "on": as_bool(raw.get("on"), False),
        "source": source if source in SOURCES else "",
        "ref": str(raw.get("ref") or "").strip()[:1000],
        "kind": re.sub(r"[^A-Za-z]", "", str(raw.get("kind") or ""))[:20],
        "label": str(raw.get("label") or "").strip()[:200],
        "stationId": re.sub(r"[^A-Za-z0-9-]", "", str(raw.get("stationId") or ""))[:64],
        "target": str(raw.get("target") or "frame").strip()[:200],
        "targetLabel": str(raw.get("targetLabel") or "").strip()[:120],
        "volume": max(5, min(100, as_int(raw.get("volume"), 60))),
        "shuffle": as_bool(raw.get("shuffle"), True),
        "playlistName": str(raw.get("playlistName") or "").strip()[:200],
    }


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "choice":
        value = str(raw if raw is not None else "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "url":
        return services.normalize_url(raw)
    if kind == "time":
        value = str(raw or "").strip()
        return value if re.match(r"^([01]\d|2[0-3]):[0-5]\d$", value) else ""
    if kind == "name":
        return str(raw if raw is not None else spec["default"]).strip()[:80]
    if kind == "rules":
        rules = raw if isinstance(raw, dict) else {}
        out = {}
        for key, rule in list(rules.items())[:300]:
            key = str(key)
            if key == "*" or re.match(r"^pl:[A-Za-z0-9_-]{1,64}$", key):
                out[key] = coerce_rule(rule)
        return out
    return re.sub(r"\s+", "", str(raw or ""))[:400]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def save_rule(key, rule):
    with _settings_lock:
        values = settings()
        rules = dict(values["Rules"])
        if rule is None:
            rules.pop(key, None)
        else:
            merged = dict(rules.get(key) or {})
            merged.update(rule if isinstance(rule, dict) else {})
            rules[key] = coerce_rule(merged)
        values["Rules"] = coerce("Rules", rules)
        write_json(SETTINGS_FILE, values)
        return values["Rules"].get(key)


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


def load_state():
    data = read_json(STATE_FILE, {})
    return data if isinstance(data, dict) else {}


def save_state(**changes):
    data = load_state()
    data.update(changes)
    write_json(STATE_FILE, data)


# --------------------------------------------------------------------------
# Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, timeout=10):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(5, timeout))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    if response.status_code == 204 or not (response.content or b"").strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def _rows(data):
    if isinstance(data, list):
        return [r for r in data if isinstance(r, dict)]
    if isinstance(data, dict):
        for key in ("items", "playlists", "results", "data"):
            if isinstance(data.get(key), list):
                return [r for r in data[key] if isinstance(r, dict)]
    return []


def _quick_mix(row):
    text = row.get("description")
    return isinstance(text, str) and "quick_mix" in text.replace(" ", "").lower()


_playlists = {"at": 0.0, "rows": [], "error": ""}


def playlists(force=False):
    if not force and now() - _playlists["at"] < 30:
        return _playlists["rows"]
    try:
        rows = _rows(engine_call("GET", "/playlists"))
        out = []
        for row in rows:
            name = str(row.get("name") or "?")
            if row.get("id") is None or _quick_mix(row) or name.endswith("(takeover)"):
                continue
            out.append({"id": str(row["id"]), "name": name})
        _playlists.update(at=now(), rows=sorted(out, key=lambda r: r["name"].lower()), error="")
    except EngineError as exc:
        _playlists.update(at=now(), error=str(exc))
    return _playlists["rows"]


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


# --------------------------------------------------------------------------
# Dienste
# --------------------------------------------------------------------------

spotify = services.Spotify(DATA_DIR / "spotify", log)


def jellyfin():
    values = settings()
    other = services.jellyfin_from_other_plugin(PLUGIN_DIR.parent)
    return services.Jellyfin(values["JellyfinUrl"] or other.get("url"), values["JellyfinKey"] or other.get("key"),
                             values["JellyfinUser"] or other.get("user"))


def music_assistant():
    values = settings()
    return services.MusicAssistant(values["MaUrl"], values["MaToken"])


# --------------------------------------------------------------------------
# Ausgänge: wo die Musik herauskommt
# --------------------------------------------------------------------------

def ramp(setter, start, end, seconds, stop=None):
    """Lautstärke in kleinen Schritten von start nach end (0-100)."""
    steps = max(1, int(seconds * 4))
    for i in range(1, steps + 1):
        if stop is not None and stop():
            return
        setter(round(start + (end - start) * i / steps))
        time.sleep(seconds / steps)


class FrameOutput:
    """Radio, Adresse, Jellyfin, Ordner: ffmpeg auf dem Rahmen."""

    def __init__(self, rule):
        self.rule = rule
        source, ref = rule["source"], rule["ref"]
        live = source in ("radio", "url")
        if source in ("radio", "url"):
            tracks = lambda: [(ref, rule["label"])]
        elif source == "jellyfin":
            tracks = lambda: jellyfin().tracks(ref, rule["kind"])
        elif source == "folder":
            tracks = lambda: services.folder_tracks(ref)
        else:
            raise SourceError("unbekannte Quelle")
        if source == "url" and ref.lower().split("?")[0].endswith((".m3u", ".m3u8", ".pls")) and not ref.lower().endswith(".m3u8"):
            tracks = lambda: [(_first_stream(ref), rule["label"])]
        self.player = audio.FramePlayer(tracks, live=live, shuffle=rule["shuffle"] and not live, log=log)
        self.player.volume = rule["volume"] / 100

    def busy(self):
        return False

    def start(self, fade):
        tools = audio.find_tools()
        if not tools["decoder"]:
            raise SourceError(tr("ffmpeg fehlt auf dem Rahmen."))
        if not tools["sink"]:
            raise SourceError(tr("Kein Tonausgang gefunden ({note}).", note=tools["note"] or "-"))
        if self.rule["source"] == "radio":
            threading.Thread(target=services.radio_click, args=(self.rule["stationId"],), daemon=True).start()
        self.player.start(fade_seconds=max(1.0, fade))

    def level(self, factor, fade):
        self.player.fade_to(factor, max(0.3, fade))

    def pause(self):
        self.player.pause()

    def resume(self, factor):
        self.player.target = factor
        self.player.resume(1.5)

    def stop(self, fade):
        self.player.stop(fade_seconds=fade)

    def alive(self):
        return self.player.running()

    def title(self):
        return self.player.title

    def problem(self):
        return self.player.problem


def _first_stream(url):
    """Erste Adresse aus einer .m3u/.pls-Datei."""
    try:
        text = requests.get(url, timeout=services.TIMEOUT, headers={"User-Agent": services.USER_AGENT}).text
    except requests.RequestException as exc:
        raise SourceError(str(exc)) from exc
    for line in text.splitlines():
        line = line.strip()
        if line.lower().startswith("file") and "=" in line:
            line = line.split("=", 1)[1].strip()
        if line.startswith(("http://", "https://")):
            return line
    return url


class VolumeOutput:
    """Gemeinsames für Ausgänge, deren Lautstärke man nur in Schritten stellt."""

    def __init__(self, rule):
        self.rule = rule
        self.factor = 1.0
        self.before = None
        self.paused = False
        self.started = 0.0

    def target_level(self, factor=None):
        return round(self.rule["volume"] * (self.factor if factor is None else factor))

    def level(self, factor, fade):
        old = self.target_level()
        self.factor = factor
        ramp(self.set_volume, old, self.target_level(), max(0.5, fade))

    def resume(self, factor):
        self.factor = factor
        self.set_volume(self.target_level())
        self.do_resume()
        self.paused = False

    def pause(self):
        self.do_pause()
        self.paused = True

    def stop(self, fade):
        if fade > 0 and not self.paused:
            ramp(self.set_volume, self.target_level(), 0, fade)
        try:
            self.do_stop()
        finally:
            if self.before is not None:
                time.sleep(0.5)
                self.set_volume(self.before)   # wie vorher, für das nächste Mal
            save_state(active=None)

    def alive(self):
        return True

    def title(self):
        return ""

    def problem(self):
        return ""


class SpotifyHere(VolumeOutput):
    def busy(self):
        return spotify.busy_here()

    def start(self, fade):
        if not spotify.ready():
            raise SourceError(tr("Spotify ist noch nicht bereit."))
        spotify.set_volume(0)
        spotify.play(self.rule["ref"], self.rule["shuffle"])
        ramp(spotify.set_volume, 0, self.target_level(), max(1.0, fade))

    def set_volume(self, level):
        spotify.set_volume(level)

    def do_pause(self):
        spotify.pause()

    def do_resume(self):
        spotify.resume()

    def do_stop(self):
        spotify.stop()


class SpotifyRemote(VolumeOutput):
    def __init__(self, rule, device_id):
        super().__init__(rule)
        self.device = device_id

    def busy(self):
        return spotify.remote_busy(self.device)

    def start(self, fade):
        if not spotify.ready():
            raise SourceError(tr("Spotify ist noch nicht bereit."))
        device = next((d for d in spotify.devices() if d["id"] == self.device), None)
        if device and isinstance(device.get("volume"), int):
            self.before = round(device["volume"] * 100 / 65535)
        save_state(active={"type": "spotify", "id": self.device, "before": self.before})
        self.set_volume(0)
        spotify.remote(self.device, "play", uri=self.rule["ref"])
        ramp(self.set_volume, 0, self.target_level(), max(1.0, fade))

    def set_volume(self, level):
        spotify.remote(self.device, "set_volume", volume=int(max(0, min(100, level)) * 65535 / 100))

    def do_pause(self):
        spotify.remote(self.device, "pause")

    def do_resume(self):
        spotify.remote(self.device, "resume")

    def do_stop(self):
        spotify.remote(self.device, "pause")


class MaOutput(VolumeOutput):
    def __init__(self, rule, player_id):
        super().__init__(rule)
        self.player = player_id
        self.ma = music_assistant()

    def busy(self):
        return self.ma.player_state(self.player) == "playing"

    def start(self, fade):
        self.before = self.ma.get_volume(self.player)
        save_state(active={"type": "ma", "id": self.player, "before": self.before})
        source, ref = self.rule["source"], self.rule["ref"]
        if source == "jellyfin":
            media = [url for url, _title in jellyfin().tracks(ref, self.rule["kind"])]
            if not media:
                raise SourceError("Jellyfin: keine Stücke")
        elif source == "folder":
            raise SourceError("Ordner gehen nur am Rahmen")
        else:
            media = ref
        self.set_volume(0)
        self.ma.play(self.player, media, shuffle=self.rule["shuffle"] and source not in ("radio", "url"))
        ramp(self.set_volume, 0, self.target_level(), max(1.0, fade))

    def set_volume(self, level):
        self.ma.volume(self.player, level)

    def do_pause(self):
        self.ma.pause(self.player)

    def do_resume(self):
        self.ma.resume(self.player)

    def do_stop(self):
        self.ma.stop(self.player)


def make_output(rule):
    target = rule["target"] or "frame"
    if rule["source"] == "spotify":
        if target.startswith("spotify:"):
            return SpotifyRemote(rule, target[8:])
        return SpotifyHere(rule)
    if target.startswith("ma:"):
        return MaOutput(rule, target[3:])
    if rule["source"] == "ma":
        raise SourceError("Music Assistant braucht einen Lautsprecher von Music Assistant")
    return FrameOutput(rule)


def target_name(rule):
    target = rule.get("target") or "frame"
    if target == "frame":
        return tr("Der Rahmen")
    return rule.get("targetLabel") or target.split(":", 1)[-1]


def cleanup_leftover():
    """Nach einem Neustart mitten in der Musik: externen Lautsprecher anhalten."""
    active = load_state().get("active")
    if not isinstance(active, dict):
        return
    try:
        if active.get("type") == "ma":
            ma = music_assistant()
            ma.stop(active["id"])
            if active.get("before") is not None:
                ma.volume(active["id"], active["before"])
        elif active.get("type") == "spotify" and spotify.ready():
            spotify.remote(active["id"], "pause")
            if active.get("before") is not None:
                spotify.remote(active["id"], "set_volume", volume=int(active["before"] * 65535 / 100))
        else:
            return
        log("Musik vom letzten Lauf angehalten.")
    except (SourceError, KeyError) as exc:
        log(f"Konnte die Musik vom letzten Lauf nicht anhalten: {exc}", "warning")
    save_state(active=None)


# --------------------------------------------------------------------------
# Was soll gerade laufen?
# --------------------------------------------------------------------------

_now = {"key": None, "rule": None, "output": None, "playlist": "", "hold": "", "state": "idle",
        "note": "", "since": 0.0, "skipped": None, "continued": False}
_wish = {"key": None, "count": 0}
_manual = {"key": None}
_wake = threading.Event()
_stop_requested = threading.Event()
_lock = threading.RLock()


def read_selection():
    try:
        data = json.loads(SELECTION_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def in_time_window(values):
    start, end = values["TimeFrom"], values["TimeTo"]
    if not start or not end or start == end:
        return True
    clock = time.strftime("%H:%M")
    if start < end:
        return start <= clock < end
    return clock >= start or clock < end   # über Mitternacht


def rule_ready(rule):
    return bool(rule and rule["on"] and rule["source"] and rule["ref"])


def wanted(status, values):
    """(Schlüssel der Regel oder None, Name der Playlist, Hinweis)."""
    rules = values["Rules"]
    pid = status.get("activePlaylistId")
    name = str(status.get("playlistName") or "")
    key = f"pl:{pid}" if pid is not None else None
    if key and rule_ready(rules.get(key)):
        return key, name, ""
    # Playlist neu angelegt (andere ID), aber gleicher Name
    for other, rule in rules.items():
        if other != "*" and rule_ready(rule) and name and rule["playlistName"] == name:
            return other, name, ""
    # Quick Mix: die gespeicherten Playlists darin
    selection = read_selection()
    mix = selection.get("QuickMixState") if selection.get("Mode") == "quick_mix" else None
    if isinstance(mix, dict):
        for ident in mix.get("EnabledSavedPlaylistIds") or []:
            other = f"pl:{ident}"
            if rule_ready(rules.get(other)):
                return other, name, ""
    if rule_ready(rules.get("*")):
        return "*", name, ""
    return None, name, ""


def is_video(item):
    if not isinstance(item, dict):
        return False
    kind = str(item.get("mediaType") or item.get("type") or item.get("contentType") or "").lower()
    if "video" in kind:
        return True
    path = str(item.get("filePath") or item.get("path") or item.get("fileName") or "").lower()
    return path.endswith(VIDEO_EXT)


def someone_has_screen():
    try:
        data = engine_call("GET", "/display-sessions/status", timeout=5) or {}
    except EngineError:
        return False
    return bool(data.get("active"))


def stop_current(fade, note=""):
    with _lock:
        output = _now["output"]
        _now.update(output=None, key=None, rule=None, hold="", state="idle", continued=False, note=note, playlist="")
    if output is not None:
        try:
            output.stop(fade)
        except Exception as exc:   # Lautsprecher weg: trotzdem als gestoppt gelten
            log(f"Beim Anhalten: {exc}", "warning")
        log("Musik angehalten.")


def start_rule(key, rule, playlist_name, values, manual=False):
    try:
        output = make_output(rule)
        if values["SkipIfBusy"] and not manual and output.busy():
            _now.update(skipped=key, note=tr("Nicht gestartet: auf {target} läuft schon Musik.", target=target_name(rule)))
            log(_now["note"])
            return
        output.start(values["FadeSeconds"])
    except (SourceError, OSError) as exc:
        _now.update(skipped=key, note=tr("Konnte nicht abspielen: {problem}", problem=exc))
        log(_now["note"], "warning")
        return
    with _lock:
        _now.update(key=key, rule=rule, output=output, playlist=playlist_name, hold="", state="playing",
                    since=now(), skipped=None, continued=False, note="")
    log(f"Musik an: {rule['label'] or rule['ref']} auf {target_name(rule)} für {playlist_name or key}.")


def apply_hold(hold, values):
    """'' normal, 'pause' oder 'quieter' wegen Video/Takeover."""
    output = _now["output"]
    if output is None or hold == _now["hold"]:
        return
    try:
        if hold == "pause":
            output.pause()
        elif hold == "quieter":
            if _now["hold"] == "pause":
                output.resume(values["QuietPercent"] / 100)
            else:
                output.level(values["QuietPercent"] / 100, 1.0)
        else:
            if _now["hold"] == "pause":
                output.resume(1.0)
            else:
                output.level(1.0, 1.5)
    except (SourceError, OSError) as exc:
        log(f"Lautsprecher reagiert nicht: {exc}", "warning")
    _now["hold"] = hold


def tick():
    values = settings()
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", timeout=5) or {}
    except EngineError as exc:
        _now["note"] = tr("DynaFrame antwortet nicht: {exc}", exc=exc)
        return
    asleep = bool(status.get("isSleeping")) or str(status.get("sleepState") or "Awake") != "Awake"
    running = bool(status.get("isRunning")) and not asleep
    takeover = someone_has_screen() if running else False
    video = is_video(status.get("currentItem"))

    # Was wäre jetzt dran?
    if _manual["key"]:
        key, name = _manual["key"], status.get("playlistName") or ""
    elif not values["Enabled"] or not running:
        key, name = None, ""
    elif takeover and _now["key"]:
        key, name = _now["key"], _now["playlist"]   # Takeover-Playlist zählt nicht als Wechsel
    else:
        key, name, _hint = wanted(status, values)
        if key and not in_time_window(values):
            if _now["key"] != key:
                _now["note"] = tr("Nicht gestartet: außerhalb der Uhrzeit {start}–{end}.",
                                  start=values["TimeFrom"], end=values["TimeTo"])
            key = None

    # Erst nach zwei gleichen Antworten wechseln (Übergänge, kurze Aussetzer)
    if key != _wish["key"]:
        _wish.update(key=key, count=1)
    else:
        _wish["count"] += 1
    settled = _wish["count"] >= 2 or _manual["key"]

    if key != _skipped_key():
        _now["skipped"] = None

    current = _now["key"]
    if settled and key != current:
        keep = (current and key is None and values["EndMode"] == "continue" and running
                and values["Enabled"] and not _manual["key"])
        if keep:
            if not _now["continued"]:
                _now["continued"] = True
                log("Playlist ohne Musik, die Musik läuft weiter.")
        else:
            if current:
                stop_current(values["FadeSeconds"])
            if key and key != _now["skipped"]:
                rule = (values["Rules"].get(key) if key != "manual" else None)
                if rule_ready(rule):
                    start_rule(key, rule, name, values, manual=bool(_manual["key"]))
    elif current and key == current:
        _now["continued"] = False

    # Dazwischen: Video, anderes Plugin
    if _now["output"] is not None:
        hold, why = "", ""
        if takeover and values["OnTakeover"] != "ignore":
            hold, why = values["OnTakeover"], "takeover"
        elif video and values["OnVideo"] != "ignore":
            hold, why = values["OnVideo"], "video"
        apply_hold(hold, values)
        _now["holdWhy"] = why
        if _now["output"] is not None and not _now["output"].alive():
            problem = _now["output"].problem()
            stop_current(0, tr("Konnte nicht abspielen: {problem}", problem=problem) if problem else "")


def _skipped_key():
    return _now["skipped"]


def control_loop():
    cleanup_leftover()
    last_spotify = 0.0
    while not _stop_requested.is_set():
        try:
            values = settings()
            spotify.configure(values["SpotifyEnabled"], values["SpotifyName"] or "DynaFrame",
                              values["SpotifyDiscoverable"])
            if now() - last_spotify > 5:
                last_spotify = now()
                spotify.tick()
            tick()
        except Exception as exc:  # pragma: no cover - darf die Schleife nie beenden
            log(f"Fehler in der Steuerung: {exc}", "warning")
        _wake.wait(POLL_SECONDS)
        _wake.clear()
    stop_current(0)
    spotify.stop_process()


# --------------------------------------------------------------------------
# Plugin-Seite
# --------------------------------------------------------------------------

def state_payload():
    values = settings()
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    rule = _now["rule"]
    output = _now["output"]
    if not values["Enabled"] and not _manual["key"]:
        text, tone = tr("Musik ist ausgeschaltet."), ""
    elif rule:
        music = rule["label"] or rule["ref"]
        if _manual["key"]:
            text = tr("Probehören: {music}", music=music)
        elif _now["hold"] in ("pause", "quieter"):
            why = tr("ein anderes Plugin zeigt etwas") if _now.get("holdWhy") == "takeover" else tr("ein Video läuft")
            text = tr("Pausiert ({why})." if _now["hold"] == "pause" else "Leiser ({why}).", why=why)
        else:
            text = tr("Spielt {music} für {playlist}.", music=music, playlist=_now["playlist"] or tr("Alle anderen Playlists"))
        if _now["continued"]:
            text += " " + tr("Läuft weiter, obwohl die Playlist gewechselt hat.")
        tone = "ok"
    else:
        text, tone = _now["note"] or tr("Bereit, es läuft gerade keine Playlist mit Musik."), "bad" if _now["note"] else ""
    jf_other = services.jellyfin_from_other_plugin(PLUGIN_DIR.parent)
    tools = audio.find_tools()
    return {
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "now": {"text": text, "tone": tone, "key": _now["key"], "title": output.title() if output else "",
                "target": target_name(rule) if rule else "", "playlist": _now["playlist"],
                "hold": _now["hold"], "manual": _manual["key"]},
        "tools": {"decoder": bool(tools["decoder"]), "sink": tools["sinkName"], "note": tools["note"]},
        "spotify": {"state": spotify.state, "note": spotify.note, "installed": spotify.installed()},
        "playlists": playlists(),
        "playlistError": _playlists["error"],
        "jellyfinOther": {"url": jf_other.get("url") or "", "user": jf_other.get("user") or "",
                          "keySet": bool(jf_other.get("key"))},
        "theme": {"id": theme_id()},
    }


def targets(source):
    out = []
    errors = []
    if source == "spotify":
        if spotify.ready():
            out.append({"id": "frame", "label": tr("Der Rahmen")})
            out += [{"id": "spotify:" + d["id"], "label": d["label"] + (f" ({d['type']})" if d["type"] else "")}
                    for d in spotify.devices()]
        else:
            errors.append(tr("Spotify ist noch nicht bereit."))
        return out, errors
    if source not in ("ma",):
        out.append({"id": "frame", "label": tr("Der Rahmen")})
    if source != "folder":
        ma = music_assistant()
        if ma.ok():
            try:
                out += [{"id": "ma:" + p["id"], "label": "Music Assistant: " + p["label"]} for p in ma.players()]
            except SourceError as exc:
                errors.append(str(exc))
    return out, errors


def search(source, query):
    query = str(query or "").strip()[:200]
    if source == "radio":
        return services.radio_search(query)
    if source == "jellyfin":
        return jellyfin().search(query)
    if source == "folder":
        return services.folder_browse(query)
    if source == "spotify":
        uri = services.spotify_uri(query)
        if uri:
            return [{"ref": uri, "label": uri, "sub": "", "kind": uri.split(":")[1]}]
        if not spotify.ready():
            raise SourceError(tr("Spotify ist noch nicht bereit."))
        rows = spotify.library()
        if query:
            rows = [r for r in rows if query.lower() in str(r["label"]).lower()]
        return rows
    if source == "ma":
        return music_assistant().search(query)
    return []


def test_service(what):
    try:
        if what == "jellyfin":
            server, user = jellyfin().test()
            return {"ok": True, "message": tr("Verbunden mit {server}, Benutzer {user}.", server=server, user=user)}
        if what == "ma":
            version_text, count = music_assistant().test()
            return {"ok": True, "message": tr("Verbunden mit Music Assistant {version}, {count} Lautsprecher.",
                                              version=version_text, count=count)}
        if what == "folder":
            return {"ok": True}
    except SourceError as exc:
        return {"ok": False, "message": str(exc)}
    return {"ok": False, "message": "?"}


def preview(key):
    """Regel sofort abspielen, unabhängig von der Playlist (zum Ausprobieren)."""
    values = settings()
    rule = values["Rules"].get(key)
    if not rule or not rule["source"] or not rule["ref"]:
        return {"success": False, "error": tr("Wähle zuerst, was gespielt werden soll.")}
    rule = dict(rule, on=True)
    threading.Thread(target=_preview_run, args=(key, rule, values), daemon=True).start()
    return {"success": True}


def _preview_run(key, rule, values):
    with _lock:
        _manual["key"] = "manual"
        if _now["output"] is not None:
            stop_current(1.0)
        start_rule("manual", rule, rule["label"], values, manual=True)


def stop_now():
    _manual["key"] = None
    _wish.update(key=None, count=0)
    threading.Thread(target=lambda: stop_current(settings()["FadeSeconds"], tr("Gestoppt.")), daemon=True).start()
    # Was gerade läuft, bleibt aus, bis die Playlist wechselt
    _now["skipped"] = _now["key"]
    return {"success": True}


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status)

    def _body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        raw = self.rfile.read(min(length, 1024 * 1024)) if length > 0 else b""
        try:
            body = json.loads(raw.decode("utf-8")) if raw else {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        arg = lambda name: (query.get(name) or [""])[0]
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/targets":
                rows, errors = targets(arg("source"))
                self._json({"success": True, "targets": rows, "errors": errors})
                return
            if path == "/api/search":
                try:
                    rows = search(arg("source"), arg("q"))
                    self._json({"success": True, "items": rows})
                except SourceError as exc:
                    self._json({"success": False, "error": str(exc)})
                return
            if path == "/api/foldercount":
                count = services.folder_count(arg("path"))
                self._json({"success": True, "count": count,
                            "message": tr("Dieser Ordner enthält {count} Musikdateien.", count=count) if count > 0
                            else tr("In diesem Ordner ist keine Musik.")})
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        body = self._body()
        try:
            if path == "/api/settings":
                for name in SECRETS:
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)
                    elif name in body and str(body[name]).strip() == "-":
                        body[name] = ""
                body.pop("Rules", None)
                changed = save_settings(body)
                _wake.set()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/rule":
                key = str(body.get("key") or "")
                if key != "*" and not re.match(r"^pl:[A-Za-z0-9_-]{1,64}$", key):
                    self._json({"success": False, "error": "key"}, 400)
                    return
                rule = save_rule(key, None if body.get("delete") else body.get("rule"))
                _wish.update(key=None, count=0)
                if _now["key"] == key and rule and (rule["ref"] != (_now["rule"] or {}).get("ref") or
                                                    rule["target"] != (_now["rule"] or {}).get("target") or not rule["on"]):
                    threading.Thread(target=stop_current, args=(1.0,), daemon=True).start()
                elif _now["key"] == key and rule and _now["output"] is not None and rule["volume"] != _now["rule"]["volume"]:
                    _now["rule"] = rule
                    _now["output"].rule = rule
                    if isinstance(_now["output"], FrameOutput):
                        _now["output"].player.volume = rule["volume"] / 100
                    else:
                        threading.Thread(target=_now["output"].level, args=(_now["output"].factor, 0.5), daemon=True).start()
                _now["skipped"] = None
                _wake.set()
                self._json({"success": True, "rule": rule})
                return
            if path == "/api/test":
                self._json(dict(test_service(str(body.get("what") or "")), success=True))
                return
            if path == "/api/preview":
                self._json(preview(str(body.get("key") or "")))
                return
            if path == "/api/stop":
                self._json(stop_now())
                return
            if path == "/api/spotify/forget":
                spotify.forget()
                self._json({"success": True, "message": tr("Spotify ist abgemeldet. Gleich erscheint ein neuer Code.")})
                return
            if path == "/api/tools":
                tools = audio.find_tools(force=True)
                self._json({"success": True, "sink": tools["sinkName"], "decoder": bool(tools["decoder"]), "note": tools["note"]})
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}")
    plugin.on_action("stop", lambda _context=None: stop_now())
    start_studio()
    plugin.connect_sse()
    plugin.ready()
    spotify.kill_leftover()
    threading.Thread(target=lambda: log(f"Tonausgang: {audio.find_tools()['sinkName'] or 'keiner'}"),
                     daemon=True).start()
    worker = threading.Thread(target=control_loop, name=f"{PLUGIN_ID}-control", daemon=True)
    worker.start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown(worker)


def shutdown(worker=None):
    _stop_requested.set()
    _wake.set()
    if worker is not None:
        worker.join(timeout=8)
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    log(f"{PLUGIN_ID} gestoppt.")


def _at_exit():
    """Beim Beenden durch den Rahmen: nichts weiterlaufen lassen."""
    output = _now.get("output")
    if isinstance(output, FrameOutput):
        output.player._stop.set()
        output.player._kill()
    spotify.stop_process()


if __name__ == "__main__":
    import atexit
    atexit.register(_at_exit)
    main()
