#!/usr/bin/env python3
"""Secret Santa - der Plugin-Teil des Pakets "secret-santa".

Wichteln mit dem Rahmen: Alle melden sich am Handy an (QR-Code auf dem
Fernseher, keine App), schreiben ihre Wunschliste und wählen eine PIN. Der
Rahmen lost geheim aus; jeder sieht nur auf seinem eigenen Handy, wen er
beschenkt, samt Wunschliste, Budget und Countdown bis zur Bescherung. Über
das Handy kann man seinem Wichtelkind anonym eine Frage stellen. Am Ende deckt
der Fernseher die Paare mit Trommelwirbel auf.

Geheim heißt hier: Weder der Fernseher noch die Plugin-Seite zeigen vor der
Auflösung, wer wen hat. Die Paare gehen nur an das Handy der Person selbst
(mit ihrem Schlüssel oder Name + PIN) und an die laufende Auflösung, dort
auch nur Schritt für Schritt.

Dieses Plugin
- liefert die Handy-Seite im WLAN (Port 8155, PortKeeper),
- lost aus (eine große Kette, keine Paare im selben Haushalt, nicht dieselbe
  Person wie letztes Jahr),
- sagt der Szene, was sie zeigen soll, und spielt den Ton der Auflösung,
- holt die Szene auf Wunsch über das laufende Programm (Takeover),
- zeigt die Plugin-Seite.
"""

import datetime
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import own_playlist  # noqa: E402
import plugin_ports  # noqa: E402
import santa as santalib  # noqa: E402
import texts  # noqa: E402

try:
    import playback_guard  # noqa: E402
except Exception:  # noqa: BLE001 - nur ein Behelf, darf fehlen
    playback_guard = None

plugin = create_plugin()

PLUGIN_ID = "SecretSanta"
SCENE_ID = "secret-santa"            # id in scene.dynamic - nie ändern
DISPLAY_NAME = "Secret Santa"
PLAYLIST_NAMES = {"de": "Secret Santa", "en": "Secret Santa", "es": "Secret Santa"}
TAKEOVER_PLAYLIST_NAME = "Secret Santa (takeover)"
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"       # Einstellungen und die Runde; bleibt bei Updates
SOUNDS = PLUGIN_DIR / "sounds"

CONNECT_TIMEOUT = 10
SCENE_GONE = 10                      # so lange ohne Frage der Szene: sie ist nicht zu sehen
INTRO_SECONDS = 8                    # Auflösung: Vorspann
DRUM_SECONDS = 5.3                   # so lange wirbelt die Trommel, dann kommt der Name
LEAD_SECONDS = 1.5                   # so viel früher bekommt die Szene den nächsten Schritt
DRAWN_SECONDS = 75                   # so lange zeigt der Fernseher „Die Lose sind gezogen“
GIVING_AFTER = 10 * 60               # so lange bleibt „Frohe Bescherung“ nach der Zeit stehen
LOGIN_TRIES = 6                      # Fehlversuche je Name in 10 Minuten


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


read_json = santalib.read_json
write_json = santalib.write_json


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

def default_gift_date():
    today = datetime.date.today()
    christmas = datetime.date(today.year, 12, 24)
    if today > christmas + datetime.timedelta(days=7):
        christmas = datetime.date(today.year + 1, 12, 24)
    return christmas.isoformat()


SCHEMA = {
    "Language":       {"kind": "choice", "default": "en", "choices": texts.LANGUAGES},
    "Title":          {"kind": "text", "default": "", "max": 60},
    "Budget":         {"kind": "int", "default": 25, "min": 0, "max": 10000},
    "Currency":       {"kind": "choice", "default": "€", "choices": ("€", "CHF", "$", "£")},
    "GiftDate":       {"kind": "date", "default": None},
    "GiftTime":       {"kind": "clock", "default": "18:00"},
    "DrawDate":       {"kind": "date", "default": "", "empty": True},
    "DrawTime":       {"kind": "clock", "default": "20:00"},
    "SignupOpen":     {"kind": "bool", "default": True},
    "Houses":         {"kind": "bool", "default": True},
    "SingleChain":    {"kind": "bool", "default": True},
    "AvoidRepeat":    {"kind": "bool", "default": True},
    "Messages":       {"kind": "bool", "default": True},
    "DrawOnTv":       {"kind": "bool", "default": True},
    "CountdownOnTv":  {"kind": "int", "default": 0, "min": 0, "max": 240},
    "RevealAuto":     {"kind": "bool", "default": False},
    "RevealStep":     {"kind": "int", "default": 11, "min": 8, "max": 30},
    "DoneMinutes":    {"kind": "int", "default": 10, "min": 1, "max": 120},
    "Sound":          {"kind": "bool", "default": True},
    "Volume":         {"kind": "int", "default": 0, "min": 0, "max": 100},
    "Theme":          {"kind": "choice", "default": "cozy", "choices": ("cozy", "night")},
    "ShowQr":         {"kind": "bool", "default": True},
    "Snow":           {"kind": "bool", "default": True},
    "WakeScreen":     {"kind": "bool", "default": True},
    "PlaylistSeconds": {"kind": "int", "default": 600, "min": 60, "max": 86400},
    "MakePlaylist":   {"kind": "bool", "default": False},
}
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()
_settings_cache = {"at": 0.0, "values": None}


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    default = spec["default"]
    if kind == "date" and default is None:
        default = default_gift_date()
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, default)))
    if kind == "choice":
        value = str(raw or "").strip()
        return value if value in spec["choices"] else default
    if kind == "clock":
        match = re.match(r"^\s*(\d{1,2})[:.](\d{2})\s*$", str(raw or ""))
        if not match or int(match.group(1)) > 23 or int(match.group(2)) > 59:
            return default
        return f"{int(match.group(1)):02d}:{match.group(2)}"
    if kind == "date":
        value = str(raw or "").strip()
        if not value and spec.get("empty"):
            return ""
        try:
            return datetime.date.fromisoformat(value).isoformat()
        except ValueError:
            return default
    return santalib.clean_text(raw, spec.get("max", 80))


def settings():
    cached = _settings_cache["values"]
    if cached is not None and now() - _settings_cache["at"] < 1.0:
        return dict(cached)
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    values = {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}
    _settings_cache.update(at=now(), values=values)
    return dict(values)


def save_settings(changes):
    with _settings_lock:
        _settings_cache["values"] = None
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        _settings_cache["values"] = None
    if "Language" in changed:
        threading.Thread(target=check_services, args=(True,), name=f"{PLUGIN_ID}-services",
                         daemon=True).start()
    return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


def round_title(values=None):
    values = values or settings()
    year = (values["GiftDate"] or default_gift_date())[:4]
    return values["Title"] or texts.t(values["Language"], "Wichteln {year}", year=year)


def at_epoch(day, clock):
    if not day:
        return 0
    try:
        date = datetime.date.fromisoformat(day)
        hour, minute = (int(x) for x in clock.split(":"))
        return datetime.datetime.combine(date, datetime.time(hour, minute)).timestamp()
    except (ValueError, TypeError):
        return 0


def gift_at(values=None):
    values = values or settings()
    return at_epoch(values["GiftDate"], values["GiftTime"])


def draw_at(values=None):
    values = values or settings()
    return at_epoch(values["DrawDate"], values["DrawTime"])


def budget_text(values=None):
    values = values or settings()
    if not values["Budget"]:
        return ""
    amount = f"{values['Budget']}"
    cur = values["Currency"]
    if cur in ("$", "£"):
        return f"{cur}{amount}"
    return f"{amount} {cur}"


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=60):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


# --------------------------------------------------------------------------
# Die Runde und was die Szene zeigt
# --------------------------------------------------------------------------

game = None
_scene = {"seen": 0.0}
_focus = {"kind": "", "at": 0.0}
_draw_note = {"text": "", "tone": ""}


def scene_visible(t=None):
    return (t or now()) - _scene["seen"] < SCENE_GONE


def reveal_end(rev):
    return rev["started"] + rev["intro"] + rev["count"] * rev["step"]


def mode(t=None):
    t = t or now()
    rev = game.reveal()
    if rev:
        return "reveal" if t < reveal_end(rev) else "done"
    if game.drawn:
        gift = gift_at()
        if gift and t >= gift:
            return "giving"
        return "drawn"
    return "signup"


def reveal_payload(t):
    """Nur die Schritte, die schon dran sind; der Name des Wichtels erst kurz vor dem Trommelschlag."""
    rev = game.reveal()
    if not rev:
        return None
    pairs = game.reveal_pairs()
    shown = []
    for index, pair in enumerate(pairs):
        start = rev["started"] + rev["intro"] + index * rev["step"]
        if t + LEAD_SECONDS < start:
            break
        row = {"receiver": pair["receiver"], "chainEnd": pair["chainEnd"], "giver": None}
        if t + LEAD_SECONDS >= start + rev["drum"]:
            row["giver"] = pair["giver"]
        shown.append(row)
    return {"id": rev["id"], "started": rev["started"], "intro": rev["intro"], "step": rev["step"],
            "drum": rev["drum"], "count": len(pairs), "end": reveal_end(rev), "shown": shown}


def scene_state():
    t = now()
    values = settings()
    current = mode(t)
    people = game.people()
    out = {
        "success": True,
        "now": t,
        "lang": values["Language"],
        "mode": current,
        "title": round_title(values),
        "theme": values["Theme"],
        "snow": values["Snow"],
        "showQr": values["ShowQr"],
        "budget": budget_text(values),
        "gift": gift_at(values),
        "drawAt": 0 if game.drawn else draw_at(values),
        "url": phone_url(),
        "code": game.code,
        "signupOpen": values["SignupOpen"],
        "names": [p["name"] for p in sorted(people, key=lambda p: p["joined"])],
        "stats": game.stats(),
        "seq": game.seq,
        "takeover": _takeover["handle"] is not None,
        "focus": _focus["kind"] if _focus["kind"] and now() - _focus["at"] < DRAWN_SECONDS else "",
    }
    if current in ("reveal", "done"):
        out["reveal"] = reveal_payload(t)
    return out


# --------------------------------------------------------------------------
# Auslosen, Auflösung, neue Runde
# --------------------------------------------------------------------------

DRAW_NOTES = {
    "repeat": "Nicht alle konnten jemand anderen als letztes Jahr bekommen.",
    "houses": "Mit den Haushalten ging es nicht auf; einige beschenken jemanden aus dem eigenen Haushalt.",
    "chain": "Eine einzige große Kette ging nicht auf, darum gibt es mehrere kleine Kreise.",
}


def do_draw(reason="Plugin-Seite"):
    values = settings()
    if game.reveal():
        return {"success": False, "error": tr("Die Auflösung läuft schon. Fang erst eine neue Runde an.")}
    if len(game.people()) < 3:
        return {"success": False, "error": tr("Zum Auslosen braucht es mindestens drei Leute.")}
    try:
        notes = game.draw(values["SingleChain"], values["AvoidRepeat"], values["Houses"])
    except santalib.DrawError:
        return {"success": False, "error": tr("So geht die Auslosung nicht auf. Lass bei den Haushalten etwas weg.")}
    note = " ".join(tr(DRAW_NOTES[n]) for n in notes if n in DRAW_NOTES)
    _draw_note.update(text=note, tone="")
    stats = game.stats()
    log(f"Ausgelost ({reason}): {stats['count']} Leute, {stats['chains']} Kreis(e)." + (f" {note}" if note else ""))
    if values["SignupOpen"]:
        save_settings({"SignupOpen": False})
    with _takeover_lock:
        _focus.update(kind="drawn", at=now())
    if values["DrawOnTv"]:
        want("drawn", DRAWN_SECONDS)
    return {"success": True, "note": note, "stats": stats}


def do_undraw():
    if game.reveal():
        return {"success": False, "error": tr("Die Auflösung lief schon. Fang erst eine neue Runde an.")}
    game.undraw()
    _draw_note.update(text="", tone="")
    log("Auslosung zurückgenommen.")
    return {"success": True}


def start_reveal(reason="Plugin-Seite"):
    values = settings()
    if not game.drawn:
        return {"success": False, "error": tr("Es ist noch nicht ausgelost.")}
    rev = game.start_reveal(values["RevealStep"], DRUM_SECONDS, INTRO_SECONDS)
    log(f"Auflösung beginnt ({reason}).")
    want("reveal", reveal_end(rev) - now() + values["DoneMinutes"] * 60)
    if values["Sound"]:
        threading.Thread(target=reveal_sounds, args=(rev["id"],), name=f"{PLUGIN_ID}-drums", daemon=True).start()
    return {"success": True}


def stop_reveal():
    """Auflösung abbrechen: die Paare bleiben geheim (die Runde geht weiter)."""
    if not game.reveal():
        return {"success": False, "error": tr("Es läuft keine Auflösung.")}
    game.stop_reveal()
    stop_sounds()
    want("reveal", 0)
    return {"success": True}


def new_round(clear=False):
    values = settings()
    stop_sounds()
    if clear:
        game.clear_people()
    else:
        game.archive_and_reset(round_title(values))
    want("reveal", 0)
    want("drawn", 0)
    _draw_note.update(text="", tone="")
    state = load_state()
    state.pop("autoDraw", None)
    state.pop("autoReveal", None)
    write_json(STATE_FILE, state)
    save_settings({"SignupOpen": True})
    log("Neue Runde." + (" Alle Teilnehmer entfernt." if clear else ""))
    return {"success": True}


# --------------------------------------------------------------------------
# Handy
# --------------------------------------------------------------------------

_tries = {}                       # Name -> Fehlversuche (Zeiten)
_tries_lock = threading.Lock()


def code_ok(code):
    return str(code or "").strip() == game.code


def person_for(body_or_query):
    token = body_or_query.get("tok")
    if isinstance(token, list):
        token = (token or [""])[0]
    return game.by_token(token) if token else None


def me_public(row):
    values = settings()
    out = {"id": row["id"], "name": row["name"], "house": row.get("house") or "", "wish": row.get("wish") or "",
           "nope": row.get("nope") or "", "ready": bool(row.get("ready")), "seen": bool(row.get("seen"))}
    current = mode()
    if game.drawn and values["Messages"]:
        # Was mein Wichtel mir (anonym) geschrieben hat, und meine Antworten
        out["fromSanta"] = game.messages(row["id"])
        target = game.match_for(row["id"])
        out["toKid"] = game.messages(target["id"]) if target and row.get("seen") else []
    if current == "done":
        santa = game.santa_of(row["id"])
        out["santa"] = santa["name"] if santa else ""
    return out


def phone_info(query):
    values = settings()
    code = (query.get("c") or [""])[0]
    out = {"success": True, "lang": values["Language"], "title": round_title(values), "codeOk": code_ok(code)}
    if not out["codeOk"]:
        return out
    row = person_for(query)
    out.update({
        "budget": budget_text(values), "gift": gift_at(values), "drawAt": 0 if game.drawn else draw_at(values),
        "houses": values["Houses"], "signupOpen": values["SignupOpen"] and not game.drawn, "drawn": game.drawn,
        "messages": values["Messages"], "mode": mode(), "now": now(),
        "names": [p["name"] for p in sorted(game.people(), key=lambda p: p["joined"])],
        "me": me_public(row) if row else None,
    })
    return out


def phone_post(path, body):
    values = settings()
    if not code_ok(body.get("c")):
        return {"success": False, "error": "code"}, 403
    if path == "/api/join":
        if not values["SignupOpen"] or game.drawn:
            return {"success": False, "error": tr("Die Anmeldung ist geschlossen.")}, 400
        try:
            row = game.join(body.get("name"), body.get("pin"), body.get("house") if values["Houses"] else "",
                            body.get("wish"), body.get("nope"), body.get("tok"))
        except ValueError as exc:
            return {"success": False, "error": join_error(str(exc))}, 400
        log(f"{row['name']} macht mit.")
        return {"success": True, "me": me_public(row)}, 200
    if path == "/api/login":
        name = santalib.name_key(body.get("name"))
        with _tries_lock:
            recent = [x for x in _tries.get(name, []) if now() - x < 600]
            _tries[name] = recent
            if len(recent) >= LOGIN_TRIES:
                return {"success": False, "error": tr("Zu viele Versuche. Warte zehn Minuten.")}, 429
        row = game.login(body.get("name"), body.get("pin"), body.get("tok"))
        if not row:
            with _tries_lock:
                _tries.setdefault(name, []).append(now())
            return {"success": False, "error": tr("Name oder PIN stimmen nicht.")}, 400
        return {"success": True, "me": me_public(row)}, 200
    row = person_for(body)
    if not row:
        return {"success": False, "error": "login"}, 401
    if path == "/api/logout":
        game.logout(body.get("tok"))
        return {"success": True}, 200
    if path == "/api/me":
        fields = {k: body[k] for k in ("wish", "nope") if k in body}
        if not game.drawn:
            fields.update({k: body[k] for k in ("name",) if k in body})
            if values["Houses"] and "house" in body:
                fields["house"] = body["house"]
        try:
            row = game.update(row["id"], **fields)
        except ValueError as exc:
            return {"success": False, "error": join_error(str(exc))}, 400
        return {"success": True, "me": me_public(row)}, 200
    if path == "/api/leave":
        if game.drawn:
            return {"success": False, "error": tr("Nach der Auslosung kann man nicht mehr aussteigen. Sag der "
                                                  "Spielleitung Bescheid.")}, 400
        game.remove(row["id"])
        log(f"{row['name']} macht nicht mehr mit.")
        return {"success": True}, 200
    if not game.drawn:
        return {"success": False, "error": tr("Es ist noch nicht ausgelost.")}, 400
    if path == "/api/open":
        target = game.match_for(row["id"])
        if not target:
            return {"success": False, "error": tr("Für dich gibt es kein Los. Sag der Spielleitung Bescheid.")}, 400
        first = not row.get("seen")
        game.mark_seen(row["id"])
        if first:
            log(f"Jemand hat sein Los angesehen ({game.stats()['seen']} von {game.stats()['count']}).")
        return {"success": True, "match": {"name": target["name"], "wish": target.get("wish") or "",
                                           "nope": target.get("nope") or "", "house": target.get("house") or ""},
                "me": me_public(game.person(row["id"]))}, 200
    if path == "/api/ready":
        game.update(row["id"], ready=as_bool(body.get("ready")))
        return {"success": True, "me": me_public(game.person(row["id"]))}, 200
    if path in ("/api/ask", "/api/answer"):
        if not values["Messages"]:
            return {"success": False, "error": tr("Nachrichten sind ausgeschaltet.")}, 400
        if path == "/api/ask":
            target = game.match_for(row["id"])
            receiver, by = (target or {}).get("id"), "santa"
        else:
            receiver, by = row["id"], "kid"
        if not receiver:
            return {"success": False, "error": tr("Für dich gibt es kein Los. Sag der Spielleitung Bescheid.")}, 400
        try:
            message = game.add_message(receiver, by, body.get("text"))
        except ValueError:
            return {"success": False, "error": tr("Das sind genug Nachrichten.")}, 400
        if not message:
            return {"success": False, "error": tr("Schreib erst etwas.")}, 400
        return {"success": True, "me": me_public(game.person(row["id"]))}, 200
    return {"success": False, "error": "Nicht gefunden"}, 404


def join_error(code):
    return {
        "drawn": tr("Die Lose sind schon gezogen."),
        "name": tr("Bitte schreib deinen Namen dazu."),
        "pin": tr("Die PIN hat genau vier Ziffern."),
        "taken": tr("Diesen Namen gibt es schon. Wenn du das bist: melde dich mit deiner PIN an. Sonst nimm "
                    "einen anderen, z. B. mit Nachnamen."),
        "full": tr("Mehr Leute gehen nicht."),
    }.get(code, code)


def lan_address():
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("10.255.255.255", 1))     # schickt nichts, sucht nur die Route
        return probe.getsockname()[0]
    except OSError:
        return ""
    finally:
        probe.close()


_lan = {"at": 0.0, "ip": ""}


def phone_url():
    if now() - _lan["at"] > 60:
        _lan.update(at=now(), ip=lan_address())
    port = PORTS.port
    if not port:
        return ""
    host = _lan["ip"] or socket.gethostname()
    return f"http://{host}:{port}/"


# --------------------------------------------------------------------------
# Takeover: die Szene über das laufende Programm legen
# --------------------------------------------------------------------------
# Gründe (wichtigster zuerst): Auflösung, Bescherung, Lose gezogen, von Hand.

REASONS = ("reveal", "giving", "drawn", "manual")
TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
TAKEOVER_DESCRIPTION = ("Wird vom Plugin Secret Santa abgespielt: die Auslosung, der Countdown zur Bescherung "
                        "und die Auflösung. Bleibt ausgeschaltet, damit es nicht im Quick Mix landet. Das Plugin "
                        "legt sie neu an, wenn sie gelöscht wird.")
TAKEOVER_ITEM_SECONDS = 24 * 3600
STATE_FILE = DATA_DIR / "state.json"

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "since": 0.0, "limit": 0, "reason": "", "note": "", "retryAt": 0.0,
             "busy": False, "playlistId": None, "playlistAt": 0.0}
_want = {reason: 0.0 for reason in REASONS}
_stop_requested = threading.Event()


def load_state():
    stored = read_json(STATE_FILE, {})
    return stored if isinstance(stored, dict) else {}


def save_state(**fields):
    stored = load_state()
    stored.update(fields)
    write_json(STATE_FILE, stored)


def want(reason, seconds):
    with _takeover_lock:
        _want[reason] = max(_want[reason], now() + seconds) if seconds > 0 else 0.0
        _takeover["retryAt"] = 0.0
    if reason == "reveal":
        save_state(revealUntil=_want["reveal"])


def wanted_reason(t=None):
    t = t or now()
    for reason in REASONS:
        if _want[reason] > t:
            return reason
    return ""


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


def ensure_takeover_playlist(scene_db_id):
    """Ein Takeover spielt eine Playlist: die Szene allein, lange, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = None
    if playlist_id:
        try:
            playlist = engine_call("GET", f"/playlists/{playlist_id}")
        except EngineError as exc:
            if exc.status != 404:
                raise
    if not playlist:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist and playlist_id:
        items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
        items = items.get("items") if isinstance(items, dict) else items
        items = [i for i in items or [] if isinstance(i, dict)]
        if len(items) == 1 and str(items[0].get("dynamicSceneId")) == str(scene_db_id):
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=TAKEOVER_PLAYLIST_NAME))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": scene_db_id, "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


_permission = {"at": 0.0, "ok": True, "note": ""}


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover", read_timeout=8) or {}
    except EngineError:
        return ""
    enabled = config.get("enabledPluginNames")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Secret Santa auf der Plugins-Seite aus. Schalte es ein, sonst kann "
                  "die Auflösung nicht von selbst auf den Fernseher.")
    return ""


def takeover_allowed_cached():
    if now() - _permission["at"] > 60:
        note = takeover_permission_note()
        _permission.update(at=now(), ok=not note, note=note)
    return _permission["ok"]


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        log(text)
    return False


def _on_session_state(handle_or_state):
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        reason = _takeover["reason"]
        _takeover.update(handle=None, since=0.0, reason="")
        if new_state != "expired":
            for key in REASONS:            # jemand anderes hat den Bildschirm genommen
                if key != "reveal":
                    _want[key] = 0.0
            _takeover["retryAt"] = now() + 60
    log(f"Der Rahmen hat Secret Santa beendet ({reason}): {new_state}.")
    if new_state != "expired":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason):
    with _takeover_lock:
        handle = _takeover["handle"]
        _takeover.update(handle=None, since=0.0, reason="")
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:  # noqa: BLE001
        log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", "warning")
    log(f"Bildschirm zurückgegeben ({reason}).")
    if reason != "neu":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def show_scene(reason):
    scene = find_scene()
    if not scene:
        return _note(tr("Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal."))
    try:
        if not _takeover["playlistId"] or now() - _takeover["playlistAt"] > 600:
            _takeover.update(playlistId=ensure_takeover_playlist(scene["id"]), playlistAt=now())
    except EngineError as exc:
        return _note(tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc))
    playlist_id = _takeover["playlistId"]
    left = max(60, int(_want[reason] - now()))
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             "overlay": {"enabled": False}}
    handle, limit, last_error = None, 0, None
    for seconds in sorted({min(left + 60, 12 * 3600), min(left + 60, 4 * 3600), min(left + 60, 3600),
                           min(left + 60, 300)}, reverse=True):
        try:
            _leftover["askedAt"] = time.time()
            handle = plugin.acquire_display_session(
                session_key="secret-santa", state=state, display_name=DISPLAY_NAME,
                max_duration_seconds=seconds, wake_if_off=settings()["WakeScreen"])
            limit = seconds
            break
        except Exception as exc:  # noqa: BLE001
            last_error = exc
    if handle is None:
        if last_error is not None:
            return _note(takeover_permission_note() or tr("Konnte Secret Santa nicht zeigen: {exc}", exc=last_error))
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    with _takeover_lock:
        _takeover.update(handle=handle, since=now(), limit=limit, note="", reason=reason)
    try:
        handle.on_state_change(_on_session_state)
    except Exception:  # noqa: BLE001
        pass
    try:
        if not handle.wait_until_active(timeout=15):
            end_takeover("fehlgeschlagen")
            return _note(tr("Der Rahmen hat Secret Santa nicht rechtzeitig gezeigt."))
    except Exception as exc:  # noqa: BLE001
        end_takeover("fehlgeschlagen")
        return _note(tr("Konnte Secret Santa nicht zeigen: {exc}", exc=exc))
    _scene["seen"] = max(_scene["seen"], now())
    log(f"Secret Santa hat den Bildschirm ({reason}).")
    return True


def decide_takeover():
    t = now()
    reason = wanted_reason(t)
    with _takeover_lock:
        handle, since, limit = _takeover["handle"], _takeover["since"], _takeover["limit"]
        retry_at, busy = _takeover["retryAt"], _takeover["busy"]
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        if not reason:
            end_takeover("fertig")
        elif limit and t - since >= limit - 20:
            end_takeover("neu")
        else:
            _takeover["reason"] = reason
        return
    if not reason:
        stop_leftover_takeover()
        return
    if t < retry_at or busy:
        return
    _takeover["busy"] = True
    try:
        if not show_scene(reason):
            with _takeover_lock:
                _takeover["retryAt"] = t + 20
    finally:
        _takeover["busy"] = False


def stop_all():
    with _takeover_lock:
        for key in REASONS:
            _want[key] = 0.0
    save_state(revealUntil=0)
    end_takeover("von der Plugin-Seite beendet")
    return {"success": True}


def tick():
    t = now()
    values = settings()
    state = load_state()
    rid = game.data["id"]
    # Von selbst auslosen
    when = draw_at(values)
    if when and t >= when and not game.drawn and state.get("autoDraw") != rid and t < when + 7 * 86400:
        save_state(autoDraw=rid)
        if len(game.people()) >= 3:
            result = do_draw("Zeitpunkt erreicht")
            if not result["success"]:
                _draw_note.update(text=result["error"], tone="bad")
        else:
            _draw_note.update(text=tr("Zum ausgemachten Zeitpunkt waren weniger als drei Leute angemeldet; "
                                      "lose von Hand aus."), tone="bad")
    gift = gift_at(values)
    current = mode(t)
    # Countdown in den letzten Minuten, „Frohe Bescherung“ danach
    if gift and game.drawn and current in ("drawn", "giving") and values["CountdownOnTv"]:
        if gift - values["CountdownOnTv"] * 60 <= t < gift + GIVING_AFTER and state.get("countdown") != rid:
            save_state(countdown=rid)
            want("giving", gift + GIVING_AFTER - t)
    # Auflösung von selbst
    if values["RevealAuto"] and gift and game.drawn and not game.reveal() and state.get("autoReveal") != rid \
            and gift + 20 <= t < gift + 6 * 3600:
        save_state(autoReveal=rid)
        start_reveal("Zeit der Bescherung")
    rev = game.reveal()
    if rev and current == "done" and _want["reveal"] and t > _want["reveal"]:
        want("reveal", 0)
    if current != "giving" and _want["giving"] and not (gift and t < gift):
        want("giving", 0)
    decide_takeover()


def loop():
    while not _stop_requested.is_set():
        try:
            tick()
            if now() - _services["at"] > SERVICES_EVERY and not _services["busy"]:
                _services["at"] = now()
                threading.Thread(target=check_services, args=(True,), name=f"{PLUGIN_ID}-services",
                                 daemon=True).start()
        except Exception as exc:  # noqa: BLE001 - der Faden darf nicht sterben
            log(f"Schleife: {exc!r}", "warning")
        _stop_requested.wait(1.0)


# ---- Takeover-Playlist, die nach dem Zurückgeben weiterläuft ---------------
# Lief vor einem Takeover keine Playlist, stellt die Engine dieses "nichts"
# nicht wieder her, und die Takeover-Playlist läuft einfach weiter (Jans
# Rahmen, 2026-10-24). Dann hält das Plugin sie mit POST /slideshow/stop an:
# nur wenn sie läuft, niemand den Bildschirm hält und das Plugin nicht
# gerade selbst darum gebeten hat.
_leftover = {"askedAt": 0.0, "failed": False, "checkedAt": 0.0}


def stop_leftover_takeover():
    if time.time() - _leftover["checkedAt"] < 15:
        return False
    _leftover["checkedAt"] = time.time()
    try:
        playlist_id = _takeover["playlistId"] or load_state().get("takeoverPlaylistId")
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status") or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status") or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop")
    except Exception as exc:  # noqa: BLE001 - darf die Schleife nie aufhalten
        if not _leftover["failed"]:
            log(f"The takeover playlist kept running and could not be stopped: {exc}", "warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def check_playback_resumed():
    if playback_guard is not None:
        try:
            playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log, stop_event=_stop_requested)
        except Exception as exc:  # noqa: BLE001
            log(f"playback_guard: {exc}", "warning")


# --------------------------------------------------------------------------
# Ton (wie Photo Gala): Trommelwirbel, Tusch, Applaus, Glöckchen
# --------------------------------------------------------------------------

_audio_lock = threading.Lock()
_audio = {"active": 0, "saved": False, "restoreTimer": None, "processes": [], "note": "", "gen": 0}
SINK = "@DEFAULT_AUDIO_SINK@"
CUES = ("bells", "drumroll", "tada", "applause")


def sound_environment():
    """Der Rahmen startet Plugins ohne XDG_RUNTIME_DIR; ohne finden pw-play
    und paplay den Tondienst nicht (gemessen von FireWatch)."""
    env = dict(os.environ)
    env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
    return env


def player_commands(path):
    options = [("pw-play", []), ("paplay", []), ("aplay", ["-q"]),
               ("ffplay", ["-nodisp", "-autoexit", "-loglevel", "error"]), ("mpv", ["--no-video", "--really-quiet"])]
    commands = []
    for name, args in options:
        tool = shutil.which(name)
        if tool:
            commands.append([tool, *args, str(path)])
    return commands


def run_player(path):
    """Eine Datei mit dem ersten Spieler, der es schafft. "" oder der Fehler."""
    said = tr("Kein Abspielprogramm auf dem Rahmen gefunden.")
    for command in player_commands(path):
        try:
            process = subprocess.Popen(command, env=sound_environment(),
                                       stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        except OSError as exc:
            said = f"{Path(command[0]).name}: {exc}"
            continue
        with _audio_lock:
            _audio["processes"].append(process)
        try:
            _, errors = process.communicate(timeout=60)
        except subprocess.TimeoutExpired:
            process.kill()
            _, errors = process.communicate()
        finally:
            with _audio_lock:
                if process in _audio["processes"]:
                    _audio["processes"].remove(process)
        if process.returncode == 0 or process.returncode < 0:
            return ""
        said = f"{Path(command[0]).name}: " + \
            ((errors or b"").decode("utf-8", "replace").strip()[:160] or str(process.returncode))
    return said


def stop_sounds():
    with _audio_lock:
        _audio["gen"] += 1
        processes = list(_audio["processes"])
    for process in processes:
        try:
            process.terminate()
        except OSError:
            pass


def sink_state():
    tool = shutil.which("wpctl")
    if not tool:
        return None
    try:
        done = subprocess.run([tool, "get-volume", SINK], env=sound_environment(),
                              capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return None
    match = re.search(r"Volume:\s*([0-9.]+)", done.stdout or "")
    if done.returncode != 0 or not match:
        return None
    return float(match.group(1)), "MUTED" in done.stdout


def set_sink(volume=None, muted=None):
    tool = shutil.which("wpctl")
    if not tool:
        return
    commands = []
    if volume is not None:
        commands.append([tool, "set-volume", SINK, f"{max(0.0, min(1.0, volume)):.2f}"])
    if muted is not None:
        commands.append([tool, "set-mute", SINK, "1" if muted else "0"])
    for command in commands:
        try:
            subprocess.run(command, env=sound_environment(), capture_output=True, timeout=10)
        except (OSError, subprocess.TimeoutExpired) as exc:
            plugin.log(f"wpctl failed: {exc}", level="warning")


def frame_volume():
    try:
        body = engine_call("GET", "/api/v1/system/volume", read_timeout=10) or {}
    except EngineError:
        return None, None
    if not isinstance(body, dict):
        return None, None
    level = next((body[k] for k in ("value", "volume", "level") if isinstance(body.get(k), (int, float))), None)
    muted = next((body[k] for k in ("muted", "isMuted", "mute") if isinstance(body.get(k), bool)), None)
    return level, muted


def raise_volume():
    """Vor dem ersten Geräusch: Lautstärke merken und setzen (nur wenn eine eingestellt ist)."""
    values = settings()
    if values["Volume"] <= 0:
        return
    try:
        level, muted = frame_volume()
        if level is not None:
            save_state(volumeBefore={"volume": level, "muted": muted, "set": values["Volume"]})
            engine_call("POST", "/api/v1/system/volume", {"value": values["Volume"]}, read_timeout=10)
            if muted:
                engine_call("POST", "/api/v1/system/mute", {"value": False}, read_timeout=10)
        sink = sink_state()
        if sink is not None:
            save_state(sinkBefore={"volume": sink[0], "muted": sink[1]})
            set_sink(volume=values["Volume"] / 100, muted=False)
    except EngineError as exc:
        plugin.log(f"Could not set the volume: {exc}", level="warning")


def restore_volume():
    """Lautstärke zurück, wie sie vorher war (auch nach einem Neustart)."""
    state = load_state()
    saved = state.get("volumeBefore")
    if isinstance(saved, dict):
        level, muted = frame_volume()
        try:
            if level is not None and int(level) == int(saved.get("set", -1)) and saved.get("volume") is not None:
                engine_call("POST", "/api/v1/system/volume", {"value": int(saved["volume"])}, read_timeout=10)
            if saved.get("muted") is True and muted is False:
                engine_call("POST", "/api/v1/system/mute", {"value": True}, read_timeout=10)
        except EngineError as exc:
            plugin.log(f"Could not restore the volume: {exc}", level="warning")
        save_state(volumeBefore=None)
    sink = state.get("sinkBefore")
    if isinstance(sink, dict):
        set_sink(volume=sink.get("volume"), muted=bool(sink.get("muted")))
        save_state(sinkBefore=None)
    with _audio_lock:
        _audio["saved"] = False


def _restore_if_quiet():
    with _audio_lock:
        if _audio["active"] > 0:
            return
        _audio["restoreTimer"] = None
    restore_volume()


def audio_begin():
    with _audio_lock:
        first = not _audio["saved"]
        _audio["saved"] = True
        _audio["active"] += 1
        if _audio["restoreTimer"] is not None:
            _audio["restoreTimer"].cancel()
            _audio["restoreTimer"] = None
    if first:
        raise_volume()


def audio_end():
    with _audio_lock:
        _audio["active"] = max(0, _audio["active"] - 1)
        if _audio["active"] == 0:
            timer = threading.Timer(6.0, _restore_if_quiet)
            timer.daemon = True
            _audio["restoreTimer"] = timer
            timer.start()


def play_cue(name):
    """Ein Geräusch abspielen, ohne zu warten."""
    path = SOUNDS / f"{name}.wav"
    if not path.is_file():
        return False

    def run():
        audio_begin()
        try:
            problem = run_player(path)
            _audio["note"] = tr("Konnte den Klang nicht abspielen ({problem}).", problem=problem) if problem else ""
            if problem:
                plugin.log(_audio["note"], level="warning")
        finally:
            audio_end()

    threading.Thread(target=run, name=f"{PLUGIN_ID}-sound", daemon=True).start()
    return True


def reveal_sounds(reveal_id):
    """Die Auflösung im Takt: Glöckchen zum Vorspann, je Paar Trommelwirbel und Tusch, am Ende Applaus."""
    with _audio_lock:
        generation = _audio["gen"]

    def still():
        rev = game.reveal()
        return rev and rev["id"] == reveal_id and _audio["gen"] == generation and not _stop_requested.is_set()

    def wait_until(at):
        while still():
            left = at - now()
            if left <= 0:
                return True
            _stop_requested.wait(min(left, 0.25))
        return False

    rev = game.reveal()
    if not rev:
        return
    # Die Szene braucht einen Moment, bis sie steht.
    if wait_until(rev["started"] + 0.8):
        play_cue("bells")
    for index in range(rev["count"]):
        start = rev["started"] + rev["intro"] + index * rev["step"]
        if not wait_until(start):
            return
        play_cue("drumroll")
        if not wait_until(start + rev["drum"]):
            return
        play_cue("tada")
    if wait_until(reveal_end(rev) + 0.5):
        play_cue("applause")


def test_sound(body):
    name = str(body.get("name") or "drumroll")
    if name not in CUES:
        name = "drumroll"
    if not play_cue(name):
        return {"success": False, "error": tr("Den Klang gibt es nicht.")}
    return {"success": True}


# --------------------------------------------------------------------------
# Verbindungen (Karte auf der Plugin-Seite)
# --------------------------------------------------------------------------

SERVICES_EVERY = 5 * 60
_services = {"at": 0.0, "rows": [], "busy": False}
_services_lock = threading.Lock()


def _row(key, name, state, text, hint=""):
    return {"key": key, "name": name, "state": state, "text": text, "hint": hint}


def _check_engine():
    name = tr("DynaFrame auf diesem Rahmen")
    started = time.time()
    try:
        engine_call("GET", "/slideshow/status", read_timeout=8)
    except EngineError as exc:
        return _row("engine", name, "bad", tr("Nicht erreichbar: {exc}", exc=exc),
                    tr("Starte den Rahmen neu, wenn das rot bleibt."))
    return _row("engine", name, "ok", tr("Erreichbar ({ms} ms).", ms=int((time.time() - started) * 1000)))


def _check_scene():
    name = tr("Szene „Secret Santa“")
    if not find_scene():
        return _row("scene", name, "bad", tr("Nicht installiert."), tr("Installiere das Paket noch einmal."))
    return _row("scene", name, "ok", tr("Installiert."))


def _check_takeover():
    name = tr("Von selbst auf den Fernseher")
    note = takeover_permission_note()
    _permission.update(at=now(), ok=not note, note=note)
    if note:
        return _row("takeover", name, "warn", tr("„Allow takeover“ ist aus."),
                    tr("Ohne das zeigt der Fernseher die Auslosung und die Auflösung nur, wenn die Playlist "
                       "„Secret Santa“ läuft. Einschalten auf der Plugins-Seite."))
    return _row("takeover", name, "ok", tr("Erlaubt."))


def _check_phone():
    name = tr("Handy-Seite")
    url = phone_url()
    if not url:
        return _row("phone", name, "bad", tr("Kein freier Port gefunden."), tr("Trag unten einen freien Port ein."))
    started = time.time()
    try:
        response = requests.get(url + "api/ping", timeout=5)
        ok = response.status_code == 200
    except requests.RequestException:
        ok = False
    if not ok:
        return _row("phone", name, "bad", tr("{url} antwortet nicht.", url=url),
                    tr("Ist das WLAN des Rahmens verbunden?"))
    text = tr("Läuft unter {url} ({ms} ms).", url=url, ms=int((time.time() - started) * 1000))
    return _row("phone", name, "ok", text, tr("Mit Web Login und strenger Firewall muss der Port dort offen sein."))


def _check_sound():
    values = settings()
    if not values["Sound"]:
        return None
    name = tr("Ton (Trommelwirbel, Applaus)")
    players = [p for p in ("pw-play", "paplay", "aplay", "ffplay", "mpv") if shutil.which(p)]
    if not players:
        return _row("sound", name, "bad", tr("Kein Abspielprogramm auf dem Rahmen gefunden."))
    if _audio["note"]:
        return _row("sound", name, "warn", _audio["note"])
    return _row("sound", name, "ok", tr("Spielt über {player}.", player=players[0]))


def _check_clock():
    name = tr("Uhr auf dem Rahmen")
    today = datetime.date.today()
    text = tr("Heute ist der {date}.", date=today.strftime("%d.%m.%Y" if settings()["Language"] == "de" else "%d/%m/%Y"))
    if today.year < 2025:
        return _row("clock", name, "bad", text, tr("Das Datum stimmt nicht; der Countdown wäre falsch."))
    try:
        synced = subprocess.run(["timedatectl", "show", "-p", "NTPSynchronized", "--value"], capture_output=True,
                                text=True, timeout=4).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        synced = ""
    if synced == "no":
        return _row("clock", name, "warn", text + " " + tr("Die Uhr ist nicht mit dem Internet abgeglichen."))
    return _row("clock", name, "ok", text)


def check_services(force=False):
    with _services_lock:
        if _services["busy"] or (not force and now() - _services["at"] < SERVICES_EVERY and _services["rows"]):
            return _services["rows"]
        _services["busy"] = True
    try:
        rows = []
        for fn in (_check_engine, _check_scene, _check_takeover, _check_phone, _check_sound, _check_clock):
            try:
                row = fn()
            except Exception as exc:  # noqa: BLE001 - eine kaputte Prüfung soll die anderen nicht aufhalten
                row = _row("error", tr("Prüfung"), "bad", str(exc))
            if row:
                rows.append(row)
        before = {r["key"]: r["state"] for r in _services["rows"]}
        for r in rows:
            if r["state"] == "bad" and before.get(r["key"]) != "bad":
                log(f"{r['name']}: {r['text']}", "warning")
        _services.update(rows=rows, at=now())
        return rows
    finally:
        _services["busy"] = False


def services_payload():
    rows = _services["rows"]
    return {"at": _services["at"] or None, "busy": _services["busy"], "rows": rows,
            "bad": sum(1 for r in rows if r["state"] == "bad"),
            "warn": sum(1 for r in rows if r["state"] == "warn")}


# --------------------------------------------------------------------------
# Playlist für die Szene
# --------------------------------------------------------------------------

OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=PLAYLIST_NAMES.values(),
    name=lambda: PLAYLIST_NAMES.get(settings()["Language"], PLAYLIST_NAMES["en"]),
    description=lambda: tr("Wichteln: wer mitmacht, der Countdown zur Bescherung und die Auflösung."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
    held=lambda: _takeover["handle"] is not None,
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def people_admin():
    """Teilnehmer für die Plugin-Seite: nie, wen jemand gezogen hat."""
    rows = []
    for p in sorted(game.people(), key=lambda p: p["joined"]):
        rows.append({"id": p["id"], "name": p["name"], "house": p.get("house") or "", "joined": p["joined"],
                     "wish": bool(p.get("wish")), "seen": bool(p.get("seen")), "ready": bool(p.get("ready")),
                     "phones": len(p.get("tokens") or []), "offline": bool(p.get("offline")),
                     "wishText": (p.get("wish") or "") if p.get("offline") else ""})
    return rows


def state_payload():
    values = settings()
    t = now()
    with _takeover_lock:
        note = _takeover["note"]
        reason = _takeover["reason"] if _takeover["handle"] is not None else ""
        wanted = wanted_reason(t)
        until = _want[wanted] if wanted else 0
    rev = game.reveal()
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": values,
        "title": round_title(values),
        "code": game.code,
        "stats": game.stats(),
        "people": people_admin(),
        "mode": mode(t),
        "now": t,
        "gift": gift_at(values),
        "drawAt": draw_at(values),
        "budget": budget_text(values),
        "drawNote": dict(_draw_note),
        "reveal": {"started": rev["started"], "end": reveal_end(rev)} if rev else None,
        "history": game.history(),
        "sceneVisible": scene_visible(t),
        "phoneUrl": phone_url(),
        "port": PORTS.status(),
        "takeover": reason,
        "takeoverWanted": wanted,
        "takeoverUntil": until,
        "takeoverNote": note if wanted else "",
        "services": services_payload(),
        "theme": {"id": theme_id()},
    }


def admin_post(path, body):
    if path == "/api/port":
        return PORTS.change(body.get("port"))
    if path == "/api/settings":
        changed = save_settings(body)
        if "MakePlaylist" in changed:
            OWN.changed()
        if {"GiftDate", "GiftTime", "CountdownOnTv", "RevealAuto"} & set(changed):
            state = load_state()
            for key in ("countdown", "autoReveal"):
                state.pop(key, None)
            write_json(STATE_FILE, state)
        if {"DrawDate", "DrawTime"} & set(changed):
            state = load_state()
            state.pop("autoDraw", None)
            write_json(STATE_FILE, state)
        return {"success": True, "changed": changed}
    if path == "/api/code":
        game.set_code(santalib.new_code())
        return {"success": True, "code": game.code}
    if path == "/api/person/add":
        try:
            row = game.join(body.get("name"), body.get("pin"), body.get("house"), body.get("wish"), "",
                            offline=True)
        except ValueError as exc:
            return {"success": False, "error": join_error(str(exc))}
        log(f"{row['name']} von der Plugin-Seite eingetragen.")
        return {"success": True}
    if path == "/api/person/update":
        ident = str(body.get("id") or "")
        fields = {}
        if not game.drawn:
            fields.update({k: body[k] for k in ("name", "house") if k in body})
        if "pin" in body and str(body.get("pin") or ""):
            fields["pin"] = body["pin"]
        row = game.person(ident)
        if row and row.get("offline") and "wish" in body:
            fields["wish"] = body["wish"]
        try:
            row = game.update(ident, **fields)
        except ValueError as exc:
            return {"success": False, "error": join_error(str(exc))}
        return {"success": bool(row)}
    if path == "/api/person/remove":
        was_drawn = game.drawn
        ok = game.remove(str(body.get("id") or ""))
        if ok and was_drawn:
            _draw_note.update(text=tr("Weil jemand entfernt wurde, ist die Auslosung zurückgenommen. Lose neu aus."),
                              tone="bad")
        return {"success": ok}
    if path == "/api/draw":
        return do_draw()
    if path == "/api/undraw":
        return do_undraw()
    if path == "/api/reveal":
        return start_reveal()
    if path == "/api/reveal/stop":
        return stop_reveal()
    if path == "/api/newround":
        return new_round(as_bool(body.get("clear")))
    if path == "/api/show":
        want("manual", max(1, min(120, as_int(body.get("minutes"), 5))) * 60)
        return {"success": True}
    if path == "/api/stop":
        return stop_all()
    if path == "/api/sound":
        return test_sound(body)
    if path == "/api/playlist":
        return make_playlist()
    return None


def page_html(name="index.html"):
    html = (PLUGIN_DIR / "studio" / name).read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
    "/qrcode.js": ("phone/qrcode.js", "application/javascript; charset=utf-8"),
    "/port_block.js": ("studio/port_block.js", "application/javascript; charset=utf-8"),
}
PHONE_FILES = {
    "/phone.css": ("phone/phone.css", "text/css; charset=utf-8"),
    "/phone.js": ("phone/phone.js", "application/javascript; charset=utf-8"),
    "/icon.png": ("icon.png", "image/png"),
}


class BaseHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False, extra=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self, limit=64 * 1024):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(min(length, limit)) if length > 0 else b""
        if length > limit:
            self.close_connection = True

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()


class StudioHandler(BaseHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        arg = lambda name, default="": (query.get(name) or [default])[0]  # noqa: E731
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                # Die Szene fragt etwa jede Sekunde; daran merkt das Plugin, dass sie zu sehen ist.
                _scene["seen"] = now()
                self._json(scene_state(), cors=True)
                return
            if path == "/api/services":
                check_services(force=True)
                self._json({"success": True, "services": services_payload()})
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", arg("m"))[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            result = admin_post(path, self._body())
            if result is None:
                self._json({"success": False, "error": "Nicht gefunden"}, 404)
            else:
                self._json(result)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


def phone_html():
    html = (PLUGIN_DIR / "phone" / "index.html").read_text(encoding="utf-8")
    lang = settings()["Language"]
    return html.replace('<html lang="en">', f'<html lang="{lang}">', 1)


class PhoneHandler(BaseHandler):
    """Die Seite für die Mitspieler, im ganzen WLAN erreichbar. Keine Einstellungen."""

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(phone_html().encode("utf-8"), "text/html; charset=utf-8",
                           extra={"Referrer-Policy": "no-referrer"})
                return
            asset = PHONE_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1], cache="public, max-age=600")
                return
            if path == "/api/ping":
                self._json({"success": True, "plugin": PLUGIN_ID})
                return
            if path == "/api/info":
                self._json(phone_info(query))
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError:
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            payload, status = phone_post(path, self._body())
            self._json(payload, status)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None
PORTS = plugin_ports.PortKeeper(PLUGIN_ID, "Secret Santa", DATA_DIR, default=8155, env="SECRETSANTA_PORT",
                                log=lambda text, level="info": log(text, level),
                                language=lambda: settings()["Language"])


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    studio_server.daemon_threads = True
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


def start_phone():
    PORTS.start(lambda port: ThreadingHTTPServer(("0.0.0.0", port), PhoneHandler))
    if PORTS.port:
        log(f"Handy-Seite: {phone_url()}")


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    global game
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}")
    game = santalib.Round(DATA_DIR)

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("playlist", lambda _context=None: make_playlist())
    plugin.on_action("reveal", lambda _context=None: start_reveal("Aktion"))

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    start_phone()
    rev = game.reveal()
    until = float(load_state().get("revealUntil") or 0)
    if rev and until > now() + 30:          # nach einem Neustart mitten in der Auflösung
        with _takeover_lock:
            _want["reveal"] = until
        if settings()["Sound"] and now() < reveal_end(rev):
            threading.Thread(target=reveal_sounds, args=(rev["id"],), name=f"{PLUGIN_ID}-drums", daemon=True).start()
    restore_volume()
    threading.Thread(target=loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    threading.Thread(target=check_services, args=(True,), name=f"{PLUGIN_ID}-services", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    stop_sounds()
    end_takeover("gestoppt")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:  # noqa: BLE001
        pass
    PORTS.stop()
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:  # noqa: BLE001
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
