"""Die Wichtelrunde: Teilnehmer, geheime Auslosung, Wunschlisten, Nachrichten.

Alles liegt in data/round.json (die laufende Runde) und data/history.json
(frühere Runden, nur damit niemand zweimal hintereinander dieselbe Person
zieht). Wer wen beschenkt, verlässt dieses Modul nur auf zwei Wegen:
- match_for(person) für das Handy genau dieser Person,
- reveal_pairs() für die Auflösung, und nur wenn die Auflösung läuft.
Die Plugin-Seite bekommt nur Zahlen (wie viele haben nachgesehen).
"""

import datetime
import hashlib
import hmac
import json
import random
import re
import secrets
import threading
import time
from pathlib import Path

MAX_PEOPLE = 60
NAME_MAX = 40
HOUSE_MAX = 40
WISH_MAX = 800
MSG_MAX = 300
MSGS_PER_PERSON = 40


def now():
    return time.time()


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


def write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)


def clean_text(value, limit, lines=False):
    text = str(value or "")
    if lines:
        text = re.sub(r"\r\n?", "\n", text)
        text = re.sub(r"[\x00-\x09\x0b-\x1f\x7f<>]", "", text)
        text = "\n".join(re.sub(r"[ \t]+", " ", row).strip() for row in text.split("\n"))
        text = re.sub(r"\n{3,}", "\n\n", text).strip()
        return text[:limit]
    text = re.sub(r"[\x00-\x1f\x7f<>]", "", text)
    return re.sub(r"\s+", " ", text).strip()[:limit]


def name_key(name):
    return re.sub(r"\s+", " ", str(name or "")).strip().casefold()


def new_code():
    return f"{secrets.randbelow(9000) + 1000}"


def new_id():
    return secrets.token_hex(5)


def token_hash(token):
    token = str(token or "")
    if not re.match(r"^[A-Za-z0-9_-]{16,80}$", token):
        return ""
    return hashlib.sha256(("secret-santa:" + token).encode()).hexdigest()[:32]


def pin_ok(pin):
    return bool(re.match(r"^\d{4}$", str(pin or "")))


def pin_hash(pin, salt=None):
    salt = salt or secrets.token_hex(8)
    digest = hashlib.pbkdf2_hmac("sha256", str(pin).encode(), salt.encode(), 60000).hex()[:40]
    return f"{salt}${digest}"


def pin_check(pin, stored):
    try:
        salt, _digest = str(stored).split("$", 1)
    except ValueError:
        return False
    return hmac.compare_digest(pin_hash(pin, salt), str(stored))


# --------------------------------------------------------------------------
# Auslosen
# --------------------------------------------------------------------------

class DrawError(Exception):
    pass


def _cycle(ids, allowed, rng, budget):
    """Eine große Kette A→B→C→…→A (Hamiltonkreis), zufällig, mit Rückverfolgung."""
    n = len(ids)
    start = ids[0]
    path = [start]
    used = {start}
    steps = [0]

    def walk():
        steps[0] += 1
        if steps[0] > budget:
            return False
        if len(path) == n:
            return path[-1] in allowed and start in allowed[path[-1]]
        options = [x for x in allowed[path[-1]] if x not in used]
        rng.shuffle(options)
        # Wer wenige Möglichkeiten hat, zuerst (macht das Suchen viel schneller)
        options.sort(key=lambda x: len([y for y in allowed[x] if y not in used]))
        for nxt in options:
            path.append(nxt)
            used.add(nxt)
            if walk():
                return True
            path.pop()
            used.discard(nxt)
        return False

    if walk():
        return {path[i]: path[(i + 1) % n] for i in range(n)}
    return None


def _matching(ids, allowed, rng):
    """Irgendeine Zuordnung ohne sich selbst (darf in mehrere Kreise zerfallen)."""
    order = list(ids)
    rng.shuffle(order)
    match_of = {}          # Beschenkter -> Schenkender

    def try_give(giver, seen):
        options = list(allowed[giver])
        rng.shuffle(options)
        for receiver in options:
            if receiver in seen:
                continue
            seen.add(receiver)
            if receiver not in match_of or try_give(match_of[receiver], seen):
                match_of[receiver] = giver
                return True
        return False

    for giver in order:
        if not try_give(giver, set()):
            return None
    return {giver: receiver for receiver, giver in match_of.items()}


def draw_pairs(people, single_chain=True, avoid=None, rng=None):
    """people: [{id, house}]; avoid: {(giverId, receiverId)} (frühere Runden).
    Gibt (pairs, notes) zurück; notes nennt, welche Wünsche nicht gingen."""
    rng = rng or random.SystemRandom()
    ids = [p["id"] for p in people]
    if len(ids) < 3:
        raise DrawError("few")
    house = {p["id"]: name_key(p.get("house")) for p in people}
    avoid = set(avoid or ())
    notes = []

    def allowed_map(use_houses, use_avoid):
        out = {}
        for a in ids:
            out[a] = [b for b in ids if b != a
                      and not (use_houses and house[a] and house[a] == house[b])
                      and not (use_avoid and (a, b) in avoid)]
        return out

    tries = [(True, True), (True, False), (False, False)] if avoid else [(True, False), (False, False)]
    for use_houses, use_avoid in tries:
        allowed = allowed_map(use_houses, use_avoid)
        if any(not v for v in allowed.values()):
            continue
        notes = []
        if avoid and not use_avoid:
            notes.append("repeat")
        if not use_houses and any(house.values()):
            notes.append("houses")
        if single_chain:
            order = list(ids)
            rng.shuffle(order)
            pairs = _cycle(order, allowed, rng, budget=200000)
            if pairs:
                return pairs, notes
        pairs = _matching(ids, allowed, rng)
        if pairs:
            if single_chain:
                notes.append("chain")
            return pairs, notes
    raise DrawError("impossible")


def chain_order(pairs):
    """Reihenfolge für die Auflösung: Kreis für Kreis der Kette nach."""
    left = list(pairs.keys())
    order = []
    while left:
        start = left[0]
        node = start
        while True:
            order.append(node)
            left.remove(node)
            node = pairs[node]
            if node == start or node not in left:
                break
    return order


# --------------------------------------------------------------------------
# Die Runde
# --------------------------------------------------------------------------

class Round:
    """Die laufende Wichtelrunde. Alle Methoden halten self.lock."""

    def __init__(self, folder):
        self.folder = Path(folder)
        self.lock = threading.RLock()
        self.folder.mkdir(parents=True, exist_ok=True)
        self.file = self.folder / "round.json"
        self.history_file = self.folder / "history.json"
        self.seq = 0
        self.data = read_json(self.file, None)
        if not isinstance(self.data, dict) or "people" not in self.data:
            self.data = self._fresh()
            self._save()

    @staticmethod
    def _fresh(code=None):
        return {"id": new_id(), "code": code or new_code(), "created": now(), "people": [], "pairs": {},
                "order": [], "drawnAt": 0, "drawNotes": [], "reveal": None, "messages": {}}

    def _save(self):
        self.seq += 1
        write_json(self.file, self.data)

    # ---- Zugriff ----------------------------------------------------------

    @property
    def code(self):
        return self.data["code"]

    def set_code(self, code):
        with self.lock:
            self.data["code"] = code
            self._save()

    @property
    def drawn(self):
        return bool(self.data.get("pairs"))

    def people(self):
        with self.lock:
            return [dict(p) for p in self.data["people"]]

    def person(self, ident):
        with self.lock:
            return next((p for p in self.data["people"] if p["id"] == ident), None)

    def by_token(self, token):
        digest = token_hash(token)
        if not digest:
            return None
        with self.lock:
            return next((p for p in self.data["people"] if digest in p.get("tokens", [])), None)

    def by_name(self, name):
        key = name_key(name)
        with self.lock:
            return next((p for p in self.data["people"] if name_key(p["name"]) == key), None)

    # ---- Anmelden ---------------------------------------------------------

    def join(self, name, pin, house="", wish="", nope="", token="", offline=False):
        name = clean_text(name, NAME_MAX)
        with self.lock:
            if self.drawn:
                raise ValueError("drawn")
            if not name:
                raise ValueError("name")
            if not pin_ok(pin):
                raise ValueError("pin")
            if self.by_name(name):
                raise ValueError("taken")
            if len(self.data["people"]) >= MAX_PEOPLE:
                raise ValueError("full")
            digest = token_hash(token)
            row = {"id": new_id(), "name": name, "house": clean_text(house, HOUSE_MAX),
                   "pin": pin_hash(pin), "tokens": [digest] if digest else [],
                   "wish": clean_text(wish, WISH_MAX, lines=True), "nope": clean_text(nope, WISH_MAX, lines=True),
                   "joined": now(), "seen": 0, "ready": False, "offline": bool(offline)}
            self.data["people"].append(row)
            self._save()
            return dict(row)

    def login(self, name, pin, token):
        """Mit Name und PIN auf einem (anderen) Handy anmelden."""
        with self.lock:
            row = self.by_name(name)
            if not row or not pin_check(pin, row.get("pin", "")):
                return None
            digest = token_hash(token)
            if digest and digest not in row["tokens"]:
                row["tokens"] = (row["tokens"] + [digest])[-6:]
                self._save()
            return dict(row)

    def logout(self, token):
        digest = token_hash(token)
        with self.lock:
            for row in self.data["people"]:
                if digest in row.get("tokens", []):
                    row["tokens"].remove(digest)
                    self._save()
                    return True
        return False

    def update(self, ident, **fields):
        with self.lock:
            row = self.person(ident)
            if not row:
                return None
            if "name" in fields:
                name = clean_text(fields["name"], NAME_MAX)
                other = self.by_name(name)
                if not name or (other and other["id"] != ident):
                    raise ValueError("taken" if name else "name")
                row["name"] = name
            if "house" in fields:
                row["house"] = clean_text(fields["house"], HOUSE_MAX)
            if "wish" in fields:
                row["wish"] = clean_text(fields["wish"], WISH_MAX, lines=True)
            if "nope" in fields:
                row["nope"] = clean_text(fields["nope"], WISH_MAX, lines=True)
            if "ready" in fields:
                row["ready"] = bool(fields["ready"])
            if "pin" in fields:
                if not pin_ok(fields["pin"]):
                    raise ValueError("pin")
                row["pin"] = pin_hash(fields["pin"])
                row["tokens"] = []        # alle Handys abmelden
            self._save()
            return dict(row)

    def remove(self, ident):
        with self.lock:
            before = len(self.data["people"])
            self.data["people"] = [p for p in self.data["people"] if p["id"] != ident]
            if len(self.data["people"]) == before:
                return False
            if self.drawn:
                # Ohne diese Person geht die Auslosung nicht mehr auf: zurücksetzen.
                self._undraw()
            self._save()
            return True

    def mark_seen(self, ident):
        with self.lock:
            row = self.person(ident)
            if row and not row.get("seen"):
                row["seen"] = now()
                self._save()

    # ---- Auslosen ---------------------------------------------------------

    def _undraw(self):
        self.data.update(pairs={}, order=[], drawnAt=0, drawNotes=[], reveal=None, messages={})
        for row in self.data["people"]:
            row.update(seen=0, ready=False)

    def avoid_pairs(self):
        """(Schenkender, Beschenkter) der letzten Runde, über die Namen zugeordnet."""
        history = read_json(self.history_file, [])
        if not isinstance(history, list) or not history:
            return set()
        last = history[-1]
        keys = {name_key(p["name"]): p["id"] for p in self.data["people"]}
        out = set()
        for giver, receiver in last.get("pairs", []):
            a, b = keys.get(name_key(giver)), keys.get(name_key(receiver))
            if a and b:
                out.add((a, b))
        return out

    def draw(self, single_chain=True, avoid_repeat=True, use_houses=True):
        with self.lock:
            people = [{"id": p["id"], "house": p.get("house") if use_houses else ""} for p in self.data["people"]]
            pairs, notes = draw_pairs(people, single_chain, self.avoid_pairs() if avoid_repeat else None)
            self._undraw()
            self.data.update(pairs=pairs, order=chain_order(pairs), drawnAt=now(), drawNotes=notes)
            self._save()
            return notes

    def undraw(self):
        with self.lock:
            self._undraw()
            self._save()

    def match_for(self, ident):
        """Nur für das Handy dieser Person: wen sie beschenkt."""
        with self.lock:
            target = self.data["pairs"].get(ident)
            return self.person(target) if target else None

    def santa_of(self, ident):
        """Wer diese Person beschenkt. Nur nach der Auflösung nach außen geben."""
        with self.lock:
            return next((self.person(g) for g, r in self.data["pairs"].items() if r == ident), None)

    def stats(self):
        with self.lock:
            people = self.data["people"]
            return {"count": len(people), "seen": sum(1 for p in people if p.get("seen")),
                    "ready": sum(1 for p in people if p.get("ready")),
                    "wishes": sum(1 for p in people if p.get("wish")),
                    "houses": len({name_key(p.get("house")) for p in people if p.get("house")}),
                    "drawn": self.drawn, "drawnAt": self.data.get("drawnAt") or 0,
                    "chains": self.chain_count()}

    def chain_count(self):
        return sum(1 for row in self.reveal_pairs() if row["chainEnd"]) if self.drawn else 0

    # ---- Auflösung --------------------------------------------------------

    def start_reveal(self, step, drum, intro):
        with self.lock:
            if not self.drawn:
                return None
            self.data["reveal"] = {"id": new_id(), "started": now(), "step": step, "drum": drum, "intro": intro,
                                   "count": len(self.data["order"])}
            self._save()
            return dict(self.data["reveal"])

    def reveal(self):
        with self.lock:
            value = self.data.get("reveal")
            return dict(value) if value else None

    def stop_reveal(self):
        with self.lock:
            self.data["reveal"] = None
            self._save()

    def reveal_pairs(self):
        """Alle Paare in Kettenreihenfolge (nur für die laufende Auflösung).
        chainEnd: mit diesem Paar schließt sich ein Kreis."""
        with self.lock:
            pairs = self.data["pairs"]
            out, start = [], None
            for giver in self.data["order"]:
                start = start or giver
                g, r = self.person(giver), self.person(pairs.get(giver))
                if not (g and r):
                    continue
                end = pairs.get(giver) == start
                out.append({"giver": g["name"], "receiver": r["name"], "chainEnd": end})
                if end:
                    start = None
            return out

    # ---- Nachrichten (anonym an das Wichtelkind und zurück) ----------------

    def messages(self, receiver_id):
        with self.lock:
            return [dict(m) for m in self.data["messages"].get(receiver_id, [])]

    def add_message(self, receiver_id, by, text):
        text = clean_text(text, MSG_MAX, lines=True)
        if not text or by not in ("santa", "kid"):
            return None
        with self.lock:
            rows = self.data["messages"].setdefault(receiver_id, [])
            if len(rows) >= MSGS_PER_PERSON:
                raise ValueError("many")
            row = {"by": by, "text": text, "at": now()}
            rows.append(row)
            self._save()
            return dict(row)

    # ---- Neue Runde -------------------------------------------------------

    def archive_and_reset(self, title):
        with self.lock:
            if self.drawn:
                history = read_json(self.history_file, [])
                history = history if isinstance(history, list) else []
                names = {p["id"]: p["name"] for p in self.data["people"]}
                history.append({"title": title, "year": datetime.date.today().year, "at": now(),
                                "pairs": [[names[g], names[r]] for g, r in self.data["pairs"].items()
                                          if g in names and r in names]})
                write_json(self.history_file, history[-10:])
            keep = [{**p, "tokens": p.get("tokens", []), "seen": 0, "ready": False}
                    for p in self.data["people"]]
            self.data = self._fresh(self.data["code"])
            self.data["people"] = keep          # dieselben Leute bleiben angemeldet
            self._save()

    def clear_people(self):
        with self.lock:
            self.data = self._fresh(self.data["code"])
            self._save()

    def history(self):
        rows = read_json(self.history_file, [])
        return [{"title": r.get("title"), "year": r.get("year"), "count": len(r.get("pairs", []))}
                for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []
