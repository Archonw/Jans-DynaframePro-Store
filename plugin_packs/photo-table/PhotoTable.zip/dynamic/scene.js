/* Photo Table - die Szene.
 *
 * Viele Fotos liegen als Abzüge verstreut auf einem großen Tisch. Der ganze
 * Tisch dreht sich, mal mehr, mal weniger, mal links, mal rechts herum, um
 * einen Punkt am oder außerhalb des Bildschirmrands. Bleibt er stehen,
 * liegen andere Fotos oben.
 *
 * So funktioniert es:
 *  - Die Abzüge liegen in "Tischkoordinaten" (Welt). Die Kamera hat einen
 *    Mittelpunkt, einen Winkel und einen Zoom. Eine Drehung dreht die Kamera
 *    um einen Drehpunkt; auf dem Bildschirm dreht sich der Tisch.
 *  - Vor jeder Drehung wird der Weg der Kamera abgetastet: Wo der Tisch dort
 *    leer wäre, kommen Abzüge hin, aber nur außerhalb des gerade sichtbaren
 *    Bereichs (sonst würden sie aufploppen). Was am Ende zu sehen ist, sind
 *    neue Fotos, upright zur Kamera am Ziel; unterwegs sieht man ältere
 *    Fotos noch einmal vorbeiziehen.
 *  - Nach der Drehung verschwinden die Abzüge, die nicht mehr zu sehen sind.
 *    Ihre Texturen bleiben eine Weile für den nächsten Weg.
 *
 * Gezeichnet wird mit WebGL (ohne WebGL mit Canvas 2D), nur solange sich
 * etwas bewegt. Der Tisch ist eine nahtlose Kachel, die sich mitdreht.
 *
 * Zum Ausprobieren: ?plugin=<URL der Plugin-Seite> &lang=de|en|es &speed=2
 * &demo=1 (Fotos aus ?photos=a.jpg,b.jpg oder gemalt, ohne Plugin)
 * &look=table|linen|dark &border=mixed|print|polaroid|none &size=large|medium|small
 * &density=dense|loose &still=8 &turns=varied|small|large &dir=alternate|random|same
 * &pace=calm|slow|lively &zoom=0|1 &captions=0|1
 * &pose=still|spin (Standbild für Store-Bilder, &k=0..1) &seed=3 &nogl=1
 */
(function () {
  "use strict";

  const PLUGIN_ID = "PhotoTable";
  const params = new URLSearchParams(location.search);
  const SPEED = Math.max(0.1, Number(params.get("speed")) || 1);
  const DEMO = params.get("demo") === "1";
  const POSE = params.get("pose") || "";
  const NOGL = params.get("nogl") === "1";
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  // Über die Weboberfläche (Port 80/443, z. B. RemoteFrame über HTTPS) nur derselbe Ursprung:
  // mit DynaFrames HTTPS/Login verwirft die Firewall :8003 von außen ohne Antwort,
  // jede Anfrage dorthin hinge bis zum Zeitlimit.
  const viaWebUi = location.port === "" || location.port === "80" || location.port === "443";
  const pluginBases = params.get("plugin") ? [params.get("plugin").replace(/\/?$/, "/")]
    : viaWebUi && /^https?:$/.test(location.protocol) ? [`${location.origin}${advanced}`]
    : [...new Set([
      `${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`,
      `http://${location.hostname || "localhost"}${advanced}`
    ])];
  let baseIndex = 0;

  const TEXT = {
    de: {
      wait: "Photo Table liest die Fotos …", none: "Photo Table findet keine Fotos. Wähle auf der Plugin-Seite eine Quelle.",
      unreachable: "Photo Table antwortet nicht.", login: "Bitte zuerst im Browser beim Rahmen anmelden.",
      months: ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"]
    },
    en: {
      wait: "Photo Table is reading the photos …", none: "Photo Table finds no photos. Pick a source on the plugin page.",
      unreachable: "Photo Table is not responding.", login: "Please sign in to the frame in the browser first.",
      months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    },
    es: {
      wait: "Photo Table está leyendo las fotos …", none: "Photo Table no encuentra fotos. Elige una fuente en la página del plugin.",
      unreachable: "Photo Table no responde.", login: "Inicia sesión primero en el marco desde el navegador.",
      months: ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
    }
  };
  let lang = params.get("lang") || "en";
  const tx = (key) => (TEXT[lang] || TEXT.en)[key] ?? TEXT.en[key] ?? key;

  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const lerp = (a, b, k) => a + (b - a) * k;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms / SPEED));
  const DEG = Math.PI / 180;

  // Zufall, mit ?seed= wiederholbar (für Store-Bilder)
  let seed = Number(params.get("seed")) || 0;
  const rand = seed ? () => {
    seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  } : Math.random;
  const rnd = (a, b) => a + (b - a) * rand();

  // ------------------------------------------------------------ Plugin

  // Mit Zeitlimit: hängt die Verbindung (DynaFrame-HTTPS/Login, Plugin neu
  // gestartet), steht die Szene nicht still, sondern versucht es wieder.
  async function fetchTimed(target, ms) {
    const control = typeof AbortController === "function" ? new AbortController() : null;
    const timer = control ? setTimeout(() => control.abort(), ms) : 0;
    try {
      return await fetch(target, { cache: "no-store", credentials: "same-origin", signal: control ? control.signal : undefined });
    } finally {
      clearTimeout(timer);
    }
  }

  async function api(path) {
    let lastError = null;
    for (let i = 0; i < pluginBases.length; i += 1) {
      const base = pluginBases[(baseIndex + i) % pluginBases.length];
      try {
        const response = await fetchTimed(base + path, 12000);
        if (response.redirected && /login/i.test(response.url)) throw new Error("login");
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const body = await response.json();
        baseIndex = (baseIndex + i) % pluginBases.length;
        return body;
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error("unreachable");
  }
  const url = (path) => pluginBases[baseIndex] + path;

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = "anonymous";     // als WebGL-Textur nur mit CORS
      img.decoding = "async";
      const timer = setTimeout(() => { img.src = ""; reject(new Error("image timeout")); }, 30000);
      img.onload = () => { clearTimeout(timer); resolve(img); };
      img.onerror = () => { clearTimeout(timer); reject(new Error("image")); };
      img.src = src;
    });
  }

  function report(message) {
    if (!DEMO) api("api/report?m=" + encodeURIComponent(String(message).slice(0, 180))).catch(() => {});
  }

  // DynaFrame wartet, bis die Szene meldet, dass sie steht; sonst bricht der
  // Fernseher nach einer Frist ab ("scene readiness deadline expired").
  let readySent = false;
  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 8000);

  const note = document.getElementById("note");
  function showNote(text) {
    note.textContent = text || "";
    note.hidden = !text;
  }

  // ------------------------------------------------------------ Einstellungen

  const cfg = {
    Look: params.get("look") || "table", Border: params.get("border") || "mixed",
    PrintSize: params.get("size") || "large", Density: params.get("density") || "dense",
    StillSeconds: Number(params.get("still")) || 8, Turns: params.get("turns") || "varied",
    Direction: params.get("dir") || "alternate", Pace: params.get("pace") || "calm",
    Zoom: params.get("zoom") !== "0", Captions: params.get("captions") !== "0"
  };
  const KEYMAP = { Look: "look", Border: "border", PrintSize: "size", Density: "density", StillSeconds: "still",
                   Turns: "turns", Direction: "dir", Pace: "pace", Zoom: "zoom", Captions: "captions" };
  const PACE = { calm: 1, slow: 1.4, lively: 0.72 };
  const pace = () => PACE[cfg.Pace] || 1;
  // lange Seite eines Abzugs in Teilen der kurzen Bildschirmseite
  const SIZES = { large: 0.74, medium: 0.58, small: 0.44 };
  const sizeF = () => SIZES[cfg.PrintSize] || SIZES.large;

  // Wie die Oberflächen wirken
  const LOOKS = {
    table: { shadow: 0.62, tint: [1.0, 0.975, 0.94], bg: "#4a2f1b" },
    linen: { shadow: 0.46, tint: [1.0, 0.985, 0.96], bg: "#d6c9b2" },
    dark:  { shadow: 0.8, tint: [0.97, 0.97, 0.98], bg: "#1b1d21" }
  };
  const look = () => LOOKS[cfg.Look] || LOOKS.table;

  function applySettings(s) {
    if (!s) return;
    if (s.Language && !params.get("lang")) lang = s.Language;
    const before = cfg.Look;
    for (const key of Object.keys(cfg)) {
      if (s[key] === undefined || params.has(KEYMAP[key])) continue;
      cfg[key] = s[key];
    }
    cfg.StillSeconds = clamp(Number(cfg.StillSeconds) || 8, 2, 600);
    if (cfg.Look !== before && tileTex) {
      buildTile();
      dirty = true;
    }
    document.documentElement.lang = lang;
  }

  // ------------------------------------------------------------ Zeichenfläche

  const canvas = document.getElementById("stage");
  let W = window.innerWidth, H = window.innerHeight;
  let renderScale = 1;
  try {
    const stored = Number(localStorage.getItem("pt-scale"));
    if (stored >= 0.5 && stored <= 1) renderScale = stored;
  } catch (_) { /* kein Speicher */ }
  const dpr = () => Math.min(window.devicePixelRatio || 1, 1.5) * renderScale;

  let gl = null, ctx = null, prog = null;
  const loc = {};
  const VS = `
    attribute vec2 aPos;
    uniform vec2 uCenter, uSize, uView;
    uniform float uRot;
    varying vec2 vUV, vLocal;
    void main() {
      vec2 p = aPos * uSize;
      vLocal = p;
      float c = cos(uRot), s = sin(uRot);
      p = vec2(c * p.x - s * p.y, s * p.x + c * p.y) + uCenter;
      vec2 clip = p / uView * 2.0 - 1.0;
      gl_Position = vec4(clip.x, -clip.y, 0.0, 1.0);
      vUV = aPos + 0.5;
    }`;
  const FS = `
    #ifdef GL_FRAGMENT_PRECISION_HIGH
    precision highp float;
    #else
    precision mediump float;
    #endif
    uniform sampler2D uTex;
    uniform float uAlpha, uMode, uBlur;
    uniform vec4 uColor, uUV;
    uniform vec2 uBox;
    varying vec2 vUV, vLocal;
    void main() {
      if (uMode > 1.5) {
        // weicher Schatten eines Rechtecks: Kante je Achse weich auslaufen lassen
        float ax = smoothstep(-uBlur, uBlur, uBox.x - abs(vLocal.x));
        float ay = smoothstep(-uBlur, uBlur, uBox.y - abs(vLocal.y));
        gl_FragColor = vec4(uColor.rgb, ax * ay * uColor.a * uAlpha);
      } else if (uMode > 0.5) {
        gl_FragColor = vec4(uColor.rgb, uColor.a * uAlpha);
      } else {
        vec4 t = texture2D(uTex, vUV * uUV.xy + uUV.zw);
        gl_FragColor = vec4(t.rgb * uColor.rgb, t.a * uAlpha);
      }
    }`;

  function setupGL() {
    if (NOGL) return false;
    const opts = { alpha: false, antialias: false, premultipliedAlpha: false, preserveDrawingBuffer: !!POSE };
    try {
      gl = canvas.getContext("webgl", opts) || canvas.getContext("experimental-webgl", opts);
    } catch (_) {
      gl = null;
    }
    if (!gl) return false;
    try {
      const compile = (type, source) => {
        const shader = gl.createShader(type);
        gl.shaderSource(shader, source);
        gl.compileShader(shader);
        if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader));
        return shader;
      };
      prog = gl.createProgram();
      gl.attachShader(prog, compile(gl.VERTEX_SHADER, VS));
      gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FS));
      gl.linkProgram(prog);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
      gl.useProgram(prog);
      for (const name of ["uCenter", "uSize", "uView", "uRot", "uTex", "uAlpha", "uMode", "uBlur", "uColor", "uBox", "uUV"]) {
        loc[name] = gl.getUniformLocation(prog, name);
      }
      const buffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-0.5, -0.5, 0.5, -0.5, -0.5, 0.5, 0.5, 0.5]), gl.STATIC_DRAW);
      const aPos = gl.getAttribLocation(prog, "aPos");
      gl.enableVertexAttribArray(aPos);
      gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);
      gl.enable(gl.BLEND);
      gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
      gl.uniform1i(loc.uTex, 0);
      gl.uniform4f(loc.uUV, 1, 1, 0, 0);
      gl.activeTexture(gl.TEXTURE0);
      canvas.addEventListener("webglcontextlost", (event) => { event.preventDefault(); report("WebGL: Kontext verloren"); });
      canvas.addEventListener("webglcontextrestored", () => location.reload());
      return true;
    } catch (error) {
      report(`WebGL: ${error.message}`);
      gl = null;
      return false;
    }
  }
  if (!setupGL()) ctx = canvas.getContext("2d");

  // Ohne Mipmaps: die Abzüge erscheinen etwa in Originalgröße, so spart es ein Drittel Speicher.
  function makeTexture(source, repeat = false) {
    if (!gl) return { src: source, w: source.width, h: source.height };
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
    const wrap = repeat ? gl.REPEAT : gl.CLAMP_TO_EDGE;   // REPEAT nur mit 2er-Potenz (Kachel 1024)
    if (repeat) gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, repeat ? gl.LINEAR_MIPMAP_LINEAR : gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrap);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrap);
    return { tex, w: source.width, h: source.height };
  }
  function freeTexture(t) {
    if (t && t.tex && gl) gl.deleteTexture(t.tex);
  }

  // Ein Viereck: Textur (mode 0), Farbe (mode 1) oder weicher Schatten (mode 2)
  function quad(t, cx, cy, w, h, rot, alpha, mode = 0, color = [1, 1, 1, 1], box = null, blur = 1) {
    if (alpha <= 0.002) return;
    if (gl) {
      gl.uniform2f(loc.uCenter, cx, cy);
      gl.uniform2f(loc.uSize, w, h);
      gl.uniform1f(loc.uRot, rot);
      gl.uniform1f(loc.uAlpha, alpha);
      gl.uniform1f(loc.uMode, mode);
      gl.uniform4f(loc.uColor, color[0], color[1], color[2], color[3]);
      if (box) gl.uniform2f(loc.uBox, box[0], box[1]);
      gl.uniform1f(loc.uBlur, Math.max(0.5, blur));
      if (mode === 0 && t) gl.bindTexture(gl.TEXTURE_2D, t.tex);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      return;
    }
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(rot);
    ctx.globalAlpha = alpha;
    if (mode === 2) {
      ctx.shadowColor = `rgba(0,0,0,${color[3]})`;
      ctx.shadowBlur = blur * 1.4;
      ctx.shadowOffsetX = 10000;
      ctx.fillStyle = "#000";
      ctx.fillRect(-box[0] - 10000, -box[1], box[0] * 2, box[1] * 2);
    } else if (mode === 1) {
      ctx.fillStyle = `rgba(${color[0] * 255},${color[1] * 255},${color[2] * 255},${color[3]})`;
      ctx.fillRect(-w / 2, -h / 2, w, h);
    } else {
      ctx.drawImage(t.src, -w / 2, -h / 2, w, h);
    }
    ctx.restore();
  }

  // ------------------------------------------------------------ Kamera

  // Bildschirm = z · R(-psi) · (Welt - c) + Bildschirmmitte
  const cam = { cx: 0, cy: 0, psi: 0, z: 1 };
  let spin = null;          // laufende Drehung: { px, py, c0x, c0y, psi0, st: { d, z } }

  function currentCam() {
    if (!spin) return cam;
    const d = spin.st.d, c = Math.cos(d), s = Math.sin(d);
    const rx = spin.c0x - spin.px, ry = spin.c0y - spin.py;
    cam.cx = spin.px + rx * c - ry * s;
    cam.cy = spin.py + rx * s + ry * c;
    cam.psi = spin.psi0 + d;
    cam.z = spin.st.z;
    return cam;
  }

  function camAt(from, pivot, delta, k, zdip) {
    const d = delta * k, c = Math.cos(d), s = Math.sin(d);
    const rx = from.cx - pivot[0], ry = from.cy - pivot[1];
    return { cx: pivot[0] + rx * c - ry * s, cy: pivot[1] + rx * s + ry * c, psi: from.psi + d, z: 1 - zdip * Math.sin(Math.PI * k) };
  }

  function toScreen(x, y, c) {
    const co = Math.cos(c.psi), si = Math.sin(c.psi);
    const dx = x - c.cx, dy = y - c.cy;
    return [c.z * (dx * co + dy * si) + W / 2, c.z * (-dx * si + dy * co) + H / 2];
  }
  function toWorld(sx, sy, c) {
    const lx = (sx - W / 2) / c.z, ly = (sy - H / 2) / c.z;
    const co = Math.cos(c.psi), si = Math.sin(c.psi);
    return [c.cx + lx * co - ly * si, c.cy + lx * si + ly * co];
  }

  // ------------------------------------------------------------ Der Tisch (nahtlose Kachel)

  const TILE = 1024;
  let tileTex = null, vignetteTex = null, tilePattern = null;
  const tileWorld = () => Math.max(H, W * 0.5) * 0.95;    // so groß ist eine Kachel auf dem Tisch

  function noisePattern(g, size, strength, warm) {
    const n = document.createElement("canvas");
    n.width = n.height = size;
    const c = n.getContext("2d");
    const data = c.createImageData(size, size);
    for (let i = 0; i < data.data.length; i += 4) {
      const v = Math.random();
      data.data[i] = 255 * v;
      data.data[i + 1] = 255 * v * (warm ? 0.92 : 1);
      data.data[i + 2] = 255 * v * (warm ? 0.8 : 1);
      data.data[i + 3] = 255 * strength * Math.abs(v - 0.5) * 2;
    }
    c.putImageData(data, 0, 0);
    return g.createPattern(n, "repeat");
  }

  // Etwas an (x, y) malen, an den Kanten auch gegenüber, damit die Kachel nahtlos bleibt
  function wrapped(T, x, y, r, paint) {
    for (const dx of [-T, 0, T]) {
      for (const dy of [-T, 0, T]) {
        if (x + dx + r < 0 || x + dx - r > T || y + dy + r < 0 || y + dy - r > T) continue;
        paint(x + dx, y + dy);
      }
    }
  }

  function paintWood(g, T) {
    const planks = 4;
    const ph = T / planks;
    const tones = ["#6b4528", "#5f3c22", "#704a2b", "#5a391f", "#664226"];
    for (let i = 0; i < planks; i += 1) {
      const y0 = i * ph;
      const base = g.createLinearGradient(0, y0, 0, y0 + ph);
      const tone = tones[(i * 3 + 1) % tones.length];
      base.addColorStop(0, tone);
      base.addColorStop(0.5, tones[(i * 2) % tones.length]);
      base.addColorStop(1, tone);
      g.fillStyle = base;
      g.fillRect(0, y0, T, ph);
      // Maserung: feine, gewellte Linien; Wellen mit ganzen Perioden je Kachel
      const lines = Math.round(ph / 3.4);
      for (let k = 0; k < lines; k += 1) {
        const y = y0 + (k + Math.random()) * (ph / lines);
        const m1 = 1 + Math.floor(Math.random() * 3), m2 = 3 + Math.floor(Math.random() * 4);
        const a1 = 1 + Math.random() * 6, a2 = Math.random() * 2, p1 = Math.random() * 7, p2 = Math.random() * 7;
        g.strokeStyle = Math.random() < 0.5 ? `rgba(30,15,5,${0.06 + Math.random() * 0.16})` : `rgba(160,110,70,${0.04 + Math.random() * 0.08})`;
        g.lineWidth = 0.6 + Math.random() * 2.2;
        g.beginPath();
        for (let x = 0; x <= T; x += 16) {
          const yy = y + Math.sin((x / T) * Math.PI * 2 * m1 + p1) * a1 + Math.sin((x / T) * Math.PI * 2 * m2 + p2) * a2;
          if (x === 0) g.moveTo(x, yy); else g.lineTo(x, yy);
        }
        g.stroke();
      }
      if (Math.random() < 0.7) {
        const kx = Math.random() * T, ky = y0 + ph * (0.3 + Math.random() * 0.4), kr = ph * (0.08 + Math.random() * 0.07);
        wrapped(T, kx, ky, kr * 3.4, (x, y) => {
          const knot = g.createRadialGradient(x, y, 0, x, y, kr * 2.4);
          knot.addColorStop(0, "rgba(35,18,8,.55)");
          knot.addColorStop(0.35, "rgba(45,25,12,.25)");
          knot.addColorStop(1, "rgba(45,25,12,0)");
          g.fillStyle = knot;
          g.beginPath();
          g.ellipse(x, y, kr * 3.2, kr * 1.1, 0, 0, Math.PI * 2);
          g.fill();
        });
      }
      g.fillStyle = "rgba(20,10,4,.55)";
      g.fillRect(0, y0 + ph - 2, T, 2);
      g.fillStyle = "rgba(190,140,95,.12)";
      g.fillRect(0, y0, T, 1);
    }
    g.fillStyle = noisePattern(g, 256, 0.18, true);
    g.fillRect(0, 0, T, T);
  }

  function paintLinen(g, T) {
    g.fillStyle = "#d8ccb6";
    g.fillRect(0, 0, T, T);
    for (let x = 0; x < T; x += 2 + Math.random() * 1.6) {
      g.fillStyle = `rgba(${Math.random() < 0.5 ? "90,70,45" : "255,250,240"},${0.04 + Math.random() * 0.07})`;
      g.fillRect(x, 0, 1 + Math.random(), T);
    }
    for (let y = 0; y < T; y += 2 + Math.random() * 1.6) {
      g.fillStyle = `rgba(${Math.random() < 0.5 ? "90,70,45" : "255,250,240"},${0.04 + Math.random() * 0.07})`;
      g.fillRect(0, y, T, 1 + Math.random());
    }
    g.fillStyle = noisePattern(g, 256, 0.12, true);
    g.fillRect(0, 0, T, T);
    for (let i = 0; i < 10; i += 1) {
      const x = Math.random() * T, y = Math.random() * T, r = 90 + Math.random() * 200, dark = Math.random() < 0.5;
      wrapped(T, x, y, r, (px, py) => {
        const spot = g.createRadialGradient(px, py, 0, px, py, r);
        spot.addColorStop(0, dark ? "rgba(80,60,40,.06)" : "rgba(255,255,255,.07)");
        spot.addColorStop(1, "rgba(0,0,0,0)");
        g.fillStyle = spot;
        g.fillRect(px - r, py - r, r * 2, r * 2);
      });
    }
  }

  function paintDark(g, T) {
    g.fillStyle = "#24262b";
    g.fillRect(0, 0, T, T);
    for (let i = 0; i < 14; i += 1) {
      const x = Math.random() * T, y = Math.random() * T, r = 120 + Math.random() * 260, light = Math.random() < 0.5;
      wrapped(T, x, y, r, (px, py) => {
        const spot = g.createRadialGradient(px, py, 0, px, py, r);
        spot.addColorStop(0, light ? "rgba(255,255,255,.035)" : "rgba(0,0,0,.12)");
        spot.addColorStop(1, "rgba(0,0,0,0)");
        g.fillStyle = spot;
        g.fillRect(px - r, py - r, r * 2, r * 2);
      });
    }
    g.fillStyle = noisePattern(g, 256, 0.16, false);
    g.fillRect(0, 0, T, T);
  }

  function buildTile() {
    const c = document.createElement("canvas");
    c.width = c.height = TILE;
    const g = c.getContext("2d");
    ({ table: paintWood, linen: paintLinen, dark: paintDark }[cfg.Look] || paintWood)(g, TILE);
    freeTexture(tileTex);
    tileTex = makeTexture(c, true);
    if (!gl) tilePattern = ctx.createPattern(c, "repeat");
    document.body.style.background = look().bg;
    buildVignette();
  }

  // Licht und Vignette liegen fest über dem Bildschirm (die Lampe dreht sich nicht mit)
  function buildVignette() {
    const c = document.createElement("canvas");
    const s = Math.min(1, 960 / Math.max(W, H));
    c.width = Math.max(64, Math.round(W * s));
    c.height = Math.max(64, Math.round(H * s));
    const g = c.getContext("2d");
    g.scale(c.width / W, c.height / H);
    const dark = cfg.Look === "linen" ? "50,35,20" : "0,0,0";
    const strength = cfg.Look === "linen" ? 0.32 : cfg.Look === "dark" ? 0.6 : 0.5;
    const light = g.createRadialGradient(W * 0.28, H * 0.08, 0, W * 0.28, H * 0.08, Math.hypot(W, H) * 0.8);
    light.addColorStop(0, cfg.Look === "dark" ? "rgba(255,255,255,.05)" : "rgba(255,214,160,.13)");
    light.addColorStop(1, "rgba(255,214,160,0)");
    g.fillStyle = light;
    g.fillRect(0, 0, W, H);
    const v = g.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.38, W / 2, H / 2, Math.hypot(W, H) * 0.62);
    v.addColorStop(0, `rgba(${dark},0)`);
    v.addColorStop(1, `rgba(${dark},${strength})`);
    g.fillStyle = v;
    g.fillRect(0, 0, W, H);
    freeTexture(vignetteTex);
    vignetteTex = makeTexture(c);
  }

  function drawTable(c) {
    const S = Math.hypot(W, H) / c.z + 4;          // Quadrat, das den gedrehten Bildschirm sicher deckt
    const tw = tileWorld();
    if (gl) {
      const k = S / tw;
      const fx = c.cx / tw - k / 2, fy = c.cy / tw - k / 2;
      gl.uniform4f(loc.uUV, k, k, fx - Math.floor(fx), fy - Math.floor(fy));
      quad(tileTex, W / 2, H / 2, S * c.z, S * c.z, -c.psi, 1);
      gl.uniform4f(loc.uUV, 1, 1, 0, 0);
      return;
    }
    ctx.save();
    ctx.translate(W / 2, H / 2);
    ctx.scale(c.z, c.z);
    ctx.rotate(-c.psi);
    ctx.translate(-c.cx, -c.cy);
    if (tilePattern.setTransform) tilePattern.setTransform(new DOMMatrix().scale(tw / TILE));
    ctx.fillStyle = tilePattern;
    ctx.fillRect(c.cx - S / 2, c.cy - S / 2, S, S);
    ctx.restore();
  }

  // ------------------------------------------------------------ Abzüge malen

  const PAD = 3;   // durchsichtiger Rand: glatte Kanten ohne Kantenglättung
  const HAND = (size) => `700 ${size}px Hand, "Segoe Print", "Comic Sans MS", cursive`;

  function dateText(taken) {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(taken || "");
    if (!m) return "";
    const month = tx("months")[Number(m[2]) - 1] || "";
    return lang === "es" ? `${month} de ${m[1]}` : `${month} ${m[1]}`;
  }
  const shortPlace = (place) => String(place || "").split(",")[0].trim();

  function pickBorder() {
    if (["print", "polaroid", "none"].includes(cfg.Border)) return cfg.Border;
    return rand() < 0.55 ? "print" : "polaroid";
  }

  function gloss(g, w, h) {
    const sheen = g.createLinearGradient(0, 0, w, h);
    sheen.addColorStop(0, "rgba(255,255,255,.10)");
    sheen.addColorStop(0.35, "rgba(255,255,255,.02)");
    sheen.addColorStop(0.6, "rgba(255,255,255,0)");
    sheen.addColorStop(1, "rgba(0,0,0,.06)");
    g.fillStyle = sheen;
    g.fillRect(0, 0, w, h);
  }

  function drawPhoto(g, img, x, y, w, h) {
    let sx = 0, sy = 0, sw = img.naturalWidth || img.width, sh = img.naturalHeight || img.height;
    const want = w / h;
    if (sw / sh > want + 0.005) { const nw = sh * want; sx = (sw - nw) / 2; sw = nw; } else if (sw / sh < want - 0.005) { const nh = sw / want; sy = (sh - nh) / 2; sh = nh; }
    g.drawImage(img, sx, sy, sw, sh, x, y, w, h);
  }

  function paintPrint(img, info, border) {
    const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
    let pw = iw, ph = ih;
    let left, top, right, bottom;
    const short = Math.min(iw, ih);
    if (border === "polaroid") {
      // Sofortbild: fast quadratisch, breiter Rand unten zum Beschriften
      const ratio = clamp(iw / ih, 0.82, 1.22);
      if (iw / ih > ratio) pw = Math.round(ih * ratio); else ph = Math.round(iw / ratio);
      const side = Math.round(Math.max(pw, ph) * 0.055);
      left = right = top = side;
      bottom = Math.round(Math.max(pw, ph) * 0.2);
    } else if (border === "print") {
      left = right = top = bottom = Math.round(short * 0.05);
    } else {
      left = right = top = bottom = Math.max(2, Math.round(short * 0.006));
    }
    const w = pw + left + right, h = ph + top + bottom;
    const c = document.createElement("canvas");
    c.width = w + PAD * 2;
    c.height = h + PAD * 2;
    const g = c.getContext("2d");
    g.translate(PAD, PAD);
    const paper = g.createLinearGradient(0, 0, w, h);
    paper.addColorStop(0, border === "polaroid" ? "#fbfaf6" : "#faf8f3");
    paper.addColorStop(1, border === "polaroid" ? "#ecebe5" : "#efece5");
    g.fillStyle = paper;
    g.fillRect(0, 0, w, h);
    drawPhoto(g, img, left, top, pw, ph);
    if (border === "polaroid") {
      g.strokeStyle = "rgba(0,0,0,.18)";
      g.lineWidth = Math.max(1, left * 0.04);
      g.strokeRect(left, top, pw, ph);
      const text = cfg.Captions ? [dateText(info.taken), shortPlace(info.place)].filter(Boolean).join(" · ") : "";
      if (text) {
        let size = bottom * 0.42;
        g.font = HAND(size);
        while (g.measureText(text).width > w * 0.86 && size > 8) {
          size *= 0.92;
          g.font = HAND(size);
        }
        g.fillStyle = "rgba(32,42,78,.86)";
        g.textAlign = "center";
        g.textBaseline = "middle";
        g.save();
        g.translate(w / 2, top + ph + bottom * 0.52);
        g.rotate((rand() - 0.5) * 0.04);
        g.fillText(text, 0, 0);
        g.restore();
      }
    } else if (border === "none") {
      g.strokeStyle = "rgba(255,255,255,.35)";
      g.lineWidth = 1;
      g.strokeRect(0.5, 0.5, w - 1, h - 1);
    } else {
      g.strokeStyle = "rgba(0,0,0,.08)";
      g.lineWidth = 1;
      g.strokeRect(left - 0.5, top - 0.5, pw + 1, ph + 1);
    }
    gloss(g, w, h);
    return { canvas: c, aspect: w / h };
  }

  // ------------------------------------------------------------ Fotos und Abzüge

  // photo: ein gemaltes Foto als Textur. Mehrere Abzüge können dasselbe Foto zeigen
  // (nur unterwegs, wenn gerade nichts anderes da ist).
  let photos = [];          // schon gezeigte Fotos (Texturen)
  let fresh = [];           // geladene, noch nie gezeigte Fotos
  let prints = [];          // unten -> oben: { photo, x, y, rot, w, h, scale, lift, alpha }
  let dirty = true;

  const maxTextures = () => ({ large: 34, medium: 44, small: 56 }[cfg.PrintSize] || 34);

  function makePhoto(entry) {
    const border = pickBorder();
    const painted = paintPrint(entry.img, entry.info, border);
    const tex = makeTexture(painted.canvas);
    if (gl) { painted.canvas.width = 1; painted.canvas.height = 1; }   // Speicher frei, die Textur hat das Bild
    return { tex, aspect: painted.aspect, info: entry.info, refs: 0, seen: 0, sizeJitter: rnd(0.9, 1.08) };
  }

  function printSize(photo) {
    const long = Math.min(W, H) * sizeF() * photo.sizeJitter;
    return photo.aspect >= 1 ? [long, long / photo.aspect] : [long * photo.aspect, long];
  }

  function addPrint(photo, x, y, rot, extra = {}) {
    if (!photos.includes(photo)) photos.push(photo);
    photo.refs += 1;
    const [w, h] = printSize(photo);
    const p = Object.assign({ photo, x, y, rot, w, h, scale: 1, lift: 0, alpha: 1 }, extra);
    prints.push(p);
    dirty = true;
    return p;
  }

  function removePrint(p) {
    prints = prints.filter((q) => q !== p);
    p.photo.refs -= 1;
    dirty = true;
  }

  // Zu viele Texturen: ungenutzte, am längsten nicht gesehene freigeben
  function trimPhotos() {
    const limit = maxTextures();
    if (photos.length + fresh.length <= limit) return;
    const idle = photos.filter((ph) => ph.refs <= 0).sort((a, b) => a.seen - b.seen);
    while (photos.length + fresh.length > limit && idle.length) {
      const ph = idle.shift();
      photos = photos.filter((q) => q !== ph);
      freeTexture(ph.tex);
    }
  }

  // Liegt Weltpunkt (wx, wy) auf Abzug p? k > 1: großzügig (lockere Dichte)
  function onPrint(p, wx, wy, k) {
    const dx = wx - p.x, dy = wy - p.y;
    const co = Math.cos(p.rot), si = Math.sin(p.rot);
    const lx = dx * co + dy * si, ly = -dx * si + dy * co;
    return Math.abs(lx) <= (p.w / 2) * k && Math.abs(ly) <= (p.h / 2) * k;
  }

  // Ecken eines Abzugs auf dem Bildschirm (bei Kamera c)
  function screenBox(p, c, grow = 1) {
    const co = Math.cos(p.rot), si = Math.sin(p.rot);
    const hw = (p.w / 2) * grow, hh = (p.h / 2) * grow;
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const [ax, ay] of [[-hw, -hh], [hw, -hh], [hw, hh], [-hw, hh]]) {
      const [sx, sy] = toScreen(p.x + ax * co - ay * si, p.y + ax * si + ay * co, c);
      x0 = Math.min(x0, sx); y0 = Math.min(y0, sy); x1 = Math.max(x1, sx); y1 = Math.max(y1, sy);
    }
    return [x0, y0, x1, y1];
  }
  function inView(p, c, margin = 0, grow = 1) {
    const [x0, y0, x1, y1] = screenBox(p, c, grow);
    return x1 > -margin && y1 > -margin && x0 < W + margin && y0 < H + margin;
  }

  const maxTilt = () => (cfg.Density === "loose" ? 16 : 13) * DEG;

  // ------------------------------------------------------------ Den Weg belegen

  // Rasterpunkte über dem Bildschirm (in Bildschirm-Koordinaten)
  function gridPoints() {
    const unit = Math.min(W, H);
    const step = unit * (cfg.Density === "loose" ? 0.2 : 0.115) * (sizeF() / 0.74);
    const m = unit * 0.03;
    const pts = [];
    for (let y = -m; y <= H + m + 0.1; y += step) {
      for (let x = -m; x <= W + m + 0.1; x += step) pts.push([x, y]);
    }
    for (let i = pts.length - 1; i > 0; i -= 1) {
      const j = Math.floor(rand() * (i + 1));
      [pts[i], pts[j]] = [pts[j], pts[i]];
    }
    return pts;
  }

  // Ein Foto für einen neuen Abzug. final: der Abzug ist nach der Drehung zu sehen.
  function takePhoto(final) {
    if (final && fresh.length) return fresh.shift();
    const idle = photos.filter((ph) => ph.refs <= 0).sort((a, b) => a.seen - b.seen);
    if (idle.length) return idle[Math.floor(rand() * Math.ceil(idle.length / 2))];
    if (fresh.length && (final || fresh.length > 2)) return fresh.shift();
    if (photos.length) return photos[Math.floor(rand() * photos.length)];
    return fresh.shift() || null;
  }

  // Weg einer Drehung von Kamera "from" um "pivot" um "delta" belegen.
  // Neue Abzüge nur dort, wo man sie gerade nicht sieht.
  function planPath(from, pivot, delta, zdip) {
    const dense = cfg.Density !== "loose";
    const k = dense ? 0.94 : 1.4;
    const steps = Math.max(1, Math.ceil(Math.abs(delta) / (7 * DEG)));
    const target = camAt(from, pivot, delta, 1, 0);
    const grid = gridPoints();
    let added = 0;
    for (let i = 1; i <= steps; i += 1) {
      const kk = i / steps;
      const c = camAt(from, pivot, delta, kk, zdip);
      const last = i === steps;
      for (const [sx, sy] of grid) {
        const [wx, wy] = toWorld(sx, sy, c);
        // Am Ziel zählen nur Abzüge, die dort einigermaßen gerade liegen
        const covered = prints.some((p) => onPrint(p, wx, wy, k));
        if (covered) continue;
        const peek = { w: 1, h: 1 };
        // Platz und Größe erst mit dem Foto bekannt; zuerst prüfen, ob die Stelle gerade sichtbar ist
        const jx = rnd(-0.12, 0.12) * Math.min(W, H) * sizeF(), jy = rnd(-0.12, 0.12) * Math.min(W, H) * sizeF();
        const x = wx + jx, y = wy + jy;
        const rot = anyAngle();
        const probeLong = Math.min(W, H) * sizeF() * 1.1;
        Object.assign(peek, { x, y, rot, w: probeLong, h: probeLong });
        if (inView(peek, from, 2)) continue;
        const final = inView(peek, target, -Math.min(W, H) * 0.02);
        const photo = takePhoto(final);
        if (!photo) return added;
        addPrint(photo, x, y, rot);
        added += 1;
      }
    }
    return added;
  }

  function angleDiff(a, b) {
    let d = (a - b) % (Math.PI * 2);
    if (d > Math.PI) d -= Math.PI * 2;
    if (d < -Math.PI) d += Math.PI * 2;
    return d;
  }

  // Nach einer Drehung: was man nicht mehr sieht, kommt weg; Gesehenes merken
  function afterSpin() {
    const c = currentCam();
    const t = performance.now();
    for (const p of prints.slice()) {
      if (inView(p, c, 4, 1.05)) p.photo.seen = t;
      else removePrint(p);
    }
    trimPhotos();
  }

  // ------------------------------------------------------------ Bewegung

  const easeInOut = (k) => (k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2);
  const easeSine = (k) => 0.5 - 0.5 * Math.cos(Math.PI * k);
  const easeOut = (k) => 1 - Math.pow(1 - k, 3);
  const easeLand = (k) => (k < 0.4 ? 0 : easeInOut((k - 0.4) / 0.6));
  const linear = (k) => k;

  let tweens = [];
  let clockMs = 0, lastNow = 0;

  function tween(obj, to, seconds, ease = easeInOut, delay = 0) {
    return new Promise((resolve) => {
      tweens.push({ obj, to, from: null, start: clockMs + delay * 1000, dur: Math.max(1, seconds * 1000), ease, resolve });
    });
  }

  function stepTweens() {
    const done = [];
    for (const t of tweens) {
      if (clockMs < t.start) continue;
      if (!t.from) {
        t.from = {};
        for (const key of Object.keys(t.to)) t.from[key] = t.obj[key];
      }
      const k = clamp((clockMs - t.start) / t.dur);
      const e = t.ease(k);
      for (const key of Object.keys(t.to)) t.obj[key] = lerp(t.from[key], t.to[key], e);
      if (k >= 1) done.push(t);
    }
    if (done.length) {
      tweens = tweens.filter((t) => !done.includes(t));
      for (const t of done) t.resolve();
    }
  }

  // ------------------------------------------------------------ Zeichnen

  function drawPrint(p, c) {
    const a = p.alpha;
    if (a <= 0.002) return;
    const [sx, sy] = toScreen(p.x, p.y, c);
    const s = c.z * p.scale;
    const w = p.w * s, h = p.h * s;
    const r = Math.hypot(w, h) / 2 + H * 0.05;
    if (sx + r < 0 || sy + r < 0 || sx - r > W || sy - r > H) return;
    const rot = p.rot - c.psi;
    const L = look();
    const lift = p.lift;
    // Schatten: flach eng und dunkel, angehoben weit, weich und versetzt (Licht steht fest)
    const off = H * (0.004 + lift * 0.03);
    const blur = H * (0.005 + lift * 0.035) + Math.min(w, h) * 0.012;
    quad(null, sx + off * 0.45, sy + off, w + blur * 4, h + blur * 4, rot, a, 2,
         [0, 0, 0, L.shadow * (1 - lift * 0.35)], [w / 2, h / 2], blur);
    if (lift < 0.15) {
      quad(null, sx + 0.6, sy + 1.2, w + 6, h + 6, rot, a * (1 - lift / 0.15), 2, [0, 0, 0, L.shadow * 0.5], [w / 2, h / 2], 1.6);
    }
    const tint = L.tint;
    const lit = 1 + lift * 0.03;
    const t = p.photo.tex;
    const tw = w * (t.w / (t.w - PAD * 2)), th = h * (t.h / (t.h - PAD * 2));
    quad(t, sx, sy, tw, th, rot, a, 0, [tint[0] * lit, tint[1] * lit, tint[2] * lit, 1]);
  }

  function draw() {
    const width = canvas.width, height = canvas.height;
    const bg = look().bg;
    const c = currentCam();
    if (gl) {
      gl.viewport(0, 0, width, height);
      gl.uniform2f(loc.uView, W, H);
      gl.clearColor(parseInt(bg.slice(1, 3), 16) / 255, parseInt(bg.slice(3, 5), 16) / 255, parseInt(bg.slice(5, 7), 16) / 255, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
    } else {
      ctx.setTransform(width / W, 0, 0, height / H, 0, 0);
      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, W, H);
    }
    if (tileTex) drawTable(c);
    for (const p of prints) drawPrint(p, c);
    if (vignetteTex) quad(vignetteTex, W / 2, H / 2, W, H, 0, 1);
  }

  // Bildrate beobachten: wird es zu langsam, weniger Pixel
  const perf = { frames: 0, since: 0, slow: 0 };
  function watchPerf(now) {
    if (!tweens.length || document.hidden) { perf.frames = 0; perf.since = now; return; }
    perf.frames += 1;
    if (now - perf.since < 3000) return;
    const fps = (perf.frames * 1000) / (now - perf.since);
    perf.frames = 0;
    perf.since = now;
    if (fps < 24) perf.slow += 1; else perf.slow = 0;
    if (perf.slow >= 2 && renderScale > 0.6) {
      perf.slow = 0;
      renderScale = Math.max(0.6, renderScale * 0.8);
      try { localStorage.setItem("pt-scale", String(renderScale)); } catch (_) { /* kein Speicher */ }
      report(`Bildrate ${fps.toFixed(0)} fps: weniger Pixel (${Math.round(renderScale * 100)} %)`);
      resizeCanvas();
    }
  }

  function frame(now) {
    const dt = lastNow ? Math.min(100, now - lastNow) : 16;
    lastNow = now;
    clockMs += dt * SPEED;
    const moving = tweens.length > 0;
    if (moving) stepTweens();
    if (moving || dirty) {
      draw();
      dirty = false;
    }
    watchPerf(now);
    requestAnimationFrame(frame);
  }

  function resizeCanvas() {
    canvas.width = Math.max(2, Math.round(W * dpr()));
    canvas.height = Math.max(2, Math.round(H * dpr()));
    dirty = true;
  }

  let resizeTimer = 0;
  window.addEventListener("resize", () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      const f = Math.min(window.innerWidth, window.innerHeight) / Math.min(W, H);
      W = window.innerWidth;
      H = window.innerHeight;
      for (const p of prints) { p.x *= f; p.y *= f; p.w *= f; p.h *= f; }
      cam.cx *= f; cam.cy *= f;
      resizeCanvas();
      buildVignette();
    }, 300);
  });

  // ------------------------------------------------------------ Fotos holen

  function requestSize() {
    const ratio = Math.min(window.devicePixelRatio || 1, 1.5);
    const long = Math.min(1400, Math.round(Math.min(W, H) * sizeF() * 1.1 * ratio));
    return [long, long];
  }

  async function fetchNext() {
    if (DEMO) return demoPhoto();
    const [w, h] = requestSize();
    const info = await api(`api/next?w=${w}&h=${h}`);
    if (!info || !info.success) {
      throw new Error(info && info.error === "empty" ? (info.busy ? "wait" : "none") : "photo");
    }
    const img = await loadImage(url(`api/photo?id=${info.id}`));
    try { await img.decode(); } catch (_) { /* schon dekodiert */ }
    return { img, info };
  }

  async function poll() {
    if (DEMO) return { count: 1 };
    try {
      const data = await api("api/scene");
      applySettings(data.settings);
      if (!data.count) showNote(data.busy || data.status === "" ? tx("wait") : tx("none"));
      else if ([tx("wait"), tx("none"), tx("unreachable"), tx("login")].includes(note.textContent)) showNote("");
      return data;
    } catch (error) {
      if (!prints.length) showNote(error.message === "login" ? tx("login") : tx("unreachable"));
      ready();
      return null;
    }
  }

  async function pollLoop() {
    while (true) {
      await sleep(20000);
      await poll();
    }
  }

  // So viele neue Fotos braucht ein voller Bildschirm etwa
  function wantFresh() {
    const long = Math.min(W, H) * sizeF();
    const area = long * long * 0.72;
    const cover = cfg.Density === "loose" ? 0.9 : 1.7;
    return clamp(Math.ceil((W * H) / area * cover), 4, 18);
  }

  let loading = 0;
  let failures = 0;
  let waiters = [];

  function wake() {
    const list = waiters;
    waiters = [];
    list.forEach((resolve) => resolve());
  }

  // Im Hintergrund nachladen, bis genug neue Fotos bereitliegen (zwei auf einmal)
  function topUp() {
    const target = wantFresh() + 2;
    const inUse = photos.filter((ph) => ph.refs > 0).length;
    while (loading < 2 && fresh.length + loading < target && inUse + fresh.length + loading < maxTextures() + 6) {
      loading += 1;
      fetchNext().then((entry) => {
        fresh.push(makePhoto(entry));
        trimPhotos();
        failures = 0;
        if (note.textContent && note.textContent !== tx("none")) showNote("");
      }).catch((error) => {
        failures += 1;
        if (!prints.length) {
          if (error.message === "wait" || error.message === "none") showNote(tx(error.message));
          else if (failures > 1) showNote(error.message === "login" ? tx("login") : tx("unreachable"));
        }
        ready();
      }).finally(() => {
        loading -= 1;
        wake();
        const pause = failures ? Math.min(15000, 2000 * failures) : 0;
        if (pause) setTimeout(topUp, pause / SPEED); else topUp();
      });
    }
  }

  // Warten, bis count neue Fotos da sind oder die Zeit um ist
  async function waitFresh(count, maxMs) {
    const until = Date.now() + maxMs / SPEED;
    topUp();
    while (fresh.length < count && Date.now() < until) {
      await Promise.race([new Promise((r) => waiters.push(r)), sleep(1500)]);
      topUp();
    }
    return fresh.length;
  }

  // ------------------------------------------------------------ Regie

  // Am Anfang fallen die Abzüge einer nach dem anderen auf den Tisch
  async function firstLayout() {
    const dense = cfg.Density !== "loose";
    const k = dense ? 0.94 : 1.4;
    const grid = gridPoints();
    const drops = [];
    for (const [sx, sy] of grid) {
      const [wx, wy] = toWorld(sx, sy, cam);
      if (prints.some((p) => onPrint(p, wx, wy, k))) continue;
      while (!fresh.length) {
        await waitFresh(1, prints.length ? 30000 : 6 * 3600 * 1000);
        if (!fresh.length && prints.length) break;
      }
      const photo = fresh.shift();
      if (!photo) break;
      const jx = rnd(-0.12, 0.12) * Math.min(W, H) * sizeF(), jy = rnd(-0.12, 0.12) * Math.min(W, H) * sizeF();
      const p = addPrint(photo, wx + jx, wy + jy, anyAngle(), { alpha: 0, lift: 1, scale: 1.1 });
      const d = 1.5 * pace();
      drops.push(Promise.all([
        tween(p, { alpha: 1 }, d * 0.35, linear),
        tween(p, { scale: 1 }, d, easeInOut),
        tween(p, { lift: 0 }, d, easeLand)
      ]));
      topUp();
      await sleep(380 * pace());
    }
    // zuletzt das große Foto obenauf in der Mitte
    if (!fresh.length) await waitFresh(1, 20000);
    const hero = fresh.length ? addHero({ x: cam.cx + rnd(-0.03, 0.03) * W, y: cam.cy + rnd(-0.03, 0.03) * H, tilt: heroTilt() }) : null;
    if (hero) {
      Object.assign(hero, { alpha: 0, lift: 1, scale: 1.1 });
      const d = 1.8 * pace();
      drops.push(tween(hero, { alpha: 1 }, d * 0.35, linear), tween(hero, { scale: 1 }, d, easeInOut), tween(hero, { lift: 0 }, d, easeLand));
    }
    await Promise.all(drops);
    afterSpin();
  }

  let direction = rand() < 0.5 ? 1 : -1;
  let lastPivotAngle = null;

  function pickTurn() {
    // Weit genug, dass am Ziel ein ganz neuer Teil des Tisches zu sehen ist (Jan, 17.11.2026)
    const [lo, hi] = { small: [60, 110], large: [140, 260], varied: [75, 220] }[cfg.Turns] || [75, 220];
    const u = rand();
    const angle = lerp(lo, hi, u) * DEG;
    if (cfg.Direction === "random") direction = rand() < 0.5 ? 1 : -1;
    else if (cfg.Direction === "same") direction = 1;
    const delta = angle * direction;
    if (cfg.Direction === "alternate") direction = -direction;
    return delta;
  }

  // Drehpunkt außerhalb des Bildes: der Bildschirm wandert über den Tisch,
  // am Ziel ist nichts mehr vom alten Ausschnitt zu sehen.
  function pickPivot(far) {
    const hd = Math.hypot(W, H) / 2;
    const dist = hd * rnd(0.75, 1.25) * far;
    let a = rand() * Math.PI * 2;
    if (lastPivotAngle !== null && Math.abs(angleDiff(a, lastPivotAngle)) < 40 * DEG) a += Math.PI * 0.6;
    lastPivotAngle = a;
    return toWorld(W / 2 + Math.cos(a) * dist, H / 2 + Math.sin(a) * dist, cam);
  }

  // Das Foto, auf dem die Drehung endet: groß, mitten im Bild, ganz oben
  // Fotos darunter liegen kreuz und quer, das obere mal gerader, mal schiefer (Jan, 17.11.2026)
  const anyAngle = () => rand() * Math.PI * 2;
  const heroTilt = () => (rand() < 0.5 ? -1 : 1) * Math.pow(rand(), 0.8) * 42 * DEG;

  function heroProbe(target) {
    const unit = Math.min(W, H);
    const long = unit * Math.min(0.86, sizeF() * 1.18);
    return { x: target.cx + rnd(-0.04, 0.04) * W, y: target.cy + rnd(-0.04, 0.04) * H,
             tilt: heroTilt(), w: long, h: long, base: target.psi, get rot() { return this.base + this.tilt; } };
  }
  function addHero(probe) {
    const photo = fresh.shift() || takePhoto(true);
    if (!photo) return null;
    const unit = Math.min(W, H);
    const long = unit * Math.min(0.86, sizeF() * 1.18);
    const base = probe.base !== undefined ? probe.base : cam.psi;
    const p = addPrint(photo, probe.x, probe.y, base + probe.tilt);
    const [w, h] = photo.aspect >= 1 ? [long, long / photo.aspect] : [long * photo.aspect, long];
    // hochkant auf Querformat-Bildschirm (und umgekehrt) nicht größer als der Bildschirm
    const co = Math.abs(Math.cos(probe.tilt)), si = Math.abs(Math.sin(probe.tilt));
    const fit = Math.min(1, (W * 0.94) / (w * co + h * si), (H * 0.94) / (w * si + h * co));
    p.w = w * fit; p.h = h * fit; p.hero = true;
    return p;
  }

  async function turnTable() {
    const from = { cx: cam.cx, cy: cam.cy, psi: cam.psi, z: 1 };
    let delta = 0, pivot = null, probe = null;
    // so lange wählen, bis der ganze Zielausschnitt gerade unsichtbar ist
    for (let tries = 0; tries < 30; tries += 1) {
      delta = pickTurn();
      pivot = pickPivot(1 + tries * 0.05);
      const target = camAt(from, pivot, delta, 1, 0);
      probe = heroProbe(target);
      const view = { x: target.cx, y: target.cy, rot: target.psi, w: W * 1.02, h: H * 1.02 };
      if (!inView(view, from, 0) || tries === 29) break;
      if (cfg.Direction === "alternate") direction = -direction;   // Richtung nicht verbrauchen
    }
    const zdip = cfg.Zoom ? Math.min(0.24, 0.08 + (Math.abs(delta) / (220 * DEG)) * 0.14) : 0;
    const hero = inView(probe, from, 2) ? null : addHero(probe);
    planPath(from, pivot, delta, zdip);
    if (hero) { prints = prints.filter((q) => q !== hero); prints.push(hero); }
    const T = (1.6 + Math.abs(delta) / (52 * DEG)) * pace();
    spin = { px: pivot[0], py: pivot[1], c0x: from.cx, c0y: from.cy, psi0: from.psi, st: { d: 0, z: 1 } };
    const over = Math.sign(delta) * Math.min(2.2 * DEG, Math.abs(delta) * 0.03);
    const jobs = [
      tween(spin.st, { d: delta + over }, T, easeInOut).then(() => tween(spin.st, { d: delta }, 0.9 * pace(), easeSine))
    ];
    if (zdip) jobs.push(tween(spin.st, { z: 1 - zdip }, T * 0.5, easeSine).then(() => tween(spin.st, { z: 1 }, T * 0.5, easeSine)));
    await Promise.all(jobs);
    currentCam();
    spin = null;
    cam.z = 1;
    afterSpin();
    dirty = true;
  }

  async function director() {
    topUp();
    await firstLayout();
    while (true) {
      await sleep(cfg.StillSeconds * 1000);
      await waitFresh(wantFresh(), 25000);
      await turnTable();
      topUp();
    }
  }

  // ------------------------------------------------------------ Ohne Plugin (?demo=1)

  let demoIndex = 0;
  const demoList = (params.get("photos") || "").split(",").filter(Boolean);
  function paintDemo(i) {
    const c = document.createElement("canvas");
    c.width = i % 3 === 1 ? 600 : 900; c.height = i % 3 === 1 ? 820 : 600;
    const g = c.getContext("2d");
    const sky = g.createLinearGradient(0, 0, 0, c.height);
    const themes = [["#1d3b72", "#f08a4b", "#ffd27a"], ["#7fb7e6", "#cfe8f7", "#f7f3e8"], ["#2b1844", "#8e3b6b", "#f2a65a"], ["#3c7a5a", "#a9d18e", "#f0f4d8"], ["#5a2a1a", "#d4683a", "#f6d38a"]];
    const th = themes[i % themes.length];
    sky.addColorStop(0, th[0]); sky.addColorStop(0.6, th[1]); sky.addColorStop(1, th[2]);
    g.fillStyle = sky; g.fillRect(0, 0, c.width, c.height);
    g.fillStyle = "rgba(255,240,200,.9)";
    g.beginPath(); g.arc(150 + 180 * (i % 3), 190, 55, 0, Math.PI * 2); g.fill();
    g.fillStyle = "#2a2f3a";
    g.beginPath(); g.moveTo(0, c.height * 0.75);
    for (let x = 0; x <= c.width; x += 60) g.lineTo(x, c.height * 0.65 + 45 * Math.sin(x / 110 + i));
    g.lineTo(c.width, c.height); g.lineTo(0, c.height); g.fill();
    g.fillStyle = "rgba(255,255,255,.85)";
    g.font = "bold 90px sans-serif";
    g.fillText(String(i + 1), 30, 100);
    return c.toDataURL("image/jpeg", 0.9);
  }
  async function demoPhoto() {
    const i = demoIndex;
    demoIndex += 1;
    if (!POSE) await sleep(150);
    const src = demoList.length ? demoList[i % demoList.length] : paintDemo(i);
    const img = await loadImage(src);
    try { await img.decode(); } catch (_) { /* schon dekodiert */ }
    const places = ["Lisbon, Portugal", "Lake Garda, Italy", "Rome, Italy", "", "Gran Canaria, Spain", "Stockholm, Sweden", "Edinburgh, Scotland"];
    return { img, info: { taken: `20${18 + (i % 7)}-0${1 + (i % 9)}-1${i % 9}T12:00:00`, place: places[i % places.length], rating: i % 6 } };
  }

  // ------------------------------------------------------------ Standbild (?pose=) für Store-Bilder

  async function posed() {
    const need = 60;
    for (let i = 0; i < need; i += 1) fresh.push(makePhoto(await fetchNext()));
    const k0 = cfg.Density !== "loose" ? 0.94 : 1.4;
    for (const [sx, sy] of gridPoints()) {
      const [wx, wy] = toWorld(sx, sy, cam);
      if (prints.some((p) => onPrint(p, wx, wy, k0))) continue;
      const jx = rnd(-0.12, 0.12) * Math.min(W, H) * sizeF(), jy = rnd(-0.12, 0.12) * Math.min(W, H) * sizeF();
      addPrint(fresh.shift(), wx + jx, wy + jy, anyAngle());
    }
    addHero({ x: cam.cx, y: cam.cy, tilt: Number(params.get("tilt") || 14) * DEG });
    afterSpin();
    if (POSE === "spin") {
      const k = clamp(Number(params.get("k")) || 0.5, 0, 1);
      const delta = (Number(params.get("turn")) || 110) * DEG;
      const pivot = toWorld(W * 0.5 + Math.hypot(W, H) * 0.55, H * 0.15, cam);
      const zdip = cfg.Zoom ? 0.15 : 0;
      planPath({ ...cam }, pivot, delta, zdip);
      spin = { px: pivot[0], py: pivot[1], c0x: cam.cx, c0y: cam.cy, psi0: cam.psi, st: { d: delta * easeInOut(k), z: 1 - zdip * Math.sin(Math.PI * k) } };
    }
    draw();
    ready();
    document.body.dataset.shot = "ready";
  }

  // ------------------------------------------------------------ Start

  async function start() {
    resizeCanvas();
    if (!DEMO) await poll();
    try { await document.fonts.load(HAND(40)); } catch (_) { /* ohne Handschrift */ }
    buildTile();
    draw();
    ready();        // der Tisch steht, die Abzüge kommen gleich
    if (POSE) {
      posed();
      return;
    }
    requestAnimationFrame(frame);
    pollLoop();
    director();
  }
  start();
})();
