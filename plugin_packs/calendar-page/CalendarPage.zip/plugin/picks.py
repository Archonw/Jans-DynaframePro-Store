"""Welche Fotos auf das Kalenderblatt kommen.

Für einen Monat (Jahr Y, Monat M) zählen Fotos aus demselben Monat in
früheren Jahren. Je Jahr gewinnt das beste Foto (Sterne, Favorit,
Querformat, mit Kamera aufgenommen); der Zufall ist je Monat fest, damit das
Blatt nicht bei jedem Einlesen andere Fotos zeigt. Gibt es weniger Jahre als
Plätze, kommen zweitbeste Fotos aus anderen Tagen dazu.
"""

import hashlib


def _jitter(seed, key):
    return int(hashlib.sha1(f"{seed}|{key}".encode("utf-8")).hexdigest()[:8], 16) / 0xFFFFFFFF


def score(row, seed, prefer_landscape=True):
    value = 0.0
    stars = row.get("stars") or 0
    value += stars * 10
    if row.get("fav"):
        value += 15
    w, h = row.get("w") or 0, row.get("h") or 0
    if w and h and prefer_landscape:
        ratio = w / h
        value += 6 if ratio >= 1.2 else (2 if ratio >= 0.95 else 0)
    if row.get("cam"):
        value += 3
    value += _jitter(seed, row["k"]) * 8
    return value


def pick(rows, year, month, count, excluded=(), prefer_landscape=True, same_year=False):
    """Bis zu `count` Fotos (Zeilen) aus dem Monat in früheren Jahren, nach Jahr sortiert."""
    prefix = f"-{month:02d}-"
    seed = f"{year}-{month:02d}"
    excluded = set(excluded or ())
    by_year = {}
    for row in rows:
        taken = row.get("t") or ""
        if len(taken) < 10 or taken[4:8] != prefix:
            continue
        y = int(taken[:4])
        if y > year or (y == year and not same_year) or y < 1900:
            continue
        if row.get("pid") in excluded:
            continue
        by_year.setdefault(y, []).append(row)
    if not by_year:
        return []
    ranked = {y: sorted(found, key=lambda r: -score(r, seed, prefer_landscape)) for y, found in by_year.items()}
    # Erst je Jahr das beste; die Jahre mit den besten Fotos gewinnen, neuere bei Gleichstand.
    firsts = sorted(ranked, key=lambda y: (-score(ranked[y][0], seed, prefer_landscape), -y))
    chosen = [(y, ranked[y][0]) for y in firsts[:count]]
    # Zu wenig Jahre: weitere Fotos von anderen Tagen der Jahre dazu.
    if len(chosen) < count:
        used_days = {r["t"][:10] for _y, r in chosen}
        extra = []
        for y, found in ranked.items():
            for row in found[1:]:
                if row["t"][:10] not in used_days:
                    extra.append((score(row, seed, prefer_landscape), y, row))
        extra.sort(key=lambda e: -e[0])
        for _s, y, row in extra:
            if len(chosen) >= count:
                break
            if row["t"][:10] in used_days:
                continue
            used_days.add(row["t"][:10])
            chosen.append((y, row))
    chosen.sort(key=lambda e: e[1]["t"])
    return [row for _y, row in chosen]


def month_stats(rows, month):
    """Wie viele Fotos und Jahre es für diesen Monat gibt."""
    prefix = f"-{month:02d}-"
    years = {}
    for row in rows:
        taken = row.get("t") or ""
        if len(taken) >= 10 and taken[4:8] == prefix:
            years[taken[:4]] = years.get(taken[:4], 0) + 1
    return {"count": sum(years.values()), "years": len(years)}
