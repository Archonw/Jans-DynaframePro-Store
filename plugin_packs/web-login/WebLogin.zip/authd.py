#!/usr/bin/env python3
"""Web Login - the small login service in front of the DynaFrame web page.

nginx (port 80) asks this service about every request (auth_request to
/auth) and shows its login page under /dfr-login/. It runs as a system
service of its own (dfr-weblogin.service, as the frame user), from a copy in
/usr/local/lib/dfr-weblogin, so the web page stays protected even while the
plugin restarts, and so it can still switch the protection off when the
plugin folder is gone.

Standard library only. Settings come from the plugin's data/authd.json,
written by plugin.py and read again whenever it changes:

  passwordHash   pbkdf2_sha256$<iterations>$<salt b64>$<hash b64>
  secret         hex key that signs the login cookie
  sessionMinutes how long a login lasts without being used (renewed while
                 the web page is in use); older settings: sessionDays
  trusted        IPs / networks that never see the login (Home Assistant ...)
  language       de | en | es, for the login page when the browser asks for
                 none of them
  frameName      shown on the login page
  pluginDir      the plugin folder; gone or disabled = switch everything off
  helper         the root helper used for that

Usage: authd.py --config /path/to/authd.json [--port 8097]
"""

import argparse
import base64
import hashlib
import hmac
import html
import ipaddress
import json
import os
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oidc  # noqa: E402

COOKIE = "dfr_login"
DEFAULT_PORT = 8097
MAX_FORM = 16 * 1024
FAIL_FREE = 5            # wrong passwords before an IP has to wait
FAIL_BASE_WAIT = 30      # seconds, doubled with every further miss
FAIL_MAX_WAIT = 15 * 60
WATCH_EVERY = 30         # seconds between plugin checks
WATCH_STRIKES = 3        # checks in a row before switching off

TEXTS = {
    "title": {"de": "Anmelden", "en": "Sign in", "es": "Iniciar sesión"},
    "lede": {"de": "Die Weboberfläche dieses Rahmens ist geschützt.",
             "en": "This frame's web page is protected.",
             "es": "La página web de este marco está protegida."},
    "password": {"de": "Passwort", "en": "Password", "es": "Contraseña"},
    "submit": {"de": "Anmelden", "en": "Sign in", "es": "Entrar"},
    "wrong": {"de": "Falsches Passwort.", "en": "Wrong password.", "es": "Contraseña incorrecta."},
    "wait": {"de": "Zu viele Versuche. Bitte warte {s} Sekunden.",
             "en": "Too many tries. Please wait {s} seconds.",
             "es": "Demasiados intentos. Espera {s} segundos."},
    "notset": {"de": "Es ist noch kein Passwort gesetzt.", "en": "No password has been set yet.",
               "es": "Aún no se ha definido ninguna contraseña."},
    "out": {"de": "Du bist abgemeldet.", "en": "You are signed out.", "es": "Has cerrado la sesión."},
    "sso": {"de": "Mit {label} anmelden", "en": "Sign in with {label}", "es": "Entrar con {label}"},
    "or": {"de": "oder mit Passwort", "en": "or with the password", "es": "o con la contraseña"},
    "denied": {"de": "Das Konto {user} darf sich hier nicht anmelden.", "en": "The account {user} may not sign in here.",
               "es": "La cuenta {user} no puede iniciar sesión aquí."},
    "failed": {"de": "Anmeldung über {label} hat nicht geklappt: {reason}",
               "en": "Signing in with {label} did not work: {reason}",
               "es": "No se pudo entrar con {label}: {reason}"},
}
LANGS = ("de", "en", "es")


def is_loopback(ip):
    try:
        address = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return address.is_loopback or bool(getattr(address, "ipv4_mapped", None) and address.ipv4_mapped.is_loopback)


def log(message):
    print(f"[weblogin] {message}", flush=True)


# --------------------------------------------------------------------------
# Settings
# --------------------------------------------------------------------------

class Config:
    def __init__(self, path):
        self.path = Path(path)
        self._mtime = None
        self.data = {}
        self.networks = []
        self.lock = threading.Lock()
        self.reload()

    def reload(self):
        try:
            mtime = self.path.stat().st_mtime_ns
        except OSError:
            return
        if mtime == self._mtime:
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            log(f"cannot read {self.path}: {exc}")
            return
        networks = []
        for entry in data.get("trusted") or []:
            try:
                networks.append(ipaddress.ip_network(str(entry).strip(), strict=False))
            except ValueError:
                pass
        with self.lock:
            self.data = data if isinstance(data, dict) else {}
            self.networks = networks
            self._mtime = mtime

    def get(self, key, default=None):
        with self.lock:
            return self.data.get(key, default)

    def trusted(self, ip):
        try:
            address = ipaddress.ip_address(ip)
        except ValueError:
            return False
        if getattr(address, "ipv4_mapped", None):
            address = address.ipv4_mapped
        if address.is_loopback:
            return True
        with self.lock:
            return any(address in net for net in self.networks)


# --------------------------------------------------------------------------
# Passwords and the login cookie
# --------------------------------------------------------------------------

def check_password(password, stored):
    try:
        scheme, rounds, salt, digest = str(stored).split("$")
        if scheme != "pbkdf2_sha256":
            return False
        expected = base64.b64decode(digest)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), base64.b64decode(salt), int(rounds))
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(actual, expected)


def _b64(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _unb64(text):
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def password_version(config):
    # Changing the password ends every login made with the old one.
    return hashlib.sha256(str(config.get("passwordHash") or "").encode()).hexdigest()[:12]


def session_seconds(config):
    minutes = config.get("sessionMinutes")
    if minutes is None:
        minutes = int(config.get("sessionDays") or 30) * 1440
    try:
        minutes = int(minutes)
    except (TypeError, ValueError):
        minutes = 30 * 1440
    return max(5, min(365 * 1440, minutes)) * 60


def make_cookie(config, now=None):
    now = now or time.time()
    lifetime = session_seconds(config)
    body = _b64(json.dumps({"e": int(now + lifetime), "v": password_version(config)},
                           separators=(",", ":")).encode())
    key = bytes.fromhex(str(config.get("secret") or ""))
    sig = _b64(hmac.new(key, body.encode(), hashlib.sha256).digest())
    return f"{body}.{sig}", lifetime


def cookie_expiry(config, value, now=None):
    """When a valid login cookie runs out, or 0 if it is not valid."""
    if not value or "." not in value:
        return 0
    secret = str(config.get("secret") or "")
    if not secret:
        return 0
    body, sig = value.rsplit(".", 1)
    try:
        key = bytes.fromhex(secret)
        expected = _b64(hmac.new(key, body.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(expected, sig):
            return 0
        payload = json.loads(_unb64(body))
    except (ValueError, TypeError):
        return 0
    expiry = payload.get("e", 0)
    if payload.get("v") != password_version(config) or expiry <= (now or time.time()):
        return 0
    # A shorter time set later counts at once.
    return min(expiry, (now or time.time()) + session_seconds(config))


def cookie_valid(config, value, now=None):
    return cookie_expiry(config, value, now) > 0


def api_key_from(headers):
    auth = (headers.get("Authorization") or "").strip()
    if auth[:7].lower() == "bearer ":
        return auth[7:].strip()
    return (headers.get("X-DynaFrame-Key") or "").strip()


def find_key(config, key):
    """The stored entry for an API key, compared by its SHA-256 hash."""
    if not key or len(key) > 200:
        return None
    digest = hashlib.sha256(key.encode("utf-8")).hexdigest()
    found = None
    for entry in config.get("apiKeys") or []:
        if isinstance(entry, dict) and hmac.compare_digest(str(entry.get("hash") or ""), digest):
            found = entry
    return found


def read_cookie(header):
    for part in (header or "").split(";"):
        name, _, value = part.strip().partition("=")
        if name == COOKIE:
            return value
    return ""


# --------------------------------------------------------------------------
# Wrong passwords
# --------------------------------------------------------------------------

class Throttle:
    def __init__(self):
        self.lock = threading.Lock()
        self.misses = {}   # ip -> (count, blocked_until)

    def wait(self, ip):
        with self.lock:
            _count, until = self.misses.get(ip, (0, 0))
        return max(0, int(until - time.time() + 0.999))

    def miss(self, ip):
        with self.lock:
            count, _until = self.misses.get(ip, (0, 0))
            count += 1
            until = 0
            if count >= FAIL_FREE:
                until = time.time() + min(FAIL_MAX_WAIT, FAIL_BASE_WAIT * 2 ** (count - FAIL_FREE))
            self.misses[ip] = (count, until)
            if len(self.misses) > 1000:
                self.misses.pop(next(iter(self.misses)))

    def ok(self, ip):
        with self.lock:
            self.misses.pop(ip, None)


# --------------------------------------------------------------------------
# What was turned away (shown on the plugin page, so a device like Home
# Assistant can be added to the trusted list with one tap)
# --------------------------------------------------------------------------

class Refused:
    def __init__(self, size=30):
        self.lock = threading.Lock()
        self.rows = {}
        self.size = size

    def add(self, ip, path, agent):
        with self.lock:
            row = self.rows.pop(ip, {"ip": ip, "count": 0})
            row.update(count=row["count"] + 1, last=int(time.time()), path=path[:200], agent=agent[:200])
            self.rows[ip] = row
            while len(self.rows) > self.size:
                self.rows.pop(next(iter(self.rows)))

    def list(self):
        with self.lock:
            return sorted(self.rows.values(), key=lambda r: r["last"], reverse=True)


# --------------------------------------------------------------------------
# The login page
# --------------------------------------------------------------------------

def pick_language(config, accept):
    for part in (accept or "").split(","):
        code = part.split(";")[0].strip().lower()[:2]
        if code in LANGS:
            return code
    fallback = str(config.get("language") or "en")
    return fallback if fallback in LANGS else "en"


def safe_target(target):
    target = (target or "").strip()
    if not target.startswith("/") or target.startswith("//") or "\\" in target or target.startswith("/dfr-login"):
        return "/"
    return target


def password_login(config):
    return config.get("passwordLogin", True) is not False or not oidc.enabled(config)


def login_page(config, lang, target, message="", kind="bad"):
    t = {key: row.get(lang, row["en"]) for key, row in TEXTS.items()}
    name = html.escape(str(config.get("frameName") or "DynaFrame"))
    note = f'<p class="note {kind}">{html.escape(message)}</p>' if message else ""
    disabled = "" if config.get("passwordHash") else " disabled"
    if not config.get("passwordHash") and not message:
        note = f'<p class="note bad">{html.escape(t["notset"])}</p>'
    sso = ""
    if oidc.enabled(config):
        label = html.escape(str(oidc.settings(config).get("label") or "SSO"))
        link = "/dfr-login/oidc/start?rd=" + quote(target, safe="")
        sso = f'<a class="sso" href="{html.escape(link)}">{t["sso"].format(label=label)}</a>'
        if password_login(config):
            sso += f'<p class="or">{t["or"]}</p>'
    pw = "" if not password_login(config) else f"""<label>{t['password']}
    <input type="password" name="password" autocomplete="current-password"{'' if sso else ' autofocus'} required{disabled}>
  </label>
  <input type="hidden" name="rd" value="{html.escape(target)}">
  <button type="submit"{disabled}>{t['submit']}</button>"""
    return f"""<!doctype html>
<html lang="{lang}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>{t['title']} · {name}</title>
<style>
:root {{ color-scheme: dark; }}
* {{ box-sizing: border-box; }}
body {{ margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px 16px;
  background: #0e1116; color: #e8edf3;
  font: 16px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }}
form {{ width: 100%; max-width: 360px; background: #161b22; border: 1px solid #2a323d;
  border-radius: 14px; padding: 28px 24px; display: grid; gap: 14px; }}
.frame {{ margin: 0; color: #98a4b3; font-size: 12px; letter-spacing: .09em; text-transform: uppercase; }}
h1 {{ margin: 0; font-size: 24px; }}
p {{ margin: 0; color: #98a4b3; font-size: 14px; }}
label {{ display: grid; gap: 6px; font-size: 13px; color: #98a4b3; }}
input {{ font: inherit; padding: 10px 12px; border-radius: 8px; border: 1px solid #2a323d;
  background: #1c232c; color: #e8edf3; }}
input:focus {{ outline: 2px solid #4c9aff; outline-offset: 1px; }}
button {{ font: inherit; font-weight: 600; padding: 10px 14px; border-radius: 8px; border: 0;
  background: #4c9aff; color: #06121f; cursor: pointer; }}
button:disabled {{ opacity: .45; cursor: not-allowed; }}
.note.bad {{ color: #f85149; }}
.note.ok {{ color: #3fb950; }}
.sso {{ display: block; text-align: center; font-weight: 600; padding: 10px 14px; border-radius: 8px;
  background: #4c9aff; color: #06121f; text-decoration: none; }}
.sso + .or + label {{ margin-top: 2px; }}
.or {{ text-align: center; font-size: 13px; }}
</style>
</head>
<body>
<form method="post" action="/dfr-login/">
  <p class="frame">{name}</p>
  <h1>{t['title']}</h1>
  <p>{t['lede']}</p>
  {note}
  {sso}
  {pw}
</form>
</body>
</html>"""


# --------------------------------------------------------------------------
# HTTP
# --------------------------------------------------------------------------

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "dfr-weblogin"
    sys_version = ""

    def log_message(self, *_args):
        pass

    # nginx passes the browser's address; direct callers are local.
    def client_ip(self):
        ip = (self.headers.get("X-Real-IP") or self.client_address[0]).strip()
        forwarded = (self.headers.get("X-Forwarded-For") or "").strip()
        # A proxy on the frame itself (an HTTPS add-on, say) makes every
        # browser look local; then the address it forwards is the real one.
        if forwarded and is_loopback(ip):
            return forwarded.split(",")[-1].strip() or ip
        return ip

    def secure(self):
        return (self.headers.get("X-Forwarded-Proto") or "").lower() == "https"

    def host(self):
        host = (self.headers.get("Host") or "").strip()
        return host if host and all(c.isalnum() or c in ".-:[]" for c in host) else ""

    def https_only(self, config):
        """With HTTPS on, browsers sign in over HTTPS only."""
        https = config.get("https") if isinstance(config.get("https"), dict) else {}
        return bool(config.get("active") and https.get("enabled")) and not self.secure() and self.host()

    def to_https(self, path):
        host = self.host()
        host = host[:host.index("]") + 1] if host.startswith("[") else host.split(":")[0]
        return self.send(302, headers={"Location": f"https://{host}{path}"})

    def lang(self, config):
        return pick_language(config, self.headers.get("Accept-Language"))

    def cookie_named(self, name):
        for part in (self.headers.get("Cookie") or "").split(";"):
            key, _, value = part.strip().partition("=")
            if key == name:
                return value
        return ""

    def send(self, status, body=b"", content_type="text/html; charset=utf-8", headers=None):
        self.send_response(status)
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        if body or status not in (204, 304):
            self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        if body and self.command != "HEAD":
            self.wfile.write(body)

    def cookie_header(self, value, max_age):
        flags = "; Secure" if self.secure() else ""
        return f"{COOKIE}={value}; Path=/; Max-Age={max_age}; HttpOnly; SameSite=Lax{flags}"

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        config = self.server.config
        config.reload()
        url = urlparse(self.path)
        path = url.path
        if path == "/auth":
            return self.auth(config)
        if path == "/health":
            return self.send(200, b"ok", "text/plain")
        if path == "/status":
            return self.status(config)
        if path == "/dfr-login/oidc/start":
            return self.oidc_start(config, url)
        if path == "/dfr-login/oidc/callback":
            return self.oidc_callback(config, url)
        if path in ("/dfr-login", "/dfr-login/"):
            if self.https_only(config):
                return self.to_https(self.path)
            # rd is passed raw by nginx ($request_uri), so take everything after it.
            query = url.query
            target = query.split("rd=", 1)[1] if "rd=" in query else "/"
            lang = pick_language(config, self.headers.get("Accept-Language"))
            if cookie_valid(config, read_cookie(self.headers.get("Cookie"))):
                return self.send(302, headers={"Location": safe_target(target)})
            return self.send(200, login_page(config, lang, safe_target(target)).encode("utf-8"))
        if path == "/dfr-login/logout":
            lang = pick_language(config, self.headers.get("Accept-Language"))
            body = login_page(config, lang, "/", TEXTS["out"].get(lang, TEXTS["out"]["en"]), "ok").encode("utf-8")
            return self.send(200, body, headers={"Set-Cookie": self.cookie_header("", 0)})
        return self.send(404, b"not found", "text/plain")

    def do_POST(self):
        config = self.server.config
        config.reload()
        if urlparse(self.path).path not in ("/dfr-login", "/dfr-login/"):
            return self.send(404, b"not found", "text/plain")
        try:
            length = min(int(self.headers.get("Content-Length") or 0), MAX_FORM)
        except ValueError:
            length = 0
        form = parse_qs(self.rfile.read(length).decode("utf-8", "replace")) if length else {}
        password = (form.get("password") or [""])[0]
        target = safe_target((form.get("rd") or ["/"])[0])
        ip = self.client_ip()
        lang = pick_language(config, self.headers.get("Accept-Language"))
        if self.https_only(config) or not password_login(config):
            return self.send(303, headers={"Location": "/dfr-login/?rd=" + target})
        throttle = self.server.throttle
        wait = throttle.wait(ip)
        if wait:
            text = TEXTS["wait"][lang].format(s=wait)
            return self.send(429, login_page(config, lang, target, text).encode("utf-8"),
                             headers={"Retry-After": str(wait)})
        stored = config.get("passwordHash")
        if stored and password and check_password(password, stored):
            throttle.ok(ip)
            value, max_age = make_cookie(config)
            log(f"login from {ip}")
            return self.send(303, headers={"Location": target, "Set-Cookie": self.cookie_header(value, max_age)})
        throttle.miss(ip)
        log(f"wrong password from {ip}")
        return self.send(401, login_page(config, lang, target, TEXTS["wrong"][lang]).encode("utf-8"))

    def oidc_start(self, config, url):
        if not oidc.enabled(config):
            return self.send(302, headers={"Location": "/dfr-login/"})
        if self.https_only(config):
            return self.to_https(self.path)
        query = parse_qs(url.query)
        target = safe_target((query.get("rd") or ["/"])[0])
        scheme = "https" if self.secure() else "http"
        redirect = f"{scheme}://{self.host()}/dfr-login/oidc/callback"
        o = oidc.settings(config)
        try:
            state, location = self.server.provider.start(o, redirect, target)
        except oidc.OidcError as exc:
            lang = self.lang(config)
            text = TEXTS["failed"][lang].format(label=o.get("label") or "SSO", reason=exc)
            log(f"oidc start failed: {exc}")
            return self.send(502, login_page(config, lang, target, text).encode("utf-8"))
        flags = "; Secure" if self.secure() else ""
        cookie = f"dfr_oidc={state}; Path=/dfr-login/; Max-Age=600; HttpOnly; SameSite=Lax{flags}"
        return self.send(302, headers={"Location": location, "Set-Cookie": cookie})

    def oidc_callback(self, config, url):
        query = parse_qs(url.query)
        lang = self.lang(config)
        o = oidc.settings(config)
        label = o.get("label") or "SSO"
        state = (query.get("state") or [""])[0]
        clear = "dfr_oidc=; Path=/dfr-login/; Max-Age=0; HttpOnly; SameSite=Lax"
        try:
            if not oidc.enabled(config):
                raise oidc.OidcError("OIDC is switched off")
            if query.get("error"):
                raise oidc.OidcError((query.get("error_description") or query.get("error"))[0])
            if not state or not hmac.compare_digest(state, self.cookie_named("dfr_oidc")):
                raise oidc.OidcError("sign-in was started in another browser; please try again")
            claims, target = self.server.provider.finish(o, state, (query.get("code") or [""])[0])
        except oidc.OidcError as exc:
            log(f"oidc sign-in failed: {exc}")
            text = TEXTS["failed"][lang].format(label=label, reason=exc)
            return self.send(401, login_page(config, lang, "/", text).encode("utf-8"), headers={"Set-Cookie": clear})
        user = oidc.who(claims)
        if not oidc.allowed(o, claims):
            log(f"oidc: {user} is not on the allowed list")
            text = TEXTS["denied"][lang].format(user=user)
            return self.send(403, login_page(config, lang, "/", text).encode("utf-8"), headers={"Set-Cookie": clear})
        value, max_age = make_cookie(config)
        log(f"login from {self.client_ip()} as {user} ({label})")
        self.send_response(303)
        self.send_header("Location", target)
        self.send_header("Set-Cookie", self.cookie_header(value, max_age))
        self.send_header("Set-Cookie", clear)
        self.send_header("Content-Length", "0")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        return None

    def auth(self, config):
        ip = self.client_ip()
        if config.trusted(ip):
            return self.send(204)
        key = api_key_from(self.headers)
        if key:
            entry = find_key(config, key)
            if entry and (self.secure() or config.get("keysHttpsOnly") is False):
                self.server.key_use[entry.get("id")] = {"last": int(time.time()), "ip": ip}
                return self.send(204)
            why = "API key over plain http" if entry else "unknown API key"
            self.server.refused.add(ip, f"{self.headers.get('X-Original-URI') or ''} ({why})",
                                    self.headers.get("User-Agent") or "")
            return self.send(401)
        expiry = cookie_expiry(config, read_cookie(self.headers.get("Cookie")))
        if expiry:
            # Renew the login while the page is in use, once half of it is
            # gone; nginx hands the cookie on to the browser.
            if expiry - time.time() < session_seconds(config) / 2:
                value, max_age = make_cookie(config)
                return self.send(204, headers={"Set-Cookie": self.cookie_header(value, max_age)})
            return self.send(204)
        self.server.refused.add(ip, self.headers.get("X-Original-URI") or "",
                                self.headers.get("User-Agent") or "")
        return self.send(401)

    def status(self, config):
        if self.headers.get("X-Real-IP"):   # only for the plugin, never through nginx
            return self.send(404, b"not found", "text/plain")
        payload = {"ok": True, "since": int(self.server.started), "refused": self.server.refused.list(),
                   "keyUse": dict(self.server.key_use),
                   "passwordSet": bool(config.get("passwordHash"))}
        return self.send(200, json.dumps(payload).encode("utf-8"), "application/json")


# --------------------------------------------------------------------------
# Switch everything off when the plugin is disabled or removed
# --------------------------------------------------------------------------

def plugin_gone(config):
    folder = config.get("pluginDir")
    if not folder:
        return False
    manifest = Path(folder) / "manifest.json"
    if not Path(folder).is_dir() or not manifest.is_file():
        return True
    try:
        enabled = json.loads(manifest.read_text(encoding="utf-8")).get("Enabled", True)
    except (OSError, ValueError):
        return False   # half-written during an update: ask again later
    return enabled is False


LIB = Path("/usr/local/lib/dfr-weblogin")
NGINX_SOURCE = Path("/etc/nginx/sites-available/dynaframe")
NGINX_LINK = Path("/etc/nginx/sites-enabled/dynaframe")
NGINX_OURS = Path("/etc/nginx/dfr-weblogin/site.conf")
NGINX_HASH = Path("/etc/nginx/dfr-weblogin/source.sha256")


def root_call(verb):
    script = LIB / "weblogin_root.py"
    try:
        result = subprocess.run(["sudo", "-n", "/usr/bin/python3", "-I", str(script), verb],
                                capture_output=True, text=True, timeout=180)
        log(f"{verb}: {(result.stdout or result.stderr).strip()[:300]}")
    except (OSError, subprocess.TimeoutExpired) as exc:
        log(f"{verb} failed: {exc}")


def nginx_drifted(config):
    """DynaFrame rewrote its site or put its own link back (every update does)."""
    if not (config.get("active") and config.get("passwordHash")):
        return False
    try:
        if os.readlink(NGINX_LINK) != str(NGINX_OURS):
            return True
        stored = NGINX_HASH.read_text().strip()
        return stored != hashlib.sha256(NGINX_SOURCE.read_bytes()).hexdigest()
    except OSError:
        return True


def drift_state():
    try:
        link = os.readlink(NGINX_LINK)
    except OSError:
        link = ""
    try:
        digest = hashlib.sha256(NGINX_SOURCE.read_bytes()).hexdigest()
    except OSError:
        digest = ""
    return link, digest


def watch(config):
    time.sleep(5)
    root_call("ensure")          # after a reboot the firewall table is gone
    strikes = 0
    last_try = None
    while True:
        time.sleep(WATCH_EVERY)
        config.reload()
        strikes = strikes + 1 if plugin_gone(config) else 0
        if strikes >= WATCH_STRIKES:
            log("plugin disabled or removed: switching the login off")
            root_call("off")
            os._exit(0)
        if strikes == 0 and nginx_drifted(config):
            seen = drift_state()
            # Try once per new state, so a site nginx will not take is not
            # retried (and logged by sudo) every half minute.
            if seen != last_try:
                log("DynaFrame changed its nginx site: adding the login again")
                root_call("ensure")
                last_try = seen


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--no-watch", action="store_true")
    args = parser.parse_args()
    config = Config(args.config)
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    server.daemon_threads = True
    server.config = config
    server.throttle = Throttle()
    server.refused = Refused()
    server.provider = oidc.Provider()
    server.key_use = {}
    server.started = time.time()
    if not args.no_watch:
        threading.Thread(target=watch, args=(config,), daemon=True).start()
    log(f"listening on 127.0.0.1:{args.port}")
    server.serve_forever()


if __name__ == "__main__":
    sys.exit(main())
