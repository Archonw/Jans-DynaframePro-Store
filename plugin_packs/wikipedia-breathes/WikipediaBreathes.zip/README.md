# Wikipedia Breathes

Watch Wikipedia breathe: every change to any Wikipedia worldwide, live, as a
point of light on a world map.

## What it shows

- **Every change as a light.** The Wikimedia EventStreams send every edit to
  every Wikipedia as it happens, many per second. Each one lights up where its
  language is spoken: German in Germany, Austria and Switzerland, English in
  the US, the UK, India, Australia and more, Spanish in Spain and Latin
  America. (This is the language area, not where the editor is.)
- **Size = amount of text.** A typo fix is a tiny spark, a rewritten section a
  big glow.
- **Red when something was removed**: text taken out or a page deleted.
- **Golden ring for new articles**, a ring as well for very big changes.
- **Breathing language areas.** Busy languages glow softly and pulse slowly.
- **Ticker** "Being edited now: …" with article names, language and bytes
  (articles only, no bots, big changes and new articles first).
- **Side panel**: changes per minute, the "breath" (changes per second over the
  last 5 minutes), text added and removed per minute, new articles and deleted
  pages, the busiest languages.
- Map area: whole world, Europe, Americas, Asia, Africa and Middle East.
  Landscape and portrait.

## Settings (plugin page)

Map area, bots (show / faint / leave out), all pages or articles only, points
of light per second at most (10/20/40/80), how long a point keeps glowing,
ticker, side panel, language labels, language (German, English, Spanish), and
the card "A playlist for it".

## How it works

- The plugin reads `https://stream.wikimedia.org/v2/stream/recentchange`
  (Server-Sent Events) **only while the scene is on screen** (and for one
  minute after "Test the live stream"). Around the clock the stream would be
  several gigabytes a day. Events from Wikidata, Commons etc. are dropped
  before parsing; it keeps Wikipedia edits, new pages and page deletions.
- Every second the scene asks for the new changes. If there are more than the
  allowed points per second, the plugin keeps the big ones, new articles and
  deletions and thins out the rest. Every change is still counted.
- The scene replays the changes in their real rhythm (about one second late)
  and draws them with Canvas 2D from pre-rendered glow sprites, 30 frames per
  second; the map is drawn once.
- **Pi-hole / ad blockers:** allow `stream.wikimedia.org`.

## Credits

Data: Wikimedia EventStreams (recentchange). Coastlines and borders: Natural
Earth. Wikipedia is a trademark of the Wikimedia Foundation; this plugin is
not affiliated with or endorsed by the Wikimedia Foundation.
