#!/usr/bin/env python3
"""Solar System Live - der Plugin-Teil des Pakets.

Die Szene "solar-system-live" zeigt das Sonnensystem mit den Planeten an ihrem
echten Ort von heute (die Szene rechnet die Orte selbst mit Astronomy Engine),
mit Monden, Raumsonden und Kometen. Die Kamera fliegt von Planet zu Planet.

Dieses Plugin
- rechnet die Himmelsereignisse der nächsten Monate (Finsternisse, Oppositionen,
  Konjunktionen, Meteorströme …) für den eingestellten Ort (events.py),
- holt einmal am Tag die Orte der Raumsonden von JPL Horizons und hell werdende
  Kometen aus der JPL Small-Body Database (beides frei, ohne Schlüssel),
- gibt alles der Szene (/api/scene), pflegt die Playlist „Solar System Live“
- und legt auf Wunsch ein Ereignis (z. B. eine Mondfinsternis) über die laufende
  Playlist (Takeover).

Kein LAN-Port: Szene und Seite laufen über die DynaFrame-Weboberfläche.
"""

import json
import os
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

try:
    # Räumt nach einem Takeover auf, wenn DynaFrame das nicht tut (siehe dort).
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None

import events as sky_events  # noqa: E402
import own_playlist  # noqa: E402
import sources  # noqa: E402
import texts  # noqa: E402

plugin = create_plugin()

PLUGIN_ID = "SolarSystemLive"
SCENE_ID = "solar-system-live"        # id in scene.dynamic - nie ändern
PLAYLIST_NAME = "Solar System Live"   # in allen Sprachen gleich (englische Namen, Jans Regel 12.11.2026)
DISPLAY_NAME = "Solar System Live"
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"
CONNECT_TIMEOUT = 10
GEOCODE_URL = os.environ.get("SSL_GEOCODE_URL", "https://geocoding-api.open-meteo.com/v1/search")
EVENT_DAYS = 400
EVENTS_EVERY = 6 * 3600
FETCH_EVERY = 24 * 3600
OBJECTS = json.loads((PLUGIN_DIR / "sky_objects.json").read_text(encoding="utf-8"))
def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def log(text, level="info"):
    plugin.log(text, level=level)


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        log(f"Konnte {path.name} nicht lesen: {exc}", "warning")
        return default


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"



# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

EVENT_TYPES = {
    "EvEclipses": ("lunar-eclipse", "solar-eclipse", "transit"),
    "EvPlanets": ("opposition", "conjunction", "elongation"),
    "EvMoon": ("supermoon",),
    "EvMeteors": ("meteors",),
    "EvSeasons": ("season",),
    "EvComets": ("comet",),
}
SCHEMA = {
    "Language":     {"kind": "choice", "default": "de", "choices": texts.LANGUAGES},
    # Was die Szene zeigt
    "ShowOverview": {"kind": "bool", "default": True},
    "ShowSun":      {"kind": "bool", "default": True},
    "ShowInner":    {"kind": "bool", "default": True},
    "ShowOuter":    {"kind": "bool", "default": True},
    "ShowDwarf":    {"kind": "bool", "default": True},
    "ShowProbes":   {"kind": "bool", "default": True},
    "ShowComets":   {"kind": "bool", "default": True},
    "StopSeconds":  {"kind": "int", "default": 30, "min": 10, "max": 300},
    "Labels":       {"kind": "bool", "default": True},
    "Panel":        {"kind": "bool", "default": True},
    "Orbits":       {"kind": "bool", "default": True},
    "Belts":        {"kind": "bool", "default": True},
    "Blur":         {"kind": "choice", "default": "normal", "choices": ("off", "light", "normal", "strong")},
    "Quality":      {"kind": "choice", "default": "auto", "choices": ("auto", "pi4", "pi5", "high")},
    # Ort
    "PlaceName":    {"kind": "name", "default": ""},
    "Lat":          {"kind": "coord", "default": None, "min": -90, "max": 90},
    "Lon":          {"kind": "coord", "default": None, "min": -180, "max": 180},
    # Ereignisse
    **{name: {"kind": "bool", "default": name not in ("EvSeasons",)} for name in EVENT_TYPES},
    "Banner":       {"kind": "bool", "default": True},
    "Preview":      {"kind": "bool", "default": True},
    "LeadDays":     {"kind": "choice", "default": "7", "choices": ("1", "3", "7", "14", "30")},
    "Takeover":     {"kind": "choice", "default": "off", "choices": ("off", "eclipses", "big")},
    "TakeoverMinutes": {"kind": "choice", "default": "10", "choices": ("5", "10", "20", "30", "60")},
    "WakeScreen":   {"kind": "bool", "default": False},
    # Online-Quellen
    "FetchProbes":  {"kind": "bool", "default": True},
    "FetchComets":  {"kind": "bool", "default": True},
    # Playlist
    "PlaylistSeconds": {"kind": "int", "default": 300, "min": 30, "max": 86400},
    "MakePlaylist": {"kind": "bool", "default": False},
}
SCENE_SETTINGS = ("Language", "ShowOverview", "ShowSun", "ShowInner", "ShowOuter", "ShowDwarf", "ShowProbes",
                  "ShowComets", "StopSeconds", "Labels", "Panel", "Orbits", "Belts", "Blur", "Quality", "PlaceName",
                  "Lat", "Lon", "Banner", "Preview")
EVENT_SETTINGS = ("Lat", "Lon")
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()
def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "name":
        return re.sub(r"[\x00-\x1f]", " ", str(raw or "")).strip()[:80]
    if kind == "coord":
        if raw is None or str(raw).strip() == "":
            return None
        try:
            number = float(str(raw).replace(",", "."))
        except ValueError:
            return spec["default"]
        return round(number, 4) if spec["min"] <= number <= spec["max"] else spec["default"]
    value = str(raw if raw is not None else "").strip()
    return value if value in spec["choices"] else spec["default"]



def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    values = {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}
    values["LeadDays"] = int(values["LeadDays"])
    return values
def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


def has_place(values=None):
    values = values or settings()
    return values["Lat"] is not None and values["Lon"] is not None



def borrow_place():
    """Kein Ort eingetragen? Dann den Ort eines anderen Plugins übernehmen (Satellite Swarm & Co.)."""
    if has_place():
        return
    plugins_dir = PLUGIN_DIR.parent
    for name in ("SatelliteSwarm", "HallOfRecords", "ComicDay", "MoodyFrame", "PendlerCockpit"):
        stored = read_json(plugins_dir / name / "data" / "settings.json", {})
        if not isinstance(stored, dict):
            continue
        lat, lon = stored.get("Lat"), stored.get("Lon")
        try:
            lat, lon = float(lat), float(lon)
        except (TypeError, ValueError):
            continue
        if -90 <= lat <= 90 and -180 <= lon <= 180:
            save_settings({"Lat": lat, "Lon": lon, "PlaceName": stored.get("PlaceName") or ""})
            log(f"Ort von {name} übernommen.")
            return

# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=120):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "at": 0.0}


def find_scene():
    if _scene["dbId"] is not None and now() - _scene["at"] < 600:
        return {"id": _scene["dbId"]}
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}", read_timeout=15)
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], at=now())
        return row
    _scene.update(dbId=None, at=0.0)
    return None



# --------------------------------------------------------------------------
# Online-Quellen: Raumsonden (JPL Horizons) und Kometen (JPL SBDB)
# --------------------------------------------------------------------------

PROBES_FILE = DATA_DIR / "probes.json"
COMETS_FILE = DATA_DIR / "comets.json"
_stop = threading.Event()
_wake_fetch = threading.Event()
_online = {
    "probes": {},
    "comets": [],
    "conn": {"horizons": {"ok": None, "at": 0, "error": ""}, "sbdb": {"ok": None, "at": 0, "error": ""},
             "geocoding": {"ok": None, "at": 0, "error": ""}},
    "busy": "",
    "force": False,
}


def user_agent():
    return f"DynaFrame-SolarSystemLive/{version()} (+https://github.com/Archonw/Jans-DynaframePro-Store)"


def load_online_cache():
    data = read_json(PROBES_FILE, {})
    if isinstance(data, dict) and isinstance(data.get("probes"), dict):
        _online["probes"] = data["probes"]
        _online["conn"]["horizons"].update(ok=True, at=data.get("at", 0))
    data = read_json(COMETS_FILE, {})
    if isinstance(data, dict) and isinstance(data.get("comets"), list):
        _online["comets"] = data["comets"]
        _online["conn"]["sbdb"].update(ok=True, at=data.get("at", 0))


def fetch_online():
    values = settings()
    if values["FetchProbes"]:
        _online["busy"] = "probes"
        try:
            found, error = sources.fetch_probes(OBJECTS["probes"], user_agent(), log)
            if found:
                _online["probes"] = found
                write_json(PROBES_FILE, {"at": now(), "probes": found})
                _online["conn"]["horizons"].update(ok=True, at=now(), error="", count=len(found))
                log(f"Horizons: {len(found)} Raumsonden.")
            else:
                _online["conn"]["horizons"].update(ok=False, at=now(), error=error or "keine Daten")
        except Exception as exc:  # noqa: BLE001
            _online["conn"]["horizons"].update(ok=False, at=now(), error=str(exc)[:200])
            log(f"Horizons: {exc}", "warning")
    if values["FetchComets"]:
        _online["busy"] = "comets"
        try:
            found = sources.fetch_comets(user_agent())
            _online["comets"] = found
            write_json(COMETS_FILE, {"at": now(), "comets": found})
            _online["conn"]["sbdb"].update(ok=True, at=now(), error="", count=len(found))
            log(f"Kometen: {len(found)} von der JPL Small-Body Database.")
        except Exception as exc:  # noqa: BLE001
            _online["conn"]["sbdb"].update(ok=False, at=now(), error=f"{exc.__class__.__name__}: {exc}"[:200])
            log(f"Kometen: {exc}", "warning")
    _online["busy"] = ""
    _wake_events.set()


def fetch_loop():
    load_online_cache()
    last = max(_online["conn"]["horizons"]["at"] or 0, _online["conn"]["sbdb"]["at"] or 0)
    failures = 0
    while not _stop.is_set():
        due = now() - last >= (FETCH_EVERY if not failures else min(6 * 3600, 900 * 2 ** failures))
        if due or _online["force"]:
            _online["force"] = False
            fetch_online()
            last = now()
            bad = _online["conn"]["horizons"]["ok"] is False or _online["conn"]["sbdb"]["ok"] is False
            failures = failures + 1 if bad else 0
        _wake_fetch.clear()
        _wake_fetch.wait(600)


def refresh_now():
    _online["force"] = True
    _wake_fetch.set()
    return {"success": True, "message": tr("Holt die Daten der Raumsonden und Kometen jetzt neu.")}


def all_comets():
    """Bekannte Kometen + live gefundene (ohne Doppelte)."""
    out = []
    seen = set()
    for c in _online["comets"] if settings()["FetchComets"] else []:
        out.append(c)
        seen.add(re.sub(r"[^a-z0-9]", "", c["name"].lower())[:8])
    for c in OBJECTS["comets"]:
        key = re.sub(r"[^a-z0-9]", "", c["name"].lower())[:8]
        if key not in seen:
            out.append(c)
    return out


# --------------------------------------------------------------------------
# Himmelsereignisse
# --------------------------------------------------------------------------

_events = {"list": [], "key": None, "at": 0.0, "error": "", "demo": None}
_wake_events = threading.Event()


def compute_events():
    values = settings()
    comets = []
    t = now()
    for c in all_comets():
        try:
            tp = sources.next_perihelion(c, t)
        except (KeyError, ValueError, TypeError):
            continue
        comets.append(dict(c, tp=tp))
    key = (values["Lat"], values["Lon"], len(comets), int(t // EVENTS_EVERY))
    if key == _events["key"]:
        return
    started = time.time()
    found = sky_events.compute(t, EVENT_DAYS, values["Lat"], values["Lon"], 0.0, comets)
    _events.update(list=found, key=key, at=t, error="")
    log(f"Ereignisse: {len(found)} in den nächsten {EVENT_DAYS} Tagen ({time.time() - started:.1f} s).")


def events_loop():
    while not _stop.is_set():
        try:
            compute_events()
        except Exception as exc:  # noqa: BLE001
            _events["error"] = str(exc)[:200]
            log(f"Ereignisse: {exc}", "warning")
        _wake_events.clear()
        _wake_events.wait(600)


def wanted_types(values):
    out = set()
    for name, types in EVENT_TYPES.items():
        if values[name]:
            out.update(types)
    return out


def localized(e, values):
    title, sub = texts.event_text(values["Language"], e, values["Lat"])
    return dict(e, title=title, sub=sub)


def visible_events(values=None, limit=40, with_demo=True):
    values = values or settings()
    types = wanted_types(values)
    t = now()
    out = [localized(e, values) for e in _events["list"] if e["type"] in types and e["end"] > t]
    demo = _events["demo"]
    if with_demo and demo and demo["until"] > t:
        out = [localized(demo["event"], values)] + out
    return out[:limit]


def demo_event():
    """Vorführung: das nächste große Ereignis zwei Minuten lang im Zeitraffer (mit Takeover, wenn an)."""
    values = settings()
    types = wanted_types(values) or {"lunar-eclipse", "solar-eclipse"}
    pick = next((e for e in _events["list"] if e["prio"] == 1 and e["type"] in types), None) \
        or next((e for e in _events["list"] if e["type"] in types), None)
    if pick is None:
        return {"success": False, "error": tr("Kein Ereignis in den nächsten Monaten gefunden.")}
    event = dict(pick, id="demo-" + pick["id"], demo=True)
    _events["demo"] = {"event": event, "until": now() + 120}
    _wake_takeover.set()
    title = localized(event, values)["title"]
    return {"success": True, "message": tr("Vorführung: Die Szene zeigt zwei Minuten lang „{name}“ im Zeitraffer.",
                                           name=title)}


# --------------------------------------------------------------------------
# Den Bildschirm übernehmen (Takeover) während eines Ereignisses
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = "Solar System Live (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Played by the Solar System Live plugin when it shows a sky event (an eclipse, for "
                                 "example) over the running playlist. Stays switched off so it does not end up in a "
                                 "Quick Mix. The plugin creates it again if it is deleted.")
TAKEOVER_ITEM_SECONDS = 6 * 3600
TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
STATE_FILE = DATA_DIR / "state.json"
_takeover_lock = threading.Lock()
_takeover = {"handle": None, "since": None, "token": 0, "note": "", "passId": None, "tried": set()}
_playlists = {"at": 0.0, "takeoverId": None, "note": ""}
_playlist_lock = threading.Lock()
_wake_takeover = threading.Event()


def load_state():
    data = read_json(STATE_FILE, {})
    return data if isinstance(data, dict) else {}


def save_state(**changes):
    data = load_state()
    data.update(changes)
    write_json(STATE_FILE, data)


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError:
        return False
    return bool(status.get("active"))


def ensure_takeover_playlist(scene_db_id):
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if i.get("dynamicSceneId") == scene_db_id]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_PLAYLIST_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(f"no id for {TAKEOVER_PLAYLIST_NAME}")
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": scene_db_id, "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def maintain_playlists(force=False):
    """Die Übernahme-Playlist gibt es nur, solange Takeover eingeschaltet ist."""
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        if settings()["Takeover"] == "off":
            _playlists["note"] = ""
            return
        row = find_scene()
        if row is None:
            _playlists["note"] = tr("Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.")
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(row["id"]), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Konnte die Übernahme-Playlist nicht anlegen: {exc}", exc=exc)
            log(_playlists["note"], "warning")


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform", read_timeout=10) or {}
    except EngineError:
        return True
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover", read_timeout=10) or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Solar System Live ist auf der Plugins-Seite ausgeschaltet.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Übernahme erlauben“ ist für Solar System Live auf der Plugins-Seite aus. Schalte es ein, sonst "
                  "kann das Ereignis nicht über die Playlist gelegt werden.")
    return ""


def display_is_off():
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def scene_on_screen():
    """Läuft die Szene gerade ganz normal in einer Playlist? Dann sagt sie selbst an."""
    if _scene["dbId"] is None:
        return False
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", read_timeout=5) or {}
    except EngineError:
        return False
    item = status.get("currentItem") or {}
    return bool(status.get("isRunning") and item.get("dynamicSceneId") == _scene["dbId"]
                and not same_id(status.get("activePlaylistId"), _playlists["takeoverId"]))


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        log(text)
    return False



def _check_after_release():
    """Nach dem Zurückgeben: Bild stehen geblieben oder Playlist nicht wieder da? (playback_guard)"""
    if playback_guard is None:
        return
    threading.Thread(target=playback_guard.restore_if_stalled, name="playback-guard",
                     args=(engine_base(), engine_headers, lambda m, level="info": log(m, level)),
                     kwargs={"stop_event": _stop}, daemon=True).start()

def _on_session_state(handle_or_state):
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _takeover.update(handle=None, since=None, passId=None)
    log(f"Der Rahmen hat das Ereignis beendet: {new_state}.")
    _check_after_release()


def end_takeover(reason, token=None):
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        _takeover.update(handle=None, since=None, passId=None)
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:  # noqa: BLE001
        log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", "warning")
    log(f"Bildschirm zurückgegeben ({reason}).")
    if reason not in ("stopped", "gestoppt"):
        _check_after_release()
    return True


def takeover_candidate(e, values):
    """Kommt dieses Ereignis über die Playlist?"""
    if e.get("demo"):
        return values["Takeover"] != "off"
    if values["Takeover"] == "off":
        return False
    if values["Takeover"] == "eclipses":
        return e["type"] in ("lunar-eclipse", "solar-eclipse", "transit") and e.get("visible") is True \
            and not (e["type"] == "lunar-eclipse" and e["info"].get("kind") == "penumbral")
    return e["prio"] == 1 and e.get("visible") is not False


def takeover_window(e, values):
    if e.get("demo"):
        return now() - 1, _events["demo"]["until"] if _events["demo"] else now()
    minutes = int(values["TakeoverMinutes"])
    half = minutes * 30
    peak = e["peak"]
    if e["type"] == "solar-eclipse" and (e["info"] or {}).get("local"):
        peak = e["info"]["local"]["peak"]
    return peak - half, peak + half


def show_event(e, values):
    if not takeover_supported():
        return _note(tr("Dieser Rahmen ist zu alt, damit ein Plugin den Bildschirm übernehmen kann."))
    if find_scene() is None:
        return _note(tr("Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("Die Übernahme-Playlist ist noch nicht angelegt."))
    wake = values["WakeScreen"]
    if not wake and display_is_off():
        return _note(tr("Der Bildschirm ist aus; das Ereignis wird nicht gezeigt."))
    lo, hi = takeover_window(e, values)
    seconds = int(max(30, min(3900, hi - now() + 20)))
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             "overlay": {"enabled": False}}
    name = localized(e, values)["title"]
    try:
        _leftover["askedAt"] = time.time()
        handle = plugin.acquire_display_session(
            session_key="event", state=state, display_name=DISPLAY_NAME,
            max_duration_seconds=seconds, wake_if_off=bool(wake))
    except Exception as exc:  # noqa: BLE001
        return _note(tr("Konnte das Ereignis nicht zeigen: {exc}", exc=exc))
    if handle is None:
        return _note(takeover_permission_note() or tr("Gerade hat etwas anderes den Bildschirm."))
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, since=now(), note="", passId=e["id"])
    try:
        handle.on_state_change(_on_session_state)
    except Exception:  # noqa: BLE001
        pass
    try:
        if not handle.wait_until_active(timeout=10):
            end_takeover("failed", token)
            return _note(tr("Der Rahmen hat das Ereignis nicht rechtzeitig gezeigt."))
    except Exception as exc:  # noqa: BLE001
        end_takeover("failed", token)
        return _note(tr("Konnte das Ereignis nicht zeigen: {exc}", exc=exc))
    _note(tr("Zeigt gerade: {name}.", name=name))
    return True


def decide_takeover():
    values = settings()
    t = now()
    want = None
    candidates = list(_events["list"])
    if _events["demo"] and _events["demo"]["until"] > t:
        candidates = [_events["demo"]["event"]] + candidates
    for e in candidates:
        if takeover_candidate(e, values):
            lo, hi = takeover_window(e, values)
            if lo <= t <= hi:
                want = e
                break
    with _takeover_lock:
        handle = _takeover["handle"]
        held_for = _takeover["passId"]
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        if want is None or want["id"] != held_for:
            end_takeover("done")
        return
    if want is None or want["id"] in _takeover["tried"]:
        return
    _takeover["tried"].add(want["id"])
    if scene_on_screen():
        log("Die Szene läuft schon in einer Playlist und zeigt das Ereignis selbst.")
        return
    show_event(want, values)
# ---- Takeover-Playlist, die nach dem Zurückgeben weiterläuft ---------------
# Lief vor einem Takeover keine Playlist, stellt die Engine dieses "nichts"
# nicht wieder her, und die Takeover-Playlist läuft einfach weiter (Jans
# Rahmen, 2026-10-24). Jeder Durchlauf hält sie dann mit POST /slideshow/stop
# an: nur wenn sie läuft, niemand den Bildschirm hält und das Plugin nicht
# gerade selbst darum gebeten hat.
_leftover = {"askedAt": 0.0, "failed": False}


def stop_leftover_takeover():
    try:
        playlist_id = _playlists["takeoverId"]
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status", read_timeout=5) or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status", read_timeout=5) or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop", read_timeout=10)
    except Exception as exc:  # noqa: BLE001 - darf die Schleife nie aufhalten
        if not _leftover["failed"]:
            log(f"The takeover playlist kept running and could not be stopped: {exc}", "warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def takeover_loop():
    last_leftover = 0.0
    while not _stop.is_set():
        try:
            if settings()["Takeover"] != "off" or _takeover["handle"] is not None:
                maintain_playlists()
                decide_takeover()
            if now() - last_leftover > 15:
                last_leftover = now()
                stop_leftover_takeover()
        except Exception as exc:  # noqa: BLE001
            log(f"Takeover: {exc}", "warning")
        _wake_takeover.clear()
        _wake_takeover.wait(5)


# --------------------------------------------------------------------------
# Die eigene Playlist
# --------------------------------------------------------------------------

OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=(PLAYLIST_NAME,),
    name=lambda: PLAYLIST_NAME,
    description=lambda: tr("Die Planeten an ihrem echten Ort von heute, mit Monden, Raumsonden, Kometen und den nächsten Finsternissen."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
    held=screen_held,
)


def make_playlist():
    return OWN.create_now()


# --------------------------------------------------------------------------
# Ort suchen
# --------------------------------------------------------------------------

def search_places(query):
    name = (query.get("q") or [""])[0].strip()[:80]
    if len(name) < 2:
        return {"success": True, "places": []}
    try:
        response = requests.get(GEOCODE_URL, params={"name": name, "count": 8, "language": settings()["Language"],
                                                     "format": "json"},
                                timeout=(CONNECT_TIMEOUT, 20),
                                headers={"User-Agent": f"DynaFrame-SolarSystemLive/{version()}"})
        response.raise_for_status()
        data = response.json()
    except (requests.RequestException, ValueError) as exc:
        _online["conn"]["geocoding"].update(ok=False, at=now(), error=exc.__class__.__name__)
        return {"success": False, "error": f"Open-Meteo: {exc.__class__.__name__}"}
    _online["conn"]["geocoding"].update(ok=True, at=now(), error="")
    out = []
    for row in data.get("results") or []:
        try:
            lat, lon = float(row["latitude"]), float(row["longitude"])
        except (KeyError, TypeError, ValueError):
            continue
        region = ", ".join(str(x) for x in (row.get("admin1"), row.get("country")) if x)
        out.append({"name": row.get("name") or "?", "region": region, "lat": round(lat, 4), "lon": round(lon, 4),
                    "height": row.get("elevation")})
    return {"success": True, "places": out}




# --------------------------------------------------------------------------
# Was die Szene und die Seite bekommen
# --------------------------------------------------------------------------

_gpu = {"fps": None, "scale": None, "tier": "", "at": 0.0, "renderer": ""}


def scene_focus():
    demo = _events["demo"]
    if demo and demo["until"] > now():
        return demo["event"]["id"]
    with _takeover_lock:
        return _takeover["passId"] if _takeover["handle"] is not None else None


def scene_payload(query):
    values = settings()
    comets = all_comets()
    probes = [{k: p.get(k) for k in ("id", "name", "launched", "model")} for p in OBJECTS["probes"]]
    have = set(_online["probes"]) if values["FetchProbes"] else set()
    return {
        "success": True,
        "now": round(now(), 1),
        "settings": {k: values[k] for k in SCENE_SETTINGS} | {"LeadDays": values["LeadDays"]},
        "events": visible_events(values),
        "focus": scene_focus(),
        "comets": comets,
        "cometsVer": "|".join(c["id"] for c in comets),
        "probeList": [p for p in probes if p["model"] or p["id"] in have],
        "probes": _online["probes"] if values["FetchProbes"] else {},
    }


DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    with _takeover_lock:
        note = _takeover["note"] if values["Takeover"] != "off" else ""
    if values["Takeover"] != "off" and not note:
        note = _playlists["note"] or takeover_permission_note()
    every = visible_events(values, limit=400, with_demo=False)
    evs = every[:12]
    big = next((e for e in every if e["prio"] == 1), None)
    return {
        "nextBig": big,
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": values,
        "events": evs,
        "eventsError": _events["error"],
        "eventsAt": _events["at"],
        "probes": len(_online["probes"]),
        "comets": len(all_comets()),
        "liveComets": len(_online["comets"]),
        "conn": _online["conn"],
        "busy": _online["busy"],
        "gpu": _gpu,
        "takeoverNote": note,
        "theme": {"id": theme_id()},
    }


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}
class StudioHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(min(length, 1024 * 1024)) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(query), cors=True)
                return
            if path == "/api/places":
                self._json(search_places(query))
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            if path == "/api/gpu":
                q = {k: (v or [""])[0] for k, v in query.items()}
                try:
                    _gpu.update(fps=float(q.get("fps") or 0), scale=float(q.get("scale") or 0), at=now(),
                                tier=re.sub(r"[^a-z0-9]", "", q.get("tier", ""))[:8],
                                renderer=re.sub(r"[\x00-\x1f]", " ", q.get("r", ""))[:100])
                except ValueError:
                    pass
                self._json({"success": True}, cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                changed = save_settings(self._body())
                if "MakePlaylist" in changed:
                    OWN.changed()
                if any(name in EVENT_SETTINGS for name in changed):
                    _events["key"] = None
                    _wake_events.set()
                if any(name in ("FetchProbes", "FetchComets") for name in changed):
                    _events["key"] = None
                    _online["force"] = True
                    _wake_fetch.set()
                if "Takeover" in changed:
                    _playlists["at"] = 0.0
                    _wake_takeover.set()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(refresh_now())
                return
            if path == "/api/demo":
                self._json(demo_event())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}")
    plugin.on_action("refresh", lambda _context=None: refresh_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())
    plugin.on_action("demo", lambda _context=None: demo_event())
    start_studio()
    plugin.connect_sse()
    plugin.ready()
    try:
        borrow_place()
    except Exception as exc:  # noqa: BLE001
        log(f"Ort übernehmen: {exc}", "warning")
    _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
    threading.Thread(target=fetch_loop, name=f"{PLUGIN_ID}-fetch", daemon=True).start()
    threading.Thread(target=events_loop, name=f"{PLUGIN_ID}-events", daemon=True).start()
    threading.Thread(target=takeover_loop, name=f"{PLUGIN_ID}-takeover", daemon=True).start()
    try:
        while not _stop.is_set():
            _stop.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop.set()
    _wake_fetch.set()
    _wake_events.set()
    _wake_takeover.set()
    end_takeover("stopped")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:  # noqa: BLE001
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:  # noqa: BLE001
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
