/* Wikipedia Breathes - die Szene.
 *
 * Jede Änderung an Wikipedia weltweit wird ein Lichtpunkt auf der Weltkarte,
 * am Ort ihrer Sprache (langs.js): groß bei viel Text, rot, wenn Text
 * entfernt oder eine Seite gelöscht wurde, mit goldenem Ring bei neuen
 * Artikeln. Unten läuft die Zeile „Gerade bearbeitet: …“.
 *
 * Das Plugin liest den Datenstrom (Wikimedia EventStreams) und gibt jede
 * Sekunde die neuen Änderungen, schon auf "PerSecond" ausgedünnt. Die Szene
 * spielt sie im echten Takt ab (eine gute Sekunde verzögert), damit das Licht
 * nicht stoßweise kommt. Gezeichnet wird mit Canvas 2D und vorgerenderten
 * Leuchtpunkten; die Karte wird nur bei Größenänderung neu gemalt.
 *
 * Zum Ausprobieren: ?plugin=<URL der Plugin-Seite> &lang=de|en|es &fps=1
 */
(function () {
  "use strict";

  const PLUGIN_ID = "WikipediaBreathes";
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const sameOrigin = (location.protocol === "http:" && (location.port === "" || location.port === "80"))
    || (location.protocol === "https:" && (location.port === "" || location.port === "443"));
  const pluginBases = params.get("plugin") ? [params.get("plugin").replace(/\/?$/, "/")] : [...new Set(sameOrigin ? [
    `${location.origin}${advanced}`,
    `${location.protocol}//${location.hostname}:8003${advanced}`
  ] : [
    `${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`,
    `http://${location.hostname || "localhost"}${advanced}`
  ])];
  let baseIndex = 0;

  const TEXT = {
    de: {
      sub: "Jede Änderung an Wikipedia, live", perMin: "Änderungen\npro Minute", breath: "Der Atem: Änderungen pro Sekunde, letzte 5 Minuten",
      bytes: "{a} Text dazu · {d} entfernt pro Minute", pages: "{n} neue Artikel · {x} Seiten gelöscht seit {t}",
      add: "Text dazu", del: "Text entfernt", newp: "neuer Artikel", size: "Größe = Menge Text",
      ticker: "Gerade bearbeitet:", newTag: "neu", delTag: "gelöscht", bytesUnit: "Bytes",
      credit: "Daten: Wikimedia EventStreams · Karte: Natural Earth · Nicht verbunden mit der Wikimedia Foundation",
      connecting: "Verbindet mit dem Datenstrom von Wikipedia …", unreachable: "Wikipedia Breathes antwortet nicht.",
      login: "Bitte zuerst im Browser beim Rahmen anmelden.",
      error: "Der Datenstrom von Wikipedia ist gerade nicht erreichbar ({e}). Mit Pi-hole: stream.wikimedia.org freigeben.",
      quiet: "Warte auf Änderungen …"
    },
    en: {
      sub: "Every change to Wikipedia, live", perMin: "changes\nper minute", breath: "The breath: changes per second, last 5 minutes",
      bytes: "{a} text added · {d} removed per minute", pages: "{n} new articles · {x} pages deleted since {t}",
      add: "text added", del: "text removed", newp: "new article", size: "size = amount of text",
      ticker: "Being edited now:", newTag: "new", delTag: "deleted", bytesUnit: "bytes",
      credit: "Data: Wikimedia EventStreams · Map: Natural Earth · Not affiliated with the Wikimedia Foundation",
      connecting: "Connecting to the Wikipedia live stream …", unreachable: "Wikipedia Breathes is not responding.",
      login: "Please sign in to the frame in the browser first.",
      error: "The Wikipedia live stream cannot be reached right now ({e}). Using Pi-hole? Allow stream.wikimedia.org.",
      quiet: "Waiting for changes …"
    },
    es: {
      sub: "Cada cambio en Wikipedia, en directo", perMin: "cambios\npor minuto", breath: "La respiración: cambios por segundo, últimos 5 minutos",
      bytes: "{a} de texto añadido · {d} quitado por minuto", pages: "{n} artículos nuevos · {x} páginas borradas desde las {t}",
      add: "texto añadido", del: "texto quitado", newp: "artículo nuevo", size: "tamaño = cantidad de texto",
      ticker: "Editando ahora:", newTag: "nuevo", delTag: "borrado", bytesUnit: "bytes",
      credit: "Datos: Wikimedia EventStreams · Mapa: Natural Earth · Sin relación con la Wikimedia Foundation",
      connecting: "Conectando con la transmisión en directo de Wikipedia …", unreachable: "Wikipedia Breathes no responde.",
      login: "Inicia sesión primero en el marco desde el navegador.",
      error: "No se puede acceder a la transmisión de Wikipedia ahora mismo ({e}). ¿Usas Pi-hole? Permite stream.wikimedia.org.",
      quiet: "Esperando cambios …"
    }
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  let lang = params.get("lang") || "en";
  const tx = (key, values) => {
    let text = (TEXT[lang] || TEXT.en)[key] ?? key;
    for (const [k, v] of Object.entries(values || {})) text = text.replace(`{${k}}`, v);
    return text;
  };

  const $ = (id) => document.getElementById(id);
  const mapCanvas = $("map"), labelCanvas = $("labels"), fxCanvas = $("fx");
  const mapCtx = mapCanvas.getContext("2d");
  const labelCtx = labelCanvas.getContext("2d");
  const fx = fxCanvas.getContext("2d");
  const note = $("note"), panel = $("panel"), ticker = $("ticker"), track = $("track");
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const LANGS = window.WB_LANGS || {};

  // ------------------------------------------------------------ Plugin

  async function api(path) {
    let lastError = null;
    for (let i = 0; i < pluginBases.length; i += 1) {
      const base = pluginBases[(baseIndex + i) % pluginBases.length];
      try {
        const response = await fetch(base + path, { cache: "no-store", credentials: "same-origin" });
        if (response.redirected && /login/i.test(response.url)) throw new Error("login");
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const body = await response.json();
        baseIndex = (baseIndex + i) % pluginBases.length;
        return body;
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error("unreachable");
  }

  function report(message) {
    api("api/report?m=" + encodeURIComponent(String(message).slice(0, 180))).catch(() => {});
  }
  window.addEventListener("error", (e) => report(`${e.message} @${e.lineno}`));

  // DynaFrame wartet, bis die Szene meldet, dass sie steht; sonst bricht der
  // Fernseher nach einer Frist ab ("scene readiness deadline expired").
  let readySent = false;
  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 8000);

  function showNote(text) {
    if (note.textContent !== (text || "")) note.textContent = text || "";
    note.hidden = !text;
  }

  // ------------------------------------------------------------ Einstellungen

  let settings = {
    Language: lang, Region: "world", Bots: "dim", Pages: "all", PerSecond: "20", Glow: "8",
    Ticker: true, Panel: true, LanguageLabels: true
  };

  // ------------------------------------------------------------ Karte und Projektion

  const REGIONS = {
    world: { w: -169, e: 191, s: -56, n: 76 },
    europe: { w: -24, e: 44, s: 34, n: 70 },
    americas: { w: -168, e: -30, s: -56, n: 70 },
    asia: { w: 26, e: 150, s: -11, n: 58 },
    africa: { w: -19, e: 55, s: -36, n: 38 }
  };
  const RAD = Math.PI / 180;
  const miller = (lat) => 1.25 * Math.log(Math.tan(Math.PI / 4 + 0.4 * clamp(lat, -85, 85) * RAD)) / RAD;

  let W = 0, H = 0, DPR = 1, unit = 1, portrait = false;
  let view = null;
  let layoutPanelTop = 0;

  function makeView() {
    const r = REGIONS[settings.Region] || REGIONS.world;
    const tickerH = settings.Ticker ? 3.2 * fontPx() : 0;
    const y0 = miller(r.s), y1 = miller(r.n);
    const bw = r.e - r.w, bh = y1 - y0;
    // Fläche für die Karte: im Hochformat mittig über der Seitenleiste
    let areaTop = 0;
    let areaH = H - tickerH * 0.35;
    if (portrait) {
      layoutPanelTop = panel.hidden ? 0 : panel.getBoundingClientRect().top;
      const free = settings.Panel && !panel.hidden ? Math.max(H * 0.4, layoutPanelTop) : H - tickerH;
      areaH = Math.min(free, bh * W / bw * 1.15);
      areaTop = (free - areaH) / 2;
    }
    const scale = Math.min(W / bw, areaH / bh);
    const cx = (r.w + r.e) / 2, cy = (y0 + y1) / 2;
    const world = settings.Region === "world";
    return {
      scale, cx, cy, world, region: r,
      x: (lon) => {
        let d = lon - cx;
        if (world) d = ((d + 540) % 360) - 180;
        return W / 2 + d * scale;
      },
      y: (lat) => areaTop + areaH / 2 - (miller(lat) - cy) * scale,
      rawX: (lon) => W / 2 + (lon - cx) * scale
    };
  }

  function fontPx() {
    return Math.min(W, H) / 54;
  }

  // Ringe aus land.js (erster Punkt, dann Differenzen in 1/100 Grad)
  function decode(rings) {
    return (rings || []).map((ring) => {
      const out = new Float32Array(ring.length);
      let lon = 0, lat = 0;
      for (let i = 0; i < ring.length; i += 2) {
        lon += ring[i]; lat += ring[i + 1];
        out[i] = lon / 100; out[i + 1] = lat / 100;
      }
      return out;
    });
  }
  const WORLD = window.WORLD_MAP || { land: [], lakes: [], borders: [] };
  const LAND = decode(WORLD.land), LAKES = decode(WORLD.lakes), BORDERS = decode(WORLD.borders);

  function tracePath(ctx, ring, closed, shift) {
    // Linien ohne Sprung über die Kartennaht; Ringe, die über den Rand reichen, zusätzlich verschoben zeichnen
    const v = view;
    let first = true, prev = 0;
    for (let i = 0; i < ring.length; i += 2) {
      let lon = ring[i];
      if (v.world) {
        let d = lon - v.cx;
        d = ((d + 540) % 360) - 180;
        if (!first) {
          while (d - prev > 180) d -= 360;
          while (prev - d > 180) d += 360;
        }
        prev = d;
        lon = v.cx + d;
      }
      const x = v.rawX(lon + shift), y = v.y(ring[i + 1]);
      if (first) { ctx.moveTo(x, y); first = false; } else ctx.lineTo(x, y);
    }
    if (closed) ctx.closePath();
  }

  function drawRings(ctx, rings, closed) {
    const shifts = view.world ? [0, -360, 360] : [0];
    ctx.beginPath();
    for (const ring of rings) for (const s of shifts) tracePath(ctx, ring, closed, s);
  }

  function drawMap() {
    const ctx = mapCtx;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    const bg = ctx.createRadialGradient(W * 0.5, H * 0.45, 0, W * 0.5, H * 0.45, Math.max(W, H) * 0.75);
    bg.addColorStop(0, "#08111f");
    bg.addColorStop(1, "#03050a");
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);
    // feines Gradnetz
    ctx.strokeStyle = "rgba(120, 150, 200, 0.05)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let lat = -60; lat <= 80; lat += 20) { ctx.moveTo(0, view.y(lat)); ctx.lineTo(W, view.y(lat)); }
    for (let lon = -180; lon < 180; lon += 30) {
      const x = view.x(lon);
      ctx.moveTo(x, view.y(-80)); ctx.lineTo(x, view.y(85));
    }
    ctx.stroke();
    // Weltkarte: unterhalb des Ausschnitts (Antarktis) nichts zeichnen
    ctx.save();
    if (view.world) {
      ctx.beginPath();
      ctx.rect(0, 0, W, view.y(view.region.s));
      ctx.clip();
    }
    // Land mit weichem Küstenschein
    ctx.save();
    ctx.shadowColor = "rgba(90, 140, 220, 0.18)";
    ctx.shadowBlur = 10 * unit;
    ctx.fillStyle = "#0e1726";
    drawRings(ctx, LAND, true);
    ctx.fill("evenodd");
    ctx.restore();
    ctx.fillStyle = "#06090f";
    drawRings(ctx, LAKES, true);
    ctx.fill("evenodd");
    ctx.strokeStyle = "rgba(110, 150, 210, 0.22)";
    ctx.lineWidth = Math.max(0.6, 0.8 * unit);
    drawRings(ctx, LAND, true);
    ctx.stroke();
    ctx.strokeStyle = "rgba(110, 150, 210, 0.10)";
    ctx.lineWidth = Math.max(0.5, 0.6 * unit);
    drawRings(ctx, BORDERS, false);
    ctx.stroke();
    ctx.restore();
  }

  // ------------------------------------------------------------ Leuchtpunkte

  const SPRITE = 96;
  function sprite(core, mid, edge) {
    const c = document.createElement("canvas");
    c.width = c.height = SPRITE;
    const g = c.getContext("2d");
    const r = SPRITE / 2;
    const grad = g.createRadialGradient(r, r, 0, r, r, r);
    grad.addColorStop(0, core);
    grad.addColorStop(0.16, core);
    grad.addColorStop(0.32, mid);
    grad.addColorStop(1, edge);
    g.fillStyle = grad;
    g.fillRect(0, 0, SPRITE, SPRITE);
    return c;
  }
  const SPRITES = {
    add: sprite("rgba(255,255,255,1)", "rgba(170,220,255,0.55)", "rgba(120,190,255,0)"),
    del: sprite("rgba(255,225,220,1)", "rgba(255,70,60,0.6)", "rgba(255,40,40,0)"),
    new: sprite("rgba(255,250,225,1)", "rgba(255,205,90,0.6)", "rgba(255,190,60,0)"),
    bot: sprite("rgba(200,205,235,0.9)", "rgba(140,150,210,0.35)", "rgba(120,130,200,0)"),
    halo: sprite("rgba(150,200,255,0.22)", "rgba(120,180,255,0.10)", "rgba(100,160,255,0)")
  };

  const dots = [];
  const rings = [];
  const MAX_DOTS = 700;

  function gauss() {
    let u = 0, v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  function pickPlace(code) {
    const places = LANGS[code];
    if (!places) return null;
    let total = 0;
    for (const p of places) total += p[2];
    let r = Math.random() * total;
    let place = places[0];
    for (const p of places) { r -= p[2]; if (r <= 0) { place = p; break; } }
    const s = place[3];
    const lat = place[0] + gauss() * s * 0.6;
    const lon = place[1] + gauss() * s / Math.max(0.35, Math.cos(place[0] * RAD)) * 0.6;
    return [lat, lon];
  }

  function radiusFor(delta, flags) {
    if (flags & 4) return 13;
    const d = Math.abs(delta);
    return Math.min(30, 3 + 3.4 * Math.log2(1 + d / 40));
  }

  function spawn(ev, t) {
    const [code, delta, flags] = ev;
    const place = pickPlace(code);
    if (!place) return;
    const x = view.x(place[1]), y = view.y(place[0]);
    if (x < -40 || x > W + 40 || y < -40 || y > H + 40) return;
    const bot = (flags & 1) !== 0;
    const removed = (flags & 4) !== 0 || delta < 0;
    const isNew = (flags & 2) !== 0;
    let kind = removed ? "del" : isNew ? "new" : "add";
    let alpha = 1;
    let r = radiusFor(delta, flags) * unit;
    if (bot && settings.Bots === "dim") { kind = removed ? "del" : "bot"; alpha = 0.45; r *= 0.75; }
    const life = Number(settings.Glow || 8) * 1000 * (0.7 + 0.3 * Math.min(1, r / (20 * unit)));
    dots.push({ x, y, r, kind, alpha, born: t, life });
    if (dots.length > MAX_DOTS) dots.splice(0, dots.length - MAX_DOTS);
    if (!bot && (isNew || (flags & 4) || Math.abs(delta) >= 3000)) {
      rings.push({ x, y, r, color: isNew ? "255,207,90" : removed ? "255,74,74" : "191,230,255", born: t, life: 1800 });
      if (rings.length > 40) rings.shift();
    }
    tick(code, t);
  }

  // ------------------------------------------------------------ Atmende Sprachräume

  const langRate = new Map();   // Sprache -> geglättete Aktivität
  function tick(code, t) {
    const row = langRate.get(code) || { v: 0, t };
    row.v = row.v * Math.exp(-(t - row.t) / 20000) + 1;
    row.t = t;
    langRate.set(code, row);
  }

  function drawHalos(t) {
    const rows = [];
    for (const [code, row] of langRate) {
      const v = row.v * Math.exp(-(t - row.t) / 20000);
      if (v > 0.6) rows.push([code, v]);
    }
    rows.sort((a, b) => b[1] - a[1]);
    fx.globalCompositeOperation = "lighter";
    const breath = 0.82 + 0.18 * Math.sin(t / 1000 * Math.PI * 2 / 6.5);
    for (const [code, v] of rows.slice(0, 24)) {
      const p = LANGS[code] && LANGS[code][0];
      if (!p) continue;
      const x = view.x(p[1]), y = view.y(p[0]);
      const size = (40 + 26 * Math.log2(1 + v)) * unit * breath * (0.6 + Math.min(1.6, p[3] / 3));
      fx.globalAlpha = clamp(0.25 + Math.log2(1 + v) / 9, 0.2, 0.9);
      fx.drawImage(SPRITES.halo, x - size / 2, y - size / 2, size, size);
    }
    fx.globalAlpha = 1;
  }

  // ------------------------------------------------------------ Takt

  const pending = [];            // [zeigenUm, ereignis]
  const DELAY = 1300;            // ms Verzögerung, um den echten Takt nachzuspielen
  let clockOffset = null;        // lokale Zeit (ms) - Plugin-Zeit (ms)

  function enqueue(events, serverNow, first) {
    const local = performance.now();
    const offset = local - serverNow * 1000;
    clockOffset = clockOffset === null ? offset : clockOffset * 0.8 + offset * 0.2;
    if (first) {
      // beim Start die letzten Sekunden zügig nachholen
      events.forEach((ev, i) => pending.push([local + (i / Math.max(1, events.length)) * 1200, ev]));
    } else {
      for (const ev of events) pending.push([ev[4] * 1000 + clockOffset + DELAY, ev]);
    }
    pending.sort((a, b) => a[0] - b[0]);
    if (pending.length > 1500) pending.splice(0, pending.length - 1500);
    for (const ev of events) if (ev[3]) offerTitle(ev);
  }

  // ------------------------------------------------------------ Laufzeile

  let names = null;
  const NAME_FIX = {
    simple: { de: "Einfaches Englisch", en: "Simple English", es: "inglés simple" },
    als: { de: "Alemannisch", en: "Alemannic", es: "alemánico" },
    "be-tarask": { de: "Belarussisch (Taraschkewiza)", en: "Belarusian (Taraškievica)", es: "bielorruso (taraškievica)" },
    "map-bms": { de: "Banyumasan", en: "Banyumasan", es: "banyumasan" },
    "cbk-zam": { de: "Chavacano", en: "Chavacano", es: "chabacano" },
    "nds-nl": { de: "Niedersächsisch (NL)", en: "Dutch Low Saxon", es: "bajo sajón neerlandés" },
    sh: { de: "Serbokroatisch", en: "Serbo-Croatian", es: "serbocroata" }
  };
  const CODE_ALIAS = { "zh-yue": "yue", "zh-min-nan": "nan", "zh-classical": "lzh", "roa-rup": "rup", "bat-smg": "sgs", "fiu-vro": "vro", "zh-wuu": "wuu" };
  const nameCache = new Map();
  function langName(code) {
    const key = lang + ":" + code;
    if (nameCache.has(key)) return nameCache.get(key);
    let name = NAME_FIX[code] && NAME_FIX[code][lang];
    if (!name) {
      try {
        if (!names || names.lang !== lang) names = { lang, dn: new Intl.DisplayNames([LOCALES[lang] || "en"], { type: "language" }) };
        const n = names.dn.of(CODE_ALIAS[code] || code);
        if (n && n !== code && n !== (CODE_ALIAS[code] || code)) name = n;
      } catch (_) { /* unbekannter Code */ }
    }
    name = name ? name.charAt(0).toLocaleUpperCase(LOCALES[lang]) + name.slice(1) : code;
    nameCache.set(key, name);
    return name;
  }

  const candidates = [];
  let lastLang = "";
  function offerTitle(ev) {
    candidates.push({ ev, at: performance.now() });
    if (candidates.length > 300) candidates.splice(0, candidates.length - 300);
  }

  function nextTitle() {
    const now = performance.now();
    while (candidates.length && now - candidates[0].at > 12000) candidates.shift();
    if (!candidates.length) return null;
    let best = -1, bestScore = -1;
    for (let i = 0; i < candidates.length; i += 1) {
      const [code, delta, flags, title] = candidates[i].ev;
      if (!title) continue;
      let score = Math.log2(2 + Math.abs(delta)) + (flags & 2 ? 6 : 0) + (flags & 4 ? 4 : 0);
      score += (now - candidates[i].at) < 4000 ? 2 : 0;
      if (code === lastLang) score -= 4;
      if (score > bestScore) { bestScore = score; best = i; }
    }
    if (best < 0) return null;
    const pick = candidates.splice(best, 1)[0].ev;
    lastLang = pick[0];
    return pick;
  }

  const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang] || "en");
  function kb(bytes) {
    if (Math.abs(bytes) >= 1e6) return (bytes / 1e6).toLocaleString(LOCALES[lang], { maximumFractionDigits: 1 }) + " MB";
    if (Math.abs(bytes) >= 1e4) return Math.round(bytes / 1e3).toLocaleString(LOCALES[lang]) + " KB";
    return fmt(bytes) + " " + tx("bytesUnit");
  }

  let trackX = 0, trackW = 0, laneW = 0;
  function tickerItem(ev) {
    const [code, delta, flags, title] = ev;
    const item = document.createElement("span");
    item.className = "item";
    const removed = (flags & 4) || delta < 0;
    const dot = document.createElement("span");
    dot.className = "dot " + (removed ? "del" : (flags & 2) ? "new" : "add");
    const t = document.createElement("span");
    t.className = "t";
    t.textContent = title;
    const m = document.createElement("span");
    m.className = "m";
    const tag = document.createElement("span");
    if (flags & 4) { tag.className = "d"; tag.textContent = tx("delTag"); }
    else if (flags & 2) { tag.className = "n"; tag.textContent = tx("newTag") + " · " + kb(delta); }
    else { tag.className = delta < 0 ? "d" : "a"; tag.textContent = (delta < 0 ? "−" : "+") + kb(Math.abs(delta)); }
    m.append(langName(code) + " · ", tag);
    item.append(dot, t, m);
    return item;
  }

  function moveTicker(dt) {
    if (ticker.hidden) return;
    const speed = 80 * unit;
    trackX -= speed * dt / 1000;
    // vorne heraus gelaufene Einträge entfernen
    const first = track.firstElementChild;
    if (first && trackX + first.offsetWidth < 0) {
      trackX += first.offsetWidth;
      trackW -= first.offsetWidth;
      first.remove();
    }
    // hinten nachlegen, sobald Platz ist
    if (trackX + trackW < laneW + 10) {
      const ev = nextTitle();
      if (ev) {
        const node = tickerItem(ev);
        track.appendChild(node);
        trackW += node.offsetWidth;
        if (trackX + trackW - node.offsetWidth < laneW * 0.5) {
          // leere Zeile (Start): Eintrag nicht von weit rechts kommen lassen
          trackX = Math.max(trackX, laneW * 0.55 - (trackW - node.offsetWidth));
        }
      }
    }
    track.style.transform = `translate3d(${trackX.toFixed(1)}px,0,0)`;
  }

  // ------------------------------------------------------------ Seitenleiste

  const breathCanvas = $("breath");
  const breathCtx = breathCanvas.getContext("2d");
  let stats = null;
  let streamSince = null;

  function drawBreath() {
    if (!stats || !stats.rate) return;
    const w = breathCanvas.clientWidth, h = breathCanvas.clientHeight;
    if (!w || !h) return;
    if (breathCanvas.width !== Math.round(w * DPR)) { breathCanvas.width = Math.round(w * DPR); breathCanvas.height = Math.round(h * DPR); }
    const g = breathCtx;
    g.setTransform(DPR, 0, 0, DPR, 0, 0);
    g.clearRect(0, 0, w, h);
    const raw = stats.rate.slice(0, -1);
    const live = Math.min(raw.length, Math.max(0, stats.liveFor || 0));
    const data = raw.slice(raw.length - live);
    if (data.length < 3) return;
    // über 5 s glätten
    const sm = data.map((_, i) => {
      let s = 0, n = 0;
      for (let k = Math.max(0, i - 2); k <= Math.min(data.length - 1, i + 2); k += 1) { s += data[k]; n += 1; }
      return s / n;
    });
    const max = Math.max(5, ...sm) * 1.15;
    const span = Math.max(60, data.length);   // am Anfang nicht als Strich ganz rechts
    const step = w / (span - 1);
    const off = (span - data.length) * step;
    g.beginPath();
    sm.forEach((v, i) => {
      const x = off + i * step, y = h - (v / max) * h;
      if (i === 0) g.moveTo(x, y); else g.lineTo(x, y);
    });
    const line = g.createLinearGradient(0, 0, w, 0);
    line.addColorStop(0, "rgba(191,230,255,0.25)");
    line.addColorStop(1, "rgba(191,230,255,1)");
    g.strokeStyle = line;
    g.lineWidth = 1.6;
    g.stroke();
    g.lineTo(off + (sm.length - 1) * step, h);
    g.lineTo(off, h);
    g.closePath();
    const fill = g.createLinearGradient(0, 0, 0, h);
    fill.addColorStop(0, "rgba(120,190,255,0.28)");
    fill.addColorStop(1, "rgba(120,190,255,0)");
    g.fillStyle = fill;
    g.fill();
  }

  // Sprachen zählt das Plugin über die letzten 5 Minuten, kurz nach dem Verbinden über weniger
  function langMinutes() {
    return clamp(((stats && stats.liveFor) || 0) / 60, 1 / 6, 5);
  }

  function renderPanel() {
    panel.hidden = !settings.Panel;
    if (!settings.Panel || !stats) return;
    $("perMin").textContent = stats.liveFor ? fmt(stats.perMin) : "–";
    $("bytes").innerHTML = "";
    const parts = tx("bytes").split(/(\{a\}|\{d\})/);
    for (const p of parts) {
      if (p === "{a}") { const s = document.createElement("span"); s.className = "a"; s.textContent = "+" + kb(stats.addedMin); $("bytes").append(s); }
      else if (p === "{d}") { const s = document.createElement("span"); s.className = "d"; s.textContent = "−" + kb(stats.removedMin); $("bytes").append(s); }
      else $("bytes").append(p);
    }
    const since = streamSince ? new Date(streamSince).toLocaleTimeString(LOCALES[lang], { hour: "2-digit", minute: "2-digit" }) : "–";
    const pages = $("pages");
    pages.innerHTML = "";
    for (const p of tx("pages", { t: since }).split(/(\{n\}|\{x\})/)) {
      if (p === "{n}") { const s = document.createElement("span"); s.className = "n"; s.textContent = fmt(stats.newPages); pages.append(s); }
      else if (p === "{x}") pages.append(fmt(stats.deletedPages));
      else pages.append(p);
    }
    const list = $("langs");
    const top = (stats.langs || []).slice(0, portrait ? 6 : 5);
    const max = top.length ? top[0][1] : 1;
    list.innerHTML = "";
    for (const [code, n] of top) {
      const li = document.createElement("li");
      const name = document.createElement("span"); name.className = "n"; name.textContent = langName(code);
      const barBox = document.createElement("span");
      const bar = document.createElement("span"); bar.className = "bar"; bar.style.display = "block"; bar.style.width = `${Math.max(4, n / max * 100)}%`;
      barBox.append(bar);
      const c = document.createElement("span"); c.className = "c"; c.textContent = fmt(Math.round(n / langMinutes()));
      li.append(name, barBox, c);
      list.append(li);
    }
    drawBreath();
  }

  function renderStatic() {
    document.documentElement.lang = lang;
    $("sub").textContent = tx("sub");
    $("perMinUnit").innerText = tx("perMin");
    $("breathNote").textContent = tx("breath");
    $("tickerLabel").textContent = tx("ticker");
    $("credit").textContent = tx("credit");
    const legend = $("legend");
    legend.innerHTML = "";
    const add = (cls, text) => {
      const s = document.createElement("span");
      const d = document.createElement("span"); d.className = "dot " + cls;
      s.append(d, text);
      legend.append(s);
    };
    add("add", tx("add"));
    add("del", tx("del"));
    add("new", tx("newp"));
    const size = document.createElement("span");
    const small = document.createElement("span"); small.className = "dot add small";
    const big = document.createElement("span"); big.className = "dot add big";
    size.append(small, big, tx("size"));
    legend.append(size);
    nameCache.clear();
  }

  // ------------------------------------------------------------ Sprachen beschriften

  function drawLabels() {
    const ctx = labelCtx;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    ctx.clearRect(0, 0, W, H);
    if (!settings.LanguageLabels || !stats || !stats.langs) return;
    const fs = fontPx() * 0.72;
    ctx.font = `600 ${fs}px Inter, "Segoe UI", "Noto Sans", "DejaVu Sans", sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "top";
    const placed = [];
    const panelBox = panel.hidden ? null : panel.getBoundingClientRect();
    for (const [code, n] of stats.langs.slice(0, 10)) {
      const p = LANGS[code] && LANGS[code][0];
      if (!p) continue;
      const x = view.x(p[1]), y = view.y(p[0]) + Math.max(18 * unit, p[3] * view.scale * 0.5);
      const text = `${langName(code)} · ${fmt(Math.round(n / langMinutes()))}/min`;
      const w = ctx.measureText(text).width;
      const box = [x - w / 2 - 4, y - 2, x + w / 2 + 4, y + fs + 2];
      if (box[0] < 4 || box[2] > W - 4 || box[3] > H - 3.4 * fontPx()) continue;
      if (placed.some((b) => !(box[2] < b[0] || box[0] > b[2] || box[3] < b[1] || box[1] > b[3]))) continue;
      if (panelBox && !(box[2] < panelBox.left || box[0] > panelBox.right || box[3] < panelBox.top || box[1] > panelBox.bottom)) continue;
      placed.push(box);
      ctx.fillStyle = "rgba(4,7,13,0.55)";
      ctx.fillRect(box[0], box[1], box[2] - box[0], box[3] - box[1]);
      ctx.fillStyle = "rgba(200,220,245,0.78)";
      ctx.fillText(text, x, y);
      if (placed.length >= 7) break;
    }
  }

  // ------------------------------------------------------------ Zeichnen

  function frameDots(t) {
    fx.setTransform(DPR, 0, 0, DPR, 0, 0);
    fx.globalCompositeOperation = "source-over";
    fx.clearRect(0, 0, W, H);
    drawHalos(t);
    fx.globalCompositeOperation = "lighter";
    let keep = 0;
    for (let i = 0; i < dots.length; i += 1) {
      const d = dots[i];
      const age = t - d.born;
      if (age > d.life) continue;
      dots[keep++] = d;
      if (age < 0) continue;
      // einatmen (schnell aufleuchten), ausatmen (langsam verglimmen)
      const k = age / d.life;
      const grow = age < 260 ? 0.35 + 0.65 * (age / 260) * (2 - age / 260) : 1;
      const fade = age < 260 ? 1 : Math.pow(1 - k, 1.6);
      const size = d.r * 2.6 * grow * (1 - 0.35 * k);
      fx.globalAlpha = d.alpha * fade;
      fx.drawImage(SPRITES[d.kind], d.x - size, d.y - size, size * 2, size * 2);
    }
    dots.length = keep;
    fx.globalAlpha = 1;
    // Ringe bei neuen Artikeln, Löschungen und großen Änderungen
    fx.globalCompositeOperation = "source-over";
    let rk = 0;
    for (let i = 0; i < rings.length; i += 1) {
      const r = rings[i];
      const age = t - r.born;
      if (age > r.life) continue;
      rings[rk++] = r;
      if (age < 0) continue;
      const k = age / r.life;
      fx.strokeStyle = `rgba(${r.color},${(0.85 * (1 - k)).toFixed(3)})`;
      fx.lineWidth = Math.max(1, 2 * unit * (1 - k));
      fx.beginPath();
      fx.arc(r.x, r.y, Math.min(r.r, 14 * unit) * (1.2 + 4 * Math.sqrt(k)), 0, Math.PI * 2);
      fx.stroke();
    }
    rings.length = rk;
  }

  let lastFrame = 0;
  const minFrame = params.get("fps") ? 1000 / Number(params.get("fps")) : 1000 / 30;
  function frame(t) {
    requestAnimationFrame(frame);
    if (t - lastFrame < minFrame - 2) return;
    const dt = Math.min(200, t - lastFrame);
    lastFrame = t;
    const t0 = performance.now();
    while (pending.length && pending[0][0] <= t) spawn(pending.shift()[1], t);
    frameDots(t);
    moveTicker(dt);
    perf.frames += 1;
    perf.ms += performance.now() - t0;
  }
  const perf = window.__wbPerf = { frames: 0, ms: 0, dots: () => dots.length };

  // ------------------------------------------------------------ Größe

  function resize() {
    W = window.innerWidth; H = window.innerHeight;
    DPR = Math.min(1.5, window.devicePixelRatio || 1);
    portrait = H > W * 1.05;
    unit = Math.min(W, H) / 1080;
    document.body.classList.toggle("portrait", portrait);
    document.body.classList.toggle("noticker", !settings.Ticker);
    for (const c of [mapCanvas, labelCanvas, fxCanvas]) {
      c.width = Math.round(W * DPR); c.height = Math.round(H * DPR);
    }
    view = makeView();
    drawMap();
    drawLabels();
    laneW = track.parentElement.clientWidth || W;
    dots.length = 0;
    rings.length = 0;
  }
  let resizeTimer = 0;
  window.addEventListener("resize", () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(resize, 150); });

  // ------------------------------------------------------------ Abfragen

  let seq = -1;
  let lastPoll = 0;
  let pollCount = 0;
  let failures = 0;
  let lastEventSeen = performance.now();

  function applySettings(next) {
    if (!next) return;
    const before = JSON.stringify(settings);
    const changedLook = ["Region", "Ticker", "Panel"].some((k) => next[k] !== undefined && next[k] !== settings[k]);
    settings = Object.assign({}, settings, next);
    if (settings.Language !== lang && TEXT[settings.Language]) {
      lang = settings.Language;
      renderStatic();
    }
    ticker.hidden = !settings.Ticker;
    panel.hidden = !settings.Panel;
    if (changedLook) resize();
    if (before !== JSON.stringify(settings)) renderPanel();
  }

  async function poll() {
    const t = performance.now();
    const elapsed = lastPoll ? (t - lastPoll) / 1000 : 1;
    lastPoll = t;
    const n = Math.max(1, Math.min(400, Math.round(Number(settings.PerSecond || 20) * Math.min(4, elapsed))));
    const wantStats = pollCount % 2 === 0;
    pollCount += 1;
    try {
      const body = await api(`api/scene?since=${seq}&n=${n}&stats=${wantStats ? 1 : 0}`);
      failures = 0;
      applySettings(body.settings);
      const first = seq < 0;
      if (Array.isArray(body.events) && body.events.length) {
        enqueue(body.events, body.now, first);
        lastEventSeen = performance.now();
      }
      if (typeof body.seq === "number") seq = body.seq;
      if (body.stats) {
        stats = body.stats;
        if (stats.liveFor && (!streamSince || Math.abs(Date.now() - stats.liveFor * 1000 - streamSince) > 120000)) {
          streamSince = Date.now() - stats.liveFor * 1000;
        }
        if (!stats.liveFor) streamSince = null;
        renderPanel();
        if (portrait && !panel.hidden && Math.abs(panel.getBoundingClientRect().top - layoutPanelTop) > 40) resize();
        else if (pollCount % 4 === 1) drawLabels();
      }
      const quietFor = performance.now() - lastEventSeen;
      if (body.state === "error") showNote(tx("error", { e: body.error || "?" }));
      else if (body.state !== "live" && quietFor > 2000) showNote(tx("connecting"));
      else if (quietFor > 15000) showNote(tx("quiet"));
      else showNote("");
      ready();
    } catch (error) {
      failures += 1;
      if (failures >= 3) showNote(error && error.message === "login" ? tx("login") : tx("unreachable"));
      if (failures >= 5) ready();
    }
    setTimeout(poll, failures ? Math.min(10000, 1000 * failures) : 1000);
  }

  // ------------------------------------------------------------ Start

  lang = TEXT[lang] ? lang : "en";
  settings.Language = lang;
  renderStatic();
  panel.hidden = !settings.Panel;
  ticker.hidden = !settings.Ticker;
  resize();
  requestAnimationFrame((t) => { lastFrame = t; frame(t); });
  poll();
})();
