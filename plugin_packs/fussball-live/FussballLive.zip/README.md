# Fußball Live

Fußball Live zeigt die aktuellen Ergebnisse, den Spieltag und die Tabelle deiner Ligen auf dem Rahmen: 1. Bundesliga, 2. Bundesliga und Champions League sind voreingestellt, 3. Liga, DFB-Pokal, Europa League, Conference League, Premier League, LaLiga, Serie A und Ligue 1 lassen sich dazuschalten.

Fußball Live besteht aus zwei Teilen, die zusammen installiert werden:

- **Die Szene Fußball Live** zeichnet die Spiele und die Tabelle. Jede gewählte Liga ist eine eigene Seite; die Seiten wechseln im eingestellten Takt.
- **Das Plugin** liest die Ergebnisse, hält alle Einstellungen und legt die Szene nach Zeitplan über die laufende Playlist.

## Einrichten

1. Paket installieren (Plugins > Hochladen, oder über den Store).
2. Auf der Plugins-Seite bei Fußball Live **Allow takeover** einschalten. Ohne das kann Fußball Live die Playlist nicht kurz beiseiteschieben.
3. **Fußball Live öffnen** und Ligen, Takt und Anzeigedauer wählen. Alles wird sofort gespeichert.
4. Zum Ausprobieren **Anzeigen** drücken.

## Wie die Szene über die Playlist kommt

Es gibt drei Wege, und sie lassen sich kombinieren:

- **Regelmäßig (Takeover):** Unter *Regelmäßig über die Playlist legen* stellst du ein, **wann** (immer, nur an Spieltagen, nur wenn ein Spiel läuft, oder nie), **alle wie viele Minuten** und **für wie viele Sekunden**. Fußball Live bittet den Rahmen dann um den Bildschirm, zeigt die Szene und gibt den Bildschirm danach zurück; die Playlist läuft an der Stelle weiter, an der sie war. Mit **Von/Bis Uhr** bleibt es z. B. nachts ruhig. Ein ausgeschalteter Bildschirm wird nie geweckt.
- **Bei einem Tor:** Wenn eingeschaltet, zeigt die Szene bei einem Tor sofort nur die Seite seiner Liga, so lange wie eingestellt. Auf Wunsch spielt der Rahmen dazu einen Ton (Torjubel, Torhupe oder ein eigener), sobald die Seite des Tores zu sehen ist. Tore werden bei laufenden Spielen alle 20 Sekunden abgefragt.
- **In einer Playlist:** Die Szene Fußball Live kann wie jedes Bild in eine Playlist; dann kommt sie in deren Reihenfolge dran (empfohlene Dauer 60 Sekunden). Mit *Eine Playlist dafür* legt das Plugin eine Playlist „Fußball Live“ für dich an.

Die Playlist **Fußball Live (takeover)** benutzt das Plugin selbst für die Übernahme. Lass sie ausgeschaltet; wird sie gelöscht, legt das Plugin sie neu an.

Tipp: Damit in einer Anzeige alle Ligen zu sehen sind, sollte *Für … Sekunden* mindestens *Ligen × Sekunden je Liga* sein. Die Plugin-Seite rechnet es dir vor.

## Was die Szene zeigt

- Kopf: Liga, Spieltag (bzw. Spieltermine), Anzahl der Live-Spiele, Uhrzeit und Stand der Daten.
- Je Spiel: Anstoß oder Spielminute, beide Vereine mit Wappen und das Ergebnis. Laufende Spiele sind rot markiert, mit dem letzten Torschützen, wenn die Quelle ihn kennt. Bei beendeten Bundesliga-Spielen steht der Halbzeitstand.
- Daneben (im Hochformat darunter) die Tabelle, mit den Vereinen, die gerade spielen, in Rot.
- Sehr viele Spiele (Champions League) werden zweispaltig gezeigt.
- Wer unter *Mein Verein* seinen Verein wählt, sieht dessen Wappen im Hintergrund der Szene und der Plugin-Seite. Auf Wunsch werden seine Vereinsfarben (von ESPN) zur Akzentfarbe statt der Farbe der Liga. Ist eine Vereinsfarbe zu dunkel für den dunklen Hintergrund, nimmt das Plugin die zweite.

## Automationen

Aktionen: **Anzeigen**, **Beenden**, **Umschalten**, **Jetzt aktualisieren**.

Ereignisse:

- **fussball_tor** mit liga, heim, gast, stand, torschuetze.
- **fussball_anzeige_gestartet** mit grund (show, zeitplan, tor).
- **fussball_anzeige_beendet** mit grund (fertig, abgebrochen, verdraengt, abgelaufen, fehlgeschlagen, gestoppt).

Der Overlay-Dienst **Live-Stand** liefert eine Zeile mit den laufenden Spielen, sonst das nächste Spiel.

## Woher die Daten kommen

- **OpenLigaDB** (api.openligadb.de) für 1., 2. und 3. Liga: Spieltag, Ergebnisse, Torschützen, Tabelle. Gemeinschaftlich gepflegt und frei. Die Spielminute nennt OpenLigaDB nicht; sie wird aus der Anstoßzeit geschätzt.
- **ESPN** (site.api.espn.com) für Champions League und alle anderen Wettbewerbe, und als Ersatz, wenn OpenLigaDB nicht antwortet. Das ist die öffentliche Schnittstelle der ESPN-Webseite, ohne Konto, aber nicht offiziell dokumentiert.

Gelesen wird alle 20 Sekunden, solange ein Spiel läuft (bremst eine Quelle, eine Viertelstunde lang nur jede Minute), jede Minute kurz vor Anstoß, alle 10 Minuten an Spieltagen und sonst jede halbe Stunde. Vereinswappen werden einmal geladen und auf dem Rahmen gespeichert.

## Wenn etwas nicht stimmt

- **Die Szene kommt nicht von selbst.** Ist *Allow takeover* an? Die Plugin-Seite sagt unter Status, warum nicht (Bildschirm aus, anderes Plugin hat den Bildschirm, außerhalb der Uhrzeiten, kein Spieltag …).
- **Unten rechts steht „Plugin nicht erreichbar – Notbetrieb“.** Die Szene liest dann 1., 2. Bundesliga und Champions League selbst, ohne Tabellen der anderen Ligen. Prüfe, ob das Plugin läuft.
- **„Stand“ oben rechts ist gelb.** Die Daten sind älter als 15 Minuten, meist weil die Quelle oder das Internet nicht antwortet. Die Szene zeigt den letzten Stand weiter.
- **Nach der Anzeige läuft die Playlist nicht weiter.** Das ist ein bekannter Fehler des Rahmens bei einem Quick Mix; das Plugin versucht ihn selbst zu beheben. Mit einer gespeicherten Playlist passiert es nicht.
- **Ohne laufende Playlist geht die Szene nicht wieder weg.** Lief vor der Anzeige keine Playlist, hält Fußball Live die Anzeige danach selbst an. Klappt das auf deinem Rahmen nicht, sagt es die Plugin-Seite, und die regelmäßige Anzeige wartet, bis wieder eine Playlist läuft.

## Ton bei einem Tor

Unter *Bei einem Tor* lässt sich **Ton abspielen** einschalten. Der Ton kommt aus dem Lautsprecher des Rahmens, einmal je Tor-Anzeige, und erst wenn die Szene die Seite des Tores fertig zeigt.

- Mitgeliefert sind **Torjubel** (echter Stadionjubel nach einem Tor) und **Torhupe** (Drucklufthorn). Beides sind echte Aufnahmen von freesound.org mit der Lizenz CC0 (gemeinfrei), gekürzt und in der Lautstärke angeglichen: Torjubel ist ["19 Football Crowd - Reaction To Goal"](https://freesound.org/people/D.jones/sounds/528799/) von D.jones, Torhupe ist ["S026_Airhorn_Bright_Sound_Mono"](https://freesound.org/people/P%C3%B3l/sounds/385922/) von Pól.
- **Eigenen Ton hochladen** nimmt WAV, MP3, OGG oder FLAC bis 5 MB. Eigene Töne liegen in `data/sounds/` und bleiben bei Updates erhalten. Am sichersten spielt der Rahmen WAV ab.
- **Lautstärke:** 0 lässt den Rahmen so laut, wie er ist. Ein anderer Wert stellt ihn für den Ton darauf und danach wieder zurück.
- **Auf dem Rahmen anhören** spielt den gewählten Ton sofort.
- Bleibt es still, steht auf der Plugin-Seite unter dem Ton, warum (zum Beispiel kein Abspielprogramm auf dem Rahmen).
