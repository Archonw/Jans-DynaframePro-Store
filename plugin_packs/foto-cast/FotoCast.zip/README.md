# Foto Cast

Foto Cast zeigt das Foto oder Video, das du gerade auf dem Handy anschaust, **sofort auf dem Rahmen**: auf dem iPhone und auf Android, ohne eigene App, auch aus WhatsApp. Ein Foto füllt ein paar Minuten lang den Bildschirm (einstellbar), ein Video spielt DynaFrame selbst einmal mit Ton ab, mehrere kurz hintereinander geschickte Fotos wechseln sich ab, Videos laufen nacheinander. Danach läuft die Playlist weiter.

Das Paket besteht aus zwei Teilen:

- **Das Plugin** nimmt Fotos und Videos im WLAN an (Port 8095), dreht Fotos wie aufgenommen, verkleinert sie auf Bildschirmgröße und hebt die letzten auf, damit man sie noch einmal zeigen kann. HEIC-Fotos vom iPhone liest es selbst. Videos (H.264, HEVC vom iPhone, VP9, AV1) gibt es an DynaFrames eigenen Player; seltene andere Formate wandelt es vorher mit ffmpeg in H.264 um, falls ffmpeg auf dem Rahmen ist.
- **Die Szene Foto Cast** zeigt die Fotos (ganzes Foto vor unscharfem Hintergrund oder bildschirmfüllend) und wird nur geholt, solange ein Foto zu sehen sein soll.

## Einrichten

1. Paket installieren (Store oder Plugins > Hochladen).
2. Auf der Plugins-Seite bei Foto Cast **Allow takeover** einschalten.
3. Plugin-Seite öffnen. Dort stehen die Wege aufs Handy, mit der Adresse des Rahmens schon eingetragen:
   - **Handy-Seite** `http://<rahmen>:8095/` (QR-Code auf der Plugin-Seite): Fotos wählen, fertig. Lässt sich auf den Home-Bildschirm legen.
   - **iPhone:** ein Kurzbefehl „Auf DynaFrame“ im Teilen-Menü der Fotos-App (Schritte auf der Plugin-Seite).
   - **Android:** die kostenlose App „HTTP Shortcuts“ trägt „Auf DynaFrame“ ins Teilen-Menü der Galerie ein (Schritte auf der Plugin-Seite).

## Für Bastler

- `POST http://<rahmen>:8095/upload?from=<Name>` mit dem Bild oder Video als Body (JPEG, PNG, WebP, GIF, HEIC, MP4, MOV, WebM) oder als `multipart/form-data` (auch mehrere Dateien, zusammen bis 400 MB; einzeln bis 2 GB). Antwort: `{"success": true, "ids": [...]}`.
- Ist auf der Plugin-Seite ein Code gesetzt: `&pin=<Code>` oder Header `X-Pin`.
- `POST /api/control` mit `{"action": "hide"}`, `{"action": "last"}` oder `{"action": "show", "id": "<id>"}`.

**Handys koppeln:** Ist „Handys erst koppeln“ an (bei neuen Installationen voreingestellt), nimmt der Rahmen nur Fotos von gekoppelten Handys an. Auf der Handy-Seite „Code auf dem Rahmen anzeigen“ tippen, den vierstelligen Code vom Rahmen eingeben, fertig. Danach zeigt die Handy-Seite den Link mit dem eigenen Schlüssel des Handys für Kurzbefehl oder HTTP Shortcuts. Gekoppelte Handys lassen sich auf der Plugin-Seite wieder entfernen.

Fotos und Videos bleiben nur auf dem Rahmen (Plugin-Ordner `data/photos`), höchstens so viele wie eingestellt.
