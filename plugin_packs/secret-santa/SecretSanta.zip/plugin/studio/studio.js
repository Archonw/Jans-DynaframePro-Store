"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/SecretSanta/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["Budget", "CountdownOnTv", "RevealStep", "DoneMinutes", "Volume", "PlaylistSeconds"];
const CHECK_FIELDS = ["SignupOpen", "Houses", "Messages", "SingleChain", "AvoidRepeat", "DrawOnTv", "RevealAuto", "Sound",
  "ShowQr", "Snow", "WakeScreen"];
const SELECT_FIELDS = ["Theme", "Currency"];
const TEXT_FIELDS = ["Title", "GiftDate", "GiftTime", "DrawDate", "DrawTime"];
let current = null;
let editing = false;
let langChangedAt = 0;

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["Secret Santa", "Secret Santa", "Secret Santa"],
  lede: ["Wichteln mit dem Rahmen: Alle melden sich am Handy mit einer Wunschliste an, der Rahmen lost geheim aus, und jeder sieht nur auf seinem eigenen Handy, wen er beschenkt. Der Fernseher zählt bis zur Bescherung herunter und deckt am Ende alle Paare mit Trommelwirbel auf. Nicht einmal diese Seite zeigt, wer wen gezogen hat. Jede Änderung hier wird sofort gespeichert.",
    "Secret Santa with your frame: everyone joins on their phone with a wish list, the frame draws in secret, and each person sees only on their own phone whom they give a present to. The TV counts down to gift-giving and at the end reveals all pairs with a drum roll. Not even this page shows who drew whom. Every change here is saved immediately.",
    "El amigo invisible con el marco: cada uno se apunta en su móvil con una lista de deseos, el marco hace el sorteo en secreto y cada persona ve solo en su propio móvil a quién le hace el regalo. La tele hace la cuenta atrás hasta la entrega y al final desvela todas las parejas con redoble de tambor. Ni siquiera esta página muestra a quién le ha tocado quién. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  statusTitle: ["Die Runde", "The round", "La ronda"],
  showNow: ["5 Minuten auf den Fernseher", "Show on the TV for 5 minutes", "5 minutos en la tele"],
  stopNow: ["Fernseher zurückgeben", "Give the TV back", "Devolver la tele"],
  factNow: ["Gerade", "Now", "Ahora"],
  factPeople: ["Dabei", "Taking part", "Participan"],
  factSeen: ["Los angesehen", "Looked at their lot", "Han mirado su papelito"],
  factReady: ["Geschenke besorgt", "Presents ready", "Regalos listos"],
  factGift: ["Bescherung", "Gift-giving", "Entrega"],
  factVersion: ["Version", "Version", "Versión"],
  phase_signup: ["Anmeldung", "Sign-up", "Inscripción"],
  phase_drawn: ["Ausgelost", "Drawn", "Sorteado"],
  phase_giving: ["Bescherung", "Gift-giving", "Entrega"],
  phase_reveal: ["Auflösung läuft", "Reveal running", "Revelación en marcha"],
  phase_done: ["Aufgelöst", "Revealed", "Desvelado"],
  onTv: [" · auf dem Fernseher", " · on the TV", " · en la tele"],
  offTv: [" · gerade nicht zu sehen", " · not on screen", " · no se ve ahora"],
  reason_manual: [" (bis {time})", " (until {time})", " (hasta las {time})"],
  reason_drawn: [" (Auslosung)", " (draw)", " (sorteo)"],
  reason_giving: [" (Countdown)", " (countdown)", " (cuenta atrás)"],
  reason_reveal: [" (Auflösung)", " (reveal)", " (revelación)"],
  waitTv: [" · wartet auf den Fernseher", " · waiting for the TV", " · esperando a la tele"],
  ofN: ["{n} von {m}", "{n} of {m}", "{n} de {m}"],
  todayLine: ["„{title}“ · Code {code}", "“{title}” · code {code}", "«{title}» · código {code}"],
  giftLeft: ["{when} (in {left})", "{when} (in {left})", "{when} (en {left})"],
  dLeft: ["{d} T. {h} Std.", "{d} d {h} h", "{d} d {h} h"],
  hLeft: ["{h} Std. {m} Min.", "{h} h {m} min", "{h} h {m} min"],
  servicesTitle: ["Verbindungen", "Connections", "Conexiones"],
  servicesCheck: ["Jetzt prüfen", "Check now", "Comprobar ahora"],
  servicesHint: ["Alles, was Secret Santa braucht. Das Plugin prüft es alle fünf Minuten selbst; rot heißt, etwas fehlt, gelb, dass es nur teilweise geht.",
    "Everything Secret Santa needs. The plugin checks it by itself every five minutes; red means something is missing, yellow that it only partly works.",
    "Todo lo que necesita Secret Santa. El plugin lo comprueba solo cada cinco minutos; rojo significa que falta algo, amarillo que solo funciona en parte."],
  servicesWait: ["Wird geprüft …", "Checking …", "Comprobando …"],
  servicesAllOk: ["Alles in Ordnung, zuletzt geprüft {time}.", "Everything fine, last checked {time}.", "Todo bien, última comprobación {time}."],
  servicesSome: ["Nicht alles in Ordnung, zuletzt geprüft {time}.", "Not everything is fine, last checked {time}.", "No todo está bien, última comprobación {time}."],
  svc_ok: ["in Ordnung", "fine", "bien"],
  svc_warn: ["teilweise", "partly", "en parte"],
  svc_bad: ["fehlt", "missing", "falta"],
  phoneTitle: ["Mitmachen am Handy", "Joining with the phone", "Apuntarse con el móvil"],
  phoneCode: ["Code {code} (steht auch auf dem Fernseher)", "Code {code} (also shown on the TV)", "Código {code} (también sale en la tele)"],
  newCode: ["Neuer Code", "New code", "Código nuevo"],
  phoneNoPort: ["Die Handy-Seite läuft nicht: kein freier Port. Trag unten einen Port ein.", "The phone page is not running: no free port. Enter a port below.", "La página del móvil no funciona: no hay puerto libre. Indica uno abajo."],
  signupOpen: ["Anmeldung offen (schließt beim Auslosen von selbst)", "Sign-up is open (closes by itself with the draw)", "Inscripción abierta (se cierra sola con el sorteo)"],
  houses: ["Nach dem Haushalt fragen (wer in einem Haushalt lebt, zieht sich nie gegenseitig)", "Ask for the household (people of one household never draw each other)", "Preguntar por el hogar (quienes viven juntos nunca se tocan entre sí)"],
  messages: ["Anonyme Fragen an das Wichtelkind", "Anonymous questions to the giftee", "Preguntas anónimas a quien recibe el regalo"],
  phoneHint: ["Der QR-Code auf dem Fernseher öffnet eine Seite dieses Plugins auf Port <b>8155</b> in eurem WLAN, mit dem Code schon eingetragen; keine App nötig. Jeder gibt seinen Namen ein, wählt eine vierstellige PIN und schreibt eine Wunschliste. Mit Name und PIN kann man auf jedem Handy wieder nachsehen. Nach dem Auslosen zeigt jedes Handy nur das eigene Los, und erst nach einem Tippen. Mit „Neuer Code“ gehen alte Links nicht mehr. Wenn du <b>Web Login</b> nutzt, erlaube dort Port 8155.",
    "The QR code on the TV opens a page of this plugin on port <b>8155</b> in your Wi-Fi, with the code filled in; no app needed. Everyone enters their name, picks a four-digit PIN and writes a wish list. With name and PIN they can look again on any phone. After the draw each phone shows only its own lot, and only after a tap. With “New code”, old links stop working. If you use <b>Web Login</b>, allow port 8155 there.",
    "El código QR de la tele abre una página de este plugin en el puerto <b>8155</b> de vuestra wifi, con el código ya puesto; sin app. Cada uno escribe su nombre, elige un PIN de cuatro cifras y una lista de deseos. Con nombre y PIN se puede volver a mirar en cualquier móvil. Tras el sorteo cada móvil muestra solo su propio papelito, y solo al tocarlo. Con «Código nuevo» los enlaces antiguos dejan de funcionar. Si usas <b>Web Login</b>, permite allí el puerto 8155."],
  roundTitle: ["Budget und Termine", "Budget and dates", "Presupuesto y fechas"],
  title: ["Name der Runde (auf dem Fernseher und den Handys)", "Name of the round (on the TV and the phones)", "Nombre de la ronda (en la tele y los móviles)"],
  titlePh: ["Wichteln 2026", "Secret Santa 2026", "Amigo invisible 2026"],
  budget: ["Budget pro Geschenk (0 = keins)", "Budget per present (0 = none)", "Presupuesto por regalo (0 = ninguno)"],
  giftDate: ["Bescherung am", "Gift-giving on", "Entrega el"],
  giftTime: ["um (Uhrzeit)", "at (time)", "a las (hora)"],
  drawDate: ["Von selbst auslosen am (leer = ich lose von Hand aus)", "Draw by itself on (empty = I draw by hand)", "Sortear solo el (vacío = sorteo a mano)"],
  drawTime: ["um (Uhrzeit)", "at (time)", "a las (hora)"],
  roundHint: ["Handys und Fernseher zählen bis zur Bescherung herunter. Das Budget sieht jeder neben seinem Los.",
    "The phones and the TV count down to gift-giving. The budget is shown to everyone next to their lot.",
    "Los móviles y la tele hacen la cuenta atrás hasta la entrega. Todos ven el presupuesto junto a su papelito."],
  peopleTitle: ["Wer macht mit", "Who takes part", "Quién participa"],
  peopleEmpty: ["Noch niemand. Scannt den QR-Code mit dem Handy.", "Nobody yet. Scan the QR code with your phone.", "Todavía nadie. Escanead el código QR con el móvil."],
  house: ["Haushalt: {h}", "Household: {h}", "Hogar: {h}"],
  hasWish: ["Wunschliste ✓", "Wish list ✓", "Lista de deseos ✓"],
  noWish: ["ohne Wunschliste", "no wish list", "sin lista de deseos"],
  seenYes: ["Los angesehen ✓", "Looked at lot ✓", "Ha mirado ✓"],
  seenNo: ["Los noch nicht angesehen", "Has not looked yet", "Aún no ha mirado"],
  readyYes: ["Geschenk besorgt ✓", "Present ready ✓", "Regalo listo ✓"],
  phones: ["{n} Handy(s)", "{n} phone(s)", "{n} móvil(es)"],
  offline: ["ohne Handy eingetragen", "added without phone", "añadido sin móvil"],
  edit: ["Ändern", "Change", "Cambiar"],
  remove: ["Entfernen", "Remove", "Quitar"],
  removeSureDrawn: ["Auslosung geht verloren!", "Undoes the draw!", "¡Se deshace el sorteo!"],
  newPin: ["Neue PIN (leer = behalten)", "New PIN (empty = keep)", "PIN nuevo (vacío = mantener)"],
  save: ["Speichern", "Save", "Guardar"],
  cancel: ["Abbrechen", "Cancel", "Cancelar"],
  pinHint: ["Eine neue PIN meldet die Person auf allen Handys ab. Sag ihr die neue PIN.", "A new PIN signs the person out on all phones. Tell them the new PIN.", "Un PIN nuevo cierra la sesión de esa persona en todos los móviles. Dile el PIN nuevo."],
  addTitle: ["Jemanden ohne Handy eintragen", "Add someone without a phone", "Añadir a alguien sin móvil"],
  addName: ["Name", "Name", "Nombre"],
  addPin: ["PIN (4 Ziffern, sag sie der Person)", "PIN (4 digits, tell it to them)", "PIN (4 cifras, díselo a esa persona)"],
  addHouse: ["Haushalt (freiwillig)", "Household (optional)", "Hogar (opcional)"],
  addWish: ["Wunschliste (freiwillig)", "Wish list (optional)", "Lista de deseos (opcional)"],
  addButton: ["Eintragen", "Add", "Añadir"],
  added: ["{name} ist dabei.", "{name} is in.", "{name} ya participa."],
  addHint: ["Für Oma oder die Kinder: Sie sehen ihr Los mit Name und PIN auf irgendeinem Handy nach, zum Beispiel auf deinem, während du wegschaust.",
    "For grandma or the kids: they look up their lot with name and PIN on any phone, for example on yours, while you look away.",
    "Para la abuela o los niños: miran su papelito con nombre y PIN en cualquier móvil, por ejemplo en el tuyo, mientras tú no miras."],
  drawTitle: ["Auslosen", "The draw", "El sorteo"],
  drawNow: ["Jetzt auslosen", "Draw now", "Sortear ahora"],
  drawAgain: ["Neu auslosen", "Draw again", "Volver a sortear"],
  drawSure: ["Wirklich auslosen?", "Really draw?", "¿Sortear de verdad?"],
  drawAgainSure: ["Alles neu mischen?", "Mix everything anew?", "¿Mezclar todo de nuevo?"],
  undraw: ["Auslosung zurücknehmen", "Undo the draw", "Deshacer el sorteo"],
  undrawSure: ["Wirklich zurücknehmen?", "Really undo?", "¿Deshacer de verdad?"],
  drawnLine: ["Ausgelost {time}: {n} Leute, {chains}.", "Drawn {time}: {n} people, {chains}.", "Sorteado {time}: {n} personas, {chains}."],
  oneChain: ["eine große Kette", "one big chain", "una gran cadena"],
  nChains: ["{n} Kreise", "{n} circles", "{n} círculos"],
  notDrawn: ["Noch nicht ausgelost. Es braucht mindestens drei Leute.", "Not drawn yet. It needs at least three people.", "Aún sin sortear. Hacen falta al menos tres personas."],
  drawAtLine: ["Noch nicht ausgelost. Der Rahmen lost von selbst am {when} aus.", "Not drawn yet. The frame draws by itself on {when}.", "Aún sin sortear. El marco sortea solo el {when}."],
  drawDone: ["Ausgelost. Jeder kann jetzt am Handy nachsehen.", "Drawn. Everyone can look on their phone now.", "Sorteado. Cada uno puede mirarlo ya en su móvil."],
  singleChain: ["Eine große Kette (A beschenkt B, B beschenkt C … zurück zu A), so wird die Auflösung eine lange Kette", "One big chain (A gives to B, B to C … back to A), so the reveal is one long chain", "Una gran cadena (A regala a B, B a C … y vuelta a A), así la revelación es una cadena larga"],
  avoidRepeat: ["Niemand zieht dieselbe Person wie in der letzten Runde", "Nobody draws the same person as last round", "Nadie saca a la misma persona que en la ronda anterior"],
  drawOnTv: ["Auslosung auf dem Fernseher zeigen (die Namen fliegen in eine Geschenkkiste)", "Show the draw on the TV (the names fly into a gift box)", "Mostrar el sorteo en la tele (los nombres vuelan a una caja de regalo)"],
  drawHint: ["Der Rahmen lost geheim aus. Weder diese Seite noch der Fernseher zeigen, wer wen gezogen hat; du siehst nur, wie viele ihr Los angesehen und ihr Geschenk haben. Machst du selbst mit, erfährst du es wie alle anderen auf deinem Handy. Neu auslosen oder nach dem Auslosen jemanden entfernen mischt alles neu.",
    "The frame draws in secret. Neither this page nor the TV shows who drew whom; you only see how many have looked at their lot and have their present. If you take part yourself, you find out like everyone else, on your phone. Drawing again or removing someone after the draw mixes everything anew.",
    "El marco sortea en secreto. Ni esta página ni la tele muestran a quién le ha tocado quién; solo ves cuántos han mirado su papelito y tienen su regalo. Si participas, te enteras como los demás, en tu móvil. Volver a sortear o quitar a alguien después del sorteo lo mezcla todo de nuevo."],
  revealTitle: ["Bescherung und Auflösung", "Gift-giving and the reveal", "Entrega y revelación"],
  revealNow: ["Auflösung starten", "Start the reveal", "Empezar la revelación"],
  revealSure: ["Jetzt allen zeigen?", "Show everyone now?", "¿Mostrarlo a todos ya?"],
  revealStop: ["Auflösung abbrechen", "Stop the reveal", "Parar la revelación"],
  revealRunning: ["Die Auflösung läuft bis {time}.", "The reveal runs until {time}.", "La revelación dura hasta las {time}."],
  revealDone: ["Aufgelöst. Die Handys zeigen jetzt auch, wer wessen Wichtel war.", "Revealed. The phones now also show who was whose Secret Santa.", "Desvelado. Los móviles ya muestran también quién era el amigo invisible de quién."],
  revealAutoLine: ["Die Auflösung startet von selbst zur Bescherung ({when}).", "The reveal starts by itself at gift-giving ({when}).", "La revelación empieza sola con la entrega ({when})."],
  revealHand: ["Die Auflösung startest du hier, wenn alle beisammen sind.", "You start the reveal here when everyone is together.", "La revelación la empiezas aquí cuando estéis todos juntos."],
  countdownOnTv: ["Countdown … Minuten vor der Bescherung auf den Fernseher holen (0 = nicht)", "Bring the countdown onto the TV … minutes before gift-giving (0 = not)", "Poner la cuenta atrás en la tele … minutos antes de la entrega (0 = no)"],
  revealStep: ["Sekunden je Paar in der Auflösung", "Seconds per pair in the reveal", "Segundos por pareja en la revelación"],
  doneMinutes: ["Danach alle Paare … Minuten zeigen", "Afterwards show all pairs for … minutes", "Después mostrar todas las parejas … minutos"],
  volume: ["Lautstärke für die Auflösung (0 = so lassen)", "Volume for the reveal (0 = leave as it is)", "Volumen para la revelación (0 = dejarlo como está)"],
  revealAuto: ["Auflösung zur Bescherung von selbst starten", "Start the reveal by itself at gift-giving time", "Empezar la revelación sola a la hora de la entrega"],
  sound: ["Mit Ton: Glöckchen, Trommelwirbel, Fanfare und Applaus", "With sound: bells, drum roll, fanfare and applause", "Con sonido: campanillas, redoble, fanfarria y aplausos"],
  testDrum: ["Trommelwirbel testen", "Test drum roll", "Probar redoble"],
  testTada: ["Fanfare testen", "Test fanfare", "Probar fanfarria"],
  testBells: ["Glöckchen testen", "Test bells", "Probar campanillas"],
  soundPlaying: ["Spielt auf dem Rahmen …", "Playing on the frame …", "Suena en el marco …"],
  revealHint: ["Die Auflösung geht Paar für Paar: „Wer war der Wichtel von Ben?“, Trommelwirbel, dann der Name. Dafür braucht es „Allow takeover“ für Secret Santa auf der Plugins-Seite, oder die Playlist läuft. Der Ton kommt vom Rahmen. Nach der Auflösung zeigt auch jedes Handy, wer der eigene Wichtel war.",
    "The reveal goes pair by pair: “Who was Secret Santa for Ben?”, a drum roll, then the name. It needs “Allow takeover” for Secret Santa on the Plugins page, or the playlist running. The sound plays from the frame. After the reveal every phone also shows who their Secret Santa was.",
    "La revelación va pareja a pareja: «¿Quién era el amigo invisible de Ben?», redoble y luego el nombre. Necesita «Allow takeover» para Secret Santa en la página de plugins, o que se esté reproduciendo la lista. El sonido sale del marco. Después, cada móvil muestra también quién era su amigo invisible."],
  newRoundTitle: ["Eine neue Runde", "A new round", "Una ronda nueva"],
  newRound: ["Neue Runde, dieselben Leute", "New round, same people", "Ronda nueva, mismas personas"],
  newRoundSure: ["Wirklich neu anfangen?", "Really start over?", "¿Empezar de nuevo de verdad?"],
  clearAll: ["Neue Runde, alle entfernen", "New round, remove everyone", "Ronda nueva, quitar a todos"],
  clearSure: ["Wirklich alle entfernen?", "Really remove everyone?", "¿Quitar a todos de verdad?"],
  newRoundHint: ["Eine neue Runde behält die Teilnehmer und ihre PINs, löscht aber die Auslosung, die Nachrichten und die Häkchen „Geschenk besorgt“. Der Rahmen merkt sich, wer wen hatte, damit beim nächsten Mal niemand dieselbe Person bekommt.",
    "A new round keeps the participants and their PINs but clears the draw, the messages and the “present ready” ticks. The frame remembers who had whom, so nobody gets the same person again next time.",
    "Una ronda nueva mantiene a los participantes y sus PIN, pero borra el sorteo, los mensajes y las marcas de «regalo listo». El marco recuerda quién tenía a quién para que la próxima vez a nadie le toque la misma persona."],
  historyLine: ["Frühere Runden: {list}", "Earlier rounds: {list}", "Rondas anteriores: {list}"],
  lookTitle: ["Auf dem Fernseher", "On the TV", "En la tele"],
  theme: ["Aussehen", "Look", "Aspecto"],
  themeCozy: ["Gemütlich rot", "Cosy red", "Rojo acogedor"],
  themeNight: ["Winternacht", "Winter night", "Noche de invierno"],
  showQr: ["QR-Code auf dem Fernseher zeigen", "Show the QR code on the TV", "Mostrar el código QR en la tele"],
  snow: ["Es schneit", "Let it snow", "Que nieve"],
  wakeScreen: ["Bildschirm für Auslosung und Auflösung einschalten", "Switch the screen on for the draw and the reveal", "Encender la pantalla para el sorteo y la revelación"],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „Secret Santa“ anlegen", "Create the playlist “Secret Santa”", "Crear la lista «Secret Santa»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la lista (segundos)"],
  playlistHint: ["Die Playlist enthält nur die Szene und ist eingeschaltet. Die Dauer gilt beim Anlegen; danach änderst du sie in der Playlist selbst. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist holds only the scene and is switched on. The duration applies when it is created; after that you change it in the playlist itself. You can also add the scene to any playlist yourself.",
    "La lista contiene solo la escena y está activada. La duración vale al crearla; después la cambias en la propia lista. También puedes añadir la escena tú mismo a cualquier lista."],
  sure: ["Wirklich?", "Sure?", "¿Seguro?"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status}).", "Error (HTTP {status}).", "Error (HTTP {status})."],
  oclock: ["{time} Uhr", "{time}", "{time}"],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."]
};

const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "";

const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[1]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "en";
  if (chosen === lang && document.documentElement.dataset.applied === chosen) return;
  lang = chosen;
  document.documentElement.dataset.applied = lang;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  el("people").dataset.empty = t("peopleEmpty");
  peopleKey = "";
  if (current) render(current);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}
const post = (path, body = {}) => api(path, { method: "POST", body: JSON.stringify(body) });

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(epoch) {
  if (!epoch) return "—";
  const date = new Date(epoch * 1000);
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}
const longWhen = (epoch) => new Date(epoch * 1000).toLocaleString(LOCALES[lang], { weekday: "short", day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" });

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await post("./api/settings", changes);
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

// Knöpfe, die etwas Endgültiges tun: erst „Wirklich?“, dann noch einmal tippen.
function confirmClick(button, action) {
  if (button.classList.contains("confirm")) {
    button.classList.remove("confirm");
    button.textContent = button.dataset.label || button.textContent;
    action();
    return;
  }
  button.dataset.label = button.textContent;
  button.classList.add("confirm");
  button.textContent = button.dataset.sure ? t(button.dataset.sure) : t("sure");
  setTimeout(() => {
    if (!button.isConnected || !button.classList.contains("confirm")) return;
    button.classList.remove("confirm");
    button.textContent = button.dataset.label;
  }, 4000);
}

// ------------------------------------------------------------ Verbindungen

function renderServices(sv) {
  if (!sv || !sv.rows || !sv.rows.length) return;
  el("servicesList").innerHTML = sv.rows.map((r) => `<li class="svc ${esc(r.state)}"><span class="dot"></span>
    <div><b>${esc(r.name)}</b> <span class="tag">${esc(t("svc_" + r.state))}</span><div class="txt">${esc(r.text)}</div>
    ${r.hint && r.state !== "ok" ? `<div class="hint2">${esc(r.hint)}</div>` : ""}</div></li>`).join("");
  if (el("servicesNote").dataset.sticky) return;
  const time = clock(sv.at);
  setStatus(sv.bad || sv.warn ? t("servicesSome", { time }) : t("servicesAllOk", { time }),
    sv.bad ? "bad" : sv.warn ? "" : "ok", "servicesNote");
}
el("servicesButton").addEventListener("click", async () => {
  const button = el("servicesButton");
  button.disabled = true;
  el("servicesNote").dataset.sticky = "1";
  setStatus(t("servicesWait"), "busy", "servicesNote");
  try {
    const result = await api("./api/services");
    delete el("servicesNote").dataset.sticky;
    renderServices(result.services);
  } catch (error) {
    delete el("servicesNote").dataset.sticky;
    setStatus(error.message, "bad", "servicesNote");
  }
  button.disabled = false;
});

// ------------------------------------------------------------ Handy

let qrFor = "";
function renderPhone(state) {
  const url = state.phoneUrl;
  el("phoneBox").hidden = !url;
  if (url) {
    const link = `${url}?c=${state.code}`;
    el("phoneUrl").href = link;
    el("phoneUrl").textContent = url.replace(/^https?:\/\//, "").replace(/\/$/, "");
    el("phoneCode").textContent = t("phoneCode", { code: state.code });
    if (link !== qrFor && typeof qrcode === "function") {
      qrFor = link;
      const qr = qrcode(0, "M");
      qr.addData(link);
      qr.make();
      el("phoneQr").innerHTML = qr.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
    }
  }
  setStatus(url ? "" : t("phoneNoPort"), url ? "" : "bad", "phoneNote");
}

// ------------------------------------------------------------ Teilnehmer

let peopleKey = "";
let editingPerson = "";
function renderPeople(state) {
  const key = JSON.stringify([state.people, state.stats.drawn, state.settings.Houses, editingPerson, lang]);
  if (key === peopleKey) return;
  if (el("people").contains(document.activeElement)) return;     // nicht unter den Fingern neu bauen
  peopleKey = key;
  const drawn = state.stats.drawn;
  el("people").innerHTML = state.people.map((p) => {
    const meta = [];
    if (p.house) meta.push(esc(t("house", { h: p.house })));
    meta.push(p.wish ? `<span class="yes">${esc(t("hasWish"))}</span>` : esc(t("noWish")));
    if (drawn) {
      meta.push(p.seen ? `<span class="yes">${esc(t("seenYes"))}</span>` : esc(t("seenNo")));
      if (p.ready) meta.push(`<span class="yes">${esc(t("readyYes"))}</span>`);
    }
    meta.push(esc(p.offline ? t("offline") : t("phones", { n: p.phones })));
    const edit = editingPerson === p.id ? `<div class="edit">
        ${drawn ? "" : `<label class="field"><span>${esc(t("addName"))}</span><input type="text" data-f="name" maxlength="40" value="${esc(p.name)}"></label>`}
        ${drawn || !state.settings.Houses ? "" : `<label class="field"><span>${esc(t("addHouse"))}</span><input type="text" data-f="house" maxlength="40" value="${esc(p.house)}"></label>`}
        ${p.offline ? `<label class="field"><span>${esc(t("addWish"))}</span><input type="text" data-f="wish" maxlength="800" value="${esc(p.wishText)}"></label>` : ""}
        <label class="field"><span>${esc(t("newPin"))}</span><input type="text" data-f="pin" maxlength="4" inputmode="numeric"></label>
        <div class="card-actions left"><button type="button" data-act="save">${esc(t("save"))}</button>
        <button type="button" class="secondary" data-act="cancel">${esc(t("cancel"))}</button></div>
        <p class="hint">${esc(t("pinHint"))}</p></div>` : "";
    return `<div class="person" data-id="${esc(p.id)}"><div><b>${esc(p.name)}</b><div class="meta">${meta.map((m) => `<span>${m}</span>`).join("")}</div></div>
      <div class="acts"><button type="button" class="secondary" data-act="edit">${esc(t("edit"))}</button>
      <button type="button" class="secondary danger" data-act="remove" data-sure="${drawn ? "removeSureDrawn" : "sure"}">${esc(t("remove"))}</button></div>${edit}</div>`;
  }).join("");
}
el("people").addEventListener("click", (e) => {
  const button = e.target.closest("button[data-act]");
  if (!button) return;
  const row = button.closest(".person");
  const id = row.dataset.id;
  const act = button.dataset.act;
  if (act === "edit") { editingPerson = editingPerson === id ? "" : id; peopleKey = ""; render(current); return; }
  if (act === "cancel") { editingPerson = ""; peopleKey = ""; render(current); return; }
  if (act === "remove") {
    confirmClick(button, async () => {
      try { await post("./api/person/remove", { id }); setStatus("", "", "peopleNote"); }
      catch (error) { setStatus(error.message, "bad", "peopleNote"); }
      refresh();
    });
    return;
  }
  if (act === "save") {
    const body = { id };
    row.querySelectorAll("[data-f]").forEach((input) => { body[input.dataset.f] = input.value; });
    if (!body.pin) delete body.pin;
    post("./api/person/update", body).then(() => {
      editingPerson = "";
      peopleKey = "";
      setStatus(t("saved"), "ok", "peopleNote");
      refresh();
    }).catch((error) => setStatus(error.message, "bad", "peopleNote"));
  }
});
el("addButton").addEventListener("click", async () => {
  const name = el("addName").value.trim();
  try {
    await post("./api/person/add", { name, pin: el("addPin").value.trim(), house: el("addHouse").value, wish: el("addWish").value });
    for (const id of ["addName", "addPin", "addHouse", "addWish"]) el(id).value = "";
    setStatus(t("added", { name }), "ok", "peopleNote");
    refresh();
  } catch (error) {
    setStatus(error.message, "bad", "peopleNote");
  }
});

// ------------------------------------------------------------ Gesamtbild

function leftText(epoch, nowS) {
  let left = Math.max(0, epoch - nowS);
  const d = Math.floor(left / 86400); left -= d * 86400;
  const h = Math.floor(left / 3600); left -= h * 3600;
  const m = Math.floor(left / 60);
  return d ? t("dLeft", { d, h }) : t("hLeft", { h, m });
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  if (Date.now() - langChangedAt > 6000 || s.Language === lang) applyLanguage(s.Language);
  if (window.PortBlock) PortBlock.render(state.port, lang);
  const st = state.stats;
  let now = t("phase_" + state.mode) + (state.sceneVisible ? t("onTv") : t("offTv"));
  if (state.takeover) now += t("reason_" + state.takeover, { time: clock(state.takeoverUntil) });
  else if (state.takeoverWanted) now += t("waitTv");
  el("factNow").textContent = now;
  el("factPeople").textContent = String(st.count);
  el("factSeen").textContent = st.drawn ? t("ofN", { n: st.seen, m: st.count }) : "—";
  el("factReady").textContent = st.drawn ? t("ofN", { n: st.ready, m: st.count }) : "—";
  el("factGift").textContent = state.gift ? (state.gift > state.now ? t("giftLeft", { when: longWhen(state.gift), left: leftText(state.gift, state.now) }) : longWhen(state.gift)) : "—";
  el("factVersion").textContent = state.version;
  el("todayLine").textContent = t("todayLine", { title: state.title, code: state.code });
  el("showButton").hidden = Boolean(state.takeover || state.takeoverWanted);
  el("stopButton").hidden = !(state.takeover || state.takeoverWanted);
  setStatus(state.takeoverNote || "", state.takeoverNote ? "bad" : "");
  renderServices(state.services);
  renderPhone(state);
  renderPeople(state);
  el("addHouseField").hidden = !s.Houses;

  // Auslosen
  const draw = el("drawButton");
  if (!draw.classList.contains("confirm")) {
    draw.textContent = t(st.drawn ? "drawAgain" : "drawNow");
    draw.dataset.sure = st.drawn ? "drawAgainSure" : "drawSure";
  }
  draw.disabled = st.count < 3 || Boolean(state.reveal);
  el("undrawButton").hidden = !st.drawn || Boolean(state.reveal);
  el("drawLine").textContent = st.drawn
    ? t("drawnLine", { time: clock(st.drawnAt), n: st.count, chains: st.chains === 1 ? t("oneChain") : t("nChains", { n: st.chains }) })
    : state.drawAt && state.drawAt > state.now ? t("drawAtLine", { when: longWhen(state.drawAt) }) : t("notDrawn");
  if (!el("drawNote").dataset.sticky) setStatus(state.drawNote.text || "", state.drawNote.tone || "", "drawNote");

  // Auflösung
  el("revealButton").disabled = !st.drawn || state.mode === "reveal";
  el("revealStop").hidden = state.mode !== "reveal";
  el("revealLine").textContent = state.mode === "reveal" ? t("revealRunning", { time: clock(state.reveal.end) })
    : state.mode === "done" ? t("revealDone")
      : s.RevealAuto && state.gift ? t("revealAutoLine", { when: longWhen(state.gift) }) : t("revealHand");
  el("historyLine").textContent = state.history.length
    ? t("historyLine", { list: state.history.slice(-4).map((h) => `${h.title} (${h.count})`).join(" · ") }) : "";

  if (document.activeElement !== el("MakePlaylist")) el("MakePlaylist").value = String(Boolean(s.MakePlaylist));
  el("playlistNote").textContent = state.ownPlaylist || "";
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Secret Santa ${state.version}] `);

  if (!editing) {
    for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) el(name).value = String(s[name]);
    el("Language").value = lang;
  }
  el("DrawTime").disabled = !s.DrawDate;
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
}
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
for (const name of TEXT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));
el("Language").addEventListener("change", (e) => {
  const chosen = e.target.value;
  langChangedAt = Date.now();
  if (current) current.settings.Language = chosen;
  applyLanguage(chosen);
  save({ Language: chosen });
});

async function action(path, body, note = "statusNote") {
  try {
    const result = await post(path, body);
    if (result.note) setStatus(result.note, "", note);
    else if (note !== "statusNote") setStatus("", "", note);
    await refresh();
    return result;
  } catch (error) {
    setStatus(error.message, "bad", note);
    return null;
  }
}
el("showButton").addEventListener("click", () => action("./api/show", { minutes: 5 }));
el("stopButton").addEventListener("click", () => action("./api/stop"));
el("codeButton").addEventListener("click", () => action("./api/code", {}, "phoneNote"));
el("drawButton").addEventListener("click", (e) => confirmClick(e.currentTarget, async () => {
  const result = await action("./api/draw", {}, "drawNote");
  if (result && !result.note) setStatus(t("drawDone"), "ok", "drawNote");
}));
el("undrawButton").addEventListener("click", (e) => confirmClick(e.currentTarget, () => action("./api/undraw", {}, "drawNote")));
el("revealButton").addEventListener("click", (e) => confirmClick(e.currentTarget, () => action("./api/reveal", {}, "revealNote")));
el("revealStop").addEventListener("click", () => action("./api/reveal/stop", {}, "revealNote"));
el("newRound").addEventListener("click", (e) => confirmClick(e.currentTarget, () => action("./api/newround", {}, "revealNote")));
el("clearAll").addEventListener("click", (e) => confirmClick(e.currentTarget, () => action("./api/newround", { clear: true }, "revealNote")));
for (const button of document.querySelectorAll("[data-cue]")) {
  button.addEventListener("click", async () => {
    setStatus(t("soundPlaying"), "busy", "revealNote");
    const result = await action("./api/sound", { name: button.dataset.cue }, "revealNote");
    if (result) setTimeout(() => setStatus("", "", "revealNote"), 4000);
  });
}

applyLanguage(document.documentElement.lang);
refresh();
setInterval(refresh, 4000);
