/* Solar System Live – die Szene.
 *
 * Alle Planeten an ihrem echten Ort von heute (Astronomy Engine, lokal gerechnet), mit
 * Monden, Raumsonden und Kometen. Die Kamera fliegt langsam von Planet zu Planet.
 * Himmelsereignisse (Finsternisse, Oppositionen, Konjunktionen …) kündigt die Szene an,
 * zeigt sie vorher im Zeitraffer und während sie passieren live.
 *
 * Look: Miniatur-/Modellbau – gemalte Kugeln unter einer Lampe (der Sonne), weiche
 * Schatten, Schärfentiefe wie bei einer Kamera auf einem Modell, Vignette.
 *
 * Maßstab: Richtungen echt, Abstände von der Sonne logarithmisch gestaucht, Größen
 * übertrieben. Finsternisse werden dagegen in echter Geometrie (km) gerechnet: Die
 * Schatten auf Erde und Mond liegen genau dort, wo sie wirklich liegen.
 *
 * Zum Ausprobieren: ?plugin=<URL der Plugin-Seite> &lang=de|en|es &demo=1 (ohne Plugin)
 * &stop=<id> (Kamera bleibt dort: sun, earth, saturn, overview-inner, voyager1, event …)
 * &event=lunar|solar|<Ereignis-id> &progress=0..1 (Zeitraffer anhalten) &t=<ISO-Zeit>
 * &tier=pi4|pi5|high &scale=0.7 &lat=52.5&lon=13.4 &still=1 &portrait=1
 */
import * as THREE from "./lib/three.module.min.js";

const A = window.Astronomy;
const TEXT = window.SSL_TEXT;
const PLUGIN_ID = "SolarSystemLive";
const params = new URLSearchParams(location.search);
const DEMO = params.get("demo") === "1";
const STILL = params.get("still") === "1";
const FIXED_STOP = params.get("stop") || "";
const TIME_OFFSET = params.get("t") ? Date.parse(params.get("t")) - Date.now() : 0;
const DEG = Math.PI / 180;
const AU_KM = 149597870.7;
const DAY_MS = 86400000;

// ------------------------------------------------------------------ Plugin erreichen
const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
const sameOrigin = (location.protocol === "http:" && (location.port === "" || location.port === "80"))
  || (location.protocol === "https:" && (location.port === "" || location.port === "443"));
// Über die Weboberfläche (80/443, auch RemoteFrame über HTTPS) nur derselbe Ursprung: :8003 ist dort per Firewall gesperrt
// und würde jede Anfrage bis zum Timeout hängen lassen.
const pluginBases = params.get("plugin") ? [params.get("plugin").replace(/\/?$/, "/")]
  : sameOrigin ? [`${location.origin}${advanced}`]
  : [...new Set([`${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`, `http://${location.hostname || "localhost"}${advanced}`])];
let baseIndex = 0, baseFound = false;

async function api(path, timeoutMs = 12000) {
  let lastError = null;
  const tries = baseFound ? 1 : pluginBases.length;   // hat eine Adresse einmal geklappt, bleibt es bei ihr
  for (let i = 0; i < tries; i += 1) {
    const base = pluginBases[(baseIndex + i) % pluginBases.length];
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), timeoutMs);
    try {
      const response = await fetch(base + path, { cache: "no-store", credentials: "same-origin", signal: ctl.signal });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const body = await response.json();
      baseIndex = (baseIndex + i) % pluginBases.length;
      baseFound = true;
      return body;
    } catch (error) {
      lastError = error;
    } finally {
      clearTimeout(timer);
    }
  }
  throw lastError || new Error("unreachable");
}

function report(message) {
  if (DEMO) { console.log("report:", message); return; }
  api("api/report?m=" + encodeURIComponent(String(message).slice(0, 300))).catch(() => {});
}
window.addEventListener("error", (e) => report(`JS: ${e.message} (${(e.filename || "").split("/").pop()}:${e.lineno})`));

let readySent = false;
function ready() {
  if (readySent) return;
  readySent = true;
  try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
}
setTimeout(ready, 8000);

// ------------------------------------------------------------------ Einstellungen
const DEFAULTS = {
  Language: params.get("lang") || "de", Labels: true, Panel: true, Orbits: true, Belts: true, Blur: "normal",
  Quality: "auto", StopSeconds: 30, ShowSun: true, ShowInner: true, ShowOuter: true, ShowDwarf: true, ShowMoons: true,
  ShowProbes: true, ShowComets: true, ShowOverview: true, LeadDays: 7, Preview: true, Banner: true,
  Lat: params.get("lat") ? Number(params.get("lat")) : null, Lon: params.get("lon") ? Number(params.get("lon")) : null,
  PlaceName: ""
};
let cfg = Object.assign({}, DEFAULTS);
let lang = cfg.Language;
const T = () => TEXT[lang] || TEXT.en;
const tx = (key) => T()[key] ?? TEXT.en[key] ?? key;
const nameOf = (id) => T().names[id] || TEXT.en.names[id] || id;
const fmt = (s, v) => String(s).replace(/\{(\w+)\}/g, (_, k) => (v[k] ?? ""));

// ------------------------------------------------------------------ Hilfen
const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const lerp = (a, b, k) => a + (b - a) * k;
const ease = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
const smoothstep = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };

const ROT_EQJ_ECL = A.Rotation_EQJ_ECL();
// EQJ-Vektor (AE) -> Welt (Ekliptik: x -> X, y -> -Z, z -> Y)
function eqjToEcl(v) {
  const r = ROT_EQJ_ECL.rot;
  return [r[0][0] * v.x + r[1][0] * v.y + r[2][0] * v.z,
    r[0][1] * v.x + r[1][1] * v.y + r[2][1] * v.z,
    r[0][2] * v.x + r[1][2] * v.y + r[2][2] * v.z];
}
const eclToWorld = (e, out = new THREE.Vector3()) => out.set(e[0], e[2], -e[1]);
// gestauchter Abstand: Sonne 0, Merkur 11.6, Erde 20.5, Jupiter 40.7, Neptun 64.6
const visR = (au) => 14 * Math.log(1 + au / 0.3);
function helioWorld(ecl, out = new THREE.Vector3()) {
  const r = Math.hypot(ecl[0], ecl[1], ecl[2]);
  if (r < 1e-9) return out.set(0, 0, 0);
  const k = visR(r) / r;
  return out.set(ecl[0] * k, ecl[2] * k, -ecl[1] * k);
}
// Sichtgröße aus echtem Radius (km)
const visSize = (km) => Math.max(0.035, 0.35 * Math.pow(km / 6371, 0.45));
// Pol aus RA/Dec (Grad, J2000) -> Weltvektor
function poleWorld(raDeg, decDeg) {
  const ra = raDeg * DEG, de = decDeg * DEG;
  const e = eqjToEcl({ x: Math.cos(de) * Math.cos(ra), y: Math.cos(de) * Math.sin(ra), z: Math.sin(de) });
  return eclToWorld(e).normalize();
}

let simNow = Date.now() + TIME_OFFSET;   // ms
const atime = (ms) => A.MakeTime(new Date(ms));

// ------------------------------------------------------------------ Körper (Daten)
const PLANETS = [
  // id, Body, Radius km, Pol RA/Dec, Rotation h, Jahr d, Tag (Text), Monde
  { id: "mercury", body: "Mercury", km: 2440, pole: [281.01, 61.42], rot: 1407.6, year: 87.97, moons: 0, tex: "mercury" },
  { id: "venus", body: "Venus", km: 6052, pole: [272.76, 67.16], rot: -5832.5, year: 224.7, moons: 0, tex: "venus" },
  { id: "earth", body: "Earth", km: 6371, pole: null, rot: 23.934, year: 365.256, moons: 1, tex: "earth" },
  { id: "mars", body: "Mars", km: 3390, pole: [317.68, 52.89], rot: 24.623, year: 686.98, moons: 2, tex: "mars" },
  { id: "jupiter", body: "Jupiter", km: 69911, pole: [268.06, 64.5], rot: 9.925, year: 4332.6, moons: "95+", tex: "jupiter" },
  { id: "saturn", body: "Saturn", km: 58232, pole: [40.59, 83.54], rot: 10.656, year: 10759, moons: "270+", tex: "saturn" },
  { id: "uranus", body: "Uranus", km: 25362, pole: [257.31, -15.18], rot: -17.24, year: 30687, moons: 28, tex: "uranus" },
  { id: "neptune", body: "Neptune", km: 24622, pole: [299.36, 43.46], rot: 16.11, year: 60190, moons: 16, tex: "neptune" },
  { id: "pluto", body: "Pluto", km: 1188, pole: [132.99, -6.16], rot: -153.3, year: 90560, moons: 5, tex: "pluto", dwarf: true }
];
// vereinfachte Monde: Abstand km, Umlauf d (negativ = rückläufig), Radius km, Startwinkel
const SIMPLE_MOONS = {
  mars: [["phobos", 9376, 0.31891, 11, 0, "dark"], ["deimos", 23463, 1.26244, 6, 120, "dark"]],
  saturn: [["mimas", 185539, 0.9424, 198, 10, "ice"], ["enceladus", 237948, 1.3702, 252, 80, "ice"],
    ["tethys", 294619, 1.8878, 531, 150, "ice"], ["dione", 377396, 2.7369, 561, 220, "ice"],
    ["rhea", 527108, 4.5182, 764, 300, "ice"], ["titan", 1221870, 15.945, 2575, 40, "titan"],
    ["iapetus", 3560820, 79.32, 734, 200, "dark"]],
  uranus: [["miranda", 129390, 1.4135, 236, 0, "ice"], ["ariel", 191020, 2.5204, 579, 90, "ice"],
    ["umbriel", 266000, 4.1442, 585, 200, "dark"], ["titania", 435910, 8.7059, 789, 270, "ice"],
    ["oberon", 583520, 13.4632, 761, 30, "ice"]],
  neptune: [["triton", 354759, -5.8769, 1353, 60, "ice"]],
  pluto: [["charon", 19591, 6.3872, 606, 0, "ice"]]
};
const MOON_EPOCH = Date.UTC(2026, 0, 1);
const RING_IN = 1.24, RING_OUT = 2.27;

// ------------------------------------------------------------------ Renderer und Qualität
const canvas = document.getElementById("gl");
let renderer;
try {
  renderer = new THREE.WebGLRenderer({ canvas, antialias: false, alpha: false, powerPreference: "high-performance", stencil: false });
} catch (error) {
  document.getElementById("note").hidden = false;
  document.getElementById("note").textContent = "WebGL2: " + error.message;
  report("WebGL2: " + error.message);
  ready();
  throw error;
}
renderer.outputColorSpace = THREE.LinearSRGBColorSpace;
renderer.setClearColor(0x020308, 1);
const glInfo = (() => {
  try {
    const gl = renderer.getContext();
    const ext = gl.getExtension("WEBGL_debug_renderer_info");
    return String(ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER));
  } catch (_) { return ""; }
})();
const TIERS = {
  pi4: { scale: 0.6, min: 0.4, max: 0.75, seg: 40, stars: 2200, belt: 1400, taps: 10, target: 28 },
  pi5: { scale: 0.8, min: 0.5, max: 1.0, seg: 56, stars: 4000, belt: 2600, taps: 14, target: 40 },
  high: { scale: 1.0, min: 0.6, max: 1.0, seg: 64, stars: 6000, belt: 4000, taps: 16, target: 50 }
};
function detectTier() {
  const q = params.get("tier") || cfg.Quality;
  if (TIERS[q]) return q;
  if (/V3D\s*4/i.test(glInfo) || /VideoCore\s*VI\b/i.test(glInfo)) return "pi4";
  if (/V3D\s*7/i.test(glInfo) || /VideoCore\s*VII/i.test(glInfo)) return "pi5";
  if (/llvmpipe|softpipe|swiftshader|mali|adreno 3/i.test(glInfo)) return "pi4";
  return "high";
}
let tierName = detectTier();
let tier = TIERS[tierName];
let scale = tier.scale;
try {
  const stored = Number(localStorage.getItem("ssl-scale-" + tierName));
  if (stored >= tier.min && stored <= tier.max) scale = stored;
} catch (_) { /* egal */ }
if (params.get("scale")) scale = Number(params.get("scale"));

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(40, 16 / 9, 0.05, 6000);
let W = 0, H = 0, portrait = false;
const depthTex = new THREE.DepthTexture(4, 4);
depthTex.type = THREE.UnsignedIntType;
const rt = new THREE.WebGLRenderTarget(4, 4, { depthTexture: depthTex, depthBuffer: true, type: THREE.UnsignedByteType, samples: params.get("msaa") === "0" ? 0 : 4 });

function resize() {
  const dpr = Math.min(window.devicePixelRatio || 1, 1.25);
  const w = Math.max(2, Math.round(window.innerWidth * dpr * scale));
  const h = Math.max(2, Math.round(window.innerHeight * dpr * scale));
  portrait = params.get("portrait") === "1" || window.innerHeight > window.innerWidth * 1.05;
  document.body.classList.toggle("portrait", portrait);
  camera.fov = portrait ? 58 : 40;
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  if (w === W && h === H) return;
  W = w; H = h;
  renderer.setPixelRatio(1);
  renderer.setSize(w, h, false);
  rt.setSize(w, h);
  post.uniforms.res.value.set(w, h);
}

// ------------------------------------------------------------------ Shader
const NOISE_GLSL = `
float h3(vec3 p){ p = fract(p*0.3183099+.1); p*=17.0; return fract(p.x*p.y*p.z*(p.x+p.y+p.z)); }
float n3(vec3 x){ vec3 i=floor(x); vec3 f=fract(x); f=f*f*(3.0-2.0*f);
  return mix(mix(mix(h3(i+vec3(0,0,0)),h3(i+vec3(1,0,0)),f.x),mix(h3(i+vec3(0,1,0)),h3(i+vec3(1,1,0)),f.x),f.y),
             mix(mix(h3(i+vec3(0,0,1)),h3(i+vec3(1,0,1)),f.x),mix(h3(i+vec3(0,1,1)),h3(i+vec3(1,1,1)),f.x),f.y),f.z); }
float fbm3(vec3 p){ float s=0.0, a=0.5; for(int i=0;i<4;i++){ s+=a*n3(p); p*=2.03; a*=0.5; } return s; }`;

const ECLIPSE_GLSL = `
float angBetween(vec3 a, vec3 b){ return 2.0*asin(clamp(length(normalize(a)-normalize(b))*0.5, 0.0, 1.0)); }
// Anteil der Scheibe r1 (Sonne), den die Scheibe r2 im Abstand d verdeckt
float overlapFrac(float r1, float r2, float d){
  if (d >= r1 + r2) return 0.0;
  if (d <= abs(r2 - r1)) return r2 >= r1 ? 1.0 : (r2*r2)/(r1*r1);
  float a = clamp((d*d + r1*r1 - r2*r2)/(2.0*d*r1), -1.0, 1.0);
  float b = clamp((d*d + r2*r2 - r1*r1)/(2.0*d*r2), -1.0, 1.0);
  float k = (-d+r1+r2)*(d+r1-r2)*(d-r1+r2)*(d+r1+r2);
  float ar = r1*r1*acos(a) + r2*r2*acos(b) - 0.5*sqrt(max(0.0, k));
  return clamp(ar/(3.14159265*r1*r1), 0.0, 1.0);
}`;

const PLANET_VS = `
varying vec3 vN; varying vec3 vW; varying vec2 vUv;
void main(){
  vUv = uv;
  vec4 w = modelMatrix * vec4(position, 1.0);
  vW = w.xyz;
  vN = normalize(mat3(modelMatrix) * normal);
  gl_Position = projectionMatrix * viewMatrix * w;
}`;

const PLANET_FS = `
precision highp float;
uniform sampler2D map; uniform sampler2D clouds; uniform sampler2D ringMap;
uniform vec3 centerW; uniform float radiusW; uniform float ambient; uniform float time;
uniform int mode;            // 0 normal, 1 Erde, 2 Mond, 3 Saturn
uniform vec3 sunG; uniform vec3 moonG;   // geozentrisch, km, Weltachsen
uniform vec3 ringN; uniform float cloudShift; uniform vec3 atmo; uniform float atmoK; uniform float highlight;
varying vec3 vN; varying vec3 vW; varying vec2 vUv;
${ECLIPSE_GLSL}
void main(){
  vec3 N = normalize(vN);
  vec3 L = normalize(-vW);                 // Sonne im Ursprung
  vec3 V = normalize(cameraPosition - vW);
  vec3 base = texture2D(map, vUv).rgb;
  float nl = dot(N, L);
  float diff = clamp((nl + 0.08) / 1.08, 0.0, 1.0);
  diff = diff * diff * (3.0 - 2.0 * diff);
  float shade = 1.0;
  vec3 extra = vec3(0.0);
  if (mode == 1) {
    // Erde: Wolken, Meer glänzt, Mondschatten in echter Geometrie
    vec3 p = normalize(vW - centerW) * 6371.0;
    vec3 s = sunG - p; vec3 m = moonG - p;
    float rs = asin(clamp(696000.0/length(s), 0.0, 1.0));
    float rm = asin(clamp(1737.4/length(m), 0.0, 1.0));
    float f = overlapFrac(rs, rm, angBetween(s, m));
    shade *= 1.0 - f * 0.985;
    float c = texture2D(clouds, vUv + vec2(cloudShift, 0.0)).r;
    float sea = step(base.b, base.r * 0.9 + 0.12) < 0.5 && base.b > base.g ? 1.0 : 0.0;
    vec3 H = normalize(L + V);
    extra += sea * pow(max(dot(N, H), 0.0), 40.0) * 0.35 * vec3(1.0, 0.95, 0.85) * shade;
    base = mix(base, vec3(0.97), c * 0.85);
  } else if (mode == 2) {
    // Mond: Erdschatten in echter Geometrie, im Kernschatten kupferrot
    vec3 q = moonG + normalize(vW - centerW) * 1737.4;
    vec3 s = sunG - q; vec3 e = -q;
    float rs = asin(clamp(696000.0/length(s), 0.0, 1.0));
    float re = asin(clamp(6371.0*1.02/length(e), 0.0, 1.0));
    float f = overlapFrac(rs, re, angBetween(s, e));
    shade *= 1.0 - f;
    float red = smoothstep(0.93, 1.0, f);
    extra += base * vec3(0.62, 0.2, 0.07) * 0.75 * red * diff;
  } else if (mode == 3) {
    // Saturn: Schatten der Ringe
    float dn = dot(L, ringN);
    if (abs(dn) > 1e-4) {
      float t = dot(centerW - vW, ringN) / dn;
      if (t > 0.0) {
        float r = length(vW + L * t - centerW) / radiusW;
        if (r > ${RING_IN.toFixed(2)} && r < ${RING_OUT.toFixed(2)}) {
          float a = texture2D(ringMap, vec2((r - ${RING_IN.toFixed(2)}) / ${(RING_OUT - RING_IN).toFixed(2)}, 0.5)).a;
          shade *= 1.0 - a * 0.8;
        }
      }
    }
  }
  vec3 col = base * (ambient + diff * shade * 1.05) + extra;
  // Modell-Look: etwas Raumlicht von vorn, Rand mit Atmosphäre
  col += base * 0.05 * max(dot(N, V), 0.0);
  float fr = pow(1.0 - max(dot(N, V), 0.0), 3.0);
  col += atmo * fr * atmoK * (0.25 + 0.75 * clamp(nl + 0.35, 0.0, 1.0)) * (mode == 1 ? shade : 1.0);
  col += highlight * fr * vec3(1.0, 0.85, 0.55) * 0.35;
  gl_FragColor = vec4(col, 1.0);
}`;

const RING_FS = `
precision highp float;
uniform sampler2D ringMap; uniform vec3 centerW; uniform float radiusW; uniform vec3 ringN;
varying vec3 vW;
void main(){
  float r = length(vW - centerW) / radiusW;
  if (r < ${RING_IN.toFixed(2)} || r > ${RING_OUT.toFixed(2)}) discard;
  vec4 t = texture2D(ringMap, vec2((r - ${RING_IN.toFixed(2)}) / ${(RING_OUT - RING_IN).toFixed(2)}, 0.5));
  vec3 L = normalize(-vW);
  // Schatten des Planeten: Strahl zur Sonne trifft die Kugel?
  vec3 oc = vW - centerW;
  float b = dot(oc, L);
  float c = dot(oc, oc) - radiusW * radiusW;
  float disc = b * b - c;
  float lit = (disc > 0.0 && -b - sqrt(disc) > 0.0) ? 0.08 : 1.0;
  vec3 V = normalize(cameraPosition - vW);
  float sameSide = sign(dot(L, ringN)) * sign(dot(V, ringN));
  float k = sameSide > 0.0 ? 1.0 : 0.45;
  float nl = abs(dot(L, ringN));
  vec3 col = t.rgb * (0.06 + lit * k * (0.35 + 0.75 * sqrt(nl)));
  gl_FragColor = vec4(col, t.a * 0.95);
}`;
const RING_VS = `varying vec3 vW; void main(){ vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`;

const SUN_FS = `
precision highp float;
uniform float time; varying vec3 vN; varying vec3 vW; varying vec2 vUv; varying vec3 vL;
${NOISE_GLSL}
void main(){
  vec3 V = normalize(cameraPosition - vW);
  float mu = max(dot(normalize(vN), V), 0.0);
  float g = fbm3(vL * 6.0 + vec3(0.0, time * 0.03, time * 0.02));
  float g2 = n3(vL * 22.0 + time * 0.05);
  vec3 col = mix(vec3(1.0, 0.55, 0.16), vec3(1.0, 0.93, 0.7), g * 0.8 + g2 * 0.25);
  float limb = 0.35 + 0.65 * pow(mu, 0.45);
  gl_FragColor = vec4(col * limb * 1.15, 1.0);
}`;
const SUN_VS = `
varying vec3 vN; varying vec3 vW; varying vec2 vUv; varying vec3 vL;
void main(){ vUv = uv; vL = normal; vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; vN = normalize(mat3(modelMatrix)*normal);
  gl_Position = projectionMatrix * viewMatrix * w; }`;

// Punkte (Sterne, Gürtel): Größe in Pixeln, rund und weich
const POINTS_VS = `
attribute float size; attribute vec3 color; varying vec3 vC; uniform float px; uniform float time;
attribute float orbit;    // Gürtel: Winkelgeschwindigkeit (rad/Tag); 0 = fest
uniform float days;
void main(){
  vC = color;
  vec3 p = position;
  if (orbit != 0.0) { float a = orbit * days; float c = cos(a), s = sin(a); p = vec3(c*p.x + s*p.z, p.y, -s*p.x + c*p.z); }
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  gl_PointSize = size * px;
  gl_Position = projectionMatrix * mv;
}`;
const POINTS_FS = `
varying vec3 vC;
void main(){ vec2 d = gl_PointCoord - 0.5; float r = dot(d, d) * 4.0; if (r > 1.0) discard; gl_FragColor = vec4(vC * (1.0 - r), 1.0); }`;

// Nachbearbeitung: Schärfentiefe (Modellbau-Look), Vignette, Farbe, Korn
const POST_VS = `varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`;
const POST_FS = `
precision highp float;
uniform sampler2D tColor; uniform sampler2D tDepth; uniform vec2 res; uniform float focus; uniform float near; uniform float far;
uniform float strength; uniform float maxR; uniform float time; uniform int taps;
varying vec2 vUv;
float lin(float z){ float n = z * 2.0 - 1.0; return 2.0 * near * far / (far + near - n * (far - near)); }
float coc(float d){ float c = abs(1.0 - focus / max(d, 1e-4)) * strength; if (d > far * 0.2) c = min(c, 0.55); return clamp(c, 0.0, 1.0); }
void main(){
  float d0 = lin(texture2D(tDepth, vUv).r);
  float c0 = coc(d0);
  vec3 sum = texture2D(tColor, vUv).rgb; float wsum = 1.0;
  float R = c0 * maxR;
  if (R > 0.6) {
    for (int i = 1; i < 17; i++) {
      if (i > taps) break;
      float fi = float(i);
      float r = sqrt(fi / float(taps)) * R;
      float a = fi * 2.39996;
      vec2 o = vec2(cos(a), sin(a)) * r / res;
      vec2 uv = vUv + o;
      vec3 c = texture2D(tColor, uv).rgb;
      float cs = coc(lin(texture2D(tDepth, uv).r)) * maxR;
      float w = d0 < lin(texture2D(tDepth, uv).r) ? 1.0 : smoothstep(0.0, 1.0, cs / max(r, 0.5));
      sum += c * w; wsum += w;
    }
  }
  vec3 col = sum / wsum;
  // Farbe: warm, leicht entsättigt in den Schatten, Vignette, Korn
  float l = dot(col, vec3(0.299, 0.587, 0.114));
  col = mix(vec3(l), col, 1.06);
  col *= vec3(1.03, 1.0, 0.95);
  vec2 q = vUv - 0.5;
  col *= 1.0 - dot(q, q) * 0.9;
  float gr = fract(sin(dot(vUv * res + time, vec2(12.9898, 78.233))) * 43758.5453);
  col += (gr - 0.5) * 0.018;
  gl_FragColor = vec4(col, 1.0);
}`;

const post = new THREE.ShaderMaterial({
  vertexShader: POST_VS, fragmentShader: POST_FS, depthTest: false, depthWrite: false,
  uniforms: {
    tColor: { value: rt.texture }, tDepth: { value: depthTex }, res: { value: new THREE.Vector2(4, 4) },
    focus: { value: 10 }, near: { value: 0.05 }, far: { value: 6000 }, strength: { value: 0.9 }, maxR: { value: 6 },
    time: { value: 0 }, taps: { value: tier.taps }
  }
});
const postScene = new THREE.Scene();
const postCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
postScene.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), post));

// ------------------------------------------------------------------ Texturen
const TX = {};
function texFrom(canvasEl, repeat = true) {
  const t = new THREE.CanvasTexture(canvasEl);
  t.colorSpace = THREE.NoColorSpace;
  t.wrapS = repeat ? THREE.RepeatWrapping : THREE.ClampToEdgeWrapping;
  t.wrapT = THREE.ClampToEdgeWrapping;
  t.anisotropy = 2;
  t.needsUpdate = true;
  return t;
}

// ------------------------------------------------------------------ Welt aufbauen
const world = new THREE.Group();
scene.add(world);
const bodies = {};          // id -> { id, kind, group, mesh, r, pos: Vector3, label, parent, sys }
const labelLayer = document.getElementById("labels");

function makeLabel(id, kind) {
  const el = document.createElement("div");
  el.className = "label " + kind;
  el.textContent = nameOf(id);
  labelLayer.appendChild(el);
  return el;
}

function planetMaterial(map, extra) {
  return new THREE.ShaderMaterial({
    vertexShader: PLANET_VS, fragmentShader: PLANET_FS,
    uniforms: Object.assign({
      map: { value: map }, clouds: { value: null }, ringMap: { value: null }, centerW: { value: new THREE.Vector3() },
      radiusW: { value: 1 }, ambient: { value: 0.035 }, time: { value: 0 }, mode: { value: 0 },
      sunG: { value: new THREE.Vector3(1, 0, 0) }, moonG: { value: new THREE.Vector3(0, 0, 1) }, ringN: { value: new THREE.Vector3(0, 1, 0) },
      cloudShift: { value: 0 }, atmo: { value: new THREE.Color(0, 0, 0) }, atmoK: { value: 0 }, highlight: { value: 0 }
    }, extra || {})
  });
}

let sphereGeo;
function addSphereBody(id, kind, km, texKey, opts = {}) {
  const r = opts.r || visSize(km);
  const group = new THREE.Group();
  const spin = new THREE.Group();
  group.add(spin);
  const mat = planetMaterial(TX[texKey]);
  mat.uniforms.radiusW.value = r;
  if (opts.atmo) { mat.uniforms.atmo.value.set(...opts.atmo); mat.uniforms.atmoK.value = opts.atmoK ?? 0.8; }
  const mesh = new THREE.Mesh(sphereGeo, mat);
  mesh.scale.setScalar(r);
  spin.add(mesh);
  world.add(group);
  const b = { id, kind, km, r, group, spin, mesh, mat, pos: group.position, sys: r, label: null, parent: opts.parent || null };
  if (opts.label !== false) b.label = makeLabel(id, kind);
  bodies[id] = b;
  return b;
}

function orbitLine(points, color, opacity) {
  const geo = new THREE.BufferGeometry().setFromPoints(points);
  const mat = new THREE.LineBasicMaterial({ color, transparent: true, opacity, depthWrite: false });
  const line = new THREE.LineLoop(geo, mat);
  world.add(line);
  return line;
}

let sunGlow, belts = [], orbitLines = [], moonOrbitLines = [], stars, milky, shadowCone, alignLine;
function buildWorld() {
  sphereGeo = new THREE.SphereGeometry(1, tier.seg, Math.round(tier.seg * 0.7));
  // Sonne
  const sunMat = new THREE.ShaderMaterial({ vertexShader: SUN_VS, fragmentShader: SUN_FS, uniforms: { time: { value: 0 } } });
  const sunMesh = new THREE.Mesh(sphereGeo, sunMat);
  const sunR = 2.2;
  sunMesh.scale.setScalar(sunR);
  const sunGroup = new THREE.Group();
  sunGroup.add(sunMesh);
  world.add(sunGroup);
  bodies.sun = { id: "sun", kind: "star", km: 696000, r: sunR, group: sunGroup, spin: sunGroup, mesh: sunMesh, mat: sunMat,
    pos: sunGroup.position, sys: sunR, label: makeLabel("sun", "star") };
  const glowMat = new THREE.SpriteMaterial({ map: texFrom(TX.sunGlowC, false), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true });
  sunGlow = new THREE.Sprite(glowMat);
  sunGlow.scale.setScalar(sunR * 9);
  sunGroup.add(sunGlow);

  // Planeten
  for (const p of PLANETS) {
    const atmo = { earth: [0.35, 0.6, 1.0], venus: [1.0, 0.85, 0.55], mars: [1.0, 0.6, 0.4], uranus: [0.6, 0.95, 1.0],
      neptune: [0.4, 0.6, 1.0], jupiter: [1.0, 0.9, 0.75], saturn: [1.0, 0.9, 0.7] }[p.id];
    const b = addSphereBody(p.id, p.dwarf ? "dwarf" : "planet", p.km, p.tex, { atmo, atmoK: p.id === "earth" ? 1.1 : 0.45 });
    b.planet = p;
    if (p.id === "earth") {
      b.mat.uniforms.mode.value = 1;
      b.mat.uniforms.clouds.value = TX.clouds;
      b.mat.uniforms.ambient.value = 0.03;
      b.tilt = new THREE.Group();
      b.group.remove(b.spin);
      b.group.add(b.tilt);
      b.tilt.add(b.spin);
      b.tilt.rotation.x = 23.4393 * DEG;
    } else if (p.pole) {
      const pole = poleWorld(p.pole[0], p.pole[1]);
      b.spin.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), pole);
      b.poleW = pole;
    }
  }
  // Saturnringe
  const sat = bodies.saturn;
  sat.mat.uniforms.mode.value = 3;
  sat.mat.uniforms.ringMap.value = TX.rings;
  const ringGeo = new THREE.RingGeometry(RING_IN, RING_OUT, 128, 1);
  ringGeo.rotateX(-Math.PI / 2);
  const ringMat = new THREE.ShaderMaterial({
    vertexShader: RING_VS, fragmentShader: RING_FS, transparent: true, side: THREE.DoubleSide, depthWrite: false,
    uniforms: { ringMap: { value: TX.rings }, centerW: sat.mat.uniforms.centerW, radiusW: sat.mat.uniforms.radiusW, ringN: sat.mat.uniforms.ringN }
  });
  const ring = new THREE.Mesh(ringGeo, ringMat);
  ring.scale.setScalar(sat.r);
  ring.quaternion.copy(sat.spin.quaternion);
  sat.group.add(ring);
  sat.mat.uniforms.ringN.value.copy(sat.poleW);
  sat.sys = sat.r * RING_OUT;
  // dünner Ring für Uranus
  const ur = bodies.uranus;
  const uRing = new THREE.Mesh(new THREE.RingGeometry(1.9, 2.0, 96, 1).rotateX(-Math.PI / 2),
    new THREE.MeshBasicMaterial({ color: 0x8aa0a6, transparent: true, opacity: 0.25, side: THREE.DoubleSide, depthWrite: false }));
  uRing.scale.setScalar(ur.r);
  uRing.quaternion.copy(ur.spin.quaternion);
  ur.group.add(uRing);

  // Mond der Erde
  const moon = addSphereBody("moon", "moon", 1737.4, "moon", { parent: "earth" });
  moon.mat.uniforms.mode.value = 2;
  moon.mat.uniforms.ambient.value = 0.015;
  // Galileische Monde
  for (const [id, km, tex] of [["io", 1821, "io"], ["europa", 1561, "europa"], ["ganymede", 2634, "ice"], ["callisto", 2410, "dark"]]) {
    addSphereBody(id, "moon", km, tex, { parent: "jupiter" });
  }
  for (const [parent, list] of Object.entries(SIMPLE_MOONS)) {
    for (const [id, , , km, , tex] of list) addSphereBody(id, "moon", km, tex, { parent });
  }
  // Mondbahnen (Kreise im Äquator des Planeten, gestaucht)
  for (const [parent, list] of Object.entries(SIMPLE_MOONS)) {
    const pb = bodies[parent];
    for (const m of list) {
      const d = moonDist(pb, m[1]);
      const pts = [];
      for (let k = 0; k < 96; k += 1) { const a = k / 96 * Math.PI * 2; pts.push(new THREE.Vector3(Math.cos(a) * d, 0, Math.sin(a) * d)); }
      const line = orbitLine(pts, 0xbfa77a, 0.16);
      world.remove(line);
      line.quaternion.copy(pb.spin.quaternion);
      pb.group.add(line);
      moonOrbitLines.push(line);
      pb.sys = Math.max(pb.sys, d);
    }
  }
  for (const id of ["io", "europa", "ganymede", "callisto"]) {
    const d = moonDist(bodies.jupiter, { io: 421700, europa: 671034, ganymede: 1070412, callisto: 1882709 }[id]);
    const pts = [];
    for (let k = 0; k < 96; k += 1) { const a = k / 96 * Math.PI * 2; pts.push(new THREE.Vector3(Math.cos(a) * d, 0, Math.sin(a) * d)); }
    const line = orbitLine(pts, 0xbfa77a, 0.16);
    world.remove(line);
    line.quaternion.copy(bodies.jupiter.spin.quaternion);
    bodies.jupiter.group.add(line);
    moonOrbitLines.push(line);
    bodies.jupiter.sys = Math.max(bodies.jupiter.sys, d);
  }
  bodies.earth.sys = moonDist(bodies.earth, 384400);

  // Sterne und Milchstraße
  const skyR = 2400;
  const milkyMat = new THREE.MeshBasicMaterial({ map: texFrom(TX.milkyC), side: THREE.BackSide, depthWrite: false });
  milky = new THREE.Mesh(new THREE.SphereGeometry(skyR, 48, 24), milkyMat);
  milky.rotation.y = Math.PI;          // u = 0.5 bei Länge 0 -> +X
  scene.add(milky);
  stars = makeStars(skyR * 0.95);
  scene.add(stars);
  belts = [makeBelt(2.1, 3.3, 0.08, tier.belt, [0.75, 0.68, 0.58]), makeBelt(30, 50, 0.12, Math.round(tier.belt * 0.8), [0.6, 0.66, 0.75])];
  for (const b of belts) world.add(b);

  // Erdschatten (Kegel) für Mondfinsternisse
  const coneGeo = new THREE.ConeGeometry(1, 1, 48, 1, true);
  coneGeo.translate(0, -0.5, 0);
  shadowCone = new THREE.Mesh(coneGeo, new THREE.MeshBasicMaterial({ color: 0x220a04, transparent: true, opacity: 0.0,
    depthWrite: false, side: THREE.DoubleSide }));
  world.add(shadowCone);
  // Linie für Oppositionen/Konjunktionen
  alignLine = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3(1, 0, 0), new THREE.Vector3(2, 0, 0)]),
    new THREE.LineDashedMaterial({ color: 0xf0d6a0, dashSize: 0.6, gapSize: 0.4, transparent: true, opacity: 0.0, depthWrite: false }));
  alignLine.frustumCulled = false;
  world.add(alignLine);
}

function moonDist(pb, km) {
  const rp = pb.km;
  return pb.r * (1.5 + 0.95 * Math.log(Math.max(1.2, km / rp)));
}

function pointsMaterial(extra) {
  return new THREE.ShaderMaterial({
    vertexShader: POINTS_VS, fragmentShader: POINTS_FS, transparent: false, depthWrite: false,
    uniforms: Object.assign({ px: { value: 1 }, time: { value: 0 }, days: { value: 0 } }, extra || {})
  });
}

function makeStars(R) {
  const n = tier.stars;
  const pos = new Float32Array(n * 3), col = new Float32Array(n * 3), size = new Float32Array(n), orbit = new Float32Array(n);
  let s = 12345;
  const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  for (let i = 0; i < n; i += 1) {
    const z = rnd() * 2 - 1, a = rnd() * Math.PI * 2, r = Math.sqrt(1 - z * z);
    pos[i * 3] = Math.cos(a) * r * R; pos[i * 3 + 1] = z * R; pos[i * 3 + 2] = Math.sin(a) * r * R;
    const m = Math.pow(rnd(), 6);
    const t = rnd();
    const c = t < 0.15 ? [1.0, 0.8, 0.6] : t < 0.35 ? [0.75, 0.85, 1.0] : [1, 0.97, 0.92];
    const k = 0.35 + 0.65 * m;
    col[i * 3] = c[0] * k; col[i * 3 + 1] = c[1] * k; col[i * 3 + 2] = c[2] * k;
    size[i] = 1.2 + m * 3.2;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
  geo.setAttribute("size", new THREE.BufferAttribute(size, 1));
  geo.setAttribute("orbit", new THREE.BufferAttribute(orbit, 1));
  const p = new THREE.Points(geo, pointsMaterial());
  p.frustumCulled = false;
  return p;
}

// Gürtel: Punkte auf Kepler-Kreisen, drehen sich mit echter Geschwindigkeit (im Shader)
function makeBelt(r0, r1, thick, n, tint) {
  const pos = new Float32Array(n * 3), col = new Float32Array(n * 3), size = new Float32Array(n), orbit = new Float32Array(n);
  let s = Math.round(r0 * 1000) + 7;
  const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
  for (let i = 0; i < n; i += 1) {
    const au = r0 + (r1 - r0) * Math.pow(rnd(), 0.8);
    const a = rnd() * Math.PI * 2;
    const vr = visR(au) * (1 + (rnd() - 0.5) * 0.02);
    pos[i * 3] = Math.cos(a) * vr; pos[i * 3 + 2] = Math.sin(a) * vr;
    pos[i * 3 + 1] = (rnd() - 0.5) * 2 * thick * vr * rnd();
    const k = 0.35 + rnd() * 0.45;
    col[i * 3] = tint[0] * k; col[i * 3 + 1] = tint[1] * k; col[i * 3 + 2] = tint[2] * k;
    size[i] = 1.0 + rnd() * 1.4;
    orbit[i] = -2 * Math.PI / (365.256 * Math.pow(au, 1.5));     // gegen den Uhrzeigersinn von oben
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
  geo.setAttribute("size", new THREE.BufferAttribute(size, 1));
  geo.setAttribute("orbit", new THREE.BufferAttribute(orbit, 1));
  const p = new THREE.Points(geo, pointsMaterial());
  p.frustumCulled = false;
  return p;
}

// Planetenbahnen: echte Bahn (Astronomy Engine) über einen Umlauf, gestaucht. Läuft stückweise.
async function buildOrbits() {
  for (const p of PLANETS) {
    const steps = p.id === "pluto" ? 180 : 140;
    const pts = [];
    for (let k = 0; k < steps; k += 1) {
      const ms = simNow + (k / steps) * p.year * DAY_MS;
      pts.push(helioWorld(eqjToEcl(A.HelioVector(p.body, atime(ms)))));
    }
    const line = orbitLine(pts, p.dwarf ? 0x9a8c74 : 0xd8b878, p.dwarf ? 0.14 : 0.22);
    line.visible = cfg.Orbits;
    orbitLines.push(line);
    await new Promise((r) => setTimeout(r, 0));
  }
}

// ------------------------------------------------------------------ Kometen und Sonden
const OBJ = window.SSL_OBJECTS || { comets: [], probes: [] };
let comets = [];          // { id, name, el, line, head, tail, pos }
let probes = [];          // { id, name, data, model, pos }
let probeTables = {};

function parseTp(v) { return typeof v === "number" ? v * 1000 : Date.parse(v); }

function keplerPos(c, ms) {
  const k = 0.01720209895;
  const days = (ms - c.tpMs) / DAY_MS;
  const e = c.e, q = c.q;
  let x, y;
  if (e < 1) {
    const a = q / (1 - e);
    const M = k / Math.pow(a, 1.5) * days;
    let Mm = M % (2 * Math.PI);
    let E = e < 0.8 ? Mm : Math.PI * Math.sign(Mm || 1);
    for (let i = 0; i < 30; i += 1) { const d = (E - e * Math.sin(E) - Mm) / (1 - e * Math.cos(E)); E -= d; if (Math.abs(d) < 1e-10) break; }
    x = a * (Math.cos(E) - e); y = a * Math.sqrt(1 - e * e) * Math.sin(E);
  } else {
    const ee = Math.max(e, 1.000001);
    const a = q / (ee - 1);
    const M = k / Math.pow(a, 1.5) * days;
    let Hh = Math.asinh(M / ee);
    for (let i = 0; i < 40; i += 1) { const d = (ee * Math.sinh(Hh) - Hh - M) / (ee * Math.cosh(Hh) - 1); Hh -= d; if (Math.abs(d) < 1e-10) break; }
    x = a * (ee - Math.cosh(Hh)); y = a * Math.sqrt(ee * ee - 1) * Math.sinh(Hh);
  }
  return rotOrbit(c, x, y);
}
function rotOrbit(c, x, y) {
  const w = c.peri * DEG, O = c.node * DEG, i = c.i * DEG;
  const cw = Math.cos(w), sw = Math.sin(w), cO = Math.cos(O), sO = Math.sin(O), ci = Math.cos(i), si = Math.sin(i);
  const X = (cO * cw - sO * sw * ci) * x + (-cO * sw - sO * cw * ci) * y;
  const Y = (sO * cw + cO * sw * ci) * x + (-sO * sw + cO * cw * ci) * y;
  const Z = (sw * si) * x + (cw * si) * y;
  return [X, Y, Z];
}
function cometOrbitPoints(c) {
  const pts = [];
  if (c.e < 1) {
    const a = c.q / (1 - c.e);
    for (let k = 0; k < 160; k += 1) {
      const E = k / 160 * Math.PI * 2;
      pts.push(helioWorld(rotOrbit(c, a * (Math.cos(E) - c.e), a * Math.sqrt(1 - c.e * c.e) * Math.sin(E))));
    }
  } else {
    const ee = Math.max(c.e, 1.000001), a = c.q / (ee - 1);
    const Hmax = Math.acosh(Math.min(1e6, (40 / a + ee) / ee));
    for (let k = 0; k <= 120; k += 1) {
      const Hh = -Hmax + 2 * Hmax * k / 120;
      pts.push(helioWorld(rotOrbit(c, a * (ee - Math.cosh(Hh)), a * Math.sqrt(ee * ee - 1) * Math.sinh(Hh))));
    }
  }
  return pts;
}

const TAIL_VS = `
attribute float side; attribute float along; varying float vAlong; varying float vSide;
uniform vec3 head; uniform vec3 dir; uniform float len; uniform float width;
void main(){
  vAlong = along; vSide = side;
  vec3 p = head + dir * len * along;
  vec3 toCam = normalize(cameraPosition - p);
  vec3 sideV = normalize(cross(dir, toCam));
  p += sideV * side * width * (0.15 + along * 1.0);
  gl_Position = projectionMatrix * viewMatrix * vec4(p, 1.0);
}`;
const TAIL_FS = `
varying float vAlong; varying float vSide; uniform vec3 color; uniform float alpha;
void main(){ float a = (1.0 - vAlong) * (1.0 - vSide * vSide) * alpha; gl_FragColor = vec4(color * a, a); }`;

function makeTail(color) {
  const geo = new THREE.BufferGeometry();
  const n = 24;
  const pos = [], side = [], along = [], idx = [];
  for (let i = 0; i <= n; i += 1) {
    for (const s of [-1, 0, 1]) { pos.push(0, 0, 0); side.push(s); along.push(i / n); }
  }
  for (let i = 0; i < n; i += 1) {
    const a = i * 3, b = (i + 1) * 3;
    idx.push(a, b, a + 1, b, b + 1, a + 1, a + 1, b + 1, a + 2, b + 1, b + 2, a + 2);
  }
  geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute("side", new THREE.Float32BufferAttribute(side, 1));
  geo.setAttribute("along", new THREE.Float32BufferAttribute(along, 1));
  geo.setIndex(idx);
  const mat = new THREE.ShaderMaterial({
    vertexShader: TAIL_VS, fragmentShader: TAIL_FS, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
    uniforms: { head: { value: new THREE.Vector3() }, dir: { value: new THREE.Vector3(1, 0, 0) }, len: { value: 1 },
      width: { value: 0.3 }, color: { value: new THREE.Color(color) }, alpha: { value: 0.8 } }
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.frustumCulled = false;
  return mesh;
}

function setComets(list) {
  for (const c of comets) {
    world.remove(c.group); world.remove(c.line); c.label?.remove();
  }
  comets = [];
  for (const raw of list || []) {
    const c = Object.assign({}, raw, { tpMs: parseTp(raw.tp) });
    if (!Number.isFinite(c.tpMs) || !(c.q > 0) || !(c.e >= 0)) continue;
    c.group = new THREE.Group();
    const head = new THREE.Sprite(new THREE.SpriteMaterial({ map: TX.dot, color: 0xcff4ff, blending: THREE.AdditiveBlending,
      depthWrite: false, transparent: true }));
    head.scale.setScalar(0.35);
    c.group.add(head);
    c.head = head;
    c.ion = makeTail(0x6fa8ff);
    c.dust = makeTail(0xffe2b0);
    world.add(c.ion); world.add(c.dust);
    world.add(c.group);
    c.line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(cometOrbitPoints(c)),
      new THREE.LineBasicMaterial({ color: 0x8fb8d8, transparent: true, opacity: 0.16, depthWrite: false }));
    world.add(c.line);
    c.label = makeLabel(c.id, "comet");
    c.label.textContent = shortComet(c.name);
    c.pos = c.group.position;
    c.kind = "comet"; c.r = 0.12; c.sys = 1.5;
    comets.push(c);
  }
}
const shortComet = (name) => String(name).replace(/\s*\(.*\)$/, "").replace(/^(\d+[PI])\/(.*)$/, "$2 ($1)");

function setProbes(list) {
  for (const p of probes) { world.remove(p.group); p.label?.remove(); if (p.ray) world.remove(p.ray); }
  probes = [];
  for (const raw of list || []) {
    const p = Object.assign({}, raw);
    p.group = new THREE.Group();
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: TX.dot, color: 0xffd38a, blending: THREE.AdditiveBlending,
      depthWrite: false, transparent: true }));
    s.scale.setScalar(0.12);
    p.group.add(s);
    // kleines Modell: Schüssel + Stab (Miniatur)
    const dish = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.03, 16, 1, true), new THREE.MeshBasicMaterial({ color: 0xe8e2d0, side: THREE.DoubleSide }));
    dish.rotation.x = Math.PI / 2;
    p.group.add(dish);
    world.add(p.group);
    p.label = makeLabel(p.id, "probe");
    p.label.textContent = p.name;
    p.pos = p.group.position;
    p.kind = "probe"; p.r = 0.06; p.sys = 0.8;
    if (p.model && p.model.kind === "radial") {
      p.ray = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3(1, 0, 0)]),
        new THREE.LineDashedMaterial({ color: 0xffd38a, dashSize: 1.2, gapSize: 1.0, transparent: true, opacity: 0.18, depthWrite: false }));
      world.add(p.ray);
    }
    probes.push(p);
  }
}

// Ort einer Sonde: Horizons-Tabelle, sonst Ersatzmodell. Ekliptisch, AE, oder null.
function probeEcl(p, ms) {
  const tab = probeTables[p.id];
  if (tab && tab.t && tab.t.length > 1) {
    const s = ms / 1000;
    const t = tab.t;
    let i = 0;
    if (s <= t[0]) i = 0; else if (s >= t[t.length - 1]) i = t.length - 2;
    else { while (i < t.length - 2 && t[i + 1] < s) i += 1; }
    const k = (s - t[i]) / (t[i + 1] - t[i]);
    if (k > -20 && k < 25) {
      const a = tab.p[i], b = tab.p[i + 1];
      return [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];
    }
  }
  const m = p.model;
  if (!m) return null;
  if (m.kind === "radial") {
    const au = m.au + m.auPerYear * (ms - Date.parse(m.epoch)) / (365.25 * DAY_MS);
    const lo = m.lon * DEG, la = m.lat * DEG;
    return [au * Math.cos(la) * Math.cos(lo), au * Math.cos(la) * Math.sin(lo), au * Math.sin(la)];
  }
  if (m.kind === "l2") {
    const e = planetEcl("earth");
    const r = Math.hypot(...e);
    return e.map((x) => x * (1 + 0.01 / r));
  }
  if (m.kind === "with" && (!m.from || ms >= Date.parse(m.from))) {
    const e = planetEcl(m.body);
    return e.map((x) => x * 1.0005);
  }
  return null;
}

// ------------------------------------------------------------------ Orte rechnen
const cache = {};          // id -> { at, ecl }
function planetEcl(id) {
  const c = cache[id];
  return c ? c.ecl : [0, 0, 0];
}
function updatePositions(ms, force) {
  // Planeten (heliozentrisch)
  for (const p of PLANETS) {
    const tol = p.id === "earth" ? 300e3 : p.id === "mercury" || p.id === "venus" ? 1800e3 : 3600e3;
    const c = cache[p.id];
    if (!force && c && Math.abs(c.at - ms) < tol) continue;
    const ecl = eqjToEcl(A.HelioVector(p.body, atime(ms)));
    cache[p.id] = { at: ms, ecl };
    helioWorld(ecl, bodies[p.id].group.position);
  }
  // Mond (echter geozentrischer Vektor, gestauchter Abstand)
  const mc = cache.moonG;
  if (force || !mc || Math.abs(mc.at - ms) > 20e3) {
    const g = eqjToEcl(A.GeoMoon(atime(ms)));
    cache.moonG = { at: ms, ecl: g };
  }
  const earth = bodies.earth, moon = bodies.moon;
  const g = cache.moonG.ecl;
  const gkm = Math.hypot(...g) * AU_KM;
  const dir = eclToWorld(g, new THREE.Vector3()).normalize();
  moon.group.position.copy(earth.group.position).addScaledVector(dir, moonDist(earth, gkm));
  // Mond zeigt der Erde immer dieselbe Seite: lokale +X (Länge 0) zur Erde
  moon.spin.quaternion.setFromUnitVectors(new THREE.Vector3(1, 0, 0), dir.clone().negate());
  // Galileische Monde (echt)
  const jc = cache.jmoons;
  if (force || !jc || Math.abs(jc.at - ms) > 120e3) {
    const jm = A.JupiterMoons(atime(ms));
    cache.jmoons = { at: ms, m: { io: jm.io, europa: jm.europa, ganymede: jm.ganymede, callisto: jm.callisto } };
  }
  const jup = bodies.jupiter;
  for (const [id, sv] of Object.entries(cache.jmoons.m)) {
    const e = eqjToEcl(sv);
    const km = Math.hypot(...e) * AU_KM;
    const d = eclToWorld(e, new THREE.Vector3()).normalize();
    bodies[id].group.position.copy(jup.group.position).addScaledVector(d, moonDist(jup, km));
  }
  // vereinfachte Monde
  const days = (ms - MOON_EPOCH) / DAY_MS;
  for (const [parent, list] of Object.entries(SIMPLE_MOONS)) {
    const pb = bodies[parent];
    for (const [id, km, period, , start] of list) {
      const a = (start * DEG) + 2 * Math.PI * days / period;
      const d = moonDist(pb, km);
      const local = new THREE.Vector3(Math.cos(a) * d, 0, -Math.sin(a) * d);
      local.applyQuaternion(pb.spin.quaternion);
      bodies[id].group.position.copy(pb.group.position).add(local);
    }
  }
  // Drehung der Planeten
  const gast = A.SiderealTime(atime(ms));
  earth.spin.rotation.y = gast * 15 * DEG;
  const hours = (ms - Date.UTC(2000, 0, 1, 12)) / 3600e3;
  for (const p of PLANETS) {
    if (p.id === "earth") continue;
    const b = bodies[p.id];
    const spinA = (hours / p.rot) * Math.PI * 2;
    const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), b.poleW);
    b.spin.quaternion.copy(q).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), spinA % (Math.PI * 2)));
  }
  // Kometen
  for (const c of comets) {
    const ecl = keplerPos(c, ms);
    c.ecl = ecl;
    c.rAU = Math.hypot(...ecl);
    helioWorld(ecl, c.group.position);
    const away = c.group.position.clone().normalize();
    const act = smoothstep(5.5, 1.0, c.rAU);
    const len = act * (3 + 9 * smoothstep(3, 0.4, c.rAU));
    c.ion.material.uniforms.head.value.copy(c.group.position);
    c.ion.material.uniforms.dir.value.copy(away);
    c.ion.material.uniforms.len.value = len * 1.15;
    c.ion.material.uniforms.width.value = 0.25 + len * 0.03;
    c.ion.material.uniforms.alpha.value = 0.55 * act;
    // Staubschweif leicht gekrümmt: etwas gegen die Bewegungsrichtung
    const later = helioWorld(keplerPos(c, ms + 5 * DAY_MS));
    const vel = later.sub(c.group.position).normalize();
    const dustDir = away.clone().addScaledVector(vel, -0.35).normalize();
    c.dust.material.uniforms.head.value.copy(c.group.position);
    c.dust.material.uniforms.dir.value.copy(dustDir);
    c.dust.material.uniforms.len.value = len * 0.8;
    c.dust.material.uniforms.width.value = 0.35 + len * 0.08;
    c.dust.material.uniforms.alpha.value = 0.45 * act;
    c.head.scale.setScalar(0.18 + 0.3 * act);
    c.ion.visible = c.dust.visible = act > 0.01;
  }
  // Sonden
  for (const p of probes) {
    const ecl = probeEcl(p, ms);
    p.ecl = ecl;
    p.group.visible = !!ecl;
    if (p.label) p.label.dataset.off = ecl ? "" : "1";
    if (!ecl) continue;
    helioWorld(ecl, p.group.position);
    if (p.model && p.model.kind === "with") p.group.position.add(new THREE.Vector3(0.0, bodies[p.model.body].r * 1.6, 0));
    if (p.model && p.model.kind === "l2" && !probeTables[p.id]) {
      const e = bodies.earth.group.position;
      p.group.position.copy(e).addScaledVector(e.clone().normalize(), moonDist(bodies.earth, 1.5e6));
    }
    if (p.ray) {
      const arr = p.ray.geometry.attributes.position.array;
      arr[3] = p.group.position.x; arr[4] = p.group.position.y; arr[5] = p.group.position.z;
      p.ray.geometry.attributes.position.needsUpdate = true;
      p.ray.computeLineDistances();
    }
    p.group.lookAt(0, 0, 0);
  }
  // Uniforms: Zentren, Finsternis-Geometrie (km, Weltachsen)
  const sunG = eclToWorld(planetEcl("earth").map((x) => -x * AU_KM), new THREE.Vector3());
  const moonG = eclToWorld(g.map((x) => x * AU_KM), new THREE.Vector3());
  earth.mat.uniforms.sunG.value.copy(sunG);
  earth.mat.uniforms.moonG.value.copy(moonG);
  moon.mat.uniforms.sunG.value.copy(sunG);
  moon.mat.uniforms.moonG.value.copy(moonG);
  for (const b of Object.values(bodies)) if (b.mat && b.mat.uniforms && b.mat.uniforms.centerW) b.mat.uniforms.centerW.value.copy(b.group.position);
  // Erdschatten-Kegel (sichtbar nur bei Mondfinsternissen)
  const ep = earth.group.position;
  const anti = ep.clone().normalize();
  shadowCone.position.copy(ep);
  shadowCone.quaternion.setFromUnitVectors(new THREE.Vector3(0, -1, 0), anti);
  const coneLen = moonDist(earth, 384400) * 1.35;
  shadowCone.scale.set(earth.r * 0.98, coneLen, earth.r * 0.98);
}

// ------------------------------------------------------------------ Daten vom Plugin
let events = [];
let focusEventId = null;
let pluginOk = null;
let lastPayload = null;
let probesSet = false, cometsSet = false;

function applySettings(s) {
  if (!s) return;
  const before = JSON.stringify(cfg);
  cfg = Object.assign({}, DEFAULTS, s);
  if (params.get("lat")) { cfg.Lat = Number(params.get("lat")); cfg.Lon = Number(params.get("lon")); }
  if (params.get("lang")) cfg.Language = params.get("lang");
  if (cfg.Language !== lang) {
    lang = cfg.Language;
    for (const b of Object.values(bodies)) if (b.label) b.label.textContent = nameOf(b.id);
    document.documentElement.lang = lang;
    renderUpcoming();
  }
  for (const l of orbitLines) l.visible = cfg.Orbits;
  for (const l of moonOrbitLines) l.visible = cfg.Orbits;
  for (const c of comets) c.line.visible = cfg.Orbits;
  for (const b of belts) b.visible = cfg.Belts;
  document.body.classList.toggle("nolabels", !cfg.Labels);
  document.body.classList.toggle("nopanel", !cfg.Panel);
  post.uniforms.strength.value = { off: 0, light: 0.8, normal: 1.4, strong: 2.2 }[cfg.Blur] ?? 1.4;
  if (before !== JSON.stringify(cfg)) tour.dirty = true;
}

async function poll() {
  if (DEMO) return;
  try {
    const data = await api("api/scene");
    pluginOk = true;
    lastPayload = data;
    applySettings(data.settings);
    if (Array.isArray(data.events)) { events = data.events; renderUpcoming(); }
    if (data.probes && typeof data.probes === "object") probeTables = data.probes;
    if (Array.isArray(data.comets) && (!cometsSet || data.cometsVer !== cometsSet)) { setComets(data.comets); cometsSet = data.cometsVer || true; }
    if (Array.isArray(data.probeList) && !probesSet) { setProbes(data.probeList); probesSet = true; }
    const f = data.focus || null;
    if (f !== focusEventId) { focusEventId = f; tour.dirty = true; }
    document.getElementById("note").hidden = true;
  } catch (error) {
    if (pluginOk !== false) report("Szene: Plugin nicht erreichbar: " + error.message);
    pluginOk = false;
    if (!events.length) { events = localEvents(); renderUpcoming(); }
  }
}

// Ereignisse ohne Plugin (Vorschau im Browser): Finsternisse selbst suchen
function localEvents() {
  const out = [];
  try {
    const now = new Date(simNow - 86400e3);
    let le = A.SearchLunarEclipse(now);
    for (let i = 0; i < 3; i += 1) {
      const peak = le.peak.date.getTime();
      const half = le.sd_penum * 60e3;
      out.push({ id: "lunar-" + peak, type: "lunar-eclipse", start: (peak - half) / 1000, peak: peak / 1000, end: (peak + half) / 1000,
        bodies: ["moon", "earth"], info: { kind: String(le.kind).toLowerCase() }, prio: 1, visible: null });
      le = A.NextLunarEclipse(le.peak);
    }
    let se = A.SearchGlobalSolarEclipse(now);
    for (let i = 0; i < 3; i += 1) {
      const peak = se.peak.date.getTime();
      out.push({ id: "solar-" + peak, type: "solar-eclipse", start: (peak - 3 * 3600e3) / 1000, peak: peak / 1000,
        end: (peak + 3 * 3600e3) / 1000, bodies: ["sun", "moon", "earth"], info: { kind: String(se.kind).toLowerCase() }, prio: 1, visible: null });
      se = A.NextGlobalSolarEclipse(se.peak);
    }
  } catch (error) { report("localEvents: " + error.message); }
  out.sort((a, b) => a.peak - b.peak);
  return out;
}

function eventTitle(e) {
  if (e.title) return e.title;
  const kind = T().eventKind[e.type] || e.type;
  return kind;
}

// ------------------------------------------------------------------ Panel und Banner
const $ = (id) => document.getElementById(id);
const dateFmt = () => new Intl.DateTimeFormat(lang === "en" ? "en-GB" : lang, { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
const dayFmt = () => new Intl.DateTimeFormat(lang === "en" ? "en-GB" : lang, { weekday: "short", day: "numeric", month: "short" });
const clockFmt = () => new Intl.DateTimeFormat(lang === "en" ? "en-GB" : lang, { weekday: "long", day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" });

function relTime(ms) {
  const d = ms - Date.now();
  if (Math.abs(d) < 60e3) return tx("now");
  if (d < 0) return tx("now");
  if (d < 3600e3) return fmt(tx("inMin"), { n: Math.round(d / 60e3) });
  if (d < 20 * 3600e3) return fmt(tx("inHours"), { n: Math.round(d / 3600e3) });
  const days = Math.round((new Date(ms).setHours(0, 0, 0, 0) - new Date().setHours(0, 0, 0, 0)) / DAY_MS);
  if (days <= 0) return tx("today");
  if (days === 1) return tx("tomorrow");
  return fmt(tx("inDays"), { n: days });
}

function renderUpcoming() {
  const box = $("upcoming");
  const now = Date.now() / 1000;
  const list = events.filter((e) => e.end > now && (e.prio <= 2 || e.peak - now < 3 * 86400)).slice(0, portrait ? 3 : 4);
  $("upTitle").textContent = tx("upcoming");
  box.innerHTML = "";
  for (const e of list) {
    const row = document.createElement("div");
    row.className = "ev" + (e.start <= now ? " live" : "");
    const when = e.start <= now ? tx("live") : relTime(e.peak * 1000);
    const vis = e.visible === true ? ` · ${tx("visibleHere")}` : "";
    row.innerHTML = `<span class="when"></span><span class="what"></span><span class="sub"></span>`;
    row.children[0].textContent = when;
    row.children[1].textContent = eventTitle(e);
    row.children[2].textContent = dayFmt().format(new Date(e.peak * 1000)) + vis;
    box.appendChild(row);
  }
  box.parentElement.hidden = !list.length;
}

function fmtDist(km) {
  if (km < 1e6) return `${Math.round(km).toLocaleString(lang)} ${tx("km")}`;
  if (km < 1e9) return `${(km / 1e6).toLocaleString(lang, { maximumFractionDigits: km < 1e7 ? 1 : 0 })} ${tx("mkm")}`;
  return `${(km / 1e9).toLocaleString(lang, { maximumFractionDigits: 1 })} ${tx("bkm")}`;
}
function fmtLight(km) {
  const s = km / 299792.458;
  if (s < 120) return `${s.toFixed(1)} ${tx("s")}`;
  if (s < 7200) return `${Math.round(s / 60)} ${tx("min")}`;
  return `${(s / 3600).toLocaleString(lang, { maximumFractionDigits: 1 })} ${tx("h")}`;
}
function fmtDays(d) {
  if (Math.abs(d) < 2) return `${(Math.abs(d) * 24).toLocaleString(lang, { maximumFractionDigits: 1 })} ${tx("h")}`;
  if (Math.abs(d) < 800) return `${Math.round(Math.abs(d)).toLocaleString(lang)} ${tx("d")}`;
  return `${(Math.abs(d) / 365.25).toLocaleString(lang, { maximumFractionDigits: 1 })} ${tx("y")}`;
}

function eclOf(id) {
  if (id === "sun") return [0, 0, 0];
  if (cache[id]) return cache[id].ecl;
  if (id === "moon") return planetEcl("earth").map((x, i) => x + cache.moonG.ecl[i]);
  const c = comets.find((x) => x.id === id);
  if (c) return c.ecl;
  const p = probes.find((x) => x.id === id);
  if (p) return p.ecl;
  return null;
}

function showInfo(stop) {
  const card = $("info");
  if (!stop || !stop.body) { card.classList.remove("on"); return; }
  const id = stop.body;
  const b = bodies[id] || comets.find((c) => c.id === id) || probes.find((p) => p.id === id);
  if (!b) { card.classList.remove("on"); return; }
  const kindKey = { star: "star", planet: "planet", dwarf: "dwarf", moon: "moon", probe: "probe", comet: "comet" }[b.kind] || "planet";
  $("infoKind").textContent = tx(kindKey);
  $("infoName").textContent = b.kind === "comet" ? b.name : b.kind === "probe" ? b.name : nameOf(id);
  const rows = [];
  const ecl = eclOf(id);
  const earth = planetEcl("earth");
  if (ecl && id !== "earth") {
    const dE = (id === "moon" ? Math.hypot(...cache.moonG.ecl) : Math.hypot(ecl[0] - earth[0], ecl[1] - earth[1], ecl[2] - earth[2])) * AU_KM;
    rows.push([tx("fromEarth"), fmtDist(dE)]);
    rows.push([tx("light"), fmtLight(dE)]);
  }
  if (ecl && id !== "sun" && id !== "moon") rows.push([tx("fromSun"), fmtDist(Math.hypot(...ecl) * AU_KM)]);
  if (b.planet) {
    rows.push([tx("year"), fmtDays(b.planet.year)]);
    rows.push([tx("day"), fmtDays(b.planet.rot / 24)]);
    if (b.planet.moons) rows.push([tx("moons"), String(b.planet.moons)]);
  }
  if (b.kind === "probe" && b.launched) rows.push([tx("launched"), String(b.launched)]);
  if (b.kind === "comet") {
    const tp = nextPerihelion(b);
    rows.push([tx("perihelion"), new Intl.DateTimeFormat(lang === "en" ? "en-GB" : lang, { month: "long", year: "numeric" }).format(new Date(tp))]);
  }
  const dl = $("infoRows");
  dl.innerHTML = "";
  for (const [k, v] of rows.slice(0, 5)) {
    const dt = document.createElement("dt"); dt.textContent = k;
    const dd = document.createElement("dd"); dd.textContent = v;
    dl.append(dt, dd);
  }
  const facts = T().facts;
  let fact = facts[id] || (b.kind === "comet" ? facts.comet : "");
  if (b.kind === "comet" && b.live) fact = facts.comet;
  let note = "";
  if (b.kind === "probe" && !probeTables[id]) note = tx("approx");
  if (SIMPLE_MOONS_IDS.has(id) || (b.kind === "comet" && !b.live)) note = tx("simplified");
  $("infoFact").textContent = fact;
  $("infoNote").textContent = note;
  card.classList.add("on");
}
const SIMPLE_MOONS_IDS = new Set(Object.values(SIMPLE_MOONS).flat().map((m) => m[0]));
function nextPerihelion(c) {
  let tp = c.tpMs;
  if (c.e < 1) {
    const P = 365.25636 * DAY_MS * Math.pow(c.q / (1 - c.e), 1.5);
    while (tp < simNow - 60 * DAY_MS) tp += P;
  }
  return tp;
}

let bannerFor = null;
function showBanner(e, mode) {
  const el = $("banner");
  if (!e || !cfg.Banner) { el.classList.remove("on"); bannerFor = null; return; }
  const key = e.id + mode;
  if (bannerFor === key) return;
  bannerFor = key;
  $("bannerKicker").textContent = mode === "live" ? tx("live") : mode === "preview" ? `${tx("preview")} · ${relTime(e.peak * 1000)}` : relTime(e.peak * 1000);
  $("bannerTitle").textContent = eventTitle(e);
  const vis = e.visible === true ? tx("visibleHere") : e.visible === false ? tx("notVisibleHere") : "";
  $("bannerSub").textContent = [dateFmt().format(new Date(e.peak * 1000)), e.sub || vis].filter(Boolean).join(" · ");
  el.classList.add("on");
}

// ------------------------------------------------------------------ Einblendung "So sieht es bei dir aus"
const inset = $("inset");
const insetCtx = $("insetCanvas").getContext("2d");
const observer = () => (Number.isFinite(cfg.Lat) && Number.isFinite(cfg.Lon) && cfg.Lat !== null ? new A.Observer(cfg.Lat, cfg.Lon, 0) : null);

function drawInset(e, ms) {
  if (!e) { inset.classList.remove("on"); return; }
  const c = insetCtx, cv = c.canvas;
  const S = cv.width;
  c.clearRect(0, 0, S, S);
  const obs = observer();
  const t = atime(ms);
  let ok = false;
  c.save();
  c.translate(S / 2, S / 2);
  const bg = c.createRadialGradient(0, 0, 0, 0, 0, S * 0.7);
  if (e.type === "solar-eclipse") {
    const o = obs || new A.Observer(e.info?.lat ?? 0, e.info?.lon ?? 0, 0);
    const sun = A.Equator("Sun", t, o, true, true), moon = A.Equator("Moon", t, o, true, true);
    const sunR = Math.asin(696000 / (sun.dist * AU_KM)), moonR = Math.asin(1737.4 / (moon.dist * AU_KM));
    const [dx, dy] = tangent(sun, moon);
    const px = S * 0.22 / sunR;
    const cover = overlapJS(sunR, moonR, Math.hypot(dx, dy));
    const sky = 0.55 * (1 - cover) + 0.03;
    bg.addColorStop(0, `rgba(${40 + 120 * sky},${60 + 140 * sky},${90 + 150 * sky},1)`); bg.addColorStop(1, "rgba(5,8,16,1)");
    c.fillStyle = bg; c.fillRect(-S / 2, -S / 2, S, S);
    if (cover > 0.995) {      // Korona
      const cg = c.createRadialGradient(0, 0, sunR * px, 0, 0, sunR * px * 3);
      cg.addColorStop(0, "rgba(255,250,235,0.9)"); cg.addColorStop(1, "rgba(255,250,235,0)");
      c.fillStyle = cg; c.beginPath(); c.arc(0, 0, sunR * px * 3, 0, Math.PI * 2); c.fill();
    }
    c.fillStyle = "#ffe9b0"; c.beginPath(); c.arc(0, 0, sunR * px, 0, Math.PI * 2); c.fill();
    c.fillStyle = "#0b0d14"; c.beginPath(); c.arc(dx * px, -dy * px, moonR * px, 0, Math.PI * 2); c.fill();
    const sunAlt = obs ? A.Horizon(t, obs, sun.ra, sun.dec, "normal").altitude : 1;
    $("insetSub").textContent = obs && (cover < 0.005 || sunAlt < -0.5) && e.visible !== true
      ? tx("notVisibleHere") : `${Math.round(cover * 100)} % ${tx("obscured")}`;
    ok = true;
  } else if (e.type === "lunar-eclipse") {
    const o = obs || new A.Observer(0, 0, 0);
    const moon = A.Equator("Moon", t, o, true, true);
    const sun = A.Equator("Sun", t, o, true, true);
    // Mittelpunkt des Erdschattens: Gegenpunkt der Sonne (geozentrisch)
    const sunG = A.Equator("Sun", t, new A.Observer(0, 0, -6371000), true, true);
    const anti = { ra: (sunG.ra + 12) % 24, dec: -sunG.dec, dist: 1 };
    const moonGeo = A.Equator("Moon", t, new A.Observer(0, 0, -6371000), true, true);
    const [dx, dy] = tangent(anti, moonGeo);
    const moonR = Math.asin(1737.4 / (moonGeo.dist * AU_KM));
    const piM = Math.asin(6378.1 / (moonGeo.dist * AU_KM)), piS = 8.794 / 3600 * DEG / sunG.dist, sS = Math.asin(696000 / (sunG.dist * AU_KM));
    const umbra = 1.02 * (piM + piS - sS), pen = 1.02 * (piM + piS + sS);
    const px = S * 0.13 / moonR;
    bg.addColorStop(0, "rgba(14,18,32,1)"); bg.addColorStop(1, "rgba(4,6,12,1)");
    c.fillStyle = bg; c.fillRect(-S / 2, -S / 2, S, S);
    // Schatten relativ zum Mond zeichnen (Mond in der Mitte)
    const sx = -dx * px, sy = dy * px;
    c.save();
    c.beginPath(); c.arc(0, 0, moonR * px, 0, Math.PI * 2); c.clip();
    c.fillStyle = "#d9d6cc"; c.fillRect(-S / 2, -S / 2, S, S);
    const pg = c.createRadialGradient(sx, sy, umbra * px, sx, sy, pen * px);
    pg.addColorStop(0, "rgba(40,20,10,0.55)"); pg.addColorStop(1, "rgba(40,20,10,0)");
    c.fillStyle = pg; c.beginPath(); c.arc(sx, sy, pen * px, 0, Math.PI * 2); c.fill();
    const ug = c.createRadialGradient(sx, sy, 0, sx, sy, umbra * px);
    ug.addColorStop(0, "rgba(110,30,12,0.95)"); ug.addColorStop(0.92, "rgba(150,48,18,0.9)"); ug.addColorStop(1, "rgba(60,20,10,0.6)");
    c.fillStyle = ug; c.beginPath(); c.arc(sx, sy, umbra * px, 0, Math.PI * 2); c.fill();
    c.restore();
    c.strokeStyle = "rgba(255,255,255,0.18)"; c.setLineDash([4, 4]);
    c.beginPath(); c.arc(sx, sy, umbra * px, 0, Math.PI * 2); c.stroke();
    c.setLineDash([]);
    const alt = obs ? A.Horizon(t, obs, moon.ra, moon.dec, "normal").altitude : null;
    $("insetSub").textContent = alt === null ? tx("shadow") : alt > 0 ? `${tx("moon")} ${Math.round(alt)}°` : tx("notVisibleHere");
    void sun;
    ok = true;
  } else if (["conjunction", "opposition", "elongation", "transit", "supermoon"].includes(e.type)) {
    const o = obs || new A.Observer(50, 10, 0);
    const ids = e.type === "transit" ? [e.info.body, "sun"] : e.type === "supermoon" ? ["moon"]
      : e.type === "conjunction" ? [e.info.a, e.info.b] : e.type === "elongation" ? [e.info.body, "sun"] : [e.info.body, "moon"];
    const eqs = ids.map((id) => ({ id, eq: A.Equator(id.charAt(0).toUpperCase() + id.slice(1), t, o, true, true) }));
    const center = eqs[0].eq;
    const pts = eqs.map((x) => ({ id: x.id, xy: tangent(center, x.eq), eq: x.eq }));
    const span = Math.max(1.2 * DEG, ...pts.map((p) => Math.hypot(...p.xy) * 1.4));
    const px = S * 0.4 / span;
    bg.addColorStop(0, "rgba(18,24,44,1)"); bg.addColorStop(1, "rgba(5,7,14,1)");
    c.fillStyle = bg; c.fillRect(-S / 2, -S / 2, S, S);
    c.font = `${Math.round(S * 0.055)}px system-ui, sans-serif`; c.textAlign = "center";
    for (const p of pts) {
      const x = p.xy[0] * px, y = -p.xy[1] * px;
      const col = { sun: "#ffe7a0", moon: "#e8e6dc", mars: "#ff9a6a", jupiter: "#f3e1c0", saturn: "#f0dca0", venus: "#fff6d8", mercury: "#d8cfc4" }[p.id] || "#e0e8ff";
      const rr = p.id === "sun" || p.id === "moon" ? Math.max(3, Math.asin((p.id === "sun" ? 696000 : 1737.4) / (p.eq.dist * AU_KM)) * px) : 4;
      c.fillStyle = col; c.beginPath(); c.arc(x, y, Math.min(rr, S * 0.45), 0, Math.PI * 2); c.fill();
      c.fillStyle = "rgba(240,230,210,0.85)"; c.fillText(nameOf(p.id), x, y - Math.min(rr, S * 0.45) - 6);
    }
    // Maßstab: Mondgröße
    const mr = 0.26 * DEG * px;
    c.strokeStyle = "rgba(255,255,255,0.35)"; c.beginPath(); c.arc(-S * 0.36, S * 0.36, Math.min(mr, S * 0.1), 0, Math.PI * 2); c.stroke();
    $("insetSub").textContent = e.type === "conjunction" ? `${e.info.deg.toLocaleString(lang)}° · ${tx("moonSize")} ◯` : tx("moonSize") + " ◯";
    ok = true;
  }
  c.restore();
  $("insetTitle").textContent = obs ? tx("atHome") : tx("fromEarthSky");
  inset.classList.toggle("on", ok);
}

// Lage von b relativ zu a auf der Himmelskugel (Radiant, x nach Osten, y nach Norden)
function tangent(a, b) {
  const ra1 = a.ra * 15 * DEG, d1 = a.dec * DEG, ra2 = b.ra * 15 * DEG, d2 = b.dec * DEG;
  const cosc = Math.sin(d1) * Math.sin(d2) + Math.cos(d1) * Math.cos(d2) * Math.cos(ra2 - ra1);
  const x = Math.cos(d2) * Math.sin(ra2 - ra1) / cosc;
  const y = (Math.cos(d1) * Math.sin(d2) - Math.sin(d1) * Math.cos(d2) * Math.cos(ra2 - ra1)) / cosc;
  return [-x, y];
}
function overlapJS(r1, r2, d) {
  if (d >= r1 + r2) return 0;
  if (d <= Math.abs(r2 - r1)) return r2 >= r1 ? 1 : (r2 * r2) / (r1 * r1);
  const a = clamp((d * d + r1 * r1 - r2 * r2) / (2 * d * r1), -1, 1), b = clamp((d * d + r2 * r2 - r1 * r1) / (2 * d * r2), -1, 1);
  const k = (-d + r1 + r2) * (d + r1 - r2) * (d - r1 + r2) * (d + r1 + r2);
  return clamp((r1 * r1 * Math.acos(a) + r2 * r2 * Math.acos(b) - 0.5 * Math.sqrt(Math.max(0, k))) / (Math.PI * r1 * r1));
}

// ------------------------------------------------------------------ Rundflug
const tour = { stops: [], i: -1, phase: "fly", t0: 0, dur: 1, from: null, dirty: true, stop: null, previewOf: null };

function stopList() {
  const now = (Date.now() + TIME_OFFSET) / 1000;
  const list = [];
  const add = (s) => list.push(s);
  // Ereignis zuerst: läuft gerade (live) oder steht bevor (Vorschau)
  const lead = (cfg.LeadDays || 7) * 86400;
  const forced = params.get("event");
  let ev = null;
  if (forced) {
    ev = events.find((e) => e.id === forced) || events.find((e) => e.type.startsWith(forced) && e.end > now)
      || events.find((e) => e.type.startsWith(forced)) || null;
  } else if (focusEventId) {
    ev = events.find((e) => e.id === focusEventId) || null;
  } else {
    ev = events.find((e) => e.start <= now && e.end > now && e.prio <= 2 && showable(e))
      || (cfg.Preview ? events.find((e) => e.peak > now && e.peak - now < lead && e.prio <= 2 && showable(e)) : null);
  }
  if (ev) add({ id: "event", event: ev, mode: ev.start <= now && ev.end > now && !forced ? "live" : "preview", dwell: 44 });
  if (cfg.ShowOverview) add({ id: "overview-inner", label: "overviewInner" });
  if (cfg.ShowSun) add({ id: "sun", body: "sun" });
  if (cfg.ShowInner) for (const id of ["mercury", "venus", "earth", "mars"]) add({ id, body: id });
  if (cfg.ShowOuter) for (const id of ["jupiter", "saturn", "uranus", "neptune"]) add({ id, body: id });
  if (cfg.ShowDwarf) add({ id: "pluto", body: "pluto" });
  if (cfg.ShowProbes) for (const p of probes) if (p.ecl && (p.id !== "bepicolombo")) add({ id: p.id, body: p.id, probe: true });
  if (cfg.ShowComets) for (const c of comets) if (c.rAU < 8 || c.live) add({ id: c.id, body: c.id, comet: true });
  if (cfg.ShowOverview) add({ id: "overview-outer", label: "overviewOuter" });
  if (!list.length) add({ id: "overview-inner", label: "overviewInner" });
  return list;
}
const showable = (e) => !!e;

function framing(stop, ms, k) {
  // gibt { target, dir (Einheitsvektor Kamera <- Ziel), dist }
  const target = new THREE.Vector3();
  let dir = new THREE.Vector3(0, 0.6, 1).normalize();
  let dist = 30;
  const swing = (k ?? 0) * 0.45;           // langsames Kreisen während des Verweilens
  const sideOfSun = (pos, az, el) => {
    const s = pos.lengthSq() > 1e-6 ? pos.clone().negate().normalize() : new THREE.Vector3(1, 0, 0);
    s.y = 0; if (s.lengthSq() < 1e-6) s.set(1, 0, 0); s.normalize();
    const d = s.applyAxisAngle(new THREE.Vector3(0, 1, 0), az + swing);
    d.y = Math.tan(el); return d.normalize();
  };
  if (stop.id === "overview-inner") {
    dist = visR(1.8) * (portrait ? 3.6 : 2.5);
    dir.set(Math.cos(0.9 + swing), 1.1, Math.sin(0.9 + swing)).normalize();
  } else if (stop.id === "overview-outer") {
    dist = visR(40) * (portrait ? 3.4 : 2.3);
    dir.set(Math.cos(2.4 + swing), 1.35, Math.sin(2.4 + swing)).normalize();
  } else if (stop.id === "event") {
    return eventFraming(stop, ms, k);
  } else {
    const b = bodies[stop.body] || comets.find((c) => c.id === stop.body) || probes.find((p) => p.id === stop.body);
    if (!b) return framing({ id: "overview-inner" }, ms, k);
    target.copy(b.pos || b.group.position);
    const fov = camera.fov * DEG;
    if (stop.body === "sun") {
      dist = b.r * 6.5; dir.set(Math.cos(swing * 2), 0.35, Math.sin(swing * 2)).normalize();
    } else if (b.kind === "probe") {
      const out = target.clone().normalize();
      if (b.model && b.model.kind === "radial") {
        // hinter der Sonde, Blick zurück zur Sonne
        dist = 5; dir = out.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), 0.35 + swing).add(new THREE.Vector3(0, 0.25, 0)).normalize();
      } else {
        dist = 2.2; dir = sideOfSun(target, 1.1, 0.35);
      }
    } else if (b.kind === "comet") {
      const tail = b.ion.visible ? b.ion.material.uniforms.len.value : 0;
      dist = Math.max(3.5, tail * 1.6);
      const away = target.clone().normalize();
      dir = new THREE.Vector3().crossVectors(away, new THREE.Vector3(0, 1, 0)).normalize().add(new THREE.Vector3(0, 0.4, 0)).normalize();
      if (tail > 0.5) target.addScaledVector(away, tail * 0.35);
    } else {
      // erst nah am Planeten, beim Verweilen langsam zurück, bis die Monde im Bild sind
      const near = b.r * (stop.body === "saturn" ? 3.4 : 2.7);
      const wide = Math.max(near, b.sys * 1.2);
      const extent = Math.exp(lerp(Math.log(near), Math.log(wide), ease(clamp(((k ?? 0) - 0.1) / 0.8))));
      dist = extent / Math.tan(fov / 2) * (camera.aspect < 1 ? 0.85 / Math.max(0.45, camera.aspect) : 1.0);
      dir = sideOfSun(target, b.kind === "moon" ? 0.9 : 1.0, stop.body === "saturn" ? 0.55 : 0.28);
    }
  }
  return { target, dir, dist };
}

// Kamera bei Ereignissen
function eventFraming(stop, ms) {
  const e = stop.event;
  const target = new THREE.Vector3();
  let dir = new THREE.Vector3(0, 0.4, 1).normalize();
  let dist = 6;
  const earth = bodies.earth, moon = bodies.moon;
  const sunDir = earth.pos.clone().negate().normalize();      // von der Erde zur Sonne
  if (e.type === "lunar-eclipse" || e.type === "supermoon") {
    target.copy(earth.pos).lerp(moon.pos, 0.62);
    const side = new THREE.Vector3().crossVectors(sunDir, new THREE.Vector3(0, 1, 0)).normalize();
    dir = side.multiplyScalar(0.8).addScaledVector(sunDir, -0.55).add(new THREE.Vector3(0, 0.28, 0)).normalize();
    dist = earth.pos.distanceTo(moon.pos) * 2.0;
  } else if (e.type === "solar-eclipse") {
    target.copy(earth.pos).lerp(moon.pos, 0.5);
    const side = new THREE.Vector3().crossVectors(sunDir, new THREE.Vector3(0, 1, 0)).normalize();
    dir = sunDir.clone().multiplyScalar(0.62).addScaledVector(side, 0.75).add(new THREE.Vector3(0, 0.18, 0)).normalize();
    dist = earth.pos.distanceTo(moon.pos) * 2.3;
  } else if (e.type === "opposition" || e.type === "conjunction" || e.type === "elongation") {
    const ids = e.type === "conjunction" ? [e.info.a, e.info.b, "earth"] : [e.info.body, "earth", "sun"];
    const pts = ids.map((id) => bodies[id].pos);
    const box = new THREE.Box3().setFromPoints([...pts, new THREE.Vector3()]);
    box.getCenter(target);
    const size = box.getSize(new THREE.Vector3()).length();
    dist = size * (portrait ? 1.6 : 1.15) + 4;
    dir.set(0.25, 1.15, 0.55).normalize();
  } else if (e.type === "transit") {
    target.copy(bodies[e.info.body].pos).multiplyScalar(0.5);
    dist = visR(1) * 1.8;
    dir.set(0.3, 0.9, 0.6).normalize();
  } else if (e.type === "meteors" || e.type === "season") {
    target.copy(earth.pos);
    const side = new THREE.Vector3().crossVectors(sunDir, new THREE.Vector3(0, 1, 0)).normalize();
    dir = sunDir.clone().multiplyScalar(0.6).addScaledVector(side, 0.8).add(new THREE.Vector3(0, 0.3, 0)).normalize();
    dist = earth.r * 9;
  } else if (e.type === "comet") {
    const c = comets.find((x) => x.id === e.info.id);
    return framing({ id: "c", body: c ? c.id : "sun" }, ms, 0);
  }
  return { target, dir, dist };
}

function eventTimeline(stop, k) {
  // Sim-Zeit während eines Ereignis-Halts
  const e = stop.event;
  if (stop.mode === "live") return Date.now() + TIME_OFFSET;
  const pk = params.get("progress");
  const p = pk !== null ? Number(pk) : k;
  let a = e.start * 1000, b = e.end * 1000;
  if (e.type === "lunar-eclipse" && e.info && e.info.partialStart) { a = (e.info.partialStart - 1800) * 1000; b = (e.info.partialEnd + 1800) * 1000; }
  if (e.type === "solar-eclipse" && e.info && e.info.local) { a = (e.info.local.start - 600) * 1000; b = (e.info.local.end + 600) * 1000; }
  if (["opposition", "conjunction", "elongation"].includes(e.type)) { a = (e.peak - 30 * 86400) * 1000; b = (e.peak + 30 * 86400) * 1000; }
  return lerp(a, b, clamp(p));
}

function nextStop() {
  if (tour.dirty || !tour.stops.length) {
    const keep = tour.stop ? tour.stop.id : null;
    tour.stops = stopList();
    tour.dirty = false;
    const idx = keep ? tour.stops.findIndex((s) => s.id === keep) : -1;
    tour.i = idx;
    if (tour.stops[0] && tour.stops[0].id === "event" && keep !== "event") tour.i = -1;
  }
  if (FIXED_STOP) {
    const s = FIXED_STOP === "event" ? tour.stops.find((x) => x.id === "event") : null;
    return s || tour.stops.find((x) => x.id === FIXED_STOP) || { id: FIXED_STOP, body: bodies[FIXED_STOP] ? FIXED_STOP : null };
  }
  // Übernahme oder Vorführung: die Kamera bleibt beim Ereignis
  if (focusEventId && tour.stops[0] && tour.stops[0].id === "event") { tour.i = 0; return tour.stops[0]; }
  tour.i = (tour.i + 1) % tour.stops.length;
  return tour.stops[tour.i];
}

const camState = { target: new THREE.Vector3(), dir: new THREE.Vector3(0, 0.5, 1).normalize(), dist: 80 };
function beginStop(now) {
  const prev = { target: camState.target.clone(), dir: camState.dir.clone(), dist: camState.dist };
  tour.stop = nextStop();
  tour.from = prev;
  const first = tour.i === 0 && !tour.started;
  tour.started = true;
  tour.phase = (first || STILL || FIXED_STOP) ? "dwell" : "fly";
  const hop = prev.target.distanceTo(framing(tour.stop, simNow, 0).target);
  tour.flyDur = clamp(5 + Math.log2(1 + hop) * 1.2, 5, 12) * 1000;
  tour.dwellDur = (tour.stop.dwell || cfg.StopSeconds || 30) * 1000;
  tour.t0 = now;
  showInfo(tour.stop);
  document.body.classList.toggle("event", tour.stop.id === "event");
  if (tour.stop.id === "event") showBanner(tour.stop.event, tour.stop.mode);
  else {
    const now2 = Date.now() / 1000;
    const soon = events.find((e) => e.prio === 1 && e.peak > now2 && e.peak - now2 < (cfg.LeadDays || 7) * 86400);
    showBanner(soon || null, "soon");
  }
  $("stopTitle").textContent = tour.stop.label ? tx(tour.stop.label) : "";
  $("stopTitle").classList.toggle("on", !!tour.stop.label);
}

function slerpDir(a, b, k) {
  const q = new THREE.Quaternion().setFromUnitVectors(a, b);
  return a.clone().applyQuaternion(new THREE.Quaternion().slerp(q, k));
}

function updateCamera(now) {
  if (!tour.stop) beginStop(now);
  let el = now - tour.t0;
  if (tour.phase === "fly" && el >= tour.flyDur) { tour.phase = "dwell"; tour.t0 = now; el = 0; }
  if (tour.phase === "dwell" && el >= tour.dwellDur && !FIXED_STOP && !STILL) { beginStop(now); el = 0; }
  const stop = tour.stop;
  const dwellK = tour.phase === "dwell" ? clamp(el / tour.dwellDur) : 0;
  // Sim-Zeit
  if (stop.id === "event") {
    simNow = eventTimeline(stop, STILL ? 0.5 : (tour.phase === "dwell" ? dwellK : 0));
  } else {
    simNow = Date.now() + TIME_OFFSET;
  }
  const f = framing(stop, simNow, STILL ? 0.3 : dwellK);
  if (tour.phase === "fly") {
    const k = ease(clamp(el / tour.flyDur));
    const from = tour.from;
    camState.target.copy(from.target).lerp(f.target, k);
    camState.dir.copy(slerpDir(from.dir, f.dir, k));
    const hop = from.target.distanceTo(f.target);
    const lift = Math.sin(Math.PI * k) * Math.min(hop * 0.45, 60);
    camState.dist = Math.exp(lerp(Math.log(from.dist), Math.log(f.dist), k)) + lift;
  } else {
    camState.target.copy(f.target);
    camState.dir.copy(f.dir);
    camState.dist = f.dist;
  }
  camera.position.copy(camState.target).addScaledVector(camState.dir, camState.dist);
  camera.up.set(0, 1, 0);
  camera.lookAt(camState.target);
  camera.near = Math.max(0.01, camState.dist * 0.02);
  camera.far = 6000;
  camera.updateProjectionMatrix();
  post.uniforms.focus.value = camState.dist;
  post.uniforms.near.value = camera.near;
  post.uniforms.far.value = camera.far;
  // Ereignis-Extras
  const ev = stop.id === "event" ? stop.event : null;
  shadowCone.material.opacity = ev && ev.type === "lunar-eclipse" ? 0.16 : 0;
  shadowCone.visible = shadowCone.material.opacity > 0;
  if (ev && ["opposition", "conjunction", "elongation"].includes(ev.type)) {
    const ids = ev.type === "conjunction" ? ["earth", ev.info.a, ev.info.b] : ev.type === "opposition" ? ["sun", "earth", ev.info.body] : ["earth", "sun", ev.info.body];
    const pts = ids.map((id) => (id === "sun" ? new THREE.Vector3() : bodies[id].pos.clone()));
    if (ev.type !== "opposition") { pts.splice(1, 0, pts[0].clone()); }
    alignLine.geometry.setFromPoints(ev.type === "opposition" ? pts : [pts[1], pts[2], pts[0], pts[3]]);
    alignLine.computeLineDistances();
    alignLine.material.opacity = 0.55;
    alignLine.visible = true;
  } else { alignLine.visible = false; }
  for (const b of Object.values(bodies)) if (b.mat && b.mat.uniforms && b.mat.uniforms.highlight) b.mat.uniforms.highlight.value = 0;
  return { stop, ev, dwellK };
}

// ------------------------------------------------------------------ Beschriftungen
const tmpV = new THREE.Vector3();
function updateLabels(stop) {
  // Monde, die direkt vor der Linse vorbeiziehen würden, ausblenden (die Kamera fliegt manchmal durch ihre Bahn)
  for (const b of Object.values(bodies)) {
    if (b.kind === "moon" && b.group) b.group.visible = b.group.position.distanceTo(camera.position) > b.r * 7;
  }
  if (!cfg.Labels) return;
  const focus = stop && stop.body;
  const ev = stop && stop.id === "event";
  const overview = stop && /^overview/.test(stop.id);
  const all = [...Object.values(bodies), ...comets, ...probes];
  const camDist = camState.dist;
  const cand = [];
  const vh = window.innerHeight, vw = window.innerWidth;
  const pxPerUnit = vh / (2 * Math.tan(camera.fov * DEG / 2));
  for (const b of all) {
    const el = b.label;
    if (!el) continue;
    let o = 0;
    if (el.dataset.off !== "1" && !(b.group && !b.group.visible) && b.id !== focus) {
      tmpV.copy(b.pos || b.group.position);
      const d = tmpV.distanceTo(camera.position);
      tmpV.project(camera);
      if (tmpV.z < 1 && Math.abs(tmpV.x) < 1.05 && Math.abs(tmpV.y) < 1.05) {
        if (b.kind === "moon") o = smoothstep(camDist * 3.5, camDist * 1.2, d) * (b.parent && d < bodies[b.parent].sys * 14 ? 1 : 0);
        else if (b.kind === "probe") o = ev ? 0 : Math.max(smoothstep(40, 8, d), overview ? 0.75 * (b.model && b.model.kind === "radial" ? 0 : 1) : 0);
        else if (b.kind === "comet") o = ev ? 0 : Math.max(smoothstep(40, 8, d), overview && b.rAU < 6 ? 0.8 : 0);
        else o = 1;
        if (o > 0.02) {
          const x = (tmpV.x * 0.5 + 0.5) * vw, y = (-tmpV.y * 0.5 + 0.5) * vh;
          const lift = b.r ? Math.min(60, (b.r / Math.max(0.01, d)) * pxPerUnit) : 0;
          const prio = { star: 5, planet: 4, dwarf: 3, moon: 2, probe: 1, comet: 1 }[b.kind] || 1;
          cand.push({ el, x, y: y - lift - 8, o, prio, d, w: el.textContent.length * vh * 0.011 + 10, h: vh * 0.022 });
        }
      }
    }
    if (o <= 0.02) el.style.opacity = "0";
  }
  cand.sort((a, b) => b.prio - a.prio || a.d - b.d);
  const placed = panelBoxes();
  for (const c of cand) {
    const box = [c.x - c.w / 2, c.y - c.h, c.x + c.w / 2, c.y];
    const hit = placed.some((p) => box[0] < p[2] && box[2] > p[0] && box[1] < p[3] && box[3] > p[1]);
    if (hit) { c.el.style.opacity = "0"; continue; }
    placed.push(box);
    c.el.style.transform = `translate(${c.x.toFixed(1)}px, ${c.y.toFixed(1)}px) translate(-50%, -100%)`;
    c.el.style.opacity = c.o.toFixed(2);
  }
}

// Kästen auf dem Bild (Kopf, Infokasten, Demnächst, Banner, Bild-im-Bild): Namen weichen ihnen aus
const boxCache = { at: 0, list: [] };
function panelBoxes() {
  const now = performance.now();
  if (now - boxCache.at > 500) {
    boxCache.at = now;
    boxCache.list = [];
    for (const id of ["head", "info", "upcomingBox", "banner", "inset"]) {
      const el = document.getElementById(id);
      if (!el) continue;
      const cs = getComputedStyle(el);
      if (cs.display === "none" || parseFloat(cs.opacity) < 0.05) continue;
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) boxCache.list.push([r.left - 6, r.top - 6, r.right + 6, r.bottom + 6]);
    }
  }
  return boxCache.list.slice();
}

// ------------------------------------------------------------------ Bildrate
const perf = { frames: 0, since: performance.now(), good: 0, lastReport: 0, fps: 0 };
function watchPerf(now) {
  perf.frames += 1;
  const span = now - perf.since;
  if (span < 4000) return;
  const fps = perf.frames * 1000 / span;
  perf.fps = fps; perf.frames = 0; perf.since = now;
  if (STILL || params.get("scale")) return;
  let changed = false;
  if (fps < tier.target * 0.85 && scale > tier.min + 0.001) { scale = Math.max(tier.min, scale * (fps < tier.target * 0.6 ? 0.82 : 0.9)); perf.good = 0; changed = true; }
  else if (fps > tier.target * 1.35 && scale < tier.max - 0.001) { perf.good += 1; if (perf.good >= 3) { scale = Math.min(tier.max, scale * 1.08); perf.good = 0; changed = true; } }
  else perf.good = 0;
  if (changed) { try { localStorage.setItem("ssl-scale-" + tierName, scale.toFixed(3)); } catch (_) { /* egal */ } resize(); }
  if (now - perf.lastReport > 120000 || changed) {
    perf.lastReport = now;
    if (!DEMO) api(`api/gpu?fps=${fps.toFixed(1)}&scale=${scale.toFixed(2)}&tier=${tierName}&w=${W}&h=${H}&r=${encodeURIComponent(glInfo.slice(0, 100))}`).catch(() => {});
  }
}

// ------------------------------------------------------------------ Hauptschleife
let frameCount = 0;
let lastUi = 0;
const t0 = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  const { stop, ev } = updateCamera(now);
  updatePositions(simNow, false);
  const secs = (now - t0) / 1000;
  bodies.sun.mat.uniforms.time.value = secs;
  bodies.earth.mat.uniforms.cloudShift.value = (secs / 3600) * 0.25;
  const days = (simNow - Date.UTC(2000, 0, 1, 12)) / DAY_MS;
  for (const b of belts) b.material.uniforms.days.value = days;
  const px = H / 1080 * 1.0;
  for (const p of [stars, ...belts]) p.material.uniforms.px.value = Math.max(0.6, px * 1.2);
  sunGlow.material.rotation = secs * 0.01;
  post.uniforms.time.value = secs % 100;
  post.uniforms.maxR.value = Math.max(3, H / 1080 * 12);
  renderer.setRenderTarget(rt);
  renderer.render(scene, camera);
  renderer.setRenderTarget(null);
  renderer.render(postScene, postCam);
  updateLabels(stop);
  if (now - lastUi > 1000) {
    lastUi = now;
    $("clock").textContent = clockFmt().format(new Date(stop && stop.id === "event" ? simNow : Date.now() + TIME_OFFSET));
    if (ev) drawInset(ev, simNow); else inset.classList.remove("on");
    if (stop && stop.body) showInfo(stop);
  }
  frameCount += 1;
  if (frameCount === 3) { ready(); document.body.classList.add("shown"); }
  watchPerf(now);
}

// ------------------------------------------------------------------ Start
async function start() {
  $("brand").textContent = TEXT.en.brand;
  $("scaleNote").textContent = tx("scale");
  const tex = window.SSL_TEXTURES.makeAll(tierName);
  for (const [k, c] of Object.entries(tex)) TX[k + "C"] = c;
  for (const k of Object.keys(tex)) if (!["sunGlow", "milky"].includes(k)) TX[k] = texFrom(tex[k], k !== "rings" && k !== "dot");
  TX.rings.wrapS = THREE.ClampToEdgeWrapping;
  buildWorld();
  resize();
  window.addEventListener("resize", () => { clearTimeout(window.__rs); window.__rs = setTimeout(resize, 250); });
  setComets(OBJ.comets);
  setProbes(OBJ.probes);
  updatePositions(simNow, true);
  if (DEMO) { events = localEvents(); renderUpcoming(); }
  else {
    await Promise.race([poll(), new Promise((r) => setTimeout(r, 4000))]);
    setInterval(poll, 30000);
  }
  if (!events.length) { events = localEvents(); renderUpcoming(); }
  applySettings(cfg);
  requestAnimationFrame(frame);
  setTimeout(() => buildOrbits().then(() => applySettings(cfg)), 300);
  setInterval(renderUpcoming, 60000);
  report(`Start: ${tierName}, ${glInfo.slice(0, 80)}`);
}
start().catch((error) => { report("Start: " + error.message); console.error(error); ready(); });
