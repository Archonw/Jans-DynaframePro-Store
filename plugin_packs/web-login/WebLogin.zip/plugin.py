#!/usr/bin/env python3
"""Web Login - a login in front of the DynaFrame web page.

Parts:
- authd.py          the login service (runs as its own system service)
- weblogin_root.py  everything that needs administrator rights: nginx,
                    firewall, the service itself (run through sudo)
- this file         the plugin page where the owner sets the password,
                    the trusted devices and the ports to close, and switches
                    the protection on and off

All settings live in data/authd.json, which the login service and the root
part read too. Saving there and calling `weblogin_root.py apply` is all it
takes to change what the frame does.
"""

import os
import sys
import traceback
from datetime import datetime

_plugin_dir = os.environ.get("DYNAFRAME_PLUGIN_DIR") or os.path.dirname(os.path.abspath(__file__))
try:
    os.chdir(_plugin_dir)
except Exception:
    pass


def _write_crash_log(exc_type, exc_value, exc_tb):
    try:
        with open(os.path.join(_plugin_dir, "crash.log"), "a") as f:
            f.write(f"\n=== Crash at {datetime.now().isoformat()} ===\n")
            traceback.print_exception(exc_type, exc_value, exc_tb, file=f)
    except Exception:
        pass
    sys.__excepthook__(exc_type, exc_value, exc_tb)


sys.excepthook = _write_crash_log

import base64  # noqa: E402
import hashlib  # noqa: E402
import ipaddress  # noqa: E402
import json  # noqa: E402
import re  # noqa: E402
import secrets  # noqa: E402
import socket  # noqa: E402
import subprocess  # noqa: E402
import threading  # noqa: E402
import time  # noqa: E402
import urllib.request  # noqa: E402
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer  # noqa: E402
from pathlib import Path  # noqa: E402
from urllib.parse import unquote, urlparse  # noqa: E402

# Dynaframe puts the shared SDK one folder above each plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import oidc  # noqa: E402

PLUGIN_ID = "WebLogin"
PLUGIN_DIR = Path(__file__).resolve().parent
DATA_DIR = PLUGIN_DIR / "data"
CONFIG_FILE = DATA_DIR / "authd.json"
STUDIO_DIR = PLUGIN_DIR / "studio"
DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
ROOT_SCRIPT = PLUGIN_DIR / "weblogin_root.py"
INSTALLED_ROOT_SCRIPT = Path(os.environ.get("WEBLOGIN_ROOT", "/")) / "usr/local/lib/dfr-weblogin/weblogin_root.py"
AUTHD_URL = os.environ.get("WEBLOGIN_AUTHD", "http://127.0.0.1:8097")
SUDO = os.environ.get("WEBLOGIN_SUDO", "sudo -n").split()
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
LANGUAGES = ("de", "en", "es")
PBKDF2_ROUNDS = 310000
MIN_PASSWORD = 8
DEFAULT_PORTS = [8001, 8003, 8080]
NEVER_BLOCK = {22, 80, 443}
KNOWN_PORTS = {
    22: "ssh", 80: "web", 443: "webtls", 139: "samba", 445: "samba", 8001: "engine", 8003: "webui",
    8080: "renderer", 8090: "youtube", 8095: "photos",
}

plugin = create_plugin()
_lock = threading.Lock()
_cache = {"ports": (0, None), "status": (0, None)}


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return ""


# --------------------------------------------------------------------------
# Settings (data/authd.json)
# --------------------------------------------------------------------------

def read_config():
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def write_config(data):
    DATA_DIR.mkdir(exist_ok=True)
    tmp = CONFIG_FILE.with_suffix(".tmp")
    with open(os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600), "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=1, ensure_ascii=False)
    os.replace(tmp, CONFIG_FILE)


def config():
    """The settings with every field present."""
    data = read_config()
    changed = False
    defaults = {
        "active": False, "passwordHash": "", "sessionMinutes": 30 * 1440, "trusted": [], "language": "en",
        "blockPorts": list(DEFAULT_PORTS), "firewall": True, "openPaths": ["/nfc/", "/automations/"],
        "https": {"enabled": False, "cert": "", "key": ""}, "passwordLogin": True,
        "apiKeys": [], "keysHttpsOnly": True, "protectAutomations": False,
        "oidc": {"enabled": False, "issuer": "", "clientId": "", "clientSecret": "", "label": "",
                 "allowedUsers": [], "allowedGroups": [], "caPem": "", "insecure": False},
    }
    for key, value in defaults.items():
        if key not in data:
            data[key] = value
            changed = True
        elif isinstance(value, dict):
            if not isinstance(data[key], dict):
                data[key] = dict(value)
                changed = True
            for inner, default in value.items():
                if inner not in data[key]:
                    data[key][inner] = default
                    changed = True
    if not data.get("secret"):
        data["secret"] = secrets.token_hex(32)
        changed = True
    if data.get("pluginDir") != str(PLUGIN_DIR):
        data["pluginDir"] = str(PLUGIN_DIR)
        changed = True
    name = frame_name()
    if name and data.get("frameName") != name:
        data["frameName"] = name
        changed = True
    if changed:
        write_config(data)
    return data


def session_minutes(data):
    if data.get("sessionMinutes") is not None:
        return int(data["sessionMinutes"])
    return int(data.get("sessionDays") or 30) * 1440


def frame_name():
    try:
        return socket.gethostname()
    except OSError:
        return ""


def hash_password(password):
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ROUNDS)
    return f"pbkdf2_sha256${PBKDF2_ROUNDS}${base64.b64encode(salt).decode()}${base64.b64encode(digest).decode()}"


def clean_trusted(values):
    result = []
    for value in values or []:
        text = str(value).strip()
        if not text:
            continue
        try:
            net = ipaddress.ip_network(text, strict=False)
        except ValueError:
            raise PageError("badAddress", text)
        if net.num_addresses > 2 ** 16 and net.version == 4 or net.prefixlen == 0:
            raise PageError("tooWide", text)
        if text not in result:
            result.append(text)
    return result


def clean_ports(values):
    result = []
    for value in values or []:
        try:
            port = int(value)
        except (TypeError, ValueError):
            continue
        if 0 < port < 65536 and port not in NEVER_BLOCK and port not in result:
            result.append(port)
    return sorted(result)


class PageError(Exception):
    def __init__(self, code, detail=""):
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code = code
        self.detail = detail


# --------------------------------------------------------------------------
# Root part
# --------------------------------------------------------------------------

def root(verb, *args, timeout=180):
    """Run weblogin_root.py through sudo; the installed copy if there is one,
    so that the service and the plugin always use the same version."""
    script = ROOT_SCRIPT if verb == "install" or not INSTALLED_ROOT_SCRIPT.exists() else INSTALLED_ROOT_SCRIPT
    command = [*SUDO, "/usr/bin/python3", "-I", str(script), verb, *args]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"ok": False, "error": str(exc)}
    try:
        payload = json.loads(result.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        error = (result.stderr or result.stdout).strip()
        if "password" in error.lower() and "sudo" in error.lower():
            return {"ok": False, "error": "nosudo"}
        return {"ok": False, "error": error[:400] or f"exit {result.returncode}"}
    if not payload.get("ok"):
        plugin.log(f"{verb}: {payload.get('error')}", level="warning")
    return payload


def apply_now():
    data = config()
    verb = "install" if data.get("active") else "apply"
    if not data.get("active") and not INSTALLED_ROOT_SCRIPT.exists():
        return {"ok": True}
    payload = root(verb, str(PLUGIN_DIR)) if verb == "install" else root("apply")
    with _lock:
        _cache["status"] = (0, None)
    return payload


def cached(key, maker, seconds):
    with _lock:
        stamp, value = _cache[key]
    if value is not None and time.time() - stamp < seconds:
        return value
    value = maker()
    with _lock:
        _cache[key] = (time.time(), value)
    return value


def root_status():
    if not INSTALLED_ROOT_SCRIPT.exists():
        return {"ok": True, "installed": False, "nginx": "dynaframe", "firewall": "", "service": "inactive"}
    return root("status")


def listening_ports():
    payload = root("ports")
    rows = payload.get("ports") or [] if payload.get("ok") else []
    if not rows:
        rows = [{"port": p, "process": ""} for p in sorted(set(DEFAULT_PORTS) | {22, 80})]
    return rows


def authd_status():
    try:
        with urllib.request.urlopen(f"{AUTHD_URL}/status", timeout=2) as response:
            return json.loads(response.read().decode("utf-8"))
    except (OSError, ValueError):
        return None


# --------------------------------------------------------------------------
# Page actions
# --------------------------------------------------------------------------

def state():
    data = config()
    status = cached("status", root_status, 5)
    ports = cached("ports", listening_ports, 20)
    blocked = set(data.get("blockPorts") or [])
    port_rows = []
    for row in ports:
        number = row["port"]
        port_rows.append({
            "port": number, "process": row.get("process") or "", "kind": KNOWN_PORTS.get(number, ""),
            "blocked": number in blocked, "locked": number in NEVER_BLOCK,
        })
    for number in sorted(blocked - {r["port"] for r in port_rows}):
        port_rows.append({"port": number, "process": "", "kind": KNOWN_PORTS.get(number, ""),
                          "blocked": True, "locked": False, "idle": True})
    service = authd_status() if data.get("active") else None
    return {
        "success": True,
        "version": version(),
        "frame": data.get("frameName") or frame_name(),
        "theme": {"id": theme_id()},
        "settings": {
            "Language": data.get("language", "en"), "active": bool(data.get("active")),
            "passwordSet": bool(data.get("passwordHash")), "sessionMinutes": session_minutes(data),
            "trusted": data.get("trusted") or [], "firewall": bool(data.get("firewall", True)),
        },
        "status": status,
        "ports": sorted(port_rows, key=lambda r: r["port"]),
        "refused": [r for r in ((service or {}).get("refused") or [])
                    if r.get("ip") not in (data.get("trusted") or [])],
        "serviceUp": service is not None,
        "emergency": "sudo python3 /usr/local/lib/dfr-weblogin/weblogin_root.py off",
        "https": {"enabled": bool(data["https"].get("enabled")), "ownCert": bool(data["https"].get("cert"))},
        "passwordLogin": data.get("passwordLogin", True) is not False,
        "oidc": {**{k: v for k, v in data["oidc"].items() if k != "clientSecret"},
                 "secretSet": bool(data["oidc"].get("clientSecret"))},
        "redirectUris": redirect_uris(bool(data["https"].get("enabled"))),
        "keys": [{"id": k.get("id"), "name": k.get("name"), "created": k.get("created"),
                  "hint": k.get("hint"), **((service or {}).get("keyUse") or {}).get(k.get("id"), {})}
                 for k in data.get("apiKeys") or []],
        "keysHttpsOnly": data.get("keysHttpsOnly", True) is not False,
        "protectAutomations": bool(data.get("protectAutomations")),
    }


def frame_addresses():
    try:
        out = subprocess.run(["hostname", "-I"], capture_output=True, text=True, timeout=5).stdout.split()
    except (OSError, subprocess.TimeoutExpired):
        out = []
    result = []
    for text in out:
        try:
            ip = ipaddress.ip_address(text)
        except ValueError:
            continue
        if ip.version == 4:
            result.append(str(ip))
    return result


def redirect_uris(https):
    scheme = "https" if https else "http"
    host = frame_name()
    names = frame_addresses() + ([f"{host}.local", host] if host else [])
    return [f"{scheme}://{name}/dfr-login/oidc/callback" for name in names]


def clean_list(value):
    if isinstance(value, str):
        value = re.split(r"[\n,;]+", value)
    return [str(v).strip() for v in value or [] if str(v).strip()][:100]


def action_https(body):
    data = config()
    https = data["https"]
    if "enabled" in body:
        https["enabled"] = bool(body["enabled"])
    if body.get("clearCert"):
        https["cert"], https["key"] = "", ""
    if body.get("cert") or body.get("key"):
        cert, key = str(body.get("cert") or "").strip(), str(body.get("key") or "").strip()
        if "BEGIN CERTIFICATE" not in cert or "PRIVATE KEY" not in key:
            raise PageError("badCert")
        if "ENCRYPTED" in key:
            raise PageError("encryptedKey")
        https["cert"], https["key"] = cert, key
    data["https"] = https
    write_config(data)
    result = apply_now() if data.get("active") else {"ok": True}
    if not result.get("ok"):
        return {"success": False, "code": "apply", "error": result.get("error")}
    return {"success": True}


def action_oidc(body):
    data = config()
    o = data["oidc"]
    for key in ("issuer", "clientId", "label", "caPem"):
        if key in body:
            o[key] = str(body.get(key) or "").strip()
    if body.get("clientSecret"):
        o["clientSecret"] = str(body["clientSecret"]).strip()
    if body.get("clearSecret"):
        o["clientSecret"] = ""
    for key in ("allowedUsers", "allowedGroups"):
        if key in body:
            o[key] = clean_list(body.get(key))
    if "insecure" in body:
        o["insecure"] = bool(body["insecure"])
    if "enabled" in body:
        o["enabled"] = bool(body["enabled"])
    if o["enabled"] and not (o["issuer"] and o["clientId"]):
        raise PageError("oidcMissing")
    if o["issuer"] and not o["issuer"].startswith(("https://", "http://")):
        raise PageError("oidcIssuer")
    if "passwordLogin" in body:
        data["passwordLogin"] = bool(body["passwordLogin"])
    data["oidc"] = o
    write_config(data)
    return {"success": True}


def action_oidc_test(body):
    data = config()
    o = {**data["oidc"], **{k: v for k, v in body.items() if k in ("issuer", "caPem", "insecure")}}
    try:
        doc = oidc.Provider().document(o, fresh=True)
    except oidc.OidcError as exc:
        return {"success": False, "code": "oidcTest", "detail": str(exc), "error": str(exc)}
    return {"success": True, "issuer": doc.get("issuer"),
            "pkce": "S256" in (doc.get("code_challenge_methods_supported") or ["S256"]),
            "groups": "groups" in (doc.get("scopes_supported") or [])}


def action_key_create(body):
    name = str(body.get("name") or "").strip()[:60]
    if not name:
        raise PageError("keyName")
    data = config()
    key = "dfk_" + secrets.token_urlsafe(32)
    entry = {"id": secrets.token_hex(6), "name": name, "created": int(time.time()),
             "hash": hashlib.sha256(key.encode("utf-8")).hexdigest(), "hint": key[-4:]}
    data["apiKeys"] = [*(data.get("apiKeys") or []), entry]
    write_config(data)
    plugin.log(f"API key created: {name}")
    return {"success": True, "key": key, "name": name}


def action_key_delete(body):
    data = config()
    keep = [k for k in data.get("apiKeys") or [] if k.get("id") != body.get("id")]
    gone = len(data.get("apiKeys") or []) - len(keep)
    data["apiKeys"] = keep
    write_config(data)
    if gone:
        plugin.log("API key deleted")
    return {"success": True}


def action_access(body):
    data = config()
    if "keysHttpsOnly" in body:
        data["keysHttpsOnly"] = bool(body["keysHttpsOnly"])
    changed = "protectAutomations" in body and bool(body["protectAutomations"]) != bool(data.get("protectAutomations"))
    if "protectAutomations" in body:
        data["protectAutomations"] = bool(body["protectAutomations"])
    write_config(data)
    result = apply_now() if changed and data.get("active") else {"ok": True}
    if not result.get("ok"):
        return {"success": False, "code": "apply", "error": result.get("error")}
    return {"success": True}


def action_password(body):
    password = str(body.get("password") or "")
    if len(password) < MIN_PASSWORD:
        raise PageError("short")
    data = config()
    data["passwordHash"] = hash_password(password)
    write_config(data)
    plugin.log("password changed")
    return {"success": True}


def action_settings(body):
    data = config()
    if "Language" in body and str(body["Language"]).lower() in LANGUAGES:
        data["language"] = str(body["Language"]).lower()
    if "sessionMinutes" in body:
        try:
            data["sessionMinutes"] = max(5, min(365 * 1440, int(body["sessionMinutes"])))
            data.pop("sessionDays", None)
        except (TypeError, ValueError):
            pass
    if "trusted" in body:
        data["trusted"] = clean_trusted(body.get("trusted"))
    if "blockPorts" in body:
        data["blockPorts"] = clean_ports(body.get("blockPorts"))
    if "firewall" in body:
        data["firewall"] = bool(body.get("firewall"))
    write_config(data)
    result = apply_now() if data.get("active") and set(body) - {"Language", "sessionMinutes"} else {"ok": True}
    if not result.get("ok"):
        return {"success": False, "code": "apply", "error": result.get("error")}
    return {"success": True}


def action_active(body):
    data = config()
    want = bool(body.get("active"))
    if want and not data.get("passwordHash"):
        raise PageError("nopassword")
    data["active"] = want
    write_config(data)
    result = apply_now() if want else (root("off") if INSTALLED_ROOT_SCRIPT.exists() else {"ok": True})
    if not result.get("ok"):
        if want:   # leave nothing half switched on
            data["active"] = False
            write_config(data)
            root("off")
        code = "nosudo" if result.get("error") == "nosudo" else "apply"
        return {"success": False, "code": code, "error": result.get("error")}
    plugin.log(f"login {'switched on' if want else 'switched off'}")
    return {"success": True}


def action_logout_all(_body):
    data = config()
    data["secret"] = secrets.token_hex(32)
    write_config(data)
    return {"success": True}


def action_trust(body):
    ip = str(body.get("ip") or "").strip()
    data = config()
    data["trusted"] = clean_trusted([*(data.get("trusted") or []), ip])
    write_config(data)
    result = apply_now() if data.get("active") else {"ok": True}
    return {"success": bool(result.get("ok")), "error": result.get("error")}


# --------------------------------------------------------------------------
# The page
# --------------------------------------------------------------------------

def theme_id():
    try:
        stored = json.loads((DFR_DATA_DIR / "webui_theme.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return ""
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html():
    html = (STUDIO_DIR / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio.js", "application/javascript; charset=utf-8"),
}
POST_ACTIONS = {
    "/api/password": action_password,
    "/api/settings": action_settings,
    "/api/active": action_active,
    "/api/logout-all": action_logout_all,
    "/api/trust": action_trust,
    "/api/https": action_https,
    "/api/oidc": action_oidc,
    "/api/oidc-test": action_oidc_test,
    "/api/keys/create": action_key_create,
    "/api/keys/delete": action_key_delete,
    "/api/access": action_access,
}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        pass

    def _send(self, body, content_type, status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8", status)

    def _body(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        raw = self.rfile.read(min(length, 256 * 1024)) if length > 0 else b""
        try:
            body = json.loads(raw.decode("utf-8")) if raw else {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
            elif path in STUDIO_FILES:
                name, kind = STUDIO_FILES[path]
                self._send((STUDIO_DIR / name).read_bytes(), kind)
            elif path == "/api/state":
                self._json(state())
            else:
                self._json({"success": False, "error": "Not found"}, 404)
        except Exception as exc:
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        try:
            body = self._body()
            action = POST_ACTIONS.get(path)
            if action is None:
                self._json({"success": False, "error": "Not found"}, 404)
            else:
                self._json(action(body))
        except PageError as exc:
            self._json({"success": False, "code": exc.code, "detail": exc.detail, "error": str(exc)})
        except Exception as exc:
            plugin.log(f"{path} failed: {exc}", level="error")
            self._json({"success": False, "error": str(exc)}, 500)


_server = None


def start_page():
    global _server
    try:
        _server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        _server.daemon_threads = True
        threading.Thread(target=_server.serve_forever, name="weblogin-page", daemon=True).start()
        url = f"http://127.0.0.1:{_server.server_address[1]}/"
        plugin.register_advanced_settings_page(url)
        plugin.log(f"Plugin page at {url}")
    except Exception as exc:
        plugin.log(f"Plugin page not available: {exc}", level="warning")


def bring_up():
    """At start: if the login is on, make sure the service, nginx and the
    firewall are in place with this version's files (after an update, say)."""
    data = config()
    if data.get("active"):
        result = root("install", str(PLUGIN_DIR))
        plugin.log(f"login on: {result.get('did') if result.get('ok') else result.get('error')}")


def main():
    DATA_DIR.mkdir(exist_ok=True)
    config()
    start_page()
    plugin.connect_sse()
    plugin.ready()
    plugin.log(f"Web Login {version()} started")
    threading.Thread(target=bring_up, name="weblogin-up", daemon=True).start()
    try:
        while plugin.is_running():
            time.sleep(1)
    finally:
        try:
            plugin.unregister_advanced_settings_page()
        except Exception:
            pass


if __name__ == "__main__":
    main()
