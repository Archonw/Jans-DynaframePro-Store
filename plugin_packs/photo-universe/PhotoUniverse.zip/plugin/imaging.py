"""Die Bildarbeit des Photo Universe, mit Pillow (von Foto Mosaik).

- open_image(): Foto öffnen, richtig gedreht, JPEGs schon beim Entpacken verkleinert.
- file_meta(): Sterne, Datum, Kamera aus der Datei (auch aus foto.jpg.xmp).
- screen_photo(): das Foto, das sich aus dem Stern öffnet, in Bildschirmgröße.
"""

import io
import os
import re

from PIL import Image, ImageOps

try:  # HEIC-Fotos von iPhones, wenn das Paket da ist
    import pillow_heif  # type: ignore

    pillow_heif.register_heif_opener()
    HEIF = True
except Exception:  # pragma: no cover - optional
    HEIF = False

Image.MAX_IMAGE_PIXELS = 120_000_000


def open_image(data_or_path, want):
    """Bild öffnen, gedreht wie aufgenommen, mindestens `want` Pixel an der kurzen Seite (wenn möglich)."""
    source = io.BytesIO(data_or_path) if isinstance(data_or_path, (bytes, bytearray)) else data_or_path
    image = Image.open(source)
    if image.format == "JPEG":
        image.draft("RGB", (want, want))
    image = ImageOps.exif_transpose(image)
    if image.mode != "RGB":
        if image.mode in ("RGBA", "LA", "P", "PA"):
            image = image.convert("RGBA")
            flat = Image.new("RGB", image.size, (0, 0, 0))
            flat.paste(image, mask=image.split()[-1])
            image = flat
        else:
            image = image.convert("RGB")
    return image


def taken_date(data):
    """Aufnahmedatum aus EXIF als 2024-05-01T12:00:00, sonst ""."""
    try:
        with Image.open(io.BytesIO(data)) as image:
            exif = image.getexif()
            value = exif.get_ifd(0x8769).get(0x9003) or exif.get(0x0132) or ""
    except Exception:
        return ""
    value = str(value).strip()
    if len(value) >= 19 and value[4] == ":":
        return value[:10].replace(":", "-") + "T" + value[11:19]
    return ""


_RATING = (re.compile(rb'xmp:Rating="(-?\d)"'), re.compile(rb"<xmp:Rating>(-?\d)</xmp:Rating>"))


def file_meta(path):
    """EXIF/XMP-Daten direkt aus einer Fotodatei, wie sie die Mediendatenbank
    von DynaFrame hätte: Sterne (XMP oder EXIF 0x4746, auch aus einer .xmp
    daneben), Datum, Kamera, Größe. Für Fotos aus Ordnern ohne DB-Eintrag."""
    meta = {"r": 0, "mk": "", "md": "", "ln": "", "w": 0, "h": 0, "x": "", "n": os.path.basename(path)}
    taken = ""
    try:
        with Image.open(path) as image:
            meta["w"], meta["h"] = image.size
            exif = image.getexif()
            if exif.get(0x0112) in (5, 6, 7, 8):
                meta["w"], meta["h"] = meta["h"], meta["w"]
            meta["mk"] = str(exif.get(0x010F) or "").strip("\x00 ")[:60]
            meta["md"] = str(exif.get(0x0110) or "").strip("\x00 ")[:60]
            sub = exif.get_ifd(0x8769)
            meta["ln"] = str(sub.get(0xA434) or "").strip("\x00 ")[:80]
            value = str(sub.get(0x9003) or exif.get(0x0132) or "").strip()
            if len(value) >= 19 and value[4] == ":":
                taken = value[:10].replace(":", "-") + "T" + value[11:19]
            if exif.get(0x4746):
                meta["r"] = int(exif.get(0x4746))
    except Exception:
        return None, ""
    # XMP im Kopf der Datei oder als .xmp daneben
    sources = []
    for side in (path + ".xmp", os.path.splitext(path)[0] + ".xmp"):
        if os.path.isfile(side):
            sources.append(side)
    sources.append(path)
    for source in sources:
        try:
            with open(source, "rb") as handle:
                head = handle.read(512 * 1024)
        except OSError:
            continue
        found = next((m for m in (r.search(head) for r in _RATING) if m), None)
        if found:
            meta["r"] = max(0, int(found.group(1)))
            break
    return meta, taken


def screen_photo(data_or_path, width, height):
    """JPEG, das in width x height passt (nicht vergrößert), und seine Größe."""
    image = open_image(data_or_path, max(width, height))
    image.thumbnail((width, height), Image.LANCZOS)
    buffer = io.BytesIO()
    image.save(buffer, "JPEG", quality=86, optimize=True)
    return buffer.getvalue(), image.size
