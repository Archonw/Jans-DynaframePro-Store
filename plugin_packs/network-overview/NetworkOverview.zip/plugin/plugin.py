#!/usr/bin/env python3
"""Network Overview (früher Netzwerk-Lagebild) - der Plugin-Teil des Pakets.

Sammelt, was im Heimnetz los ist, und wertet es aus:

- Pi-hole (5 oder 6): Anfragen, Geblocktes, aktivste Geräte,
- Fritzbox über TR-064: welche Geräte online sind (LAN, WLAN, Gast),
  Internetverbindung und Datenvolumen,
- Unraid (offizielle API ab 7.2) oder Glances: Speicher, Platten mit
  Temperatur, CPU, RAM, Docker.

Daraus entstehen das Gerätebild für den Netzplan der Szene und ein kurzes
"Lagebild" mit dem, was heute auffällt (neues Gerät, heiße Platte, mehr
geblockt als sonst ...). Tageswerte bewahrt das Plugin selbst auf
(data/daily.json), damit es mit den letzten Tagen vergleichen kann.

Die Szene "network-overview" holt alles über den Proxy der Weboberfläche
auf :8003, wie bei Weltkarte Live. Sie kommt wie ein Bild in eine Playlist;
die Plugin-Seite kann dafür eine Playlist anlegen. Keine Übernahme des
Bildschirms, also auch kein Takeover-Playlist-Stopp nötig.
"""

import json
import os
import re
import socket
import sys
import threading
import time
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import sources  # noqa: E402
import own_playlist  # noqa: E402
import texts  # noqa: E402

plugin = create_plugin()

PLUGIN_ID = "NetworkOverview"
DISPLAY_NAME = "Network Overview"
# Ältere Namen erkennen, damit keine zweite Playlist entsteht.
PLAYLIST_NAMES = ("Network Overview", "Netzwerk-Lagebild", "Panorama de la red")
SCENE_ID = "network-overview"     # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen und Verlauf; bleibt bei Updates

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30
DAYS_KEPT = 60


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=1, ensure_ascii=False)
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält Passwörter und Keys
        except OSError:
            pass


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


def clock(epoch):
    return time.strftime("%H:%M", time.localtime(epoch)) if epoch else ""


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

SCHEMA = {
    "Language":        {"kind": "choice", "default": "de", "choices": texts.LANGUAGES},
    "PiholeAddress":   {"kind": "text", "default": ""},
    "PiholePassword":  {"kind": "secret", "default": ""},
    "Pihole2Address":  {"kind": "text", "default": ""},
    "Pihole2Password": {"kind": "secret", "default": ""},
    "Pihole3Address":  {"kind": "text", "default": ""},
    "Pihole3Password": {"kind": "secret", "default": ""},
    "FritzAddress":    {"kind": "text", "default": "fritz.box"},
    "FritzUser":       {"kind": "text", "default": ""},
    "FritzPassword":   {"kind": "secret", "default": ""},
    "ServerKind":      {"kind": "choice", "default": "unraid", "choices": ("unraid", "glances", "off")},
    "ServerAddress":   {"kind": "text", "default": ""},
    "ServerApiKey":    {"kind": "secret", "default": ""},
    "ShowOffline":     {"kind": "bool", "default": True},
    "Labels":          {"kind": "choice", "default": "active", "choices": ("all", "active", "none")},
    "HotDisk":         {"kind": "int", "default": 45, "min": 30, "max": 80},
    "FullPercent":     {"kind": "int", "default": 90, "min": 50, "max": 99},
    "PlaylistSeconds": {"kind": "int", "default": 120, "min": 10, "max": 86400},
    "MakePlaylist":        {"kind": "bool", "default": False},
}
SECRETS = [name for name, spec in SCHEMA.items() if spec["kind"] == "secret"]
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "choice":
        value = str(raw or "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "secret":
        return str(raw or "").strip()[:400]
    return re.sub(r"\s+", "", str(raw or ""))[:400]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


# --------------------------------------------------------------------------
# Quellen
# --------------------------------------------------------------------------

# Bis zu drei Pi-holes (z. B. zwei mit keepalived). Ihre Zahlen werden
# zusammengezählt; zeigen zwei Einträge auf dieselbe Pi-hole (die eigene
# Adresse und die keepalived-Adresse), zählt sie nur einmal und gilt als aktiv.
piholes = [sources.PiHole(log, index) for index in (1, 2, 3)]
PIHOLE_FIELDS = (("PiholeAddress", "PiholePassword"), ("Pihole2Address", "Pihole2Password"),
                 ("Pihole3Address", "Pihole3Password"))
fritz = sources.Fritzbox(log)
unraid = sources.Unraid(log)
glances = sources.Glances(log)
ALL_SOURCES = (*piholes, fritz, unraid, glances)


def server_source():
    kind = settings()["ServerKind"]
    return unraid if kind == "unraid" else glances if kind == "glances" else None


def apply_settings():
    values = settings()
    for source, (address, password) in zip(piholes, PIHOLE_FIELDS):
        # Ohne eigenes Passwort gilt das der ersten Pi-hole (oft gleich).
        source.configure(values[address], values[password] or values["PiholePassword"])
    fritz.configure(values["FritzAddress"], values["FritzUser"], values["FritzPassword"])
    kind = values["ServerKind"]
    unraid.configure(values["ServerAddress"] if kind == "unraid" else "", values["ServerApiKey"])
    glances.configure(values["ServerAddress"] if kind == "glances" else "")


def refresh_now():
    for source in ALL_SOURCES:
        source.poke()
    return {"success": True, "message": tr("Die Daten werden neu geladen.")}


def pihole_instances():
    """Die erreichbaren Pi-holes, doppelte (gleicher Rechnername) nur einmal."""
    seen, result, duplicates = set(), [], set()
    for source in piholes:
        if not source.enabled or source.status["state"] != "ok":
            continue
        data = source.snapshot()
        if not data:
            continue
        name = data.get("nodename") or data.get("address")
        if name in seen:
            duplicates.add(name)
            continue
        seen.add(name)
        result.append(data)
    return result, duplicates


def pihole_data():
    """Alle Pi-holes zusammen, in derselben Form wie eine einzelne."""
    rows, duplicates = pihole_instances()
    if not rows:
        return {}
    series, clients, blocked, devices = {}, {}, {}, {}
    for data in rows:
        for ts, total, block in data.get("series") or []:
            bucket = series.setdefault(ts // 600 * 600, [0, 0])
            bucket[0] += total
            bucket[1] += block
        for client in data.get("clients") or []:
            entry = clients.setdefault(client["ip"], {"ip": client["ip"], "name": client["name"], "count": 0})
            entry["count"] += client["count"]
            entry["name"] = entry["name"] or client["name"]
        for row in data.get("topBlocked") or []:
            blocked[row["domain"]] = blocked.get(row["domain"], 0) + row["count"]
        for device in data.get("devices") or []:
            key = device["mac"] or ",".join(device["ips"])
            old = devices.get(key)
            if old is None or device["lastQuery"] > old["lastQuery"]:
                devices[key] = device
    # Aktiv: die, auf die auch die keepalived-Adresse zeigt, sonst die mit den meisten Anfragen.
    busiest = max(rows, key=lambda d: d.get("perMinute", 0))
    instances = []
    for data in rows:
        name = data.get("nodename") or ""
        active = (name in duplicates) if duplicates else (data is busiest and len(rows) > 1)
        instances.append({"name": name or sources.host_of(data["address"]), "address": data["address"],
                          "ip": resolve(sources.host_of(data["address"])), "active": active,
                          "blocking": data.get("blocking", True), "perMinute": data.get("perMinute", 0)})
    for source in piholes:
        if source.enabled and source.status["state"] == "error":
            host = sources.host_of(source.base)
            instances.append({"name": source.nodename.strip("-") or host, "address": source.base, "ip": resolve(host),
                              "active": False, "blocking": True, "perMinute": 0, "down": True})

    def total(field):
        return sum(d.get(field, 0) for d in rows)

    return {
        "version": max(d.get("version") or 0 for d in rows),
        "blocking": all(d.get("blocking", True) for d in rows),
        "notBlocking": [i["name"] for i in instances if not i["blocking"] and not i.get("down")],
        "total24": total("total24"), "blocked24": total("blocked24"),
        "todayTotal": total("todayTotal"), "todayBlocked": total("todayBlocked"),
        "series": [[ts, v[0], v[1]] for ts, v in sorted(series.items())][-150:],
        "clients": sorted(clients.values(), key=lambda c: -c["count"]),
        "topBlocked": [{"domain": d, "count": n} for d, n in sorted(blocked.items(), key=lambda x: -x[1])[:5]],
        "domains": max(d.get("domains", 0) for d in rows),
        "perMinute": round(total("perMinute"), 1), "blockedPerMinute": round(total("blockedPerMinute"), 2),
        "devices": list(devices.values()),
        "instances": instances,
    }


# --------------------------------------------------------------------------
# Verlauf: Tageswerte und bekannte Geräte
# --------------------------------------------------------------------------

DAILY_FILE = DATA_DIR / "daily.json"
DEVICES_FILE = DATA_DIR / "devices.json"
_history_lock = threading.Lock()
daily = {}            # "2026-10-28": {total, blocked, down, up, downHours[24], online{hour: max}}
registry = {}         # key -> {name, first, last, conn}
registry_meta = {}    # {"seeded": zeit}
_dirty = {"daily": False, "devices": False}


def day_key(epoch=None):
    return datetime.fromtimestamp(epoch or now()).strftime("%Y-%m-%d")


def today_row():
    key = day_key()
    row = daily.get(key)
    if row is None:
        row = daily[key] = {"total": 0, "blocked": 0, "down": 0, "up": 0, "downHours": [0] * 24, "online": {}}
        for old in sorted(daily)[:-DAYS_KEPT]:
            daily.pop(old, None)
    return row


def load_history():
    global daily, registry, registry_meta
    stored = read_json(DAILY_FILE, {})
    daily = stored if isinstance(stored, dict) else {}
    stored = read_json(DEVICES_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    registry = stored.get("devices") if isinstance(stored.get("devices"), dict) else {}
    registry_meta = stored.get("meta") if isinstance(stored.get("meta"), dict) else {}


def save_history(force=False):
    with _history_lock:
        if _dirty["daily"] or force:
            write_json(DAILY_FILE, daily)
            _dirty["daily"] = False
        if _dirty["devices"] or force:
            write_json(DEVICES_FILE, {"meta": registry_meta, "devices": registry})
            _dirty["devices"] = False


def on_volume(down, up):
    """Die Fritzbox meldet, was seit der letzten Abfrage durch die Leitung ging."""
    with _history_lock:
        row = today_row()
        row["down"] = row.get("down", 0) + down
        row["up"] = row.get("up", 0) + up
        hours = row.setdefault("downHours", [0] * 24)
        hours[datetime.now().hour] += down
        _dirty["daily"] = True


fritz.on_volume = on_volume


def record_pihole(data):
    if not data:
        return
    with _history_lock:
        row = today_row()
        row["total"] = max(row.get("total", 0), data.get("todayTotal", 0))
        row["blocked"] = max(row.get("blocked", 0), data.get("todayBlocked", 0))
        _dirty["daily"] = True


def backfill_pihole():
    """Vergangene Tage aus Pi-holes Langzeit-Datenbank, damit der Vergleich
    nicht erst nach einer Woche funktioniert (nur Pi-hole 6)."""
    sources_v6 = [p for p in piholes if p.enabled and p.version == 6 and p.status["state"] == "ok"]
    names = {}
    for source in sources_v6:
        names.setdefault(source.nodename or source.base, source)
    sources_v6 = list(names.values())
    if not sources_v6:
        return
    midnight = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    for back in range(1, 8):
        start = midnight - timedelta(days=back)
        key = start.strftime("%Y-%m-%d")
        if daily.get(key, {}).get("total"):
            continue
        parts = [p.daily6(start.timestamp(), (start + timedelta(days=1)).timestamp() - 1) for p in sources_v6]
        if any(part is None for part in parts):
            continue
        result = {"total": sum(p["total"] for p in parts), "blocked": sum(p["blocked"] for p in parts)}
        if not result["total"]:
            continue
        with _history_lock:
            row = daily.setdefault(key, {"total": 0, "blocked": 0, "down": 0, "up": 0,
                                         "downHours": [0] * 24, "online": {}})
            row["total"], row["blocked"] = result["total"], result["blocked"]
            _dirty["daily"] = True


def past_days(n=14):
    key = day_key()
    return [daily[k] for k in sorted(daily) if k < key][-n:]


# --------------------------------------------------------------------------
# Geräte: Fritzbox + Pi-hole zu einem Bild zusammenführen
# --------------------------------------------------------------------------

KIND_RULES = [
    (r"pi-?hole|adguard", "pihole"),
    (r"iphone|android|pixel|galaxy-?s|redmi|xiaomi|oneplus|huawei|motorola|nokia|handy|phone|smartphone", "phone"),
    (r"ipad|tablet|tab-?s|kindle|fire-?hd|tolino", "tablet"),
    (r"watch|uhr", "watch"),
    (r"macbook|laptop|notebook|thinkpad|surface|xps|chromebook|zenbook|vivobook", "laptop"),
    (r"imac|mac-?mini|mac-?pro|desktop|\bpc\b|-pc\b|^pc|workstation|windows|win1\d", "computer"),
    (r"tv|fernseher|bravia|webos|tizen|firetv|fire-?tv|fire-?stick|chromecast|appletv|apple-?tv|roku|shield|"
     r"kodi|libreelec|osmc|sky-?q|magenta|telekom-?tv|vu\+|dreambox|enigma", "tv"),
    (r"echo|alexa|sonos|homepod|speaker|lautsprecher|nest-?(mini|audio|hub)|google-?home|bose|denon|heos|"
     r"yamaha|marantz|wiim|squeeze", "speaker"),
    (r"playstation|ps[345]|xbox|nintendo|switch|steam-?deck", "console"),
    (r"drucker|printer|hp[a-z0-9-]*|epson|brother|canon|kyocera|lexmark|laserjet|officejet|envy", "printer"),
    (r"cam|kamera|ring-|reolink|arlo|eufy|blink|doorbell|klingel|unifi-?protect", "camera"),
    (r"shelly|tasmota|esp|sonoff|tuya|hue|tradfri|dirigera|tado|homematic|ccu|zigbee|deconz|homey|"
     r"wled|fritz-?dect|myenergi|wallbox|wechselrichter|inverter|fronius|sma|smartmeter|tibber|"
     r"vacuum|roborock|roomba|staubsauger|miele|bosch|siemens|vorwerk|nuki|bridge|gateway", "smarthome"),
    (r"homeassistant|home-?assistant|hassio|\bha\b", "smarthome"),
    (r"nas|unraid|synology|diskstation|qnap|truenas|server|proxmox|pve|docker", "server"),
    (r"raspberry|raspberrypi|rpi|\bpi\d?\b|pi-?\d|dynaframe|frame", "board"),
    (r"repeater|fritz-?repeater|fritz-?powerline|powerline|mesh|access-?point|switch-|unifi|deco", "network"),
]
_KIND_RULES = [(re.compile(pattern, re.I), kind) for pattern, kind in KIND_RULES]
VENDOR_KINDS = [
    (r"apple", "phone"), (r"samsung|xiaomi|oneplus|huawei|motorola|google", "phone"),
    (r"espressif|shelly|tuya|signify|philips lighting|ikea|sonoff|itead|tado", "smarthome"),
    (r"sonos|bose|amazon", "speaker"), (r"raspberry", "board"), (r"avm", "network"),
    (r"hewlett|epson|brother|canon|kyocera", "printer"), (r"lg electronics|sony|tcl|hisense|roku", "tv"),
    (r"nintendo|microsoft|sony interactive", "console"), (r"synology|qnap", "server"),
]
_VENDOR_KINDS = [(re.compile(p, re.I), k) for p, k in VENDOR_KINDS]


def guess_kind(name, vendor="", model=""):
    for pattern, kind in _KIND_RULES:
        if pattern.search(name or "") or pattern.search(model or ""):
            return kind
    for pattern, kind in _VENDOR_KINDS:
        if pattern.search(vendor or ""):
            return kind
    return "other"


def own_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
            probe.connect(("192.0.2.1", 9))   # schickt nichts, sucht nur die Route
            return probe.getsockname()[0]
    except OSError:
        return ""


_resolved = {}


def resolve(host):
    """Name -> IPv4-Adresse, 10 Minuten zwischengespeichert."""
    if not host:
        return ""
    if re.match(r"^\d+\.\d+\.\d+\.\d+$", host):
        return host
    cached = _resolved.get(host)
    if cached and now() - cached[1] < 600:
        return cached[0]
    try:
        ip = socket.gethostbyname(host)
    except OSError:
        ip = ""
    _resolved[host] = (ip, now())
    return ip


_roles = {"at": 0.0, "ips": {}}


def role_ips():
    """IP-Adressen von Pi-hole, Server und diesem Rahmen; alle 10 Minuten neu."""
    if now() - _roles["at"] > 600:
        values = settings()
        _roles["ips"] = {
            "pihole": [ip for ip in (resolve(sources.host_of(values[a])) for a, _ in PIHOLE_FIELDS) if ip],
            "server": resolve(sources.host_of(values["ServerAddress"])) if values["ServerKind"] != "off" else "",
            "frame": own_ip(),
            "router": resolve(sources.host_of(values["FritzAddress"] or "fritz.box")),
        }
        _roles["at"] = now()
    return _roles["ips"]


def clean_name(name, ip=""):
    text = (name or "").strip()
    text = re.sub(r"\.(fritz\.box|local|lan|home|localdomain|speedport\.ip|box)$", "", text, flags=re.I)
    if not text or text in ("*", "?") or re.match(r"^\d+\.\d+\.\d+\.\d+$", text):
        return ip or "?"
    return text


def merge_devices():
    """Die Geräteliste für die Szene: Fritzbox zuerst, Pi-hole ergänzt
    Aktivität und Geräte, die die Fritzbox nicht kennt (oder wenn es keine
    Fritzbox gibt)."""
    t = now()
    fritz_data = fritz.snapshot() if fritz.enabled else {}
    pi_data = pihole_data()
    counts = {}
    names_by_ip = {}
    for client in pi_data.get("clients") or []:
        if client["ip"]:
            counts[client["ip"]] = counts.get(client["ip"], 0) + client["count"]
            if client["name"]:
                names_by_ip[client["ip"]] = client["name"]
    roles = role_ips()
    server_name = (server_payload().get("name") or "").lower()
    devices = {}

    for host in fritz_data.get("hosts") or []:
        key = host["mac"] or host["ip"]
        if not key:
            continue
        devices[key] = {"key": key, "ip": host["ip"], "mac": host["mac"],
                        "name": clean_name(host["name"] or names_by_ip.get(host["ip"], ""), host["ip"]),
                        "online": host["active"], "conn": host["conn"], "vendor": "", "model": host.get("model", ""),
                        "speed": host.get("speed", 0)}
    by_ip = {d["ip"]: d for d in devices.values() if d["ip"]}
    for row in pi_data.get("devices") or []:
        ips = [ip for ip in row["ips"] if ip and ":" not in ip] or row["ips"]
        if not ips or (row["mac"] or "").startswith("ip-"):
            # Pi-hole führt Clients ohne MAC als "ip-<adresse>"; die Fritzbox kennt sie meist schon.
            ips = ips or [row["mac"][3:]]
        target = devices.get(row["mac"]) or next((by_ip[ip] for ip in ips if ip in by_ip), None)
        if target is not None:
            target["vendor"] = target["vendor"] or row["vendor"]
            if target["name"] in ("?", target["ip"]) and row["name"]:
                target["name"] = clean_name(row["name"], target["ip"])
            continue
        if fritz_data.get("hosts") and not row["lastQuery"]:
            continue
        recent = t - row["lastQuery"] < 15 * 60
        if fritz_data.get("hosts") and t - row["lastQuery"] > 7 * 86400:
            continue  # lange weg und der Fritzbox unbekannt: nicht mehr zeigen
        key = row["mac"] if row["mac"] and not row["mac"].startswith("ip-") else ips[0]
        if key in devices or ips[0] in ("127.0.0.1", "::1"):
            continue
        devices[key] = {"key": key, "ip": ips[0], "mac": row["mac"], "name": clean_name(row["name"], ips[0]),
                        "online": recent, "conn": "other", "vendor": row["vendor"], "model": "", "speed": 0}

    total = sum(counts.values()) or 1
    seeded = registry_meta.get("seeded")
    changed = False
    result = []
    for device in devices.values():
        ip = device["ip"]
        role = next((r for r, rip in roles.items() if rip and (ip in rip if isinstance(rip, list) else rip == ip)), "")
        if not role and server_name and device["name"].lower() == server_name:
            role = "server"
        if role == "router":
            continue  # die Fritzbox ist die Mitte des Plans
        count = counts.get(ip, 0)
        if count and not fritz_data.get("hosts"):
            device["online"] = device["online"] or count > 0
        entry = registry.get(device["key"])
        if entry is None:
            entry = registry[device["key"]] = {"name": device["name"], "first": t, "last": 0, "conn": device["conn"]}
            changed = True
        if device["online"]:
            if t - entry.get("last", 0) > 300:
                changed = True
            entry["last"] = t
        if entry.get("name") != device["name"] and device["name"] != "?":
            entry["name"] = device["name"]
            changed = True
        kind = {"pihole": "pihole", "server": "server", "frame": "frame"}.get(role) or \
            guess_kind(device["name"], device["vendor"], device["model"])
        result.append({
            "key": device["key"], "name": device["name"], "ip": ip, "kind": kind, "role": role,
            "conn": device["conn"], "online": bool(device["online"]), "count": count,
            "share": round(count / total, 4),
            "new": bool(seeded and entry["first"] > seeded and t - entry["first"] < 86400),
            "first": entry["first"], "last": entry.get("last", 0),
        })
    if not seeded and result:
        registry_meta["seeded"] = t   # beim ersten Mal ist niemand "neu"
        changed = True
    if changed:
        _dirty["devices"] = True
    online = sum(1 for d in result if d["online"])
    if result:
        with _history_lock:
            hours = today_row().setdefault("online", {})
            hour = str(datetime.now().hour)
            if online > hours.get(hour, 0):
                hours[hour] = online
                _dirty["daily"] = True
    result.sort(key=lambda d: (not d["online"], -d["count"], d["name"].lower()))
    return result


# --------------------------------------------------------------------------
# Auswertung: das Lagebild
# --------------------------------------------------------------------------

TONE_ORDER = {"bad": 0, "warn": 1, "calm": 2, "info": 3, "good": 4}


def insights(devices, server):
    values = settings()
    lang = values["Language"]
    out = []

    def add(tone, icon, title, text=""):
        out.append({"tone": tone, "icon": icon, "title": title, "text": text})

    fritz_data = fritz.snapshot() if fritz.enabled and fritz.status["state"] == "ok" else {}
    connection = fritz_data.get("connection")
    if connection and connection.lower() != "connected":
        add("bad", "internet", tr("Internet ist getrennt"), tr("Die Fritzbox meldet: {state}", state=connection))

    pi = pihole_data()
    if pi and not pi.get("blocking", True):
        names = pi.get("notBlocking") or []
        title = tr("Pi-hole blockt gerade nicht") if len(pi.get("instances") or []) < 2 else \
            tr("{name} blockt gerade nicht", name=", ".join(names))
        add("warn", "pihole", title, tr("Werbung und Tracker kommen ungefiltert durch."))
    down = [p.label for p in piholes if p.enabled and p.status["state"] == "error"]
    if down and pi:
        add("warn", "pihole", tr("{name} antwortet nicht", name=", ".join(down)),
            tr("Die anderen Pi-holes laufen weiter."))

    if server:
        state = (server.get("state") or "").upper()
        if state and state != "STARTED":
            add("bad", "server", tr("Array ist nicht gestartet"), tr("Unraid meldet: {state}", state=state))
        limit = values["HotDisk"]
        hot = [d for d in server.get("disks") or [] if d.get("temp") is not None and d["temp"] >= limit]
        for disk in sorted(hot, key=lambda d: -d["temp"])[:2]:
            add("bad" if disk["temp"] >= limit + 10 else "warn", "disk",
                tr("{disk} ist {temp} °C warm", disk=disk["name"], temp=round(disk["temp"])),
                tr("Wärmer als die Grenze von {limit} °C.", limit=limit))
        for disk in server.get("disks") or []:
            status = (disk.get("status") or "").upper()
            if status and status not in ("DISK_OK", "DISK_NP", "DISK_NP_DSBL", "OK", ""):
                add("bad", "disk", tr("{disk} meldet {status}", disk=disk["name"],
                                      status=status.replace("DISK_", "").lower()))
        total, used = server.get("total") or 0, server.get("used") or 0
        if total and used / total * 100 >= values["FullPercent"]:
            add("warn", "server", tr("Server-Speicher zu {pct} % voll", pct=round(used / total * 100)),
                tr("Noch {free} frei.", free=texts.size(lang, total - used)))

    fresh = [d for d in devices if d["new"]]
    if len(fresh) == 1:
        add("warn", "device", tr("Neues Gerät: {name}", name=fresh[0]["name"]),
            tr("zum ersten Mal gesehen um {time}", time=clock(fresh[0]["first"])))
    elif fresh:
        add("warn", "device", tr("Neue Geräte: {names}", names=", ".join(d["name"] for d in fresh[:3]) +
                                 (" …" if len(fresh) > 3 else "")),
            tr("{n} Geräte, zuerst gesehen heute", n=len(fresh)))

    if fritz_data:
        down, max_down = fritz_data.get("downBps", 0), fritz_data.get("maxDown", 0)
        if max_down and down > 0.6 * max_down:
            add("info", "volume", tr("Gerade viel los: {rate} im Download", rate=texts.rate(lang, down)),
                tr("{pct} % der Leitung", pct=round(down / max_down * 100)))

    past = past_days()
    if pi and pi.get("todayTotal"):
        pct = pi["todayBlocked"] / pi["todayTotal"] * 100
        rows = [r for r in past if r.get("total")]
        if rows:
            avg = sum(r["blocked"] / r["total"] * 100 for r in rows) / len(rows)
            if pct > avg + 3:
                note = tr("mehr als im Schnitt der letzten Tage ({avg} %)", avg=texts.decimal(lang, avg))
            elif pct < avg - 3:
                note = tr("weniger als im Schnitt der letzten Tage ({avg} %)", avg=texts.decimal(lang, avg))
            else:
                note = tr("wie im Schnitt der letzten Tage")
        else:
            note = ""
        add("info", "pihole", tr("Heute {pct} % der Anfragen geblockt", pct=texts.decimal(lang, pct)), note)
    if pi and pi.get("topBlocked"):
        top = pi["topBlocked"][0]
        add("info", "pihole", tr("Am häufigsten geblockt: {domain}", domain=top["domain"]),
            tr("{n}-mal in 24 Stunden", n=texts.number(lang, top["count"])))

    active = [d for d in devices if d["count"] and d["role"] not in ("pihole", "server")]
    if active:
        best = max(active, key=lambda d: d["count"])
        add("info", "activity", tr("Am aktivsten: {name}", name=best["name"]),
            tr("{n} DNS-Anfragen in 24 Stunden, {pct} % von allen", n=texts.number(lang, best["count"]),
               pct=round(best["share"] * 100)))

    online = sum(1 for d in devices if d["online"])
    if devices:
        hour = str(datetime.now().hour)
        usual = [r["online"][hour] for r in past if isinstance(r.get("online"), dict) and r["online"].get(hour)]
        note = ""
        if len(usual) >= 3:
            avg = sum(usual) / len(usual)
            if online > avg * 1.3 + 1:
                note = tr("mehr als sonst um diese Zeit ({avg})", avg=round(avg))
            elif online < avg * 0.7 - 1:
                note = tr("weniger als sonst um diese Zeit ({avg})", avg=round(avg))
        add("info", "device", tr("{n} Geräte online", n=online), note)

    if fritz_data:
        today = daily.get(day_key(), {})
        down_today = today.get("down", 0)
        if down_today > 50e6:
            hour = datetime.now().hour
            frac = datetime.now().minute / 60
            normal = [sum(r["downHours"][:hour]) + r["downHours"][hour] * frac
                      for r in past if isinstance(r.get("downHours"), list) and sum(r["downHours"])]
            note = ""
            if len(normal) >= 3:
                avg = sum(normal) / len(normal)
                if avg and down_today > avg * 1.3:
                    note = tr("{pct} % mehr als an einem normalen Tag bis jetzt", pct=round((down_today / avg - 1) * 100))
                elif avg and down_today < avg * 0.7:
                    note = tr("{pct} % weniger als an einem normalen Tag bis jetzt", pct=round((1 - down_today / avg) * 100))
            add("info", "volume", tr("Heute {volume} aus dem Internet geladen", volume=texts.size(lang, down_today)), note)

    if server:
        asleep = [d["name"] for d in server.get("disks") or [] if not d.get("spinning") and d.get("role") != "cache"]
        if asleep:
            add("good", "disk", tr("Platten schlafen: {names}", names=", ".join(asleep[:4]) + (" …" if len(asleep) > 4 else "")),
                tr("spart Strom"))
        containers = server.get("containers") or {}
        if containers.get("total"):
            add("good", "server", tr("{n} von {m} Containern laufen", n=containers["running"], m=containers["total"]))

    if not any(i["tone"] in ("bad", "warn") for i in out) and out:
        out.insert(0, {"tone": "calm", "icon": "ok", "title": tr("Alles ruhig"), "text": ""})
    out.sort(key=lambda i: TONE_ORDER[i["tone"]])
    return out


# --------------------------------------------------------------------------
# Sammeln im Hintergrund
# --------------------------------------------------------------------------

_stop_requested = threading.Event()
_view = {"devices": [], "insights": [], "at": 0.0}
_view_lock = threading.Lock()


def server_payload():
    source = server_source()
    if source is None or not source.enabled or source.status["state"] != "ok":
        return {}
    return source.snapshot()


def rebuild_view():
    devices = merge_devices()
    server = server_payload()
    result = insights(devices, server)
    with _view_lock:
        _view.update(devices=devices, insights=result, at=now())


def collector():
    last_save = now()
    last_backfill = 0.0
    while not _stop_requested.is_set():
        t = now()
        touched = False
        for source in ALL_SOURCES:
            if source.due(t):
                source.run_once(t)
                touched = True
                if source in piholes and source.status["state"] == "ok":
                    record_pihole(pihole_data())
        if any(p.status["state"] == "ok" for p in piholes) and t - last_backfill > 6 * 3600:
            last_backfill = t
            try:
                backfill_pihole()
            except Exception as exc:  # pragma: no cover
                log(f"Rückblick aus Pi-hole: {exc!r}", "warning")
        if touched or t - _view["at"] > 30:
            try:
                rebuild_view()
            except Exception as exc:  # pragma: no cover
                log(f"Lagebild: {exc!r}", "warning")
        if t - last_save > 300:
            save_history()
            last_save = t
        _stop_requested.wait(2)


# --------------------------------------------------------------------------
# Die Engine: eine Playlist für die Szene
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def find_scene():
    """Die installierte Szene. Ihre numerische id braucht ein Playlist-Eintrag."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=PLAYLIST_NAMES,
    name=lambda: DISPLAY_NAME,
    description=lambda: tr("Dein Heimnetz auf einen Blick."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()


# --------------------------------------------------------------------------
# Was die Szene und die Seite bekommen
# --------------------------------------------------------------------------

def scene_payload():
    values = settings()
    with _view_lock:
        devices = list(_view["devices"])
        found = list(_view["insights"])
    fritz_data = fritz.snapshot() if fritz.enabled else {}
    pi = pihole_data()
    server = server_payload()
    today = daily.get(day_key(), {})
    week = []
    for back in range(6, -1, -1):
        key = day_key(now() - back * 86400)
        row = daily.get(key, {})
        week.append({"day": key, "total": row.get("total", 0), "blocked": row.get("blocked", 0),
                     "down": row.get("down", 0)})
    if pi:
        week[-1].update(total=pi.get("todayTotal", 0), blocked=pi.get("todayBlocked", 0))
    return {
        "success": True,
        "now": now(),
        "version": version(),
        "settings": {k: values[k] for k in ("Language", "ShowOffline", "Labels", "HotDisk")},
        "status": {"pihole": "ok" if pi else ("off" if not any(p.enabled for p in piholes) else "error"), "fritz": fritz.status["state"],
                   "server": (server_source().status["state"] if server_source() else "off")},
        "internet": {
            "connection": fritz_data.get("connection", ""), "down": fritz_data.get("downBps", 0),
            "up": fritz_data.get("upBps", 0), "maxDown": fritz_data.get("maxDown", 0),
            "maxUp": fritz_data.get("maxUp", 0), "uptime": fritz_data.get("uptime", 0),
            "model": fritz_data.get("model", ""), "todayDown": today.get("down", 0), "todayUp": today.get("up", 0),
        } if fritz_data else None,
        "pihole": {
            "blocking": pi.get("blocking", True), "todayTotal": pi.get("todayTotal", 0),
            "todayBlocked": pi.get("todayBlocked", 0), "total24": pi.get("total24", 0),
            "blocked24": pi.get("blocked24", 0), "series": pi.get("series", []),
            "topBlocked": pi.get("topBlocked", [])[:3], "perMinute": pi.get("perMinute", 0),
            "blockedPerMinute": pi.get("blockedPerMinute", 0), "domains": pi.get("domains", 0),
            "instances": pi.get("instances", []),
        } if pi else None,
        "server": server or None,
        "week": week,
        "devices": devices[:160],
        "insights": found[:6],
    }


ERRORS = {
    "network": "Keine Verbindung. Stimmt die Adresse?",
    "timeout": "Keine Antwort (Zeitüberschreitung).",
    "tls": "Zertifikatsfehler bei https.",
    "server": "Der Server meldet einen Fehler.",
    "notfound": "Der Server meldet einen Fehler.",
}
SOURCE_ERRORS = {
    "pihole": {"login": "Anmeldung abgelehnt. Stimmt das Passwort?", "nopassword": "Pi-hole verlangt ein Passwort.",
               "seats": "Pi-hole hat zu viele offene Sitzungen. Es geht gleich von selbst weiter.",
               "nopihole": "Unter dieser Adresse antwortet kein Pi-hole."},
    "fritz": {"login": "Anmeldung abgelehnt. Stimmen Benutzer und Passwort?",
              "rights": "Dem Benutzer fehlt das Recht „FRITZ!Box Einstellungen“.",
              "notr064": "Die Fritzbox antwortet nicht über TR-064. Ist „Zugriff für Anwendungen zulassen“ an?"},
    "server": {"key": "Der API-Key wird nicht angenommen.",
               "noapi": "Keine Unraid-API gefunden. Sie gibt es ab Unraid 7.2; sonst Glances nehmen.",
               "query": "Die Unraid-API versteht die Abfrage nicht: {detail}",
               "noglances": "Unter dieser Adresse antwortet kein Glances."},
}


def source_payload(source):
    if source is None:
        return {"state": "off", "tone": "", "text": tr("Ausgeschaltet"), "detail": ""}
    with source.lock:
        status = dict(source.status)
    state = status["state"]
    if state == "off":
        text = tr("Noch nicht eingerichtet")
    elif state == "nokey":
        text = tr("Noch kein API-Key") if source.name == "server" else tr("Noch kein Passwort")
    elif state == "error":
        code = status["error"]
        template = SOURCE_ERRORS.get(source.name, {}).get(code) or ERRORS.get(code) or "Fehler: {code}"
        text = tr(template, code=code, detail=status.get("detail", ""))
    elif state == "loading" and not status["at"]:
        text = tr("Lädt …")
    else:
        text = tr("Verbunden um {time}", time=clock(status["at"]))
    tone = {"ok": "ok", "error": "bad", "loading": "busy"}.get(state, "")
    return {"state": state, "tone": tone, "text": text, "detail": status.get("detail") or ""}


DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    with _view_lock:
        devices = list(_view["devices"])
    fritz_data = fritz.snapshot() if fritz.enabled else {}
    server = server_payload()
    lang = values["Language"]
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "piholes": [dict(source_payload(p), extra=" · ".join(x for x in (
            (p.snapshot().get("nodename") if p.status["state"] == "ok" else ""),
            (f"Pi-hole {p.version}" if p.version and p.status["state"] == "ok" else "")) if x))
            for p in piholes],
        "fritz": dict(source_payload(fritz), extra=" ".join(x for x in (fritz_data.get("model"), fritz_data.get("firmware")) if x)),
        "server": dict(source_payload(server_source()), extra=server.get("name", "") if server else ""),
        "devices": {"text": tr("{n} online, {m} bekannt", n=sum(1 for d in devices if d["online"]), m=len(devices))
                    if devices else "–",
                    "list": [{"name": d["name"], "ip": d["ip"], "kind": d["kind"], "online": d["online"],
                              "conn": d["conn"], "count": texts.number(lang, d["count"]), "new": d["new"]}
                             for d in devices[:200]]},
        "theme": {"id": theme_id()},
    }


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über :8003.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        """Den ganzen Body lesen: ungelesene Bytes würden auf einer offenen
        Verbindung zum Anfang der nächsten Anfrage."""
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(), cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                for name in SECRETS:
                    # Ein leeres Feld heißt: das alte behalten. Löschen geht mit "-".
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)
                    elif name in body and str(body[name]).strip() == "-":
                        body[name] = ""
                changed = save_settings(body)
                if "MakePlaylist" in changed:
                    OWN.changed()
                if changed:
                    _roles["at"] = 0.0
                    apply_settings()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(refresh_now())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}")

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: refresh_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    load_history()
    apply_settings()
    threading.Thread(target=collector, name=f"{PLUGIN_ID}-collector", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    try:
        save_history()
    except Exception:
        pass
    for source in ALL_SOURCES:
        source.close()
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
