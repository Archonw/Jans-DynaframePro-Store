"""Sichern und Zurückspielen der Einstellungen aller Plugins.

Was gesichert wird, pro Plugin unter ~/.local/share/dfr/plugins/<Name>/:
- die Werte der Plugins-Seite (manifest.json, "Settings"[].Value),
- der Ordner data/ (dort legen die meisten Plugins ihre Einstellungen ab) und
  ein paar übliche Einstellungsdateien direkt im Plugin-Ordner,
- dazu die Einstellungen der Szenen in der Engine (/dynamic-scenes/{id}/settings).

Was nur zu diesem Rahmen gehört (Takeover-Playlist-Nummern in state.json,
Caches, Fotos, gekoppelte Handys, Logs), bleibt weg; die Plugins legen das auf
dem neuen Rahmen selbst neu an.

Zugangsdaten (API-Schlüssel, Passwörter, Tokens) kommen nur in die Datei, wenn
sie mit einem Passwort verschlüsselt wird. Ohne Passwort stehen an ihrer Stelle
Platzhalter, und beim Zurückspielen bleiben die Zugangsdaten des Ziel-Rahmens
stehen. Die Verschlüsselung braucht nur die Standardbibliothek: PBKDF2-SHA256
für den Schlüssel, HMAC-SHA256 im Zählermodus als Schlüsselstrom und ein
HMAC-SHA256 über alles, damit ein falsches Passwort sicher erkannt wird.
"""
import base64
import copy
import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import socket
import time
from datetime import datetime, timezone
from pathlib import Path

FORMAT = "dynaframe-settings-backup"
FORMAT_VERSION = 1
OMITTED = "__settings_backup_omitted__"

MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_TOTAL_BYTES = 60 * 1024 * 1024
MAX_CODE_BYTES = 25 * 1024 * 1024
MAX_DEPTH = 4
KDF_ITERATIONS = 200_000

NAME_OK = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,99}$")
SECRET_KEY = re.compile(r"passw|passwort|secret|token|api[_-]?key|key$|keys$|credential|auth(?!or)|cookie|private",
                        re.I)
SECRET_FILE = re.compile(r"secret|credential|token|passw|\.env$|\.key$|\.pem$", re.I)

# Einstellungsdateien, die manche Plugins direkt in ihren Ordner legen.
ROOT_FILES = ("settings.json", "config.json", "options.json", "picker.json", "user_settings.json")
SETTING_DIRS = ("data", "config")

# Gehört nur zu diesem Rahmen oder entsteht von selbst neu.
SKIP_NAMES = {
    "state.json", "playback_selection_state.json", "webui_theme.json", "events.json", "devices.json",
    "results.json", "points.json", "places.json", "order.json", "fuel_history.json", "index.json",
    "pending-import.json", "page_url",
}
SKIP_DIRS = {
    "cache", "caches", "tmp", "temp", "log", "logs", "photos", "images", "media", "videos", "buffer",
    "thumbs", "thumbnails", "backups", "undo", "venv", "__pycache__", "node_modules", "downloads",
}
# Beim Code eines Plugins ohne Store: was der Rahmen selbst neu anlegt.
CODE_SKIP_DIRS = {"venv", ".venv", "__pycache__", "data", "config", "cache", "caches", "logs", "log", "tmp", "temp",
                  "node_modules", ".git"}
CODE_SKIP_FILES = {"manifest.json", ".dynaframe-install.json", "crash.log"}

SKIP_SUFFIXES = {
    ".log", ".tmp", ".pid", ".lock", ".pyc", ".sqlite", ".sqlite3", ".db", ".db-wal", ".db-shm",
    ".jpg", ".jpeg", ".png", ".webp", ".gif", ".heic", ".heif", ".bmp", ".tif", ".tiff",
    ".mp4", ".mov", ".m4v", ".mkv", ".webm", ".mp3", ".m4a", ".wav", ".gz", ".part",
}


class BackupError(Exception):
    """Fehler mit Code für die Seite (Texte in DE/EN/ES kommen aus studio.js)."""

    def __init__(self, code, detail=""):
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code = code
        self.detail = detail


# --------------------------------------------------------------------------
# Kleinkram
# --------------------------------------------------------------------------

def now_iso():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def read_json(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


def write_bytes(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".sbtmp")
    with open(temp, "wb") as stream:
        stream.write(data)
    temp.replace(path)


def write_json(path, value, indent=2):
    write_bytes(path, (json.dumps(value, indent=indent, ensure_ascii=False) + "\n").encode("utf-8"))


def b64(data):
    return base64.b64encode(data).decode("ascii")


def unb64(text):
    return base64.b64decode(text.encode("ascii"), validate=True)


def hostname():
    try:
        return socket.gethostname()
    except OSError:
        return ""


def safe_relpath(text):
    """Nur Pfade wie data/settings.json: relativ, ohne .., in einem erlaubten Ordner."""
    parts = [p for p in str(text or "").replace("\\", "/").split("/") if p not in ("", ".")]
    if not parts or any(p == ".." for p in parts) or len(parts) > MAX_DEPTH + 1:
        return None
    if len(parts) == 1:
        return parts[0] if parts[0] in ROOT_FILES else None
    return "/".join(parts) if parts[0] in SETTING_DIRS else None


# --------------------------------------------------------------------------
# Zugangsdaten erkennen und auslassen
# --------------------------------------------------------------------------

def is_secret_key(name):
    return bool(SECRET_KEY.search(str(name)))


def strip_secrets(value):
    """Kopie ohne Zugangsdaten und die Zahl der ausgelassenen Werte."""
    count = 0

    def walk(node):
        nonlocal count
        if isinstance(node, dict):
            out = {}
            for key, item in node.items():
                if is_secret_key(key) and isinstance(item, (str, int, float)) and not isinstance(item, bool) \
                        and str(item).strip() != "":
                    out[key] = OMITTED
                    count += 1
                else:
                    out[key] = walk(item)
            return out
        if isinstance(node, list):
            return [walk(item) for item in node]
        return node

    return walk(value), count


def has_secrets(value):
    return strip_secrets(value)[1] > 0


def fill_omitted(new, old):
    """Platzhalter in new durch die Werte aus old ersetzen (oder weglassen)."""
    if isinstance(new, dict):
        out = {}
        for key, item in new.items():
            if item == OMITTED:
                if isinstance(old, dict) and key in old:
                    out[key] = old[key]
                continue
            out[key] = fill_omitted(item, old.get(key) if isinstance(old, dict) else None)
        return out
    if isinstance(new, list):
        return [fill_omitted(item, old[i] if isinstance(old, list) and i < len(old) else None)
                for i, item in enumerate(new) if item != OMITTED]
    return new


# --------------------------------------------------------------------------
# Verschlüsselung (nur Standardbibliothek)
# --------------------------------------------------------------------------

def _keys(password, salt, iterations):
    material = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations, dklen=64)
    return material[:32], material[32:]


def _keystream_xor(key, nonce, data):
    if not data:
        return b""
    base = hmac.new(key, nonce, hashlib.sha256)
    blocks = []
    for block in range((len(data) + 31) // 32):
        mac = base.copy()
        mac.update(block.to_bytes(8, "big"))
        blocks.append(mac.digest())
    stream = b"".join(blocks)[:len(data)]
    # Als große Zahlen verknüpfen: auf dem Pi viel schneller als Byte für Byte.
    return (int.from_bytes(data, "big") ^ int.from_bytes(stream, "big")).to_bytes(len(data), "big")


def encrypt(payload_bytes, password):
    salt, nonce = secrets.token_bytes(16), secrets.token_bytes(16)
    enc_key, mac_key = _keys(password, salt, KDF_ITERATIONS)
    data = _keystream_xor(enc_key, nonce, payload_bytes)
    mac = hmac.new(mac_key, salt + nonce + data, hashlib.sha256).digest()
    return {"kdf": "pbkdf2-sha256", "iterations": KDF_ITERATIONS, "cipher": "hmac-sha256-ctr",
            "salt": b64(salt), "nonce": b64(nonce), "data": b64(data), "mac": b64(mac)}


def decrypt(box, password):
    try:
        salt, nonce, data, mac = (unb64(box[k]) for k in ("salt", "nonce", "data", "mac"))
        iterations = int(box.get("iterations") or KDF_ITERATIONS)
    except (KeyError, TypeError, ValueError):
        raise BackupError("bad-file")
    if not password:
        raise BackupError("need-password")
    enc_key, mac_key = _keys(password, salt, iterations)
    if not hmac.compare_digest(hmac.new(mac_key, salt + nonce + data, hashlib.sha256).digest(), mac):
        raise BackupError("wrong-password")
    return _keystream_xor(enc_key, nonce, data)


# --------------------------------------------------------------------------
# Sichern
# --------------------------------------------------------------------------

def skip_reason(rel, size):
    parts = rel.split("/")
    name = parts[-1].lower()
    if any(p.lower() in SKIP_DIRS for p in parts[:-1]):
        return "runtime"
    if name in SKIP_NAMES or name.startswith(".") and name != ".env":
        return "frame"
    if "cache" in name or "history" in name or name.endswith(".sbtmp"):
        return "runtime"
    if Path(name).suffix in SKIP_SUFFIXES:
        return "media"
    if size > MAX_FILE_BYTES:
        return "large"
    return None


def candidate_files(plugin_dir):
    """(relpath, Path) aller Dateien, die als Einstellungen in Frage kommen."""
    found = []
    for name in ROOT_FILES:
        path = plugin_dir / name
        if path.is_file():
            found.append((name, path))
    for top in SETTING_DIRS:
        base = plugin_dir / top
        if not base.is_dir() or base.is_symlink():
            continue
        for root, dirs, files in os.walk(base):
            depth = len(Path(root).relative_to(plugin_dir).parts)
            dirs[:] = sorted(d for d in dirs if depth < MAX_DEPTH and not os.path.islink(os.path.join(root, d)))
            for name in sorted(files):
                path = Path(root) / name
                if path.is_symlink() or not path.is_file():
                    continue
                found.append((path.relative_to(plugin_dir).as_posix(), path))
    return found


def store_info(plugin_dir):
    info = read_json(plugin_dir / ".dynaframe-install.json", {}) or {}
    if not isinstance(info, dict) or not info.get("storePackId"):
        return None
    return {"packId": info.get("storePackId"), "title": info.get("storeTitle") or "",
            "version": info.get("storeVersion") or "", "sourceStore": info.get("sourceStore") or ""}


def list_plugins(plugins_root, own_name):
    """Alle installierten Plugins außer diesem: [(Name, Ordner, manifest)]."""
    out = []
    try:
        entries = sorted(plugins_root.iterdir(), key=lambda p: p.name.lower())
    except OSError:
        return out
    for entry in entries:
        if entry.name == own_name or not entry.is_dir() or not NAME_OK.match(entry.name):
            continue
        manifest = read_json(entry / "manifest.json")
        if isinstance(manifest, dict):
            out.append((entry.name, entry, manifest))
    return out


def manifest_settings(manifest):
    values = {}
    for item in manifest.get("Settings") or []:
        if isinstance(item, dict) and item.get("Name"):
            values[str(item["Name"])] = item.get("Value", item.get("DefaultValue"))
    return values


def manifest_secret_names(manifest):
    names = set()
    for item in manifest.get("Settings") or []:
        if not isinstance(item, dict) or not item.get("Name"):
            continue
        kind = str(item.get("Type") or "").lower()
        if item.get("Secret") or is_secret_key(item["Name"]) or "secret" in kind or "password" in kind:
            names.add(str(item["Name"]))
    return names


def code_files(plugin_dir):
    """Die Programmdateien eines Plugins: [(relpath, Path, Größe)], ohne venv, Daten und Caches."""
    found = []
    for root, dirs, files in os.walk(plugin_dir):
        rel_root = Path(root).relative_to(plugin_dir)
        dirs[:] = sorted(d for d in dirs if not (not rel_root.parts and d in CODE_SKIP_DIRS)
                         and d not in ("__pycache__", ".git") and not os.path.islink(os.path.join(root, d)))
        for name in sorted(files):
            path = Path(root) / name
            rel = path.relative_to(plugin_dir).as_posix()
            if rel in CODE_SKIP_FILES or name.endswith((".pyc", ".log", ".sbtmp")) or path.is_symlink():
                continue
            try:
                found.append((rel, path, path.stat().st_size))
            except OSError:
                continue
    return found


def safe_code_path(text):
    parts = [p for p in str(text or "").replace("\\", "/").split("/") if p not in ("", ".")]
    if not parts or any(p == ".." for p in parts) or "/".join(parts) in CODE_SKIP_FILES:
        return None
    if len(parts) > 1 and parts[0] in CODE_SKIP_DIRS:
        return None
    return "/".join(parts)


def describe_plugin(name, plugin_dir, manifest):
    """Was von einem Plugin gesichert würde, ohne Inhalte (für die Übersicht)."""
    files, skipped, secret_count = [], [], 0
    for rel, path in candidate_files(plugin_dir):
        try:
            size = path.stat().st_size
        except OSError:
            continue
        reason = skip_reason(rel, size)
        if reason:
            skipped.append({"path": rel, "reason": reason, "size": size})
            continue
        secret = bool(SECRET_FILE.search(path.name))
        if not secret and path.suffix.lower() == ".json":
            value = read_json(path)
            secret_count += strip_secrets(value)[1] if value is not None else 0
        files.append({"path": rel, "size": size, "secret": secret})
    settings = manifest_settings(manifest)
    secret_count += sum(1 for n in manifest_secret_names(manifest) if str(settings.get(n) or "").strip())
    secret_count += sum(1 for f in files if f["secret"])
    store = store_info(plugin_dir)
    code = None
    if store is None:
        listed = code_files(plugin_dir)
        code = {"files": len(listed), "bytes": sum(size for _rel, _path, size in listed)} if listed else None
    return {
        "name": name,
        "displayName": manifest.get("DisplayName") or name,
        "version": str(manifest.get("Version") or ""),
        "enabled": bool(manifest.get("Enabled")),
        "store": store,
        "code": code,
        "settingCount": len(settings),
        "files": files,
        "skipped": skipped,
        "secretCount": secret_count,
    }


def collect_plugin(name, plugin_dir, manifest, with_secrets, budget, with_code=True):
    info = describe_plugin(name, plugin_dir, manifest)
    settings = manifest_settings(manifest)
    if not with_secrets:
        for secret_name in manifest_secret_names(manifest):
            if str(settings.get(secret_name) or "").strip():
                settings[secret_name] = OMITTED
    files = []
    for entry in info["files"]:
        path = plugin_dir / entry["path"]
        try:
            raw = path.read_bytes()
        except OSError:
            continue
        if budget["left"] - len(raw) < 0:
            info["skipped"].append({"path": entry["path"], "reason": "large", "size": len(raw)})
            continue
        item = {"path": entry["path"]}
        if entry["secret"] and not with_secrets:
            item["omitted"] = True
        elif path.suffix.lower() == ".json" and not with_secrets:
            try:
                value = json.loads(raw.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                item["data"] = b64(raw)
            else:
                stripped, count = strip_secrets(value)
                item["json"] = stripped
                if count:
                    item["omittedValues"] = count
        else:
            item["data"] = b64(raw)
        budget["left"] -= len(raw)
        files.append(item)
    item = {
        "name": name, "displayName": info["displayName"], "version": info["version"],
        "enabled": info["enabled"], "store": info["store"], "settings": settings,
        "files": files, "skipped": info["skipped"],
    }
    if with_code and info["code"] and 0 < info["code"]["bytes"] <= min(MAX_CODE_BYTES, budget["left"]):
        # Kommt aus keinem Store: der Code muss mit, sonst lässt es sich drüben nicht installieren.
        code = []
        for rel, path, _size in code_files(plugin_dir):
            try:
                code.append({"path": rel, "data": b64(path.read_bytes())})
            except OSError:
                continue
        clean = copy.deepcopy(manifest)
        for setting in clean.get("Settings") or []:
            if isinstance(setting, dict) and setting.get("Name") in settings:
                setting["Value"] = None if settings[setting["Name"]] == OMITTED else settings[setting["Name"]]
        item["code"] = code
        item["manifest"] = clean
        budget["left"] -= info["code"]["bytes"]
    return item


def scene_key(row):
    for key in ("sceneId", "slug", "key", "id"):
        value = row.get(key)
        if value not in (None, ""):
            return str(value)
    return None


def list_scenes(engine):
    """[(Schlüssel, Name, Zeile)] aller Szenen der Engine; leer, wenn sie nicht antwortet."""
    try:
        rows = engine("GET", "/dynamic-scenes")
    except Exception:
        return []
    if isinstance(rows, dict):
        rows = rows.get("items") or rows.get("scenes") or rows.get("data") or []
    out = []
    for row in rows if isinstance(rows, list) else []:
        if not isinstance(row, dict):
            continue
        key = scene_key(row)
        if key:
            name = row.get("name") or row.get("displayName") or row.get("title") or key
            out.append((key, str(name), row))
    return out


def scene_settings(engine, key):
    try:
        value = engine("GET", f"/dynamic-scenes/{key}/settings")
    except Exception:
        return None
    if value in (None, {}, []):
        return None
    if isinstance(value, dict) and isinstance(value.get("values"), dict):
        # Die Engine liefert {sceneId, schema, values, credentials}; schreiben will sie {values}.
        return {"values": value["values"]} if value["values"] else None
    if isinstance(value, dict):
        inner = value.get("settings")
        if isinstance(inner, dict) and not inner:
            return None
    return value


def create_backup(plugins_root, own_name, engine, password="", only=None, with_scenes=True, tool="",
                  with_code=True, extra=None):
    """Die Sicherungsdatei als Text und eine kurze Zusammenfassung."""
    with_secrets = bool(password)
    budget = {"left": MAX_TOTAL_BYTES}
    plugins = []
    for name, plugin_dir, manifest in list_plugins(plugins_root, own_name):
        if only is not None and name not in only:
            continue
        plugins.append(collect_plugin(name, plugin_dir, manifest, with_secrets, budget, with_code))
    scenes = []
    if with_scenes:
        for key, name, row in list_scenes(engine):
            value = scene_settings(engine, key)
            if value is None:
                continue
            if not with_secrets:
                value = strip_secrets(value)[0]
            scenes.append({"id": key, "name": name, "packageId": row.get("packageId") or "", "settings": value})
    payload = {
        "format": FORMAT, "formatVersion": FORMAT_VERSION, "createdAt": now_iso(),
        "frame": {"hostname": hostname(), "tool": tool},
        "secretsIncluded": with_secrets, "plugins": plugins, "scenes": scenes,
    }
    payload.update(extra or {})
    if with_secrets:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        wrapper = {"format": FORMAT, "formatVersion": FORMAT_VERSION, "createdAt": payload["createdAt"],
                   "frame": payload["frame"], "encrypted": encrypt(body, password)}
        text = json.dumps(wrapper, ensure_ascii=False, indent=1)
    else:
        text = json.dumps(payload, ensure_ascii=False, indent=1)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M")
    host = re.sub(r"[^A-Za-z0-9_-]+", "-", hostname() or "dynaframe").strip("-") or "dynaframe"
    return {
        "text": text, "filename": f"dynaframe-settings_{host}_{stamp}.json",
        "plugins": len(plugins), "scenes": len(scenes), "encrypted": with_secrets,
        "withCode": sum(1 for p in plugins if p.get("code")),
        "bytes": len(text.encode("utf-8")),
    }


# --------------------------------------------------------------------------
# Zurückspielen
# --------------------------------------------------------------------------

def open_backup(text, password=""):
    """Die Datei lesen (und entschlüsseln). Gibt den Inhalt als dict zurück."""
    try:
        outer = json.loads(text)
    except (TypeError, ValueError):
        raise BackupError("bad-file")
    if not isinstance(outer, dict) or outer.get("format") != FORMAT:
        raise BackupError("bad-file")
    if int(outer.get("formatVersion") or 0) > FORMAT_VERSION:
        raise BackupError("too-new")
    if "encrypted" in outer:
        try:
            payload = json.loads(decrypt(outer["encrypted"], password).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise BackupError("bad-file")
    else:
        payload = outer
    if not isinstance(payload, dict) or not isinstance(payload.get("plugins"), list):
        raise BackupError("bad-file")
    return payload


def summarize(payload, plugins_root, own_name, engine):
    """Was die Datei enthält und was davon auf diesem Rahmen passt."""
    installed = {name: (plugin_dir, manifest) for name, plugin_dir, manifest in list_plugins(plugins_root, own_name)}
    plugins = []
    for item in payload.get("plugins") or []:
        if not isinstance(item, dict) or not NAME_OK.match(str(item.get("name") or "")):
            continue
        name = item["name"]
        here = installed.get(name)
        files = [f for f in item.get("files") or [] if isinstance(f, dict)]
        plugins.append({
            "name": name,
            "displayName": item.get("displayName") or name,
            "version": item.get("version") or "",
            "enabled": bool(item.get("enabled")),
            "store": item.get("store"),
            "installed": here is not None,
            "versionHere": str(here[1].get("Version") or "") if here else "",
            "enabledHere": bool(here[1].get("Enabled")) if here else False,
            "settingCount": len(item.get("settings") or {}),
            "fileCount": len(files),
            "hasCode": bool(item.get("code")) and isinstance(item.get("manifest"), dict),
            "omitted": sum(1 for f in files if f.get("omitted")) + sum(int(f.get("omittedValues") or 0) for f in files)
            + sum(1 for v in (item.get("settings") or {}).values() if v == OMITTED),
        })
    here_scenes = {key for key, _name, _row in list_scenes(engine)}
    scenes = [{"id": s.get("id"), "name": s.get("name") or s.get("id"), "installed": s.get("id") in here_scenes,
               "packageId": s.get("packageId") or ""}
              for s in payload.get("scenes") or [] if isinstance(s, dict) and s.get("id")]
    return {
        "createdAt": payload.get("createdAt") or "",
        "frame": (payload.get("frame") or {}).get("hostname") or "",
        "sameFrame": ((payload.get("frame") or {}).get("hostname") or "") == hostname(),
        "secretsIncluded": bool(payload.get("secretsIncluded")),
        "plugins": plugins,
        "scenes": scenes,
    }


class Undo:
    """Merkt sich, was vor dem Zurückspielen auf dem Rahmen stand."""

    def __init__(self, folder):
        self.folder = folder
        self.index = {"createdAt": now_iso(), "files": [], "scenes": [], "settings": [], "enabled": [],
                      "installed": [], "restart": []}
        self.seen = set()

    def start(self):
        if self.folder.exists():
            shutil.rmtree(self.folder, ignore_errors=True)
        (self.folder / "files").mkdir(parents=True, exist_ok=True)

    def remember_file(self, plugin, rel, path):
        key = (plugin, rel)
        if key in self.seen:
            return
        self.seen.add(key)
        existed = path.is_file()
        if existed:
            copy_to = self.folder / "files" / plugin / rel
            copy_to.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, copy_to)
        self.index["files"].append({"plugin": plugin, "path": rel, "existed": existed})

    def remember_scene(self, key, value):
        self.index["scenes"].append({"id": key, "settings": value})

    def remember(self, kind, value):
        self.index[kind].append(value)

    def save(self):
        write_json(self.folder / "undo.json", self.index)


def _try(engine, method, path, payload=None):
    try:
        engine(method, path, payload)
        return True
    except Exception:
        return False


def engine_plugins(engine):
    """{Name: Zeile} aus GET /plugins (running, enabled, ...); leer, wenn die Engine nicht antwortet."""
    try:
        rows = engine("GET", "/plugins")
    except Exception:
        return {}
    return {str(r.get("name")): r for r in rows if isinstance(r, dict) and r.get("name")} \
        if isinstance(rows, list) else {}


def _apply_file(plugin_dir, name, item, undo):
    rel = safe_relpath(item.get("path"))
    if rel is None:
        return "skip"
    if item.get("omitted"):
        return "kept"
    target = plugin_dir / rel
    if target.is_symlink():
        return "skip"
    if "json" in item:
        value = item["json"]
        if item.get("omittedValues"):
            value = fill_omitted(value, read_json(target, {}) if target.is_file() else {})
        data = (json.dumps(value, indent=1, ensure_ascii=False) + "\n").encode("utf-8")
    else:
        try:
            data = unb64(item.get("data") or "")
        except ValueError:
            return "skip"
    undo.remember_file(name, rel, target)
    write_bytes(target, data)
    return "written"


def _apply_settings(engine, plugin_dir, name, item, undo):
    """Werte der Plugins-Seite setzen: über die Engine (wirkt sofort), sonst in manifest.json.
    Gibt (Zahl geänderter Werte, live) zurück."""
    path = plugin_dir / "manifest.json"
    manifest = read_json(path)
    if not isinstance(manifest, dict):
        return 0, True
    wanted = item.get("settings") or {}
    before = copy.deepcopy(manifest.get("Settings") or [])
    after = copy.deepcopy(before)
    changed = 0
    for setting in after:
        if not isinstance(setting, dict):
            continue
        key = str(setting.get("Name") or "")
        if key in wanted and wanted[key] != OMITTED and setting.get("Value") != wanted[key]:
            setting["Value"] = wanted[key]
            changed += 1
    if not changed:
        return 0, True
    undo.remember_file(name, "manifest.json", path)
    undo.remember("settings", {"plugin": name, "settings": before})
    if _try(engine, "POST", f"/plugins/{name}/settings", after):
        return changed, True
    manifest["Settings"] = after
    write_json(path, manifest)
    return changed, False


def _apply_enabled(engine, plugin_dir, name, wanted, undo):
    path = plugin_dir / "manifest.json"
    manifest = read_json(path)
    if not isinstance(manifest, dict) or bool(manifest.get("Enabled")) == bool(wanted):
        return False, True
    undo.remember("enabled", {"plugin": name, "enabled": bool(manifest.get("Enabled"))})
    if _try(engine, "POST", f"/plugins/{name}/{'enable' if wanted else 'disable'}"):
        return True, True
    undo.remember_file(name, "manifest.json", path)
    manifest["Enabled"] = bool(wanted)
    write_json(path, manifest)
    return True, False


def _install_plugin(engine, plugins_root, name, item, undo):
    """Ein Plugin ohne Store aus dem mitgesicherten Code anlegen und von der Engine einrichten lassen."""
    plugin_dir = plugins_root / name
    if plugin_dir.exists():
        raise OSError(f"{plugin_dir} already exists")
    undo.remember("installed", name)
    undo.save()
    for entry in item.get("code") or []:
        rel = safe_code_path(entry.get("path")) if isinstance(entry, dict) else None
        if rel is None:
            continue
        try:
            write_bytes(plugin_dir / rel, unb64(entry.get("data") or ""))
        except ValueError:
            continue
    manifest = copy.deepcopy(item["manifest"])
    manifest["Name"] = name
    manifest["Enabled"] = bool(item.get("enabled"))
    write_json(plugin_dir / "manifest.json", manifest)
    engine_plugins(engine)  # die Engine den neuen Ordner finden lassen
    # repair legt venv und Pakete im Hintergrund an und startet das Plugin danach selbst.
    if _try(engine, "POST", f"/plugins/{name}/repair"):
        return True
    return _try(engine, "POST", f"/plugins/{name}/install")


def apply_backup(payload, plugins_root, own_name, engine, undo_dir, names=None, scene_ids=None,
                 set_enabled=False):
    """Gewählte Plugins und Szenen zurückspielen. Vorher Gesichertes kommt nach undo_dir."""
    installed = {name: plugin_dir for name, plugin_dir, _m in list_plugins(plugins_root, own_name)}
    running = engine_plugins(engine)
    undo = Undo(undo_dir)
    undo.start()
    results = []
    for item in payload.get("plugins") or []:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "")
        if not NAME_OK.match(name) or name == own_name or (names is not None and name not in names):
            continue
        plugin_dir = installed.get(name)
        fresh = False
        if plugin_dir is None:
            if not (item.get("code") and isinstance(item.get("manifest"), dict)):
                results.append({"name": name, "status": "missing"})
                continue
            try:
                live = _install_plugin(engine, plugins_root, name, item, undo)
            except OSError as exc:
                results.append({"name": name, "status": "error", "error": str(exc)})
                continue
            plugin_dir, fresh = plugins_root / name, True
        written = kept = settings_changed = 0
        live = live if fresh else True
        error = ""
        try:
            for file_item in item.get("files") or []:
                if not isinstance(file_item, dict):
                    continue
                outcome = _apply_file(plugin_dir, name, file_item, undo)
                written += outcome == "written"
                kept += outcome == "kept"
            if not fresh:
                settings_changed, settings_live = _apply_settings(engine, plugin_dir, name, item, undo)
                live = live and settings_live
                toggled = False
                if set_enabled:
                    toggled, enabled_live = _apply_enabled(engine, plugin_dir, name, item.get("enabled"), undo)
                    live = live and enabled_live
                row = running.get(name) or {}
                if (written or settings_changed) and row.get("running") and not (toggled and not item.get("enabled")):
                    # Neu starten, damit das Plugin die neuen Dateien liest; ohne Engine bleibt nur der Neustart von DynaFrame.
                    if _try(engine, "POST", f"/plugins/{name}/restart"):
                        undo.remember("restart", name)
                    else:
                        live = False
                elif written and not row:
                    live = False
        except OSError as exc:
            error = str(exc)
        status = "error" if error else "installed" if fresh else "done"
        results.append({"name": name, "status": status, "files": written, "kept": kept,
                        "settings": settings_changed, "live": live, "error": error})
    scene_results = []
    if scene_ids is None or scene_ids:
        here = {key for key, _n, _r in list_scenes(engine)}
        for scene in payload.get("scenes") or []:
            if not isinstance(scene, dict) or not scene.get("id"):
                continue
            key = str(scene["id"])
            if scene_ids is not None and key not in scene_ids:
                continue
            if key not in here:
                scene_results.append({"id": key, "status": "missing"})
                continue
            before = scene_settings(engine, key)
            value = scene.get("settings")
            if before is not None:
                value = fill_omitted(copy.deepcopy(value), before)
            undo.remember_scene(key, before)
            ok = _put_scene(engine, key, value)
            scene_results.append({"id": key, "status": "done" if ok else "error"})
    undo.save()
    return {"plugins": results, "scenes": scene_results, "at": time.time(),
            "restartNeeded": any(r.get("live") is False for r in results)}


def _put_scene(engine, key, value):
    if _try(engine, "PUT", f"/dynamic-scenes/{key}/settings", value):
        return True
    # Ältere Sicherungen hielten die Werte ohne Hülle; die Engine will {values}.
    if isinstance(value, dict) and "values" not in value:
        return _try(engine, "PUT", f"/dynamic-scenes/{key}/settings", {"values": value})
    return False


def undo_last(plugins_root, own_name, engine, undo_dir):
    index = read_json(undo_dir / "undo.json")
    if not isinstance(index, dict):
        raise BackupError("no-undo")
    restored = 0
    for name in index.get("installed") or []:
        if NAME_OK.match(str(name)) and name != own_name:
            if not _try(engine, "DELETE", f"/plugins/{name}"):
                shutil.rmtree(plugins_root / name, ignore_errors=True)
            restored += 1
    gone = set(index.get("installed") or [])
    installed = {name: plugin_dir for name, plugin_dir, _m in list_plugins(plugins_root, own_name)}
    for entry in index.get("files") or []:
        plugin_dir = installed.get(entry.get("plugin"))
        rel = entry.get("path")
        if plugin_dir is None or entry.get("plugin") in gone or (rel != "manifest.json" and safe_relpath(rel) is None):
            continue
        target = plugin_dir / rel
        if entry.get("existed"):
            saved = undo_dir / "files" / entry["plugin"] / rel
            if saved.is_file():
                write_bytes(target, saved.read_bytes())
                restored += 1
        elif target.is_file():
            target.unlink()
            restored += 1
    for entry in index.get("settings") or []:
        if entry.get("plugin") in installed:
            _try(engine, "POST", f"/plugins/{entry['plugin']}/settings", entry.get("settings") or [])
    for entry in index.get("enabled") or []:
        if entry.get("plugin") in installed:
            _try(engine, "POST", f"/plugins/{entry['plugin']}/{'enable' if entry.get('enabled') else 'disable'}")
    for name in index.get("restart") or []:
        if name in installed:
            _try(engine, "POST", f"/plugins/{name}/restart")
    for scene in index.get("scenes") or []:
        if scene.get("settings") is not None and _put_scene(engine, scene["id"], scene["settings"]):
            restored += 1
    shutil.rmtree(undo_dir, ignore_errors=True)
    return {"restored": restored}


def undo_available(undo_dir):
    index = read_json(undo_dir / "undo.json")
    return index.get("createdAt") if isinstance(index, dict) else None
