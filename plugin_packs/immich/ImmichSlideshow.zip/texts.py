"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

import re

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Angelegt: die Playlist Immich Slideshow steht unter Playlists.": (
        "Created: the Immich Slideshow playlist is listed under Playlists.",
        "Creada: la lista Immich Slideshow aparece en Playlists."),
    "Dem API-Schlüssel fehlt eine Berechtigung ({path}).": (
        "The API key lacks a permission ({path}).",
        "A la clave API le falta un permiso ({path})."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.",
        "El marco no ha creado la lista {name}."),
    "Immich ist nicht erreichbar: {exc}": (
        "Immich is not reachable: {exc}",
        "Immich no está disponible: {exc}"),
    "Immich lehnt den API-Schlüssel ab.": (
        "Immich rejects the API key.",
        "Immich rechaza la clave API."),
    "Keine Fotos passen zu deiner Auswahl.": (
        "No photos match your selection.",
        "Ninguna foto coincide con tu selección."),
    "Konnte die Playlist Immich Slideshow nicht pflegen: {exc}": (
        "Could not maintain the Immich Slideshow playlist: {exc}",
        "No se pudo mantener la lista Immich Slideshow: {exc}"),
    "Liest die Fotos aus Immich …": (
        "Reading the photos from Immich …",
        "Leyendo las fotos de Immich …"),
    "Noch nicht gelesen.": (
        "Not read yet.",
        "Aún sin leer."),
    "Trag Adresse und API-Schlüssel deines Immich-Servers ein.": (
        "Enter the address and API key of your Immich server.",
        "Introduce la dirección y la clave API de tu servidor Immich."),
    "Trag die Adresse deines Immich-Servers ein.": (
        "Enter the address of your Immich server.",
        "Introduce la dirección de tu servidor Immich."),
    "Trag einen API-Schlüssel von Immich ein.": (
        "Enter an Immich API key.",
        "Introduce una clave API de Immich."),
    "Unter dieser Adresse antwortet kein Immich-Server.": (
        "No Immich server answers at this address.",
        "En esta dirección no responde ningún servidor Immich."),
    "Verbunden mit Immich {version} als {user}.": (
        "Connected to Immich {version} as {user}.",
        "Conectado a Immich {version} como {user}."),
    "Wähle mindestens ein Album.": (
        "Pick at least one album.",
        "Elige al menos un álbum."),
    "Die Engine hat die Fotos noch nicht übernommen; gleich noch einmal.": (
        "The engine has not taken the photos in yet; trying again shortly.",
        "El motor aún no ha registrado las fotos; se reintentará en breve."),
    "Wird mit den nächsten Fotos angelegt.": (
        "Will be created with the next photos.",
        "Se creará con las próximas fotos."),
    "{n} Fotos ausgewählt.": (
        "{n} photos selected.",
        "{n} fotos seleccionadas."),
}

MONTHS = {
    "de": ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober",
           "November", "Dezember"],
    "en": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
           "November", "December"],
    "es": ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre",
           "noviembre", "diciembre"],
}

_PLACEHOLDER = re.compile(r"\{(\w+)\}")


def t(language, template, **values):
    row = _TEXTS.get(template)
    text = template
    if row and language in LANGUAGES[1:]:
        text = row[LANGUAGES.index(language) - 1] or template
    return _PLACEHOLDER.sub(lambda m: str(values.get(m.group(1), m.group(0))), text)
