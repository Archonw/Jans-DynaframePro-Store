"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/PartyWall/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["SlideSeconds", "TopEvery", "RecapCount", "PartyHours", "PlaylistSeconds"];
const CHECK_FIELDS = ["Uploads", "Gallery", "Approve", "ShowNames", "ShowCaptions", "FlyNames", "WakeScreen"];
const SELECT_FIELDS = ["Theme", "Style"];
const TEXT_FIELDS = ["RecapAt"];
let current = null;
let editing = false;
let langChangedAt = 0;

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["Party Wall", "Party Wall", "Party Wall"],
  lede: ["Die Fotowand für deine Party: Gäste scannen den QR-Code auf dem Fernseher, laden ihre Fotos vom Abend hoch und reagieren mit Emojis, die über den Bildschirm fliegen. Am Ende zeigt eine Rückschau die beliebtesten Fotos. Jede Änderung hier wird sofort gespeichert.",
    "The photo wall for your party: guests scan the QR code on the TV, upload their photos of the evening and react with emojis that fly across the screen. At the end, a recap shows the most popular photos. Every change here is saved immediately.",
    "El muro de fotos para tu fiesta: los invitados escanean el código QR de la tele, suben sus fotos de la noche y reaccionan con emojis que vuelan por la pantalla. Al final, un resumen muestra las fotos más populares. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  statusTitle: ["Die Party", "The party", "La fiesta"],
  startNow: ["Wand auf den Fernseher holen", "Show the wall on the TV", "Mostrar el muro en la tele"],
  endNow: ["Wand auf dem Fernseher beenden", "End the wall on the TV", "Terminar el muro en la tele"],
  recapStart: ["Rückschau starten", "Start the recap", "Iniciar el resumen"],
  recapStop: ["Zurück zur Fotowand", "Back to the photo wall", "Volver al muro"],
  factNow: ["Gerade", "Now", "Ahora"],
  factPhotos: ["Fotos", "Photos", "Fotos"],
  factGuests: ["Gäste", "Guests", "Invitados"],
  factReactions: ["Reaktionen", "Reactions", "Reacciones"],
  factVersion: ["Version", "Version", "Versión"],
  nowOff: ["nicht auf dem Fernseher", "not on the TV", "no está en la tele"],
  nowWelcome: ["wartet auf das erste Foto", "waiting for the first photo", "esperando la primera foto"],
  nowWall: ["Fotowand läuft", "photo wall running", "muro en marcha"],
  nowTop: ["zeigt die Hitliste", "showing the top photos", "mostrando las más populares"],
  nowRecap: ["Rückschau läuft", "recap running", "resumen en marcha"],
  takeoverOn: [" · auf den Fernseher geholt bis {time}", " · sent to the TV until {time}", " · en la tele hasta las {time}"],
  takeoverWait: [" · kommt gleich auf den Fernseher …", " · coming to the TV …", " · llega enseguida a la tele …"],
  partyLine: ["„{title}“ seit {time} · Code {code}", "“{title}” since {time} · code {code}", "«{title}» desde las {time} · código {code}"],
  untitled: ["Party ohne Namen", "Untitled party", "Fiesta sin nombre"],
  photosLine: ["{n} ({w} warten auf Freigabe)", "{n} ({w} waiting for approval)", "{n} ({w} pendientes)"],
  guestsLine: ["{n} ({a} gerade dabei)", "{n} ({a} here now)", "{n} ({a} ahora)"],
  guestsTitle: ["Gäste und Handys", "Guests and phones", "Invitados y móviles"],
  newCode: ["Neuer Code", "New code", "Nuevo código"],
  phoneCode: ["Code für die Gäste: {code}", "Code for the guests: {code}", "Código para los invitados: {code}"],
  phoneNoPort: ["Die Gäste-Seite hat keinen freien Port gefunden (8110 bis 8113). Starte das Plugin neu.", "The guest page found no free port (8110 to 8113). Restart the plugin.", "La página de invitados no ha encontrado un puerto libre (8110 a 8113). Reinicia el plugin."],
  noPillow: ["Auf dem Rahmen fehlt Pillow, Fotos können nicht angenommen werden. Installiere das Paket noch einmal.", "Pillow is missing on the frame, so photos cannot be accepted. Install the pack again.", "Falta Pillow en el marco; no se pueden recibir fotos. Vuelve a instalar el paquete."],
  noHeif: ["HEIC-Fotos (iPhone) kann der Rahmen gerade nicht lesen; die Gäste-Seite wandelt sie meist vorher um.", "The frame cannot read HEIC photos (iPhone) right now; the guest page usually converts them first.", "El marco no puede leer fotos HEIC (iPhone); la página de invitados suele convertirlas antes."],
  uploads: ["Gäste können Fotos hochladen", "Guests can upload photos", "Los invitados pueden subir fotos"],
  gallery: ["Gäste sehen alle Fotos auf dem Handy (und können sie speichern)", "Guests see all photos on their phone (and can save them)", "Los invitados ven todas las fotos en el móvil (y pueden guardarlas)"],
  approve: ["Ich gebe jedes Foto frei, bevor es erscheint", "I approve every photo before it appears", "Apruebo cada foto antes de que aparezca"],
  guestsHint: ["Der QR-Code auf dem Fernseher öffnet eine Seite dieses Plugins auf Port <b>8110</b> in deinem WLAN, der Code steht schon drin; Gäste geben nur ihren Namen ein. Der Code oben steht auch auf dem Fernseher. Mit „Neuer Code“ brauchen Handys, die noch nicht dabei sind, den neuen Code. Wenn du <b>Web Login</b> nutzt, hake dort Port 8110 als offen an. Fotos werden auf 1920 Pixel verkleinert und ohne Ort und Kameradaten auf dem Rahmen gespeichert.",
    "The QR code on the TV opens a page of this plugin on port <b>8110</b> in your Wi-Fi, with the code already filled in; guests only enter their name. The code above is also on the TV. With “New code”, phones that have not joined yet need the new code. If you use <b>Web Login</b>, tick port 8110 there as open. Photos are shrunk to 1920 pixels and stored on the frame without location or camera data.",
    "El código QR de la tele abre una página de este plugin en el puerto <b>8110</b> de tu wifi, con el código ya puesto; los invitados solo escriben su nombre. El código de arriba también está en la tele. Con «Nuevo código», los móviles que aún no se han unido necesitan el código nuevo. Si usas <b>Web Login</b>, marca allí el puerto 8110 como abierto. Las fotos se reducen a 1920 píxeles y se guardan en el marco sin ubicación ni datos de cámara."],
  photosTitle: ["Fotos", "Photos", "Fotos"],
  approveAll: ["Alle wartenden freigeben", "Approve all waiting", "Aprobar todas las pendientes"],
  zip: ["Alle als ZIP laden", "Download all as ZIP", "Descargar todas en ZIP"],
  photosHint: ["Die neuesten zuerst. Ausgeblendete Fotos bleiben auf dem Rahmen, erscheinen aber nicht mehr auf dem Fernseher und den Handys; Löschen entfernt sie endgültig.",
    "Newest first. Hidden photos stay on the frame but no longer appear on the TV or on the phones; deleting removes them for good.",
    "Las más nuevas primero. Las fotos ocultas siguen en el marco, pero ya no aparecen en la tele ni en los móviles; borrar las elimina para siempre."],
  noPhotos: ["Noch keine Fotos auf dieser Party.", "No photos at this party yet.", "Aún no hay fotos en esta fiesta."],
  waiting: ["wartet auf Freigabe", "waiting for approval", "pendiente de aprobación"],
  hiddenFlag: ["ausgeblendet", "hidden", "oculta"],
  approveOne: ["Freigeben", "Approve", "Aprobar"],
  hide: ["Ausblenden", "Hide", "Ocultar"],
  unhide: ["Zeigen", "Show", "Mostrar"],
  del: ["Löschen", "Delete", "Borrar"],
  sure: ["Wirklich?", "Sure?", "¿Seguro?"],
  photoMeta: ["{time} · {r} Reaktionen · {s}× gezeigt", "{time} · {r} reactions · shown {s}×", "{time} · {r} reacciones · {s}× mostrada"],
  recapTitle: ["Hitliste und Rückschau", "Top photos and recap", "Las más populares y resumen"],
  topEvery: ["Hitliste zwischendurch alle … Minuten (0 = nie)", "Show the top photos every … minutes (0 = never)", "Mostrar las más populares cada … minutos (0 = nunca)"],
  recapCount: ["Fotos in der Rückschau", "Photos in the recap", "Fotos en el resumen"],
  recapAt: ["Rückschau von selbst um (Uhrzeit, leer = nie)", "Start the recap by itself at (time, empty = never)", "Iniciar el resumen solo a las (hora, vacío = nunca)"],
  recapHint: ["Die Rückschau zeigt die Zahlen des Abends, zählt dann die beliebtesten Fotos herunter und endet mit einer Collage der Nacht. Sie läuft im Kreis, bis du zur Fotowand zurückgehst. Jeder Gast zählt höchstens drei Reaktionen je Foto, so kann niemand ein Foto allein nach oben tippen. Hochladen geht während der Rückschau weiter.",
    "The recap shows the numbers of the evening, then counts down the most popular photos and ends with a collage of the night. It runs in a loop until you go back to the wall. Each guest counts at most three reactions per photo, so nobody can tap a photo to the top alone. Guests can keep uploading during the recap.",
    "El resumen muestra las cifras de la noche, cuenta hacia atrás las fotos más populares y termina con un collage de la noche. Se repite hasta que vuelvas al muro. Cada invitado cuenta como máximo tres reacciones por foto, así nadie puede subir una foto solo. Durante el resumen se pueden seguir subiendo fotos."],
  lookTitle: ["Aussehen", "Look", "Aspecto"],
  theme: ["Farben", "Colours", "Colores"],
  themeParty: ["Party (lila und pink)", "Party (purple and pink)", "Fiesta (lila y rosa)"],
  themeElegant: ["Elegant (schwarz und gold, z. B. Hochzeit)", "Elegant (black and gold, e.g. a wedding)", "Elegante (negro y oro, p. ej. una boda)"],
  themeBright: ["Hell (bunt auf creme, z. B. Kindergeburtstag)", "Bright (colourful on cream, e.g. a children's party)", "Claro (colores sobre crema, p. ej. una fiesta infantil)"],
  style: ["Fotos als", "Photos as", "Fotos como"],
  stylePolaroid: ["Sofortbild mit Namen darunter", "Instant photo with the name below", "Foto instantánea con el nombre debajo"],
  styleFull: ["Großes Foto mit Namen darauf", "Large photo with the name on it", "Foto grande con el nombre encima"],
  slideSeconds: ["Sekunden je Foto", "Seconds per photo", "Segundos por foto"],
  showNames: ["Zeigen, wer das Foto gemacht hat", "Show who took the photo", "Mostrar quién hizo la foto"],
  showCaptions: ["Den Satz der Gäste zum Foto zeigen", "Show the guests' line for the photo", "Mostrar la frase de los invitados"],
  flyNames: ["Namen an den fliegenden Emojis zeigen", "Show names with the flying emojis", "Mostrar nombres con los emojis que vuelan"],
  lookHint: ["Neue Fotos kommen nach wenigen Sekunden dran und bekommen ein „NEU“. Danach kommen beliebte Fotos öfter wieder als andere.",
    "New photos come up within a few seconds and get a “NEW” badge. After that, popular photos come back more often than others.",
    "Las fotos nuevas salen en pocos segundos con la etiqueta «NUEVA». Después, las populares vuelven más a menudo que otras."],
  tvTitle: ["Auf den Fernseher holen", "Send to the TV", "Llevar a la tele"],
  partyHours: ["„Wand auf den Fernseher holen“ dauert … Stunden", "“Show the wall on the TV” lasts … hours", "«Mostrar el muro en la tele» dura … horas"],
  wakeScreen: ["Bildschirm dafür einschalten", "Switch the screen on for it", "Encender la pantalla para ello"],
  tvHint: ["„Wand auf den Fernseher holen“ oben legt die Wand über das, was gerade läuft, und gibt den Bildschirm nach der eingestellten Zeit oder beim Beenden zurück. Dafür muss auf der Plugins-Seite „Allow takeover“ für Party Wall an sein. Alternativ startest du selbst die Playlist „Party Wall“ (letzte Karte).",
    "“Show the wall on the TV” at the top puts the wall over whatever is playing and hands the screen back after the set hours or when you end it. For this, “Allow takeover” must be on for Party Wall on the Plugins page. Alternatively, start the playlist “Party Wall” (last card) yourself.",
    "«Mostrar el muro en la tele» pone el muro sobre lo que se esté reproduciendo y devuelve la pantalla tras las horas fijadas o al terminarlo. Para ello, «Allow takeover» debe estar activado para Party Wall en la página de plugins. También puedes iniciar tú la lista «Party Wall» (última tarjeta)."],
  partiesTitle: ["Partys", "Parties", "Fiestas"],
  partyName: ["Name dieser Party (steht auf dem Fernseher)", "Name of this party (shown on the TV)", "Nombre de esta fiesta (sale en la tele)"],
  partyNamePh: ["z. B. Annas 40. Geburtstag", "e.g. Anna's 40th birthday", "p. ej. 40 cumpleaños de Ana"],
  newPartyLabel: ["Fertig? Die nächste Party beginnt leer", "Finished? The next party starts empty", "¿Terminado? La próxima fiesta empieza vacía"],
  newParty: ["Neue Party beginnen", "Start a new party", "Empezar una fiesta nueva"],
  newPartySure: ["Wirklich neue Party beginnen?", "Really start a new party?", "¿Seguro que empiezas una fiesta nueva?"],
  newPartyDone: ["Neue Party begonnen. Die Fotos der letzten Party stehen unten.", "New party started. The photos of the last party are listed below.", "Fiesta nueva iniciada. Las fotos de la anterior están abajo."],
  earlierTitle: ["Alle Partys auf diesem Rahmen", "All parties on this frame", "Todas las fiestas en este marco"],
  partyRow: ["{date} · {n} Fotos · {mb} MB", "{date} · {n} photos · {mb} MB", "{date} · {n} fotos · {mb} MB"],
  currentParty: ["läuft gerade", "current", "actual"],
  partiesHint: ["Jede Party behält ihre Fotos, bis du sie hier löschst. Eine neue Party bekommt einen neuen Code, Handys von der letzten Party scannen den QR-Code also neu.",
    "Each party keeps its photos until you delete it here. A new party gets a new code, so phones from the last party have to scan the QR code again.",
    "Cada fiesta conserva sus fotos hasta que la borres aquí. Una fiesta nueva tiene un código nuevo, así que los móviles de la anterior deben escanear el QR de nuevo."],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „Party Wall“ anlegen", "Create the playlist “Party Wall”", "Crear la lista «Party Wall»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la lista (segundos)"],
  playlistHint: ["Die Playlist enthält nur die Szene und ist eingeschaltet. Die Dauer gilt beim Anlegen; danach änderst du sie in der Playlist selbst. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist holds only the scene and is switched on. The duration applies when it is created; after that you change it in the playlist itself. You can also add the scene to any playlist yourself.",
    "La lista contiene solo la escena y está activada. La duración se aplica al crearla; después la cambias en la propia lista. También puedes añadir la escena a cualquier lista."],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status}).", "Error (HTTP {status}).", "Error (HTTP {status})."],
  oclock: ["{time} Uhr", "{time}", "{time}"],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."]
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "";

const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[1]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "en";
  if (chosen === lang && document.documentElement.dataset.applied === chosen) return;
  lang = chosen;
  document.documentElement.dataset.applied = lang;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  photosKey = "";
  partiesKey = "";
  if (current) render(current);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}
const post = (path, body = {}) => api(path, { method: "POST", body: JSON.stringify(body) });

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(epoch) {
  if (!epoch) return "—";
  const date = new Date(epoch * 1000);
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}
const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang]);

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await post("./api/settings", changes);
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

// Knöpfe, die etwas Endgültiges tun: erst „Wirklich?“, dann noch einmal tippen.
function confirmClick(button, action) {
  if (button.classList.contains("confirm")) {
    button.classList.remove("confirm");
    action();
    return;
  }
  const label = button.textContent;
  button.classList.add("confirm");
  button.textContent = button.dataset.sure ? t(button.dataset.sure) : t("sure");
  setTimeout(() => {
    if (!button.isConnected || !button.classList.contains("confirm")) return;
    button.classList.remove("confirm");
    button.textContent = label;
  }, 4000);
}

// ------------------------------------------------------------ Gäste

let qrFor = "";
function renderPhone(state) {
  const url = state.phoneUrl;
  el("phoneBox").hidden = !url;
  const code = state.party.code;
  if (url) {
    const link = `${url}?c=${code}`;
    el("phoneUrl").href = link;
    el("phoneUrl").textContent = url.replace(/^https?:\/\//, "").replace(/\/$/, "");
    el("phoneCode").textContent = t("phoneCode", { code });
    if (link !== qrFor && typeof qrcode === "function") {
      qrFor = link;
      const qr = qrcode(0, "M");
      qr.addData(link);
      qr.make();
      el("phoneQr").innerHTML = qr.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
    }
  }
  const note = !url ? t("phoneNoPort") : !state.pillow ? t("noPillow") : !state.heif ? t("noHeif") : "";
  setStatus(note, note && (!url || !state.pillow) ? "bad" : "", "phoneNote");
}

// ------------------------------------------------------------ Fotos

let photosKey = "";
let photosAt = 0;
async function loadPhotos(force = false) {
  if (!force && Date.now() - photosAt < 8000) return;
  photosAt = Date.now();
  try {
    const result = await api("./api/photos");
    renderPhotos(result.photos || []);
  } catch (error) {
    setStatus(error.message, "bad", "photosNote");
  }
}

function renderPhotos(photos) {
  const key = lang + JSON.stringify(photos.map((p) => [p.id, p.st, p.score, p.shown]));
  el("approveAll").hidden = !photos.some((p) => p.st === "wait");
  if (key === photosKey) return;
  photosKey = key;
  if (!photos.length) {
    el("tiles").innerHTML = "";
    setStatus(t("noPhotos"), "", "photosNote");
    return;
  }
  setStatus("", "", "photosNote");
  el("tiles").innerHTML = photos.map((p) => {
    const reactions = Object.values(p.r || {}).reduce((a, b) => a + b, 0);
    const time = new Date(p.at * 1000).toLocaleTimeString(LOCALES[lang], { hour: "2-digit", minute: "2-digit" });
    const flag = p.st === "wait" ? `<span class="flag">${esc(t("waiting"))}</span>` : p.st === "hidden" ? `<span class="flag">${esc(t("hiddenFlag"))}</span>` : "";
    const first = p.st === "wait" ? ["ok", "approveOne"] : p.st === "hidden" ? ["ok", "unhide"] : ["hidden", "hide"];
    return `<div class="tile ${p.st === "wait" ? "wait" : p.st === "hidden" ? "hidden" : ""}">
      <img loading="lazy" src="./api/photo?id=${encodeURIComponent(p.id)}&s=t&admin=1" alt="">
      <div class="meta"><b>${esc(p.name)}</b>${p.cap ? `<span>${esc(p.cap)}</span>` : ""}
        <span>${esc(t("photoMeta", { time, r: fmt(reactions), s: fmt(p.shown) }))}</span>${flag}</div>
      <div class="acts"><button type="button" class="secondary" data-st="${first[0]}" data-id="${esc(p.id)}">${esc(t(first[1]))}</button>
        <button type="button" class="secondary danger" data-del="${esc(p.id)}">${esc(t("del"))}</button></div></div>`;
  }).join("");
}

el("tiles").addEventListener("click", async (event) => {
  const button = event.target.closest("button");
  if (!button) return;
  try {
    if (button.dataset.st) {
      await post("./api/photo/state", { id: button.dataset.id, st: button.dataset.st });
      loadPhotos(true);
    } else if (button.dataset.del) {
      confirmClick(button, async () => {
        await post("./api/photo/delete", { id: button.dataset.del }).catch((e) => setStatus(e.message, "bad", "photosNote"));
        loadPhotos(true);
      });
    }
  } catch (error) {
    setStatus(error.message, "bad", "photosNote");
  }
});
el("approveAll").addEventListener("click", async () => {
  await post("./api/photo/approve-all").catch((e) => setStatus(e.message, "bad", "photosNote"));
  loadPhotos(true);
});

// ------------------------------------------------------------ Partys

let partiesKey = "";
let partiesAt = 0;
async function loadParties(force = false) {
  if (!force && Date.now() - partiesAt < 15000) return;
  partiesAt = Date.now();
  try {
    const result = await api("./api/parties");
    const rows = result.parties || [];
    const key = lang + JSON.stringify(rows);
    if (key === partiesKey) return;
    partiesKey = key;
    el("parties").innerHTML = rows.map((p) => {
      const date = new Date(p.started * 1000).toLocaleDateString(LOCALES[lang], { day: "numeric", month: "short", year: "numeric" });
      return `<div class="player party-row"><span><b>${esc(p.title || t("untitled"))}</b>
        <small>${esc(t("partyRow", { date, n: fmt(p.photos), mb: (p.bytes / 1048576).toFixed(1) }))}${p.current ? " · " + esc(t("currentParty")) : ""}</small></span>
        <span class="acts"><a class="button" href="./api/zip?party=${encodeURIComponent(p.id)}" download>ZIP</a>
        ${p.current ? "" : `<button type="button" class="secondary danger" data-party="${esc(p.id)}">${esc(t("del"))}</button>`}</span></div>`;
    }).join("");
  } catch (error) {
    setStatus(error.message, "bad", "partiesNote");
  }
}

el("parties").addEventListener("click", (event) => {
  const button = event.target.closest("button[data-party]");
  if (!button) return;
  confirmClick(button, async () => {
    await post("./api/party/delete", { id: button.dataset.party }).catch((e) => setStatus(e.message, "bad", "partiesNote"));
    loadParties(true);
  });
});

el("newParty").dataset.sure = "newPartySure";
el("newParty").addEventListener("click", () => confirmClick(el("newParty"), async () => {
  try {
    await post("./api/party/new", { title: "" });
    setStatus(t("newPartyDone"), "ok", "partiesNote");
    el("newParty").textContent = t("newParty");
    el("partyTitle").value = "";
    await refresh();
    loadPhotos(true);
    loadParties(true);
  } catch (error) {
    setStatus(error.message, "bad", "partiesNote");
  }
}));

el("partyTitle").addEventListener("change", async (event) => {
  try {
    await post("./api/title", { title: event.target.value });
    setStatus(t("saved"), "ok", "partiesNote");
    partiesAt = 0;
    loadParties(true);
    refresh();
  } catch (error) {
    setStatus(error.message, "bad", "partiesNote");
  }
});

// ------------------------------------------------------------ Darstellen

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  // Eine eben gewählte Sprache nicht von einer älteren Antwort zurückdrehen lassen.
  if (Date.now() - langChangedAt > 6000 || s.Language === lang) applyLanguage(s.Language);
  const stats = state.stats || {};
  const phaseKey = { welcome: "nowWelcome", wall: "nowWall", top: "nowTop", recap: "nowRecap" }[state.phase] || "nowWall";
  el("factNow").textContent = state.sceneVisible ? t(phaseKey) : (state.phase === "recap" ? t("nowRecap") + " · " : "") + t("nowOff");
  el("factPhotos").textContent = stats.waiting ? t("photosLine", { n: fmt(stats.photos), w: fmt(stats.waiting) }) : fmt(stats.photos);
  el("factGuests").textContent = state.activeGuests ? t("guestsLine", { n: fmt(stats.guests), a: fmt(state.activeGuests) }) : fmt(stats.guests);
  el("factReactions").textContent = fmt(stats.reactions);
  el("factVersion").textContent = state.version;
  const party = state.party;
  let line = t("partyLine", { title: party.title || t("untitled"), time: clock(party.started), code: party.code });
  if (state.takeover) line += t("takeoverOn", { time: clock(state.takeoverUntil) });
  else if (state.takeoverWanted) line += t("takeoverWait");
  el("partyLine").textContent = line;
  el("startButton").hidden = state.takeover || state.takeoverWanted;
  el("endButton").hidden = !(state.takeover || state.takeoverWanted);
  el("recapButton").textContent = t(party.recap ? "recapStop" : "recapStart");
  el("recapButton").dataset.on = party.recap ? "1" : "";
  setStatus(state.takeoverNote || "", state.takeoverNote ? "bad" : "", "takeoverNote");
  if (document.activeElement !== el("partyTitle")) el("partyTitle").value = party.title || "";
  el("zipLink").href = `./api/zip?party=${encodeURIComponent(party.id)}`;
  if (document.activeElement !== el("MakePlaylist")) el("MakePlaylist").value = String(Boolean(s.MakePlaylist));
  el("playlistNote").textContent = state.ownPlaylist || "";
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Party Wall ${state.version}] `);
  renderPhone(state);

  if (!editing) {
    for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) el(name).value = String(s[name]);
    el("Language").value = lang;
  }
  loadPhotos();
  loadParties();
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS, ["partyTitle"])) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
}
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
for (const name of TEXT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));
el("Language").addEventListener("change", (e) => {
  const chosen = e.target.value;
  langChangedAt = Date.now();
  if (current) current.settings.Language = chosen;
  applyLanguage(chosen);
  save({ Language: chosen });
});

async function action(path, body) {
  try {
    await post(path, body);
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}
el("startButton").addEventListener("click", () => action("./api/start"));
el("endButton").addEventListener("click", () => action("./api/end"));
el("recapButton").addEventListener("click", () => action("./api/recap", { on: !el("recapButton").dataset.on }));
el("codeButton").addEventListener("click", () => action("./api/code"));

applyLanguage(document.documentElement.lang);
refresh();
setInterval(refresh, 4000);
