/* Solar System Live – gemalte Texturen (Canvas, ohne fremde Bilder).
 *
 * Alles wird beim Start aus Rauschen gemalt, im Stil handbemalter Modelle.
 * Erde aus den Natural-Earth-Küsten (land.js). Größe je nach Grafik-Stufe.
 */
(function () {
  "use strict";

  // ------------------------------------------------------------ Rauschen
  function hash(x, y, seed) {
    let h = (x * 374761393 + y * 668265263 + seed * 1442695041) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }
  function noise2(x, y, seed, wrap) {
    const xi = Math.floor(x), yi = Math.floor(y);
    const xf = x - xi, yf = y - yi;
    const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
    const w = (k) => (wrap ? ((k % wrap) + wrap) % wrap : k);
    const a = hash(w(xi), yi, seed), b = hash(w(xi + 1), yi, seed);
    const c = hash(w(xi), yi + 1, seed), d = hash(w(xi + 1), yi + 1, seed);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  }
  // fbm, horizontal nahtlos (wrap = Zellen über die Breite bei Frequenz 1)
  function fbm(x, y, seed, oct, wrap) {
    let s = 0, amp = 0.5, f = 1, norm = 0;
    for (let o = 0; o < oct; o += 1) {
      s += amp * noise2(x * f, y * f, seed + o * 17, wrap ? wrap * f : 0);
      norm += amp; amp *= 0.5; f *= 2;
    }
    return s / norm;
  }

  function canvas(w, h) {
    const c = document.createElement("canvas");
    c.width = w; c.height = h;
    return c;
  }
  const mix = (a, b, k) => a + (b - a) * k;
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };

  function paint(w, h, fn) {
    const c = canvas(w, h);
    const g = c.getContext("2d");
    const img = g.createImageData(w, h);
    const d = img.data;
    const col = [0, 0, 0];
    for (let y = 0; y < h; y += 1) {
      const lat = 90 - (y + 0.5) / h * 180;
      for (let x = 0; x < w; x += 1) {
        const lon = (x + 0.5) / w * 360 - 180;
        fn(lon, lat, x / w, y / h, col);
        const k = (y * w + x) * 4;
        d[k] = col[0]; d[k + 1] = col[1]; d[k + 2] = col[2]; d[k + 3] = 255;
      }
    }
    g.putImageData(img, 0, 0);
    return c;
  }

  // Farbverlauf aus Stützstellen [[t, r, g, b], ...]
  function ramp(stops, t, out) {
    t = clamp(t);
    for (let i = 1; i < stops.length; i += 1) {
      if (t <= stops[i][0]) {
        const a = stops[i - 1], b = stops[i];
        const k = (t - a[0]) / Math.max(1e-6, b[0] - a[0]);
        out[0] = mix(a[1], b[1], k); out[1] = mix(a[2], b[2], k); out[2] = mix(a[3], b[3], k);
        return out;
      }
    }
    const l = stops[stops.length - 1];
    out[0] = l[1]; out[1] = l[2]; out[2] = l[3];
    return out;
  }

  // ------------------------------------------------------------ Gasriesen
  function bands(w, h, seed, stops, opts) {
    const o = Object.assign({ turb: 0.06, freq: 9, storm: null, wobble: 0.5 }, opts || {});
    return paint(w, h, (lon, lat, u, v, col) => {
      const tw = fbm(u * 8, v * 24, seed, 4, 8) - 0.5;
      const sw = fbm(u * 3, v * 3, seed + 5, 3, 3) - 0.5;
      let t = v + tw * o.turb + sw * o.turb * o.wobble;
      let k = 0.5 + 0.5 * Math.sin(t * Math.PI * o.freq + Math.sin(t * 7.3) * 1.2);
      k = k * 0.75 + fbm(u * 30, v * 60, seed + 9, 3, 30) * 0.25;
      ramp(stops, k, col);
      const pole = smooth(0.55, 0.95, Math.abs(lat) / 90);
      col[0] = mix(col[0], o.pole ? o.pole[0] : col[0] * 0.8, pole);
      col[1] = mix(col[1], o.pole ? o.pole[1] : col[1] * 0.8, pole);
      col[2] = mix(col[2], o.pole ? o.pole[2] : col[2] * 0.85, pole);
      if (o.storm) {
        const s = o.storm;
        let dl = lon - s.lon; if (dl > 180) dl -= 360; if (dl < -180) dl += 360;
        const r = Math.hypot(dl / s.rx, (lat - s.lat) / s.ry);
        if (r < 1.25) {
          const swirl = fbm(u * 40 + r * 2, v * 40, seed + 31, 2, 40);
          const a = smooth(1.25, 0.6, r) * (0.75 + 0.25 * swirl);
          col[0] = mix(col[0], s.c[0], a); col[1] = mix(col[1], s.c[1], a); col[2] = mix(col[2], s.c[2], a);
        }
      }
    });
  }

  // ------------------------------------------------------------ Gestein mit Kratern
  function rocky(w, h, seed, base, opts) {
    const o = Object.assign({ craters: 140, dark: null, maria: [], caps: 0, capColor: [235, 235, 240], contrast: 0.35 }, opts || {});
    const c = paint(w, h, (lon, lat, u, v, col) => {
      const n = fbm(u * 10, v * 5, seed, 5, 10);
      const m = fbm(u * 3, v * 1.5, seed + 3, 3, 3);
      let k = 0.5 + (n - 0.5) * o.contrast * 2;
      ramp(base, k, col);
      if (o.dark) {
        const a = smooth(0.48, 0.62, m) * o.dark[3];
        col[0] = mix(col[0], o.dark[0], a); col[1] = mix(col[1], o.dark[1], a); col[2] = mix(col[2], o.dark[2], a);
      }
      for (const mare of o.maria) {
        let dl = lon - mare[1]; if (dl > 180) dl -= 360; if (dl < -180) dl += 360;
        const r = Math.hypot(dl * Math.cos(lat * Math.PI / 180), lat - mare[0]) / mare[2];
        const edge = mare[2] * (0.25 * (fbm(u * 20, v * 10, seed + 77, 2, 20) - 0.5));
        const a = smooth(1.1 + edge / mare[2], 0.75, r) * (mare[3] || 0.6);
        if (a > 0) { col[0] = mix(col[0], o.mariaColor[0], a); col[1] = mix(col[1], o.mariaColor[1], a); col[2] = mix(col[2], o.mariaColor[2], a); }
      }
      if (o.caps) {
        const capEdge = o.caps + (fbm(u * 16, v * 4, seed + 41, 3, 16) - 0.5) * 8;
        const a = smooth(capEdge, capEdge + 3, Math.abs(lat));
        col[0] = mix(col[0], o.capColor[0], a); col[1] = mix(col[1], o.capColor[1], a); col[2] = mix(col[2], o.capColor[2], a);
      }
    });
    // Krater
    const g = c.getContext("2d");
    let s = seed * 9973;
    const rnd = () => { s = (s * 16807) % 2147483647; return s / 2147483647; };
    for (let i = 0; i < o.craters; i += 1) {
      const y = h * (0.08 + 0.84 * Math.acos(1 - 2 * rnd()) / Math.PI);
      const x = rnd() * w;
      const r = (0.4 + Math.pow(rnd(), 3) * 7) * w / 512;
      const sx = 1 / Math.max(0.25, Math.sin(y / h * Math.PI));
      for (const dx of [0, -w, w]) {
        g.save();
        g.translate(x + dx, y);
        g.scale(sx, 1);
        const grad = g.createRadialGradient(-r * 0.15, -r * 0.15, r * 0.2, 0, 0, r);
        grad.addColorStop(0, "rgba(0,0,0,0.22)");
        grad.addColorStop(0.75, "rgba(0,0,0,0.10)");
        grad.addColorStop(0.9, "rgba(255,255,255,0.16)");
        grad.addColorStop(1, "rgba(255,255,255,0)");
        g.fillStyle = grad;
        g.beginPath(); g.arc(0, 0, r, 0, Math.PI * 2); g.fill();
        g.restore();
      }
    }
    return c;
  }

  // ------------------------------------------------------------ Erde
  function earth(w, h) {
    const c = canvas(w, h);
    const g = c.getContext("2d");
    // Meer
    const sea = g.createLinearGradient(0, 0, 0, h);
    sea.addColorStop(0, "#1d3f63"); sea.addColorStop(0.25, "#1b4a78"); sea.addColorStop(0.5, "#1a5384");
    sea.addColorStop(0.75, "#1b4a78"); sea.addColorStop(1, "#1d3f63");
    g.fillStyle = sea; g.fillRect(0, 0, w, h);
    const data = window.WORLD_MAP || { land: [], lakes: [] };
    const X = (lon) => (lon + 180) / 360 * w, Y = (lat) => (90 - lat) / 180 * h;
    const ring = (path, flat) => {
      let lon = flat[0] / 100, lat = flat[1] / 100, minLon = lon, maxLon = lon;
      const pts = [[lon, lat]];
      for (let k = 2; k < flat.length; k += 2) {
        lon += flat[k] / 100; lat += flat[k + 1] / 100;
        pts.push([lon, lat]); minLon = Math.min(minLon, lon); maxLon = Math.max(maxLon, lon);
      }
      path.moveTo(X(pts[0][0]), Y(pts[0][1]));
      for (const [a, b] of pts.slice(1)) path.lineTo(X(a), Y(b));
      if (maxLon - minLon > 300) { path.lineTo(X(pts[pts.length - 1][0]), h); path.lineTo(X(pts[0][0]), h); }
      path.closePath();
    };
    const land = new Path2D(), lakes = new Path2D();
    for (const r of data.land || []) ring(land, r);
    for (const r of data.lakes || []) ring(lakes, r);
    // Landfarben nach Breite (Wüstengürtel, Wälder, Tundra) mit Rauschen
    const lc = paint(w, h, (lon, lat, u, v, col) => {
      const a = Math.abs(lat);
      const n = fbm(u * 14, v * 7, 11, 4, 14);
      const dry = smooth(32, 18, Math.abs(a - 24)) * smooth(0.35, 0.65, n + 0.15);
      let r = mix(70, 52, n), gg = mix(104, 88, n), b = mix(58, 48, n);         // Grün
      r = mix(r, 196, dry * 0.85); gg = mix(gg, 168, dry * 0.85); b = mix(b, 112, dry * 0.85);  // Wüste
      const boreal = smooth(48, 62, a);
      r = mix(r, 86, boreal * 0.6); gg = mix(gg, 98, boreal * 0.6); b = mix(b, 78, boreal * 0.6);
      const ice = smooth(64, 72, a + (n - 0.5) * 10);
      r = mix(r, 236, ice); gg = mix(gg, 240, ice); b = mix(b, 244, ice);
      col[0] = r; col[1] = gg; col[2] = b;
    });
    g.save();
    g.clip(land, "evenodd");
    g.drawImage(lc, 0, 0);
    g.restore();
    g.fillStyle = "#1b4a78"; g.fill(lakes);
    // Küsten leicht abgesetzt
    g.strokeStyle = "rgba(220, 230, 200, 0.25)"; g.lineWidth = Math.max(1, w / 1400); g.stroke(land);
    // Meereis / Polkappen
    const ice = g.createLinearGradient(0, 0, 0, h);
    ice.addColorStop(0, "rgba(240,245,250,0.95)"); ice.addColorStop(0.06, "rgba(240,245,250,0.35)");
    ice.addColorStop(0.1, "rgba(240,245,250,0)"); ice.addColorStop(0.88, "rgba(240,245,250,0)");
    ice.addColorStop(0.93, "rgba(240,245,250,0.6)"); ice.addColorStop(1, "rgba(240,245,250,1)");
    g.fillStyle = ice; g.fillRect(0, 0, w, h);
    return c;
  }

  function clouds(w, h, seed) {
    const c = paint(w, h, (lon, lat, u, v, col) => {
      const a = Math.abs(lat);
      const n = fbm(u * 12, v * 6, seed, 5, 12);
      const belt = 0.55 + 0.25 * smooth(10, 0, Math.abs(a - 55)) + 0.15 * smooth(8, 0, a) - 0.18 * smooth(14, 0, Math.abs(a - 25));
      const k = smooth(0.5, 0.75, n * belt + 0.18);
      col[0] = col[1] = col[2] = Math.round(255 * k);
    });
    return c;   // als Alpha-Karte (Grauwert)
  }

  // ------------------------------------------------------------ Saturnringe (1D)
  function rings(w) {
    const c = canvas(w, 4);
    const g = c.getContext("2d");
    const img = g.createImageData(w, 4);
    for (let x = 0; x < w; x += 1) {
      const t = x / (w - 1);                         // 0 = innen (1.24 R), 1 = außen (2.27 R)
      const r = 1.24 + t * (2.27 - 1.24);
      let a = 0;
      if (r < 1.53) a = 0.12 + 0.08 * noise2(x * 0.3, 0, 3);              // C-Ring
      else if (r < 1.95) a = 0.75 + 0.2 * noise2(x * 0.5, 0, 5);          // B-Ring
      else if (r < 2.03) a = 0.03;                                         // Cassini-Teilung
      else if (r < 2.27) a = 0.5 + 0.2 * noise2(x * 0.5, 0, 7);           // A-Ring
      if (r > 2.21 && r < 2.225) a *= 0.2;                                 // Encke-Lücke
      a *= 0.85 + 0.3 * noise2(x * 2.1, 1, 9);
      const shade = 0.8 + 0.2 * noise2(x * 0.7, 2, 13);
      const tone = r < 1.53 ? [150, 140, 125] : [222, 203, 168];
      for (let y = 0; y < 4; y += 1) {
        const k = (y * w + x) * 4;
        img.data[k] = tone[0] * shade; img.data[k + 1] = tone[1] * shade; img.data[k + 2] = tone[2] * shade;
        img.data[k + 3] = clamp(a) * 255;
      }
    }
    g.putImageData(img, 0, 0);
    return c;
  }

  // ------------------------------------------------------------ Milchstraße / Sternhimmel
  // Plattkarte in ekliptikalen Koordinaten; Helligkeit nach galaktischer Breite
  function milkyWay(w, h) {
    const eps = 23.4393 * Math.PI / 180;
    // galaktischer Nordpol (J2000) RA 192.859°, Dec 27.128° -> Vektor in Äquator, dann Ekliptik
    const ra = 192.859 * Math.PI / 180, de = 27.128 * Math.PI / 180;
    const pe = [Math.cos(de) * Math.cos(ra), Math.cos(de) * Math.sin(ra), Math.sin(de)];
    const gp = [pe[0], pe[1] * Math.cos(eps) + pe[2] * Math.sin(eps), -pe[1] * Math.sin(eps) + pe[2] * Math.cos(eps)];
    // galaktisches Zentrum RA 266.405, Dec -28.936
    const rc = 266.405 * Math.PI / 180, dc = -28.936 * Math.PI / 180;
    const ce = [Math.cos(dc) * Math.cos(rc), Math.cos(dc) * Math.sin(rc), Math.sin(dc)];
    const gc = [ce[0], ce[1] * Math.cos(eps) + ce[2] * Math.sin(eps), -ce[1] * Math.sin(eps) + ce[2] * Math.cos(eps)];
    return paint(w, h, (lon, lat, u, v, col) => {
      const lo = lon * Math.PI / 180, la = lat * Math.PI / 180;
      const d = [Math.cos(la) * Math.cos(lo), Math.cos(la) * Math.sin(lo), Math.sin(la)];
      const b = Math.asin(clamp(d[0] * gp[0] + d[1] * gp[1] + d[2] * gp[2], -1, 1)) * 180 / Math.PI;
      const toCenter = d[0] * gc[0] + d[1] * gc[1] + d[2] * gc[2];
      const n = fbm(u * 40, v * 20, 21, 4, 40);
      const dust = smooth(0.45, 0.7, fbm(u * 60, v * 30, 23, 3, 60));
      let k = Math.exp(-(b * b) / (2 * 7 * 7)) * (0.55 + 0.45 * n) * (0.6 + 0.4 * (toCenter + 1) / 2);
      k *= 1 - 0.55 * dust * Math.exp(-(b * b) / 8);
      k += 0.05 * Math.exp(-(b * b) / (2 * 25 * 25)) * n;
      col[0] = 6 + 52 * k; col[1] = 8 + 48 * k; col[2] = 16 + 54 * k;
    });
  }

  function glow(size, stops) {
    const c = canvas(size, size);
    const g = c.getContext("2d");
    const grad = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
    for (const [t, color] of stops) grad.addColorStop(t, color);
    g.fillStyle = grad;
    g.fillRect(0, 0, size, size);
    return c;
  }

  // ------------------------------------------------------------ alle Texturen
  function makeAll(tier) {
    const S = tier === "pi4" ? 512 : 1024;
    const H = S / 2;
    const out = {};
    out.mercury = rocky(S, H, 3, [[0, 92, 88, 84], [0.5, 140, 134, 126], [1, 190, 182, 170]], { craters: 260 });
    out.venus = bands(S, H, 4, [[0, 196, 160, 104], [0.5, 228, 204, 152], [1, 240, 226, 190]], { turb: 0.25, freq: 3, wobble: 1.6 });
    out.earth = earth(S * 2, H * 2);
    out.clouds = clouds(S, H, 6);
    out.moon = rocky(S, H, 7, [[0, 120, 118, 114], [0.5, 172, 170, 165], [1, 214, 212, 206]], {
      craters: 220, contrast: 0.25, mariaColor: [88, 88, 92],
      maria: [[33, -16, 12, 0.75], [28, 17, 7, 0.75], [8, 31, 9, 0.75], [17, 59, 5, 0.8], [-8, 51, 6, 0.7],
        [-21, -17, 8, 0.6], [18, -55, 20, 0.6], [56, 0, 6, 0.5], [-15, 35, 4, 0.6], [-24, -39, 4, 0.65], [2, -13, 4, 0.5],
        [-2, -28, 7, 0.45]]
    });
    out.mars = rocky(S, H, 8, [[0, 150, 70, 40], [0.5, 190, 98, 56], [1, 214, 140, 90]], {
      craters: 90, dark: [100, 52, 36, 0.7], caps: 76, capColor: [240, 236, 228] });
    out.jupiter = bands(S, H, 9, [[0, 140, 98, 68], [0.3, 196, 160, 120], [0.55, 236, 222, 196], [0.8, 200, 150, 104], [1, 240, 232, 214]],
      { turb: 0.05, freq: 14, storm: { lat: -22, lon: 40, rx: 14, ry: 6, c: [192, 92, 60] }, pole: [150, 130, 112] });
    out.saturn = bands(S, H, 10, [[0, 196, 170, 120], [0.5, 228, 206, 160], [1, 244, 230, 196]], { turb: 0.03, freq: 11, pole: [176, 170, 150] });
    out.uranus = bands(S, H, 11, [[0, 150, 210, 216], [0.5, 170, 224, 228], [1, 190, 234, 236]], { turb: 0.02, freq: 4 });
    out.neptune = bands(S, H, 12, [[0, 40, 80, 190], [0.5, 60, 110, 214], [1, 120, 160, 230]], {
      turb: 0.06, freq: 6, storm: { lat: -20, lon: -60, rx: 9, ry: 5, c: [30, 50, 130] } });
    out.pluto = rocky(S / 2, H / 2, 13, [[0, 120, 96, 78], [0.5, 170, 140, 112], [1, 214, 190, 160]], {
      craters: 40, mariaColor: [236, 226, 210], maria: [[-5, 175, 22, 0.9], [-20, 155, 14, 0.8]] });
    out.ice = rocky(S / 4, H / 4, 14, [[0, 170, 170, 175], [1, 225, 225, 230]], { craters: 30, contrast: 0.2 });
    out.io = rocky(S / 4, H / 4, 15, [[0, 200, 170, 70], [0.5, 230, 210, 110], [1, 240, 236, 170]], { craters: 0, dark: [150, 80, 40, 0.8] });
    out.europa = rocky(S / 4, H / 4, 16, [[0, 196, 180, 160], [1, 236, 230, 218]], { craters: 5, dark: [150, 110, 80, 0.5], contrast: 0.2 });
    out.titan = bands(S / 4, H / 4, 17, [[0, 200, 150, 70], [1, 226, 180, 100]], { turb: 0.1, freq: 2 });
    out.dark = rocky(S / 4, H / 4, 18, [[0, 80, 76, 70], [1, 140, 132, 120]], { craters: 30 });
    out.rings = rings(1024);
    out.milky = milkyWay(tier === "pi4" ? 1024 : 2048, tier === "pi4" ? 512 : 1024);
    out.sunGlow = glow(256, [[0, "rgba(255,244,214,1)"], [0.12, "rgba(255,226,160,0.85)"], [0.3, "rgba(255,190,110,0.25)"],
      [0.6, "rgba(255,150,80,0.06)"], [1, "rgba(255,140,60,0)"]]);
    out.dot = glow(64, [[0, "rgba(255,255,255,1)"], [0.35, "rgba(255,255,255,0.6)"], [1, "rgba(255,255,255,0)"]]);
    return out;
  }

  window.SSL_TEXTURES = { makeAll, fbm, noise2 };
})();
