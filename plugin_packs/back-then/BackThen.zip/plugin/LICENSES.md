# Third-party notes

- Facts (events, people born, heads of government, number-one hits) come from Wikipedia and Wikidata. Wikidata content is CC0; Wikipedia text is CC BY-SA 4.0 (only titles, names and dates are used).
- Portraits come from Wikimedia Commons; each picture keeps the licence stated on its Commons page.
- Prices: Statistisches Bundesamt (Destatis), U.S. Bureau of Labor Statistics, Eurostat; consumer price indices from the World Bank (CC BY 4.0).
- The scene bundles the fonts Fraunces and Inter under the SIL Open Font License 1.1 (see `dynamic/fonts/OFL-*.txt`).
- `exif_gps.py` is shared with the Travel Map plugin (own code).
