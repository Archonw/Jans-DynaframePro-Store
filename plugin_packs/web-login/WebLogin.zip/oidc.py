"""Web Login - OpenID Connect sign-in (authorization code flow with PKCE).

Standard library only, so the login service needs nothing installed. Works
with any OIDC provider (Authentik, Authelia, Pocket ID, Keycloak, Zitadel,
Kanidm, Google ...). The settings (data/authd.json, key "oidc"):

  enabled        true / false
  issuer         e.g. https://auth.example.com/application/o/dynaframe/
  clientId       the client ID the provider shows
  clientSecret   empty for a public client
  label          text on the sign-in button ("Authentik", say)
  allowedUsers   optional: user names, e-mail addresses or subject IDs
  allowedGroups  optional: groups (from the "groups" claim)
  caPem          optional: the certificate of a provider with its own CA
  insecure       optional: do not check the provider's certificate at all

The ID token comes straight from the provider's token endpoint over TLS, which
the spec accepts as proof on its own (OIDC Core 3.1.3.7). RS256 signatures are
checked as well when the provider publishes its keys.
"""

import base64
import hashlib
import hmac
import json
import secrets
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

TIMEOUT = 10
STATE_TTL = 600
DISCOVERY_TTL = 3600
_SHA256_PREFIX = bytes.fromhex("3031300d060960864801650304020105000420")


class OidcError(Exception):
    """A sign-in that did not work; the text is shown on the login page."""


def b64url(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def unb64url(text):
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def settings(config):
    data = config.get("oidc") if hasattr(config, "get") else None
    return data if isinstance(data, dict) else {}


def enabled(config):
    o = settings(config)
    return bool(o.get("enabled") and o.get("issuer") and o.get("clientId"))


def tls_context(o):
    if o.get("insecure"):
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        return context
    pem = str(o.get("caPem") or "").strip()
    if pem:
        context = ssl.create_default_context()
        context.load_verify_locations(cadata=pem)
        return context
    return ssl.create_default_context()


def http_json(url, o, data=None, headers=None):
    request = urllib.request.Request(url, data=data, headers={"Accept": "application/json", **(headers or {})})
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT, context=tls_context(o)) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")[:300]
        raise OidcError(f"{urllib.parse.urlsplit(url).netloc}: HTTP {exc.code} {body}") from None
    except urllib.error.URLError as exc:
        raise OidcError(f"{urllib.parse.urlsplit(url).netloc}: {exc.reason}") from None
    except (OSError, ValueError) as exc:
        raise OidcError(f"{urllib.parse.urlsplit(url).netloc}: {exc}") from None


class Provider:
    """Discovery, the sign-in redirect and the code exchange."""

    def __init__(self):
        self.lock = threading.Lock()
        self.discovery = {}      # issuer -> (time, document)
        self.keys = {}           # jwks_uri -> (time, keys)
        self.pending = {}        # state -> dict

    # -- discovery ---------------------------------------------------------

    def document(self, o, fresh=False):
        issuer = str(o.get("issuer") or "").strip()
        if not issuer.startswith(("https://", "http://")):
            raise OidcError("issuer must start with https://")
        with self.lock:
            stamp, doc = self.discovery.get(issuer, (0, None))
        if doc and not fresh and time.time() - stamp < DISCOVERY_TTL:
            return doc
        url = issuer.rstrip("/") + "/.well-known/openid-configuration"
        doc = http_json(url, o)
        for key in ("authorization_endpoint", "token_endpoint", "issuer"):
            if not doc.get(key):
                raise OidcError(f"discovery document has no {key}")
        if doc["issuer"].rstrip("/") != issuer.rstrip("/"):
            raise OidcError(f"issuer is {doc['issuer']}, not {issuer}")
        with self.lock:
            self.discovery[issuer] = (time.time(), doc)
        return doc

    def jwks(self, o, uri):
        with self.lock:
            stamp, keys = self.keys.get(uri, (0, None))
        if keys is not None and time.time() - stamp < DISCOVERY_TTL:
            return keys
        keys = http_json(uri, o).get("keys") or []
        with self.lock:
            self.keys[uri] = (time.time(), keys)
        return keys

    # -- sign-in -----------------------------------------------------------

    def start(self, o, redirect_uri, target):
        doc = self.document(o)
        state = secrets.token_urlsafe(24)
        nonce = secrets.token_urlsafe(24)
        verifier = secrets.token_urlsafe(48)
        challenge = b64url(hashlib.sha256(verifier.encode()).digest())
        scopes = ["openid", "profile", "email"]
        if "groups" in (doc.get("scopes_supported") or []):
            scopes.append("groups")
        with self.lock:
            now = time.time()
            for key in [k for k, v in self.pending.items() if now - v["created"] > STATE_TTL]:
                self.pending.pop(key, None)
            while len(self.pending) > 200:
                self.pending.pop(next(iter(self.pending)))
            self.pending[state] = {"nonce": nonce, "verifier": verifier, "target": target,
                                   "redirect": redirect_uri, "created": now}
        query = {
            "response_type": "code", "client_id": o["clientId"], "redirect_uri": redirect_uri,
            "scope": " ".join(scopes), "state": state, "nonce": nonce,
            "code_challenge": challenge, "code_challenge_method": "S256",
        }
        sep = "&" if "?" in doc["authorization_endpoint"] else "?"
        return state, doc["authorization_endpoint"] + sep + urllib.parse.urlencode(query)

    def finish(self, o, state, code):
        """Returns (claims, target) for a good sign-in, raises OidcError otherwise."""
        with self.lock:
            pending = self.pending.pop(state, None)
        if not pending or time.time() - pending["created"] > STATE_TTL:
            raise OidcError("sign-in took too long or was started elsewhere; please try again")
        doc = self.document(o)
        form = {"grant_type": "authorization_code", "code": code, "redirect_uri": pending["redirect"],
                "code_verifier": pending["verifier"]}
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        secret = str(o.get("clientSecret") or "")
        methods = doc.get("token_endpoint_auth_methods_supported") or ["client_secret_basic"]
        if secret and "client_secret_basic" in methods:
            pair = f"{urllib.parse.quote(o['clientId'], safe='')}:{urllib.parse.quote(secret, safe='')}"
            headers["Authorization"] = "Basic " + base64.b64encode(pair.encode()).decode()
        else:
            form["client_id"] = o["clientId"]
            if secret:
                form["client_secret"] = secret
        tokens = http_json(doc["token_endpoint"], o, urllib.parse.urlencode(form).encode(), headers)
        id_token = tokens.get("id_token")
        if not id_token:
            raise OidcError("the provider sent no ID token")
        claims = self.check_token(o, doc, id_token, pending["nonce"])
        if (o.get("allowedGroups") or o.get("allowedUsers")) and doc.get("userinfo_endpoint") \
                and tokens.get("access_token") and not ({"email", "groups"} <= set(claims)):
            try:
                info = http_json(doc["userinfo_endpoint"], o,
                                 headers={"Authorization": f"Bearer {tokens['access_token']}"})
                if info.get("sub") == claims.get("sub"):
                    claims = {**info, **claims}
            except OidcError:
                pass
        return claims, pending["target"]

    def check_token(self, o, doc, token, nonce):
        try:
            head_b64, body_b64, sig_b64 = token.split(".")
            header = json.loads(unb64url(head_b64))
            claims = json.loads(unb64url(body_b64))
        except (ValueError, TypeError):
            raise OidcError("the ID token cannot be read") from None
        if header.get("alg") == "RS256" and doc.get("jwks_uri"):
            keys = [k for k in self.jwks(o, doc["jwks_uri"]) if k.get("kty") == "RSA"
                    and (not header.get("kid") or k.get("kid") == header.get("kid"))]
            signed = f"{head_b64}.{body_b64}".encode()
            if not keys or not any(verify_rs256(signed, unb64url(sig_b64), k) for k in keys):
                raise OidcError("the ID token's signature does not match the provider's keys")
        elif header.get("alg") in (None, "none"):
            raise OidcError("unsigned ID token")
        issuer = str(doc.get("issuer") or "").rstrip("/")
        if str(claims.get("iss") or "").rstrip("/") != issuer:
            raise OidcError("the ID token is from another issuer")
        audience = claims.get("aud")
        audience = audience if isinstance(audience, list) else [audience]
        if o["clientId"] not in audience:
            raise OidcError("the ID token is for another client")
        if claims.get("nonce") != nonce:
            raise OidcError("the ID token does not belong to this sign-in")
        if float(claims.get("exp") or 0) < time.time() - 120:
            raise OidcError("the ID token has expired")
        return claims


def verify_rs256(signed, signature, jwk):
    try:
        n = int.from_bytes(unb64url(jwk["n"]), "big")
        e = int.from_bytes(unb64url(jwk["e"]), "big")
    except (KeyError, ValueError, TypeError):
        return False
    size = (n.bit_length() + 7) // 8
    if len(signature) != size:
        return False
    decoded = pow(int.from_bytes(signature, "big"), e, n).to_bytes(size, "big")
    digest = _SHA256_PREFIX + hashlib.sha256(signed).digest()
    expected = b"\x00\x01" + b"\xff" * (size - len(digest) - 3) + b"\x00" + digest
    return hmac.compare_digest(decoded, expected)


def allowed(o, claims):
    """Empty lists = everyone the provider lets through for this client."""
    users = {str(u).strip().lower() for u in o.get("allowedUsers") or [] if str(u).strip()}
    groups = {str(g).strip().lower() for g in o.get("allowedGroups") or [] if str(g).strip()}
    if not users and not groups:
        return True
    names = {str(claims.get(k) or "").lower() for k in ("sub", "email", "preferred_username", "name")} - {""}
    member = claims.get("groups") or []
    member = {str(g).lower() for g in (member if isinstance(member, list) else [member])}
    return bool(names & users) or bool(member & groups)


def who(claims):
    return str(claims.get("preferred_username") or claims.get("email") or claims.get("name") or claims.get("sub") or "?")
