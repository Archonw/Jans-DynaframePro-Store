# Third-party notes

- Leaflet 1.9.4 (`phone/leaflet/`, and a copy in the scene), © Volodymyr Agafonkin and CloudMade, BSD 2-Clause licence (see `phone/leaflet/LICENSE`).
- QR Code Generator for JavaScript (`phone/qrcode.js`, and a copy in the scene), © 2009 Kazuhiko Arase, MIT licence. The word "QR Code" is a registered trademark of DENSO WAVE INCORPORATED.
- Map tiles: © OpenStreetMap contributors (ODbL), © CARTO (basemaps.cartocdn.com), loaded by the scene and the phone page.
- Coastlines for the map when no tiles load: Natural Earth 1:50m, public domain (naturalearthdata.com), shared with the Travel Map plugin.
- Weather data by Open-Meteo.com (https://open-meteo.com), licensed under CC BY 4.0; historical data from the ERA5 reanalysis (Copernicus Climate Change Service).
- Place names from OpenStreetMap via Nominatim, © OpenStreetMap contributors, ODbL.
- The scene bundles the fonts Fraunces and Inter under the SIL Open Font License 1.1 (see `dynamic/fonts/OFL-*.txt`).
- `exif_gps.py` is shared with the Travel Map plugin (own code).
