#!/usr/bin/env python3
"""Reisekarte - der Plugin-Teil des Pakets.

Die Szene "travel-map" zeichnet eine Weltkarte im Stil eines alten Globus und
steckt Nadeln an die Orte, an denen Fotos entstanden sind. Dieses Plugin
sammelt dafür die Positionen:

- aus einer Playlist von DynaFrame,
- aus der ganzen Mediendatenbank von DynaFrame (und eingehängten Ordnern),
- von einem Immich-Server (alle Fotos oder ein Album).

Jede "Sammlung" bekommt eine eigene Nadel (Farbe und Form). Die Positionen
liest das Plugin aus den Exif-Daten der Dateien (exif_gps.py) oder bekommt sie
von Immich. Die Szene holt die Daten über den Proxy der Weboberfläche, wie
Weltkarte Live, und zeigt ab und zu ein Foto an seiner Nadel.
"""

import json
import os
import re
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import sources  # noqa: E402
import texts  # noqa: E402

plugin = create_plugin()

PLUGIN_ID = "TravelMap"
SCENE_ID = "travel-map"            # id in scene.dynamic - nie ändern
PLAYLIST_NAMES = {"de": "Reisekarte", "en": "Travel Map", "es": "Mapa de viajes"}
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen, Positionen; bleibt bei Updates

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30
CELL_DEG = 0.02                     # Fotos näher als ~2 km sind ein Punkt
KEYS_PER_CELL = 6                   # so viele Fotos je Punkt kann die Szene zeigen
MAX_COLLECTIONS = 8

KINDS = ("library", "playlist", "immich_all", "immich_album")
PINS = ("pin", "tack", "flag", "needle")
PALETTE = ("#b3261e", "#1f4e8c", "#2e6b34", "#c9922b", "#6b3d82", "#1f7a7a", "#c45a24", "#2b2b2b")


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält den API-Schlüssel
        except OSError:
            pass


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

def default_collections():
    return [{"id": "c1", "kind": "library", "ref": "", "name": "", "color": PALETTE[0], "pin": "pin"}]


SCHEMA = {
    "Language":        {"kind": "choice", "default": "de", "choices": texts.LANGUAGES},
    "ServerUrl":       {"kind": "url", "default": ""},
    "ApiKey":          {"kind": "secret", "default": ""},
    "Collections":     {"kind": "collections", "default": None},
    "Layout":          {"kind": "choice", "default": "oval", "choices": ("oval", "globes")},
    "Region":          {"kind": "choice", "default": "world", "choices": ("world", "auto")},
    "Title":           {"kind": "text", "default": ""},
    "Cluster":         {"kind": "bool", "default": True},
    "ShowPhotos":      {"kind": "bool", "default": True},
    "PhotoSeconds":    {"kind": "int", "default": 12, "min": 5, "max": 120},
    "PhotoPause":      {"kind": "int", "default": 20, "min": 2, "max": 3600},
    "PhotoSize":       {"kind": "choice", "default": "l", "choices": ("s", "m", "l", "xl")},
    "ThreadWidth":     {"kind": "choice", "default": "thick", "choices": ("thin", "normal", "thick", "xthick")},
    "MapPan":          {"kind": "bool", "default": True},
    "ShowLegend":      {"kind": "bool", "default": True},
    "PlaceNames":      {"kind": "bool", "default": True},
    "Folders":         {"kind": "folders", "default": ""},
    "RefreshHours":    {"kind": "int", "default": 6, "min": 1, "max": 168},
    "PlaylistSeconds": {"kind": "int", "default": 180, "min": 10, "max": 86400},
}
SECRETS = [name for name, spec in SCHEMA.items() if spec["kind"] == "secret"]
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()


def coerce_collections(raw):
    if raw is None:
        return default_collections()
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return default_collections()
    out, ids = [], set()
    for i, row in enumerate(raw if isinstance(raw, list) else []):
        if not isinstance(row, dict) or len(out) >= MAX_COLLECTIONS:
            continue
        kind = row.get("kind") if row.get("kind") in KINDS else "library"
        ident = re.sub(r"[^A-Za-z0-9]", "", str(row.get("id") or ""))[:16] or uuid.uuid4().hex[:8]
        while ident in ids:
            ident = uuid.uuid4().hex[:8]
        ids.add(ident)
        color = str(row.get("color") or "")
        out.append({
            "id": ident,
            "kind": kind,
            "ref": re.sub(r"[^A-Za-z0-9_-]", "", str(row.get("ref") or ""))[:64],
            "name": re.sub(r"\s+", " ", str(row.get("name") or "")).strip()[:40],
            "color": color if re.match(r"^#[0-9a-fA-F]{6}$", color) else PALETTE[i % len(PALETTE)],
            "pin": row.get("pin") if row.get("pin") in PINS else "pin",
        })
    return out


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "choice":
        value = str(raw or "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "collections":
        return coerce_collections(raw)
    if kind == "url":
        return sources.normalize_url(raw)[:300]
    if kind == "text":
        return re.sub(r"\s+", " ", str(raw or "")).strip()[:60]
    if kind == "folders":
        lines = [line.strip() for line in str(raw or "").replace(";", "\n").splitlines()]
        return "\n".join(line for line in lines if line.startswith("/"))[:2000]
    return re.sub(r"\s+", "", str(raw or ""))[:400]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 120))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


# --------------------------------------------------------------------------
# Die Quellen und das Einlesen
# --------------------------------------------------------------------------

immich = sources.Immich(tr)
geo_cache = sources.GeoCache(read_json, write_json, DATA_DIR / "geo_cache.json")
dynaframe = sources.DynaFrame(engine_call, EngineError, log, geo_cache)
places = sources.Places(read_json, write_json, DATA_DIR / "places.json",
                        "DynaFrame-TravelMap/1.0 (https://github.com/Archonw/Jans-DynaframePro-Store)")

POINTS_FILE = DATA_DIR / "points.json"
_scan_lock = threading.Lock()
_scan_wake = threading.Event()
_stop_requested = threading.Event()
_scan_stop = threading.Event()        # bricht einen laufenden Durchlauf ab (Einstellungen geändert)
_data = {
    "ver": 0,
    "cells": [],          # [lat, lon, collection_index, n, first_taken, [key_idx...]]
    "keys": [],           # [(key, lat, lon, taken, place)]
    "status": {},         # collection id -> {state, total, located, error, at}
    "busy": False, "at": 0.0, "signature": "",
}


def scan_signature(values):
    """Was ein neues Einlesen nötig macht; Farbe, Nadel und Name nicht."""
    wanted = [(c["id"], c["kind"], c["ref"]) for c in values["Collections"]]
    # Die Version gehört dazu: ein neues Plugin liest mit seinen eigenen Schlüsseln neu ein.
    return json.dumps([wanted, values["ServerUrl"], values["ApiKey"], values["Folders"], version()], sort_keys=True)


def collect(collection, values, stop):
    """(Zeilen, Fotos insgesamt) für eine Sammlung."""
    kind = collection["kind"]
    if kind in ("immich_all", "immich_album"):
        immich.configure(values["ServerUrl"], values["ApiKey"])
        if kind == "immich_all":
            return immich.all_markers(stop)
        if not collection["ref"]:
            raise sources.SourceError(tr("Wähle ein Album."))
        return immich.album(collection["ref"], stop)
    if kind == "playlist":
        if not collection["ref"]:
            raise sources.SourceError(tr("Wähle eine Playlist."))
        try:
            return dynaframe.playlist(collection["ref"], stop)
        except EngineError as exc:
            if exc.status == 404:
                raise sources.SourceError(tr("Die Playlist gibt es nicht mehr.")) from exc
            raise sources.SourceError(tr("DynaFrame antwortet nicht: {exc}", exc=exc)) from exc
    folders = [f for f in values["Folders"].splitlines() if f]
    return dynaframe.library(folders, stop)


SHOWABLE = (".jpg", ".jpeg", ".jpe", ".png", ".webp", ".avif")


def showable(key):
    """Kann die Szene das Foto zeigen? HEIC und Raw-Dateien kann der Browser nicht."""
    return not key.startswith("f:") or key.lower().endswith(SHOWABLE)


def engine_image(media_id, path=""):
    """Das Vorschaubild, das die Engine für die Weboberfläche erzeugt."""
    candidates = []
    if path:
        candidates += [("/media/thumbnail", {"path": path, "purpose": "preview"}),
                       ("/media/thumbnail", {"path": path})]
    if media_id:
        candidates += [(f"/media/thumbnail/{media_id}", {"purpose": "preview"}),
                       (f"/media/thumbnail/{media_id}", None)]
    failures = []
    for route, params in candidates:
        try:
            response = requests.get(f"{engine_base()}{route}", params=params, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 60))
        except requests.RequestException as exc:
            failures.append(f"{route}: {exc}")
            continue
        kind = response.headers.get("Content-Type", "").split(";")[0]
        if response.status_code == 200 and kind.startswith("image/"):
            return response.content, kind
        failures.append(f"{route}{'?path' if params and 'path' in params else ''}: HTTP {response.status_code} {kind}")
    raise sources.SourceError(f"Vorschaubild {media_id}: " + "; ".join(failures))


def dynaframe_photo(key):
    """d:<id>|<pfad>: die Datei, wenn sie auf dem Rahmen liegt, sonst das Vorschaubild der Engine."""
    media_id, _, path = key[2:].partition("|")
    if path and path.lower().endswith(SHOWABLE) and os.path.isfile(path):
        try:
            return dynaframe.photo(path)
        except (sources.SourceError, OSError):
            pass
    return engine_image(media_id, path)


def aggregate(results):
    """Fotos zu Punkten zusammenfassen (je Sammlung, ~2 km Raster)."""
    cells, keys = {}, []
    for index, rows in enumerate(results):
        for lat, lon, taken, key, place in rows:
            cell_key = (index, round(lat / CELL_DEG), round(lon / CELL_DEG))
            cell = cells.get(cell_key)
            if cell is None:
                cell = cells[cell_key] = {"lat": 0.0, "lon": 0.0, "n": 0, "t": "", "k": []}
            cell["lat"] += lat
            cell["lon"] += lon
            cell["n"] += 1
            if taken and (not cell["t"] or taken < cell["t"]):
                cell["t"] = taken
            if key and showable(key) and len(cell["k"]) < KEYS_PER_CELL:
                cell["k"].append(len(keys))
                keys.append((key, lat, lon, taken, place))
    out = []
    for (index, _a, _b), cell in cells.items():
        out.append([round(cell["lat"] / cell["n"], 4), round(cell["lon"] / cell["n"], 4), index, cell["n"],
                    cell["t"][:10], cell["k"]])
    out.sort(key=lambda c: (c[4] or "9999", c[2]))
    return out, keys


def scan(reason=""):
    """Alle Sammlungen einlesen. Läuft im Hintergrund."""
    values = settings()
    with _scan_lock:
        if _data["busy"]:
            return
        _data["busy"] = True
        _scan_stop.clear()
    log(f"Lese die Fotos ein{' - ' + reason if reason else ''}.")
    started = now()
    results, status = [], {}
    try:
        for collection in values["Collections"]:
            cid = collection["id"]
            previous = _data["status"].get(cid) or {}
            _data["status"][cid] = dict(previous, state="busy")
            try:
                rows, total = collect(collection, values, _scan_stop)
                status[cid] = {"state": "ok", "total": total, "located": len(rows), "error": "", "at": now()}
            except (sources.SourceError, EngineError) as exc:
                rows = []
                status[cid] = {"state": "error", "total": 0, "located": 0, "error": str(exc), "at": now()}
                log(f"Sammlung {collection['name'] or collection['kind']}: {exc}", "warning")
            except Exception as exc:  # pragma: no cover - darf den Durchlauf nicht beenden
                rows = []
                status[cid] = {"state": "error", "total": 0, "located": 0, "error": str(exc)[:200], "at": now()}
                log(f"Sammlung {collection['name'] or collection['kind']}: {exc!r}", "warning")
            _data["status"][cid] = status[cid]
            results.append(rows)
            if _scan_stop.is_set() or _stop_requested.is_set():
                break
        geo_cache.save()
        if _scan_stop.is_set() or _stop_requested.is_set():
            log("Einlesen abgebrochen.")
            return
        cells, keys = aggregate(results)
        with _scan_lock:
            _data.update(cells=cells, keys=keys, status=status, at=now(), ver=_data["ver"] + 1,
                         signature=scan_signature(values))
        write_json(POINTS_FILE, {"cells": cells, "keys": keys, "status": status, "at": _data["at"],
                                 "signature": _data["signature"]})
        located = sum(s["located"] for s in status.values())
        log(f"{located} Fotos mit Ort an {len(cells)} Orten ({now() - started:.0f} s).")
    finally:
        with _scan_lock:
            _data["busy"] = False


def load_points():
    stored = read_json(POINTS_FILE, {})
    if isinstance(stored, dict) and isinstance(stored.get("cells"), list):
        _data.update(cells=stored["cells"], keys=[tuple(k) for k in stored.get("keys") or []],
                     status=stored.get("status") or {}, at=stored.get("at") or 0.0,
                     signature=stored.get("signature") or "", ver=1)


def scan_loop():
    while not _stop_requested.is_set():
        values = settings()
        due = now() - _data["at"] >= values["RefreshHours"] * 3600
        if due or _data["signature"] != scan_signature(values):
            scan("geplant" if due else "Einstellungen")
        _scan_wake.wait(60)
        _scan_wake.clear()


def rescan_now():
    if _data["busy"]:
        _scan_stop.set()
    _data["at"] = 0.0
    _scan_wake.set()
    return {"success": True, "message": tr("Die Fotos werden neu eingelesen.")}


# --------------------------------------------------------------------------
# Playlist für die Szene
# --------------------------------------------------------------------------

def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


def make_playlist():
    lang = settings()["Language"]
    name = PLAYLIST_NAMES.get(lang, PLAYLIST_NAMES["de"])
    scene = find_scene()
    if scene is None:
        return {"success": False, "error": tr("Die Szene Reisekarte ist auf diesem Rahmen nicht installiert. "
                                              "Installiere das Paket noch einmal.")}
    try:
        existing = next((p for p in dynaframe.playlists() if p["name"] in PLAYLIST_NAMES.values()), None)
        if existing:
            return {"success": True, "message": tr("Die Playlist {name} gibt es schon.", name=existing["name"])}
        created = engine_call("POST", "/playlists", {
            "name": name, "description": tr("Die Weltkarte mit Nadeln an den Orten deiner Fotos.")}) or {}
        playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
        if not playlist_id:
            raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=name))
        engine_call("POST", f"/playlists/{playlist_id}/items",
                    {"dynamicSceneId": scene["id"], "customDurationSeconds": settings()["PlaylistSeconds"]})
    except EngineError as exc:
        log(f"Playlist: {exc}", "warning")
        return {"success": False, "error": tr("Konnte die Playlist nicht anlegen: {exc}", exc=exc)}
    log(f"Playlist {name} angelegt ({playlist_id}).")
    return {"success": True, "message": tr("Playlist {name} angelegt. Starte sie auf der Startseite des Rahmens "
                                           "oder nimm die Szene in eine andere Playlist auf.", name=name)}


# --------------------------------------------------------------------------
# Was die Szene und die Seite bekommen
# --------------------------------------------------------------------------

def collection_label(collection, lang):
    if collection["name"]:
        return collection["name"]
    return texts.t(lang, {"library": "Alle Fotos", "playlist": "Playlist", "immich_all": "Immich",
                          "immich_album": "Immich-Album"}[collection["kind"]])


def scene_payload(query):
    values = settings()
    have = as_int((query.get("v") or ["-1"])[0], -1)
    lang = values["Language"]
    collections = []
    counts = [0] * len(values["Collections"])
    places_n = [0] * len(values["Collections"])
    for cell in _data["cells"]:
        if cell[2] < len(counts):
            counts[cell[2]] += cell[3]
            places_n[cell[2]] += 1
    for index, collection in enumerate(values["Collections"]):
        collections.append({"name": collection_label(collection, lang), "color": collection["color"],
                            "pin": collection["pin"], "photos": counts[index], "places": places_n[index]})
    payload = {
        "success": True,
        "ver": _data["ver"],
        "settings": {k: values[k] for k in ("Language", "Layout", "Region", "Title", "Cluster", "ShowPhotos",
                                             "PhotoSeconds", "PhotoPause", "PhotoSize", "ThreadWidth", "MapPan",
                                             "ShowLegend")},
        "collections": collections,
        "busy": _data["busy"],
    }
    if have != _data["ver"]:
        payload["cells"] = _data["cells"]
    return payload


def key_row(query):
    idx = as_int((query.get("k") or ["-1"])[0], -1)
    ver = as_int((query.get("v") or ["-1"])[0], -1)
    keys = _data["keys"]
    if ver != _data["ver"] or not 0 <= idx < len(keys):
        return None
    return keys[idx]


def photo_info(query):
    row = key_row(query)
    if row is None:
        return {"success": False}
    key, lat, lon, taken, place = row
    values = settings()
    if key.startswith("i:") and (not taken or not place):
        try:
            immich.configure(values["ServerUrl"], values["ApiKey"])
            info = immich.asset_info(key[2:])
            taken, place = taken or info["taken"], place or info["place"]
        except sources.SourceError:
            pass
    if key.startswith("f:") and not taken:
        taken = geo_cache.taken(key[2:])
    if key.startswith("d:") and not taken:
        taken = geo_cache.taken(key.partition("|")[2])
    if not place and values["PlaceNames"]:
        place = places.name(lat, lon, values["Language"]) or ""
    return {"success": True, "taken": taken, "place": place, "lat": lat, "lon": lon}


def photo_bytes(query):
    row = key_row(query)
    if row is None:
        return None
    key = row[0]
    try:
        if key.startswith("i:"):
            values = settings()
            immich.configure(values["ServerUrl"], values["ApiKey"])
            return immich.photo(key[2:])
        if key.startswith("f:"):
            return dynaframe.photo(key[2:])
        if key.startswith("d:"):
            return dynaframe_photo(key)
    except (sources.SourceError, OSError) as exc:
        log(f"Foto für die Szene: {exc}", "warning")
    return None


DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    status = {}
    for collection in values["Collections"]:
        row = dict(_data["status"].get(collection["id"]) or {})
        if _data["busy"] and row.get("state") != "busy" and not row:
            row = {"state": "wait"}
        status[collection["id"]] = row
    return {
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "status": status,
        "busy": _data["busy"],
        "at": _data["at"],
        "places": len(_data["cells"]),
        "photos": sum(c[3] for c in _data["cells"]),
        "libraryWay": dynaframe.library_way,
        "palette": PALETTE,
        "theme": {"id": theme_id()},
    }


def test_immich():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        info = immich.test()
    except sources.SourceError as exc:
        return {"success": True, "ok": False, "message": str(exc)}
    return {"success": True, "ok": True,
            "message": tr("Verbunden als {user} (Immich {version}).", user=info["user"] or "?",
                          version=info["version"] or "?")}


def list_albums():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, "albums": immich.albums()}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_playlists():
    try:
        rows = [p for p in dynaframe.playlists() if p["name"] not in PLAYLIST_NAMES.values()]
        return {"success": True, "playlists": sorted(rows, key=lambda p: str(p["name"]).lower())}
    except EngineError as exc:
        return {"success": False, "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc)}


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        """Den ganzen Body lesen: ungelesene Bytes würden auf einer offenen
        Verbindung zum Anfang der nächsten Anfrage."""
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(query), cors=True)
                return
            if path == "/api/info":
                self._json(photo_info(query), cors=True)
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            if path == "/api/photo":
                found = photo_bytes(query)
                if found is None:
                    self._json({"success": False}, 404, cors=True)
                else:
                    self._send(found[0], found[1], cache="private, max-age=3600", cors=True)
                return
            if path == "/api/albums":
                self._json(list_albums())
                return
            if path == "/api/playlists":
                self._json(list_playlists())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                for name in SECRETS:
                    # Ein leeres Feld heißt: das alte behalten. Löschen geht mit "-".
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)
                    elif name in body and str(body[name]).strip() == "-":
                        body[name] = ""
                changed = save_settings(body)
                if changed and scan_signature(settings()) != _data["signature"]:
                    rescan_now()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(rescan_now())
                return
            if path == "/api/test":
                self._json(test_immich())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}")

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: rescan_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())

    load_points()
    start_studio()
    plugin.connect_sse()
    plugin.ready()

    try:
        os.nice(5)   # das Einlesen soll die Wiedergabe nicht stören
    except OSError:
        pass
    threading.Thread(target=scan_loop, name=f"{PLUGIN_ID}-scan", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _scan_stop.set()
    _scan_wake.set()
    try:
        geo_cache.save()
    except Exception:
        pass
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
