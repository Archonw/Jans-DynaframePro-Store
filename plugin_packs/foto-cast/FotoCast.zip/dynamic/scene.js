/* Foto Cast - die Szene.
 *
 * Zeigt die Fotos, die gerade vom Handy gekommen sind. Das Plugin holt die
 * Szene nur auf den Bildschirm, solange Fotos zu sehen sein sollen. Sie
 * fragt jede Sekunde, welche das sind; bei mehreren wechseln sie sich ab,
 * ein neu angekommenes Foto kommt sofort nach vorn.
 *
 * Das Plugin erreicht sie direkt über seinen eigenen Port (8095) oder, falls
 * der nicht geht, über den Proxy der Weboberfläche.
 * Mit ?demo=<bild-url> zeigt sie ohne Plugin ein Bild (zum Ausprobieren).
 */
(function () {
  "use strict";

  const PLUGIN_ID = "PhonePhotos";
  const POLL_MS = 1000;
  const CAPTION_MS = 8000;
  const params = new URLSearchParams(location.search);
  const DEMO = params.get("demo");
  const host = location.hostname || "localhost";
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const BASES = [params.get("plugin"),
    `http://${host}:8095/`, `http://${host}:8096/`,
    `${location.protocol}//${host}:8003${advanced}`,
    `${location.protocol}//${host}${advanced}`,
    `${location.origin}${advanced}`].filter(Boolean);

  const el = (id) => document.getElementById(id);
  const ui = { stage: el("stage"), idleTitle: el("idleTitle"), idleText: el("idleText"), idleUrl: el("idleUrl"),
    caption: el("caption"), captionText: el("captionText"), count: el("count") };
  const slides = [el("slideA"), el("slideB")];

  const TEXT = {
    de: { ready: "Bereit", hint: "Schick ein Foto vom Handy: im Teilen-Menü oder auf dieser Seite:",
      from: "Von {who}", unreachable: "Foto Cast antwortet nicht." },
    en: { ready: "Ready", hint: "Send a photo from your phone: from the share menu or on this page:",
      from: "From {who}", unreachable: "Foto Cast is not responding." },
    es: { ready: "Listo", hint: "Envía una foto desde el móvil: desde el menú compartir o en esta página:",
      from: "De {who}", unreachable: "Foto Cast no responde." }
  };
  let lang = "de";
  const tx = (key, values = {}) => ((TEXT[lang] || TEXT.de)[key] || TEXT.de[key] || key)
    .replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");

  let base = null;
  let failures = 0;
  let data = null;
  let seq = null;
  let photos = [];
  let index = 0;
  let front = 0;            // welches der zwei Bilder gerade vorn ist
  let shownId = "";
  let nextAt = 0;
  let captionTimer = null;
  let switching = false;
  let readySent = false;

  // DynaFrame zeigt „Dynamic Content Loading“, bis die Szene sich fertig meldet.
  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 1500);

  async function fetchJson(url) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4000);
    try {
      const response = await fetch(url, { cache: "no-store", signal: controller.signal });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } finally {
      clearTimeout(timer);
    }
  }

  async function poll() {
    const candidates = base ? [base] : BASES;
    for (const candidate of candidates) {
      try {
        const answer = await fetchJson(candidate + "api/scene");
        base = candidate;
        failures = 0;
        return answer;
      } catch (error) {
        /* nächste Adresse */
      }
    }
    base = null;
    failures += 1;
    return null;
  }

  function timeText(iso) {
    if (!iso) return "";
    const date = new Date(iso);
    if (isNaN(date)) return "";
    const locale = { de: "de-DE", en: "en-GB", es: "es-ES" }[lang] || "de-DE";
    return date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" });
  }

  function setCaption(photo) {
    clearTimeout(captionTimer);
    const show = data && data.caption && photo;
    ui.caption.hidden = !show;
    if (!show) return;
    const parts = [];
    if (photo.from) parts.push(tx("from", { who: photo.from }));
    const time = timeText(photo.at);
    if (time) parts.push(time);
    ui.captionText.textContent = parts.join(" · ");
    ui.count.textContent = photos.length > 1 ? `${photos.indexOf(photo) + 1} / ${photos.length}` : "";
    ui.caption.classList.remove("fade");
    captionTimer = setTimeout(() => ui.caption.classList.add("fade"), CAPTION_MS);
  }

  function urlOf(photo) {
    if (DEMO) return DEMO;
    return (base || BASES[0]) + photo.url;
  }

  async function showPhoto(photo) {
    if (!photo || switching) return;
    switching = true;
    const back = slides[1 - front];
    const img = back.querySelector(".photo");
    const src = urlOf(photo);
    try {
      img.src = src;
      if (img.decode) await img.decode();
    } catch (error) {
      /* zeigt, was geladen ist */
    }
    back.querySelector(".bg").style.backgroundImage = `url("${src}")`;
    back.classList.add("on");
    slides[front].classList.remove("on");
    front = 1 - front;
    shownId = photo.id;
    ui.stage.dataset.mode = "photo";
    setCaption(photo);
    nextAt = Date.now() + (data ? data.slideSeconds : 10) * 1000;
    switching = false;
    ready();
  }

  function showIdle() {
    slides.forEach((slide) => slide.classList.remove("on"));
    ui.stage.dataset.mode = "idle";
    ui.caption.hidden = true;
    shownId = "";
    ui.idleTitle.textContent = tx("ready");
    ui.idleText.textContent = data && data.phoneUrl ? tx("hint") : (failures > 3 ? tx("unreachable") : "");
    ui.idleUrl.textContent = data && data.phoneUrl ? data.phoneUrl : "";
  }

  function apply(answer) {
    data = answer;
    lang = answer.lang || "de";
    document.documentElement.lang = lang;
    ui.stage.dataset.fit = answer.fit === "cover" ? "cover" : "contain";
    const list = Array.isArray(answer.photos) ? answer.photos : [];
    if (!answer.showing || !list.length) {
      photos = [];
      seq = answer.seq;
      showIdle();
      return;
    }
    const changed = answer.seq !== seq;
    photos = list;
    seq = answer.seq;
    if (changed) {
      // Ein neues Foto kommt sofort nach vorn; sonst das gezeigte behalten.
      let target = photos.findIndex((p) => p.id === answer.focus);
      if (target < 0) target = Math.max(0, photos.findIndex((p) => p.id === shownId));
      index = target;
      if (photos[index].id !== shownId || ui.stage.dataset.mode !== "photo") showPhoto(photos[index]);
      else setCaption(photos[index]);
    }
  }

  function advance() {
    if (photos.length > 1 && Date.now() >= nextAt && !switching) {
      index = (index + 1) % photos.length;
      showPhoto(photos[index]);
    }
  }

  async function loop() {
    const answer = await poll();
    if (answer) apply(answer);
    if (answer && !answer.showing) ready();
    else if (!photos.length) showIdle();
    advance();
    setTimeout(loop, POLL_MS);
  }

  if (DEMO) {
    data = { caption: true, slideSeconds: 10, fit: params.get("fit") || "contain" };
    ui.stage.dataset.fit = data.fit;
    photos = [{ id: "demo", url: "", from: "Demo", at: new Date().toISOString() }];
    showPhoto(photos[0]);
  } else {
    showIdle();
    loop();
  }
})();
