"use strict";

// Immer "./...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/PhonePhotos/ aus, die Handy-Seite unter :8095/.

const el = (id) => document.getElementById(id);
const PHONE = document.documentElement.hasAttribute("data-phone");
const MAX_EDGE = 3840;
let current = null;
let editing = false;
let recentKey = "";
let lang = "de";

// Texte der Seite auf Deutsch, Englisch und Spanisch. Die Sprache ist eine
// Einstellung des Plugins und gilt auch für die Szene.
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Zeig das Foto oder Video, das du gerade auf dem Handy anschaust, sofort auf dem Rahmen: aus dem Teilen-Menü oder über die Handy-Seite. Nach ein paar Minuten läuft deine Playlist weiter. Jede Änderung hier wird sofort gespeichert.",
    "Show the photo or video you are looking at on your phone on the frame right away: from the share menu or the phone page. After a few minutes your playlist carries on. Every change here is saved immediately.",
    "Muestra en el marco la foto o el vídeo que estás viendo en el móvil al instante: desde el menú compartir o la página del móvil. Después de unos minutos tu lista sigue. Cada cambio aquí se guarda al instante."],
  phoneLede: ["Foto oder Video wählen, und es erscheint auf dem Rahmen.", "Pick a photo or video and it appears on the frame.",
    "Elige una foto o un vídeo y aparece en el marco."],
  language: ["Sprache", "Language", "Idioma"],
  pinTitle: ["Code für diesen Rahmen", "Code for this frame", "Código de este marco"],
  pinHint: ["Auf diesem Rahmen dürfen nur Handys mit dem Code Fotos schicken. Du findest ihn auf der Plugin-Seite am Rahmen.",
    "Only phones with the code may send photos to this frame. You find it on the plugin page of the frame.",
    "Solo los móviles con el código pueden enviar fotos a este marco. Lo encuentras en la página del plugin del marco."],
  pinWrong: ["Der Code stimmt nicht.", "The code is not right.", "El código no es correcto."],
  pairTitle: ["Handy mit dem Rahmen koppeln", "Pair this phone with the frame", "Emparejar este móvil con el marco"],
  pairHint: ["Dieser Rahmen nimmt nur Fotos von gekoppelten Handys an. Tippe auf „Code auf dem Rahmen anzeigen“ und gib den Code ein, der dann groß auf dem Rahmen erscheint. Das ist nur einmal nötig.",
    "This frame only accepts photos from paired phones. Tap “Show code on the frame” and enter the code that then appears large on the frame. You only need to do this once.",
    "Este marco solo acepta fotos de móviles emparejados. Pulsa «Mostrar código en el marco» e introduce el código que aparece en grande en el marco. Solo hace falta una vez."],
  pairHintBoth: ["Oder gib den festen Code ein, falls du ihn kennst.", "Or enter the fixed code if you know it.", "O introduce el código fijo si lo conoces."],
  pairName: ["Name dieses Handys", "Name of this phone", "Nombre de este móvil"],
  pairStart: ["Code auf dem Rahmen anzeigen", "Show code on the frame", "Mostrar código en el marco"],
  pairShown: ["Der Code steht jetzt auf dem Rahmen. Gib ihn hier ein ({sec} Sekunden).", "The code is on the frame now. Enter it here ({sec} seconds).",
    "El código está ahora en el marco. Introdúcelo aquí ({sec} segundos)."],
  pairDone: ["Gekoppelt.", "Paired.", "Emparejado."],
  keyTitle: ["Für Kurzbefehl und Teilen-App", "For the shortcut and share app", "Para el atajo y la app de compartir"],
  keyHint: ["Dieses Handy ist gekoppelt. Für den iPhone-Kurzbefehl oder HTTP Shortcuts auf Android brauchst du diesen Link mit seinem eigenen Schlüssel:",
    "This phone is paired. For the iPhone shortcut or HTTP Shortcuts on Android, use this link with its own key:",
    "Este móvil está emparejado. Para el atajo del iPhone o HTTP Shortcuts en Android usa este enlace con su propia clave:"],
  copy: ["Link kopieren", "Copy link", "Copiar enlace"],
  hideHint: ["Zum vorzeitigen Ausblenden einen zweiten Shortcut mit diesem Link anlegen (GET oder POST, ohne Datei):",
    "To hide early, create a second shortcut with this link (GET or POST, no file):",
    "Para ocultar antes, crea un segundo atajo con este enlace (GET o POST, sin archivo):"],
  hideFrame: ["Zum vorzeitigen Ausblenden: einen zweiten Shortcut ohne Datei, URL <code>{url}</code>",
    "To hide early: a second shortcut without a file, URL <code>{url}</code>",
    "Para ocultar antes: un segundo atajo sin archivo, URL <code>{url}</code>"],
  copied: ["Kopiert.", "Copied.", "Copiado."],
  pairing: ["Handys erst koppeln: der Rahmen zeigt dafür einen Code", "Pair phones first: the frame shows a code for it",
    "Emparejar los móviles primero: el marco muestra un código"],
  devicesTitle: ["Gekoppelte Handys:", "Paired phones:", "Móviles emparejados:"],
  devicesNone: ["Noch keins. Kopple ein Handy über die Handy-Seite.", "None yet. Pair a phone from the phone page.",
    "Ninguno todavía. Empareja un móvil desde la página del móvil."],
  deviceLine: ["gekoppelt {at}, zuletzt {last}", "paired {at}, last {last}", "emparejado {at}, último {last}"],
  unpair: ["Entfernen", "Remove", "Quitar"],
  pairStepsNote: ["Mit „Handys erst koppeln“: Öffne zuerst die Handy-Seite aus Schritt 1 auf dem Handy und kopple es. Danach zeigt sie den Link mit dem Schlüssel des Handys, den nimmst du hier statt der Adresse unten.",
    "With “Pair phones first”: open the phone page from step 1 on the phone and pair it first. It then shows the link with the phone's key; use that instead of the address below.",
    "Con «Emparejar los móviles primero»: abre primero la página del móvil del paso 1 en el móvil y empareja. Después muestra el enlace con la clave del móvil; usa ese en lugar de la dirección de abajo."],
  ok: ["OK", "OK", "OK"],
  sendTitle: ["Foto oder Video senden", "Send a photo or video", "Enviar una foto o un vídeo"],
  hide: ["Ausblenden", "Hide", "Ocultar"],
  pick: ["Fotos oder Videos auswählen", "Choose photos or videos", "Elegir fotos o vídeos"],
  pickFrame: ["Fotos oder Videos auswählen oder hierher ziehen", "Choose photos or videos or drop them here",
    "Elige fotos o vídeos o arrástralos aquí"],
  uploading: ["Sende {n} von {total}: {pct} %", "Sending {n} of {total}: {pct} %", "Enviando {n} de {total}: {pct} %"],
  converting: ["wird umgewandelt {pct} %", "converting {pct} %", "convirtiendo {pct} %"],
  convertFailed: ["Umwandeln fehlgeschlagen", "Converting failed", "La conversión falló"],
  keepVideos: ["So viele Videos aufheben", "Keep this many videos", "Guardar tantos vídeos"],
  videoNative: ["Videos spielt DynaFrame selbst ab, mit Ton, und kehrt danach zur Playlist zurück.",
    "Videos are played by DynaFrame itself, with sound, and it returns to the playlist afterwards.",
    "DynaFrame reproduce los vídeos él mismo, con sonido, y después vuelve a la lista."],
  videoConvert: ["Seltene Formate wandelt ffmpeg vorher in H.264 um.", "Rare formats are converted to H.264 with ffmpeg first.",
    "Los formatos poco comunes se convierten antes a H.264 con ffmpeg."],
  senderName: ["Dein Name (erscheint klein unter dem Foto, optional)", "Your name (shown small below the photo, optional)",
    "Tu nombre (aparece pequeño bajo la foto, opcional)"],
  preparing: ["Bereite Foto {n} von {total} vor …", "Preparing photo {n} of {total} …", "Preparando foto {n} de {total} …"],
  sending: ["Sende Foto {n} von {total} …", "Sending photo {n} of {total} …", "Enviando foto {n} de {total} …"],
  sentOne: ["Auf dem Rahmen.", "On the frame.", "En el marco."],
  sentMany: ["{n} Fotos auf dem Rahmen.", "{n} photos on the frame.", "{n} fotos en el marco."],
  failed: ["Nicht gesendet: {error}", "Not sent: {error}", "No enviado: {error}"],
  noConnection: ["Der Rahmen antwortet nicht. Bist du im WLAN zu Hause?", "The frame is not responding. Are you on your home Wi-Fi?",
    "El marco no responde. ¿Estás en la wifi de casa?"],
  nowShowing: ["Gerade auf dem Rahmen, noch {time}.", "On the frame now, {time} left.", "Ahora en el marco, quedan {time}."],
  waiting: ["Wartet auf den Bildschirm …", "Waiting for the screen …", "Esperando la pantalla …"],
  recentTitle: ["Zuletzt gesendet", "Recently sent", "Enviadas recientemente"],
  recentHint: ["Antippen zeigt es noch einmal.", "Tap to show it again.", "Pulsa para mostrarla otra vez."],
  recentEmpty: ["Noch keine Fotos.", "No photos yet.", "Aún no hay fotos."],
  deleteAsk: ["Dieses Foto vom Rahmen löschen?", "Delete this photo from the frame?", "¿Borrar esta foto del marco?"],
  pageTitle: ["Die Handy-Seite (iPhone und Android)", "The phone page (iPhone and Android)", "La página del móvil (iPhone y Android)"],
  pageHint: ["Im WLAN mit der Kamera des Handys den QR-Code scannen, dann über das Teilen-Menü des Browsers „Zum Home-Bildschirm“ wählen. Ab dann: Symbol antippen, Fotos wählen, fertig.",
    "On your Wi-Fi scan the QR code with the phone's camera, then choose “Add to Home Screen” in the browser's share menu. From then on: tap the icon, choose photos, done.",
    "En la wifi escanea el código QR con la cámara del móvil y elige «Añadir a pantalla de inicio» en el menú compartir del navegador. A partir de ahí: toca el icono, elige fotos y listo."],
  pageNote: ["Funktioniert nur im WLAN zu Hause. Steht hier keine Adresse, ist Port 8095 auf dem Rahmen belegt.",
    "Works only on your home Wi-Fi. If there is no address here, port 8095 is taken on the frame.",
    "Solo funciona en la wifi de casa. Si aquí no hay dirección, el puerto 8095 está ocupado en el marco."],
  iosTitle: ["iPhone: „Auf DynaFrame“ im Teilen-Menü der Fotos-App", "iPhone: “On DynaFrame” in the share menu of the Photos app",
    "iPhone: «En DynaFrame» en el menú compartir de Fotos"],
  iosIntro: ["Einmal einen Kurzbefehl anlegen (App „Kurzbefehle“, ist auf jedem iPhone):",
    "Create a shortcut once (the Shortcuts app is on every iPhone):",
    "Crea un atajo una vez (la app Atajos está en todos los iPhone):"],
  iosSteps: [[
    "App <b>Kurzbefehle</b> öffnen, oben rechts auf <b>+</b> tippen und oben den Namen <b>Auf DynaFrame</b> eingeben.",
    "Unten auf <b>ⓘ</b> tippen, <b>Im Share-Sheet anzeigen</b> einschalten, <b>Fertig</b>. Oben in „Empfange … aus Share-Sheet“ auf die Eingabearten tippen und nur <b>Bilder</b> und <b>Medien</b> angehakt lassen.",
    "Aktion <b>Wiederholen mit jedem Objekt</b> hinzufügen (in der Suche „Wiederholen“). Sie arbeitet mit der <b>Kurzbefehleingabe</b>.",
    "In die Wiederholung die Aktion <b>Inhalte von URL abrufen</b> ziehen, mit dieser URL: <code>{url}</code>",
    "Dort auf den Pfeil <b>›</b> tippen: Methode <b>POST</b>, Haupttext anfordern <b>Datei</b>, als Datei <b>Wiederholungsobjekt</b> wählen.",
    "Fertig. Ab jetzt: Foto oder Video in der Fotos-App (oder in WhatsApp) öffnen, <b>Teilen</b>, unten <b>Auf DynaFrame</b>."
  ], [
    "Open the <b>Shortcuts</b> app, tap <b>+</b> at the top right and enter the name <b>On DynaFrame</b> at the top.",
    "Tap <b>ⓘ</b> at the bottom, switch on <b>Show in Share Sheet</b>, <b>Done</b>. At the top in “Receive … from Share Sheet” tap the input types and leave only <b>Images</b> and <b>Media</b> ticked.",
    "Add the action <b>Repeat with Each</b> (search for “Repeat”). It works on the <b>Shortcut Input</b>.",
    "Drag <b>Get Contents of URL</b> into the repeat, with this URL: <code>{url}</code>",
    "Tap its arrow <b>›</b>: method <b>POST</b>, request body <b>File</b>, and choose <b>Repeat Item</b> as the file.",
    "Done. From now on: open a photo or video in Photos (or in WhatsApp), tap <b>Share</b>, then <b>On DynaFrame</b> at the bottom."
  ], [
    "Abre la app <b>Atajos</b>, pulsa <b>+</b> arriba a la derecha y escribe arriba el nombre <b>En DynaFrame</b>.",
    "Pulsa <b>ⓘ</b> abajo, activa <b>Mostrar en hoja para compartir</b>, <b>OK</b>. Arriba en «Recibir … de la hoja para compartir» pulsa los tipos de entrada y deja marcadas solo <b>Imágenes</b> y <b>Contenido multimedia</b>.",
    "Añade la acción <b>Repetir con cada</b> (busca «Repetir»). Trabaja con la <b>Entrada del atajo</b>.",
    "Arrastra dentro de la repetición <b>Obtener contenido de URL</b>, con esta URL: <code>{url}</code>",
    "Pulsa su flecha <b>›</b>: método <b>POST</b>, cuerpo de la solicitud <b>Archivo</b> y elige <b>Elemento repetido</b> como archivo.",
    "Listo. A partir de ahora: abre una foto o un vídeo en Fotos (o en WhatsApp), pulsa <b>Compartir</b> y abajo <b>En DynaFrame</b>."
  ]],
  iosNote: ["Beim ersten Mal fragt das iPhone, ob der Kurzbefehl den Rahmen erreichen darf: „Immer erlauben“. Mehrere Fotos und Videos auf einmal gehen auch. Wer den Kurzbefehl schon mit „Bild konvertieren“ angelegt hat: für Videos diese Aktion löschen und als Datei „Wiederholungsobjekt“ wählen.",
    "The first time, the iPhone asks whether the shortcut may reach the frame: “Always Allow”. Several photos and videos at once work too. If your shortcut still has “Convert Image”: delete that action for videos and choose “Repeat Item” as the file.",
    "La primera vez el iPhone pregunta si el atajo puede acceder al marco: «Permitir siempre». También funcionan varias fotos y vídeos a la vez. Si tu atajo aún tiene «Convertir imagen»: bórrala para los vídeos y elige «Elemento repetido» como archivo."],
  androidTitle: ["Android: im Teilen-Menü der Galerie", "Android: in the gallery's share menu", "Android: en el menú compartir de la galería"],
  androidIntro: ["Android-Browser können sich nicht ins Teilen-Menü eintragen. Dafür gibt es die kostenlose App „HTTP Shortcuts“ (Google Play oder F-Droid):",
    "Android browsers cannot add themselves to the share menu. The free app “HTTP Shortcuts” (Google Play or F-Droid) does it:",
    "Los navegadores de Android no pueden añadirse al menú compartir. Lo hace la app gratuita «HTTP Shortcuts» (Google Play o F-Droid):"],
  androidSteps: [[
    "<b>HTTP Shortcuts</b> installieren und öffnen, auf <b>+</b> tippen, <b>Normaler Shortcut</b>, Name <b>Auf DynaFrame</b>.",
    "Unter den grundlegenden Anfrage-Einstellungen: Methode <b>POST</b>, URL <code>{url}</code>",
    "Unter <b>Anfrage-Body</b>: Typ <b>Datei</b> wählen (für mehrere Fotos auf einmal: <b>Formular-Daten</b> mit einem Parameter vom Typ Datei, mehrere Dateien erlaubt).",
    "Unter <b>Antwort-Verarbeitung</b>: bei <b>Bei Erfolg</b> „Toast“ wählen, sonst öffnet sich jedes Mal ein Fenster mit der Antwort.",
    "Speichern. Ab jetzt: Foto oder Video in der Galerie (oder in WhatsApp) öffnen, <b>Teilen</b>, <b>HTTP Shortcuts</b>, <b>Auf DynaFrame</b>."
  ], [
    "Install and open <b>HTTP Shortcuts</b>, tap <b>+</b>, <b>Regular Shortcut</b>, name <b>On DynaFrame</b>.",
    "In the basic request settings: method <b>POST</b>, URL <code>{url}</code>",
    "In <b>Request Body</b>: choose type <b>File</b> (for several photos at once: <b>Form data</b> with one parameter of type file, multiple files allowed).",
    "In <b>Response Handling</b>: set <b>On Success</b> to “Toast”, otherwise a window with the answer opens every time.",
    "Save. From now on: open a photo or video in the gallery (or in WhatsApp), <b>Share</b>, <b>HTTP Shortcuts</b>, <b>On DynaFrame</b>."
  ], [
    "Instala y abre <b>HTTP Shortcuts</b>, pulsa <b>+</b>, <b>Atajo normal</b>, nombre <b>En DynaFrame</b>.",
    "En los ajustes básicos de la solicitud: método <b>POST</b>, URL <code>{url}</code>",
    "En <b>Cuerpo de la solicitud</b>: elige el tipo <b>Archivo</b> (para varias fotos a la vez: <b>Datos de formulario</b> con un parámetro de tipo archivo, varios archivos permitidos).",
    "En <b>Gestión de la respuesta</b>: en <b>Si tiene éxito</b> elige «Toast»; si no, cada vez se abre una ventana con la respuesta.",
    "Guarda. A partir de ahora: abre una foto o un vídeo en la galería (o en WhatsApp), <b>Compartir</b>, <b>HTTP Shortcuts</b>, <b>En DynaFrame</b>."
  ]],
  androidNote: ["Ohne Zusatz-App: die Handy-Seite aus Schritt 1 auf den Home-Bildschirm legen. Die Bezeichnungen in den Apps können je nach Version leicht abweichen.",
    "Without an extra app: put the phone page from step 1 on the home screen. Labels in the apps may differ slightly between versions.",
    "Sin app adicional: pon la página del móvil del paso 1 en la pantalla de inicio. Los nombres en las apps pueden variar un poco según la versión."],
  settingsTitle: ["Einstellungen", "Settings", "Ajustes"],
  showMinutes: ["So lange auf dem Rahmen (Minuten)", "Time on the frame (minutes)", "Tiempo en el marco (minutos)"],
  slideSeconds: ["Bei mehreren Fotos: jedes so lange (Sekunden)", "With several photos: each for (seconds)", "Con varias fotos: cada una durante (segundos)"],
  fit: ["Darstellung", "Display", "Presentación"],
  fitContain: ["Ganzes Foto, Hintergrund unscharf", "Whole photo, blurred background", "Foto entera, fondo difuminado"],
  fitCover: ["Bildschirm füllen (Ränder abgeschnitten)", "Fill the screen (edges cropped)", "Llenar la pantalla (bordes recortados)"],
  keepPhotos: ["So viele Fotos aufheben", "Keep this many photos", "Guardar tantas fotos"],
  pin: ["Fester Code (optional; ohne Koppeln und ohne Code darf jedes Handy im WLAN senden)",
    "Fixed code (optional; without pairing and without a code every phone on the Wi-Fi may send)",
    "Código fijo (opcional; sin emparejar y sin código cualquier móvil de la wifi puede enviar)"],
  caption: ["Absender und Uhrzeit klein unten zeigen", "Show sender and time small at the bottom", "Mostrar remitente y hora abajo en pequeño"],
  wake: ["Ausgeschalteten Bildschirm für ein Foto oder Video einschalten", "Switch an off screen on for a photo or video",
    "Encender la pantalla apagada para una foto o un vídeo"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noPillow: ["Pillow fehlt auf dem Rahmen: Fotos werden unverkleinert gezeigt, HEIC geht nicht.",
    "Pillow is missing on the frame: photos are shown at full size, HEIC does not work.",
    "Falta Pillow en el marco: las fotos se muestran sin reducir y HEIC no funciona."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or wishes?", "¿Problemas, preguntas o deseos?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre un issue en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", ", with plugin name and version.", ", con el nombre y la versión del plugin."],
};

function t(key, values = {}) {
  const row = I18N[key];
  const index = { de: 0, en: 1, es: 2 }[lang] ?? 0;
  const text = row ? (row[index] ?? row[0]) : key;
  if (Array.isArray(text)) return text.map((line) => fill(line, values));
  return fill(text, values);
}

function fill(text, values) {
  return String(text).replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");
}

function applyLanguage() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach((node) => {
    const value = t(node.dataset.i18n);
    if (typeof value === "string") node.textContent = value;
  });
  if (!PHONE) el("pickLabel").querySelector(".pick-text").textContent = t("pickFrame");
  renderSteps();
}

// ---------------------------------------------------------------------------
// Code (nur auf der Handy-Seite, wenn einer eingestellt ist)
// ---------------------------------------------------------------------------

function storedPin() {
  try { return localStorage.getItem("phonePhotosPin") || ""; } catch (e) { return ""; }
}

function rememberPin(value) {
  try { localStorage.setItem("phonePhotosPin", value); } catch (e) { /* egal */ }
}

function withPin(url) {
  const pin = PHONE ? storedPin() : "";
  return pin ? url + (url.includes("?") ? "&" : "?") + "pin=" + encodeURIComponent(pin) : url;
}

async function call(path, init = {}) {
  const headers = Object.assign({}, init.headers || {});
  if (PHONE && storedPin()) headers["X-Pin"] = storedPin();
  const response = await fetch("./" + path, Object.assign({ cache: "no-store" }, init, { headers }));
  let data = {};
  try { data = await response.json(); } catch (e) { data = {}; }
  if (response.status === 403 && data.needPin) {
    showPinCard(true, data);
    throw new Error(data.error || t("pinWrong"));
  }
  return data;
}

let pairInfo = { pairing: false, hasPin: true };
let pairId = "";

function showPinCard(show, info) {
  if (info) pairInfo = { pairing: !!info.pairing, hasPin: !!info.hasPin };
  el("pinCard").hidden = !show;
  el("sendCard").hidden = show;
  if (!show) return;
  const pairing = pairInfo.pairing;
  el("pinCard").querySelector("h2").textContent = pairing ? t("pairTitle") : t("pinTitle");
  el("pinHint").textContent = pairing ? t("pairHint") + (pairInfo.hasPin ? " " + t("pairHintBoth") : "") : t("pinHint");
  el("pairStart").hidden = !pairing;
  el("pairNameField").hidden = !pairing;
  if (pairing && !el("pairName").value) el("pairName").value = el("senderName").value || guessDevice();
}

function guessDevice() {
  const agent = navigator.userAgent;
  if (/iPhone/.test(agent)) return "iPhone";
  if (/iPad/.test(agent)) return "iPad";
  const model = agent.match(/Android[^;]*;\s*([^;)]+?)(?:\s+Build|\))/);
  return model ? model[1].trim().slice(0, 40) : "Android";
}

async function postJson(path, body) {
  const response = await fetch("./" + path, { method: "POST", cache: "no-store", body: JSON.stringify(body) });
  try { return await response.json(); } catch (e) { return {}; }
}

el("pairStart").addEventListener("click", async () => {
  el("pinNote").textContent = "";
  const answer = await postJson("api/pair/start", { name: el("pairName").value.trim() }).catch(() => ({}));
  if (!answer.success) {
    el("pinNote").textContent = answer.error || t("noConnection");
    return;
  }
  pairId = answer.id;
  el("pinNote").className = "status ok";
  el("pinNote").textContent = t("pairShown", { sec: answer.seconds || 120 });
  el("pinInput").value = "";
  el("pinInput").focus();
});

el("pinForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const value = el("pinInput").value.trim();
  el("pinNote").className = "status bad";
  el("pinNote").textContent = "";
  if (pairId && /^\d{4}$/.test(value)) {
    const answer = await postJson("api/pair/finish", { id: pairId, code: value }).catch(() => ({}));
    if (!answer.success) {
      el("pinNote").textContent = answer.error || t("pinWrong");
      if (answer.error && !/stimmt nicht|not right|no es correcto/.test(answer.error)) pairId = "";
      return;
    }
    pairId = "";
    rememberPin(answer.key);
    try { localStorage.setItem("phonePhotosName", answer.name || ""); } catch (e) { /* egal */ }
    el("pinInput").value = "";
    await refresh();
    el("sendNote").className = "status ok";
    el("sendNote").textContent = t("pairDone");
    return;
  }
  rememberPin(value);
  try {
    await refresh();
    if (!el("pinCard").hidden) el("pinNote").textContent = t("pinWrong");
  } catch (e) {
    el("pinNote").textContent = t("pinWrong");
  }
});

// Nach dem Koppeln: der Link mit dem eigenen Schlüssel für Kurzbefehle.
function renderKeyCard(state) {
  const card = el("keyCard");
  const key = storedPin();
  card.hidden = !(PHONE && state.pairing && key);
  if (card.hidden) return;
  const base = state.phoneUrl || (location.origin + "/");
  let stored = "";
  try { stored = localStorage.getItem("phonePhotosName") || ""; } catch (e) { stored = ""; }
  const name = encodeURIComponent(el("senderName").value.trim() || stored || guessDevice());
  el("keyUrl").textContent = `${base}upload?from=${name}&format=text&pin=${encodeURIComponent(key)}`;
  el("hideUrl").textContent = `${base}hide?pin=${encodeURIComponent(key)}`;
}

el("keyCopy").addEventListener("click", async () => {
  const text = el("keyUrl").textContent;
  let ok = false;
  try { await navigator.clipboard.writeText(text); ok = true; } catch (e) {
    const range = document.createRange();
    range.selectNodeContents(el("keyUrl"));
    const selection = getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
    try { ok = document.execCommand("copy"); } catch (_) { ok = false; }
  }
  el("keyNote").textContent = ok ? t("copied") : "";
});

function shortDate(iso) {
  const date = iso ? new Date(iso) : null;
  return date && !isNaN(date) ? date.toLocaleString(lang, { day: "numeric", month: "numeric", hour: "2-digit", minute: "2-digit" }) : "";
}

let devicesKey = "";
function renderDevices(state) {
  el("devicesBox").hidden = !state.pairing;
  document.querySelectorAll("[data-pair-only]").forEach((node) => { node.hidden = !state.pairing; });
  const list = state.devices || [];
  const key = lang + JSON.stringify(list);
  if (key === devicesKey) return;
  devicesKey = key;
  const box = el("devices");
  box.innerHTML = "";
  if (!list.length) {
    const item = document.createElement("li");
    item.className = "muted";
    item.textContent = t("devicesNone");
    box.appendChild(item);
    return;
  }
  list.forEach((device) => {
    const item = document.createElement("li");
    const label = document.createElement("span");
    label.innerHTML = `<b>${escapeHtml(device.name)}</b> <span class="muted small">${escapeHtml(t("deviceLine", { at: shortDate(device.at), last: shortDate(device.last) }))}</span>`;
    const button = document.createElement("button");
    button.type = "button";
    button.className = "secondary small";
    button.textContent = t("unpair");
    button.addEventListener("click", async () => {
      await call("api/control", { method: "POST", body: JSON.stringify({ action: "unpair", id: device.id }) }).catch(() => {});
      devicesKey = "";
      refresh();
    });
    item.append(label, button);
    box.appendChild(item);
  });
}

// ---------------------------------------------------------------------------
// Fotos senden
// ---------------------------------------------------------------------------

// Auf dem Handy verkleinern: spart WLAN-Zeit und macht aus iPhone-HEIC ein JPEG.
async function shrink(file) {
  try {
    let bitmap;
    try {
      bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
    } catch (e) {
      bitmap = await createImageBitmap(file);
    }
    const scale = Math.min(1, MAX_EDGE / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bitmap.width * scale);
    canvas.height = Math.round(bitmap.height * scale);
    canvas.getContext("2d").drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    if (bitmap.close) bitmap.close();
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.9));
    if (blob && blob.size > 1000) return blob;
  } catch (e) {
    /* dann das Original; der Rahmen kümmert sich */
  }
  return file;
}

function senderName() {
  if (!PHONE) return "";
  const value = el("senderName").value.trim();
  try { localStorage.setItem("phonePhotosName", value); } catch (e) { /* egal */ }
  return value;
}

function isVideoFile(file) {
  return (file.type || "").startsWith("video/") || /\.(mov|mp4|m4v|webm|3gp)$/i.test(file.name || "");
}

// Mit XMLHttpRequest, weil fetch keinen Upload-Fortschritt kennt (Videos sind groß).
function uploadFile(path, body, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "./" + path);
    xhr.setRequestHeader("Content-Type", body.type || "application/octet-stream");
    if (PHONE && storedPin()) xhr.setRequestHeader("X-Pin", storedPin());
    xhr.upload.onprogress = (event) => { if (event.lengthComputable) onProgress(event.loaded / event.total); };
    xhr.onload = () => {
      let data = {};
      try { data = JSON.parse(xhr.responseText); } catch (e) { data = {}; }
      if (xhr.status === 403 && data.needPin) {
        showPinCard(true, data);
        reject(new Error(t("pinWrong")));
        return;
      }
      resolve(data);
    };
    xhr.onerror = () => reject(new Error(t("noConnection")));
    xhr.send(body);
  });
}

async function sendFiles(files) {
  const list = Array.from(files || []).filter((f) => !f.type || f.type.startsWith("image/") || isVideoFile(f)
    || /\.(heic|heif)$/i.test(f.name));
  if (!list.length) return;
  const note = el("sendNote");
  const pick = el("pickLabel");
  pick.classList.add("busy");
  note.className = "status busy";
  let sent = 0;
  let lastError = "";
  let lastMessage = "";
  const name = senderName();
  for (let i = 0; i < list.length; i += 1) {
    const video = isVideoFile(list[i]);
    let body = list[i];
    if (!video) {
      note.textContent = t("preparing", { n: i + 1, total: list.length });
      body = await shrink(list[i]);
    }
    note.textContent = t("sending", { n: i + 1, total: list.length });
    try {
      const query = name ? "?from=" + encodeURIComponent(name) : "";
      const answer = await uploadFile("upload" + query, body, (part) => {
        note.textContent = t("uploading", { n: i + 1, total: list.length, pct: Math.round(part * 100) });
      });
      if (answer.success) {
        sent += 1;
        lastMessage = answer.message || "";
      } else {
        lastError = answer.error || "?";
      }
    } catch (e) {
      lastError = e.message || t("noConnection");
    }
  }
  pick.classList.remove("busy");
  el("fileInput").value = "";
  if (lastError && !sent) {
    note.className = "status bad";
    note.textContent = t("failed", { error: lastError });
  } else {
    note.className = "status ok";
    note.textContent = sent === 1 ? (lastMessage || t("sentOne")) : t("sentMany", { n: sent });
    if (lastError) note.textContent += " " + t("failed", { error: lastError });
  }
  refresh();
}

el("fileInput").addEventListener("change", (event) => sendFiles(event.target.files));

const pickLabel = el("pickLabel");
["dragenter", "dragover"].forEach((type) => pickLabel.addEventListener(type, (event) => {
  event.preventDefault();
  pickLabel.classList.add("drag");
}));
["dragleave", "drop"].forEach((type) => pickLabel.addEventListener(type, () => pickLabel.classList.remove("drag")));
pickLabel.addEventListener("drop", (event) => {
  event.preventDefault();
  sendFiles(event.dataTransfer.files);
});

el("hideButton").addEventListener("click", async () => {
  await call("api/control", { method: "POST", body: JSON.stringify({ action: "hide" }) }).catch(() => {});
  refresh();
});

// ---------------------------------------------------------------------------
// Zuletzt gesendet
// ---------------------------------------------------------------------------

function renderRecent(state) {
  const showing = new Set(state.showing ? state.ids : []);
  const key = JSON.stringify([state.recent.map((p) => [p.id, p.state, p.progress, p.thumb, p.error]), [...showing], lang]);
  if (key === recentKey) return;
  recentKey = key;
  const box = el("recent");
  box.textContent = "";
  el("recentEmpty").hidden = state.recent.length > 0;
  state.recent.forEach((photo) => {
    const tile = document.createElement("div");
    tile.className = "tile" + (showing.has(photo.id) ? " on" : "");
    tile.setAttribute("role", "button");
    tile.tabIndex = 0;
    if (photo.thumb) {
      const img = document.createElement("img");
      img.loading = "lazy";
      img.alt = "";
      img.src = withPin("./" + photo.thumb);
      tile.appendChild(img);
    }
    if (photo.kind === "video") {
      tile.classList.add("video");
      const badge = document.createElement("span");
      badge.className = "badge";
      const seconds = Math.round(photo.duration || 0);
      badge.textContent = "▶" + (seconds ? " " + minutesText(seconds) : "");
      tile.appendChild(badge);
      if (photo.state === "converting" || photo.state === "failed" || photo.error) {
        const over = document.createElement("span");
        over.className = "over" + (photo.state === "converting" ? "" : " bad");
        over.textContent = photo.state === "converting" ? t("converting", { pct: photo.progress || 0 })
          : (photo.state === "failed" ? t("convertFailed") : "!");
        if (photo.error) over.title = photo.error;
        tile.appendChild(over);
      }
    }
    const who = document.createElement("span");
    who.className = "who";
    const at = photo.at ? new Date(photo.at) : null;
    who.textContent = [photo.from, at && !isNaN(at) ? at.toLocaleString(lang, { day: "numeric", month: "numeric", hour: "2-digit", minute: "2-digit" }) : ""]
      .filter(Boolean).join(" · ");
    tile.appendChild(who);
    tile.addEventListener("click", async (event) => {
      if (event.target.closest(".del")) return;
      await call("api/control", { method: "POST", body: JSON.stringify({ action: "show", id: photo.id }) }).catch(() => {});
      refresh();
    });
    if (!PHONE) {
      const del = document.createElement("button");
      del.type = "button";
      del.className = "del";
      del.textContent = "×";
      del.setAttribute("aria-label", t("deleteAsk"));
      del.addEventListener("click", async () => {
        if (!confirm(t("deleteAsk"))) return;
        await call("api/control", { method: "POST", body: JSON.stringify({ action: "delete", id: photo.id }) }).catch(() => {});
        refresh();
      });
      tile.appendChild(del);
    }
    box.appendChild(tile);
  });
}

// ---------------------------------------------------------------------------
// Einrichten (nur auf dem Rahmen)
// ---------------------------------------------------------------------------

function uploadUrl(from) {
  const base = current && current.phoneUrl ? current.phoneUrl : "http://<rahmen>:8095/";
  const pin = current && current.settings && current.settings.Pin;
  return `${base}upload?from=${from}&format=text` + (pin ? `&pin=${encodeURIComponent(pin)}` : "");
}

function escapeHtml(text) {
  return String(text).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;" }[c]));
}

let stepsKey = "";
function renderSteps() {
  if (PHONE) return;
  const key = lang + uploadUrl("");
  if (key === stepsKey) return;
  stepsKey = key;
  const fillList = (id, key, url) => {
    el(id).innerHTML = t(key, { url: escapeHtml(url) }).map((line) => `<li>${line}</li>`).join("");
  };
  fillList("iosSteps", "iosSteps", uploadUrl("iPhone"));
  fillList("androidSteps", "androidSteps", uploadUrl("Android"));
  const base = current && current.phoneUrl ? current.phoneUrl : "http://<rahmen>:8095/";
  const pin = current && current.settings && current.settings.Pin;
  const hide = `${base}hide` + (pin ? `?pin=${encodeURIComponent(pin)}` : "");
  ["iosHide", "androidHide"].forEach((id) => { el(id).innerHTML = t("hideFrame", { url: escapeHtml(hide) }); });
}

let qrFor = "";
function renderPhoneLink(url) {
  const link = el("phoneUrl");
  link.textContent = url || "—";
  link.href = url || "#";
  if (!url || url === qrFor || typeof qrcode !== "function") return;
  qrFor = url;
  const code = qrcode(0, "M");
  code.addData(url);
  code.make();
  const canvas = el("qr");
  const count = code.getModuleCount();
  const size = 200;
  const cell = Math.floor(size / count);
  const offset = Math.floor((size - cell * count) / 2);
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, size, size);
  ctx.fillStyle = "#000";
  for (let r = 0; r < count; r += 1) {
    for (let c = 0; c < count; c += 1) {
      if (code.isDark(r, c)) ctx.fillRect(offset + c * cell, offset + r * cell, cell, cell);
    }
  }
}

const SETTING_IDS = ["Language", "ShowMinutes", "SlideSeconds", "Fit", "KeepPhotos", "KeepVideos", "Pin", "Caption",
  "WakeScreen", "Pairing"];

function fillSettings(values) {
  if (editing) return;
  SETTING_IDS.forEach((id) => {
    const input = el(id);
    if (!input || document.activeElement === input) return;
    if (input.type === "checkbox") input.checked = !!values[id];
    else input.value = values[id] ?? "";
  });
}

async function saveSetting(id) {
  const input = el(id);
  const value = input.type === "checkbox" ? input.checked : input.value;
  const note = el("settingsNote");
  try {
    await call("api/settings", { method: "POST", body: JSON.stringify({ [id]: value }) });
    note.className = "status ok";
    note.textContent = t("saved");
  } catch (e) {
    note.className = "status bad";
    note.textContent = e.message;
  }
  editing = false;
  await refresh();
}

if (!PHONE) {
  SETTING_IDS.forEach((id) => {
    const input = el(id);
    input.addEventListener("focus", () => { editing = true; });
    input.addEventListener("change", () => saveSetting(id));
    input.addEventListener("blur", () => { editing = false; });
  });
} else {
  try { el("senderName").value = localStorage.getItem("phonePhotosName") || ""; } catch (e) { /* egal */ }
}

// ---------------------------------------------------------------------------
// Zustand
// ---------------------------------------------------------------------------

function minutesText(seconds) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

async function refresh() {
  let state;
  try {
    const response = await fetch(withPin("./api/state"), { cache: "no-store",
      headers: PHONE && storedPin() ? { "X-Pin": storedPin() } : {} });
    state = await response.json();
  } catch (e) {
    el("nowNote").className = "status bad";
    el("nowNote").textContent = t("noConnection");
    return;
  }
  if (state.language && state.language !== lang) {
    lang = state.language;
    applyLanguage();
  }
  if (!state.success) {
    if (state.needPin) showPinCard(true, state);
    return;
  }
  showPinCard(false);
  renderKeyCard(state);
  current = state;
  el("version").textContent = state.version ? "v" + state.version : "";
  el("hideButton").hidden = !state.showing;
  const now = el("nowNote");
  if (state.showing) {
    now.className = "status ok";
    now.textContent = state.onScreen ? t("nowShowing", { time: minutesText(state.remaining) }) : t("waiting");
  } else {
    now.textContent = "";
  }
  renderRecent(state);
  const permission = el("permissionNote");
  permission.hidden = !state.permission;
  permission.textContent = state.permission || "";
  const error = el("errorNote");
  const problem = state.note || state.lastError || (!PHONE && state.pillow === false ? t("noPillow") : "");
  error.hidden = !problem;
  error.textContent = problem;
  if (!PHONE) {
    fillSettings(state.settings || {});
    el("videoNote").textContent = t("videoNative") + (state.ffmpeg ? " " + t("videoConvert") : "");
    renderPhoneLink(state.phoneUrl);
    renderDevices(state);
    renderSteps();
  }
}

applyLanguage();
refresh();
setInterval(refresh, PHONE ? 3000 : 2000);
