# Photo Scanner

Your photos, scanned like in a science fiction film. Each photo appears with a sweeping scan line, a focus lock on its most detailed spot, and data panels that type themselves in:

- **Image**: resolution, megapixels, aspect ratio, format, file size, scan ID (a fingerprint of the picture)
- **Capture**: date, time, weekday and how long ago
- **Optics**: camera, lens, focal length, aperture, shutter, ISO, exposure value, flash
- **Geo**: GPS position (exact, rounded or hidden), altitude, place name and a small rotating globe with the spot
- **Spectrum**: the six main colours with their share, RGB histogram, colour temperature in kelvin
- **Analysis**: brightness, contrast, saturation, colourfulness, sharpness, detail, clipped highlights and shadows
- **Archive**: stars, tags and, with Immich, the people in the photo

At the sides run **live readings of the frame**: CPU, memory, network traffic (it spikes a lot), temperature, uptime, disk and the size of your library (photos, videos, gigabytes, located photos, cameras).

Everything is read from the photo file, DynaFrame's media database or Immich. Place names for GPS positions without one come from OpenStreetMap (can be switched off; allow nominatim.openstreetmap.org in Pi-hole). Accent colour cyan, amber, green, magenta, white or taken from the photo.

Photos come from a DynaFrame playlist, the whole DynaFrame library (WebDAV too, plus extra folders) or an Immich server, with the same filters as Photo Mosaic.

Inspired by an idea from Geektoolkit.

Settings: Plugins > Photo Scanner > Open Photo Scanner. English, German or Spanish.

Problems or ideas: https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=%5BPhoto%20Scanner%5D%20
