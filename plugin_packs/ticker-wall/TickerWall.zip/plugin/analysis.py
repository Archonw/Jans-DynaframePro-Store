"""Ticker Wall - what it makes of the data.

- topic radar: which terms show up in many sources right now, compared with
  the hours before (new, rising, falling)
- breaking: several sources report the same new topic within a short time,
  or a feed marks a headline as breaking itself
- news pace: headlines per hour over the last day
- market mood: breadth and average move of the watchlist, 0 (panic) to 100
  (euphoria)
- movers: biggest winners and losers
- keyword and price rules for alerts
"""

import re
import time
from collections import Counter, defaultdict

STOPWORDS = set("""
a about above after again against all also am an and any are as at be because been before being below between both but by
can could did do does doing down during each few for from further had has have having he her here hers him his how i if in
into is it its itself just me more most my no nor not now of off on once only or other our out over own same she should so
some such than that the their them then there these they this those through to too under until up very was we were what
when where which while who whom why will with would you your new says said say amid live latest update updates news
video watch photos what's how's here's get gets got make makes made take takes year years day days week weeks time first
last next one two three four five six many much people man woman men women world report reports could after amid over into
via may might must back still even like just know shows show sees see set sets calls call call's call wants want us u.s
der die das den dem des ein eine einer eines einem einen und oder aber auch als am an auf aus bei bis da dass durch für gegen
hat haben hatte hier ich ihr ihre im in ist ja kein keine mit nach nicht noch nun nur ob ohne sich sie sind so über um
uns unter vom von vor war waren was weil wenn wer wie wieder wird werden wurde zu zum zur zwei drei vier neue neuen neuer
neues mehr jetzt heute gestern morgen soll sollen will wollen kann können muss müssen gibt geht mal schon sehr viel viele
erste ersten letzte neu laut so sei seit seine seiner seinen seinem diese dieser dieses diesem diesen jahr jahre jahren
woche tag tage tagen uhr live ticker liveblog newsblog video bilder fotos gegen beim ab bislang bereits damit dabei dazu
el la los las un una unos unas y o pero también como en con por para de del al se su sus es son fue ser ha han hay más
menos muy sin sobre tras ante entre hasta desde que qué quien cuando donde este esta estos estas ese esa eso lo le les
nuevo nueva nuevos año años día días semana hoy ayer mañana dos tres directo última hora
""".split())

# A headline that calls itself breaking.
BREAKING_MARKERS = re.compile(r"(^|\W)(breaking( news)?|eilmeldung|\+\+\+|última hora|ultima hora|just in|exklusiv)(\W|$)",
                              re.IGNORECASE)
WORD_RE = re.compile(r"[0-9A-Za-zÀ-ÖØ-öø-ÿĀ-ž][0-9A-Za-zÀ-ÖØ-öø-ÿĀ-ž'’.\-]*[0-9A-Za-zÀ-ÖØ-öø-ÿĀ-ž]|[A-Z]{2}")

RECENT = 3 * 3600
BASELINE = 21 * 3600
BREAK_WINDOW = 45 * 60


def words(title):
    """Content words of a headline: (key, shown form)."""
    out = []
    last_end = 0
    for match in WORD_RE.finditer(title or ""):
        if re.search(r"[:;,|–—\-+/?!()\"“”„«»]", (title or "")[last_end:match.start()]) and out and out[-1] is not None:
            out.append(None)  # "Klimagipfel: Delegierte" is no name
        last_end = match.end()
        token = match.group(0).strip(".'’-")
        if token.endswith(("'s", "’s")):
            token = token[:-2]
        key = token.lower()
        if not key or key in STOPWORDS or key.isdigit():
            out.append(None)
            continue
        acronym = token.isupper() and 2 <= len(token) <= 6
        if len(key) < 4 and not acronym:
            out.append(None)
            continue
        out.append((key, token))
    return out


def terms(title):
    """Single words plus pairs of neighbours ("Donald Trump", "Federal Reserve")."""
    seq = words(title)
    found = {}
    for item in seq:
        if item:
            found.setdefault(item[0], item[1])
    return _pairs(seq, found)


def is_name(form, first=False):
    """Looks like a name or an acronym (not just the first word of a headline)."""
    if form.isupper() and len(form) >= 2:
        return True
    return form[:1].isupper() and not first


def _pairs(seq, found):
    for a, b in zip(seq, seq[1:]):
        if a and b and (a[1][:1].isupper() and b[1][:1].isupper()):
            found.setdefault(f"{a[0]} {b[0]}", f"{a[1]} {b[1]}")
    return found


def item_time(item):
    at, seen = item.get("at"), item.get("seen") or time.time()
    # Feeds sometimes date items in the future or years back; trust them only near "seen".
    if not at or at > seen + 600 or at < seen - 2 * 86400:
        return seen
    return at


def topic_radar(items, now=None, top=12):
    now = now or time.time()
    recent_sources = defaultdict(set)
    recent_count = Counter()
    base_count = Counter()
    base_sources = defaultdict(set)
    shown = defaultdict(Counter)
    ids = defaultdict(set)
    names = Counter()
    for item in items:
        t = item_time(item)
        age = now - t
        if age > RECENT + BASELINE:
            continue
        first = (words(item["title"]) or [None])[0]
        for key, form in terms(item["title"]).items():
            shown[key][form] += 1
            if is_name(form, first is not None and first[0] == key):
                names[key] += 1
            if age <= RECENT:
                ids[key].add(item["id"])
                recent_sources[key].add(item["source"])
                recent_count[key] += 1
            else:
                base_count[key] += 1
                base_sources[key].add(item["source"])
    sources_total = len({i["source"] for i in items}) or 1
    min_sources = 2 if sources_total >= 3 else 1
    scored = []
    for key, srcs in recent_sources.items():
        if len(srcs) < min_sources:
            continue
        rate_now = recent_count[key] / (RECENT / 3600)
        rate_before = base_count[key] / (BASELINE / 3600)
        score = len(srcs) * 2 + recent_count[key] + (3 if rate_now > 2 * rate_before else 0)
        if " " in key:
            score += 1.5  # a name says more than a single word
        if names[key] * 2 >= sum(shown[key].values()):
            score += 2    # mostly written like a name: Henrietta, NATO, Apple
        if base_count[key] == 0:
            trend = "new"
        elif rate_now > 1.5 * rate_before:
            trend = "up"
        elif rate_now < 0.6 * rate_before:
            trend = "down"
        else:
            trend = "flat"
        scored.append({"key": key, "term": shown[key].most_common(1)[0][0], "sources": len(srcs),
                       "count": recent_count[key], "before": base_count[key], "trend": trend, "score": score, "ids": ids[key]})
    scored.sort(key=lambda r: (-r["score"], r["key"]))
    picked = []
    for row in scored:
        # Words of the same headlines ("Tech", "shares", "rally") are one topic.
        if any(len(row["ids"] & p["ids"]) >= 0.6 * len(row["ids"]) for p in picked):
            continue
        picked.append(row)
        if len(picked) >= top:
            break
    best = picked[0]["score"] if picked else 1
    for row in picked:
        row["weight"] = round(row["score"] / best, 3)
        del row["ids"]
    return picked


def breaking(items, now=None, min_sources=3):
    """New topics that several sources report at once, plus self-declared breaking news."""
    now = now or time.time()
    out = []
    # Items of a feed's first read (just added, or after a restart) are not news.
    window = [i for i in items if now - item_time(i) <= BREAK_WINDOW and not i.get("quiet")]
    earlier = [i for i in items if BREAK_WINDOW < now - item_time(i) <= 12 * 3600]
    for item in window:
        if BREAKING_MARKERS.search(item["title"]):
            out.append({"kind": "marker", "id": item["id"], "term": "", "title": item["title"],
                        "source": item["source"], "at": item_time(item), "sources": 1})
    by_term = defaultdict(list)
    for item in window:
        for key in terms(item["title"]):
            by_term[key].append(item)
    before = Counter()
    for item in earlier:
        for key in set(terms(item["title"])):
            before[key] += 1
    clusters = []
    for key, rows in by_term.items():
        sources = {r["source"] for r in rows}
        if len(sources) >= min_sources and before[key] <= 1:
            first = (words(rows[0]["title"]) or [None])[0]
            name = is_name(terms(rows[0]["title"])[key], first is not None and first[0] == key)
            clusters.append((len(sources), " " in key, name, key, rows))
    clusters.sort(key=lambda c: (-c[0], not c[1], not c[2], -len(c[3])))
    used = []
    for count, _pair, _name, key, rows in clusters:
        row_ids = {r["id"] for r in rows}
        if any(len(row_ids & u) >= 0.5 * len(row_ids) for u in used):
            continue
        used.append(row_ids)
        latest = max(rows, key=item_time)
        out.append({"kind": "cluster", "id": f"cluster:{key}:{int(min(item_time(r) for r in rows) // 3600)}",
                    "term": terms(latest["title"]).get(key, key), "title": latest["title"],
                    "source": latest["source"], "at": item_time(latest), "sources": count})
        if len(out) >= 6:
            break
    return out


def news_pace(items, now=None):
    """Headlines per hour over the last 24 hours (oldest first) and a word for it."""
    now = now or time.time()
    hours = [0] * 24
    for item in items:
        age = now - item_time(item)
        if 0 <= age < 24 * 3600:
            hours[23 - int(age // 3600)] += 1
    previous = sorted(hours[:-1])
    median = previous[len(previous) // 2] if previous else 0
    last = hours[-1]
    ratio = last / median if median else (2.0 if last else 1.0)
    level = "calm" if ratio < 0.7 else "normal" if ratio < 1.3 else "busy" if ratio < 2 else "hectic"
    return {"hours": hours, "lastHour": last, "median": median, "level": level}


def market_mood(quotes):
    rows = [q for q in quotes if q.get("pct") is not None and q.get("kind") in ("index", "stock", "crypto", "commodity")]
    if not rows:
        return None
    pcts = []
    for q in rows:
        pct = q["pct"]
        if q["symbol"].upper() == "^VIX":
            pct = -pct / 5  # fear index: up means fear
        pcts.append(max(-10, min(10, pct)))
    up = sum(1 for p in pcts if p > 0.05)
    down = sum(1 for p in pcts if p < -0.05)
    breadth = up / (up + down) if up + down else 0.5
    avg = sum(pcts) / len(pcts)
    score = 50 + max(-35, min(35, avg * 14)) + (breadth - 0.5) * 30
    score = int(round(max(0, min(100, score))))
    label = ("panic" if score < 20 else "fear" if score < 40 else "neutral" if score < 60
             else "greed" if score < 80 else "euphoria")
    return {"score": score, "label": label, "up": up, "down": down, "avg": round(avg, 2)}


def movers(quotes, n=4):
    rows = [q for q in quotes if q.get("pct") is not None and q.get("kind") in ("stock", "crypto")]
    rows.sort(key=lambda q: q["pct"])
    up = [q for q in reversed(rows) if q["pct"] > 0][:n]
    down = [q for q in rows if q["pct"] < 0][:n]
    slim = lambda q: {"symbol": q["symbol"], "name": q["name"], "pct": q["pct"], "price": q["price"],
                      "currency": q.get("currency", ""), "kind": q["kind"]}
    return {"up": [slim(q) for q in up], "down": [slim(q) for q in down]}


def source_activity(items, now=None):
    now = now or time.time()
    counts = Counter(i["source"] for i in items if now - item_time(i) < 3 * 3600)
    return [{"source": s, "count": c} for s, c in counts.most_common(12)]


# --------------------------------------------------------------------------
# Rules for alerts
# --------------------------------------------------------------------------

def keyword_list(text):
    return [k.strip() for k in re.split(r"[,;\n]", str(text or "")) if k.strip()]


def keyword_hit(keywords, item):
    title = item.get("title") or ""
    for keyword in keywords:
        pattern = r"(?<!\w)" + re.escape(keyword) + r"(?!\w)"
        if re.search(pattern, title, re.IGNORECASE):
            return keyword
    return None


RULE_RE = re.compile(r"^\s*(\S+)\s*(>=|<=|>|<|±|\+-|\+/-|move|moves)\s*([0-9]+(?:[.,][0-9]+)?)\s*(%?)\s*$", re.IGNORECASE)


def parse_rules(text):
    """One rule per line: 'NVDA > 150', 'AAPL < 180', 'TSLA ± 5%' (day move), '^GDAXI ± 2%'."""
    rules = []
    for line in str(text or "").splitlines():
        line = line.split("#", 1)[0].strip()
        if not line:
            continue
        match = RULE_RE.match(line)
        if not match:
            continue
        symbol, op, number, pct = match.groups()
        value = float(number.replace(",", "."))
        if op in ("±", "+-", "+/-", "move", "moves"):
            rules.append({"symbol": symbol.upper(), "op": "move", "value": value, "text": line})
        else:
            rules.append({"symbol": symbol.upper(), "op": op[0], "value": value, "pct": bool(pct), "text": line})
    return rules


def rule_hit(rule, quote):
    price, pct = quote.get("price"), quote.get("pct")
    if rule["op"] == "move":
        return pct is not None and abs(pct) >= rule["value"]
    if price is None:
        return False
    return price > rule["value"] if rule["op"] == ">" else price < rule["value"]
