"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/NetworkOverview/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["HotDisk", "FullPercent", "PlaylistSeconds"];
const CHECK_FIELDS = ["ShowOffline"];
const TEXT_FIELDS = ["PiholeAddress", "Pihole2Address", "Pihole3Address", "FritzAddress", "FritzUser", "ServerAddress"];
const SECRET_FIELDS = ["PiholePassword", "Pihole2Password", "Pihole3Password", "FritzPassword", "ServerApiKey"];

// Texte der Seite auf Deutsch, Englisch und Spanisch. Die Sprache ist eine
// Einstellung des Plugins und gilt auch für die Szene. Deutsch steht im HTML.
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Dein Heimnetz als lebendiger Netzplan: welche Geräte online sind, was durch die Internetleitung geht, was die Pi-hole blockt und wie es deinem Server geht. Nimm die Szene Network Overview wie ein Bild in eine Playlist. Alles bleibt in deinem Heimnetz; jede Änderung hier wird sofort gespeichert.",
    "Your home network as a living network map: which devices are online, what goes through your internet line, what Pi-hole blocks and how your server is doing. Add the Network Overview scene to a playlist like a picture. Everything stays in your home network; every change here is saved immediately.",
    "Tu red doméstica como un mapa vivo: qué dispositivos están en línea, qué pasa por tu conexión a internet, qué bloquea Pi-hole y cómo está tu servidor. Añade la escena Network Overview a una lista como una imagen. Todo se queda en tu red doméstica; cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  refresh: ["Jetzt neu laden", "Reload now", "Recargar ahora"],
  playlist: ["Playlist anlegen", "Create playlist", "Crear lista"],
  factDevices: ["Geräte", "Devices", "Dispositivos"],
  piholeHint: ["Bis zu drei Pi-holes. Trag jede mit ihrer eigenen Adresse ein, die Zahlen werden zusammengezählt. Nutzt du keepalived, kannst du die gemeinsame (virtuelle) Adresse zusätzlich eintragen: das Plugin erkennt, dass es dieselbe Pi-hole ist, zählt sie nur einmal und zeigt sie als aktiv. Pi-hole 6 und 5 gehen beide.",
    "Up to three Pi-holes. Enter each one with its own address; the numbers are added up. If you use keepalived, you can also enter the shared (virtual) address: the plugin sees that it is the same Pi-hole, counts it only once and shows it as active. Pi-hole 6 and 5 both work.",
    "Hasta tres Pi-hole. Introduce cada uno con su propia dirección; las cifras se suman. Si usas keepalived, puedes añadir también la dirección compartida (virtual): el plugin ve que es el mismo Pi-hole, lo cuenta una sola vez y lo muestra como activo. Funcionan Pi-hole 6 y 5."],
  address: ["Adresse", "Address", "Dirección"],
  address2: ["Adresse der 2. Pi-hole", "Address of the 2nd Pi-hole", "Dirección del 2.º Pi-hole"],
  address3: ["Adresse der 3. Pi-hole (oder keepalived)", "Address of the 3rd Pi-hole (or keepalived)", "Dirección del 3.er Pi-hole (o keepalived)"],
  appPassword: ["App-Passwort", "App password", "Contraseña de aplicación"],
  appPasswordSame: ["App-Passwort (leer = wie oben)", "App password (empty = same as above)", "Contraseña de aplicación (vacía = la de arriba)"],
  save: ["Speichern", "Save", "Guardar"],
  clearHint: ["Ein leeres Passwortfeld behält das gespeicherte. Zum Löschen ein einzelnes - eintragen. Eine Adresse löschst du, indem du das Feld leerst und speicherst.",
    "An empty password field keeps the stored one. To delete it, enter a single -. To remove an address, clear the field and save.",
    "Un campo de contraseña vacío conserva la guardada. Para borrarla, escribe un solo -. Para quitar una dirección, vacía el campo y guarda."],
  piHowto: ["So bekommst du das App-Passwort", "How to get the app password", "Cómo obtener la contraseña de aplicación"],
  pi1: ["Pi-hole 6: Weboberfläche öffnen, <b>Settings</b> &rsaquo; <b>Web interface / API</b>.",
    "Pi-hole 6: open the web interface, <b>Settings</b> &rsaquo; <b>Web interface / API</b>.",
    "Pi-hole 6: abre la interfaz web, <b>Settings</b> &rsaquo; <b>Web interface / API</b>."],
  pi2: ["Oben rechts von <b>Basic</b> auf <b>Expert</b> umschalten, dann <b>Configure app password</b>.",
    "Switch from <b>Basic</b> to <b>Expert</b> at the top right, then <b>Configure app password</b>.",
    "Arriba a la derecha cambia de <b>Basic</b> a <b>Expert</b> y luego <b>Configure app password</b>."],
  pi3: ["Das angezeigte Passwort kopieren, <b>Enable new app password</b> drücken und es hier eintragen. Hast du mehrere Pi-holes, mach das auf jeder (oder nimm überall dasselbe Passwort).",
    "Copy the password shown, press <b>Enable new app password</b> and enter it here. With several Pi-holes, do this on each (or use the same password everywhere).",
    "Copia la contraseña que aparece, pulsa <b>Enable new app password</b> e introdúcela aquí. Con varios Pi-hole, hazlo en cada uno (o usa la misma contraseña en todos)."],
  pi4: ["Pi-hole 5: <b>Settings</b> &rsaquo; <b>API</b> &rsaquo; <b>Show API token</b> und den Token hier eintragen.",
    "Pi-hole 5: <b>Settings</b> &rsaquo; <b>API</b> &rsaquo; <b>Show API token</b> and enter the token here.",
    "Pi-hole 5: <b>Settings</b> &rsaquo; <b>API</b> &rsaquo; <b>Show API token</b> e introduce el token aquí."],
  fritzHint: ["Über die Schnittstelle TR-064 erfährt das Plugin, welche Geräte gerade im Heimnetz sind (LAN, WLAN, Gäste), ob das Internet verbunden ist und wie viel durch die Leitung geht. Wie viel jedes einzelne Gerät lädt, verrät die Fritzbox darüber nicht; wer am aktivsten ist, kommt deshalb aus den DNS-Anfragen der Pi-hole.",
    "Through its TR-064 interface the plugin learns which devices are in your home network right now (LAN, Wi-Fi, guests), whether the internet is connected and how much goes through the line. The FRITZ!Box does not tell how much each single device downloads; who is most active therefore comes from Pi-hole's DNS queries.",
    "Mediante la interfaz TR-064 el plugin sabe qué dispositivos están ahora en tu red (LAN, Wi-Fi, invitados), si internet está conectado y cuánto pasa por la línea. La FRITZ!Box no dice cuánto descarga cada dispositivo; quién es el más activo sale de las consultas DNS de Pi-hole."],
  user: ["Benutzer", "User", "Usuario"],
  password: ["Passwort", "Password", "Contraseña"],
  fritzHowtoTitle: ["So richtest du die Fritzbox ein", "How to set up the FRITZ!Box", "Cómo configurar la FRITZ!Box"],
  fr1: ["In der Fritzbox (<b>fritz.box</b>) unter <b>Heimnetz</b> &rsaquo; <b>Netzwerk</b> &rsaquo; <b>Netzwerkeinstellungen</b> den Haken bei <b>Zugriff für Anwendungen zulassen</b> setzen (oft schon an) und Übernehmen.",
    "In the FRITZ!Box (<b>fritz.box</b>) go to <b>Home Network</b> &rsaquo; <b>Network</b> &rsaquo; <b>Network Settings</b>, tick <b>Allow access for applications</b> (often already on) and apply.",
    "En la FRITZ!Box (<b>fritz.box</b>) ve a <b>Red doméstica</b> &rsaquo; <b>Red</b> &rsaquo; <b>Ajustes de red</b>, marca <b>Permitir acceso para aplicaciones</b> (suele estar activo) y aplica."],
  fr2: ["Unter <b>System</b> &rsaquo; <b>FRITZ!Box-Benutzer</b> &rsaquo; <b>Benutzer hinzufügen</b> einen eigenen Benutzer anlegen, zum Beispiel <b>dynaframe</b>, mit einem Passwort.",
    "Under <b>System</b> &rsaquo; <b>FRITZ!Box Users</b> &rsaquo; <b>Add User</b>, create a user of its own, for example <b>dynaframe</b>, with a password.",
    "En <b>Sistema</b> &rsaquo; <b>Usuarios de FRITZ!Box</b> &rsaquo; <b>Añadir usuario</b>, crea un usuario propio, por ejemplo <b>dynaframe</b>, con contraseña."],
  fr3: ["Bei den Rechten nur <b>FRITZ!Box Einstellungen</b> anhaken, alles andere aus. „Zugang auch aus dem Internet erlaubt“ aus lassen.",
    "For the rights, tick only <b>FRITZ!Box settings</b>, nothing else. Leave “Access from the internet allowed” off.",
    "En los permisos marca solo <b>Ajustes de FRITZ!Box</b>, nada más. Deja desactivado «Acceso también desde internet»."],
  fr4: ["Die Fritzbox will das oft am Gerät bestätigen (Taste drücken oder Telefon). Dann Benutzer und Passwort hier eintragen und Speichern.",
    "The FRITZ!Box often wants you to confirm this on the box (press a button or use a phone). Then enter user and password here and save.",
    "La FRITZ!Box suele pedir confirmación en el aparato (pulsar un botón o por teléfono). Después introduce usuario y contraseña aquí y guarda."],
  serverHint: ["Speicher, Platten mit Temperatur, CPU, RAM und Docker-Container. Unraid hat ab Version 7.2 eine eigene Schnittstelle (API) dafür. Für ältere Versionen oder einen anderen Server geht Glances.",
    "Storage, disks with temperature, CPU, RAM and Docker containers. From version 7.2 Unraid has its own interface (API) for this. For older versions or another server, Glances works.",
    "Almacenamiento, discos con temperatura, CPU, RAM y contenedores Docker. Desde la versión 7.2 Unraid tiene su propia interfaz (API). Para versiones anteriores u otro servidor sirve Glances."],
  kindUnraid: ["Unraid (ab 7.2)", "Unraid (7.2 or later)", "Unraid (desde 7.2)"],
  kindOff: ["Kein Server", "No server", "Sin servidor"],
  unHowto: ["So bekommst du den Unraid-API-Key", "How to get the Unraid API key", "Cómo obtener la clave API de Unraid"],
  un1: ["In Unraid <b>Settings</b> &rsaquo; <b>Management Access</b> öffnen und bis <b>API Keys</b> scrollen.",
    "In Unraid open <b>Settings</b> &rsaquo; <b>Management Access</b> and scroll to <b>API Keys</b>.",
    "En Unraid abre <b>Settings</b> &rsaquo; <b>Management Access</b> y baja hasta <b>API Keys</b>."],
  un2: ["<b>Create API Key</b>: Name zum Beispiel <b>dynaframe</b>, als Rolle <b>Viewer</b> (darf nur lesen).",
    "<b>Create API Key</b>: name for example <b>dynaframe</b>, role <b>Viewer</b> (read only).",
    "<b>Create API Key</b>: nombre por ejemplo <b>dynaframe</b>, rol <b>Viewer</b> (solo lectura)."],
  un3: ["Den Key kopieren und hier eintragen. Als Adresse reicht die IP des Servers; leitet Unraid auf https um, folgt das Plugin.",
    "Copy the key and enter it here. The server's IP is enough as address; if Unraid redirects to https, the plugin follows.",
    "Copia la clave e introdúcela aquí. Basta con la IP del servidor como dirección; si Unraid redirige a https, el plugin lo sigue."],
  glHowto: ["So richtest du Glances ein", "How to set up Glances", "Cómo configurar Glances"],
  gl1: ["In Unraid unter <b>Apps</b> nach <b>Glances</b> suchen und installieren (Port 61208).",
    "In Unraid, search for <b>Glances</b> under <b>Apps</b> and install it (port 61208).",
    "En Unraid, busca <b>Glances</b> en <b>Apps</b> e instálalo (puerto 61208)."],
  gl2: ["Die Adresse des Servers hier eintragen, zum Beispiel 192.168.178.10:61208. Ein Key ist nicht nötig.",
    "Enter the server's address here, for example 192.168.178.10:61208. No key is needed.",
    "Introduce aquí la dirección del servidor, por ejemplo 192.168.178.10:61208. No hace falta clave."],
  viewTitle: ["Anzeige", "Display", "Visualización"],
  labels: ["Gerätenamen", "Device names", "Nombres de dispositivos"],
  lActive: ["die aktivsten und neue", "the most active and new ones", "los más activos y los nuevos"],
  lAll: ["alle", "all", "todos"],
  lNone: ["keine", "none", "ninguno"],
  hotDisk: ["Platte zu warm ab … °C", "Disk too warm from … °C", "Disco demasiado caliente desde … °C"],
  fullPercent: ["Speicher voll ab … %", "Storage full from … %", "Almacenamiento lleno desde … %"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la lista (segundos)"],
  showOffline: ["Geräte, die gerade offline sind, blass zeigen", "Show devices that are offline right now, dimmed", "Mostrar atenuados los dispositivos desconectados"],
  playlistHint: ["„Playlist anlegen“ macht eine Playlist „Network Overview“ mit der Szene und der Dauer von oben. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "“Create playlist” makes a playlist “Network Overview” with the scene and the duration above. You can also add the scene to any playlist yourself.",
    "«Crear lista» crea una lista «Network Overview» con la escena y la duración de arriba. También puedes añadir la escena tú mismo a cualquier lista."],
  devicesTitle: ["Geräte", "Devices", "Dispositivos"],
  devicesHint: ["So sieht das Plugin dein Heimnetz gerade. Ein Gerät gilt als neu, wenn es zum ersten Mal in den letzten 24 Stunden auftaucht. Beim allerersten Start ist keines neu.",
    "This is how the plugin sees your home network right now. A device counts as new when it shows up for the first time in the last 24 hours. On the very first start none is new.",
    "Así ve el plugin tu red ahora mismo. Un dispositivo cuenta como nuevo si aparece por primera vez en las últimas 24 horas. En el primer arranque ninguno es nuevo."],
  thName: ["Name", "Name", "Nombre"], thConn: ["Verbindung", "Connection", "Conexión"], thKind: ["Art", "Type", "Tipo"],
  thQueries: ["Anfragen (24 h)", "Queries (24 h)", "Consultas (24 h)"],
  noDevices: ["Noch keine Geräte. Richte Fritzbox oder Pi-hole ein.", "No devices yet. Set up the FRITZ!Box or Pi-hole.", "Aún no hay dispositivos. Configura la FRITZ!Box o Pi-hole."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or wishes?", "¿Problemas, preguntas o deseos?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre un issue en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", ", with plugin name and version.", ", con el nombre y la versión del plugin."],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  secretSet: ["gespeichert (leer lassen = behalten)", "stored (leave empty to keep)", "guardada (dejar vacío = conservar)"],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin wurde neu gestartet (HTTP {status}). Lade die Seite neu.", "The plugin was restarted (HTTP {status}). Reload the page.", "El plugin se ha reiniciado (HTTP {status}). Recarga la página."],
  error: ["Fehler (HTTP {status}).", "Error (HTTP {status}).", "Error (HTTP {status})."],
  piholeSummary: ["{ok} von {n} erreichbar", "{ok} of {n} reachable", "{ok} de {n} accesibles"],
  conn_lan: ["LAN", "LAN", "LAN"], conn_wlan: ["WLAN", "Wi-Fi", "Wi-Fi"], conn_guest: ["Gast", "Guest", "Invitado"], conn_other: ["–", "–", "–"],
  kind_phone: ["Handy", "Phone", "Móvil"], kind_tablet: ["Tablet", "Tablet", "Tableta"], kind_watch: ["Uhr", "Watch", "Reloj"],
  kind_laptop: ["Laptop", "Laptop", "Portátil"], kind_computer: ["Computer", "Computer", "Ordenador"], kind_tv: ["TV", "TV", "TV"],
  kind_speaker: ["Lautsprecher", "Speaker", "Altavoz"], kind_console: ["Konsole", "Console", "Consola"],
  kind_printer: ["Drucker", "Printer", "Impresora"], kind_camera: ["Kamera", "Camera", "Cámara"],
  kind_smarthome: ["Smart Home", "Smart home", "Hogar inteligente"], kind_server: ["Server", "Server", "Servidor"],
  kind_board: ["Kleinrechner", "Single-board", "Miniordenador"], kind_network: ["Netzwerk", "Network", "Red"],
  kind_pihole: ["Pi-hole", "Pi-hole", "Pi-hole"], kind_frame: ["dieser Rahmen", "this frame", "este marco"], kind_other: ["–", "–", "–"],
  newTag: ["NEU", "NEW", "NUEVO"],
};
const LANGS = ["de", "en", "es"];
let lang = "de";
let current = null;

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([502, 503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "") {
  const node = el("statusNote");
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes, quiet = false) {
  try {
    await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    if (!quiet) setStatus(t("saved"), "ok");
    // Nach dem Speichern fragt das Plugin gleich neu; kurz warten, dann zeigen.
    setTimeout(refresh, 2500);
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

function fact(id, info) {
  const dd = el(`fact${id}`);
  dd.textContent = info.text;
  dd.className = info.tone || "";
  dd.title = info.detail || "";
  el(`sub${id}`).textContent = info.extra || "";
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  el("Language").value = lang;

  // Pi-holes: eine Zeile je Eintrag, oben zusammengefasst
  const configured = state.piholes.filter((p) => p.state !== "off");
  const ok = configured.filter((p) => p.state === "ok");
  if (configured.length <= 1) fact("Pihole", configured[0] || state.piholes[0]);
  else fact("Pihole", { text: t("piholeSummary", { ok: ok.length, n: configured.length }),
    tone: ok.length === configured.length ? "ok" : ok.length ? "busy" : "bad",
    extra: [...new Set(ok.map((p) => p.extra.split(" · ")[0]).filter(Boolean))].join(", ") });
  state.piholes.forEach((p, i) => {
    const node = el(`nowPihole${i + 1}`);
    node.textContent = p.state === "off" ? "" : [p.text, p.extra].filter(Boolean).join(" · ");
    node.className = `now ${p.tone === "bad" ? "bad" : ""}`;
  });
  fact("Fritz", state.fritz);
  fact("Server", state.server);
  el("factDevices").textContent = state.devices.text;
  el("factVersion").textContent = state.version;
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Network Overview ${state.version}] `);

  for (const name of TEXT_FIELDS) if (document.activeElement !== el(name)) el(name).value = s[name] || "";
  for (const name of NUMBER_FIELDS) if (document.activeElement !== el(name)) el(name).value = s[name];
  for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
  if (document.activeElement !== el("Labels")) el("Labels").value = s.Labels;
  for (const name of SECRET_FIELDS) el(name).placeholder = state.secretsSet[name] ? t("secretSet") : "";
  for (const radio of document.querySelectorAll('input[name="ServerKind"]')) radio.checked = radio.value === s.ServerKind;
  el("serverFields").classList.toggle("hidden", s.ServerKind === "off");
  el("serverFields").classList.toggle("nokey", s.ServerKind === "glances");
  el("unraidHowto").classList.toggle("hidden", s.ServerKind !== "unraid");
  el("glancesHowto").classList.toggle("hidden", s.ServerKind !== "glances");
  el("ServerAddress").placeholder = s.ServerKind === "glances" ? "192.168.178.10:61208" : "192.168.178.10";
  el("piholeHowto").open = !state.secretsSet.PiholePassword && !s.PiholeAddress;
  el("fritzHowto").open = !state.secretsSet.FritzPassword;

  const rows = el("deviceRows");
  rows.innerHTML = "";
  if (!state.devices.list.length) {
    const tr = document.createElement("tr");
    const td = document.createElement("td");
    td.colSpan = 5;
    td.textContent = t("noDevices");
    tr.append(td);
    rows.append(tr);
  }
  for (const d of state.devices.list) {
    const tr = document.createElement("tr");
    tr.className = d.online ? "on" : "off";
    const cells = [d.name, d.ip, t(`conn_${d.conn}`), t(`kind_${d.kind}`), d.count];
    cells.forEach((value, i) => {
      const td = document.createElement("td");
      if (i === 0) {
        const dot = document.createElement("span");
        dot.className = "dot";
        td.append(dot, document.createTextNode(value));
        if (d.new) {
          const tag = document.createElement("span");
          tag.className = "new";
          tag.textContent = t("newTag");
          td.append(tag);
        }
      } else {
        td.textContent = value;
      }
      if (i === 4) td.className = "num";
      tr.append(td);
    });
    rows.append(tr);
  }
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

async function post(path) {
  try {
    const result = await api(path, { method: "POST", body: "{}" });
    setStatus(result.message || t("saved"), "ok");
  } catch (error) {
    setStatus(error.message, "bad");
  }
  refresh();
}

function secret(name) {
  const value = el(name).value.trim();
  el(name).value = "";
  return value;
}

el("Language").addEventListener("change", () => save({ Language: el("Language").value }, true));
el("Labels").addEventListener("change", () => save({ Labels: el("Labels").value }));
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", () => save({ [name]: el(name).value }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", () => save({ [name]: el(name).checked }));
for (const button of document.querySelectorAll("button[data-save]")) {
  const prefix = button.dataset.save;
  button.addEventListener("click", () => save({ [`${prefix}Address`]: el(`${prefix}Address`).value.trim(),
    [`${prefix}Password`]: secret(`${prefix}Password`) }));
}
el("fritzSave").addEventListener("click", () => save({ FritzAddress: el("FritzAddress").value.trim(),
  FritzUser: el("FritzUser").value.trim(), FritzPassword: secret("FritzPassword") }));
el("serverSave").addEventListener("click", () => save({ ServerAddress: el("ServerAddress").value.trim(),
  ServerApiKey: secret("ServerApiKey") }));
for (const radio of document.querySelectorAll('input[name="ServerKind"]')) {
  radio.addEventListener("change", () => save({ ServerKind: radio.value }));
}
el("refreshButton").addEventListener("click", () => post("./api/refresh"));
el("playlistButton").addEventListener("click", () => post("./api/playlist"));

refresh();
setInterval(refresh, 5000);
