# Third-party notes

- The scene bundles the fonts Inter (SIL Open Font License 1.1, see `dynamic/fonts/OFL-Inter.txt`) and JetBrains Mono (SIL Open Font License 1.1, see `dynamic/fonts/OFL-JetBrainsMono.txt`).
- The globe in the scene uses Natural Earth land outlines (public domain), simplified.
- `sources.py`, `immich_filters.py`, `dynaframe_filters.py`, `palette.py` and `own_playlist.py` are shared with Jan's other DynaFrame plugins (own code).
- Place names: © OpenStreetMap contributors, via Nominatim (ODbL).
