"""Der Linienplan: aus Fotos (Datum, GPS, Personen) werden Haltestellen und Linien.

- Haltestellen sind Reisen (trips.find_trips, gemeinsam mit Travel Scrapbook),
  Feste zu Hause (Tage mit vielen Fotos) und Umzüge (trips.find_homes).
- Linien sind Personen (Immich-Gesichter), wiederkehrende Orte (Reisen an
  denselben Ort) oder beides. Eine Linie hält an jeder Haltestelle, auf deren
  Fotos die Person zu sehen ist bzw. die an dem Ort liegt. Wo mehrere Linien
  an einer Haltestelle halten, gab es gemeinsame Fotos (Umsteigebahnhof).
- Die Stammlinie ("Mein Leben") fährt alle Haltestellen an.

Eingabe: Zeilen mit k, t, lat, lon, place ("Stadt, Land"), fav, stars,
optional people ([[id, name], ...]) und grp (Ordner- oder Albumname).
Reines Python; die Szene rechnet das Bild des Plans selbst.
"""

import datetime
import re

import trips

PALETTE = ["#e3242b", "#0a6cbc", "#00a05a", "#f4b000", "#8e3fa8", "#f07c00", "#00a0a8", "#e5007d",
           "#8b5a2b", "#6a8f00", "#4b5fc9", "#c2185b"]
TRUNK_COLOR = "#3c4350"
GENERIC_GROUP = re.compile(
    r"^(\d+|\d{4}[-_. ]?\d{0,2}([-_. ]?\d{0,2})?|dcim|camera|kamera|100apple|\d{3}[a-z_]+|photos?|fotos?|bilder|"
    r"pictures|images|import(ed)?|uploads?|upload|whatsapp.*|screenshots?|bildschirmfotos?|download(s)?|"
    r"backup|sync|nextcloud|google ?photos|icloud.*|instant ?upload|camera ?roll|aufnahmen|media|medien|"
    r"originals?|sonstige|misc|neu|new|alle|all|tmp|temp|inbox)$", re.I)


def _date(text):
    try:
        return datetime.date(int(text[:4]), int(text[5:7]), int(text[8:10]))
    except (TypeError, ValueError):
        return None


def _located(row):
    return row.get("lat") is not None and row.get("lon") is not None


def _median(values):
    values = sorted(values)
    if not values:
        return None
    mid = len(values) // 2
    return values[mid] if len(values) % 2 else (values[mid - 1] + values[mid]) / 2


def split_place(text):
    """"Stadt, Land" -> (Stadt, Land); auch längere Ketten (Ort, Kreis, Land)."""
    parts = [p.strip() for p in str(text or "").split(",") if p.strip()]
    if not parts:
        return "", ""
    return parts[0], (parts[-1] if len(parts) > 1 else "")


def easter(year):
    a, b, c = year % 19, year // 100, year % 100
    d, e = b // 4, b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7  # noqa: E741
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = (h + l - 7 * m + 114) % 31 + 1
    return datetime.date(year, month, day)


def holiday(start, end):
    """"xmas", "nye", "easter" oder "" für ein Fest zwischen start und end."""
    day = start
    while day <= end:
        md = day.strftime("%m-%d")
        if md in ("12-24", "12-25", "12-26"):
            return "xmas"
        if md in ("12-31", "01-01"):
            return "nye"
        if abs((day - easter(day.year)).days) <= 1:
            return "easter"
        day += datetime.timedelta(days=1)
    return ""


def broad_groups(dated):
    """Ordner, die über mehr als zwei Monate gehen (z. B. "5Sterne", "Handy"): kein Name für eine Reise."""
    span = {}
    for row in dated:
        name = str(row.get("grp") or "").strip()
        if name:
            first, last = span.get(name, (row["t"], row["t"]))
            span[name] = (min(first, row["t"]), max(last, row["t"]))
    out = set()
    for name, (first, last) in span.items():
        a, b = _date(first), _date(last)
        if a and b and (b - a).days > 62:
            out.add(name)
    return out


def group_name(rows, broad=()):
    """Ordner- oder Albumname, wenn er die meisten Fotos trägt und kein Allerweltsname ist."""
    counts = {}
    for row in rows:
        name = str(row.get("grp") or "").strip()
        if name and name not in broad:
            counts[name] = counts.get(name, 0) + 1
    if not counts:
        return ""
    name, count = max(counts.items(), key=lambda item: item[1])
    if count < 0.6 * len(rows) or GENERIC_GROUP.match(name.strip()) or len(name) > 40:
        return ""
    # "2019-07 Usedom" -> "Usedom"
    clean = re.sub(r"^\s*\d{4}([-_. ]\d{1,2}){0,2}[-_. ]*", "", name).strip(" -_.")
    return clean if len(clean) >= 2 and not GENERIC_GROUP.match(clean) else ""


class Options:
    def __init__(self, **kw):
        self.line_kind = kw.get("line_kind", "auto")         # auto | people | places | mixed
        self.line_count = int(kw.get("line_count", 6))
        self.people = list(kw.get("people") or [])           # gewählte Personen-IDs (leer = automatisch)
        self.min_km = float(kw.get("min_km", 50))
        self.trip_photos = int(kw.get("trip_photos", 8))
        self.event_photos = int(kw.get("event_photos", 20))
        self.max_stations = int(kw.get("max_stations", 300))
        self.keep_photos = int(kw.get("keep_photos", 8))
        self.home = kw.get("home")                           # (lat, lon) oder None = selbst finden
        self.moves = bool(kw.get("moves", True))
        self.birthdays = dict(kw.get("birthdays") or {})     # Personen-ID -> "MM-DD"
        self.min_stars = int(kw.get("min_stars", 0))
        self.main = str(kw.get("main") or "")                 # wessen Leben: Personen-ID für die Stammlinie


def find_moves(dated, homes, min_km):
    """Umzüge: der erste Tag mit Fotos am neuen Wohnort nach dem letzten am alten."""
    out = []
    for old, new in zip(homes, homes[1:]):
        near_old = [r for r in dated if _located(r) and int(r["t"][:4]) <= new["from"]
                    and trips.haversine(old["lat"], old["lon"], r["lat"], r["lon"]) < min_km / 2]
        last_old = max((r["t"][:10] for r in near_old), default=f"{new['from']}-01-01")
        near_new = [r for r in dated if _located(r) and r["t"][:10] > last_old
                    and trips.haversine(new["lat"], new["lon"], r["lat"], r["lon"]) < min_km / 2]
        if not near_new:
            continue
        first = min(r["t"][:10] for r in near_new)
        until = (_date(first) + datetime.timedelta(days=21)).isoformat()
        rows = [r for r in near_new if r["t"][:10] <= until]
        out.append({"start": first, "end": first, "rows": rows, "home": new, "from_home": old})
    return out


def pick(rows, count, wanted_people=(), min_stars=0, seed=""):
    """Bis zu count Fotos: jede Linien-Person mindestens einmal (wenn möglich), Rest wie das Scrapbook."""
    chosen, used = [], set()
    for pid in wanted_people:
        if len(chosen) >= count:
            break
        with_person = [r for r in rows if r["k"] not in used and any(p[0] == pid for p in r.get("people") or [])]
        if not with_person:
            continue
        best = trips.pick_photos(with_person, 1, min_stars=0, seed=f"{seed}{pid}")["photos"]
        if best:
            chosen.append(best[0])
            used.add(best[0]["k"])
    rest = [r for r in rows if r["k"] not in used]
    more = trips.pick_photos(rest, count - len(chosen), min_stars=min_stars, seed=seed)["photos"] if count > len(chosen) else []
    if len(chosen) + len(more) < count and min_stars:
        extra = [r for r in rest if r["k"] not in {m["k"] for m in more}]
        more += trips.pick_photos(extra, count - len(chosen) - len(more), seed=seed)["photos"]
    out = chosen + more
    out.sort(key=lambda r: r["t"])
    return out


def build(rows, opts, namer=None):
    """Der Plan als dict (siehe Ende). namer(lat, lon) -> "Stadt, Land" oder "" (Nominatim)."""
    dated = [r for r in rows if _date(r.get("t") or "")]
    dated.sort(key=lambda r: r["t"])
    if not dated:
        return None
    if opts.home:
        homes = [{"from": 1900, "to": 2200, "lat": opts.home[0], "lon": opts.home[1]}]
    else:
        homes = trips.find_homes(dated)
    if not homes:
        homes = []

    broad = broad_groups(dated)
    stations = []
    if homes:
        for trip in trips.find_trips(dated, homes, min_km=opts.min_km, min_days=1, max_gap=2,
                                     min_photos=opts.trip_photos):
            stations.append({"kind": "trip", "start": trip["start"], "end": trip["end"], "rows": trip["rows"],
                             "far": trip["farKm"], "places": trip["places"]})
    # Im Jahr eines Umzugs kennt find_homes nur einen Wohnort: Reisen zum anderen sind keine
    def at_a_home(st):
        located = [r for r in st["rows"] if _located(r)]
        if not located or len(homes) < 2:
            return False
        lat, lon = _median([r["lat"] for r in located]), _median([r["lon"] for r in located])
        year = int(st["start"][:4])
        return any(h["from"] - 1 <= year <= h["to"] + 1 and trips.haversine(h["lat"], h["lon"], lat, lon) < opts.min_km
                   for h in homes)

    stations = [st for st in stations if not at_a_home(st)]
    in_trip = set()
    for st in stations:
        day = _date(st["start"])
        while day <= _date(st["end"]):
            in_trip.add(day.isoformat())
            day += datetime.timedelta(days=1)

    # Feste: Tage (nicht auf Reisen) mit vielen Fotos; aufeinanderfolgende zusammen
    by_day = {}
    for row in dated:
        if row["t"][:10] not in in_trip:
            by_day.setdefault(row["t"][:10], []).append(row)
    busy = sorted(day for day, day_rows in by_day.items() if len(day_rows) >= opts.event_photos)
    groups = []
    for day in busy:
        if groups and (_date(day) - _date(groups[-1][-1])).days <= 1:
            groups[-1].append(day)
        else:
            groups.append([day])
    for days in groups:
        event_rows = [r for d in days for r in by_day[d]]
        stations.append({"kind": "event", "start": days[0], "end": days[-1], "rows": event_rows, "far": 0,
                         "places": []})

    if opts.moves and len(homes) > 1:
        for move in find_moves(dated, homes, opts.min_km):
            if move["start"] in in_trip:
                continue
            stations.append({"kind": "move", "start": move["start"], "end": move["end"], "rows": move["rows"] or [],
                             "far": 0, "places": [], "home": move["home"]})

    # Zu viele? Erst kleine Feste, dann kleine Reisen weglassen (Umzüge bleiben)
    if len(stations) > opts.max_stations:
        ranked = sorted(stations, key=lambda s: (s["kind"] == "move", len(s["rows"]) * (2 if s["kind"] == "trip" else 1)),
                        reverse=True)
        stations = ranked[:opts.max_stations]
    stations.sort(key=lambda s: (s["start"], s["end"]))
    if not stations:
        return {"stations": [], "lines": [_trunk()], "photos": [], "homes": homes, "count": len(dated),
                "from": int(dated[0]["t"][:4]), "to": int(dated[-1]["t"][:4]), "homeCountry": ""}

    # Wer ist auf welchen Haltestellen zu sehen?
    names, person_stations = {}, {}
    for index, st in enumerate(stations):
        counts = {}
        for row in st["rows"]:
            for pid, pname in row.get("people") or []:
                if pname:
                    names[pid] = pname
                    counts[pid] = counts.get(pid, 0) + 1
        need = 1 if len(st["rows"]) < 25 else 2
        st["people"] = {pid: n for pid, n in counts.items() if n >= need}
        for pid in st["people"]:
            person_stations.setdefault(pid, []).append(index)

    # Wiederkehrende Orte: Reisen mit nahem Mittelpunkt (60 km)
    clusters = []
    for index, st in enumerate(stations):
        located = [r for r in st["rows"] if _located(r)]
        if located:
            st["lat"] = round(_median([r["lat"] for r in located]), 4)
            st["lon"] = round(_median([r["lon"] for r in located]), 4)
            if st["places"]:
                st["lat"], st["lon"] = st["places"][0]["lat"], st["places"][0]["lon"]
        else:
            st["lat"] = st["lon"] = None
        if st["kind"] != "trip" or st["lat"] is None:
            continue
        near = None
        for cluster in clusters:
            if trips.haversine(cluster["lat"], cluster["lon"], st["lat"], st["lon"]) < 60:
                near = cluster
                break
        if near:
            near["stations"].append(index)
        else:
            clusters.append({"lat": st["lat"], "lon": st["lon"], "stations": [index]})
    home_events = [i for i, st in enumerate(stations) if st["kind"] in ("event", "move")]

    # Ortsnamen
    def city_counts(st):
        counts = {}
        for row in st["rows"]:
            city, _country = split_place(row.get("place"))
            if city:
                counts[city] = counts.get(city, 0) + 1
        return counts

    country_count = {}
    for row in dated[:: max(1, len(dated) // 4000)]:
        if row.get("place") and homes:
            here = trips.home_at(homes, _date(row["t"]))
            if _located(row) and trips.haversine(here["lat"], here["lon"], row["lat"], row["lon"]) < opts.min_km:
                country = split_place(row["place"])[1]
                if country:
                    country_count[country] = country_count.get(country, 0) + 1
    home_country = max(country_count, key=country_count.get) if country_count else ""

    def place_of(st):
        """(Name, Land) einer Haltestelle aus den Fotos, sonst Nominatim."""
        counts = city_counts(st)
        countries = {}
        for row in st["rows"]:
            country = split_place(row.get("place"))[1]
            if country:
                countries[country] = countries.get(country, 0) + 1
        if not counts and namer:
            for spot in (st["places"] or [])[:3] or ([{"lat": st["lat"], "lon": st["lon"], "photos": 1}]
                                                       if st["lat"] is not None else []):
                found = namer(spot["lat"], spot["lon"])
                city, country = split_place(found)
                if city:
                    counts[city] = counts.get(city, 0) + int(spot.get("photos") or 1)
                if country:
                    countries[country] = countries.get(country, 0) + int(spot.get("photos") or 1)
        country = max(countries, key=countries.get) if countries else ""
        if not counts:
            return "", country
        ranked = sorted(counts.items(), key=lambda item: item[1], reverse=True)
        top = ranked[0][1]
        strong = [name for name, n in ranked if n >= 0.25 * top][:4]
        if len(strong) >= 3 and country and len(countries) == 1:
            return country, country
        return " · ".join(strong[:2]), country

    for st in stations:
        st["name"], st["country"] = place_of(st) if (st["kind"] == "trip" or st["lat"] is not None) else ("", "")
        st["city"] = st["name"]
        if st["kind"] == "event":
            st["name"] = ""          # die Szene nennt das Fest (Datum, Feiertag, Geburtstag)
        group = group_name(st["rows"], broad)
        if group:
            st["name"] = group
        st["holiday"] = holiday(_date(st["start"]), _date(st["end"])) if st["kind"] == "event" else ""
        st["birthday"] = ""
        if st["kind"] == "event" and opts.birthdays:
            md = {(_date(st["start"]) + datetime.timedelta(days=d)).strftime("%m-%d")
                  for d in range((_date(st["end"]) - _date(st["start"])).days + 1)}
            for pid, birthday in opts.birthdays.items():
                if birthday in md and pid in st["people"]:
                    st["birthday"] = names.get(pid, "")
                    break

    # Linien wählen
    def people_lines():
        if opts.people:
            order = [pid for pid in opts.people if person_stations.get(pid) and pid != opts.main]
        else:
            order = sorted((pid for pid, idx in person_stations.items() if len(idx) >= 2 and pid != opts.main),
                           key=lambda pid: (-len(person_stations[pid]), names.get(pid, "")))
        return [{"kind": "person", "id": pid, "name": names.get(pid, "?"), "stations": person_stations[pid]}
                for pid in order]

    def place_lines():
        out = []
        for cluster in clusters:
            if len(cluster["stations"]) < 2:
                continue
            counts = {}
            for idx in cluster["stations"]:
                name = stations[idx]["name"]
                if name:
                    counts[name] = counts.get(name, 0) + 1
            name = max(counts, key=counts.get) if counts else ""
            out.append({"kind": "place", "id": f"place-{cluster['stations'][0]}", "name": name,
                        "stations": cluster["stations"]})
        out.sort(key=lambda line: -len(line["stations"]))
        if len(home_events) >= 2:
            out.append({"kind": "home", "id": "home", "name": "", "stations": home_events})
        return out

    kind = opts.line_kind
    persons = people_lines() if kind in ("auto", "people", "mixed") else []
    if kind == "auto":
        chosen = persons[:opts.line_count] if persons else place_lines()[:opts.line_count]
    elif kind == "people":
        chosen = persons[:opts.line_count]
    elif kind == "places":
        chosen = place_lines()[:opts.line_count]
    else:
        places = place_lines()
        half = max(1, opts.line_count // 2)
        chosen = persons[:max(half, opts.line_count - len(places))]
        chosen += places[:opts.line_count - len(chosen)]
    lines = [_trunk()]
    if opts.main and names.get(opts.main):
        lines[0].update(id=opts.main, person=True, name=names[opts.main])
    for number, line in enumerate(chosen):
        lines.append({"id": str(line["id"]), "kind": line["kind"], "name": line["name"],
                      "color": PALETTE[number % len(PALETTE)], "n": len(line["stations"])})
        for idx in line["stations"]:
            stations[idx].setdefault("lines", []).append(number + 1)

    # Fotos je Haltestelle
    photos, out_stations = [], []
    for index, st in enumerate(stations):
        on = sorted(st.get("lines") or [])
        wanted = [chosen[i - 1]["id"] for i in on if chosen[i - 1]["kind"] == "person"]
        if opts.main and opts.main in (st.get("people") or {}):
            wanted.append(opts.main)
        picked = pick(st["rows"], opts.keep_photos, wanted, opts.min_stars, seed=st["start"])
        refs = []
        for row in picked:
            refs.append(len(photos))
            photos.append({"k": row["k"], "stamp": row.get("stamp") or "", "t": row["t"],
                           "place": split_place(row.get("place"))[0],
                           "who": [p[1] for p in row.get("people") or [] if p[1]][:6]})
        who = sorted(((names.get(pid, ""), n) for pid, n in (st.get("people") or {}).items() if names.get(pid)),
                     key=lambda item: -item[1])
        out_stations.append({
            "kind": st["kind"], "a": st["start"], "b": st["end"], "name": st["name"][:48],
            "country": st["country"][:40], "city": st["city"][:48], "n": len(st["rows"]), "km": round(st.get("far") or 0),
            "l": on, "p": refs, "lat": st["lat"], "lon": st["lon"],
            "who": [name for name, _n in who[:8]], "holiday": st["holiday"], "birthday": st["birthday"],
        })
    return {
        "stations": out_stations,
        "lines": lines,
        "photos": photos,
        "homes": [{"from": h["from"], "to": h["to"], "lat": h["lat"], "lon": h["lon"]} for h in homes],
        "homeCountry": home_country,
        "count": len(dated),
        "from": int(dated[0]["t"][:4]),
        "to": int(dated[-1]["t"][:4]),
    }


def _trunk():
    return {"id": "trunk", "kind": "trunk", "name": "", "color": TRUNK_COLOR, "n": 0}
