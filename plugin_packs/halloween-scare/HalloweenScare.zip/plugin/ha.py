"""Die Verbindung zu Home Assistant: REST für Listen und Kamerabilder, der
Websocket für Zustandsänderungen in dem Moment, in dem sie passieren.

Alles bleibt im eigenen Netz: das Plugin spricht nur mit der Adresse, die der
Besitzer einträgt, und meldet sich mit seinem langlebigen Zugangstoken an.
"""

import json
import re
import threading
import time

import requests

try:
    import websocket  # websocket-client
except ImportError:  # pragma: no cover - steht in requirements.txt
    websocket = None

CONNECT_TIMEOUT = 6
READ_TIMEOUT = 15
PING_SECONDS = 30
INVALID = {"unavailable", "unknown", "", None}


class HaError(Exception):
    pass


def normalize_url(raw):
    """"192.168.1.5", "homeassistant.local:8123/" oder "https://ha.example.org"
    werden zu einer Basisadresse ohne Schrägstrich am Ende. Ohne Port und
    ohne http(s):// nimmt es den Standardport 8123 an."""
    text = str(raw or "").strip().rstrip("/")
    if not text:
        return ""
    if not re.match(r"^https?://", text, re.I):
        host = text.split("/", 1)[0]
        if ":" not in host.rsplit("]", 1)[-1]:
            text = text.replace(host, host + ":8123", 1)
        text = "http://" + text
    text = re.sub(r"/(lovelace|config|profile|dashboard)[^ ]*$", "", text)  # aus der Adresszeile kopiert
    return text.rstrip("/")


def ws_url(base):
    return re.sub(r"^http", "ws", base, flags=re.I) + "/api/websocket"


class Rest:
    def __init__(self, base, token):
        self.base = base
        self.token = token

    def _get(self, path, timeout=READ_TIMEOUT, stream=False):
        if not self.base:
            raise HaError("no-url")
        if not self.token:
            raise HaError("no-token")
        try:
            response = requests.get(self.base + path, timeout=(CONNECT_TIMEOUT, timeout), stream=stream,
                                    headers={"Authorization": f"Bearer {self.token}"})
        except requests.exceptions.SSLError as exc:
            raise HaError(f"ssl:{exc}") from exc
        except requests.RequestException as exc:
            raise HaError(f"unreachable:{exc}") from exc
        if response.status_code == 401:
            raise HaError("token")
        if response.status_code == 404:
            raise HaError("not-found")
        if response.status_code >= 400:
            raise HaError(f"http:{response.status_code}")
        return response

    def config(self):
        return self._get("/api/config").json()

    def states(self):
        rows = self._get("/api/states", timeout=30).json()
        return [r for r in rows if isinstance(r, dict) and r.get("entity_id")]

    def camera(self, entity_id):
        response = self._get(f"/api/camera_proxy/{entity_id}", timeout=10)
        kind = response.headers.get("Content-Type", "image/jpeg").split(";")[0]
        return response.content, kind


class Stream:
    """Hält den Websocket offen, verbindet nach einem Abbruch neu und ruft für
    jede Änderung `on_change(entity_id, old, new, attributes)` auf, für
    Ereignisse vom Typ halloween_scare `on_custom(data)`.

    Abonniert werden nur die Entitäten, die gebraucht werden
    (subscribe_entities); ein Home Assistant, das das nicht kennt, bekommt
    stattdessen state_changed.
    """

    def __init__(self, log, on_change, on_custom, on_status):
        self.log = log
        self.on_change = on_change
        self.on_custom = on_custom
        self.on_status = on_status
        self._config = None          # (base, token, frozenset(entity_ids))
        self._wanted = threading.Event()
        self._stop = threading.Event()
        self._socket = None
        self._lock = threading.Lock()
        self.states = {}             # entity_id -> {"s": state, "a": attributes}
        self.status = {"state": "off", "error": "", "since": 0.0}
        threading.Thread(target=self._run, name="HalloweenScare-ws", daemon=True).start()

    def configure(self, base, token, entity_ids):
        config = (base, token, frozenset(entity_ids))
        with self._lock:
            if config == self._config:
                return
            self._config = config
        self._wanted.set()   # zuerst: das Schließen ist dann kein Fehler
        self._close()

    def stop(self):
        self._stop.set()
        self._wanted.set()
        self._close()

    def _close(self):
        sock = self._socket
        if sock is not None:
            try:
                sock.close()
            except Exception:
                pass

    def _set_status(self, state, error=""):
        if self.status["state"] != state or self.status["error"] != error:
            self.status = {"state": state, "error": error, "since": time.time()}
            self.on_status(state, error)

    def _run(self):
        delay = 2
        while not self._stop.is_set():
            with self._lock:
                config = self._config
            if not config or not config[0] or not config[1]:
                self._set_status("off")
                self._wanted.wait()
                self._wanted.clear()
                continue
            self._wanted.clear()
            started = time.time()
            try:
                self._session(*config)
            except Exception as exc:  # Netz weg, HA neu gestartet, falsches Token, ...
                # Selbst geschlossen, weil sich die Einstellungen geändert haben: kein Fehler.
                if not self._wanted.is_set() and not self._stop.is_set():
                    self._set_status("error", str(exc) if isinstance(exc, HaError) else f"unreachable:{exc}")
            if self._stop.is_set():
                break
            if self._wanted.is_set():
                delay = 2  # neue Einstellungen: sofort neu verbinden
                continue
            if time.time() - started > 120:
                delay = 2
            if self.status["error"] == "token":
                delay = 300  # ein falsches Token wird nicht durch Warten richtig
            self._wanted.wait(delay)
            delay = min(delay * 2, 60)

    def _session(self, base, token, entity_ids):
        if websocket is None:
            raise HaError("no-websocket-client")
        self._set_status("connecting")
        sock = websocket.create_connection(ws_url(base), timeout=CONNECT_TIMEOUT + 4,
                                           enable_multithread=True)
        self._socket = sock
        try:
            hello = json.loads(sock.recv())
            if hello.get("type") == "auth_required":
                sock.send(json.dumps({"type": "auth", "access_token": token}))
                answer = json.loads(sock.recv())
                if answer.get("type") != "auth_ok":
                    raise HaError("token")
            ids = sorted(entity_ids)
            next_id = 1
            sub_entities = sub_changed = None
            if ids:
                sub_entities = next_id
                sock.send(json.dumps({"id": next_id, "type": "subscribe_entities", "entity_ids": ids}))
                next_id += 1
            sub_custom = next_id
            sock.send(json.dumps({"id": next_id, "type": "subscribe_events", "event_type": "halloween_scare"}))
            next_id += 1
            self._set_status("connected")
            sock.settimeout(PING_SECONDS)
            last_ping = time.time()
            waiting_pong = None
            while not self._stop.is_set() and not self._wanted.is_set():
                try:
                    raw = sock.recv()
                except websocket.WebSocketTimeoutException:
                    raw = None
                if raw is None or time.time() - last_ping >= PING_SECONDS:
                    if waiting_pong is not None:
                        raise HaError("unreachable:no pong")
                    waiting_pong = next_id
                    sock.send(json.dumps({"id": next_id, "type": "ping"}))
                    next_id += 1
                    last_ping = time.time()
                if not raw:
                    if raw == "":
                        raise HaError("unreachable:closed")
                    continue
                message = json.loads(raw)
                kind = message.get("type")
                if kind == "pong":
                    if message.get("id") == waiting_pong:
                        waiting_pong = None
                    continue
                if kind == "result":
                    if message.get("id") == sub_entities and not message.get("success"):
                        # Altes Home Assistant: alle Zustandsänderungen nehmen und filtern.
                        sub_changed = next_id
                        sock.send(json.dumps({"id": next_id, "type": "subscribe_events",
                                              "event_type": "state_changed"}))
                        next_id += 1
                        self._seed(base, token, ids)
                    elif not message.get("success") and message.get("id") == sub_custom:
                        self.log("Home Assistant erlaubt kein Abo von halloween_scare-Ereignissen "
                                 "(Token eines Benutzers ohne Admin-Rechte?).", level="warning")
                    continue
                if kind != "event":
                    continue
                event = message.get("event") or {}
                if message.get("id") == sub_entities:
                    self._compressed(event)
                elif message.get("id") == sub_changed:
                    self._state_changed(event, entity_ids)
                elif message.get("id") == sub_custom:
                    self.on_custom(event.get("data") or {})
        finally:
            self._socket = None
            try:
                sock.close()
            except Exception:
                pass

    def _seed(self, base, token, ids):
        try:
            for row in Rest(base, token).states():
                if row["entity_id"] in ids:
                    self.states[row["entity_id"]] = {"s": row.get("state"), "a": row.get("attributes") or {}}
        except HaError:
            pass

    def _compressed(self, event):
        """subscribe_entities: "a" = alle Zustände (erst einmal, nach jedem
        Verbinden), "c" = Änderungen mit "+" und "-", "r" = entfernt."""
        for entity_id, row in (event.get("a") or {}).items():
            before = self.states.get(entity_id)
            now = {"s": row.get("s"), "a": row.get("a") or {}}
            self.states[entity_id] = now
            if before is not None and before["s"] != now["s"]:
                # Während der Verbindung weg war, hat sich etwas geändert. Das
                # ist kein Ereignis von jetzt; nur merken.
                self.on_change(entity_id, before["s"], now["s"], now["a"], fresh=False)
        for entity_id, diff in (event.get("c") or {}).items():
            row = self.states.setdefault(entity_id, {"s": None, "a": {}})
            old = row["s"]
            plus = diff.get("+") or {}
            if "a" in plus:
                row["a"] = dict(row["a"], **plus["a"])
            for key in (diff.get("-") or {}).get("a") or []:
                row["a"].pop(key, None)
            if "s" in plus:
                row["s"] = plus["s"]
                if plus["s"] != old:
                    self.on_change(entity_id, old, plus["s"], row["a"], fresh=True)
        for entity_id in event.get("r") or []:
            self.states.pop(entity_id, None)

    def _state_changed(self, event, entity_ids):
        data = event.get("data") or {}
        entity_id = data.get("entity_id")
        if entity_id not in entity_ids:
            return
        new = data.get("new_state") or {}
        old = (data.get("old_state") or {}).get("state")
        self.states[entity_id] = {"s": new.get("state"), "a": new.get("attributes") or {}}
        if new.get("state") != old:
            self.on_change(entity_id, old, new.get("state"), new.get("attributes") or {}, fresh=True)
