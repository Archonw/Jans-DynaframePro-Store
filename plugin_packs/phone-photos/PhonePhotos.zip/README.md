# Phone Photos

Phone Photos zeigt das Foto, das du gerade auf dem Handy anschaust, **sofort auf dem Rahmen**: auf dem iPhone und auf Android, ohne eigene App. Das Foto füllt ein paar Minuten lang den Bildschirm (einstellbar), mehrere kurz hintereinander geschickte Fotos wechseln sich ab. Danach läuft die Playlist weiter.

Das Paket besteht aus zwei Teilen:

- **Das Plugin** nimmt Fotos im WLAN an (Port 8095), dreht sie wie aufgenommen, verkleinert sie auf Bildschirmgröße und hebt die letzten auf, damit man sie noch einmal zeigen kann.
- **Die Szene Phone Photos** zeigt die Fotos (ganzes Foto vor unscharfem Hintergrund oder bildschirmfüllend) und wird nur geholt, solange ein Foto zu sehen sein soll.

## Einrichten

1. Paket installieren (Store oder Plugins > Hochladen).
2. Auf der Plugins-Seite bei Phone Photos **Allow takeover** einschalten.
3. Plugin-Seite öffnen. Dort stehen die Wege aufs Handy, mit der Adresse des Rahmens schon eingetragen:
   - **Handy-Seite** `http://<rahmen>:8095/` (QR-Code auf der Plugin-Seite): Fotos wählen, fertig. Lässt sich auf den Home-Bildschirm legen.
   - **iPhone:** ein Kurzbefehl „Auf DynaFrame“ im Teilen-Menü der Fotos-App (Schritte auf der Plugin-Seite).
   - **Android:** die kostenlose App „HTTP Shortcuts“ trägt „Auf DynaFrame“ ins Teilen-Menü der Galerie ein (Schritte auf der Plugin-Seite).

## Für Bastler

- `POST http://<rahmen>:8095/upload?from=<Name>` mit dem Bild als Body (JPEG, PNG, WebP, GIF) oder als `multipart/form-data` (auch mehrere Dateien). Antwort: `{"success": true, "ids": [...]}`.
- Ist auf der Plugin-Seite ein Code gesetzt: `&pin=<Code>` oder Header `X-Pin`.
- `POST /api/control` mit `{"action": "hide"}`, `{"action": "last"}` oder `{"action": "show", "id": "<id>"}`.
- HEIC vom iPhone: im Kurzbefehl „Bild konvertieren“ in JPEG (die Handy-Seite macht das selbst).

Fotos bleiben nur auf dem Rahmen (Plugin-Ordner `data/photos`), höchstens so viele wie eingestellt.
