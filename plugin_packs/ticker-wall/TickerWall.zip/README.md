# Ticker Wall

Ticker Wall turns the frame into a news-channel and trading-floor wall: news feeds, stock prices, crypto, currencies, world clocks, weather and earthquakes, all scrolling at once. Far too much to follow, and that's the point.

The package has two parts that are installed together:

- **The Ticker Wall scene**: world clocks with weather, a stock tape, market tiles that flip through your watchlist, the top stories with pictures, a topic radar, the news pace of the last 24 hours, a scrolling newswire, crypto with 7-day curves, a market mood gauge, gainers and losers, and three crawls at the bottom. Two looks: **news channel** (red and blue) and **trading terminal** (black and amber), or both alternating. Landscape and portrait.
- **The plugin** reads the sources, keeps the headlines of the last 48 hours on the frame, works out what is going on and shows the scene over the playlist when an alert fires.

## Setting up

1. Install the package (Plugins > Upload, or from the store).
2. Open **Open Ticker Wall** on the Plugins page, enter a free **Finnhub key** for stock prices (optional), pick your **region** (international, US, UK, Germany, Spain) and press *Fill lists for this region*. That fills news feeds, watchlist, crypto currency, cities and market bells. Change any list afterwards as you like.
3. Add the scene to a playlist, or let the plugin create the playlist "Ticker Wall".
4. For alerts over the playlist: switch on **Allow takeover** for Ticker Wall on the Plugins page.

## What it works out

- **Topic radar:** which terms and names appear in many sources right now, compared with the hours before (new, rising, falling).
- **Breaking news:** several sources report the same new topic within 45 minutes, or a feed marks a headline as breaking itself.
- **News pace:** stories per hour over the last day, from calm to hectic.
- **Market mood:** breadth and average move of your watchlist and crypto, 0 (panic) to 100 (euphoria).
- **Gainers and losers** of the day.

## Alerts

Each one can be switched on separately on the plugin page:

- **Keywords** in a headline (e.g. your town, a company, a team).
- **Breaking news** as above.
- **Price rules:** `NVDA > 150`, `AAPL < 180`, `TSLA ± 5%` (or `+-5%`), `BTC ± 3%`.
- **Any stock** of the watchlist moves by X % today.
- **Crash or rally:** the main index moves by X %.
- **Market bell:** when NYSE, Xetra, LSE, BME or Tokyo open.
- **Earthquake** from magnitude X (USGS).

An alert shows big for a few seconds, then stays as a red band at the top while the wall runs. At most one alert every X minutes, only between *From* and *To*, never wakes a screen that is off. **Test alert** shows how it looks.

## Sources

Free, no keys: the news outlets' own RSS/Atom feeds (any feed you add), CoinGecko, ECB rates via Frankfurter (currencies), Open-Meteo, USGS.

Stock prices: **Finnhub** with your own free key (finnhub.io/register; 60 calls a minute, Ticker Wall makes at most one a second). The free plan covers US stocks and ETFs, so indices, other countries and commodities come through ETFs that follow them (e.g. EWG for Germany, GLD for gold, shown with the ETF in brackets; the move is the ETF's in US dollars) and European companies through their US listings (SAP, SIEGY, SHEL …). Finnhub's free plan has no day charts, so the wall draws the curves from its own reads; they fill up during the day. Without a key the tiles show crypto and currencies. Not investment advice.

## Automations

Actions: **Show**, **Stop**, **Toggle**, **Refresh now**, **Test alert**.

Events: **tickerwall_alert** (kind, label, title, detail, source, symbol), **tickerwall_display_started** and **tickerwall_display_ended** (reason).

## Licences

Fonts: Barlow Condensed and JetBrains Mono, SIL Open Font License 1.1 (files in `dynamic/fonts`).
