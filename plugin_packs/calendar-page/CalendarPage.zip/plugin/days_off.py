"""Feiertage und Schulferien.

- Feiertage rechnet das Paket `holidays` auf dem Rahmen selbst aus (über
  150 Länder mit Bundesländern/Regionen, kein Internet nötig).
- Schulferien kommen von der freien OpenHolidays API (openholidaysapi.org,
  vor allem Europa) und werden je Land und Jahr eine Woche lang gemerkt.
"""

import datetime
import json
import os
import threading
import time

import requests

try:
    import holidays as holidays_lib  # type: ignore
except Exception:  # pragma: no cover - kommt mit requirements.txt
    holidays_lib = None

OPENHOLIDAYS = os.environ.get("CALENDARPAGE_OPENHOLIDAYS_URL", "https://openholidaysapi.org")
CACHE_DAYS = 7
CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30
# Länder mit Schulferien bei OpenHolidays (Stand 2026).
SCHOOL_COUNTRIES = {"AD", "AL", "AT", "BE", "BG", "BR", "BY", "CH", "CZ", "DE", "EE", "ES", "FR", "HR", "HU", "IE",
                    "IT", "LI", "LT", "LU", "LV", "MC", "MD", "MT", "MX", "NL", "PL", "PT", "RO", "RS", "SE", "SI",
                    "SK", "SM", "VA", "ZA"}
# Diese Länder fangen die Woche mit Sonntag an.
SUNDAY_FIRST = {"US", "CA", "BR", "MX", "JP", "IL", "PH", "ZA", "AU", "IN", "KR", "TW", "HK", "SA", "AR", "CO", "PE"}


class DaysOffError(Exception):
    pass


def countries(lang):
    """[{code, name, regions:[{code, name}]}] - alles, was `holidays` kennt."""
    if holidays_lib is None:
        return []
    names = _country_names(lang)
    out = []
    for code, subdivs in sorted(holidays_lib.list_supported_countries().items()):
        try:
            entity = holidays_lib.country_holidays(code)
        except Exception:  # noqa: BLE001
            continue
        aliases = {}
        for alias, sub in (getattr(entity, "subdivisions_aliases", None) or {}).items():
            if len(alias) > len(aliases.get(sub, "")):
                aliases[sub] = alias                # der längste Name ist der lesbarste
        regions = [{"code": s, "name": aliases.get(s, s)} for s in subdivs if len(s) <= 6]
        out.append({"code": code, "name": names.get(code) or code, "regions": regions,
                    "school": code in SCHOOL_COUNTRIES})
    return sorted(out, key=lambda c: c["name"].lower())


def _country_names(lang):
    """Ländernamen in der Sprache, soweit wir sie kennen (sonst Englisch über pycountry-freie Liste)."""
    try:
        from babel import Locale  # type: ignore
        return {k: v for k, v in Locale.parse(lang).territories.items()}
    except Exception:  # noqa: BLE001 - babel ist nicht Pflicht
        pass
    return COUNTRY_NAMES.get(lang) or COUNTRY_NAMES["en"]


def public(country, region, year, lang):
    """[{date, name}] für ein Jahr."""
    if holidays_lib is None or not country:
        return []
    languages = {"de": ("de",), "en": ("en_US", "en_GB", "en"), "es": ("es",)}.get(lang, ())
    try:
        probe = holidays_lib.country_holidays(country)
        supported = set(getattr(probe, "supported_languages", ()) or ())
    except Exception:  # noqa: BLE001
        return []
    language = next((code for code in languages if code in supported), None)
    kwargs = {"years": year}
    if region:
        kwargs["subdiv"] = region
    if language:
        kwargs["language"] = language
    try:
        table = holidays_lib.country_holidays(country, **kwargs)
    except Exception:  # noqa: BLE001 - z. B. Region gibt es nicht mehr
        kwargs.pop("subdiv", None)
        table = holidays_lib.country_holidays(country, **kwargs)
    return [{"date": day.isoformat(), "name": str(name)} for day, name in sorted(table.items())]


class School:
    """Schulferien von OpenHolidays, gemerkt in data/school.json."""

    def __init__(self, data_dir, log):
        self.file = os.path.join(str(data_dir), "school.json")
        self.log = log
        self.lock = threading.Lock()
        self.data = None
        self.error = ""
        self.at = 0.0

    def _load(self):
        if self.data is None:
            try:
                with open(self.file, "r", encoding="utf-8") as handle:
                    self.data = json.load(handle)
            except (OSError, ValueError):
                self.data = {}
        return self.data

    def _save(self):
        temp = self.file + ".tmp"
        with open(temp, "w", encoding="utf-8") as handle:
            json.dump(self.data, handle, ensure_ascii=False, separators=(",", ":"))
        os.replace(temp, self.file)

    def periods(self, country, region, year, lang, allow_fetch=True):
        """[{start, end, name}] (end inklusive) für ein Jahr, oder [] ohne Daten."""
        if country not in SCHOOL_COUNTRIES:
            return []
        key = f"{country}|{year}|{lang}"
        with self.lock:
            table = self._load()
            entry = table.get(key)
        fresh = entry and time.time() - entry.get("at", 0) < CACHE_DAYS * 86400
        if not fresh and allow_fetch:
            try:
                rows = self.fetch(country, year, lang)
                entry = {"at": time.time(), "rows": rows}
                with self.lock:
                    self._load()[key] = entry
                    self._save()
                self.error = ""
                self.at = time.time()
            except DaysOffError as exc:
                self.error = str(exc)
                self.log(f"Schulferien {country} {year}: {exc}", "warning")
        if not entry:
            return []
        keys = region_keys(country, region)
        return [{"start": r["start"], "end": r["end"], "name": r["name"]}
                for r in entry["rows"] if matches(r, keys)]

    def fetch(self, country, year, lang):
        params = {"countryIsoCode": country, "languageIsoCode": (lang or "en").upper(),
                  "validFrom": f"{year}-01-01", "validTo": f"{year}-12-31"}
        try:
            response = requests.get(f"{OPENHOLIDAYS}/SchoolHolidays", params=params,
                                    timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), headers={"Accept": "application/json"})
        except requests.RequestException as exc:
            raise DaysOffError(str(exc)[:160]) from exc
        if response.status_code >= 400:
            raise DaysOffError(f"HTTP {response.status_code}")
        try:
            data = response.json()
        except ValueError as exc:
            raise DaysOffError("no JSON") from exc
        rows = []
        for row in data if isinstance(data, list) else []:
            names = row.get("name") or []
            name = next((n.get("text") for n in names if str(n.get("language", "")).lower() == (lang or "en")), None)
            name = name or (names[0].get("text") if names else "")
            subs = []
            for sub in row.get("subdivisions") or []:
                subs += [str(sub.get("code") or ""), str(sub.get("shortName") or "")]
            rows.append({"start": str(row.get("startDate") or "")[:10], "end": str(row.get("endDate") or "")[:10],
                         "name": str(name or "")[:60], "all": bool(row.get("nationwide")),
                         "subs": [s for s in subs if s]})
        return rows

    def probe(self):
        started = time.time()
        try:
            response = requests.get(f"{OPENHOLIDAYS}/Countries", params={"languageIsoCode": "EN"},
                                    timeout=(CONNECT_TIMEOUT, 15), headers={"Accept": "application/json"})
            if response.status_code >= 400:
                return False, 0, f"HTTP {response.status_code}"
        except requests.RequestException as exc:
            return False, 0, str(exc)[:160]
        return True, int((time.time() - started) * 1000), ""


def region_keys(country, region):
    """Alle Schreibweisen einer Region (Code und Namen), groß geschrieben."""
    if not region:
        return set()
    keys = {region.upper()}
    try:
        entity = holidays_lib.country_holidays(country) if holidays_lib else None
        for alias, sub in (getattr(entity, "subdivisions_aliases", None) or {}).items():
            if sub == region:
                keys.add(str(alias).upper())
    except Exception:  # noqa: BLE001
        pass
    return keys


def matches(row, keys):
    """Bundesweite Ferien immer, regionale nur für die gewählte Region."""
    if row.get("all") or not row.get("subs"):
        return True
    if not keys:
        return False
    for sub in row["subs"]:
        sub = sub.upper()
        if sub in keys or sub.rsplit("-", 1)[-1] in keys:
            return True
    return False


def week_starts_sunday(country):
    return country in SUNDAY_FIRST


def year_span(start, end):
    return list(range(start.year, end.year + 1))


def today():
    return datetime.date.today()


# Häufige Länder, falls babel fehlt (die übrigen zeigen ihren Code).
COUNTRY_NAMES = {
    "de": {"DE": "Deutschland", "AT": "Österreich", "CH": "Schweiz", "ES": "Spanien", "FR": "Frankreich",
           "IT": "Italien", "NL": "Niederlande", "BE": "Belgien", "LU": "Luxemburg", "DK": "Dänemark",
           "PL": "Polen", "CZ": "Tschechien", "PT": "Portugal", "GB": "Vereinigtes Königreich", "IE": "Irland",
           "US": "Vereinigte Staaten", "CA": "Kanada", "SE": "Schweden", "NO": "Norwegen", "FI": "Finnland",
           "GR": "Griechenland", "HR": "Kroatien", "HU": "Ungarn", "SI": "Slowenien", "SK": "Slowakei",
           "TR": "Türkei", "MX": "Mexiko", "AR": "Argentinien", "BR": "Brasilien", "AU": "Australien",
           "NZ": "Neuseeland", "LI": "Liechtenstein", "RO": "Rumänien", "BG": "Bulgarien"},
    "en": {"DE": "Germany", "AT": "Austria", "CH": "Switzerland", "ES": "Spain", "FR": "France", "IT": "Italy",
           "NL": "Netherlands", "BE": "Belgium", "LU": "Luxembourg", "DK": "Denmark", "PL": "Poland",
           "CZ": "Czechia", "PT": "Portugal", "GB": "United Kingdom", "IE": "Ireland", "US": "United States",
           "CA": "Canada", "SE": "Sweden", "NO": "Norway", "FI": "Finland", "GR": "Greece", "HR": "Croatia",
           "HU": "Hungary", "SI": "Slovenia", "SK": "Slovakia", "TR": "Türkiye", "MX": "Mexico",
           "AR": "Argentina", "BR": "Brazil", "AU": "Australia", "NZ": "New Zealand", "LI": "Liechtenstein",
           "RO": "Romania", "BG": "Bulgaria"},
    "es": {"DE": "Alemania", "AT": "Austria", "CH": "Suiza", "ES": "España", "FR": "Francia", "IT": "Italia",
           "NL": "Países Bajos", "BE": "Bélgica", "LU": "Luxemburgo", "DK": "Dinamarca", "PL": "Polonia",
           "CZ": "Chequia", "PT": "Portugal", "GB": "Reino Unido", "IE": "Irlanda", "US": "Estados Unidos",
           "CA": "Canadá", "SE": "Suecia", "NO": "Noruega", "FI": "Finlandia", "GR": "Grecia", "HR": "Croacia",
           "HU": "Hungría", "SI": "Eslovenia", "SK": "Eslovaquia", "TR": "Turquía", "MX": "México",
           "AR": "Argentina", "BR": "Brasil", "AU": "Australia", "NZ": "Nueva Zelanda", "LI": "Liechtenstein",
           "RO": "Rumanía", "BG": "Bulgaria"},
}
