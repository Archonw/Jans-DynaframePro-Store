"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Jede Änderung an Wikipedia weltweit als Lichtpunkt am Ort ihrer Sprache.": (
        "Every change to Wikipedia worldwide as a point of light where its language is spoken.",
        "Cada cambio en Wikipedia en todo el mundo como un punto de luz donde se habla su idioma."),
    "Verbindet sich für eine Minute mit dem Datenstrom.": (
        "Connecting to the live stream for one minute.",
        "Conectando con la transmisión en directo durante un minuto."),
}


def t(language, text, **values):
    row = _TEXTS.get(text)
    if row and language in LANGUAGES[1:]:
        text = row[LANGUAGES.index(language) - 1]
    for key, value in values.items():
        text = text.replace("{" + key + "}", str(value))
    return text
