#!/usr/bin/env python3
"""Life Lines - der Plugin-Teil des Pakets "Life Lines" (Dein Leben als U-Bahn-Plan).

Die Szene "life-lines" zeichnet die Jahre als Linienplan: Linien stehen für
Personen oder Orte, Haltestellen für Reisen und Feste, und wo Linien sich an
einer Haltestelle treffen, gibt es gemeinsame Fotos. Eine Kamera fährt den
Plan entlang und hält an jeder Haltestelle kurz mit ein paar Fotos an.

Dieses Plugin
- liest die Fotos ein (DynaFrame: Mediendatenbank, Ordner, Playlists;
  Immich: alle Fotos oder Alben, mit den benannten Personen),
- findet Wohnorte, Umzüge, Reisen (trips.py, gemeinsam mit Travel Scrapbook)
  und Feste (Tage mit vielen Fotos) und macht daraus Haltestellen und Linien
  (plan.py),
- verkleinert die Fotos der Haltestellen für die Szene.
"""

import datetime
import hashlib
import io
import json
import os
import re
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import exif_gps  # noqa: E402
import dynaframe_filters  # noqa: E402
import immich_filters  # noqa: E402
import own_playlist  # noqa: E402
import places  # noqa: E402
import plan  # noqa: E402
import sources  # noqa: E402
import texts  # noqa: E402
import photo_privacy  # noqa: E402

try:
    from PIL import Image, ImageOps
except ImportError:  # pragma: no cover - kommt mit requirements.txt
    Image = ImageOps = None

HEIF = False
if Image is not None:
    try:
        from pillow_heif import register_heif_opener  # type: ignore

        register_heif_opener()
        HEIF = True
    except Exception:  # noqa: BLE001 - optional
        HEIF = False

plugin = create_plugin()

PLUGIN_ID = "LifeLines"
SCENE_ID = "life-lines"             # id in scene.dynamic - nie ändern
PLAYLIST_NAME = "Life Lines"
PLAYLIST_NAMES = {"de": PLAYLIST_NAME, "en": PLAYLIST_NAME, "es": PLAYLIST_NAME}
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen, Caches; bleibt bei Updates
PHOTO_DIR = DATA_DIR / "photos"
INDEX_FILE = DATA_DIR / "index.json"
PLAN_FILE = DATA_DIR / "plan.json"

CONNECT_TIMEOUT = 10
MAX_SOURCES = 6
PHOTO_EDGE = 1600                   # lange Seite der Fotos für die Szene
KEEP_PHOTOS = 8                     # so viele Fotos merkt sich jede Haltestelle

KINDS = ("library", "playlist", "immich_all", "immich_album")


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def as_float(value, default=None):
    try:
        number = float(str(value).strip().replace(",", "."))
    except (TypeError, ValueError):
        return default
    return default if number != number else number


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält den API-Schlüssel
        except OSError:
            pass


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

def default_sources():
    return [{"id": "s1", "kind": "library", "ref": "", "name": ""}]


SCHEMA = {
    "Language":        {"kind": "choice", "default": "en", "choices": texts.LANGUAGES},
    "ServerUrl":       {"kind": "url", "default": ""},
    "ApiKey":          {"kind": "secret", "default": ""},
    "Sources":         {"kind": "sources", "default": None},
    "Folders":         {"kind": "folders", "default": ""},
    # Welche Immich-Fotos überhaupt (wie Growing Up)
    "Albums":          {"kind": "albums", "default": []},
    # Immich- und DynaFrame-Filter wie Photo Mosaic (ohne "an diesem Tag")
    **immich_filters.schema(without=("OnThisDay",)),
    **dynaframe_filters.schema(without=("DfOnThisDay",)),
    # Linien
    "LineKind":        {"kind": "choice", "default": "auto", "choices": ("auto", "people", "places", "mixed")},
    "LineCount":       {"kind": "int", "default": 6, "min": 1, "max": 10},
    "LinePeople":      {"kind": "ref", "default": ""},
    "TrunkName":       {"kind": "text", "default": ""},
    "MainPerson":      {"kind": "ref", "default": ""},
    # Haltestellen
    "TripKm":          {"kind": "int", "default": 50, "min": 10, "max": 1000},
    "TripPhotos":      {"kind": "int", "default": 8, "min": 2, "max": 200},
    "EventPhotos":     {"kind": "int", "default": 20, "min": 5, "max": 1000},
    "ShowMoves":       {"kind": "bool", "default": True},
    "MaxStations":     {"kind": "int", "default": 300, "min": 10, "max": 800},
    # Fahrt
    "TourOrder":       {"kind": "choice", "default": "chrono", "choices": ("chrono", "random", "onthisday")},
    "StopSeconds":     {"kind": "float", "default": 9.0, "min": 3.0, "max": 120.0},
    "PhotosPerStop":   {"kind": "int", "default": 3, "min": 1, "max": 6},
    "StopsPerRound":   {"kind": "int", "default": 10, "min": 2, "max": 100},
    "Overview":        {"kind": "bool", "default": True},
    "Speed":           {"kind": "choice", "default": "normal", "choices": ("slow", "normal", "fast")},
    "Theme":           {"kind": "choice", "default": "light", "choices": ("light", "dark")},
    "ShowPeople":      {"kind": "bool", "default": True},
    "RefreshHours":    {"kind": "int", "default": 24, "min": 1, "max": 168},
    "PlaylistSeconds": {"kind": "int", "default": 600, "min": 30, "max": 86400},
    "MakePlaylist":    {"kind": "bool", "default": False},
}
SCHEMA.update(photo_privacy.SCHEMA)   # Fotopositionen bleiben auf dem Rahmen
SECRETS = [name for name, spec in SCHEMA.items() if spec["kind"] == "secret"]
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()


def coerce_sources(raw):
    if raw is None:
        return default_sources()
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return default_sources()
    out, ids = [], set()
    for row in raw if isinstance(raw, list) else []:
        if not isinstance(row, dict) or len(out) >= MAX_SOURCES:
            continue
        ident = re.sub(r"[^A-Za-z0-9]", "", str(row.get("id") or ""))[:16] or uuid.uuid4().hex[:8]
        while ident in ids:
            ident = uuid.uuid4().hex[:8]
        ids.add(ident)
        out.append({
            "id": ident,
            "kind": row.get("kind") if row.get("kind") in KINDS else "library",
            "ref": re.sub(r"[^A-Za-z0-9_-]", "", str(row.get("ref") or ""))[:64],
            "name": re.sub(r"\s+", " ", str(row.get("name") or "")).strip()[:60],
        })
    return out


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind in ("ref", "date", "name"):
        return immich_filters.coerce(spec, raw)
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "float":
        return round(max(spec["min"], min(spec["max"], as_float(raw, spec["default"]))), 1)
    if kind == "choice":
        value = str(raw or "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "sources":
        return coerce_sources(raw)
    if kind == "albums":
        if isinstance(raw, str):
            raw = [part for part in raw.split(",") if part]
        ids = []
        for item in raw if isinstance(raw, list) else []:
            ident = re.sub(r"[^A-Za-z0-9_-]", "", str(item or ""))[:64]
            if ident and ident not in ids:
                ids.append(ident)
        return ids[:50]
    if kind == "url":
        return sources.normalize_url(raw)[:300]
    if kind == "text":
        return re.sub(r"\s+", " ", str(raw or "")).strip()[:80]
    if kind == "folders":
        lines = [line.strip() for line in str(raw or "").replace(";", "\n").splitlines()]
        return "\n".join(line for line in lines if line.startswith("/"))[:2000]
    return re.sub(r"\s+", "", str(raw or ""))[:400]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


photo_privacy.bind(settings)


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


def adopt_immich():
    """Server und Schlüssel aus einem anderen Immich-Plugin übernehmen, wenn hier keiner steht."""
    values = settings()
    if values["ServerUrl"] and values["ApiKey"]:
        return ""
    for name, title in (("ImmichSlideshow", "Immich Slideshow"), ("GrowingUp", "Growing Up"),
                        ("OnThisDay", "On This Day"), ("ColorCalendar", "Colour Calendar"),
                        ("PhotoMosaic", "Photo Mosaic"), ("TravelMap", "Travel Map")):
        other = read_json(PLUGIN_DIR.parent / name / "data" / "settings.json", {}) or {}
        if not isinstance(other, dict):
            continue
        url, key = sources.normalize_url(other.get("ServerUrl")), str(other.get("ApiKey") or "").strip()
        if url and key:
            save_settings({"ServerUrl": url, "ApiKey": key})
            log(f"Immich-Server und API-Schlüssel aus {title} übernommen.")
            return title
    return ""


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 120))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def engine_image(media_id, path=""):
    """Das Vorschaubild, das die Engine für die Weboberfläche erzeugt (auf Jans Rahmen 512 Pixel)."""
    candidates = []
    if path:
        candidates += [("/media/thumbnail", {"path": path, "purpose": "preview"}),
                       ("/media/thumbnail", {"path": path})]
    if media_id:
        candidates += [(f"/media/thumbnail/{media_id}", {"purpose": "preview"}),
                       (f"/media/thumbnail/{media_id}", None)]
    failures = []
    for route, params in candidates:
        try:
            response = requests.get(f"{engine_base()}{route}", params=params, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 60))
        except requests.RequestException as exc:
            failures.append(f"{route}: {exc}")
            continue
        kind = response.headers.get("Content-Type", "").split(";")[0]
        if response.status_code == 200 and kind.startswith("image/"):
            return response.content
        failures.append(f"{route}{'?path' if params and 'path' in params else ''}: HTTP {response.status_code} {kind}")
    raise sources.SourceError(f"Vorschaubild {media_id}: " + "; ".join(failures))


# --------------------------------------------------------------------------
# Index der DynaFrame-Fotos (Datum + GPS), mit Cache für Dateien
# --------------------------------------------------------------------------

immich = sources.Immich(tr)
dynaframe = sources.DynaFrame(engine_call, EngineError, log)
names = places.Places(DATA_DIR, log)

EXIF_FILE = DATA_DIR / "exif.json"
_exif = {"data": None, "dirty": 0}
_exif_lock = threading.Lock()


def exif_lookup(path, stamp):
    """(taken, lat, lon) aus der Datei, mit Cache (key = Pfad, Stempel muss passen)."""
    with _exif_lock:
        if _exif["data"] is None:
            stored = read_json(EXIF_FILE, {})
            _exif["data"] = stored if isinstance(stored, dict) else {}
        row = _exif["data"].get(path)
    if isinstance(row, list) and len(row) == 4 and row[0] == stamp:
        return row[1], row[2], row[3]
    lat, lon, taken = exif_gps.read(path)
    taken = sources.clean_taken(taken)
    with _exif_lock:
        _exif["data"][path] = [stamp, taken, lat, lon]
        _exif["dirty"] += 1
    return taken, lat, lon


def exif_save(keep=None):
    with _exif_lock:
        if _exif["data"] is None:
            return
        if keep is not None:
            for key in [k for k in _exif["data"] if k not in keep]:
                del _exif["data"][key]
                _exif["dirty"] += 1
        if _exif["dirty"]:
            write_json(EXIF_FILE, _exif["data"])
            _exif["dirty"] = 0


def key_path(key):
    if key.startswith("d:"):
        return key.partition("|")[2]
    if key.startswith("f:"):
        return key[2:]
    return ""



# --------------------------------------------------------------------------
# Der Index: alle Fotos mit Datum, GPS, Ort, Personen
# --------------------------------------------------------------------------

_stop_requested = threading.Event()
_work_stop = threading.Event()
_wake = threading.Event()
_index_lock = threading.Lock()
_index = {"rows": [], "status": {}, "at": 0.0, "signature": "", "busy": False,
          "progress": {"done": 0, "todo": 0, "phase": ""}, "undated": 0, "total": 0, "dfCount": None,
          "people": [], "birthdays": {}}


def index_signature(values):
    """Nur ein Hash: index.json ist auf dem Rahmen für alle lesbar, der Schlüssel gehört nicht hinein."""
    keep = {k: values[k] for k in ("Sources", "Folders", "ServerUrl", "ApiKey", "Albums", "LinePeople", "MainPerson")}
    text = json.dumps([keep, immich_filters.signature(values), dynaframe_filters.signature(values), version()],
                      sort_keys=True, default=str)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_index():
    stored = read_json(INDEX_FILE, {})
    if isinstance(stored, dict) and isinstance(stored.get("rows"), list):
        with _index_lock:
            _index.update(rows=stored["rows"], at=float(stored.get("at") or 0), signature=stored.get("signature") or "",
                          status=stored.get("status") or {}, undated=stored.get("undated") or 0,
                          total=stored.get("total") or 0, people=stored.get("people") or [],
                          birthdays=stored.get("birthdays") or {})
        log(f"{len(stored['rows'])} Fotos aus dem letzten Einlesen geladen.")


def immich_people(values):
    """Die Personen für die Linien: gewählte oder alle benannten (für Namen, Geburtstage, Auswahl)."""
    found = immich.people_list()
    chosen = [p for p in values["LinePeople"].split(",") if p]
    if chosen:
        wanted = [p for p in found if p["id"] in chosen]
        return found, wanted
    return found, None


def build_index(reason=""):
    """Alle Quellen einlesen: Datum, GPS, Ort, Personen und Ordner jedes Fotos."""
    values = settings()
    with _index_lock:
        if _index["busy"]:
            return
        _index["busy"] = True
    started = now()
    status, rows = {}, {}
    people, birthdays = list(_index["people"]), dict(_index["birthdays"])
    local = [s for s in values["Sources"] if not s["kind"].startswith("immich")]
    match = None
    if local and dynaframe_filters.active(values):
        match = dynaframe_filters.Matcher(values, lambda: dynaframe.library_rows(_work_stop),
                                          cache_file=str(DATA_DIR / "file_meta.json"), log=log)
    try:
        log(f"Lese die Fotos ein{' - ' + reason if reason else ''}.")
        _index["progress"] = {"done": 0, "todo": 0, "phase": "list"}
        immich_ready = None
        for source in values["Sources"]:
            sid = source["id"]
            _index["status"][sid] = dict(_index["status"].get(sid) or {}, state="busy")
            try:
                if source["kind"].startswith("immich"):
                    immich.configure(values["ServerUrl"], values["ApiKey"])
                    if immich_ready is None:
                        try:
                            people_all, wanted = immich_people(values)
                        except sources.SourceError as exc:
                            if exc.status != 403:
                                raise
                            people_all, wanted = [], []
                        people = [{"id": p["id"], "name": p["name"]} for p in people_all]
                        birthdays = {p["id"]: p["birthday"] for p in people_all if p["birthday"]}
                        immich_ready = wanted if wanted is not None else sorted(people_all, key=lambda p: -p["count"])[:40]
                    if source["kind"] == "immich_album":
                        if not source["ref"]:
                            raise sources.SourceError(tr("Wähle ein Album."))
                        albums = [source["ref"]]
                    else:
                        albums = list(values["Albums"])
                    _index["progress"]["phase"] = "immich"
                    found = immich.library(albums, _work_stop, immich_filters.from_settings(values), people=immich_ready,
                                           progress=lambda n: _index["progress"].update(done=n))
                    total = len(found)
                elif source["kind"] == "playlist":
                    if not source["ref"]:
                        raise sources.SourceError(tr("Wähle eine Playlist."))
                    try:
                        found, total = dynaframe.playlist(source["ref"], _work_stop)
                    except EngineError as exc:
                        if exc.status == 404:
                            raise sources.SourceError(tr("Die Playlist gibt es nicht mehr.")) from exc
                        raise
                else:
                    folders = [f for f in values["Folders"].splitlines() if f]
                    found, total = dynaframe.library(folders, _work_stop)
                if match is not None and not source["kind"].startswith("immich"):
                    found = [row for row in found if match.keep(row["k"])]
                for row in found:
                    row["src"] = sid
                    rows.setdefault(row["k"], row)
                status[sid] = {"state": "ok", "total": total, "dated": 0, "located": 0, "error": "", "at": now()}
            except EngineError as exc:
                status[sid] = {"state": "error", "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except sources.SourceError as exc:
                status[sid] = {"state": "error", "error": str(exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except Exception as exc:  # pragma: no cover - darf den Durchlauf nicht beenden
                status[sid] = {"state": "error", "error": str(exc)[:200], "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc!r}", "warning")
            _index["status"][sid] = status[sid]
            if _work_stop.is_set() or _stop_requested.is_set():
                return

        if match is not None:
            match.save()
        _index["dfCount"] = match.counts() if match is not None else None
        # Datum/GPS aus den Dateien, wo die Engine keins mitliefert
        todo = [r for r in rows.values() if (not r["t"] or r["lat"] is None) and os.path.isfile(key_path(r["k"]))]
        _index["progress"] = {"done": 0, "todo": len(todo), "phase": "exif"}
        for count, row in enumerate(todo, 1):
            if _work_stop.is_set() or _stop_requested.is_set():
                exif_save()
                return
            taken, lat, lon = exif_lookup(key_path(row["k"]), row["stamp"])
            row["t"] = row["t"] or taken
            if row["lat"] is None and lat is not None and lon is not None:
                row["lat"], row["lon"] = lat, lon
            _index["progress"]["done"] = count
            if count % 200 == 0:
                time.sleep(0.05)
        exif_save(keep={key_path(r["k"]) for r in rows.values() if key_path(r["k"])})
        # Personen für Fotos aus DynaFrame: Gesichter aus Immich, wenn Immich eingetragen ist
        if immich_ready is None and local and values["ServerUrl"] and values["ApiKey"]:
            _index["progress"] = {"done": 0, "todo": 0, "phase": "faces"}
            try:
                immich.configure(values["ServerUrl"], values["ApiKey"])
                people_all, wanted = immich_people(values)
                people = [{"id": p["id"], "name": p["name"]} for p in people_all]
                birthdays = {p["id"]: p["birthday"] for p in people_all if p["birthday"]}
                use = wanted if wanted is not None else sorted(people_all, key=lambda p: -p["count"])[:40]
                main = values["MainPerson"]
                if main and all(p["id"] != main for p in use):
                    use = use + [p for p in people_all if p["id"] == main]
                by_size, by_day = immich.faces_by_file(use, _work_stop)
                matched = 0
                for row in rows.values():
                    path = key_path(row["k"])
                    if not path or row.get("people"):
                        continue
                    name = os.path.basename(path).lower()
                    size = as_int(str(row.get("stamp") or "").split(":")[0], 0)
                    who = by_size.get((name, size)) if size else None
                    if who is None and row.get("t"):
                        who = by_day.get((name, row["t"][:10]))
                    if who:
                        row["people"] = who[:12]
                        matched += 1
                log(f"Personen aus Immich: {matched} DynaFrame-Fotos zugeordnet ({len(use)} Personen).")
            except sources.SourceError as exc:
                log(f"Personen aus Immich nicht möglich: {exc}", "warning")
            except Exception as exc:  # noqa: BLE001 - Personen sind ein Zusatz
                log(f"Personen aus Immich: {exc!r}", "warning")
            if _work_stop.is_set() or _stop_requested.is_set():
                return
        dated = []
        for row in rows.values():
            if len(row.get("t") or "") < 10:
                continue
            dated.append({k: row.get(k) for k in ("k", "t", "lat", "lon", "place", "fav", "stars", "people", "grp",
                                                   "stamp", "src") if row.get(k) not in (None, "", [], False)})
            dated[-1].setdefault("lat", None)
            dated[-1].setdefault("lon", None)
        dated.sort(key=lambda r: r["t"])
        for sid, row in status.items():
            if row.get("state") == "ok":
                mine = [r for r in dated if r.get("src") == sid]
                row["dated"] = len(mine)
                row["located"] = sum(1 for r in mine if r["lat"] is not None)
        signature = index_signature(values)
        with _index_lock:
            _index.update(rows=dated, status=dict(_index["status"], **status), at=now(), signature=signature,
                          undated=len(rows) - len(dated), total=len(rows), people=people, birthdays=birthdays)
        write_json(INDEX_FILE, {"rows": dated, "at": _index["at"], "signature": signature, "status": _index["status"],
                                "undated": _index["undated"], "total": len(rows), "people": people,
                                "birthdays": birthdays})
        log(f"{len(dated)} Fotos mit Datum ({len(rows) - len(dated)} ohne), "
            f"{sum(1 for r in dated if r['lat'] is not None)} mit Ort, "
            f"{sum(1 for r in dated if r.get('people'))} mit Personen, {now() - started:.0f} s.")
    finally:
        _index["progress"] = {"done": 0, "todo": 0, "phase": ""}
        with _index_lock:
            _index["busy"] = False


# --------------------------------------------------------------------------
# Der Plan: Haltestellen und Linien
# --------------------------------------------------------------------------

_plan_lock = threading.Lock()
_plan = {"ver": 0, "signature": "", "busy": False, "data": None, "at": 0.0, "named": False}


def plan_signature(values):
    keep = ("LineKind", "LineCount", "LinePeople", "MainPerson", "TripKm", "TripPhotos", "EventPhotos", "ShowMoves",
            "MaxStations", "Language")
    text = json.dumps([{k: values[k] for k in keep}, _index["signature"], _index["at"], version()], sort_keys=True)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_plan():
    stored = read_json(PLAN_FILE, {})
    if isinstance(stored, dict) and isinstance(stored.get("data"), dict):
        with _plan_lock:
            _plan.update(ver=int(stored.get("ver") or 1), signature=stored.get("signature") or "",
                         data=stored["data"], at=float(stored.get("at") or 0), named=bool(stored.get("named")))


def build_plan(reason=""):
    values = settings()
    with _plan_lock:
        if _plan["busy"]:
            return
        _plan["busy"] = True
    try:
        started = now()
        signature = plan_signature(values)
        rows = list(_index["rows"])
        lang = values["Language"]
        opts = plan.Options(line_kind=values["LineKind"], line_count=values["LineCount"],
                            people=[p for p in values["LinePeople"].split(",") if p], min_km=values["TripKm"],
                            trip_photos=values["TripPhotos"], event_photos=values["EventPhotos"],
                            max_stations=values["MaxStations"], keep_photos=KEEP_PHOTOS, moves=values["ShowMoves"],
                            birthdays=_index["birthdays"], main=values["MainPerson"])
        missing = []

        def quick_namer(lat, lon):
            found = names.name(lat, lon, lang, allow_fetch=False)
            if not found:
                missing.append((lat, lon))
            return found

        data = plan.build(rows, opts, quick_namer)
        publish(data, signature, named=not missing)
        log(f"Plan: {len(data['stations']) if data else 0} Haltestellen, {len(data['lines']) - 1 if data else 0} Linien"
            f" aus {len(rows)} Fotos ({now() - started:.1f} s){' - ' + reason if reason else ''}.")
        if missing and not _work_stop.is_set():
            log(f"Suche {len(missing)} Ortsnamen bei OpenStreetMap.")
            data = plan.build(rows, opts, lambda lat, lon: names.name(lat, lon, lang))
            names.save()
            if _plan["signature"] == signature and not _work_stop.is_set():
                publish(data, signature, named=True)
    finally:
        with _plan_lock:
            _plan["busy"] = False


def publish(data, signature, named):
    with _plan_lock:
        _plan.update(ver=_plan["ver"] + 1, signature=signature, data=data, at=now(), named=named)
        payload = {"ver": _plan["ver"], "signature": signature, "data": data, "at": _plan["at"], "named": named}
    write_json(PLAN_FILE, payload)
    threading.Thread(target=prepare_all, name=f"{PLUGIN_ID}-photos", daemon=True).start()

# --------------------------------------------------------------------------
# Fotos für die Szene
# --------------------------------------------------------------------------

PHOTO_MAX = 40 * 1024 * 1024
SHOWABLE = (".jpg", ".jpeg", ".jpe", ".png", ".webp", ".gif", ".bmp", ".tif", ".tiff")


def webdav_dirs():
    seen = []
    for home in (Path.home(), Path("/home/pi")):
        folder = home / ".local/share/dfr/webdav-cache"
        if folder not in seen and folder.is_dir():
            seen.append(folder)
    return seen


def webdav_cached(path, size):
    """Fotos aus WebDAV (/webdav-media/<Quelle>/...) liefert die Engine nur als
    512-Pixel-Vorschau. Das Original legt DynaFrame aber in webdav-cache ab,
    als <Quelle>-<Hash>.<Endung>. Den Hash kennen wir nicht, also: gleiche
    Quelle, gleiche Endung, gleiche Dateigröße (wie bei Halloween Scare)."""
    if not path.startswith("/webdav-media/"):
        return None
    size = as_int(size, 0)
    if size <= 0 or size > PHOTO_MAX:
        return None
    parts = path.split("/")
    source = parts[2] if len(parts) > 2 else ""
    suffix = Path(path).suffix.lower()
    best = None
    for folder in webdav_dirs():
        try:
            entries = list(os.scandir(folder))
        except OSError:
            continue
        for entry in entries:
            name = entry.name
            if source and not name.startswith(source + "-"):
                continue
            if suffix and not name.lower().endswith(suffix):
                continue
            try:
                info = entry.stat()
            except OSError:
                continue
            if info.st_size == size and (best is None or info.st_mtime > best[0]):
                best = (info.st_mtime, Path(entry.path))
    return best[1] if best else None


def shrink(source):
    """Bild (Pfad oder Bytes) gedreht nach Exif und verkleinert als JPEG-Bytes, dazu (w, h)."""
    if Image is None:
        raise sources.SourceError("Pillow fehlt")
    handle = io.BytesIO(source) if isinstance(source, (bytes, bytearray)) else source
    with Image.open(handle) as image:
        try:
            image.draft("RGB", (PHOTO_EDGE, PHOTO_EDGE))
        except Exception:  # noqa: BLE001 - nur JPEG kennt draft
            pass
        image = ImageOps.exif_transpose(image)
        image = image.convert("RGB")
        image.thumbnail((PHOTO_EDGE, PHOTO_EDGE), Image.LANCZOS)
        out = io.BytesIO()
        image.save(out, "JPEG", quality=86, optimize=True, progressive=True)
        return out.getvalue(), image.size


def photo_file(item):
    name = hashlib.sha1(f"{item['k']}|{item.get('stamp') or ''}".encode("utf-8")).hexdigest()[:20]
    return PHOTO_DIR / f"{name}.jpg"


def prepare(item):
    """Das Foto als JPEG im Cache ablegen; liefert den Pfad."""
    target = photo_file(item)
    if target.is_file():
        return target
    key = item["k"]
    data = None
    if key.startswith("i:"):
        values = settings()
        immich.configure(values["ServerUrl"], values["ApiKey"])
        raw, _kind = immich.photo(key[2:], size="preview")
        try:
            data, _size = shrink(raw)
        except Exception:  # noqa: BLE001 - dann so, wie Immich es schickt
            data = raw
    else:
        path = key_path(key)
        local = path and os.path.isfile(path)
        if local and (path.lower().endswith(SHOWABLE) or HEIF):
            try:
                data, _size = shrink(path)
            except Exception as exc:  # noqa: BLE001 - kaputte Datei: über die Engine
                log(f"Foto {path}: {exc}", "warning")
        if data is None and path.startswith("/webdav-media/"):
            cached = webdav_cached(path, str(item.get("stamp") or "").split(":")[0])
            if cached:
                try:
                    data, _size = shrink(str(cached))
                except Exception:  # noqa: BLE001
                    data = None
        if data is None and key.startswith("d:"):
            raw = engine_image(key[2:].partition("|")[0], path)
            try:
                data, _size = shrink(raw)
            except Exception:  # noqa: BLE001
                data = raw
        if data is None:
            raise sources.SourceError("Foto nicht gefunden")
    PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(f".{threading.get_ident()}.tmp")
    temp.write_bytes(data)
    temp.replace(target)
    return target


_prepare_lock = threading.Lock()




_prepare_lock = threading.Lock()


def plan_photos():
    data = _plan["data"] or {}
    return data.get("photos") or []


def prepare_all():
    """Die ersten Fotos jeder Haltestelle vorab verkleinern (der Rest kommt, wenn die Szene sie will)."""
    with _prepare_lock:
        data = _plan["data"] or {}
        photos = data.get("photos") or []
        wanted = []
        for station in data.get("stations") or []:
            wanted += station.get("p", [])[:settings()["PhotosPerStop"]]
        keep = set()
        failed = 0
        for index in wanted:
            if _stop_requested.is_set() or data is not _plan["data"]:
                return
            if not 0 <= index < len(photos):
                continue
            try:
                keep.add(prepare(photos[index]).name)
            except Exception as exc:  # noqa: BLE001 - ein Foto darf den Rest nicht aufhalten
                failed += 1
                if failed <= 3:
                    log(f"Foto für die Szene ({photos[index]['k'][:100]}): {exc}", "warning")
            time.sleep(0.05)
        # Fotos, die zu keiner Haltestelle mehr gehören und lange keiner wollte, weg
        current = {photo_file(p).name for p in photos}
        try:
            for entry in os.scandir(PHOTO_DIR):
                if entry.name not in current and now() - entry.stat().st_mtime > 7 * 86400:
                    os.unlink(entry.path)
        except OSError:
            pass


def photo_bytes(query):
    idx = as_int((query.get("i") or ["-1"])[0], -1)
    ver = as_int((query.get("v") or ["-1"])[0], -1)
    photos = plan_photos()
    if ver != _plan["ver"] or not 0 <= idx < len(photos):
        return None
    try:
        return prepare(photos[idx]).read_bytes()
    except Exception as exc:  # noqa: BLE001
        log(f"Foto für die Szene: {exc}", "warning")
        return None


# --------------------------------------------------------------------------
# Der Arbeitsfaden
# --------------------------------------------------------------------------

def work_loop():
    while not _stop_requested.is_set():
        values = settings()
        try:
            due = now() - _index["at"] >= values["RefreshHours"] * 3600
            if due or _index["signature"] != index_signature(values):
                _work_stop.clear()
                build_index("geplant" if due and _index["at"] else "Einstellungen")
            if _index["at"] and _plan["signature"] != plan_signature(values):
                _work_stop.clear()
                build_plan()
        except Exception as exc:  # noqa: BLE001 - der Faden darf nicht sterben
            log(f"Fehler: {exc!r}", "warning")
        _wake.wait(30)
        _wake.clear()


def reload_now():
    _work_stop.set()
    _index["at"] = 0.0

    def later():
        time.sleep(1)
        _work_stop.clear()
        _wake.set()

    threading.Thread(target=later, daemon=True).start()
    return {"success": True, "message": tr("Die Fotos werden neu eingelesen.")}


# --------------------------------------------------------------------------
# Playlist für die Szene
# --------------------------------------------------------------------------

def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=PLAYLIST_NAMES.values(),
    name=lambda: PLAYLIST_NAMES.get(settings()["Language"], PLAYLIST_NAMES["en"]),
    description=lambda: tr("Dein Leben als U-Bahn-Plan: Linien für Personen und Orte, Haltestellen für Reisen und Feste."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()

# --------------------------------------------------------------------------
# Was die Szene bekommt
# --------------------------------------------------------------------------

SCENE_SETTINGS = ("Language", "TourOrder", "StopSeconds", "PhotosPerStop", "StopsPerRound", "Overview", "Speed",
                  "Theme", "ShowPeople", "TrunkName")
TOUR_FILE = DATA_DIR / "tour.json"
_tour = {"pos": None}


def tour_position():
    if _tour["pos"] is None:
        stored = read_json(TOUR_FILE, {})
        _tour["pos"] = stored if isinstance(stored, dict) else {}
    return _tour["pos"]


def save_position(query):
    """Wo die Fahrt zuletzt war (Datum der Haltestelle), damit sie nach einem Neustart weitergeht."""
    value = re.sub(r"[^0-9-]", "", (query.get("a") or [""])[0])[:10]
    if re.match(r"^\d{4}-\d{2}-\d{2}$", value):
        _tour["pos"] = {"a": value, "at": now()}
        write_json(TOUR_FILE, _tour["pos"])
    return {"success": True}


def scene_payload(query):
    values = settings()
    have = as_int((query.get("v") or ["-1"])[0], -1)
    payload = {
        "success": True,
        "ver": _plan["ver"],
        "settings": {k: values[k] for k in SCENE_SETTINGS},
        "busy": _plan["busy"] or _index["busy"],
        "sources": len(values["Sources"]),
        "pos": tour_position().get("a") or "",
        "today": datetime.date.today().isoformat(),
        "files": photo_files(),
    }
    if have != _plan["ver"]:
        data = _plan["data"] or {}
        payload["plan"] = {k: data.get(k) for k in ("stations", "lines", "homeCountry", "count", "from", "to")} \
            if data else None
        if payload["plan"]:
            payload["plan"]["photos"] = [{"t": p["t"], "place": p.get("place") or "", "who": p.get("who") or []}
                                         for p in data.get("photos") or []]
    return payload


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------


DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))

# --------------------------------------------------------------------------
# Öffentliche Kopie für den Remote Frame
#
# Mit DynaFrames HTTPS/Login verlangt /Plugins/Advanced/<Plugin>/ eine Anmeldung
# (401). Die Remote-Frame-Ansicht (Browser, Fire TV, Pi) ist nicht angemeldet und
# lädt nur die Szene über /engine-proxy/dynamic-scenes/content/<Szene>/. Darum legt
# das Plugin den Plan und die schon verkleinerten Fotos zusätzlich in den Ordner der
# Szene (data/scene.json, data/photos/<name>.jpg); die Szene liest sie, wenn sie ihr
# Plugin nicht erreicht. Fotos als Hardlink (kein zusätzlicher Platz), sonst Kopie.
# Geschrieben wird nur bei Änderungen.

_mirror = {"scene": {}, "photos": {}}


def scene_dirs():
    root = DFR_DATA_DIR / "dynamic-packages" / SCENE_ID
    try:
        return [d for d in root.glob("*/dynamic") if (d / "scene.dynamic").is_file()]
    except OSError:
        return []


def link_photo(source, target):
    try:
        os.link(source, target)
    except OSError:
        temp = target.with_suffix(".tmp")
        temp.write_bytes(source.read_bytes())
        temp.replace(target)


def photo_files():
    """Fotoindex -> Dateiname der schon verkleinerten Fotos (liegen auch im Szenenordner)."""
    try:
        ready = {e.name for e in os.scandir(PHOTO_DIR) if e.name.endswith(".jpg")}
    except OSError:
        ready = set()
    files = {}
    for index, item in enumerate(plan_photos()):
        name = photo_file(item).name
        if name in ready:
            files[str(index)] = name
    return files


def mirror_once():
    folders = scene_dirs()
    if not folders:
        return
    body = scene_payload({"v": ["-1"]})
    files = body["files"]
    text = json.dumps(body, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    wanted = set(files.values())
    for folder in folders:
        key = str(folder)
        try:
            target = folder / "data" / "photos"
            if _mirror["photos"].get(key) != wanted:
                target.mkdir(parents=True, exist_ok=True)
                have = {e.name for e in os.scandir(target) if e.name.endswith(".jpg")}
                for name in wanted - have:
                    link_photo(PHOTO_DIR / name, target / name)
                for name in have - wanted:
                    try:
                        os.unlink(target / name)
                    except OSError:
                        pass
                _mirror["photos"][key] = wanted
            if _mirror["scene"].get(key) != text:
                write_json(folder / "data" / "scene.json", body)
                _mirror["scene"][key] = text
        except OSError as exc:
            if _mirror["scene"].get(key) != "error":
                log(f"Kopie für den Remote Frame in {folder} nicht möglich: {exc}", "warning")
            _mirror["scene"][key] = "error"
            _mirror["photos"].pop(key, None)


def mirror_loop():
    while not _stop_requested.is_set():
        try:
            mirror_once()
        except Exception as exc:  # noqa: BLE001
            log(f"Kopie für den Remote Frame: {exc}", "warning")
        _stop_requested.wait(10)


THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""




def state_payload():
    values = settings()
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    status = {}
    for source in values["Sources"]:
        row = dict(_index["status"].get(source["id"]) or {})
        if _index["busy"] and not row:
            row = {"state": "wait"}
        row["kind"] = source["kind"]
        status[source["id"]] = row
    data = _plan["data"] or {}
    stations = data.get("stations") or []
    lines = []
    for line in (data.get("lines") or [])[1:]:
        lines.append({"name": line["name"], "kind": line["kind"], "color": line["color"], "n": line["n"]})
    kinds = {}
    for st in stations:
        kinds[st["kind"]] = kinds.get(st["kind"], 0) + 1
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "status": status,
        "busy": _index["busy"] or _plan["busy"],
        "progress": _index["progress"],
        "indexAt": _index["at"],
        "indexed": len(_index["rows"]),
        "located": sum(1 for r in _index["rows"] if r.get("lat") is not None),
        "withPeople": sum(1 for r in _index["rows"] if r.get("people")),
        "dfCount": _index.get("dfCount"),
        "undated": _index["undated"],
        "stations": len(stations),
        "kinds": kinds,
        "lines": lines,
        "years": [data.get("from"), data.get("to")] if data else None,
        "named": _plan["named"],
        "heif": HEIF,
        "theme": {"id": theme_id()},
    }


def test_immich():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        info = immich.test()
    except sources.SourceError as exc:
        return {"success": True, "ok": False, "message": str(exc)}
    return {"success": True, "ok": True,
            "message": tr("Verbunden als {user} (Immich {version}).", user=info["user"] or "?",
                          version=info["version"] or "?")}


def list_albums():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, "albums": immich.albums()}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_immich(what):
    """Personen bzw. Tags für die Immich-Filter und die Linien."""
    values = settings()
    if what == "people" and not (values["ServerUrl"] and values["ApiKey"]):
        return {"success": True, "people": list(_index["people"])}
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, what: getattr(immich_filters, what)(immich)}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_playlists():
    try:
        rows = [p for p in dynaframe.playlists() if p["name"] not in PLAYLIST_NAMES.values()]
        return {"success": True, "playlists": sorted(rows, key=lambda p: str(p["name"]).lower())}
    except EngineError as exc:
        return {"success": False, "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc)}


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(query), cors=True)
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            if path == "/api/photo":
                found = photo_bytes(query)
                if found is None:
                    self._json({"success": False}, 404, cors=True)
                else:
                    self._send(found, "image/jpeg", cache="private, max-age=86400", cors=True)
                return
            if path == "/api/albums":
                self._json(list_albums())
                return
            if path in ("/api/people", "/api/tags"):
                self._json(list_immich(path.rsplit("/", 1)[1]))
                return
            if path == "/api/playlists":
                self._json(list_playlists())
                return
            if path == "/api/pos":
                self._json(save_position(query), cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                for name in SECRETS:
                    # Ein leeres Feld heißt: das alte behalten. Löschen geht mit "-".
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)
                    elif name in body and str(body[name]).strip() == "-":
                        body[name] = ""
                changed = save_settings(body)
                if "MakePlaylist" in changed:
                    OWN.changed()
                if changed:
                    if any(n in changed for n in ("Sources", "Albums", *immich_filters.SCHEMA, *dynaframe_filters.SCHEMA)):
                        # Nichts Ausgefiltertes mehr zeigen, bis neu eingelesen ist
                        _work_stop.set()
                        with _plan_lock:
                            _plan.update(ver=_plan["ver"] + 1, data=None, signature="")
                        try:
                            PLAN_FILE.unlink()
                        except OSError:
                            pass

                        def resume():
                            time.sleep(1)
                            _work_stop.clear()
                            _wake.set()

                        threading.Thread(target=resume, daemon=True).start()
                    _wake.set()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(reload_now())
                return
            if path == "/api/test":
                self._json(test_immich())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}" + ("" if HEIF else " (ohne HEIC-Unterstützung, HEIC über die Engine)"))

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: reload_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    load_plan()
    load_index()
    adopt_immich()
    try:
        os.nice(5)   # das Einlesen soll die Wiedergabe nicht stören
    except OSError:
        pass
    threading.Thread(target=work_loop, name=f"{PLUGIN_ID}-work", daemon=True).start()
    threading.Thread(target=mirror_loop, name=f"{PLUGIN_ID}-mirror", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _work_stop.set()
    _wake.set()
    try:
        exif_save()
        names.save()
    except Exception:
        pass
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
