"""Ticker Wall - the sources.

Everything here is free and needs no key:

- news      RSS 2.0, RSS 1.0 (RDF) and Atom feeds, any number, chosen by the owner
- markets   Finnhub quote API with the owner's free key (US stocks and ETFs;
            indices, countries and commodities through ETFs), 60 calls a minute
- crypto    CoinGecko /coins/markets (price, 24 h change, 7 day curve)
- fx        European Central Bank rates via Frankfurter (daily)
- weather   Open-Meteo, all cities in one request
- quakes    USGS, earthquakes of magnitude 4.5+ of the last day

TICKER_WALL_MOCK=http://127.0.0.1:18300 sends every request to a local mock
(test/mock_sources.py): https://host/path -> MOCK/host/path.
"""

import hashlib
import html
import os
import re
import time
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from datetime import datetime, timezone
from urllib.parse import urlparse

import requests

MOCK = os.environ.get("TICKER_WALL_MOCK", "").rstrip("/")
USER_AGENT = "TickerWall (DynaFrame plugin; +https://github.com/Archonw/Jans-DynaframePro-Store)"
TIMEOUT = (8, 20)
_session = requests.Session()


class SourceError(Exception):
    pass


def url(address):
    if not MOCK:
        return address
    parsed = urlparse(address)
    return f"{MOCK}/{parsed.netloc}{parsed.path}" + (f"?{parsed.query}" if parsed.query else "")


def get(address, what, params=None, accept="application/json"):
    try:
        response = _session.get(url(address), params=params, timeout=TIMEOUT,
                                headers={"User-Agent": USER_AGENT, "Accept": accept})
    except requests.RequestException as exc:
        raise SourceError(f"{what}: {exc.__class__.__name__}") from exc
    if response.status_code == 429:
        raise SourceError(f"{what}: too many requests (HTTP 429)")
    if response.status_code >= 400:
        raise SourceError(f"{what}: HTTP {response.status_code}")
    return response


def get_json(address, what, params=None):
    response = get(address, what, params)
    try:
        return response.json()
    except ValueError as exc:
        raise SourceError(f"{what}: no JSON") from exc


def as_float(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number == number else None  # NaN


# --------------------------------------------------------------------------
# News feeds
# --------------------------------------------------------------------------

TAG_RE = re.compile(r"<[^>]+>")
SPACE_RE = re.compile(r"\s+")


def clean_text(text, limit=400):
    text = html.unescape(TAG_RE.sub(" ", html.unescape(text or "")))
    text = SPACE_RE.sub(" ", text).strip()
    return text[:limit]


def local(tag):
    return tag.rsplit("}", 1)[-1].lower() if isinstance(tag, str) else ""


def child(node, *names):
    for item in node:
        if local(item.tag) in names:
            return item
    return None


def child_text(node, *names):
    item = child(node, *names)
    return (item.text or "").strip() if item is not None and item.text else ""


def parse_time(text):
    text = (text or "").strip()
    if not text:
        return None
    try:
        return parsedate_to_datetime(text).timestamp()
    except (TypeError, ValueError, IndexError):
        pass
    try:
        value = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.timestamp()
    except ValueError:
        return None


def entry_image(entry, summary_html):
    for item in entry.iter():
        name = local(item.tag)
        if name in ("content", "thumbnail") and item.get("url") and (
                (item.get("medium") or "image") == "image" or name == "thumbnail"):
            if not item.get("type") or item.get("type", "").startswith("image"):
                return item.get("url")
        if name == "enclosure" and item.get("url") and (item.get("type") or "").startswith("image"):
            return item.get("url")
    match = re.search(r'<img[^>]+src="([^"]+)"', summary_html or "")
    return html.unescape(match.group(1)) if match else ""


def parse_feed(data, source):
    """Headlines of an RSS or Atom document: [{"id","title","summary","link","at","image","source"}]."""
    try:
        root = ET.fromstring(data)
    except ET.ParseError as exc:
        raise SourceError(f"{source}: not a feed ({exc})") from exc
    entries = [e for e in root.iter() if local(e.tag) in ("item", "entry")]
    out = []
    for entry in entries[:60]:
        title = clean_text(child_text(entry, "title"), 300)
        if not title:
            continue
        link = child_text(entry, "link")
        if not link:
            for item in entry:
                if local(item.tag) == "link" and item.get("href") and item.get("rel", "alternate") == "alternate":
                    link = item.get("href")
                    break
        raw_summary = child_text(entry, "description", "summary", "content", "encoded")
        at = parse_time(child_text(entry, "pubdate", "published", "updated", "date", "issued"))
        key = hashlib.sha1((link or title).encode("utf-8", "ignore")).hexdigest()[:16]
        out.append({"id": key, "title": title, "summary": clean_text(raw_summary, 300), "link": link,
                    "at": at, "image": entry_image(entry, raw_summary), "source": source})
    return out


def read_feed(name, address):
    response = get(address, name, accept="application/rss+xml, application/atom+xml, application/xml, text/xml, */*")
    return parse_feed(response.content, name)


# --------------------------------------------------------------------------
# Markets (Finnhub, free key)
# --------------------------------------------------------------------------

class RateLimited(SourceError):
    """The service said 429: wait before asking again."""


class AuthError(SourceError):
    pass


def read_finnhub(symbol, key):
    """Price and change of one US stock or ETF: {"price","previous","change","pct","high","low","at"}."""
    try:
        response = _session.get(url("https://finnhub.io/api/v1/quote"), params={"symbol": symbol},
                                headers={"X-Finnhub-Token": key, "User-Agent": USER_AGENT, "Accept": "application/json"},
                                timeout=TIMEOUT)
    except requests.RequestException as exc:
        raise SourceError(f"Finnhub {symbol}: {exc.__class__.__name__}") from exc
    if response.status_code == 429:
        raise RateLimited("Finnhub: too many requests (HTTP 429)")
    if response.status_code in (401, 403):
        text = (response.text or "")[:160]
        if "access" in text.lower() and response.status_code == 403:
            raise SourceError(f"Finnhub {symbol}: not in the free plan")
        raise AuthError(f"Finnhub: key not accepted (HTTP {response.status_code})")
    if response.status_code >= 400:
        raise SourceError(f"Finnhub {symbol}: HTTP {response.status_code}")
    try:
        data = response.json() or {}
    except ValueError as exc:
        raise SourceError(f"Finnhub {symbol}: no JSON") from exc
    price, previous = as_float(data.get("c")), as_float(data.get("pc"))
    if not price:  # unknown symbols come back as all zeros
        raise SourceError(f"Finnhub {symbol}: unknown symbol or no price")
    stamp = as_float(data.get("t"))
    return {"price": price, "previous": previous or None,
            "change": as_float(data.get("d")), "pct": as_float(data.get("dp")),
            "high": as_float(data.get("h")), "low": as_float(data.get("l")), "at": stamp,
            "open": bool(stamp and time.time() - stamp < 20 * 60), "currency": "USD"}


def thin(values, most):
    if len(values) <= most:
        return values
    step = len(values) / most
    picked = [values[int(i * step)] for i in range(most - 1)]
    return picked + [values[-1]]


# --------------------------------------------------------------------------
# Crypto (CoinGecko)
# --------------------------------------------------------------------------

def read_crypto(ids, currency="eur"):
    if not ids:
        return []
    data = get_json("https://api.coingecko.com/api/v3/coins/markets", "CoinGecko",
                    params={"vs_currency": currency, "ids": ",".join(ids), "sparkline": "true",
                            "price_change_percentage": "24h"})
    if not isinstance(data, list):
        raise SourceError("CoinGecko: unexpected answer")
    order = {coin: n for n, coin in enumerate(ids)}
    out = []
    for row in sorted(data, key=lambda r: order.get(r.get("id"), 99)):
        price = as_float(row.get("current_price"))
        if price is None:
            continue
        curve = [as_float(v) for v in ((row.get("sparkline_in_7d") or {}).get("price") or [])]
        curve = [v for v in curve if v is not None]
        out.append({"symbol": str(row.get("symbol") or "").upper(), "name": row.get("name") or row.get("id"),
                    "kind": "crypto", "price": price, "pct": as_float(row.get("price_change_percentage_24h")),
                    "change": as_float(row.get("price_change_24h")), "currency": currency.upper(),
                    "curve": thin(curve, 60), "open": True, "at": time.time()})
    return out


# --------------------------------------------------------------------------
# Currencies (ECB via Frankfurter)
# --------------------------------------------------------------------------

def read_ecb(base, targets):
    if not targets:
        return []
    last_error = None
    for host in ("https://api.frankfurter.dev/v1", "https://api.frankfurter.app"):
        try:
            start = datetime.fromtimestamp(time.time() - 21 * 86400).strftime("%Y-%m-%d")
            data = get_json(f"{host}/{start}..", "ECB rates", params={"base": base, "symbols": ",".join(targets)})
            break
        except SourceError as exc:
            last_error = exc
    else:
        raise last_error
    days = sorted((data.get("rates") or {}).items())
    out = []
    for target in targets:
        curve = [as_float(rates.get(target)) for _, rates in days]
        curve = [v for v in curve if v is not None]
        if not curve:
            continue
        previous = curve[-2] if len(curve) > 1 else None
        out.append({"symbol": f"{base}{target}", "name": f"{base}/{target}", "kind": "fx", "price": curve[-1],
                    "previous": previous, "change": (curve[-1] - previous) if previous else None,
                    "pct": ((curve[-1] / previous - 1) * 100) if previous else None, "currency": target,
                    "curve": curve, "open": False, "at": time.time()})
    return out


# --------------------------------------------------------------------------
# Weather (Open-Meteo) and earthquakes (USGS)
# --------------------------------------------------------------------------

WEATHER_CODES = {0: "clear", 1: "clear", 2: "cloudy", 3: "overcast", 45: "fog", 48: "fog",
                 51: "drizzle", 53: "drizzle", 55: "drizzle", 56: "drizzle", 57: "drizzle",
                 61: "rain", 63: "rain", 65: "rain", 66: "rain", 67: "rain", 80: "rain", 81: "rain", 82: "rain",
                 71: "snow", 73: "snow", 75: "snow", 77: "snow", 85: "snow", 86: "snow",
                 95: "storm", 96: "storm", 99: "storm"}


def read_weather(cities):
    if not cities:
        return []
    data = get_json("https://api.open-meteo.com/v1/forecast", "Open-Meteo", params={
        "latitude": ",".join(f"{c['lat']:.3f}" for c in cities),
        "longitude": ",".join(f"{c['lon']:.3f}" for c in cities),
        "current": "temperature_2m,weather_code,wind_speed_10m", "timezone": "auto"})
    rows = data if isinstance(data, list) else [data]
    out = []
    for city, row in zip(cities, rows):
        current = (row or {}).get("current") or {}
        temp = as_float(current.get("temperature_2m"))
        if temp is None:
            continue
        out.append({"city": city["name"], "temp": round(temp), "wind": as_float(current.get("wind_speed_10m")),
                    "sky": WEATHER_CODES.get(int(as_float(current.get("weather_code")) or 0), "cloudy")})
    return out


def read_quakes(min_mag=4.5):
    data = get_json("https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/4.5_day.geojson", "USGS")
    out = []
    for feature in data.get("features") or []:
        props = feature.get("properties") or {}
        mag = as_float(props.get("mag"))
        if mag is None or mag < min_mag:
            continue
        out.append({"mag": round(mag, 1), "place": props.get("place") or "", "at": (as_float(props.get("time")) or 0) / 1000,
                    "tsunami": bool(props.get("tsunami"))})
    out.sort(key=lambda q: q["at"], reverse=True)
    return out[:15]
