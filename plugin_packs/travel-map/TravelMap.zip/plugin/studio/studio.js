"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/TravelMap/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["PhotoSeconds", "PhotoPause", "RefreshHours", "PlaylistSeconds"];
const CHECK_FIELDS = ["Cluster", "ShowLegend", "ShowPhotos", "MapPan", "PlaceNames"];
const SELECT_FIELDS = ["Layout", "Region", "MapDetail", "PhotoOrder", "PhotoSize", "ThreadWidth"];
const TEXT_FIELDS = ["ServerUrl", "Title", "Folders"];
const KINDS = ["library", "playlist", "immich_album", "immich_all"];
const PINS = ["pin", "tack", "flag", "needle"];
let current = null;
let editing = false;
let collections = [];
let renderedCollections = "";
let palette = ["#b3261e", "#1f4e8c", "#2e6b34", "#c9922b", "#6b3d82", "#1f7a7a", "#c45a24", "#2b2b2b"];
const lists = { playlist: null, immich_album: null };
const listErrors = { playlist: "", immich_album: "" };

// Texte der Seite auf Deutsch, Englisch und Spanisch. Die Sprache ist eine
// Einstellung des Plugins und gilt auch für die Szene.
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["Travel Map", "Travel Map", "Travel Map"],
  lede: ["Eine Weltkarte im Stil eines alten Globus, mit Stecknadeln an den Orten, an denen deine Fotos entstanden sind. Die Orte stammen aus den GPS-Daten der Fotos. Jede Änderung hier wird sofort gespeichert.",
    "A world map in the style of an old globe, with push pins where your photos were taken. The places come from the photos' GPS data. Every change here is saved immediately.",
    "Un mapa del mundo al estilo de un globo antiguo, con chinchetas donde se tomaron tus fotos. Los lugares salen de los datos GPS de las fotos. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  refresh: ["Fotos neu einlesen", "Read photos again", "Volver a leer las fotos"],
  playlist: ["Playlist anlegen", "Create playlist", "Crear lista"],
  factNow: ["Gerade", "Now", "Ahora"],
  factPins: ["Auf der Karte", "On the map", "En el mapa"],
  factRead: ["Zuletzt eingelesen", "Last read", "Última lectura"],
  factVersion: ["Version", "Version", "Versión"],
  nowBusy: ["Liest Fotos ein …", "Reading photos …", "Leyendo fotos …"],
  nowIdle: ["Bereit", "Ready", "Listo"],
  pinsState: ["{photos} Fotos an {places} Orten", "{photos} photos at {places} places", "{photos} fotos en {places} lugares"],
  pinsTitle: ["Nadeln", "Pins", "Chinchetas"],
  pinsHint: ["Jede Zeile ist eine Sammlung von Fotos mit eigener Nadel. Fotos ohne GPS-Daten bekommen keine Nadel.",
    "Each row is a collection of photos with its own pin. Photos without GPS data get no pin.",
    "Cada fila es una colección de fotos con su propia chincheta. Las fotos sin datos GPS no reciben chincheta."],
  add: ["Sammlung hinzufügen", "Add collection", "Añadir colección"],
  remove: ["Entfernen", "Remove", "Quitar"],
  kind: ["Fotos aus", "Photos from", "Fotos de"],
  kind_library: ["Alle Fotos in DynaFrame", "All photos in DynaFrame", "Todas las fotos de DynaFrame"],
  kind_playlist: ["Einer Playlist von DynaFrame", "A DynaFrame playlist", "Una lista de DynaFrame"],
  kind_immich_album: ["Einem Immich-Album", "An Immich album", "Un álbum de Immich"],
  kind_immich_all: ["Allen Fotos in Immich", "All photos in Immich", "Todas las fotos de Immich"],
  ref_playlist: ["Playlist", "Playlist", "Lista"],
  ref_immich_album: ["Album", "Album", "Álbum"],
  ref_none: ["Keine Auswahl nötig", "Nothing to pick", "Nada que elegir"],
  pick: ["Bitte wählen …", "Please pick …", "Elige …"],
  loading: ["Lädt …", "Loading …", "Cargando …"],
  label: ["Name in der Legende", "Name in the legend", "Nombre en la leyenda"],
  labelPlaceholder: ["z. B. Sommerurlaube", "e.g. Summer holidays", "p. ej. Vacaciones de verano"],
  color: ["Farbe", "Colour", "Color"],
  pin_pin: ["Stecknadel", "Push pin", "Alfiler"],
  pin_tack: ["Reißzwecke", "Thumbtack", "Chincheta"],
  pin_flag: ["Fähnchen", "Flag", "Banderita"],
  pin_needle: ["Lange Nadel", "Long pin", "Aguja larga"],
  colBusy: ["Wird eingelesen …", "Reading …", "Leyendo …"],
  colWait: ["Wartet auf das Einlesen …", "Waiting to be read …", "Esperando la lectura …"],
  colOk: ["{located} von {total} Fotos haben einen Ort.", "{located} of {total} photos have a location.", "{located} de {total} fotos tienen ubicación."],
  colOkImmich: ["{located} Fotos mit Ort.", "{located} photos with a location.", "{located} fotos con ubicación."],
  max: ["Mehr als acht Sammlungen gehen nicht.", "No more than eight collections.", "No caben más de ocho colecciones."],
  mapTitle: ["Karte", "Map", "Mapa"],
  layout: ["Im Querformat", "In landscape", "En horizontal"],
  layoutOval: ["Ovale Weltkarte", "Oval world map", "Mapa del mundo ovalado"],
  layoutGlobes: ["Drei Globen", "Three globes", "Tres globos"],
  region: ["Ausschnitt", "Area", "Zona"],
  regionWorld: ["Die ganze Welt", "The whole world", "Todo el mundo"],
  regionAuto: ["Nur wo Nadeln stecken", "Only where pins are", "Solo donde hay chinchetas"],
  title: ["Titel auf der Karte", "Title on the map", "Título en el mapa"],
  titlePlaceholder: ["Unsere Reisen", "Our Travels", "Nuestros viajes"],
  layoutHint: ["Im Hochformat zeigt die Karte immer drei Globen übereinander.",
    "In portrait the map always shows three globes stacked.",
    "En vertical el mapa muestra siempre tres globos."],
  cluster: ["Nahe Nadeln zusammenfassen", "Merge pins that are close", "Agrupar chinchetas cercanas"],
  legend: ["Legende zeigen", "Show legend", "Mostrar leyenda"],
  photos: ["Ab und zu ein Foto an seiner Nadel zeigen", "Now and then show a photo at its pin", "De vez en cuando mostrar una foto junto a su chincheta"],
  photoSeconds: ["Foto zeigen für … Sekunden", "Show a photo for … seconds", "Mostrar una foto … segundos"],
  photoPause: ["Pause zwischen zwei Fotos (Sekunden)", "Pause between two photos (seconds)", "Pausa entre dos fotos (segundos)"],
  mapDetail: ["Details auf der Karte", "Map detail", "Detalle del mapa"],
  detail1: ["Schlicht", "Simple", "Sencillo"],
  detail2: ["Mehr: feinere Küsten, Flüsse, Meere", "More: finer coasts, rivers, seas", "Más: costas más finas, ríos, mares"],
  detail3: ["Fein: dazu große Gebirge und Wüsten", "Fine: plus major mountains and deserts", "Fino: además grandes montañas y desiertos"],
  detail4: ["Sehr fein: alle Gebirge, kleinste Inseln", "Very fine: all mountains, smallest islands", "Muy fino: todas las montañas, islas más pequeñas"],
  photoOrder: ["Reihenfolge der Fotos", "Order of the photos", "Orden de las fotos"],
  orderRandom: ["Zufällig, Ort für Ort", "Random, place by place", "Al azar, lugar por lugar"],
  orderOldest: ["Nach Datum, älteste zuerst", "By date, oldest first", "Por fecha, las más antiguas primero"],
  orderNewest: ["Nach Datum, neueste zuerst", "By date, newest first", "Por fecha, las más recientes primero"],
  orderThisDay: ["Heute vor … Jahren", "On this day … years ago", "Hoy hace … años"],
  orderHint: ["„Heute vor … Jahren“ zeigt Fotos, die an diesem Tag (± 3 Tage) in früheren Jahren entstanden sind. Gibt es keine, geht es zufällig weiter.",
    "“On this day” shows photos taken on this day (± 3 days) in earlier years. If there are none, it carries on at random.",
    "«Hoy hace … años» muestra fotos tomadas este día (± 3 días) en años anteriores. Si no hay, sigue al azar."],
  photoSize: ["Fotogröße", "Photo size", "Tamaño de la foto"],
  sizeS: ["Klein", "Small", "Pequeña"],
  sizeM: ["Mittel", "Medium", "Mediana"],
  sizeL: ["Groß", "Large", "Grande"],
  sizeXL: ["Sehr groß", "Extra large", "Muy grande"],
  threadWidth: ["Dicke des roten Fadens", "Width of the red thread", "Grosor del hilo rojo"],
  threadThin: ["Dünn", "Thin", "Fino"],
  threadNormal: ["Normal", "Normal", "Normal"],
  threadThick: ["Dick", "Thick", "Grueso"],
  threadXThick: ["Sehr dick", "Extra thick", "Muy grueso"],
  mapPan: ["Für jedes Foto die Karte zur Seite rücken", "Move the map aside for each photo", "Desplazar el mapa a un lado para cada foto"],
  placeNames: ["Ortsnamen bei OpenStreetMap nachschlagen", "Look up place names on OpenStreetMap", "Buscar nombres de lugares en OpenStreetMap"],
  placeHint: ["Fotos aus DynaFrame kennen nur ihre Koordinaten. Für die Bildunterschrift fragt das Plugin dann OpenStreetMap nach dem Ort, höchstens einmal pro Sekunde, und merkt sich die Antwort. Immich liefert den Ort selbst.",
    "Photos from DynaFrame only know their coordinates. For the caption the plugin asks OpenStreetMap for the place, at most once a second, and remembers the answer. Immich supplies the place itself.",
    "Las fotos de DynaFrame solo conocen sus coordenadas. Para el pie de foto el plugin pregunta el lugar a OpenStreetMap, como mucho una vez por segundo, y guarda la respuesta. Immich ya da el lugar."],
  refreshHours: ["Neue Fotos suchen alle … Stunden", "Look for new photos every … hours", "Buscar fotos nuevas cada … horas"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la lista (segundos)"],
  serverTitle: ["Immich-Server", "Immich server", "Servidor Immich"],
  serverHint: ["Nur nötig, wenn eine Sammlung von Immich kommt.", "Only needed when a collection comes from Immich.", "Solo hace falta si una colección viene de Immich."],
  serverUrl: ["Adresse", "Address", "Dirección"],
  apiKey: ["API-Schlüssel", "API key", "Clave API"],
  keySaved: ["gespeichert – leer lassen zum Behalten", "saved – leave empty to keep", "guardada; déjala vacía para conservarla"],
  keyMissing: ["noch keiner", "none yet", "aún ninguna"],
  test: ["Verbindung testen", "Test connection", "Probar conexión"],
  testing: ["Teste …", "Testing …", "Probando …"],
  keyHow: ["So bekommst du einen API-Schlüssel", "How to get an API key", "Cómo conseguir una clave API"],
  keyHint: ["In Immich oben rechts auf dein Profilbild, dann <b>Kontoeinstellungen &gt; API-Schlüssel &gt; Neuer API-Schlüssel</b>. Als Berechtigung reichen <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code>, <code>map.read</code>, <code>person.read</code> und <code>tag.read</code>; mit <b>Alle</b> geht es auch. Der Schlüssel bleibt im Plugin auf dem Rahmen.",
    "In Immich, click your profile picture at the top right, then <b>Account Settings &gt; API Keys &gt; New API Key</b>. The permissions <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code>, <code>map.read</code>, <code>person.read</code> and <code>tag.read</code> are enough; <b>All</b> works too. The key stays in the plugin on the frame.",
    "En Immich, pulsa tu foto de perfil arriba a la derecha y luego <b>Configuración de la cuenta &gt; Claves API &gt; Nueva clave API</b>. Bastan los permisos <code>asset.read</code>, <code>asset.view</code>, <code>album.read</code>, <code>map.read</code>, <code>person.read</code> y <code>tag.read</code>; con <b>Todos</b> también funciona. La clave se queda en el plugin del marco."],
  filterTitle: ["Welche Fotos aus Immich", "Which photos from Immich", "Qué fotos de Immich"],
  filterHint: ["Gilt für die Sammlungen aus Immich. Ohne Filter holt Travel Map alle Orte in einem Rutsch von der Karte in Immich, mit Filtern sucht sie die passenden Fotos (dauert etwas länger). Nach einer Änderung liest das Plugin die Fotos neu ein.",
    "Applies to the collections from Immich. Without filters the Travel Map fetches all places in one go from Immich's map; with filters it searches for the matching photos (takes a little longer). After a change the plugin reads the photos again.",
    "Se aplica a las colecciones de Immich. Sin filtros, Travel Map obtiene todos los lugares de una vez desde el mapa de Immich; con filtros busca las fotos que encajan (tarda un poco más). Tras un cambio el plugin vuelve a leer las fotos."],
  foldersTitle: ["Weitere Ordner auf dem Rahmen", "More folders on the frame", "Más carpetas en el marco"],
  foldersHint: ["Für die Sammlung „Alle Fotos in DynaFrame“: Das Plugin fragt DynaFrame nach seiner Mediendatenbank und den Medienordnern. Liegen Fotos woanders (z. B. ein eingehängtes NAS), trag die Ordner hier ein, einen pro Zeile.",
    "For the collection “All photos in DynaFrame”: the plugin asks DynaFrame for its media database and media folders. If photos live elsewhere (e.g. a mounted NAS), enter the folders here, one per line.",
    "Para la colección «Todas las fotos de DynaFrame»: el plugin pide a DynaFrame su base de medios y sus carpetas. Si hay fotos en otro sitio (p. ej. un NAS montado), escribe aquí las carpetas, una por línea."],
  noAnswer: ["Das Plugin antwortet nicht – vermutlich wurde es neu gestartet. Lade die Seite neu.",
    "The plugin is not responding – it was probably restarted. Reload the page.",
    "El plugin no responde; probablemente se ha reiniciado. Recarga la página."],
  restarted: ["Das Plugin wurde neu gestartet (HTTP {status}). Lade die Seite neu.",
    "The plugin was restarted (HTTP {status}). Reload the page.",
    "El plugin se ha reiniciado (HTTP {status}). Recarga la página."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  oclock: ["{time} Uhr", "{time}", "{time} h"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „Travel Map“ anlegen", "Create the playlist “Travel Map”", "Crear la lista «Travel Map»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistHint: ["Die Playlist enthält nur die Szene und ist eingeschaltet. Die Dauer gilt beim Anlegen; danach änderst du sie in der Playlist selbst. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist holds only the scene and is switched on. The duration applies when it is created; after that you change it in the playlist itself. You can also add the scene to any playlist yourself.",
    "La lista contiene solo la escena y está activada. La duración se aplica al crearla; después la cambias en la propia lista. También puedes añadir la escena a cualquier lista."],
  // Immich-Filter (wie Photo Mosaic)
  ifAlbumFilter: ["Album suchen …", "Search album …", "Buscar álbum …"],
  ifArchNo: ["Weglassen", "Leave out", "Excluir"],
  ifArchYes: ["Auch verwenden", "Use them too", "Usarlas también"],
  ifArchived: ["Archivierte Fotos", "Archived photos", "Fotos archivadas"],
  ifCameraOnly: ["Nur Fotos aus einer Kamera (ohne Screenshots und gespeicherte Bilder)", "Only photos taken with a camera (skips screenshots and saved images)", "Solo fotos de una cámara (sin capturas ni imágenes guardadas)"],
  ifCity: ["Stadt", "City", "Ciudad"],
  ifCountry: ["Land", "Country", "País"],
  ifDescription: ["Beschreibung enthält", "Description contains", "La descripción contiene"],
  ifFavAll: ["Alle Fotos", "All photos", "Todas las fotos"],
  ifFavOnly: ["Nur Favoriten", "Only favourites", "Solo favoritos"],
  ifFavoritesOnly: ["Favoriten", "Favourites", "Favoritos"],
  ifFileName: ["Dateiname enthält", "File name contains", "El nombre del archivo contiene"],
  ifGrpCamera: ["Kamera", "Camera", "Cámara"],
  ifGrpJunk: ["Aussortieren", "Skip the junk", "Descartar"],
  ifGrpSkip: ["Weglassen", "Leave out", "Excluir"],
  ifGrpText: ["Text", "Text", "Texto"],
  ifGrpWhat: ["Was", "What", "Qué"],
  ifGrpWhen: ["Wann", "When", "Cuándo"],
  ifGrpWhere: ["Wo", "Where", "Dónde"],
  ifGrpWho: ["Wer", "Who", "Quién"],
  ifLastDays: ["Nur die letzten … Tage (0 = aus)", "Only the last … days (0 = off)", "Solo los últimos … días (0 = desactivado)"],
  ifLens: ["Objektiv", "Lens", "Objetivo"],
  ifMake: ["Hersteller", "Make", "Marca"],
  ifMinFileKB: ["Mindestens … KB Dateigröße", "File size at least … KB", "Tamaño de archivo de al menos … KB"],
  ifMinMegapixels: ["Mindestens … Megapixel", "At least … megapixels", "Al menos … megapíxeles"],
  ifMinRating: ["Sterne", "Stars", "Estrellas"],
  ifModel: ["Modell", "Model", "Modelo"],
  ifNoScreenshots: ["Dateinamen weglassen, die nach Bildschirmfoto aussehen", "Skip file names that look like screenshots", "Omitir nombres de archivo que parecen capturas"],
  ifNotInAlbum: ["Nur Fotos, die in keinem Album sind", "Only photos that are not in any album", "Solo fotos que no están en ningún álbum"],
  ifOcrText: ["Text im Bild enthält", "Text in the image contains", "El texto de la imagen contiene"],
  ifOnThisDay: ["An diesem Tag: dasselbe Datum in früheren Jahren", "On this day: the same date in earlier years", "Este día: la misma fecha en años anteriores"],
  ifPeopleFilter: ["Person suchen …", "Search person …", "Buscar persona …"],
  ifPeopleHint: ["Keine angehakt: egal wer. Sonst nur Fotos, auf denen mindestens eine dieser Personen ist (aus der Gesichtserkennung von Immich).", "None ticked: anyone. Otherwise only photos with at least one of these people (from Immich's face recognition).", "Ninguna marcada: cualquiera. Si no, solo fotos con al menos una de estas personas (del reconocimiento facial de Immich)."],
  ifRating1: ["Mindestens 1 Stern", "At least 1 star", "Al menos 1 estrella"],
  ifRating2: ["Mindestens 2 Sterne", "At least 2 stars", "Al menos 2 estrellas"],
  ifRating3: ["Mindestens 3 Sterne", "At least 3 stars", "Al menos 3 estrellas"],
  ifRating4: ["Mindestens 4 Sterne", "At least 4 stars", "Al menos 4 estrellas"],
  ifRating5: ["5 Sterne", "5 stars", "5 estrellas"],
  ifRatingAny: ["Egal", "Any", "Da igual"],
  ifSkipAlbums: ["Alben weglassen", "Albums to leave out", "Álbumes a excluir"],
  ifSkipHint: ["Ein weggelassenes Album lässt alles darin weg, auch wenn es woanders noch vorkommt.", "Leaving out an album leaves out everything in it, wherever else it turns up.", "Excluir un álbum excluye todo lo que contiene, aunque aparezca en otro sitio."],
  ifSkipNames: ["Dateinamen weglassen (mit Komma getrennt)", "File names to leave out (separate with commas)", "Nombres de archivo a excluir (separados por comas)"],
  ifSkipTags: ["Tags weglassen", "Tags to leave out", "Etiquetas a excluir"],
  ifState: ["Bundesland", "State or province", "Estado o provincia"],
  ifTagFilter: ["Tag suchen …", "Search tag …", "Buscar etiqueta …"],
  ifTakenAfter: ["Aufgenommen ab", "Taken after", "Tomada desde"],
  ifTakenBefore: ["Aufgenommen bis", "Taken before", "Tomada hasta"],
  ifWithPeople: ["Nur Fotos mit Personen", "Only photos with people in them", "Solo fotos con personas"],
  ifNothingHere: ["Keine gefunden.", "None found.", "No se encontró ninguno."],
  ifOneChosen: ["1 ausgewählt", "1 ticked", "1 marcado"],
  ifManyChosen: ["{n} ausgewählt", "{n} ticked", "{n} marcados"],
  ifLoading: ["Lädt …", "Loading …", "Cargando …"],
  // DynaFrame-Filter (wie Photo Mosaic)
  dfTitle: ["Welche Fotos aus DynaFrame", "Which photos from DynaFrame", "Qué fotos de DynaFrame"],
  dfHint: ["Gilt für Fotos aus DynaFrame (alle Fotos, Ordner, Playlists). Die Daten liest DynaFrame selbst aus den Fotos (EXIF, auch Sterne aus .xmp-Dateien daneben). Fotos, die DynaFrame nicht in seiner Mediendatenbank hat, fallen weg, sobald ein Filter gesetzt ist.", "Applies to photos from DynaFrame (all photos, folders, playlists). DynaFrame reads the data from the photos itself (EXIF, also stars from .xmp files next to them). Photos that are not in DynaFrame's media database are left out as soon as a filter is set.", "Se aplica a las fotos de DynaFrame (todas las fotos, carpetas, listas). DynaFrame lee los datos de las propias fotos (EXIF, también las estrellas de archivos .xmp al lado). Las fotos que no están en la base de datos de DynaFrame se omiten en cuanto hay un filtro."],
  dfCount: ["{n} von {m} Fotos aus DynaFrame passen zu den Filtern.", "{n} of {m} photos from DynaFrame match the filters.", "{n} de {m} fotos de DynaFrame cumplen los filtros."],
  dfCameraOnly: ["Nur Fotos aus einer Kamera (ohne Screenshots und gespeicherte Bilder)", "Only photos taken with a camera (skips screenshots and saved images)", "Solo fotos de una cámara (sin capturas ni imágenes guardadas)"],
  dfPlace: ["Ort enthält", "Place contains", "El lugar contiene"],
  dfText: ["Titel, Beschreibung oder Tags enthalten", "Title, description or tags contain", "Título, descripción o etiquetas contienen"],
  dfFileName: ["Dateiname enthält", "File name contains", "El nombre del archivo contiene"],
  dfGrpCamera: ["Kamera", "Camera", "Cámara"],
  dfGrpJunk: ["Aussortieren", "Skip the junk", "Descartar"],
  dfGrpText: ["Text", "Text", "Texto"],
  dfGrpWhat: ["Was", "What", "Qué"],
  dfGrpWhen: ["Wann", "When", "Cuándo"],
  dfGrpWhere: ["Wo", "Where", "Dónde"],
  dfLastDays: ["Nur die letzten … Tage (0 = aus)", "Only the last … days (0 = off)", "Solo los últimos … días (0 = desactivado)"],
  dfLens: ["Objektiv", "Lens", "Objetivo"],
  dfMake: ["Hersteller", "Make", "Marca"],
  dfMinMegapixels: ["Mindestens … Megapixel", "At least … megapixels", "Al menos … megapíxeles"],
  dfMinRating: ["Sterne", "Stars", "Estrellas"],
  dfModel: ["Modell", "Model", "Modelo"],
  dfNoScreenshots: ["Dateinamen weglassen, die nach Bildschirmfoto aussehen", "Skip file names that look like screenshots", "Omitir nombres de archivo que parecen capturas"],
  dfOnThisDay: ["An diesem Tag: dasselbe Datum in früheren Jahren", "On this day: the same date in earlier years", "Este día: la misma fecha en años anteriores"],
  dfRating1: ["Mindestens 1 Stern", "At least 1 star", "Al menos 1 estrella"],
  dfRating2: ["Mindestens 2 Sterne", "At least 2 stars", "Al menos 2 estrellas"],
  dfRating3: ["Mindestens 3 Sterne", "At least 3 stars", "Al menos 3 estrellas"],
  dfRating4: ["Mindestens 4 Sterne", "At least 4 stars", "Al menos 4 estrellas"],
  dfRating5: ["5 Sterne", "5 stars", "5 estrellas"],
  dfRatingAny: ["Egal", "Any", "Da igual"],
  dfSkipNames: ["Dateinamen weglassen (mit Komma getrennt)", "File names to leave out (separate with commas)", "Nombres de archivo a excluir (separados por comas)"],
  dfTakenAfter: ["Aufgenommen ab", "Taken after", "Tomada desde"],
  dfTakenBefore: ["Aufgenommen bis", "Taken before", "Tomada hasta"],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  renderedCollections = "";
  if (current) renderCollections();
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) {
    throw new Error(t("restarted", { status: response.status }));
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(epoch) {
  if (!epoch) return "—";
  const date = new Date(epoch * 1000);
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang]);

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

// ------------------------------------------------------------ Nadeln zeichnen
// (dieselben Formen wie in der Szene)
function shade(hex, f) {
  const n = parseInt(hex.slice(1), 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  if (f >= 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; }
  return `rgb(${r | 0},${g | 0},${b | 0})`;
}

function ball(ctx, x, y, r, color) {
  const g = ctx.createRadialGradient(x - r * 0.38, y - r * 0.42, r * 0.08, x, y, r);
  g.addColorStop(0, shade(color, 0.65));
  g.addColorStop(0.35, color);
  g.addColorStop(1, shade(color, -0.55));
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,.75)";
  ctx.beginPath(); ctx.ellipse(x - r * 0.35, y - r * 0.4, r * 0.22, r * 0.15, -0.6, 0, Math.PI * 2); ctx.fill();
}

function needle(ctx, x0, y0, x1, y1, w) {
  const g = ctx.createLinearGradient(x0 - w, y0, x0 + w, y0);
  g.addColorStop(0, "#5d5d5d"); g.addColorStop(0.5, "#e6e6e6"); g.addColorStop(1, "#6b6b6b");
  ctx.strokeStyle = g;
  ctx.lineWidth = w;
  ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
}

function shadowLine(ctx, x, y, dx, dy, w, blur) {
  ctx.save();
  ctx.strokeStyle = "rgba(40,25,8,.28)";
  ctx.lineWidth = w;
  ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + dx, y + dy); ctx.stroke();
  ctx.fillStyle = "rgba(40,25,8,.22)";
  ctx.beginPath(); ctx.ellipse(x + dx, y + dy, blur, blur * 0.7, 0.4, 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

// Die Spitze jeder Nadel sitzt genau auf (x, y).
function drawPin(ctx, kind, x, y, r, color, alpha = 1) {
  ctx.save();
  ctx.globalAlpha = alpha;
  if (kind === "tack") {
    // Reißzwecke, schräg von oben
    ctx.fillStyle = "rgba(40,25,8,.3)";
    ctx.beginPath(); ctx.ellipse(x + r * 0.55, y + r * 0.2, r * 1.15, r * 0.75, 0, 0, Math.PI * 2); ctx.fill();
    const hx = x, hy = y - r * 0.55;
    ctx.fillStyle = shade(color, -0.45);
    ctx.beginPath(); ctx.ellipse(hx, hy + r * 0.18, r * 1.15, r * 0.82, 0, 0, Math.PI * 2); ctx.fill();
    const g = ctx.createRadialGradient(hx - r * 0.4, hy - r * 0.35, r * 0.1, hx, hy, r * 1.15);
    g.addColorStop(0, shade(color, 0.55)); g.addColorStop(0.5, color); g.addColorStop(1, shade(color, -0.3));
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.ellipse(hx, hy, r * 1.1, r * 0.78, 0, 0, Math.PI * 2); ctx.fill();
    ball(ctx, hx, hy - r * 0.08, r * 0.48, color);
  } else if (kind === "flag") {
    const top = y - r * 3.6;
    shadowLine(ctx, x, y, r * 1.8, -r * 1.1, r * 0.25, r * 0.5);
    ctx.strokeStyle = "#4a3219";
    ctx.lineWidth = Math.max(1, r * 0.22);
    ctx.lineCap = "round";
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, top); ctx.stroke();
    const fw = r * 2.1, fh = r * 1.35;
    const g = ctx.createLinearGradient(x, top, x + fw, top + fh);
    g.addColorStop(0, shade(color, 0.2)); g.addColorStop(1, shade(color, -0.25));
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(x, top + r * 0.1);
    ctx.bezierCurveTo(x + fw * 0.35, top - r * 0.35, x + fw * 0.65, top + r * 0.45, x + fw, top + r * 0.15);
    ctx.lineTo(x + fw * 0.82, top + fh * 0.6);
    ctx.lineTo(x + fw, top + fh + r * 0.05);
    ctx.bezierCurveTo(x + fw * 0.65, top + fh + r * 0.35, x + fw * 0.35, top + fh - r * 0.45, x, top + fh);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "rgba(40,25,8,.45)";
    ctx.lineWidth = Math.max(0.6, r * 0.08);
    ctx.stroke();
    ball(ctx, x, top - r * 0.12, r * 0.3, "#c9a24a");
  } else if (kind === "needle") {
    // Lange Glaskopfnadel, steil
    const hx = x + r * 0.55, hy = y - r * 3.4;
    shadowLine(ctx, x, y, r * 2.4, -r * 1.3, r * 0.22, r * 0.5);
    needle(ctx, x, y, hx, hy, Math.max(1, r * 0.17));
    ball(ctx, hx, hy, r * 0.62, color);
  } else {
    // Stecknadel mit rundem Kopf, leicht schräg
    const hx = x + r * 0.95, hy = y - r * 2.3;
    shadowLine(ctx, x, y, r * 2.1, -r * 0.7, r * 0.28, r * 0.85);
    needle(ctx, x, y, hx, hy, Math.max(1, r * 0.22));
    ball(ctx, hx, hy, r, color);
  }
  // Einstichpunkt
  ctx.fillStyle = "rgba(40,25,8,.55)";
  ctx.beginPath(); ctx.arc(x, y, Math.max(0.8, r * 0.14), 0, Math.PI * 2); ctx.fill();
  ctx.restore();
}

function pinCanvas(kind, color, size) {
  const c = document.createElement("canvas");
  const dpr = window.devicePixelRatio || 1;
  c.width = c.height = Math.round(size * dpr);
  const g = c.getContext("2d");
  g.scale(dpr, dpr);
  const r = size * (kind === "tack" ? 0.26 : kind === "pin" ? 0.2 : 0.17);
  const x = kind === "tack" ? size * 0.5 : kind === "needle" ? size * 0.4 : size * 0.28;
  const y = kind === "tack" ? size * 0.75 : size * 0.92;
  drawPin(g, kind, x, y, r, color);
  return c;
}

// ------------------------------------------------------------ Sammlungen

async function loadList(kind, force = false) {
  if (lists[kind] && !force) return;
  try {
    const result = await api(kind === "playlist" ? "./api/playlists" : "./api/albums");
    lists[kind] = kind === "playlist" ? result.playlists : result.albums;
    listErrors[kind] = "";
  } catch (error) {
    lists[kind] = null;
    listErrors[kind] = error.message;
  }
  refillRefs(kind);
}

// Änderungen an den Sammlungen gehen nacheinander raus, und solange eine
// unterwegs ist, überschreibt kein älterer Stand vom Plugin die Zeilen
// (sonst ging z. B. die gewählte Playlist verloren, wenn gleich danach die
// Nadel geändert wurde).
let commitChain = Promise.resolve();
let pendingCommits = 0;
let lastEdit = 0;
let lastCommitDone = 0;
function commit() {
  const snapshot = JSON.parse(JSON.stringify(collections));
  pendingCommits++;
  lastEdit = Date.now();
  commitChain = commitChain.then(() => save({ Collections: snapshot })).finally(() => { pendingCommits--; lastCommitDone = Date.now(); });
}

function needsRefOf(col) {
  return col.kind === "playlist" || col.kind === "immich_album";
}

function statusText(col) {
  const s = (current?.status || {})[col.id] || {};
  if (s.state === "busy") return [t("colBusy"), ""];
  if (s.state === "error") return [s.error || "", "bad"];
  if (s.state === "ok") {
    if (col.kind === "immich_all") return [t("colOkImmich", { located: fmt(s.located) }), "ok"];
    return [t("colOk", { located: fmt(s.located), total: fmt(s.total) }), s.located ? "ok" : ""];
  }
  return [current?.busy ? t("colWait") : "", ""];
}

function collectionsKey() {
  return JSON.stringify([collections, lists, listErrors, lang]);
}

// Auf dem Handy liegt zwischen Antippen und "click" etwas Zeit; wird die Zeile
// in der Zeit neu gebaut, geht das Tippen ins Leere. Darum werden die Zeilen
// nur neu gebaut, wenn gerade niemand damit hantiert, und Änderungen an einer
// Zeile werden an Ort und Stelle eingetragen.
let lastTouch = 0;
el("collections").addEventListener("pointerdown", () => { lastTouch = Date.now(); }, true);
el("collections").addEventListener("touchstart", () => { lastTouch = Date.now(); }, { capture: true, passive: true });

function busyRows() {
  const box = el("collections");
  return (box.contains(document.activeElement) && document.activeElement !== box) || Date.now() - lastTouch < 2500;
}

function fillRef(ref, col) {
  ref.textContent = "";
  ref.disabled = false;
  const needsRef = col.kind === "playlist" || col.kind === "immich_album";
  if (!needsRef) {
    ref.add(new Option(t("ref_none"), ""));
    ref.disabled = true;
    return;
  }
  const items = lists[col.kind];
  if (!items) {
    ref.add(new Option(listErrors[col.kind] || t("loading"), col.ref));
    if (!listErrors[col.kind]) loadList(col.kind);
    return;
  }
  ref.add(new Option(t("pick"), ""));
  for (const item of items) {
    const count = item.count ? ` (${fmt(item.count)})` : "";
    ref.add(new Option(`${item.name}${count}`, String(item.id), false, String(item.id) === col.ref));
  }
  if (col.ref && !items.some((i) => String(i.id) === col.ref)) ref.add(new Option(`#${col.ref}`, col.ref, false, true));
}

function refillRefs(kind) {
  const box = el("collections");
  for (const col of collections) {
    if (col.kind !== kind) continue;
    const ref = box.querySelector(`select[data-ref="${col.id}"]`);
    if (ref && document.activeElement !== ref) fillRef(ref, col);
  }
  if (renderedCollections) renderedCollections = collectionsKey();
}

function renderCollections() {
  const key = collectionsKey();
  const box = el("collections");
  if (key === renderedCollections) {
    // Nur die Zeilen mit dem Stand auffrischen; die Felder bleiben, wie sie sind.
    for (const col of collections) {
      const meta = box.querySelector(`[data-meta="${col.id}"]`);
      if (meta) { const [text, tone] = statusText(col); meta.textContent = text; meta.className = `meta ${tone}`; }
    }
    return;
  }
  if (renderedCollections && busyRows()) return;
  renderedCollections = key;
  box.textContent = "";
  collections.forEach((col, index) => {
    const row = document.createElement("div");
    row.className = "collection";

    const view = document.createElement("div");
    view.className = "pinview";
    view.appendChild(pinCanvas(col.pin, col.color, 44));
    row.appendChild(view);

    const kindField = document.createElement("label");
    kindField.className = "field";
    kindField.innerHTML = `<span>${t("kind")}</span>`;
    const kind = document.createElement("select");
    for (const k of KINDS) kind.add(new Option(t(`kind_${k}`), k, false, k === col.kind));
    kind.addEventListener("change", () => {
      col.kind = kind.value;
      col.ref = "";
      refLabel.innerHTML = `<span>${needsRefOf(col) ? t(`ref_${col.kind}`) : "&nbsp;"}</span>`;
      refLabel.appendChild(ref);
      fillRef(ref, col);
      renderedCollections = collectionsKey();
      commit();
    });
    kindField.appendChild(kind);
    row.appendChild(kindField);

    const refLabel = document.createElement("label");
    refLabel.className = "field";
    refLabel.innerHTML = `<span>${needsRefOf(col) ? t(`ref_${col.kind}`) : "&nbsp;"}</span>`;
    const ref = document.createElement("select");
    ref.dataset.ref = col.id;
    fillRef(ref, col);
    ref.addEventListener("change", () => {
      col.ref = ref.value;
      const item = (lists[col.kind] || []).find((i) => String(i.id) === ref.value);
      if (item && !col.name) { col.name = item.name.slice(0, 40); name.value = col.name; }
      renderedCollections = collectionsKey();
      commit();
    });
    refLabel.appendChild(ref);
    row.appendChild(refLabel);

    const nameField = document.createElement("label");
    nameField.className = "field";
    nameField.innerHTML = `<span>${t("label")}</span>`;
    const name = document.createElement("input");
    name.type = "text";
    name.maxLength = 40;
    name.value = col.name;
    name.placeholder = t("labelPlaceholder");
    name.addEventListener("change", () => { col.name = name.value.trim(); renderedCollections = collectionsKey(); commit(); });
    nameField.appendChild(name);
    row.appendChild(nameField);

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "secondary remove";
    remove.textContent = t("remove");
    remove.addEventListener("click", () => {
      collections.splice(index, 1);
      renderedCollections = "";
      renderCollections();
      commit();
    });
    row.appendChild(remove);

    const look = document.createElement("div");
    look.className = "look";
    const swatches = document.createElement("div");
    swatches.className = "swatches";
    swatches.setAttribute("role", "group");
    swatches.setAttribute("aria-label", t("color"));
    for (const color of palette) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "swatch";
      b.style.background = color;
      b.setAttribute("aria-pressed", String(color.toLowerCase() === col.color.toLowerCase()));
      b.addEventListener("click", () => {
        col.color = color;
        for (const other of swatches.children) other.setAttribute("aria-pressed", String(other === b));
        redrawPins();
        renderedCollections = collectionsKey();
        commit();
      });
      swatches.appendChild(b);
    }
    const pins = document.createElement("div");
    pins.className = "pins";
    for (const kindName of PINS) {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "secondary pinchoice";
      b.title = t(`pin_${kindName}`);
      b.setAttribute("aria-label", t(`pin_${kindName}`));
      b.setAttribute("aria-pressed", String(kindName === col.pin));
      b.appendChild(pinCanvas(kindName, col.color, 34));
      b.addEventListener("click", () => {
        col.pin = kindName;
        for (const other of pins.children) other.setAttribute("aria-pressed", String(other === b));
        redrawPins();
        renderedCollections = collectionsKey();
        commit();
      });
      pins.appendChild(b);
    }
    function redrawPins() {
      view.replaceChildren(pinCanvas(col.pin, col.color, 44));
      PINS.forEach((kindName, i) => pins.children[i].replaceChildren(pinCanvas(kindName, col.color, 34)));
    }
    look.append(swatches, pins);
    row.appendChild(look);

    const meta = document.createElement("p");
    const [text, tone] = statusText(col);
    meta.className = `meta ${tone}`;
    meta.dataset.meta = col.id;
    meta.textContent = text;
    row.appendChild(meta);

    box.appendChild(row);
  });
  el("addCollection").disabled = collections.length >= 8;
}

el("addCollection").addEventListener("click", () => {
  if (collections.length >= 8) { setStatus(t("max"), "bad", "collectionsNote"); return; }
  const used = new Set(collections.map((c) => c.color));
  const color = palette.find((c) => !used.has(c)) || palette[0];
  const pin = PINS[collections.length % PINS.length];
  collections.push({ id: Math.random().toString(36).slice(2, 10), kind: "playlist", ref: "", name: "", color, pin });
  renderedCollections = "";
  renderCollections();
  loadList("playlist");
  commit();
});

// ------------------------------------------------------------ Stand

function render(state, started = 0) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  palette = state.palette || palette;
  el("factNow").textContent = state.busy ? t("nowBusy") : t("nowIdle");
  el("factPins").textContent = state.photos ? t("pinsState", { photos: fmt(state.photos), places: fmt(state.places) }) : "—";
  el("factRead").textContent = clock(state.at);
  el("factVersion").textContent = state.version;
  if (document.activeElement !== el("MakePlaylist")) el("MakePlaylist").value = String(Boolean(state.settings.MakePlaylist));
  el("playlistNote").textContent = state.ownPlaylist || "";
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Travel Map ${state.version}] `);

  if (!editing) {
    for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) el(name).value = s[name];
    el("Language").value = lang;
    if (document.activeElement !== el("ApiKey")) {
      el("ApiKey").placeholder = state.secretsSet.ApiKey ? t("keySaved") : t("keyMissing");
    }
    // Ein Stand, der abgefragt wurde, bevor die letzte Änderung gespeichert war,
    // ist veraltet und darf die Auswahl nicht zurückdrehen.
    // Nur einen wirklich anderen Stand übernehmen und dann die Zeilen neu bauen,
    // sonst hingen die Zeilen noch an den alten Einträgen.
    if (!busyRows() && !pendingCommits && started > lastCommitDone && started > lastEdit &&
        JSON.stringify(s.Collections) !== JSON.stringify(collections)) {
      collections = JSON.parse(JSON.stringify(s.Collections));
      renderedCollections = "";
    }
  }
  el("PhotoSeconds").disabled = !s.ShowPhotos;
  el("PhotoPause").disabled = !s.ShowPhotos;
  el("PhotoSize").disabled = !s.ShowPhotos;
  el("PhotoOrder").disabled = !s.ShowPhotos;
  el("ThreadWidth").disabled = !s.ShowPhotos;
  el("MapPan").disabled = !s.ShowPhotos;
  renderCollections();
  ifRender(s);
  dfRender(s, state);
}

async function refresh() {
  try {
    const started = Date.now();
    render(await api("./api/state"), started);
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS, ["ApiKey"])) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
}
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
el("Title").addEventListener("change", (e) => save({ Title: e.target.value }));
el("Folders").addEventListener("change", (e) => save({ Folders: e.target.value }));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save({ Language: e.target.value });
});

async function saveServer() {
  const changes = { ServerUrl: el("ServerUrl").value };
  const key = el("ApiKey").value.trim();
  if (key) changes.ApiKey = key;
  const changed = await save(changes);
  el("ApiKey").value = "";
  if (changed.includes("ServerUrl") || changed.includes("ApiKey")) await testConnection();
}

async function testConnection() {
  setStatus(t("testing"), "busy", "testNote");
  try {
    const result = await api("./api/test", { method: "POST" });
    setStatus(result.message, result.ok ? "ok" : "bad", "testNote");
    if (result.ok) loadList("immich_album", true);
  } catch (error) {
    setStatus(error.message, "bad", "testNote");
  }
}

el("ServerUrl").addEventListener("change", saveServer);
el("ApiKey").addEventListener("change", saveServer);
el("testButton").addEventListener("click", async () => {
  if (el("ApiKey").value.trim() || el("ServerUrl").value !== (current?.settings.ServerUrl || "")) await saveServer();
  else await testConnection();
});
el("refreshButton").addEventListener("click", async () => {
  try {
    const result = await api("./api/refresh", { method: "POST" });
    setStatus(result.message || "", "busy");
    setTimeout(refresh, 1500);
  } catch (error) {
    setStatus(error.message, "bad");
  }
});
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));

refresh();
setInterval(refresh, 4000);

// ------------------------------------------------------------ Immich-Filter (wie Photo Mosaic, immich_filters.py)

const IF_TEXT = ["City", "State", "Country", "TakenAfter", "TakenBefore", "Make", "Model", "Lens", "Description", "OcrText", "FileName", "SkipNames"];
const IF_NUMBER = ["LastDays", "MinMegapixels", "MinFileKB"];
const IF_CHECK = ["OnThisDay", "WithPeople", "CameraOnly", "NoScreenshots", "NotInAlbum"];
const IF_BOOL_SELECT = ["FavoritesOnly", "IncludeArchived"];
const IF_PICKERS = { People: ["./api/people", "people"], SkipAlbums: ["./api/albums", "albums"], SkipTags: ["./api/tags", "tags"] };
const ifLists = {};
const ifErrors = {};
const ifEsc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const ifHere = (names) => names.filter((name) => el(name));
let ifSettings = null;

async function ifLoad(name, force = false) {
  if (ifLists[name] && !force) return;
  ifLists[name] = ifLists[name] || [];
  try {
    const result = await api(IF_PICKERS[name][0]);
    if (result.success === false) throw new Error(result.error || "?");
    ifLists[name] = result[IF_PICKERS[name][1]] || [];
    ifErrors[name] = "";
  } catch (error) {
    ifLists[name] = [];
    ifErrors[name] = error.message;
  }
  ifLists[name].loaded = true;
  if (ifSettings) ifRenderPickers(ifSettings);
}

function ifRenderPickers(s) {
  for (const name of Object.keys(IF_PICKERS)) {
    const box = el(name + "List");
    if (!box) continue;
    const items = ifLists[name];
    if (!items || !items.loaded) {
      if (s.ServerUrl && !items) ifLoad(name);
      if (!items) box.innerHTML = s.ServerUrl ? `<p class="hint">${ifEsc(t("ifLoading"))}</p>` : "";
      continue;
    }
    const chosen = new Set((s[name] || "").split(",").filter(Boolean));
    const query = el(name + "Filter").value.trim().toLowerCase();
    // Lange Listen: angehakte und gesuchte zuerst, höchstens 200 zeigen
    const rows = items.filter((a) => chosen.has(String(a.id)) || !query || String(a.name).toLowerCase().includes(query))
      .sort((a, b) => (chosen.has(String(b.id)) - chosen.has(String(a.id))) || String(a.name).localeCompare(String(b.name)))
      .slice(0, Math.max(200, chosen.size));
    const html = rows.map((a) => `<label title="${ifEsc(a.name)}"><input type="checkbox" value="${ifEsc(String(a.id))}" ${chosen.has(String(a.id)) ? "checked" : ""}>
        <span class="name">${ifEsc(a.name)}</span>${a.count != null ? `<span class="count">${fmt(a.count)}</span>` : ""}</label>`).join("");
    if (box.dataset.html !== html) { box.innerHTML = html; box.dataset.html = html; }
    const note = el(name + "Note");
    note.textContent = ifErrors[name] || (!items.length ? t("ifNothingHere") : chosen.size ? t(chosen.size === 1 ? "ifOneChosen" : "ifManyChosen", { n: chosen.size }) : "");
    note.className = "status" + (ifErrors[name] ? " bad" : "");
  }
}

function ifRender(s) {
  if (!el("immichFilters")) return;
  if (ifSettings && ifSettings.ServerUrl !== s.ServerUrl) {
    for (const name of Object.keys(ifLists)) delete ifLists[name];
  }
  ifSettings = s;
  for (const name of ifHere(IF_TEXT.concat(IF_NUMBER))) {
    if (document.activeElement !== el(name)) el(name).value = s[name] ?? "";
  }
  for (const name of ifHere(IF_CHECK)) el(name).checked = Boolean(s[name]);
  for (const name of ifHere(IF_BOOL_SELECT)) el(name).value = String(Boolean(s[name]));
  if (el("MinRating")) el("MinRating").value = String(s.MinRating || 0);
  if (el("Orientation")) el("Orientation").value = s.Orientation || "any";
  ifRenderPickers(s);
}

for (const name of ifHere(IF_TEXT)) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of ifHere(IF_NUMBER)) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) || 0 }));
for (const name of ifHere(IF_CHECK)) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of ifHere(IF_BOOL_SELECT)) el(name).addEventListener("change", (e) => save({ [name]: e.target.value === "true" }));
if (el("MinRating")) el("MinRating").addEventListener("change", (e) => save({ MinRating: Number(e.target.value) }));
if (el("Orientation")) el("Orientation").addEventListener("change", (e) => save({ Orientation: e.target.value }));
for (const name of Object.keys(IF_PICKERS)) {
  if (!el(name + "List")) continue;
  el(name + "Filter").addEventListener("input", () => ifSettings && ifRenderPickers(ifSettings));
  el(name + "List").addEventListener("change", () => {
    const list = el(name + "List");
    const ticked = [...list.querySelectorAll("input:checked")].map((box) => box.value);
    // Angehakte behalten, die der Suchfilter gerade ausblendet
    const hidden = (ifSettings[name] || "").split(",").filter(Boolean)
      .filter((id) => !list.querySelector(`input[value="${CSS.escape(id)}"]`));
    save({ [name]: [...hidden, ...ticked].join(",") });
  });
}
// ------------------------------------------------------------ DynaFrame-Filter (wie Photo Mosaic, dynaframe_filters.py)

const DF_TEXT = ["DfAfter", "DfBefore", "DfPlace", "DfMake", "DfModel", "DfLens", "DfText", "DfFileName", "DfSkipNames"];
const DF_NUMBER = ["DfLastDays", "DfMinMegapixels"];
const DF_CHECK = ["DfOnThisDay", "DfCameraOnly", "DfNoScreenshots"];
const dfHere = (names) => names.filter((name) => el(name));

// render(): dfRender(state.settings, state) aufrufen
function dfRender(s, state) {
  if (!el("dynaframeFilters")) return;
  for (const name of dfHere(DF_TEXT.concat(DF_NUMBER))) {
    if (document.activeElement !== el(name)) el(name).value = s[name] || (DF_NUMBER.includes(name) ? 0 : "");
  }
  for (const name of dfHere(DF_CHECK)) el(name).checked = Boolean(s[name]);
  if (el("DfMinRating")) el("DfMinRating").value = String(s.DfMinRating || 0);
  if (el("DfOrientation")) el("DfOrientation").value = s.DfOrientation || "any";
  const note = el("dfNote");
  const count = state && state.dfCount;
  if (note) {
    note.textContent = count && count.total ? t("dfCount", { n: fmt(count.kept), m: fmt(count.total) }) : "";
    note.className = "status" + (count && count.total && !count.kept ? " bad" : "");
  }
}

for (const name of dfHere(DF_TEXT)) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of dfHere(DF_NUMBER)) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) || 0 }));
for (const name of dfHere(DF_CHECK)) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
if (el("DfMinRating")) el("DfMinRating").addEventListener("change", (e) => save({ DfMinRating: Number(e.target.value) }));
if (el("DfOrientation")) el("DfOrientation").addEventListener("change", (e) => save({ DfOrientation: e.target.value }));

// ---- accordion:start
// ------------------------------------------------------------ Aufklappen (tools/plugin-vorlage/accordion)
// Karten und Abschnitte auf- und zuklappen, damit lange Plugin-Seiten übersichtlich
// bleiben. Gesteuert nur über Attribute im HTML (Anleitung: accordion/README.md):
//   <section class="card" data-fold="immich" data-fold-when="uses:immich"> …
//   <h3 class="sub" data-fold="immichFilter" data-fold-start="closed" data-fold-badge="count">
// Eigene Texte (DE/EN/ES) stehen hier, die Sprache kommt aus <html lang>.
(() => {
  const TEXT = {
    open: ["Aufklappen", "Expand", "Desplegar"],
    close: ["Zuklappen", "Collapse", "Plegar"],
    active: ["{n} aktiv", "{n} active", "{n} activos"],
    none: ["Keine Filter", "No filters", "Sin filtros"],
    set: ["Eingerichtet", "Set up", "Configurado"],
    optional: ["Optional", "Optional", "Opcional"],
    lines: ["{n} eingetragen", "{n} entered", "{n} introducidos"],
    svcOk: ["Alles erreichbar", "All reachable", "Todo accesible"],
    svcBad: ["{n} Problem", "{n} problem", "{n} problema"],
    svcBads: ["{n} Probleme", "{n} problems", "{n} problemas"],
    svcWarn: ["Teilweise", "Partly", "Parcial"],
    svcWait: ["Wird geprüft", "Checking", "Comprobando"],
    "off:immich": ["Nur mit Immich als Quelle nötig", "Only needed with Immich as source", "Solo con Immich como fuente"],
    "off:dynaframe": ["Nur mit Fotos aus DynaFrame nötig", "Only needed with photos from DynaFrame", "Solo con fotos de DynaFrame"],
    "off:library": ["Nur mit „Alle Fotos in DynaFrame“ nötig", "Only needed with “All photos in DynaFrame”", "Solo con «Todas las fotos de DynaFrame»"],
    off: ["Gerade nicht gebraucht", "Not needed right now", "No se necesita ahora"],
  };
  const LANGS = ["de", "en", "es"];
  const say = (key, n) => {
    const row = TEXT[key] || TEXT.off;
    const i = Math.max(0, LANGS.indexOf(document.documentElement.lang));
    return (row[i] ?? row[0]).replace("{n}", String(n));
  };
  const store = (() => {
    try { return window.localStorage; } catch (_) { return null; }
  })();
  const keyOf = (id) => `fold:${location.pathname}:${id}`;
  const remembered = (id) => {
    try { return JSON.parse(store?.getItem(keyOf(id)) || "null"); } catch (_) { return null; }
  };
  const remember = (id, value) => {
    try { store?.setItem(keyOf(id), JSON.stringify(value)); } catch (_) { /* privat */ }
  };

  // Quellen-Auswahl: jedes <select>, das eine Immich-Option hat (auch Quellen-Zeilen, die studio.js erst später baut)
  const DF_KINDS = ["library", "folders", "playlist", "same"];
  function sourceValues() {
    const values = [];
    for (const select of document.querySelectorAll("select")) {
      if ([...select.options].some((o) => o.value.startsWith("immich"))) values.push(select.value);
    }
    return values;
  }
  function holds(rule) {
    // "uses:immich", "uses:dynaframe", "uses:library" oder "Feld=wert1,wert2", mehrere mit "|"
    return rule.split("|").some((part) => {
      part = part.trim();
      if (part.startsWith("uses:")) {
        const values = sourceValues();
        if (!values.length) return true; // keine Quellen-Auswahl auf der Seite: immer gebraucht
        const what = part.slice(5);
        if (what === "immich") return values.some((v) => v.startsWith("immich"));
        if (what === "dynaframe") return values.some((v) => DF_KINDS.includes(v));
        return values.includes(what);
      }
      const [id, list] = part.split("=");
      const field = document.getElementById(id);
      if (!field) return true;
      const value = field.type === "checkbox" ? String(field.checked) : field.value;
      return (list || "").split(",").map((v) => v.trim()).includes(value);
    });
  }

  // Wie viele Einstellungen in einem Bereich vom Standard abweichen (Felder mit Wert, Häkchen, Auswahl ≠ erste Option)
  function activeCount(nodes) {
    let n = 0;
    for (const node of nodes) {
      for (const field of node.querySelectorAll("input, select, textarea")) {
        if (field.closest(".checks") || field.type === "password" || field.type === "button") continue;
        if (field.type === "checkbox") n += field.checked ? 1 : 0;
        else if (field.tagName === "SELECT") n += field.selectedIndex > 0 ? 1 : 0;
        else n += field.value.trim() && field.value.trim() !== "0" ? 1 : 0;
      }
      for (const list of node.querySelectorAll(".checks")) n += list.querySelector("input:checked") ? 1 : 0;
    }
    return n;
  }

  function badgeFor(fold) {
    if (!fold.needed) return [say(`off:${fold.rule.replace(/^uses:/, "").split("|")[0]}`), "off"];
    const nodes = fold.body();
    switch (fold.badge) {
      case "count": {
        const n = activeCount(nodes);
        return n ? [say("active", n), "on"] : [say("none"), ""];
      }
      case "filled": {
        const filled = nodes.some((node) => [...node.querySelectorAll('input[type="url"], input[type="text"]')].some((f) => f.value.trim()));
        return filled ? [say("set"), "on"] : [say("optional"), ""];
      }
      case "lines": {
        const n = nodes.reduce((sum, node) => sum + [...node.querySelectorAll("textarea")]
          .reduce((s, area) => s + area.value.split("\n").filter((line) => line.trim()).length, 0), 0);
        return n ? [say("lines", n), "on"] : [say("optional"), ""];
      }
      case "services": {
        const bad = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.bad").length, 0);
        const warn = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.warn").length, 0);
        const ok = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.ok").length, 0);
        if (bad) return [say(bad === 1 ? "svcBad" : "svcBads", bad), "bad"];
        if (warn) return [say("svcWarn"), "warn"];
        return ok ? [say("svcOk"), "ok"] : [say("svcWait"), ""];
      }
      default:
        return ["", ""];
    }
  }

  const folds = [];

  function setup(head, id, isCard) {
    const host = isCard ? head : head.parentElement;
    const title = isCard ? (head.querySelector(":scope > .card-head") || head.querySelector(":scope > h2")) : head;
    if (!title) return;
    const bar = document.createElement("div");
    bar.className = "fold-bar" + (isCard ? " fold-bar-card" : " fold-bar-sub");
    bar.setAttribute("role", "button");
    bar.tabIndex = 0;
    title.replaceWith(bar);
    bar.append(title);
    const badge = document.createElement("span");
    badge.className = "fold-badge";
    const chevron = document.createElement("span");
    chevron.className = "fold-chevron";
    chevron.setAttribute("aria-hidden", "true");
    bar.append(badge, chevron);
    let body = null;
    if (!isCard) {
      // Unterabschnitt: alles bis zum nächsten h3.sub / <details> / Kartenende
      body = document.createElement("div");
      body.className = "fold-body";
      let next = bar.nextElementSibling;
      while (next && !(next.matches("h3.sub, .fold-bar, details"))) {
        const after = next.nextElementSibling;
        body.append(next);
        next = after;
      }
      bar.after(body);
    }
    const src = head;
    const fold = {
      id, host, bar, body: () => (isCard ? [...host.children].filter((c) => c !== bar) : [body]),
      rule: src.dataset.foldWhen || "",
      startClosed: src.dataset.foldStart === "closed",
      badge: src.dataset.foldBadge || "", badgeEl: badge,
      needed: true, open: true, isCard, sub: body,
    };
    const toggle = (e) => {
      if (e.type === "click" && e.target.closest("button, a, input, select, textarea, label")) return;
      if (e.type === "keydown" && (e.target !== bar || (e.key !== "Enter" && e.key !== " "))) return;
      if (e.type === "keydown") e.preventDefault();
      show(fold, !fold.open);
      remember(id, { open: fold.open, needed: fold.needed });
    };
    bar.addEventListener("click", toggle);
    bar.addEventListener("keydown", toggle);
    folds.push(fold);
    if (fold.rule) show(fold, false); // erst entscheiden, wenn studio.js den Stand gesetzt hat
    else start(fold);
  }

  function start(fold) {
    const saved = remembered(fold.id);
    fold.needed = fold.rule ? holds(fold.rule) : true;
    fold.wasNeeded = fold.needed;
    fold.started = true;
    show(fold, saved && saved.needed === fold.needed ? saved.open : wanted(fold));
  }

  function wanted(fold) {
    if (!fold.needed) return false;
    if (fold.badge === "services") {
      const [, tone] = badgeFor(fold);
      if (tone === "bad") return true;
    }
    return !fold.startClosed;
  }

  function show(fold, open) {
    fold.open = open;
    fold.host.classList.toggle("fold-closed", fold.isCard && !open);
    if (fold.sub) fold.sub.hidden = !open;
    fold.bar.setAttribute("aria-expanded", String(open));
    fold.bar.title = say(open ? "close" : "open");
  }

  // Bereit, sobald studio.js den ersten Stand gezeigt hat (Version steht da) oder nach 5 s
  const born = Date.now();
  function stateShown() {
    const version = document.getElementById("factVersion");
    return !version || /\d/.test(version.textContent) || Date.now() - born > 5000;
  }

  function refresh() {
    const ready = stateShown();
    for (const fold of folds) {
      if (!fold.started) {
        if (!ready) continue;
        start(fold);
      }
      fold.needed = fold.rule ? holds(fold.rule) : true;
      if (fold.needed !== fold.wasNeeded) {
        // Quelle gewechselt: Karte auf- bzw. zuklappen, eigene Wahl vergessen
        fold.wasNeeded = fold.needed;
        remember(fold.id, null);
        show(fold, wanted(fold));
      }
      fold.host.classList.toggle("fold-unused", fold.isCard && !fold.needed);
      const [text, tone] = badgeFor(fold);
      // Verbindungen: bei einem neuen Problem von selbst aufklappen
      if (fold.badge === "services" && tone === "bad" && fold.lastTone !== "bad") show(fold, true);
      fold.lastTone = tone;
      if (fold.badgeEl.textContent !== text) fold.badgeEl.textContent = text;
      fold.badgeEl.className = "fold-badge" + (tone ? ` ${tone}` : "");
      fold.badgeEl.hidden = !text;
      fold.bar.title = say(fold.open ? "close" : "open");
    }
  }

  function init() {
    for (const card of document.querySelectorAll(".card[data-fold]")) setup(card, card.dataset.fold, true);
    for (const head of document.querySelectorAll("h3.sub[data-fold]")) setup(head, head.dataset.fold, false);
    refresh();
    document.addEventListener("change", refresh);
    document.addEventListener("input", refresh);
    setInterval(refresh, 1000); // studio.js setzt Werte beim Abfragen des Stands
  }

  window.Fold = { refresh, open: (id, value = true) => { const f = folds.find((x) => x.id === id); if (f) show(f, value); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
// ---- accordion:end
