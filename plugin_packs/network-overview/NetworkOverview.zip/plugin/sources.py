"""Die Datenquellen von Network Overview.

- PiHole: Pi-hole 6 (REST-API unter /api, App-Passwort) oder Pi-hole 5
  (/admin/api.php mit API-Token). Anfragen, Geblocktes, aktivste Geräte und
  Pi-holes eigene Geräteliste.
- Fritzbox: TR-064 auf Port 49000 (SOAP, Digest-Anmeldung). Geräteliste mit
  online/offline, LAN/WLAN/Gast, Internet-Zähler und Verbindungsstatus.
- Unraid: die offizielle GraphQL-API ab Unraid 7.2 (API-Key). Array,
  Platten mit Temperatur, Cache, CPU, RAM, Docker.
- Glances: für ältere Unraid-Versionen oder andere Server (REST-API v4/v3).

Jede Quelle hat update(), das die Daten holt und in self.data ablegt, und
ein status-Dict für die Plugin-Seite. Fehler kommen als SourceError mit einem
kurzen Code, den plugin.py in Text übersetzt.
"""

import re
import threading
import time
import xml.etree.ElementTree as ET
from datetime import datetime
from urllib.parse import urlparse

import requests
from requests.auth import HTTPDigestAuth

try:
    import urllib3
    urllib3.disable_warnings()  # Pi-hole und Unraid haben im Heimnetz oft selbst signierte Zertifikate
except Exception:  # pragma: no cover
    pass

TIMEOUT = (6, 20)
USER_AGENT = "DynaFrame-Network-Overview (+https://github.com/Archonw/Jans-DynaframePro-Store)"


class SourceError(Exception):
    def __init__(self, code, detail=""):
        super().__init__(detail or code)
        self.code = code
        self.detail = detail


def as_float(value, default=None):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return number if number == number else default  # NaN heißt: kein Wert


def as_int(value, default=0):
    number = as_float(value)
    return int(number) if number is not None else default


def base_url(address, default_scheme="http", default_port=None):
    """'pi.hole', '192.168.178.2:8080', 'https://nas/' -> 'http://pi.hole' usw."""
    text = (address or "").strip().rstrip("/")
    if not text:
        return ""
    if "://" not in text:
        text = f"{default_scheme}://{text}"
    parsed = urlparse(text)
    host = parsed.netloc
    if default_port and not parsed.port and parsed.scheme == "http":
        host = f"{host}:{default_port}"
    return f"{parsed.scheme}://{host}{parsed.path.rstrip('/')}"


def host_of(address):
    try:
        return urlparse(base_url(address)).hostname or ""
    except ValueError:
        return ""


def request_error(exc):
    if isinstance(exc, requests.exceptions.SSLError):
        return SourceError("tls", str(exc)[:200])
    if isinstance(exc, requests.exceptions.Timeout):
        return SourceError("timeout", str(exc)[:200])
    return SourceError("network", str(exc)[:200])


class Source:
    name = "source"
    every = 30          # Sekunden zwischen zwei Abfragen

    def __init__(self, log):
        self.log = log
        self.lock = threading.Lock()
        self.enabled = False
        self.data = {}
        self.status = {"state": "off", "error": "", "detail": "", "at": 0.0}
        self.next_at = 0.0
        self.session = requests.Session()
        self.session.headers["User-Agent"] = USER_AGENT

    def set_status(self, state, error="", detail=""):
        with self.lock:
            self.status.update(state=state, error=error, detail=detail)
            if state == "ok":
                self.status["at"] = time.time()

    def due(self, now):
        return self.enabled and now >= self.next_at

    def poke(self):
        self.next_at = 0.0

    def run_once(self, now):
        """Vom Sammel-Thread aufgerufen, wenn due() stimmt."""
        if self.status["state"] in ("off", "nokey"):
            self.set_status("loading")
        try:
            data = self.update()
        except SourceError as exc:
            if self.status["error"] != exc.code:
                self.log(f"{self.label}: {exc.code} {exc.detail}".strip(), "warning")
            self.set_status("error", exc.code, exc.detail)
            self.next_at = now + max(self.every, 60)
            return
        except Exception as exc:  # pragma: no cover - soll den Thread nie beenden
            self.log(f"{self.label}: {exc!r}", "warning")
            self.set_status("error", "server", repr(exc)[:200])
            self.next_at = now + max(self.every, 60)
            return
        with self.lock:
            self.data = data
        if self.status["state"] == "error":
            self.log(f"{self.label}: wieder erreichbar.")
        self.set_status("ok")
        self.next_at = now + self.every

    def snapshot(self):
        with self.lock:
            return dict(self.data)

    def close(self):
        try:
            self.session.close()
        except Exception:
            pass


# --------------------------------------------------------------------------
# Pi-hole
# --------------------------------------------------------------------------

class PiHole(Source):
    name = "pihole"
    label = "Pi-hole"
    every = 30
    DEVICE_EVERY = 300

    def __init__(self, log, index=1):
        super().__init__(log)
        self.index = index
        self.label = f"Pi-hole {index}"
        self.base = ""
        self.password = ""
        self.version = None
        self.nodename = ""      # gleicher Name = gleiche Pi-hole (z. B. einmal über die keepalived-Adresse)
        self.sid = ""
        self.devices = []
        self.devices_at = 0.0
        self.daily_cache = {}

    def configure(self, address, password):
        base = base_url(address)
        base = re.sub(r"/admin$", "", base)
        changed = (base, password) != (self.base, self.password)
        self.base, self.password = base, password or ""
        self.enabled = bool(base)
        if changed:
            self.logout()
            self.version = None
            self.nodename = ""
            self.devices, self.devices_at = [], 0.0
            self.daily_cache = {}
            self.data = {}
            self.next_at = 0.0
            self.set_status("loading" if self.enabled else "off")

    # ---- Pi-hole 6

    def _auth(self):
        try:
            response = self.session.post(self.base + "/api/auth", json={"password": self.password},
                                         timeout=TIMEOUT, verify=False)
        except requests.RequestException as exc:
            raise request_error(exc) from exc
        if response.status_code == 429:
            raise SourceError("seats", "Pi-hole: zu viele offene Sitzungen")
        try:
            session = (response.json() or {}).get("session") or {}
        except ValueError:
            session = {}
        if response.status_code == 401 or not session.get("valid"):
            raise SourceError("login" if self.password else "nopassword")
        self.sid = session.get("sid") or ""

    def _v6(self, path, params=None, retry=True):
        headers = {"X-FTL-SID": self.sid} if self.sid else {}
        try:
            response = self.session.get(self.base + path, params=params, headers=headers,
                                        timeout=TIMEOUT, verify=False)
        except requests.RequestException as exc:
            raise request_error(exc) from exc
        if response.status_code == 401 and retry:
            self._auth()
            return self._v6(path, params, retry=False)
        if response.status_code == 401:
            raise SourceError("login")
        if response.status_code == 404:
            raise SourceError("notfound", path)
        if response.status_code >= 400:
            raise SourceError("server", f"{path}: HTTP {response.status_code}")
        try:
            return response.json()
        except ValueError as exc:
            raise SourceError("server", f"{path}: keine JSON-Antwort") from exc

    def logout(self):
        if self.sid and self.base:
            try:
                self.session.delete(self.base + "/api/auth", headers={"X-FTL-SID": self.sid},
                                    timeout=(3, 5), verify=False)
            except requests.RequestException:
                pass
        self.sid = ""

    def _detect(self):
        try:
            response = self.session.get(self.base + "/api/auth", timeout=TIMEOUT, verify=False)
        except requests.RequestException as exc:
            raise request_error(exc) from exc
        if response.status_code in (200, 401) and "json" in response.headers.get("Content-Type", ""):
            return 6
        try:
            response = self.session.get(self.base + "/admin/api.php", params={"versions": ""},
                                        timeout=TIMEOUT, verify=False)
        except requests.RequestException as exc:
            raise request_error(exc) from exc
        if response.status_code == 200 and response.text.strip().startswith(("{", "[")):
            return 5
        raise SourceError("nopihole", f"HTTP {response.status_code}")

    def update(self):
        if self.version is None:
            self.version = self._detect()
            self.log(f"Pi-hole {self.version} gefunden unter {self.base}.")
        if self.version == 6 and not self.nodename:
            try:
                host = self._v6("/api/info/host").get("host") or {}
                self.nodename = ((host.get("uname") or {}).get("nodename") or "").strip()
            except SourceError as exc:
                if exc.code in ("login", "nopassword", "network", "timeout"):
                    raise
                self.nodename = "-"
        return self._update6() if self.version == 6 else self._update5()

    def _update6(self):
        summary = self._v6("/api/stats/summary")
        history = self._v6("/api/history").get("history") or []
        clients = self._v6("/api/stats/top_clients", {"count": 60}).get("clients") or []
        blocked_domains = self._v6("/api/stats/top_domains", {"blocked": "true", "count": 5}).get("domains") or []
        try:
            blocking = self._v6("/api/dns/blocking").get("blocking")
        except SourceError:
            blocking = "enabled"
        now = time.time()
        if now - self.devices_at > self.DEVICE_EVERY:
            try:
                rows = self._v6("/api/network/devices", {"max_devices": 300, "max_addresses": 4}).get("devices") or []
                self.devices = [self._device6(row) for row in rows]
            except SourceError as exc:
                self.log(f"Pi-hole Geräteliste: {exc.code}", "warning")
            self.devices_at = now
        queries = summary.get("queries") or {}
        series = [[as_int(row.get("timestamp")), as_int(row.get("total")), as_int(row.get("blocked"))]
                  for row in history if isinstance(row, dict)]
        return self._result(
            blocking=str(blocking).lower() in ("enabled", "true"),
            total=as_int(queries.get("total")), blocked=as_int(queries.get("blocked")),
            series=series,
            clients=[{"ip": c.get("ip") or "", "name": c.get("name") or "", "count": as_int(c.get("count"))}
                     for c in clients if isinstance(c, dict)],
            top_blocked=[{"domain": d.get("domain") or "", "count": as_int(d.get("count"))}
                         for d in blocked_domains if isinstance(d, dict)],
            domains=as_int((summary.get("gravity") or {}).get("domains_being_blocked")),
            active_clients=as_int((summary.get("clients") or {}).get("active")),
        )

    @staticmethod
    def _device6(row):
        ips = [a for a in (row.get("ips") or []) if isinstance(a, dict)]
        name = next((a.get("name") for a in ips if a.get("name")), "")
        return {"mac": (row.get("hwaddr") or "").lower(), "ips": [a.get("ip") for a in ips if a.get("ip")],
                "name": name, "vendor": row.get("macVendor") or "", "lastQuery": as_int(row.get("lastQuery")),
                "firstSeen": as_int(row.get("firstSeen")), "queries": as_int(row.get("numQueries"))}

    def daily6(self, day_start, day_end):
        """Summen eines vergangenen Tages aus Pi-holes Langzeit-Datenbank."""
        key = int(day_start)
        if key in self.daily_cache:
            return self.daily_cache[key]
        if self.version != 6:
            return None
        try:
            row = self._v6("/api/stats/database/summary", {"from": int(day_start), "until": int(day_end)})
        except SourceError:
            return None
        result = {"total": as_int(row.get("sum_queries")), "blocked": as_int(row.get("sum_blocked"))}
        self.daily_cache[key] = result
        return result

    # ---- Pi-hole 5

    def _v5(self, params, path="/admin/api.php"):
        params = dict(params)
        if self.password:
            params["auth"] = self.password
        try:
            response = self.session.get(self.base + path, params=params, timeout=TIMEOUT, verify=False)
        except requests.RequestException as exc:
            raise request_error(exc) from exc
        if response.status_code >= 400:
            raise SourceError("server", f"HTTP {response.status_code}")
        try:
            payload = response.json()
        except ValueError as exc:
            raise SourceError("server", "keine JSON-Antwort") from exc
        # Ohne gültigen Token liefert Pi-hole 5 [] statt der Daten.
        if isinstance(payload, list):
            raise SourceError("login" if self.password else "nopassword")
        return payload

    def _update5(self):
        summary = self._v5({"summaryRaw": ""})
        over = self._v5({"overTimeData10mins": ""})
        top = self._v5({"topClients": 60})
        items = self._v5({"topItems": 5})
        now = time.time()
        if now - self.devices_at > self.DEVICE_EVERY:
            try:
                rows = self._v5({"network": ""}, "/admin/api_db.php").get("network") or []
                self.devices = []
                for row in rows:
                    names = [n for n in (row.get("name") or []) if n]
                    self.devices.append({"mac": (row.get("hwaddr") or "").lower(), "ips": row.get("ip") or [],
                                         "name": names[0] if names else "", "vendor": row.get("macVendor") or "",
                                         "lastQuery": as_int(row.get("lastQuery")),
                                         "firstSeen": as_int(row.get("firstSeen")),
                                         "queries": as_int(row.get("numQueries"))})
            except SourceError as exc:
                self.log(f"Pi-hole Geräteliste: {exc.code}", "warning")
            self.devices_at = now
        totals = over.get("domains_over_time") or {}
        ads = over.get("ads_over_time") or {}
        series = sorted([[as_int(ts), as_int(n), as_int(ads.get(ts))] for ts, n in totals.items()])
        clients = []
        for key, count in (top.get("top_sources") or {}).items():
            name, _, ip = key.partition("|")
            clients.append({"ip": ip or name, "name": name if ip else "", "count": as_int(count)})
        return self._result(
            blocking=str(summary.get("status", "enabled")) == "enabled",
            total=as_int(summary.get("dns_queries_today")), blocked=as_int(summary.get("ads_blocked_today")),
            series=series, clients=clients,
            top_blocked=[{"domain": d, "count": as_int(n)} for d, n in (items.get("top_ads") or {}).items()][:5],
            domains=as_int(summary.get("domains_being_blocked")),
            active_clients=as_int(summary.get("unique_clients")),
        )

    def _result(self, blocking, total, blocked, series, clients, top_blocked, domains, active_clients):
        midnight = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
        today = [row for row in series if row[0] >= midnight]
        # Anfragen pro Minute aus den letzten 30 Minuten, für die Funken in der Szene.
        recent = [row for row in series if row[0] >= time.time() - 40 * 60][-3:]
        minutes = max(1, 10 * len(recent))
        return {
            "version": self.version, "blocking": blocking, "nodename": self.nodename.strip("-"),
            "address": self.base, "index": self.index,
            "total24": total, "blocked24": blocked,
            "todayTotal": sum(r[1] for r in today), "todayBlocked": sum(r[2] for r in today),
            "series": series[-150:], "clients": clients, "topBlocked": top_blocked,
            "domains": domains, "activeClients": active_clients,
            "perMinute": round(sum(r[1] for r in recent) / minutes, 1),
            "blockedPerMinute": round(sum(r[2] for r in recent) / minutes, 2),
            "devices": list(self.devices),
        }

    def close(self):
        self.logout()
        super().close()


# --------------------------------------------------------------------------
# Fritzbox (TR-064)
# --------------------------------------------------------------------------

SOAP_ENVELOPE = ('<?xml version="1.0" encoding="utf-8"?>'
                 '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
                 's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'
                 '<s:Body><u:{action} xmlns:u="{service}">{args}</u:{action}></s:Body></s:Envelope>')

DSL = "urn:dslforum-org:service:"


class Fritzbox(Source):
    name = "fritz"
    label = "Fritzbox"
    every = 10           # Zähler fürs Datenvolumen; Geräte und Status seltener
    HOSTS_EVERY = 30
    INFO_EVERY = 300

    def __init__(self, log):
        super().__init__(log)
        self.base = ""
        self.user = ""
        self.password = ""
        self.hosts = []
        self.hosts_at = 0.0
        self.info = {}
        self.info_at = 0.0
        self.counters = None      # (zeit, gesendet, empfangen) der letzten Abfrage
        self.rates = (0.0, 0.0)   # Bytes pro Sekunde runter, hoch
        self.on_volume = None     # plugin.py zählt damit das Tagesvolumen

    def configure(self, address, user, password):
        base = base_url(address or "fritz.box", default_port=49000)
        changed = (base, user, password) != (self.base, self.user, self.password)
        self.base, self.user, self.password = base, (user or "").strip(), password or ""
        self.enabled = bool(self.password)
        if changed:
            self.hosts, self.hosts_at, self.info, self.info_at = [], 0.0, {}, 0.0
            self.counters = None
            self.data = {}
            self.next_at = 0.0
            self.set_status("loading" if self.enabled else "nokey")

    def soap(self, control, service, action, args=None):
        body = "".join(f"<{k}>{v}</{k}>" for k, v in (args or {}).items())
        payload = SOAP_ENVELOPE.format(action=action, service=service, args=body)
        headers = {"Content-Type": 'text/xml; charset="utf-8"', "SoapAction": f"{service}#{action}"}
        try:
            response = self.session.post(self.base + control, data=payload.encode("utf-8"), headers=headers,
                                         auth=HTTPDigestAuth(self.user, self.password), timeout=TIMEOUT,
                                         verify=False)
        except requests.RequestException as exc:
            raise request_error(exc) from exc
        if response.status_code == 401:
            raise SourceError("login")
        if response.status_code == 500 and b"606" in response.content:
            raise SourceError("rights", action)       # Benutzer ohne die nötige Berechtigung
        if response.status_code == 500 and b"401" in response.content and b"UPnPError" in response.content:
            raise SourceError("unknownaction", action)
        if response.status_code == 404:
            raise SourceError("notr064", control)
        if response.status_code >= 400:
            raise SourceError("server", f"{action}: HTTP {response.status_code}")
        try:
            root = ET.fromstring(response.content)
        except ET.ParseError as exc:
            raise SourceError("server", f"{action}: kein XML") from exc
        result = {}
        for node in root.iter():
            tag = node.tag.split("}")[-1]
            if tag.startswith("New"):
                result[tag[3:]] = (node.text or "").strip()
        return result

    def _host_list(self):
        try:
            path = self.soap("/upnp/control/hosts", DSL + "Hosts:1", "X_AVM-DE_GetHostListPath")["X_AVM-DE_HostListPath"]
        except (SourceError, KeyError) as exc:
            if isinstance(exc, SourceError) and exc.code in ("login", "network", "timeout"):
                raise
            return self._host_entries()
        url = path if path.startswith("http") else self.base + path
        try:
            response = self.session.get(url, timeout=TIMEOUT, verify=False)
            root = ET.fromstring(response.content)
        except (requests.RequestException, ET.ParseError) as exc:
            raise SourceError("server", f"Hostliste: {exc}") from exc
        hosts = []
        for item in root.iter("Item"):
            row = {child.tag: (child.text or "").strip() for child in item}
            hosts.append(self._host(row))
        return hosts

    def _host_entries(self):
        """Ältere FRITZ!OS ohne Hostlisten-Datei: Eintrag für Eintrag."""
        count = as_int(self.soap("/upnp/control/hosts", DSL + "Hosts:1", "GetHostNumberOfEntries").get("HostNumberOfEntries"))
        hosts = []
        for index in range(min(count, 250)):
            row = self.soap("/upnp/control/hosts", DSL + "Hosts:1", "GetGenericHostEntry", {"NewIndex": index})
            hosts.append(self._host({"IPAddress": row.get("IPAddress"), "MACAddress": row.get("MACAddress"),
                                     "HostName": row.get("HostName"), "Active": row.get("Active"),
                                     "InterfaceType": row.get("InterfaceType")}))
        return hosts

    @staticmethod
    def _host(row):
        iface = (row.get("InterfaceType") or "").lower()
        guest = row.get("X_AVM-DE_Guest") == "1"
        conn = "guest" if guest else ("wlan" if "802.11" in iface else ("lan" if "ethernet" in iface else "other"))
        return {"mac": (row.get("MACAddress") or "").lower(), "ip": row.get("IPAddress") or "",
                "name": row.get("HostName") or "", "active": row.get("Active") == "1", "conn": conn,
                "speed": as_int(row.get("X_AVM-DE_Speed")), "model": row.get("X_AVM-DE_Model") or ""}

    def _info(self):
        info = {}
        try:
            row = self.soap("/upnp/control/deviceinfo", DSL + "DeviceInfo:1", "GetInfo")
            info.update(model=row.get("ModelName", ""), firmware=row.get("SoftwareVersion", ""),
                        boxUptime=as_int(row.get("UpTime")))
        except SourceError as exc:
            if exc.code in ("login", "network", "timeout"):
                raise
        try:
            row = self.soap("/upnp/control/wancommonifconfig1", DSL + "WANCommonInterfaceConfig:1",
                            "GetCommonLinkProperties")
            info.update(maxDown=as_int(row.get("Layer1DownstreamMaxBitRate")),
                        maxUp=as_int(row.get("Layer1UpstreamMaxBitRate")),
                        access=row.get("WANAccessType", ""), link=row.get("PhysicalLinkStatus", ""))
        except SourceError:
            pass
        for control, service, action in (("/upnp/control/wanpppconn1", "WANPPPConnection:1", "GetInfo"),
                                         ("/upnp/control/wanipconnection1", "WANIPConnection:1", "GetStatusInfo")):
            try:
                row = self.soap(control, DSL + service, action)
            except SourceError:
                continue
            if row.get("ConnectionStatus"):
                info.update(connection=row.get("ConnectionStatus"), uptime=as_int(row.get("Uptime")))
                break
        return info

    def _counters(self, now):
        service = DSL + "WANCommonInterfaceConfig:1"
        try:
            sent = as_int(self.soap("/upnp/control/wancommonifconfig1", service, "GetTotalBytesSent").get("TotalBytesSent"))
            received = as_int(self.soap("/upnp/control/wancommonifconfig1", service,
                                        "GetTotalBytesReceived").get("TotalBytesReceived"))
        except SourceError as exc:
            if exc.code in ("login", "network", "timeout"):
                raise
            return
        if self.counters:
            then, old_sent, old_received = self.counters
            seconds = max(1.0, now - then)
            # 32-Bit-Zähler: laufen nach 4 GiB über.
            up = (sent - old_sent) % 2 ** 32
            down = (received - old_received) % 2 ** 32
            if seconds < 600:
                self.rates = (down / seconds, up / seconds)
                if self.on_volume:
                    self.on_volume(down, up)
        self.counters = (now, sent, received)

    def update(self):
        now = time.time()
        if now - self.info_at > self.INFO_EVERY or not self.info:
            self.info = self._info()
            self.info_at = now
        if now - self.hosts_at > self.HOSTS_EVERY or not self.hosts_at:
            self.hosts = self._host_list()
            self.hosts_at = now
        self._counters(now)
        down, up = self.rates
        return dict(self.info, hosts=list(self.hosts), downBps=round(down * 8), upBps=round(up * 8))


# --------------------------------------------------------------------------
# Server: Unraid-API und Glances
# --------------------------------------------------------------------------

Q_ARRAY = [
    "{ array { state capacity { kilobytes { free used total } } "
    "parities { name size status temp isSpinning } "
    "disks { name size status temp isSpinning fsSize fsFree fsUsed } "
    "caches { name size status temp isSpinning fsSize fsFree fsUsed } } }",
    "{ array { state capacity { kilobytes { free used total } } "
    "parities { name size status temp } disks { name size status temp } caches { name size status temp } } }",
]
Q_INFO = ["{ info { os { hostname uptime } } }"]
Q_METRICS = ["{ metrics { cpu { percentTotal } memory { total used percentTotal } } }"]
Q_DOCKER = ["{ docker { containers { names state } } }"]


class Unraid(Source):
    name = "server"
    label = "Unraid"
    every = 60

    def __init__(self, log):
        super().__init__(log)
        self.base = ""
        self.key = ""
        self.working = {}       # welche Abfrage-Variante der Server versteht

    def configure(self, address, key):
        base = base_url(address)
        changed = (base, key) != (self.base, self.key)
        self.base, self.key = base, key or ""
        self.enabled = bool(base)
        if changed:
            self.working = {}
            self.data = {}
            self.next_at = 0.0
            self.set_status(("loading" if self.key else "nokey") if self.enabled else "off")
        if self.enabled and not self.key:
            self.enabled = False

    def _post(self, query):
        headers = {"x-api-key": self.key, "Content-Type": "application/json", "Accept": "application/json"}
        try:
            response = self.session.post(self.base + "/graphql", json={"query": query}, headers=headers,
                                         timeout=TIMEOUT, verify=False, allow_redirects=False)
            if response.status_code in (301, 302, 307, 308) and response.headers.get("Location"):
                # http -> https (oder myunraid.net): der Adresse folgen und merken.
                target = urlparse(response.headers["Location"])
                self.base = f"{target.scheme}://{target.netloc}"
                self.log(f"Unraid leitet weiter auf {self.base}.")
                response = self.session.post(self.base + "/graphql", json={"query": query}, headers=headers,
                                             timeout=TIMEOUT, verify=False)
        except requests.RequestException as exc:
            raise request_error(exc) from exc
        if response.status_code in (401, 403):
            raise SourceError("key")
        if response.status_code == 404:
            raise SourceError("noapi")
        try:
            payload = response.json()
        except ValueError as exc:
            raise SourceError("noapi", f"HTTP {response.status_code}") from exc
        errors = payload.get("errors") or []
        if errors and not payload.get("data"):
            text = "; ".join(str(e.get("message", "")) for e in errors if isinstance(e, dict))[:300]
            if re.search(r"unauthori[sz]ed|forbidden|api key", text, re.I):
                raise SourceError("key", text)
            raise SourceError("query", text)
        return payload.get("data") or {}

    def _ask(self, name, variants, required=False):
        order = [self.working[name]] if name in self.working else range(len(variants))
        last = None
        for index in order:
            try:
                data = self._post(variants[index])
            except SourceError as exc:
                if exc.code != "query":
                    raise
                last = exc
                continue
            self.working[name] = index
            return data
        if required and last:
            raise last
        return {}

    def update(self):
        array = (self._ask("array", Q_ARRAY, required=True).get("array")) or {}
        info = ((self._ask("info", Q_INFO).get("info")) or {}).get("os") or {}
        metrics = self._ask("metrics", Q_METRICS).get("metrics") or {}
        docker = ((self._ask("docker", Q_DOCKER).get("docker")) or {}).get("containers") or []
        kb = ((array.get("capacity") or {}).get("kilobytes")) or {}

        def disk(row, role):
            temp = as_float(row.get("temp"))
            size = as_float(row.get("fsSize")) or 0
            used = as_float(row.get("fsUsed"))
            if used is None and size:
                used = size - (as_float(row.get("fsFree")) or 0)
            spinning = row.get("isSpinning")
            if spinning is None:
                spinning = temp is not None
            return {"name": row.get("name") or "", "role": role, "temp": temp, "spinning": bool(spinning),
                    "status": row.get("status") or "", "size": (as_float(row.get("size")) or 0) * 1024,
                    "fsSize": size * 1024, "fsUsed": (used or 0) * 1024}

        disks = ([disk(r, "parity") for r in array.get("parities") or []] +
                 [disk(r, "data") for r in array.get("disks") or []] +
                 [disk(r, "cache") for r in array.get("caches") or []])
        uptime = info.get("uptime")
        boot = None
        if isinstance(uptime, (int, float)):
            boot = time.time() - uptime
        elif isinstance(uptime, str) and uptime:
            try:
                boot = datetime.fromisoformat(uptime.replace("Z", "+00:00")).timestamp()
            except ValueError:
                boot = None
        cpu = (metrics.get("cpu") or {}).get("percentTotal")
        memory = metrics.get("memory") or {}
        return {
            "kind": "unraid", "name": info.get("hostname") or "Unraid", "state": array.get("state") or "",
            "total": (as_float(kb.get("total")) or 0) * 1024, "used": (as_float(kb.get("used")) or 0) * 1024,
            "disks": disks, "cpu": as_float(cpu), "mem": as_float(memory.get("percentTotal")),
            "boot": boot,
            "containers": {"total": len(docker),
                           "running": sum(1 for c in docker if str(c.get("state", "")).upper() == "RUNNING")},
        }


class Glances(Source):
    name = "server"
    label = "Glances"
    every = 60

    def __init__(self, log):
        super().__init__(log)
        self.base = ""
        self.api = ""

    def configure(self, address, _key=""):
        base = base_url(address, default_port=61208)
        changed = base != self.base
        self.base = base
        self.enabled = bool(base)
        if changed:
            self.api = ""
            self.data = {}
            self.next_at = 0.0
            self.set_status("loading" if self.enabled else "off")

    def _get(self, path):
        try:
            response = self.session.get(f"{self.base}/api/{self.api}/{path}", timeout=TIMEOUT, verify=False)
        except requests.RequestException as exc:
            raise request_error(exc) from exc
        if response.status_code == 404:
            raise SourceError("notfound", path)
        if response.status_code >= 400:
            raise SourceError("server", f"{path}: HTTP {response.status_code}")
        try:
            return response.json()
        except ValueError as exc:
            raise SourceError("server", path) from exc

    def update(self):
        if not self.api:
            for api in ("4", "3"):
                self.api = api
                try:
                    self._get("uptime")
                    break
                except SourceError as exc:
                    if exc.code != "notfound":
                        self.api = ""
                        raise
            else:
                self.api = ""
                raise SourceError("noglances")
        fs = self._get("fs")
        try:
            sensors = self._get("sensors")
        except SourceError:
            sensors = []
        cpu = self._get("cpu")
        mem = self._get("mem")
        try:
            containers = self._get("containers")
        except SourceError:
            containers = []
        if isinstance(containers, dict):     # API 3
            containers = containers.get("containers") or []
        try:
            system = self._get("system")
        except SourceError:
            system = {}
        disks, total, used = [], 0.0, 0.0
        for row in fs if isinstance(fs, list) else []:
            mount = row.get("mnt_point") or ""
            match = re.match(r"^/mnt/(disk\d+|cache\w*|pool\w*)$", mount)
            if not match:
                continue
            name = match.group(1)
            size, use = as_float(row.get("size")) or 0, as_float(row.get("used")) or 0
            disks.append({"name": name, "role": "data" if name.startswith("disk") else "cache", "temp": None,
                          "spinning": True, "status": "", "size": size, "fsSize": size, "fsUsed": use})
            if name.startswith("disk"):
                total, used = total + size, used + use
        cpu_temp = None
        hdd = [s for s in sensors if isinstance(s, dict) and s.get("type") == "temperature_hdd"]
        for sensor in sensors if isinstance(sensors, list) else []:
            if sensor.get("type") == "temperature_core":
                value = as_float(sensor.get("value"))
                if value is not None:
                    cpu_temp = max(cpu_temp or 0, value)
        for sensor in hdd:
            label = str(sensor.get("label") or "")
            target = next((d for d in disks if d["name"] == label), None)
            if target is None:
                disks.append({"name": label, "role": "data", "temp": as_float(sensor.get("value")), "spinning": True,
                              "status": "", "size": 0, "fsSize": 0, "fsUsed": 0})
            else:
                target["temp"] = as_float(sensor.get("value"))
        if not disks and isinstance(fs, list):
            for row in fs:
                if row.get("mnt_point") in ("/", "/mnt/user"):
                    total, used = as_float(row.get("size")) or 0, as_float(row.get("used")) or 0
        return {
            "kind": "glances", "name": system.get("hostname") or "Server", "state": "STARTED",
            "total": total, "used": used, "disks": disks,
            "cpu": as_float(cpu.get("total")), "mem": as_float(mem.get("percent")), "cpuTemp": cpu_temp,
            "boot": None,
            "containers": {"total": len(containers),
                           "running": sum(1 for c in containers
                                          if str(c.get("status") or c.get("Status") or "").lower().startswith(("running", "up")))},
        }
