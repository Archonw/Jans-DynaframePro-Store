/* Party Wall: die Seite für die Gäste.
 * Beitreten mit dem Code vom Fernseher (steht schon im QR-Code), Fotos
 * hochladen (vorher im Handy verkleinert), mit Emojis reagieren, alle Fotos
 * ansehen. Fragt alle paar Sekunden ./api/state?id=<Gast>. */
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const EMOJIS = [["heart", "2764"], ["laugh", "1f602"], ["love", "1f60d"], ["fire", "1f525"],
    ["clap", "1f44f"], ["party", "1f389"], ["wow", "1f62e"]];
  const FILE = Object.fromEntries(EMOJIS);
  const T = {
    joinTitle: ["Mach mit bei der Fotowand", "Join the party wall", "Únete al muro de fotos"],
    joinLead: ["Teile deine Fotos vom Abend auf dem Fernseher und reagiere auf die Fotos der anderen.",
      "Share your photos of the evening on the TV and react to the others' photos.",
      "Comparte tus fotos de la noche en la tele y reacciona a las fotos de los demás."],
    code: ["Code vom Fernseher", "Code from the TV", "Código de la tele"],
    name: ["Dein Name (steht bei deinen Fotos)", "Your name (shown with your photos)", "Tu nombre (aparece con tus fotos)"],
    join: ["Los geht's", "Let's go", "Vamos"],
    rename: ["Speichern", "Save", "Guardar"],
    badCode: ["Der Code stimmt nicht. Er steht auf dem Fernseher neben dem QR-Code.", "That code is wrong. It is on the TV next to the QR code.", "El código no es correcto. Está en la tele junto al código QR."],
    full: ["Die Party ist voll.", "The party is full.", "La fiesta está llena."],
    noAnswer: ["Der Rahmen antwortet nicht. Bist du im selben WLAN?", "The frame does not answer. Are you on the same Wi-Fi?", "El marco no responde. ¿Estás en la misma wifi?"],
    upload: ["Fotos hochladen", "Upload photos", "Subir fotos"],
    camera: ["Foto machen", "Take a photo", "Hacer una foto"],
    captionPh: ["Ein Satz zum Foto (freiwillig)", "Add a line to your photo (optional)", "Una frase para la foto (opcional)"],
    uploadsOff: ["Hochladen ist gerade ausgeschaltet.", "Uploading is switched off right now.", "La subida de fotos está desactivada ahora."],
    preparing: ["wird vorbereitet …", "preparing …", "preparando …"],
    sending: ["wird gesendet … {p} %", "sending … {p} %", "enviando … {p} %"],
    done: ["ist auf der Wand", "is on the wall", "está en el muro"],
    waiting: ["wartet auf Freigabe", "waiting for approval", "pendiente de aprobación"],
    failed: ["ging nicht: {e}", "failed: {e}", "no ha funcionado: {e}"],
    tooBig: ["zu groß", "too large", "demasiado grande"],
    photo: ["Foto {n}", "Photo {n}", "Foto {n}"],
    nowTitle: ["Gerade auf dem Fernseher", "On the TV now", "Ahora en la tele"],
    notVisible: ["Die Fotowand ist gerade nicht auf dem Fernseher. Deine Fotos kommen, sobald sie wieder läuft.", "The photo wall is not on the TV right now. Your photos appear as soon as it is back.", "El muro no está ahora en la tele. Tus fotos aparecerán en cuanto vuelva."],
    welcome: ["Noch keine Fotos. Mach den Anfang!", "No photos yet. Be the first!", "Aún no hay fotos. ¡Empieza tú!"],
    recapNow: ["Auf dem Fernseher läuft die Rückschau mit den beliebtesten Fotos.", "The TV is showing the recap with the most popular photos.", "La tele muestra el resumen con las fotos más populares."],
    topNow: ["Auf dem Fernseher: die beliebtesten Fotos bis jetzt.", "On the TV: the most popular photos so far.", "En la tele: las fotos más populares hasta ahora."],
    topTitle: ["Die beliebtesten Fotos", "Most popular photos", "Las fotos más populares"],
    allTitle: ["Alle Fotos", "All photos", "Todas las fotos"],
    myTitle: ["Deine Fotos", "Your photos", "Tus fotos"],
    galleryOff: ["Hier stehen nur deine eigenen Fotos.", "Only your own photos are listed here.", "Aquí solo aparecen tus propias fotos."],
    none: ["Noch keine Fotos.", "No photos yet.", "Aún no hay fotos."],
    showOnTv: ["Auf den Fernseher", "Show on the TV", "Mostrar en la tele"],
    shown: ["Kommt gleich auf den Fernseher.", "Coming to the TV in a moment.", "Sale en la tele enseguida."],
    save: ["Speichern", "Save", "Guardar"],
    delete: ["Löschen", "Delete", "Borrar"],
    deleted: ["Gelöscht.", "Deleted.", "Borrada."],
    by: ["von {n}", "by {n}", "de {n}"],
    you: ["dir", "you", "ti"],
    reactions: ["{n} Reaktionen", "{n} reactions", "{n} reacciones"],
    slow: ["Nicht so schnell, die Emojis fliegen noch.", "Not so fast, the emojis are still flying.", "No tan rápido, los emojis aún vuelan."]
  };
  const langs = ["de", "en", "es"];
  const browser = (navigator.languages || [navigator.language || ""]).map((l) => String(l).slice(0, 2).toLowerCase());
  let lang = browser.find((l) => langs.includes(l)) || (document.documentElement.lang || "en").slice(0, 2);
  if (!langs.includes(lang)) lang = "en";
  const tx = (key, values) => {
    const row = T[key] || [key, key, key];
    let text = row[langs.indexOf(lang)] ?? row[1];
    for (const [k, v] of Object.entries(values || {})) text = text.replace(`{${k}}`, v);
    return text;
  };
  const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  function applyLanguage() {
    document.documentElement.lang = lang;
    document.querySelectorAll("[data-t]").forEach((node) => { node.textContent = tx(node.dataset.t); });
    document.querySelectorAll("[data-tp]").forEach((node) => { node.placeholder = tx(node.dataset.tp); });
  }

  // ------------------------------------------------------------ Speicher

  const store = {
    get(key) { try { return localStorage.getItem("partywall." + key) || ""; } catch (_) { return ""; } },
    set(key, value) { try { localStorage.setItem("partywall." + key, value); } catch (_) { /* privat */ } }
  };
  const params = new URLSearchParams(location.search);
  let partyId = "";
  let me = "";
  let state = null;
  let renaming = false;
  if (params.get("c")) $("code").value = params.get("c").replace(/\D/g, "").slice(0, 4);
  $("name").value = store.get("name");

  async function api(path, body) {
    const response = await fetch(path, body === undefined ? { cache: "no-store" } : {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
    });
    return response.json();
  }

  // ------------------------------------------------------------ Beitreten

  async function join() {
    $("joinNote").textContent = "";
    const name = $("name").value.trim();
    store.set("name", name);
    try {
      const result = await api("api/join", { id: me, code: $("code").value.trim(), name });
      if (!result.success) {
        $("joinNote").textContent = tx(result.error === "code" ? "badCode" : result.error === "full" ? "full" : "noAnswer");
        return;
      }
      me = result.id;
      partyId = result.party;
      store.set(`${partyId}.id`, me);
      renaming = false;
      await poll();
    } catch (_) {
      $("joinNote").textContent = tx("noAnswer");
    }
  }
  $("joinButton").addEventListener("click", join);
  $("name").addEventListener("keydown", (e) => { if (e.key === "Enter") join(); });
  $("me").addEventListener("click", () => {
    renaming = true;
    show();
    $("name").focus();
  });

  // ------------------------------------------------------------ Hochladen

  const queue = [];
  let uploading = false;
  let counter = 0;

  async function shrink(file) {
    // Große Fotos schon im Handy verkleinern: geht im WLAN der Party viel schneller.
    if (file.size < 1.2 * 1024 * 1024 && /jpe?g/i.test(file.type)) return file;
    try {
      let source;
      try {
        source = await createImageBitmap(file, { imageOrientation: "from-image" });
      } catch (_) {
        source = await new Promise((resolve, reject) => {
          const img = new Image();
          img.onload = () => resolve(img);
          img.onerror = reject;
          img.src = URL.createObjectURL(file);
        });
      }
      const w = source.width || source.naturalWidth, h = source.height || source.naturalHeight;
      const scale = Math.min(1, 2048 / Math.max(w, h));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(w * scale);
      canvas.height = Math.round(h * scale);
      canvas.getContext("2d").drawImage(source, 0, 0, canvas.width, canvas.height);
      const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.88));
      return blob && blob.size > 1000 ? blob : file;
    } catch (_) {
      return file;   // das Plugin kann es selbst (auch HEIC)
    }
  }

  function renderQueue() {
    $("queue").innerHTML = queue.slice(-6).map((job) => `<li class="${job.state}">
      ${job.preview ? `<img src="${job.preview}" alt="">` : "<i></i>"}
      <span><b>${esc(tx("photo", { n: job.n }))}</b> ${esc(job.text)}</span>
      <em style="width:${job.progress}%"></em></li>`).join("");
  }

  function send(job, blob) {
    return new Promise((resolve) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", `api/upload?id=${encodeURIComponent(me)}&cap=${encodeURIComponent(job.caption)}`);
      xhr.setRequestHeader("Content-Type", blob.type || "application/octet-stream");
      xhr.upload.onprogress = (e) => {
        if (!e.lengthComputable) return;
        job.progress = Math.round((e.loaded / e.total) * 100);
        job.text = tx("sending", { p: job.progress });
        renderQueue();
      };
      xhr.onload = () => {
        let body = {};
        try { body = JSON.parse(xhr.responseText); } catch (_) { /* leer */ }
        if (xhr.status === 403 && body.error === "unknown") {
          me = "";
          store.set(`${partyId}.id`, "");
        }
        resolve(body.success ? body : { success: false, error: body.error || `HTTP ${xhr.status}` });
      };
      xhr.onerror = () => resolve({ success: false, error: tx("noAnswer") });
      xhr.send(blob);
    });
  }

  async function work() {
    if (uploading) return;
    uploading = true;
    for (let job = queue.find((j) => j.state === "wait"); job; job = queue.find((j) => j.state === "wait")) {
      job.state = "busy";
      job.text = tx("preparing");
      renderQueue();
      const blob = await shrink(job.file);
      if (blob.size > 40 * 1024 * 1024) {
        job.state = "bad";
        job.text = tx("failed", { e: tx("tooBig") });
        continue;
      }
      if (!job.preview) {
        try { job.preview = URL.createObjectURL(blob); } catch (_) { /* ohne Vorschau */ }
      }
      const result = await send(job, blob);
      job.progress = 100;
      job.state = result.success ? "ok" : "bad";
      job.text = result.success ? tx(result.waiting ? "waiting" : "done") : tx("failed", { e: result.error });
      renderQueue();
      if (result.success) poll();
    }
    uploading = false;
  }

  function pick(event) {
    const files = [...(event.target.files || [])];
    const caption = $("caption").value.trim();
    for (const file of files) {
      queue.push({ file, caption, n: ++counter, state: "wait", text: "", progress: 0, preview: "" });
    }
    event.target.value = "";
    $("caption").value = "";
    renderQueue();
    work();
  }
  $("files").addEventListener("change", pick);
  $("camera").addEventListener("change", pick);

  // ------------------------------------------------------------ Reagieren

  function emojiBar(photo) {
    const counts = photo.r || {};
    return EMOJIS.map(([key, file]) => `<button type="button" data-emoji="${key}" data-photo="${esc(photo.id)}">
      <img src="emoji/${file}.svg" alt="${key}"><small>${counts[key] || ""}</small></button>`).join("");
  }

  function flyLocal(key, x, y) {
    const node = document.createElement("img");
    node.src = `emoji/${FILE[key]}.svg`;
    node.className = "flying";
    node.style.left = `${x - 20}px`;
    node.style.top = `${y - 20}px`;
    node.style.setProperty("--dx", `${(Math.random() - 0.5) * 80}px`);
    $("fly").appendChild(node);
    setTimeout(() => node.remove(), 1300);
  }

  let slowShown = 0;
  async function react(event) {
    const button = event.target.closest("button[data-emoji]");
    if (!button) return;
    const key = button.dataset.emoji;
    const box = button.getBoundingClientRect();
    flyLocal(key, box.left + box.width / 2, box.top);
    const small = button.querySelector("small");
    small.textContent = String((Number(small.textContent) || 0) + 1);
    if (navigator.vibrate) navigator.vibrate(12);
    try {
      const result = await api("api/react", { id: me, photo: button.dataset.photo, emoji: key });
      if (result.success && !result.flies && Date.now() - slowShown > 4000) {
        slowShown = Date.now();
        const note = button.closest(".viewer") ? $("viewerNote") : $("uploadNote");
        note.textContent = tx("slow");
        setTimeout(() => { note.textContent = ""; }, 3000);
      }
    } catch (_) { /* nächstes Mal */ }
  }
  $("nowEmojis").addEventListener("click", react);
  $("viewerEmojis").addEventListener("click", react);

  // ------------------------------------------------------------ Anzeigen

  const photoUrl = (photo, size) => `api/photo?id=${encodeURIComponent(photo.id)}&s=${size}&me=${encodeURIComponent(me)}`;
  const total = (photo) => Object.values(photo.r || {}).reduce((a, b) => a + b, 0);

  function show() {
    const joined = Boolean(me && state && state.known) && !renaming;
    $("joinScreen").hidden = joined;
    $("mainScreen").hidden = !joined;
    $("codeField").hidden = Boolean(me && state && state.known);
    $("joinButton").textContent = tx(renaming ? "rename" : "join");
  }

  let nowKey = "";
  function render() {
    show();
    $("partyTitle").textContent = state.title || "";
    if (!state.known) { $("me").hidden = true; return; }
    $("me").hidden = false;
    $("meDot").style.background = state.me.color;
    $("meName").textContent = state.me.label;
    if (!$("name").value && state.me.name) $("name").value = state.me.name;
    const off = !state.uploads;
    document.querySelectorAll(".pick input").forEach((input) => { input.disabled = off; });
    document.querySelector(".pick").classList.toggle("off", off);
    if (off) $("uploadNote").textContent = tx("uploadsOff");
    else if ($("uploadNote").textContent === tx("uploadsOff")) $("uploadNote").textContent = "";

    // Jetzt auf dem Fernseher
    const current = state.current;
    let html = "";
    if (state.phase === "recap") html = `<p class="note">${esc(tx("recapNow"))}</p>`;
    else if (state.phase === "top") html = `<p class="note">${esc(tx("topNow"))}</p>`;
    else if (!state.visible) html = `<p class="note">${esc(tx("notVisible"))}</p>`;
    else if (!current) html = `<p class="note">${esc(tx("welcome"))}</p>`;
    const key = current ? `${current.id}|${JSON.stringify(current.r)}` : html;
    if (key !== nowKey) {
      nowKey = key;
      if (current && state.visible && !["recap", "top"].includes(state.phase)) {
        $("nowBox").innerHTML = `<img class="now-img" src="${photoUrl(current, "t")}" alt="" data-open="${esc(current.id)}">
          <p><b>${esc(current.mine ? tx("by", { n: tx("you") }) : tx("by", { n: current.name }))}</b> ${esc(current.cap || "")}</p>`;
        $("nowEmojis").innerHTML = emojiBar(current);
        $("nowEmojis").hidden = false;
      } else {
        $("nowBox").innerHTML = html;
        $("nowEmojis").hidden = true;
      }
    }

    // Hitliste
    const top = state.top || [];
    $("topCard").hidden = !top.length;
    const topHtml = top.map((p, i) => `<li data-open="${esc(p.id)}"><b>${i + 1}</b><img src="${photoUrl(p, "t")}" alt="" data-open="${esc(p.id)}">
      <span>${esc(tx("by", { n: p.mine ? tx("you") : p.name }))}<small>${esc(tx("reactions", { n: total(p) }))}</small></span></li>`).join("");
    if ($("topList").dataset.html !== topHtml) { $("topList").innerHTML = topHtml; $("topList").dataset.html = topHtml; }

    // Alle Fotos
    const photos = state.photos || [];
    $("count").textContent = photos.length ? `(${photos.length})` : "";
    document.querySelector('[data-t="allTitle"]').textContent = tx(state.gallery ? "allTitle" : "myTitle");
    $("galleryNote").textContent = !photos.length ? tx("none") : state.gallery ? "" : tx("galleryOff");
    const grid = photos.map((p) => `<button type="button" class="tile${p.mine ? " mine" : ""}${p.st === "wait" ? " wait" : ""}" data-open="${esc(p.id)}">
      <img loading="lazy" src="${photoUrl(p, "t")}" alt="">${total(p) ? `<small>♥ ${total(p)}</small>` : ""}${p.st === "wait" ? `<em>${esc(tx("waiting"))}</em>` : ""}</button>`).join("");
    if ($("grid").dataset.html !== grid) { $("grid").innerHTML = grid; $("grid").dataset.html = grid; }
    if (viewing) renderViewer();
  }

  // ------------------------------------------------------------ Großansicht

  let viewing = "";
  function find(id) {
    return (state.photos || []).find((p) => p.id === id) || (state.top || []).find((p) => p.id === id)
      || (state.current && state.current.id === id ? state.current : null);
  }
  function renderViewer() {
    const photo = find(viewing);
    if (!photo) { closeViewer(); return; }
    const src = photoUrl(photo, "f");
    if ($("viewerImg").dataset.src !== src) { $("viewerImg").src = src; $("viewerImg").dataset.src = src; }
    $("viewerName").textContent = photo.mine ? tx("by", { n: tx("you") }) : tx("by", { n: photo.name });
    $("viewerCap").textContent = photo.cap || "";
    const bar = emojiBar(photo);
    if ($("viewerEmojis").dataset.html !== bar) { $("viewerEmojis").innerHTML = bar; $("viewerEmojis").dataset.html = bar; }
    $("viewerEmojis").hidden = photo.st === "wait";
    $("viewerShow").hidden = photo.st === "wait" || state.phase === "recap";
    $("viewerSave").href = src;
    $("viewerSave").setAttribute("download", `party-wall-${photo.id}.jpg`);
    $("viewerDelete").hidden = !photo.mine;
  }
  function openViewer(id) {
    viewing = id;
    $("viewerNote").textContent = "";
    $("viewer").hidden = false;
    document.body.classList.add("locked");
    renderViewer();
  }
  function closeViewer() {
    viewing = "";
    $("viewer").hidden = true;
    $("viewerEmojis").dataset.html = "";
    document.body.classList.remove("locked");
  }
  document.addEventListener("click", (event) => {
    const target = event.target.closest("[data-open]");
    if (target && !event.target.closest(".viewer")) openViewer(target.dataset.open);
  });
  $("viewerClose").addEventListener("click", closeViewer);
  $("viewerShow").addEventListener("click", async () => {
    const result = await api("api/show", { id: me, photo: viewing }).catch(() => ({}));
    $("viewerNote").textContent = result.success ? tx("shown") : tx("noAnswer");
  });
  $("viewerDelete").addEventListener("click", async () => {
    const result = await api("api/delete", { id: me, photo: viewing }).catch(() => ({}));
    if (result.success) { closeViewer(); poll(); }
  });

  // ------------------------------------------------------------ Abfragen

  let timer = 0;
  async function poll() {
    clearTimeout(timer);
    try {
      state = await api(`api/state?id=${encodeURIComponent(me)}`);
      if (partyId !== state.party) {
        partyId = state.party;
        me = store.get(`${partyId}.id`);
        if (me) state = await api(`api/state?id=${encodeURIComponent(me)}`);
      }
      if (me && !state.known) me = "";
      render();
    } catch (_) {
      if (!state) { $("joinScreen").hidden = false; $("joinNote").textContent = tx("noAnswer"); }
    }
    timer = setTimeout(poll, document.hidden ? 15000 : 2500);
  }
  document.addEventListener("visibilitychange", () => { if (!document.hidden) poll(); });

  applyLanguage();
  poll();
})();
