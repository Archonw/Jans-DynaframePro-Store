/* Colour Calendar - die Szene.
 *
 * Ein Jahr (oder mehrere) als Kalender, in dem jeder Tag die Farbe seiner
 * Fotos hat. Die Tage und ihre Farben kommen vom Plugin ColorCalendar über
 * den Proxy der Weboberfläche (wie bei Travel Map).
 *
 * Vier Formen:
 * - months:  12 Zeilen (Monate) x 31 Tage, im Hochformat gedreht,
 * - weeks:   Wochen x Wochentage in zwei Hälften (Jan-Jun, Jul-Dez),
 * - ring:    das Jahr als Ring, mehrere Jahre als Ringe ineinander,
 * - stripes: ein Streifen je Jahr, jeder Tag ein schmaler Strich.
 * "Alle Jahre" geht nur mit Ring und Streifen; Monate/Wochen zeigen dann Streifen.
 *
 * Zwei Canvas: "cal" (der Kalender, nur bei Daten- oder Größenwechsel neu)
 * und "fx" (der hervorgehobene Tag und die Linie zur Fotokarte).
 *
 * ?demo=1 zeigt erfundene Tage, dazu ?layout=, ?period=, ?lang=, ?bg=light.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "ColorCalendar";
  const params = new URLSearchParams(location.search);
  const DEMO = params.has("demo");
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set([
    `${location.protocol}//${location.hostname}:8003${advanced}`,
    `${location.protocol}//${location.hostname}${advanced}`,
    `${location.origin}${advanced}`,
  ])];
  // Kommt die Szene über Port 80/443 (RemoteFrame, Web Login), zuerst denselben Ursprung fragen.
  if (!params.get("plugin") && (location.port === "" || location.port === "80" || location.port === "443")) {
    pluginBases.sort((a, b) => (b.startsWith(location.origin) ? 1 : 0) - (a.startsWith(location.origin) ? 1 : 0));
  }
  let baseIndex = 0;

  const TEXT = {
    de: { title: "Das Jahr in Farben", titleMulti: "Die Jahre in Farben", stats: "{photos} Fotos an {days} Tagen",
      busy: "Die Farben werden gelesen …", progress: "Farben werden gelesen: {done} von {todo}",
      empty: "Noch keine Fotos mit Datum.", offline: "Colour Calendar antwortet nicht",
      photos: "{n} Fotos", photo: "1 Foto", ago: "heute vor {n} Jahren", ago1: "heute vor einem Jahr",
      wd: ["Mo", "", "Mi", "", "Fr", "", ""] },
    en: { title: "The year in colour", titleMulti: "The years in colour", stats: "{photos} photos on {days} days",
      busy: "Reading the colours …", progress: "Reading colours: {done} of {todo}",
      empty: "No photos with a date yet.", offline: "Colour Calendar is not responding",
      photos: "{n} photos", photo: "1 photo", ago: "{n} years ago today", ago1: "one year ago today",
      wd: ["Mon", "", "Wed", "", "Fri", "", ""] },
    es: { title: "El año en colores", titleMulti: "Los años en colores", stats: "{photos} fotos en {days} días",
      busy: "Leyendo los colores …", progress: "Leyendo colores: {done} de {todo}",
      empty: "Aún no hay fotos con fecha.", offline: "Colour Calendar no responde",
      photos: "{n} fotos", photo: "1 foto", ago: "hoy hace {n} años", ago1: "hoy hace un año",
      wd: ["lu", "", "mi", "", "vi", "", ""] },
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const DAY = 86400000;

  const el = (id) => document.getElementById(id);
  const calCanvas = el("cal"), fxCanvas = el("fx");
  const calCtx = calCanvas.getContext("2d"), fxCtx = fxCanvas.getContext("2d");

  const state = {
    lang: params.get("lang") || "en",
    layout: params.get("layout") || "months",
    period: params.get("period") || "last12",
    year: new Date().getFullYear(),
    yearsMax: 6,
    bg: params.get("bg") || "dark",
    shape: params.get("shape") || "rounded",
    fill: true, vivid: true, monthColours: true, showStats: true, title: "",
    showPhotos: params.get("photos") !== "0", photoSeconds: 12, photoPause: 8,
    scroll: params.get("scroll") !== "0", scrollLimit: params.get("scrolllimit") || "photos",
    scrollCount: Number(params.get("scrollcount")) || 12, scrollSeconds: Number(params.get("scrollseconds")) || 30,
    scrollSpeed: params.get("speed") || "normal", scrollDir: params.get("dir") || "horizontal",
    days: new Map(), ver: -1, today: "", busy: false, progress: { done: 0, todo: 0 },
    loaded: false, reachable: true, failures: 0,
  };
  let W = 0, H = 0, dpr = 1, U = 1;
  let view = null;         // {layout, rows, cells: Map(iso -> cell), from, to, ...}
  let readySent = false;

  const tx = (key, values = {}) => String((TEXT[state.lang] || TEXT.en)[key] ?? key)
    .replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");
  const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[state.lang] || "en-GB");
  const locale = () => LOCALES[state.lang] || "en-GB";

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  function report(text) {
    if (DEMO) return;
    try {
      fetch(`${pluginBases[baseIndex]}api/report?m=${encodeURIComponent(String(text).slice(0, 200))}`,
        { cache: "no-store" }).catch(() => {});
    } catch (_) { /* egal */ }
  }

  // ------------------------------------------------------------ Datum (immer UTC, kein Sommerzeit-Ärger)

  const ms = (iso) => Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10));
  const iso = (t) => new Date(t).toISOString().slice(0, 10);
  const ymd = (y, m, d) => Date.UTC(y, m, d);
  const daysIn = (y, m) => new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
  const todayIso = () => {
    if (state.today) return state.today;
    const d = new Date();
    return iso(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  };
  const monthName = (m, style = "short") =>
    new Date(Date.UTC(2001, m, 1)).toLocaleDateString(locale(), { month: style, timeZone: "UTC" }).replace(".", "");

  // ------------------------------------------------------------ Farben

  function hexRgb(hex) {
    const n = parseInt(hex, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  function rgbHsl([r, g, b]) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0;
    const l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
      h /= 6;
    }
    return [h, s, l];
  }

  function hslRgb([h, s, l]) {
    if (!s) return [l * 255, l * 255, l * 255];
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    const f = (t) => {
      t = (t + 1) % 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };
    return [f(h + 1 / 3) * 255, f(h) * 255, f(h - 1 / 3) * 255];
  }

  // Fotofarben sind oft gedämpft; "Kräftig" hebt die Sättigung und hält die
  // Helligkeit aus dem ganz Dunklen und ganz Hellen heraus.
  function tune(rgb) {
    if (!state.vivid) return rgb;
    const [h, s, l] = rgbHsl(rgb);
    return hslRgb([h, s < 0.08 ? s : Math.min(1, s * 1.3 + 0.06), Math.min(0.8, Math.max(0.2, l))]);
  }

  const css = (rgb, a = 1) => `rgba(${rgb.map((v) => Math.round(v)).join(",")},${a})`;
  const mix = (a, b, f) => a.map((v, i) => v + (b[i] - v) * f);

  function palette() {
    return state.bg === "light"
      ? { bg: [243, 239, 230], ink: [42, 38, 34], empty: "rgba(42,38,34,.075)", future: "rgba(42,38,34,.035)" }
      : { bg: [15, 16, 19], ink: [236, 235, 230], empty: "rgba(236,235,230,.06)", future: "rgba(236,235,230,.025)" };
  }

  // Die Farbe eines Monats: die Farben der Tage nach Farbton gezählt (wie im Plugin)
  function dominant(list) {
    const bins = new Map();
    for (const [rgb, w] of list) {
      const [h, s, l] = rgbHsl(rgb);
      const bin = s < 0.2 ? 24 + (l < 0.35 ? 0 : l < 0.7 ? 1 : 2) : Math.floor(h * 24) % 24;
      const weight = w * (s < 0.2 ? 0.55 : 0.6 + 1.3 * s);
      const row = bins.get(bin) || [0, 0, 0, 0];
      row[0] += weight; row[1] += rgb[0] * weight; row[2] += rgb[1] * weight; row[3] += rgb[2] * weight;
      bins.set(bin, row);
    }
    let best = null, score = -1;
    for (const [bin, row] of bins) {
      let sc = row[0];
      if (bin < 24) for (const n of [(bin + 23) % 24, (bin + 1) % 24]) sc += 0.5 * (bins.get(n)?.[0] || 0);
      if (sc > score) { score = sc; best = row; }
    }
    return best ? [best[1] / best[0], best[2] / best[0], best[3] / best[0]] : null;
  }

  // ------------------------------------------------------------ Zeitraum

  function period() {
    const today = todayIso();
    const ty = +today.slice(0, 4), tm = +today.slice(5, 7) - 1;
    let years = null, from, to;
    if (state.period === "all") {
      let first = ty;
      for (const key of state.days.keys()) { first = Math.min(first, +key.slice(0, 4)); break; }
      for (const key of state.days.keys()) first = Math.min(first, +key.slice(0, 4));
      const start = Math.max(first, ty - state.yearsMax + 1);
      years = [];
      for (let y = start; y <= ty; y++) years.push(y);
      from = `${start}-01-01`; to = `${ty}-12-31`;
    } else if (state.period === "year" || state.period === "pick") {
      const y = state.period === "pick" ? state.year : ty;
      from = `${y}-01-01`; to = `${y}-12-31`;
    } else {
      // Die letzten 12 Monate: vom selben Monat im Vorjahr bis heute
      const start = ymd(ty, tm - 11, 1);
      from = iso(start); to = iso(ymd(ty, tm + 1, 0));
    }
    return { from, to, years, today };
  }

  // ------------------------------------------------------------ Aufbau der Zellen

  function addCell(v, date, geo, order) {
    const cell = Object.assign({ d: date, order, future: date > v.today }, geo);
    v.cells.set(date, cell);
    v.list.push(cell);
  }

  function header() {
    return state.showStats ? U * 17 : U * 13.5;
  }

  function buildMonths(v) {
    const months = [];
    for (let t = ms(v.from); t <= ms(v.to); t = ymd(new Date(t).getUTCFullYear(), new Date(t).getUTCMonth() + 1, 1)) {
      const d = new Date(t);
      months.push([d.getUTCFullYear(), d.getUTCMonth()]);
    }
    const m = U * 4.2, top = header() + U * 2.5;
    const landscape = W >= H;
    const multiYear = months[0][0] !== months[months.length - 1][0];
    v.labels = [];
    if (landscape) {
      const labelW = U * (multiYear ? 11 : 8.5);
      const s = Math.min((W - 2 * m - labelW) / 31, (H - top - m - U * 3) / months.length);
      const left = (W - labelW - 31 * s) / 2 + labelW;
      const gridTop = top + U * 3 + Math.max(0, (H - top - m - U * 3 - months.length * s) / 2);
      v.s = s;
      months.forEach(([y, mo], row) => {
        const n = daysIn(y, mo);
        const label = monthName(mo) + (multiYear ? ` ${String(y).slice(2)}` : "");
        v.labels.push({ text: label, x: left - U * 2.6, y: gridTop + row * s + s / 2, align: "right", month: [y, mo],
          dot: [left - U * 1.3, gridTop + row * s + s / 2] });
        for (let d = 1; d <= n; d++) {
          addCell(v, iso(ymd(y, mo, d)), { kind: "rect", x: left + (d - 1) * s, y: gridTop + row * s, w: s, h: s },
            row * 31 + d);
        }
      });
      for (const d of [1, 5, 10, 15, 20, 25, 31]) {
        v.labels.push({ text: String(d), x: left + (d - 0.5) * s, y: gridTop - U * 1.6, align: "center", small: true });
      }
    } else {
      const labelH = U * 5;
      const dayW = U * 4.5;
      const s = Math.min((W - 2 * m - dayW) / months.length, (H - top - m - labelH) / 31);
      const left = (W - dayW - months.length * s) / 2 + dayW;
      const gridTop = top + labelH;
      v.s = s;
      months.forEach(([y, mo], col) => {
        const n = daysIn(y, mo);
        v.labels.push({ text: monthName(mo).slice(0, 3), x: left + col * s + s / 2, y: gridTop - U * 3.2, align: "center",
          month: [y, mo], dot: [left + col * s + s / 2, gridTop - U * 1.3] });
        for (let d = 1; d <= n; d++) {
          addCell(v, iso(ymd(y, mo, d)), { kind: "rect", x: left + col * s, y: gridTop + (d - 1) * s, w: s, h: s },
            col * 31 + d);
        }
      });
      for (const d of [1, 10, 20, 31]) {
        v.labels.push({ text: String(d), x: left - U * 1.6, y: gridTop + (d - 0.5) * s, align: "right", small: true });
      }
    }
  }

  function buildWeeks(v) {
    const start = ms(v.from), end = ms(v.to);
    const first = start - ((new Date(start).getUTCDay() + 6) % 7) * DAY;      // Montag davor
    const weeks = Math.ceil((end - first + DAY) / (7 * DAY));
    const half = Math.ceil(weeks / 2);
    const m = U * 4.2, top = header() + U * 2;
    const landscape = W >= H;
    v.labels = [];
    const wd = (TEXT[state.lang] || TEXT.en).wd;
    let s, ox, oy;
    if (landscape) {
      const labelW = U * 5.5, monthH = U * 3.4, gap = U * 2.4;
      s = Math.min((W - 2 * m - labelW) / half, (H - top - m - 2 * monthH - gap) / 14);
      ox = (W - labelW - half * s) / 2 + labelW;
      const blockH = monthH + 7 * s;
      oy = top + Math.max(0, (H - top - m - 2 * blockH - gap) / 2) + monthH;
      v.place = (w, d) => {
        const b = w < half ? 0 : 1;
        return { x: ox + (w - b * half) * s, y: oy + b * (blockH + gap) + d * s };
      };
      for (let b = 0; b < 2; b++) {
        for (let d = 0; d < 7; d++) {
          if (wd[d]) v.labels.push({ text: wd[d], x: ox - U * 1.4, y: oy + b * (blockH + gap) + d * s + s / 2, align: "right", small: true });
        }
      }
      v.monthLabel = (w, mo) => {
        const p = v.place(w, 0);
        return { text: monthName(mo), x: p.x, y: p.y - U * 1.6, align: "left" };
      };
    } else {
      const labelW = U * 6.5, wdH = U * 3.4, gap = U * 3;
      s = Math.min((W - 2 * m - 2 * labelW - gap) / 14, (H - top - m - wdH) / half);
      const blockW = labelW + 7 * s;
      ox = (W - 2 * blockW - gap) / 2 + labelW;
      oy = top + wdH + Math.max(0, (H - top - m - wdH - half * s) / 2);
      v.place = (w, d) => {
        const b = w < half ? 0 : 1;
        return { x: ox + b * (blockW + gap) + d * s, y: oy + (w - b * half) * s };
      };
      for (let b = 0; b < 2; b++) {
        for (let d = 0; d < 7; d++) {
          if (wd[d]) v.labels.push({ text: wd[d], x: ox + b * (blockW + gap) + d * s + s / 2, y: oy - U * 1.6, align: "center", small: true });
        }
      }
      v.monthLabel = (w, mo) => {
        const p = v.place(w, 0);
        return { text: monthName(mo), x: p.x - U * 1.2, y: p.y + s / 2, align: "right" };
      };
    }
    v.s = s;
    let order = 0;
    for (let t = start; t <= end; t += DAY) {
      const date = iso(t);
      const w = Math.floor((t - first) / (7 * DAY));
      const d = Math.round((t - first) / DAY) % 7;
      const p = v.place(w, d);
      addCell(v, date, { kind: "rect", x: p.x, y: p.y, w: s, h: s }, order++);
      if (date.slice(8) === "01" || t === start) v.labels.push(v.monthLabel(w, +date.slice(5, 7) - 1));
    }
  }

  function buildRing(v) {
    const years = v.years || [null];
    const landscape = W >= H;
    const m = U * 4.2, labelR = U * 4.6;
    let R, cx, cy;
    if (landscape) {
      R = (H - 2 * m) / 2 - labelR;
      cx = Math.max(W / 2, m + U * 34 + labelR + R);
      cx = Math.min(cx, W - m - labelR - R);
      cy = H / 2;
    } else {
      R = (W - 2 * m) / 2 - labelR;
      cx = W / 2;
      cy = Math.min(H - m - labelR - R, Math.max(H / 2 + U * 4, header() + labelR + R + U * 2));
    }
    const inner = years.length > 1 ? R * 0.34 : R * 0.6;
    const ring = (R - inner) / years.length;
    v.ring = { cx, cy, R, inner };
    v.labels = [];
    let order = 0;
    years.forEach((year, i) => {
      const r0 = inner + i * ring + (years.length > 1 ? ring * 0.08 : 0), r1 = inner + (i + 1) * ring - (years.length > 1 ? ring * 0.08 : 0);
      const start = year === null ? ms(v.from) : ymd(year, 0, 1);
      const end = year === null ? ms(v.to) : ymd(year, 11, 31);
      const n = Math.round((end - start) / DAY) + 1;
      for (let k = 0; k < n; k++) {
        const t = start + k * DAY;
        const a0 = -Math.PI / 2 + (2 * Math.PI * k) / n, a1 = -Math.PI / 2 + (2 * Math.PI * (k + 1)) / n;
        addCell(v, iso(t), { kind: "arc", cx, cy, r0, r1, a0, a1 }, order++);
      }
      if (years.length > 1) {
        v.labels.push({ text: String(year), x: cx - U * 0.9, y: cy - (r0 + r1) / 2, align: "right", small: true, pill: true });
      }
      if (i === years.length - 1) {
        // Monatsnamen außen, in der Mitte jedes Monats
        for (let k = 0, t = start; t <= end; t = ymd(new Date(t).getUTCFullYear(), new Date(t).getUTCMonth() + 1, 1)) {
          const d = new Date(t);
          const mEnd = Math.min(end, ymd(d.getUTCFullYear(), d.getUTCMonth() + 1, 0));
          const mid = ((t - start) / DAY + (mEnd - t) / DAY / 2 + 0.5) / n;
          const a = -Math.PI / 2 + 2 * Math.PI * mid;
          v.labels.push({ text: monthName(d.getUTCMonth()), x: cx + Math.cos(a) * (R + labelR * 0.62), y: cy + Math.sin(a) * (R + labelR * 0.62), align: "center", small: true,
            month: [d.getUTCFullYear(), d.getUTCMonth()] });
          const ta = -Math.PI / 2 + (2 * Math.PI * (t - start)) / DAY / n;
          v.ticks = v.ticks || [];
          v.ticks.push(ta);
          k++;
        }
      }
    });
  }

  function buildStripes(v) {
    const years = v.years || [null];
    const m = U * 4.2, top = header() + U * 5;
    const labelW = years.length > 1 ? U * 8 : 0;
    const left = m + labelW, width = W - m - left;
    const availH = H - top - m - U * 2;
    const rowH = years.length > 1 ? Math.min(availH / years.length * 0.84, U * 16) : availH * 0.72;
    const step = years.length > 1 ? Math.min(availH / years.length, rowH / 0.84) : rowH;
    const oy = top + Math.max(0, (availH - step * years.length) / 2) + (step - rowH) / 2;
    v.labels = [];
    v.stripes = { left, width, top: oy, bottom: oy + step * (years.length - 1) + rowH };
    let order = 0;
    years.forEach((year, i) => {
      const start = year === null ? ms(v.from) : ymd(year, 0, 1);
      const end = year === null ? ms(v.to) : ymd(year, 11, 31);
      const n = Math.round((end - start) / DAY) + 1;
      const y = oy + i * step;
      const bw = width / n;
      for (let k = 0; k < n; k++) {
        addCell(v, iso(start + k * DAY), { kind: "bar", x: left + k * bw, y, w: bw, h: rowH }, order++);
      }
      if (year !== null && years.length > 1) v.labels.push({ text: String(year), x: left - U * 1.6, y: y + rowH / 2, align: "right" });
      if (i === 0) {
        v.ticks = [];
        for (let t = start; t <= end; t = ymd(new Date(t).getUTCFullYear(), new Date(t).getUTCMonth() + 1, 1)) {
          const d = new Date(t);
          const x = left + ((t - start) / DAY) * bw;
          v.ticks.push(x);
          v.labels.push({ text: monthName(d.getUTCMonth()), x: x + U * 0.4, y: y - U * 1.8, align: "left", small: true });
        }
      }
    });
  }

  function effectiveLayout() {
    if (state.period === "all" && (state.layout === "months" || state.layout === "weeks")) return "stripes";
    return state.layout;
  }

  function build() {
    const p = period();
    const v = { layout: effectiveLayout(), from: p.from, to: p.to, years: p.years, today: p.today,
      cells: new Map(), list: [], labels: [], ticks: null };
    if (v.layout === "weeks") buildWeeks(v);
    else if (v.layout === "ring") buildRing(v);
    else if (v.layout === "stripes") buildStripes(v);
    else buildMonths(v);
    view = v;
  }

  // ------------------------------------------------------------ Zeichnen

  function dayColours(date) {
    const day = state.days.get(date);
    if (!day) return null;
    if (!day.tuned) day.tuned = day.cols.map((c) => tune(c));
    return day;
  }

  function fillFor(ctx, cell, day) {
    const c1 = day.tuned[0];
    const c2 = day.tuned[1] && day.w[1] >= 18 ? day.tuned[1] : null;
    if (!c2) return css(c1);
    let g;
    if (cell.kind === "arc") g = ctx.createRadialGradient(cell.cx, cell.cy, cell.r0, cell.cx, cell.cy, cell.r1);
    else if (cell.kind === "bar") g = ctx.createLinearGradient(0, cell.y, 0, cell.y + cell.h);
    else g = ctx.createLinearGradient(cell.x, cell.y, cell.x + cell.w, cell.y + cell.h);
    g.addColorStop(0, css(c1));
    g.addColorStop(0.55, css(c1));
    g.addColorStop(1, css(mix(c1, c2, 0.85)));
    return g;
  }

  function shapePath(ctx, cell, grow = 1) {
    ctx.beginPath();
    if (cell.kind === "arc") {
      const pad = grow > 1 ? 0 : Math.min((cell.a1 - cell.a0) * 0.12, 0.0025);
      const extra = (grow - 1) * (cell.r1 - cell.r0) * 0.5;
      const a0 = cell.a0 + pad - (grow > 1 ? (cell.a1 - cell.a0) * (grow - 1) : 0);
      const a1 = cell.a1 - pad + (grow > 1 ? (cell.a1 - cell.a0) * (grow - 1) : 0);
      ctx.arc(cell.cx, cell.cy, cell.r1 + extra, a0, a1);
      ctx.arc(cell.cx, cell.cy, Math.max(0, cell.r0 - extra), a1, a0, true);
      ctx.closePath();
      return;
    }
    if (cell.kind === "bar") {
      const w = grow > 1 ? Math.max(cell.w * 3, U * 0.7) : cell.w + 0.6;
      const cx = cell.x + cell.w / 2;
      const h = cell.h * (grow > 1 ? 1.08 : 1);
      ctx.rect(cx - w / 2, cell.y + cell.h / 2 - h / 2, w, h);
      return;
    }
    const s = cell.w * grow;
    const x = cell.x + cell.w / 2 - s / 2, y = cell.y + cell.h / 2 - s / 2;
    const inset = s * (state.shape === "dots" ? 0.1 : 0.08);
    const size = s - 2 * inset;
    if (state.shape === "dots") {
      ctx.arc(x + s / 2, y + s / 2, size / 2, 0, Math.PI * 2);
    } else {
      const r = state.shape === "square" ? size * 0.06 : size * 0.24;
      if (ctx.roundRect) ctx.roundRect(x + inset, y + inset, size, size, r);
      else ctx.rect(x + inset, y + inset, size, size);
    }
  }

  // Ein Tag ohne Fotos zwischen zwei Tagen mit Fotos: leise deren Farbe
  function gapColour(date) {
    if (!state.fill) return null;
    let before = null, after = null;
    const t = ms(date);
    for (let k = 1; k <= 3 && !before; k++) before = dayColours(iso(t - k * DAY));
    for (let k = 1; k <= 3 && !after; k++) after = dayColours(iso(t + k * DAY));
    if (!before || !after) return null;
    return mix(before.tuned[0], after.tuned[0], 0.5);
  }

  function sizeCanvas(c) {
    c.width = Math.round(W * dpr);
    c.height = Math.round(H * dpr);
  }

  function drawBackground(ctx) {
    const pal = palette();
    ctx.fillStyle = css(pal.bg);
    ctx.fillRect(0, 0, W, H);
    const g = ctx.createRadialGradient(W * 0.5, H * 0.45, Math.min(W, H) * 0.1, W * 0.5, H * 0.5, Math.max(W, H) * 0.75);
    g.addColorStop(0, state.bg === "light" ? "rgba(255,255,255,.35)" : "rgba(255,255,255,.035)");
    g.addColorStop(1, state.bg === "light" ? "rgba(120,100,70,.10)" : "rgba(0,0,0,.35)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
  }

  function drawLabels(ctx) {
    const pal = palette();
    ctx.textBaseline = "middle";
    if (view.ticks && view.layout === "ring") {
      const { cx, cy, R, inner } = view.ring;
      ctx.strokeStyle = css(pal.bg, 1);
      ctx.lineWidth = Math.max(1.5, U * 0.28);
      for (const a of view.ticks) {
        ctx.beginPath();
        ctx.moveTo(cx + Math.cos(a) * (inner - 2), cy + Math.sin(a) * (inner - 2));
        ctx.lineTo(cx + Math.cos(a) * (R + 2), cy + Math.sin(a) * (R + 2));
        ctx.stroke();
      }
      // Mitte: das Jahr
      const p = period();
      const lines = view.years ? [`${view.years[0]}–${String(view.years[view.years.length - 1]).slice(2)}`]
        : p.from.slice(0, 4) === p.to.slice(0, 4) ? [p.from.slice(0, 4)] : periodLabel(p).split(" – ");
      ctx.fillStyle = css(pal.ink, 0.9);
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      const size = Math.min(inner * (lines.length > 1 ? 0.26 : view.years ? 0.36 : 0.42), U * 9);
      ctx.font = `340 ${size}px Fraunces, Georgia, serif`;
      if (!view.years || inner > U * 9) {
        lines.forEach((line, i) => ctx.fillText(line, cx, cy + (i - (lines.length - 1) / 2) * size * 1.15));
      }
    }
    for (const label of view.labels) {
      ctx.font = `${label.small ? 500 : 600} ${U * (label.small ? 1.55 : 1.9)}px Inter, "DejaVu Sans", sans-serif`;
      ctx.fillStyle = css(pal.ink, label.small ? 0.42 : 0.62);
      ctx.textAlign = label.align;
      if (label.pill) {
        const w = ctx.measureText(label.text).width + U * 1.2, h = U * 2.2;
        const x = label.align === "right" ? label.x - w + U * 0.6 : label.x - w / 2;
        ctx.fillStyle = css(pal.bg, 0.82);
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(x, label.y - h / 2, w, h, h / 2); else ctx.rect(x, label.y - h / 2, w, h);
        ctx.fill();
        ctx.fillStyle = css(pal.ink, 0.75);
      }
      ctx.fillText(label.text, label.x, label.y);
      if (label.dot && state.monthColours) {
        const [y, mo] = label.month;
        const list = [];
        for (let d = 1; d <= daysIn(y, mo); d++) {
          const day = dayColours(iso(ymd(y, mo, d)));
          if (day) list.push([day.tuned[0], Math.sqrt(day.n)]);
        }
        const c = dominant(list);
        if (c) {
          ctx.beginPath();
          ctx.arc(label.dot[0], label.dot[1], U * 0.55, 0, Math.PI * 2);
          ctx.fillStyle = css(c);
          ctx.fill();
        }
      }
    }
    if (view.ticks && view.layout === "stripes") {
      ctx.strokeStyle = css(pal.ink, 0.12);
      ctx.lineWidth = 1;
      for (const x of view.ticks) {
        ctx.beginPath();
        ctx.moveTo(Math.round(x) + 0.5, view.stripes.top - U * 3);
        ctx.lineTo(Math.round(x) + 0.5, view.stripes.top - U * 0.6);
        ctx.stroke();
      }
    }
  }

  let intro = null;

  function drawCalendar(progress = 1) {
    const ctx = calCtx;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawBackground(ctx);
    const pal = palette();
    const total = view.list.length || 1;
    for (const cell of view.list) {
      const reveal = Math.max(0, Math.min(1, (progress * 1.25 - cell.order / total * 1.0) * 4));
      if (reveal <= 0) continue;
      const day = cell.future ? null : dayColours(cell.d);
      shapePath(ctx, cell);
      if (day) {
        ctx.globalAlpha = reveal;
        ctx.fillStyle = fillFor(ctx, cell, day);
      } else if (cell.future) {
        ctx.globalAlpha = 1;
        ctx.fillStyle = pal.future;
      } else {
        const gap = gapColour(cell.d);
        ctx.globalAlpha = gap ? reveal : 1;
        ctx.fillStyle = gap ? css(mix(gap, pal.bg, 0.62)) : pal.empty;
      }
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    // Heute: ein feiner Ring
    const today = view.cells.get(view.today);
    if (today && progress >= 1) {
      shapePath(ctx, today, today.kind === "rect" ? 1.0 : 1);
      ctx.strokeStyle = css(pal.ink, 0.85);
      ctx.lineWidth = Math.max(1.2, U * 0.22);
      ctx.stroke();
    }
    drawLabels(ctx);
  }

  function runIntro() {
    const started = performance.now();
    const duration = 2600;
    cancelAnimationFrame(intro);
    const step = (now) => {
      const p = Math.min(1, (now - started) / duration);
      drawCalendar(p);
      if (p < 1) intro = requestAnimationFrame(step);
      else intro = null;
    };
    intro = requestAnimationFrame(step);
  }

  // ------------------------------------------------------------ Kopf und Hinweise

  function periodLabel(p) {
    if (p.years) return `${p.years[0]} – ${p.years[p.years.length - 1]}`;
    const a = p.from.slice(0, 4), b = p.to.slice(0, 4);
    if (a === b) return a;
    const f = (isoDate) => new Date(ms(isoDate)).toLocaleDateString(locale(), { month: "short", year: "numeric", timeZone: "UTC" });
    return `${f(p.from)} – ${f(p.to)}`;
  }

  function renderHead() {
    const p = period();
    el("title").textContent = state.title || (p.years ? tx("titleMulti") : tx("title"));
    const label = periodLabel(p);
    el("period").textContent = view && view.layout === "ring" && !p.years ? "" : label;
    el("head").classList.toggle("small", label.length > 6);
    let photos = 0, days = 0;
    for (const [date, day] of state.days) {
      if (date >= p.from && date <= p.to) { photos += day.n; days++; }
    }
    el("stats").textContent = state.showStats && days ? tx("stats", { photos: fmt(photos), days: fmt(days) }) : "";
    const note = el("note");
    note.className = "note";
    if (!state.reachable && !DEMO) {
      note.textContent = tx("offline");
    } else if (state.busy && state.progress.todo) {
      note.textContent = tx("progress", { done: fmt(state.progress.done), todo: fmt(state.progress.todo) });
    } else if (state.busy) {
      note.textContent = tx("busy");
    } else if (!state.days.size && state.loaded) {
      note.textContent = tx("empty");
      note.className = "note center";
    } else {
      note.textContent = "";
    }
  }

  // ------------------------------------------------------------ Ein Tag mit Fotos

  let focusTimer = 0, focusBusy = false, focusCell = null, focusColour = null, rotate = 0;
  let lineAnim = null;

  function scheduleFocus(delay) {
    clearTimeout(focusTimer);
    if (!state.showPhotos) return;
    focusTimer = setTimeout(focusNext, delay);
  }

  function loadImage(src) {
    return new Promise((resolve) => {
      const img = new Image();
      const timer = setTimeout(() => resolve(null), 30000);
      img.onload = () => { clearTimeout(timer); resolve(img); };
      img.onerror = () => { clearTimeout(timer); resolve(null); };
      img.decoding = "async";
      img.src = src;
    });
  }

  function choose(photos, count) {
    if (photos.length <= count) return photos;
    const out = [];
    const step = photos.length / count;
    const offset = rotate++ % Math.max(1, Math.floor(step));
    for (let i = 0; i < count; i++) out.push(photos[Math.min(photos.length - 1, Math.floor(i * step) + offset)]);
    return out;
  }

  async function focusNext() {
    if (focusBusy || !view || !state.days.size) { scheduleFocus(5000); return; }
    focusBusy = true;
    try {
      let pick, detail;
      if (DEMO) {
        const dates = view.list.filter((c) => state.days.has(c.d)).map((c) => c.d);
        pick = { d: dates[Math.floor(Math.random() * dates.length)], ago: 0 };
        detail = demoDetail(pick.d);
      } else {
        pick = await fetchJson(`api/next?from=${view.from}&to=${view.to}`).catch(() => null);
        if (!pick || !pick.success) { scheduleFocus(state.photoPause * 1000); return; }
        detail = await fetchJson(`api/day?d=${pick.d}&v=${state.ver}`).catch(() => null);
        if (!detail || !detail.success) { scheduleFocus(4000); return; }
      }
      const cell = view.cells.get(pick.d);
      if (!cell) { scheduleFocus(3000); return; }
      const photoUrl = (p) => DEMO ? p.src : `${pluginBases[baseIndex]}api/photo?k=${p.k}&v=${state.ver}`;
      if (state.scroll && detail.photos.length > 2) {
        const list = state.scrollLimit === "time" ? detail.photos
          : choose(detail.photos, Math.max(3, state.scrollCount));
        const first = (await Promise.all(list.slice(0, 3).map((p) => loadImage(photoUrl(p))))).filter(Boolean);
        if (first.length) {
          await runStrip(cell, detail, pick.ago || 0, list.slice(3), first, photoUrl);
          await new Promise((r) => setTimeout(r, 1200));
          scheduleFocus(state.photoPause * 1000);
          return;
        }
      }
      const wanted = choose(detail.photos, 4);
      const images = (await Promise.all(wanted.map((p) => loadImage(photoUrl(p))))).filter(Boolean);
      if (!images.length) {
        report(`Keine Fotos für ${pick.d} geladen`);
        scheduleFocus(state.photoPause * 1000);
        return;
      }
      showCard(cell, detail, images, pick.ago || 0);
      await new Promise((r) => setTimeout(r, state.photoSeconds * 1000));
      hideCard();
      await new Promise((r) => setTimeout(r, 1200));
      scheduleFocus(state.photoPause * 1000);
    } catch (error) {
      report(`Tag zeigen: ${error && error.message}`);
      hideCard();
      scheduleFocus(state.photoPause * 1000);
    } finally {
      focusBusy = false;
    }
  }

  function placeCard(cell, aspect) {
    const landscape = W >= H;
    const center = cellCenter(cell);
    let zone;
    if (view.cardZone) {
      zone = view.cardZone;
    } else if (landscape) {
      const left = center.x > W / 2;
      const w = W * 0.44;
      zone = { x: left ? W * 0.04 : W * 0.52, y: H * 0.1, w, h: H * 0.8 };
    } else {
      const top = center.y > H * 0.55;
      zone = { x: W * 0.06, y: top ? H * 0.08 : H * 0.5, w: W * 0.88, h: H * 0.42 };
    }
    // Karte so groß wie möglich in der Zone, Fotos im Verhältnis aspect, Bildunterschrift darunter
    const caption = U * 9;
    const pad = U * 2.2;
    let w = zone.w;
    let h = w / aspect + caption + pad;
    if (h > zone.h) { h = zone.h; w = (h - caption - pad) * aspect + pad; }
    w = Math.min(w, zone.w);
    return { x: zone.x + (zone.w - w) / 2, y: zone.y + (zone.h - h) / 2, w, photoH: (w - pad) / aspect };
  }

  function cellCenter(cell) {
    if (cell.kind === "arc") {
      const a = (cell.a0 + cell.a1) / 2, r = (cell.r0 + cell.r1) / 2;
      return { x: cell.cx + Math.cos(a) * r, y: cell.cy + Math.sin(a) * r };
    }
    return { x: cell.x + cell.w / 2, y: cell.y + cell.h / 2 };
  }

  function showCard(cell, detail, images, ago, track = null) {
    const card = el("card"), box = el("photos");
    const n = Math.min(4, images.length);
    let aspect;
    if (track) {
      const vertical = state.scrollDir === "vertical";
      box.className = `photos strip${vertical ? " vertical" : ""}`;
      box.replaceChildren(track);
      aspect = vertical ? (W >= H ? 1.05 : 1.35) : (W >= H ? 2.1 : 1.9);
    } else {
      box.className = `photos n${n}`;
      box.replaceChildren(...images.slice(0, n).map((img) => { img.alt = ""; return img; }));
      const first = images[0];
      const ratio = first.naturalWidth && first.naturalHeight ? first.naturalWidth / first.naturalHeight : 1.5;
      aspect = n === 1 ? Math.max(0.75, Math.min(1.78, ratio)) : n === 2 ? 1.5 : n === 3 ? 1.45 : 1.33;
    }
    const place = placeCard(cell, aspect);
    card.style.left = `${place.x}px`;
    card.style.top = `${place.y}px`;
    card.style.width = `${place.w}px`;
    box.style.height = `${place.photoH}px`;
    const date = new Date(ms(detail.d)).toLocaleDateString(locale(),
      { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });
    el("cardDate").textContent = date;
    const parts = [detail.n === 1 ? tx("photo") : tx("photos", { n: fmt(detail.n) })];
    if (ago > 0) parts.push(ago === 1 ? tx("ago1") : tx("ago", { n: ago }));
    el("cardMeta").textContent = parts.join(" · ");
    const tuned = detail.colours.map((h) => tune(hexRgb(h)));
    const sum = detail.weights.reduce((a, b) => a + b, 0) || 1;
    el("cardSwatch").replaceChildren(...tuned.map((c, i) => {
      const bar = document.createElement("i");
      bar.style.background = css(c);
      bar.style.width = `${(detail.weights[i] / sum) * 100}%`;
      return bar;
    }));
    focusColour = tuned[0];
    document.documentElement.style.setProperty("--glow", tuned[0].map(Math.round).join(","));
    focusCell = cell;
    document.body.classList.add("focus");
    requestAnimationFrame(() => card.classList.add("show"));
    startLine(place);
    return place;
  }

  // Ein Band mit allen Fotos des Tages, ganz und ohne Ausschnitt, das langsam
  // nach links läuft. Weitere Fotos werden geladen, kurz bevor sie gebraucht werden.
  const SPEEDS = { slow: 0.035, normal: 0.06, fast: 0.1, veryfast: 0.16 };   // Kartenbreiten je Sekunde
  let stripAnim = 0;

  function runStrip(cell, detail, ago, rest, first, photoUrl) {
    return new Promise((resolve) => {
      const track = document.createElement("div");
      track.className = "track";
      const place = showCard(cell, detail, first, ago, track);
      const photoH = place.photoH;
      const viewW = place.w - U * 2.2;
      const vertical = state.scrollDir === "vertical";
      const view = vertical ? photoH : viewW;          // sichtbare Länge in Laufrichtung
      const gap = U * 0.7;
      let trackW = 0, loading = false, finished = false;   // trackW: Länge des Bandes in Laufrichtung
      const queue = rest.slice();
      const add = (img) => {
        const ratio = img.naturalWidth && img.naturalHeight ? img.naturalWidth / img.naturalHeight : 1.5;
        img.alt = "";
        let len;
        if (vertical) {
          len = viewW / Math.max(0.5, Math.min(2.6, ratio));
          img.style.width = `${viewW}px`;
          img.style.height = `${len}px`;
        } else {
          len = photoH * Math.max(0.5, Math.min(2.6, ratio));
          img.style.width = `${len}px`;
          img.style.height = `${photoH}px`;
        }
        track.appendChild(img);
        trackW += (trackW ? gap : 0) + len;
      };
      first.forEach(add);
      const loadMore = async () => {
        loading = true;
        while (queue.length) {
          const img = await loadImage(photoUrl(queue.shift()));
          if (finished) break;
          if (img) { add(img); break; }
        }
        loading = false;
      };
      const speed = (SPEEDS[state.scrollSpeed] || SPEEDS.normal) * view;
      const holdStart = 2000, holdEnd = 2500;
      const limitMs = state.scrollLimit === "time" ? state.scrollSeconds * 1000 : Infinity;
      const started = performance.now();
      let last = started, offset = 0, endAt = 0;
      const done = () => {
        finished = true;
        cancelAnimationFrame(stripAnim);
        hideCard();
        resolve();
      };
      const step = (now) => {
        const dt = Math.min(0.25, (now - last) / 1000);
        last = now;
        if (!focusCell) { finished = true; resolve(); return; }      // Karte wurde anderswo geschlossen
        if (!loading && queue.length && trackW - offset < view * 2.5) loadMore();
        const maxOff = Math.max(0, trackW - view);
        if (endAt) {
          if (now >= endAt) { done(); return; }
        } else if (now - started >= limitMs + holdStart) {
          endAt = now + 1200;
        } else if (now - started > holdStart) {
          offset = Math.min(maxOff, offset + speed * dt);
          if (offset >= maxOff && !queue.length && !loading) {
            // am Ende: bei wenigen, schmalen Fotos die Karte wenigstens photoSeconds zeigen
            endAt = Math.max(now + holdEnd, started + state.photoSeconds * 1000);
          }
        }
        track.style.transform = vertical ? `translate3d(0,${-offset}px,0)` : `translate3d(${-offset}px,0,0)`;
        stripAnim = requestAnimationFrame(step);
      };
      stripAnim = requestAnimationFrame(step);
    });
  }

  function hideCard() {
    cancelAnimationFrame(stripAnim);
    el("card").classList.remove("show");
    document.body.classList.remove("focus");
    focusCell = null;
    const started = performance.now();
    cancelAnimationFrame(lineAnim);
    const fade = (now) => {
      const p = Math.min(1, (now - started) / 900);
      drawFx(1 - p);
      if (p < 1) lineAnim = requestAnimationFrame(fade);
      else { fxCtx.setTransform(dpr, 0, 0, dpr, 0, 0); fxCtx.clearRect(0, 0, W, H); }
    };
    lineAnim = requestAnimationFrame(fade);
  }

  let lastPlace = null, lastCell = null;

  function startLine(place) {
    lastPlace = place;
    lastCell = focusCell;
    const started = performance.now();
    cancelAnimationFrame(lineAnim);
    const step = (now) => {
      const p = Math.min(1, (now - started) / 1100);
      drawFx(p);
      if (p < 1) lineAnim = requestAnimationFrame(step);
    };
    lineAnim = requestAnimationFrame(step);
  }

  function drawFx(p) {
    const ctx = fxCtx;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);
    const cell = lastCell;
    if (!cell || !lastPlace || p <= 0) return;
    const pal = palette();
    const ease = 1 - Math.pow(1 - p, 3);
    const day = dayColours(cell.d);
    const grow = 1 + (cell.kind === "rect" ? 0.7 : 0.6) * ease;
    ctx.save();
    ctx.shadowColor = css(focusColour || pal.ink, 0.9);
    ctx.shadowBlur = U * 3 * ease;
    shapePath(ctx, cell, grow);
    ctx.fillStyle = day ? fillFor(ctx, cell, day) : css(pal.ink, 0.3);
    ctx.globalAlpha = Math.min(1, p * 2);
    ctx.fill();
    ctx.restore();
    shapePath(ctx, cell, grow);
    ctx.strokeStyle = css(pal.ink, 0.95 * Math.min(1, p * 2));
    ctx.lineWidth = Math.max(1.5, U * 0.3);
    ctx.stroke();
    // Linie von der Zelle zur Karte
    const c = cellCenter(cell);
    const box = lastPlace;
    const tx_ = Math.max(box.x, Math.min(c.x, box.x + box.w));
    const ty_ = Math.max(box.y, Math.min(c.y, box.y + box.photoH + U * 11));
    let ex = tx_, ey = ty_;
    if (c.x < box.x) ex = box.x; else if (c.x > box.x + box.w) ex = box.x + box.w;
    if (c.y < box.y) ey = box.y; else if (c.y > box.y + box.photoH + U * 11) ey = box.y + box.photoH + U * 11;
    const sx = c.x + (ex - c.x) * 0.0, sy = c.y + (ey - c.y) * 0.0;
    const lx = sx + (ex - sx) * ease, ly = sy + (ey - sy) * ease;
    ctx.strokeStyle = css(pal.ink, 0.55);
    ctx.lineWidth = Math.max(1, U * 0.18);
    ctx.setLineDash([U * 0.6, U * 0.6]);
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(lx, ly);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // ------------------------------------------------------------ Daten

  async function fetchJson(path) {
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 15000);
    try {
      const response = await fetch(pluginBases[baseIndex] + path, { cache: "no-store", signal: abort.signal });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } finally {
      clearTimeout(timer);
    }
  }

  function apply(data) {
    const s = data.settings || {};
    const keyOf = () => JSON.stringify([state.layout, state.period, state.year, state.yearsMax, state.bg, state.shape,
      state.fill, state.vivid, state.monthColours, state.showStats, state.lang, state.today]);
    const before = keyOf();
    state.lang = params.get("lang") || s.Language || state.lang;
    state.layout = params.get("layout") || s.Layout || state.layout;
    state.period = params.get("period") || s.Period || state.period;
    state.year = Number(s.Year) || state.year;
    state.yearsMax = Number(s.YearsMax) || state.yearsMax;
    state.bg = params.get("bg") || s.Background || state.bg;
    state.shape = params.get("shape") || s.CellShape || state.shape;
    state.fill = s.FillGaps !== false;
    state.vivid = s.Vivid !== false;
    state.monthColours = s.MonthColours !== false;
    state.showStats = s.ShowStats !== false;
    state.title = s.Title || "";
    state.showPhotos = s.ShowPhotos !== false && params.get("photos") !== "0";
    state.photoSeconds = s.PhotoSeconds || 12;
    state.photoPause = Number.isFinite(s.PhotoPause) ? s.PhotoPause : 8;
    state.scroll = s.ScrollPhotos !== false && params.get("scroll") !== "0";
    state.scrollLimit = params.get("scrolllimit") || s.ScrollLimit || "photos";
    state.scrollCount = Number(params.get("scrollcount")) || s.ScrollCount || 12;
    state.scrollSeconds = Number(params.get("scrollseconds")) || s.ScrollSeconds || 30;
    state.scrollSpeed = params.get("speed") || s.ScrollSpeed || "normal";
    state.scrollDir = params.get("dir") || s.ScrollDirection || "horizontal";
    state.today = data.today || state.today;
    state.busy = !!data.busy;
    state.progress = data.progress || { done: 0, todo: 0 };
    let fresh = false;
    if (Array.isArray(data.days)) {
      const map = new Map();
      for (const [date, n, cols, weights] of data.days) {
        map.set(date, { n, cols: String(cols).split(",").map(hexRgb), w: String(weights).split(",").map(Number) });
      }
      state.days = map;
      state.ver = data.ver;
      fresh = true;
    }
    const first = !state.loaded;
    state.loaded = true;
    if (first || before !== keyOf() || fresh) layout(first || (fresh && before === keyOf() ? false : true));
    else renderHead();
    if (!state.showPhotos) { clearTimeout(focusTimer); if (focusCell) hideCard(); }
    else if (!focusBusy && first) scheduleFocus(4500);
    else if (!focusBusy && fresh) scheduleFocus(3000);
  }

  async function poll() {
    if (DEMO) return;
    try {
      const data = await fetchJson(`api/scene?v=${state.ver}`);
      state.reachable = true;
      state.failures = 0;
      apply(data);
    } catch (_) {
      state.failures++;
      if (pluginBases.length > 1) baseIndex = (baseIndex + 1) % pluginBases.length;
      if (state.failures >= pluginBases.length * 2) {
        state.reachable = false;
        if (!state.loaded) { state.loaded = true; layout(false); }
        renderHead();
      }
    }
    setTimeout(poll, !state.loaded || !state.reachable ? 4000 : state.busy ? 10000 : 30000);
  }

  // ------------------------------------------------------------ Aufbau

  function layout(animate) {
    W = window.innerWidth;
    H = window.innerHeight;
    dpr = Math.min(2, window.devicePixelRatio || 1);
    U = Math.min(W, H) / 100;
    document.documentElement.style.setProperty("--u", `${U}px`);
    document.documentElement.classList.toggle("light", state.bg === "light");
    sizeCanvas(calCanvas);
    sizeCanvas(fxCanvas);
    build();
    if (animate) runIntro();
    else drawCalendar(1);
    renderHead();
    if (focusCell && lastPlace) {
      const cell = view.cells.get(focusCell.d);
      if (cell) { lastCell = cell; focusCell = cell; }
      drawFx(1);
    }
    ready();
  }

  let resizeTimer = 0;
  window.addEventListener("resize", () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => layout(false), 250);
  });

  // ------------------------------------------------------------ Vorführung (?demo=1)

  function seeded(seed) {
    let x = seed;
    return () => { x = (x * 1664525 + 1013904223) % 4294967296; return x / 4294967296; };
  }

  // Erfundene Jahre: Winter grau-blau und weiß, Frühling grün und rosa,
  // Sommer blau und gelb, Herbst orange, Dezember rot und gold, dazu Urlaube.
  function demoDays() {
    const rnd = seeded(7);
    const today = todayIso();
    const ty = +today.slice(0, 4);
    const map = new Map();
    const season = [
      [[200, 30, 40, 0.5], [210, 12, 80, 0.5]], [[205, 25, 55, 0.6], [0, 0, 92, 0.4]],
      [[95, 40, 45, 0.6], [330, 45, 75, 0.4]], [[100, 45, 42, 0.6], [55, 70, 60, 0.4]],
      [[110, 45, 40, 0.7], [340, 55, 70, 0.3]], [[205, 65, 55, 0.6], [48, 80, 60, 0.4]],
      [[200, 70, 50, 0.6], [45, 85, 58, 0.4]], [[195, 75, 48, 0.5], [40, 80, 55, 0.5]],
      [[35, 70, 50, 0.6], [90, 40, 40, 0.4]], [[25, 80, 48, 0.7], [15, 60, 35, 0.3]],
      [[20, 30, 35, 0.6], [210, 15, 55, 0.4]], [[355, 70, 42, 0.5], [45, 85, 55, 0.5]],
    ];
    const hsl = (h, s, l) => hslRgb([h / 360, s / 100, l / 100]).map((v) => Math.round(v));
    const hex = (rgb) => rgb.map((v) => v.toString(16).padStart(2, "0")).join("");
    for (let y = ty - 8; y <= ty; y++) {
      const trip = 5 + Math.floor(rnd() * 3);       // Sommerurlaub im Juni/Juli/August
      const tripStart = ymd(y, trip, 1 + Math.floor(rnd() * 15));
      for (let t = ymd(y, 0, 1); t <= ymd(y, 11, 31) && iso(t) <= today; t += DAY) {
        const d = new Date(t);
        const mo = d.getUTCMonth();
        const holiday = t >= tripStart && t < tripStart + 14 * DAY;
        const xmas = mo === 11 && d.getUTCDate() >= 20;
        if (!holiday && !xmas && rnd() > (d.getUTCDay() % 6 === 0 ? 0.55 : 0.3)) continue;
        const [a, b] = season[mo];
        const jitter = () => (rnd() - 0.5) * 22;
        let c1 = hsl(a[0] + jitter(), a[1], a[2] + jitter() * 0.4), c2 = hsl(b[0] + jitter(), b[1], b[2]);
        if (holiday) { c1 = hsl(192 + jitter() * 0.5, 80, 52); c2 = hsl(46, 85, 62); }
        if (xmas) { c1 = hsl(355 + jitter() * 0.3, 72, 40); c2 = hsl(44, 85, 55); }
        const w1 = Math.round((holiday ? 60 : a[3] * 100) + jitter());
        const n = holiday || xmas ? 8 + Math.floor(rnd() * 40) : 1 + Math.floor(rnd() * 9);
        map.set(iso(t), { n, cols: [hexRgb(hex(c1)), hexRgb(hex(c2))], w: [w1, 100 - w1] });
      }
    }
    return map;
  }

  function demoPhoto(rgbA, rgbB, seed, width = 640) {
    const c = document.createElement("canvas");
    c.width = width; c.height = 440;
    const g = c.getContext("2d");
    const rnd = seeded(seed);
    const sky = g.createLinearGradient(0, 0, 0, 440);
    sky.addColorStop(0, css(mix(rgbA, [255, 255, 255], 0.25)));
    sky.addColorStop(1, css(rgbA));
    g.fillStyle = sky; g.fillRect(0, 0, 640, 440);
    g.fillStyle = css(mix(rgbB, [255, 250, 220], 0.2), 0.9);
    g.beginPath(); g.arc(160 + rnd() * 320, 120 + rnd() * 60, 46, 0, Math.PI * 2); g.fill();
    g.fillStyle = css(rgbB);
    g.beginPath(); g.moveTo(0, 440);
    for (let x = 0; x <= 640; x += 40) g.lineTo(x, 300 + Math.sin(x / 90 + seed) * 30 + rnd() * 20);
    g.lineTo(640, 440); g.fill();
    g.fillStyle = css(mix(rgbB, [0, 0, 0], 0.35));
    g.beginPath(); g.moveTo(0, 440);
    for (let x = 0; x <= 640; x += 30) g.lineTo(x, 360 + Math.cos(x / 70 + seed) * 18);
    g.lineTo(640, 440); g.fill();
    return c.toDataURL("image/jpeg", 0.85);
  }

  function demoDetail(date) {
    const day = state.days.get(date);
    const n = Math.min(16, day.n);
    const photos = [];
    for (let i = 0; i < n; i++) photos.push({ src: demoPhoto(day.cols[i % day.cols.length], day.cols[(i + 1) % day.cols.length], i + date.length * 7 + +date.slice(8), i % 3 === 1 ? 300 : 640) });
    return { d: date, n: day.n, colours: day.cols.map((c) => c.map((v) => v.toString(16).padStart(2, "0")).join("")), weights: day.w, photos };
  }

  // ------------------------------------------------------------ Start

  // Die Schriften erst laden, sonst zeichnet das Canvas mit einer Ersatzschrift
  const fontsReady = document.fonts ? Promise.all([
    document.fonts.load("340 40px Fraunces"), document.fonts.load("500 20px Inter"), document.fonts.load("600 20px Inter"),
  ]).catch(() => null) : Promise.resolve();
  fontsReady.then(() => { if (view && !intro) drawCalendar(1); });

  if (DEMO) {
    state.days = demoDays();
    state.ver = 1;
    state.loaded = true;
    if (params.get("year")) state.year = +params.get("year");
    if (params.get("years")) state.yearsMax = +params.get("years");
    if (params.get("title")) state.title = params.get("title");
    fontsReady.then(() => layout(!params.has("still")));
    if (params.get("focus")) {
      setTimeout(() => {
        const date = params.get("focus");
        const cell = view.cells.get(date);
        const detail = demoDetail(date);
        const ago = +(params.get("ago") || 0);
        if (state.scroll && detail.photos.length > 2) {
          Promise.all(detail.photos.slice(0, 3).map((p) => loadImage(p.src)))
            .then((imgs) => runStrip(cell, detail, ago, detail.photos.slice(3), imgs.filter(Boolean), (p) => p.src));
        } else {
          Promise.all(detail.photos.slice(0, 4).map((p) => loadImage(p.src))).then((imgs) => showCard(cell, detail, imgs.filter(Boolean), ago));
        }
      }, 600);
    } else if (state.showPhotos && !params.has("still")) {
      scheduleFocus(3500);
    }
  } else {
    layout(false);
    poll();
  }
})();
