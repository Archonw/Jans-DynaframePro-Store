# Licences

- Plugin, scene, pictures and sounds: made for Halloween Scare by Jan; all
  pictures are drawn by the scene's own code, all sounds are synthesised
  (tools/makesounds.py in the source), no recordings or images by others.
- Font "Creepster" (dynamic/fonts): Copyright (c) 2011, Font Diner, Inc,
  SIL Open Font License 1.1, see dynamic/fonts/OFL-Creepster.txt.
- requests, websocket-client: Apache License 2.0, installed by pip.
