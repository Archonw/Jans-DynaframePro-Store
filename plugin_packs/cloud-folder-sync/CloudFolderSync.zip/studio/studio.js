"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/CloudFolderSync/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["IntervalMinutes", "MinFreeMB"];
const TEXT_FIELDS = ["BaseFolder"];
let current = null;
let editing = false;

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["Cloud Folder Sync", "Cloud Folder Sync", "Cloud Folder Sync"],
  lede: ["Holt Fotos aus einem Ordner in Google Drive, Dropbox, OneDrive, pCloud oder Nextcloud auf den Rahmen. Hochladen geht mit der App des Anbieters, von überall; der Rahmen holt neue Fotos regelmäßig ab und DynaFrame zeigt sie. Jede Änderung hier wird sofort gespeichert.",
    "Brings photos from a folder in Google Drive, Dropbox, OneDrive, pCloud or Nextcloud to the frame. Upload with the provider's app, from anywhere; the frame picks up new photos regularly and DynaFrame shows them. Every change here is saved immediately.",
    "Trae al marco las fotos de una carpeta de Google Drive, Dropbox, OneDrive, pCloud o Nextcloud. Se suben con la app del proveedor, desde cualquier lugar; el marco recoge las fotos nuevas con regularidad y DynaFrame las muestra. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  syncNow: ["Jetzt abgleichen", "Sync now", "Sincronizar ahora"],
  factNow: ["Gerade", "Right now", "Ahora"],
  factSources: ["Cloud-Ordner", "Cloud folders", "Carpetas en la nube"],
  factFiles: ["Fotos auf dem Rahmen", "Photos on the frame", "Fotos en el marco"],
  factLast: ["Zuletzt abgeglichen", "Last synced", "Última sincronización"],
  factVersion: ["Version", "Version", "Versión"],
  nowIdle: ["Wartet", "Waiting", "Esperando"],
  nowSync: ["Gleicht {name} ab", "Syncing {name}", "Sincronizando {name}"],
  nowSyncCount: ["Gleicht {name} ab ({a} von {b})", "Syncing {name} ({a} of {b})", "Sincronizando {name} ({a} de {b})"],
  nowRclone: ["Lädt rclone", "Downloading rclone", "Descargando rclone"],
  servicesTitle: ["Verbindungen", "Connections", "Conexiones"],
  servicesCheck: ["Jetzt prüfen", "Check now", "Comprobar ahora"],
  servicesHint: ["Alles, was das Plugin braucht. Es prüft das alle fünf Minuten selbst; rot heißt, dass etwas fehlt, gelb, dass noch etwas zu tun ist.",
    "Everything the plugin needs. It checks this itself every five minutes; red means something is missing, yellow that something is still to do.",
    "Todo lo que necesita el plugin. Lo comprueba solo cada cinco minutos; rojo significa que falta algo, amarillo que aún queda algo por hacer."],
  servicesWait: ["Wird geprüft …", "Checking …", "Comprobando …"],
  svc_ok: ["in Ordnung", "fine", "bien"],
  svc_warn: ["zu tun", "to do", "pendiente"],
  svc_bad: ["fehlt", "missing", "falta"],
  servicesAllOk: ["Alles in Ordnung (geprüft {time}).", "All fine (checked {time}).", "Todo bien (comprobado {time})."],
  servicesSome: ["{bad} fehlt, {warn} zu tun (geprüft {time}).", "{bad} missing, {warn} to do (checked {time}).", "{bad} falta, {warn} pendiente (comprobado {time})."],
  sourcesTitle: ["Deine Cloud-Ordner", "Your cloud folders", "Tus carpetas en la nube"],
  sourcesHint: ["Jeder Cloud-Ordner landet in einem eigenen Ordner auf dem Rahmen. Füge einen Anbieter hinzu, melde dich an und wähle den Ordner mit den Fotos.",
    "Each cloud folder goes into its own folder on the frame. Add a provider, sign in and pick the folder with the photos.",
    "Cada carpeta en la nube va a su propia carpeta en el marco. Añade un proveedor, inicia sesión y elige la carpeta con las fotos."],
  addProvider: ["Anbieter", "Provider", "Proveedor"],
  providerCustom: ["Andere (rclone-Konfiguration)", "Other (rclone configuration)", "Otro (configuración de rclone)"],
  add: ["Hinzufügen", "Add", "Añadir"],
  noSources: ["Noch kein Cloud-Ordner. Wähle unten einen Anbieter.", "No cloud folder yet. Pick a provider below.", "Aún no hay carpetas. Elige un proveedor abajo."],
  srcName: ["Name (auch der Ordner auf dem Rahmen)", "Name (also the folder on the frame)", "Nombre (también la carpeta en el marco)"],
  connected: ["Verbunden", "Connected", "Conectado"],
  connectedAs: ["Verbunden ({who})", "Connected ({who})", "Conectado ({who})"],
  notConnected: ["Nicht verbunden", "Not connected", "No conectado"],
  paused: ["Pausiert", "Paused", "En pausa"],
  syncing: ["Wird abgeglichen …", "Syncing …", "Sincronizando …"],
  step1: ["1. Bei {provider} anmelden", "1. Sign in to {provider}", "1. Iniciar sesión en {provider}"],
  step1Hint: ["Öffnet die Anmeldeseite von {provider} in einem neuen Tab. Melde dich an und erlaube den Zugriff.",
    "Opens the {provider} sign-in page in a new tab. Sign in and allow access.",
    "Abre la página de inicio de sesión de {provider} en una pestaña nueva. Inicia sesión y permite el acceso."],
  step2Hint: ["Danach zeigt der Tab eine Fehlerseite („Seite nicht erreichbar“, Adresse beginnt mit http://127.0.0.1:53682 oder http://localhost:53682). Das ist richtig so. Kopiere die ganze Adresse aus der Adresszeile und füge sie hier ein:",
    "Afterwards the tab shows an error page (“site can't be reached”, the address starts with http://127.0.0.1:53682 or http://localhost:53682). That is expected. Copy the whole address from the address bar and paste it here:",
    "Después la pestaña muestra una página de error («no se puede acceder», la dirección empieza por http://127.0.0.1:53682 o http://localhost:53682). Es lo esperado. Copia la dirección completa de la barra y pégala aquí:"],
  step2: ["2. Verbinden", "2. Connect", "2. Conectar"],
  callbackPh: ["http://127.0.0.1:53682/?state=…&code=…", "http://127.0.0.1:53682/?state=…&code=…", "http://127.0.0.1:53682/?state=…&code=…"],
  reconnect: ["Neu anmelden", "Sign in again", "Volver a iniciar sesión"],
  tokenWay: ["Anderer Weg: mit rclone auf dem Computer", "Other way: with rclone on a computer", "Otra forma: con rclone en un ordenador"],
  tokenHint: ["Hast du rclone auf einem Computer mit Browser, führe dort {cmd} aus und füge die ganze Ausgabe hier ein.",
    "If you have rclone on a computer with a browser, run {cmd} there and paste the whole output here.",
    "Si tienes rclone en un ordenador con navegador, ejecuta allí {cmd} y pega aquí toda la salida."],
  tokenSave: ["Schlüssel übernehmen", "Use token", "Usar token"],
  davUrl: ["Adresse", "Address", "Dirección"],
  davVendor: ["Art", "Kind", "Tipo"],
  davUser: ["Benutzer", "User", "Usuario"],
  davPass: ["App-Passwort", "App password", "Contraseña de aplicación"],
  gkeyTitle: ["Eigener Google-Schlüssel (nötig ab 2026)", "Own Google key (needed from 2026)", "Clave de Google propia (necesaria desde 2026)"],
  gkeySet: ["Eigener Google-Schlüssel ist eingetragen", "Own Google key is set", "Clave de Google propia configurada"],
  gkeyWhy: ["Google Drive lässt Programme nur mit einem „Schlüssel“ (OAuth-Client) zu. Bisher nutzt das Plugin den gemeinsamen Schlüssel von rclone, den Google im Lauf von 2026 abschaltet. Mit einem eigenen, kostenlosen Schlüssel läuft Drive weiter. Einmal anlegen, ca. 10 Minuten:",
    "Google Drive only lets programs in with a “key” (OAuth client). So far the plugin uses rclone's shared key, which Google switches off during 2026. With your own free key Drive keeps working. Create it once, about 10 minutes:",
    "Google Drive solo deja entrar a programas con una «clave» (cliente OAuth). Hasta ahora el plugin usa la clave compartida de rclone, que Google desactiva durante 2026. Con una clave propia y gratuita Drive sigue funcionando. Se crea una vez, unos 10 minutos:"],
  gkeySteps: [
    "<li><a href=\"https://console.cloud.google.com/projectcreate\" target=\"_blank\" rel=\"noopener\">Google Cloud Console</a> öffnen und ein Projekt anlegen (Name egal, z. B. „Bilderrahmen“).</li><li>Unter <a href=\"https://console.cloud.google.com/apis/library/drive.googleapis.com\" target=\"_blank\" rel=\"noopener\">Google Drive API</a> auf „Aktivieren“ tippen.</li><li>„Google Auth Platform“ > „Branding“: App-Name und deine E-Mail eintragen, Zielgruppe „Extern“.</li><li>„Datenzugriff“ > Bereich <code>https://www.googleapis.com/auth/drive.readonly</code> hinzufügen und speichern.</li><li>„Zielgruppe“ > „App veröffentlichen“. Sonst läuft die Anmeldung nach 7 Tagen ab. Google zeigt später eine Warnung „nicht überprüfte App“, die ist bei der eigenen App normal (Erweitert > Weiter).</li><li>„Clients“ > „Client erstellen“ > Typ „Desktop-App“. Client-ID und Clientschlüssel hier eintragen und danach Drive neu anmelden.</li>",
    "<li>Open the <a href=\"https://console.cloud.google.com/projectcreate\" target=\"_blank\" rel=\"noopener\">Google Cloud Console</a> and create a project (any name, e.g. “Photo frame”).</li><li>Enable the <a href=\"https://console.cloud.google.com/apis/library/drive.googleapis.com\" target=\"_blank\" rel=\"noopener\">Google Drive API</a>.</li><li>“Google Auth Platform” > “Branding”: enter app name and your email, audience “External”.</li><li>“Data access”: add the scope <code>https://www.googleapis.com/auth/drive.readonly</code> and save.</li><li>“Audience” > “Publish app”. Otherwise the sign-in expires after 7 days. Google later shows an “unverified app” warning, which is normal for your own app (Advanced > Continue).</li><li>“Clients” > “Create client” > type “Desktop app”. Enter client ID and client secret here, then sign in to Drive again.</li>",
    "<li>Abre la <a href=\"https://console.cloud.google.com/projectcreate\" target=\"_blank\" rel=\"noopener\">Google Cloud Console</a> y crea un proyecto (cualquier nombre, p. ej. «Marco de fotos»).</li><li>Activa la <a href=\"https://console.cloud.google.com/apis/library/drive.googleapis.com\" target=\"_blank\" rel=\"noopener\">Google Drive API</a>.</li><li>«Google Auth Platform» > «Branding»: nombre de la app y tu correo, público «Externo».</li><li>«Acceso a datos»: añade el ámbito <code>https://www.googleapis.com/auth/drive.readonly</code> y guarda.</li><li>«Público» > «Publicar app». Si no, el inicio de sesión caduca a los 7 días. Google mostrará luego un aviso de «app no verificada», normal en tu propia app (Avanzado > Continuar).</li><li>«Clientes» > «Crear cliente» > tipo «App de escritorio». Introduce aquí el ID y el secreto de cliente y vuelve a iniciar sesión en Drive.</li>"],
  gkeyId: ["Client-ID", "Client ID", "ID de cliente"],
  gkeySecret: ["Clientschlüssel", "Client secret", "Secreto de cliente"],
  gkeySave: ["Schlüssel speichern", "Save key", "Guardar clave"],
  loginUser: ["E-Mail", "Email", "Correo"],
  megaPass: ["MEGA-Passwort", "MEGA password", "Contraseña de MEGA"],
  koofrPass: ["App-Passwort", "App password", "Contraseña de app"],
  megaHint: ["Kostenlos 20 GB. Zwei-Faktor-Anmeldung geht hier nicht, weil der Rahmen sich bei jedem Abgleich neu anmeldet: nimm ein eigenes MEGA-Konto ohne 2FA für den Rahmen und teile den Fotoordner damit, oder schalte 2FA aus.",
    "20 GB free. Two-factor sign-in does not work here because the frame signs in again on every sync: use a separate MEGA account without 2FA for the frame and share the photo folder with it, or turn 2FA off.",
    "20 GB gratis. El inicio en dos pasos no funciona aquí porque el marco inicia sesión en cada sincronización: usa una cuenta de MEGA aparte sin 2FA para el marco y comparte con ella la carpeta de fotos, o desactiva 2FA."],
  koofrHint: ["Kostenlos 10 GB, Server in der EU. Das App-Passwort legst du in Koofr unter Einstellungen > Passwörter an (nicht dein normales Passwort).",
    "10 GB free, servers in the EU. Create the app password in Koofr under Settings > Passwords (not your normal password).",
    "10 GB gratis, servidores en la UE. Crea la contraseña de app en Koofr en Ajustes > Contraseñas (no tu contraseña normal)."],
  icService: ["Was holen", "What to fetch", "Qué traer"],
  icPhotos: ["iCloud Fotos (Mediathek und Alben)", "iCloud Photos (library and albums)", "Fotos de iCloud (fototeca y álbumes)"],
  icId: ["Apple-ID (E-Mail)", "Apple ID (email)", "Apple ID (correo)"],
  icHint: ["Normales Apple-Passwort, kein App-Passwort. Danach schickt Apple einen Code an dein iPhone. Auf dem iPhone muss unter Einstellungen > Apple-Account > iCloud „Auf iCloud-Daten im Web zugreifen“ an sein. Die Anmeldung gilt 30 Tage, dann fragt das Plugin wieder nach einem Code. Passwort und Anmeldung bleiben nur auf dem Rahmen.",
    "Your normal Apple password, not an app-specific password. Apple then sends a code to your iPhone. On the iPhone, Settings > Apple Account > iCloud > “Access iCloud Data on the Web” must be on. The sign-in lasts 30 days, then the plugin asks for a new code. Password and sign-in stay on the frame only.",
    "Tu contraseña normal de Apple, no una contraseña de app. Apple enviará un código a tu iPhone. En el iPhone debe estar activado Ajustes > Cuenta de Apple > iCloud > «Acceder a los datos de iCloud en la web». El inicio de sesión dura 30 días; después el plugin pide un código nuevo. Contraseña e inicio de sesión se quedan solo en el marco."],
  icPass: ["Apple-Passwort", "Apple password", "Contraseña de Apple"],
  icLogin: ["Bei Apple anmelden", "Sign in with Apple", "Iniciar sesión en Apple"],
  icWait: ["Melde an … gleich kommt ein Code auf dein iPhone.", "Signing in … a code will arrive on your iPhone.", "Iniciando sesión … llegará un código a tu iPhone."],
  icAsk: ["Bitte den Code eingeben.", "Please enter the code.", "Introduce el código."],
  icCode: ["Code von deinem iPhone oder Mac (6 Ziffern):", "Code from your iPhone or Mac (6 digits):", "Código de tu iPhone o Mac (6 dígitos):"],
  icConfirm: ["Bestätigen", "Confirm", "Confirmar"],
  icSms: ["Kein Code gekommen? Per SMS schicken", "No code? Send by SMS", "¿No llegó? Enviar por SMS"],
  icPhone: ["An welche Nummer soll die SMS?", "Which number should get the SMS?", "¿A qué número enviamos el SMS?"],
  icSend: ["SMS schicken", "Send SMS", "Enviar SMS"],
  icDays: ["iCloud-Anmeldung gilt noch {n} Tage. Danach hier neu anmelden.", "iCloud sign-in valid for {n} more days. Then sign in again here.", "El inicio de sesión de iCloud vale {n} días más. Después vuelve a iniciar sesión aquí."],
  icExpired: ["iCloud-Anmeldung abgelaufen. Bitte neu anmelden.", "iCloud sign-in expired. Please sign in again.", "Inicio de sesión de iCloud caducado. Vuelve a iniciar sesión."],
  icFolderHint: ["PrimarySync ist deine Mediathek, darin liegen die Alben (z. B. PrimarySync/Favorites). „All Photos“ holt alles, das kann sehr viel sein.", "PrimarySync is your library with the albums inside (e.g. PrimarySync/Favorites). “All Photos” fetches everything, which can be a lot.", "PrimarySync es tu fototeca con los álbumes dentro (p. ej. PrimarySync/Favorites). «All Photos» trae todo, puede ser mucho."],
  albumUrl: ["Link zum geteilten Album", "Link to the shared album", "Enlace al álbum compartido"],
  albumHint: ["Ohne Apple-Anmeldung: Am iPhone in Fotos > Alben ein geteiltes Album öffnen, auf „Personen“ tippen, „Öffentliche Website“ einschalten und den Link hier einfügen. Alle Mitglieder können Fotos hinzufügen, der Rahmen holt sie automatisch. Wer den Link kennt, kann das Album ansehen.",
    "No Apple sign-in: on the iPhone open a shared album in Photos > Albums, tap “People”, turn on “Public Website” and paste the link here. All members can add photos and the frame fetches them automatically. Anyone with the link can view the album.",
    "Sin iniciar sesión en Apple: en el iPhone abre un álbum compartido en Fotos > Álbumes, toca «Personas», activa «Sitio web público» y pega aquí el enlace. Todos los miembros pueden añadir fotos y el marco las trae solo. Quien tenga el enlace puede ver el álbum."],
  providerAlbum: ["Geteiltes iCloud-Album (Link)", "Shared iCloud album (link)", "Álbum compartido de iCloud (enlace)"],
  davSave: ["Speichern und testen", "Save and test", "Guardar y probar"],
  davHint: ["Bei Nextcloud reicht die Adresse des Servers (z. B. https://cloud.example.de); den Rest ergänzt das Plugin. Ein App-Passwort bekommst du in Nextcloud unter Persönliche Einstellungen > Sicherheit.",
    "For Nextcloud the server address is enough (e.g. https://cloud.example.com); the plugin adds the rest. Create an app password in Nextcloud under Personal settings > Security.",
    "Para Nextcloud basta con la dirección del servidor (p. ej. https://cloud.example.com); el plugin completa el resto. Crea una contraseña de aplicación en Nextcloud en Configuración personal > Seguridad."],
  passSaved: ["gespeichert – leer lassen zum Behalten", "saved – leave empty to keep", "guardada – déjala vacía para mantenerla"],
  customHint: ["Für alle anderen Dienste, die rclone kennt (SFTP, SMB, S3, Box, MEGA …): füge den Abschnitt aus deiner rclone.conf ein. Passwörter müssen wie dort mit rclone obscure verschleiert sein.",
    "For every other service rclone knows (SFTP, SMB, S3, Box, MEGA …): paste the section from your rclone.conf. Passwords must be obscured with rclone obscure, as there.",
    "Para cualquier otro servicio que conozca rclone (SFTP, SMB, S3, Box, MEGA …): pega la sección de tu rclone.conf. Las contraseñas deben estar ofuscadas con rclone obscure, como allí."],
  customSave: ["Übernehmen und testen", "Apply and test", "Aplicar y probar"],
  customSaved: ["Konfiguration ist gespeichert. Neu einfügen ersetzt sie.", "Configuration is saved. Pasting again replaces it.", "La configuración está guardada. Pegar de nuevo la reemplaza."],
  folderTitle: ["1. Ordner in der Cloud", "1. Folder in the cloud", "1. Carpeta en la nube"],
  folderAll: ["(ganze Cloud)", "(whole cloud)", "(toda la nube)"],
  chooseFirst: ["Ordner wählen", "Choose a folder", "Elige una carpeta"],
  chooseHint: ["Verbunden. Wähle jetzt den Ordner mit den Fotos; erst dann holt das Plugin etwas.", "Connected. Now choose the folder with the photos; only then does the plugin fetch anything.", "Conectado. Ahora elige la carpeta con las fotos; solo entonces el plugin trae algo."],
  pickFolder: ["Ordner wählen", "Choose folder", "Elegir carpeta"],
  up: ["Eine Ebene höher", "Up one level", "Subir un nivel"],
  useFolder: ["Diesen Ordner nehmen", "Use this folder", "Usar esta carpeta"],
  collapse: ["Einklappen", "Collapse", "Contraer"],
  expand: ["Bearbeiten", "Edit", "Editar"],
  useDefault: ["Standard nehmen", "Use default", "Usar predeterminada"],
  newDir: ["Neuer Ordner", "New folder", "Nueva carpeta"],
  newDirName: ["Name für neuen Ordner", "Name for new folder", "Nombre de la carpeta nueva"],
  otherPlaces: ["Medienordner von DynaFrame:", "DynaFrame media folders:", "Carpetas multimedia de DynaFrame:"],
  close: ["Schließen", "Close", "Cerrar"],
  browseMedia: ["{n} Fotos/Videos direkt in diesem Ordner", "{n} photos/videos directly in this folder", "{n} fotos/vídeos directamente en esta carpeta"],
  browseEmpty: ["Keine Unterordner.", "No subfolders.", "No hay subcarpetas."],
  loading: ["Lädt …", "Loading …", "Cargando …"],
  localPath: ["2. Ordner auf dem Rahmen", "2. Folder on the frame", "2. Carpeta en el marco"],
  localFirst: ["Erst oben den Cloud-Ordner wählen, dann hier den Ordner auf dem Rahmen. Leer lassen = Standard.", "First choose the cloud folder above, then the folder on the frame here. Leave empty = default.", "Primero elige arriba la carpeta en la nube y luego aquí la carpeta en el marco. Vacío = predeterminada."],
  localPathHint: ["Muss in DynaFrames Bilder-Ordner liegen (z. B. /home/pi/Pictures/Oma), nur dort findet DynaFrame neue Fotos. Liegen dort schon eigene Fotos, wird nur hinzugefügt und nie gelöscht. Beim Wechsel bleiben die Fotos im alten Ordner liegen. Ordner außerhalb von „Cloud Folder Sync“ sind nicht in der Playlist des Plugins; nimm sie selbst in eine Playlist auf.",
    "Must be inside DynaFrame's pictures folder (e.g. /home/pi/Pictures/Grandma); only there DynaFrame finds new photos. If your own photos are already there, the plugin only adds and never deletes. When you change it, photos stay in the old folder. Folders outside “Cloud Folder Sync” are not in the plugin's playlist; add them to a playlist yourself.",
    "Debe estar dentro de la carpeta de imágenes de DynaFrame (p. ej. /home/pi/Pictures/Abuela); solo ahí DynaFrame encuentra fotos nuevas. Si ya hay fotos tuyas allí, solo se añaden y nunca se borran. Al cambiarla, las fotos se quedan en la carpeta anterior. Las carpetas fuera de «Cloud Folder Sync» no están en la lista del plugin; añádelas tú a una lista."],
  mode: ["Abgleich", "Sync", "Sincronización"],
  modeMirror: ["Spiegeln: in der Cloud gelöscht = auch vom Rahmen weg", "Mirror: deleted in the cloud = gone from the frame", "Espejo: borrado en la nube = también fuera del marco"],
  modeAdd: ["Nur hinzufügen: nichts vom Rahmen löschen", "Add only: never delete from the frame", "Solo añadir: no borrar nada del marco"],
  videos: ["Videos mitnehmen", "Include videos", "Incluir vídeos"],
  shared: ["„Mit mir geteilt“ statt „Meine Ablage“", "“Shared with me” instead of “My Drive”", "«Compartido conmigo» en lugar de «Mi unidad»"],
  enabled: ["Abgleich eingeschaltet", "Sync switched on", "Sincronización activada"],
  syncOne: ["Jetzt abgleichen", "Sync now", "Sincronizar ahora"],
  remove: ["Entfernen", "Remove", "Quitar"],
  removeKeep: ["Entfernen, Fotos auf dem Rahmen behalten", "Remove, keep photos on the frame", "Quitar, conservar fotos en el marco"],
  removeDelete: ["Entfernen und Fotos vom Rahmen löschen", "Remove and delete photos from the frame", "Quitar y borrar fotos del marco"],
  cancel: ["Abbrechen", "Cancel", "Cancelar"],
  onFrame: ["Auf dem Rahmen: {path}", "On the frame: {path}", "En el marco: {path}"],
  never: ["Noch nicht abgeglichen.", "Not synced yet.", "Aún no sincronizado."],
  opening: ["Öffne die Anmeldung …", "Opening sign-in …", "Abriendo el inicio de sesión …"],
  openedTab: ["Anmeldung im neuen Tab geöffnet. Falls nichts aufging: {link}", "Sign-in opened in a new tab. If nothing opened: {link}", "Inicio de sesión abierto en una pestaña nueva. Si no se abrió nada: {link}"],
  openLink: ["hier öffnen", "open here", "abrir aquí"],
  connecting: ["Verbinde …", "Connecting …", "Conectando …"],
  testing: ["Teste …", "Testing …", "Probando …"],
  familyTitle: ["Die Familie lädt mit hoch", "The family uploads too", "La familia también sube fotos"],
  familyText: ["Teile den Ordner in der Cloud mit Bearbeitungsrechten, dann können alle von ihrem Handy aus Fotos hineinlegen: <b>Google Drive</b> Ordner &gt; Teilen &gt; Person als Mitbearbeiter. <b>Dropbox</b> Ordner &gt; Teilen &gt; Bearbeiten erlaubt. <b>OneDrive</b> Ordner &gt; Teilen &gt; Bearbeitung zulassen. <b>Nextcloud</b> Ordner &gt; Teilen &gt; Hochladen erlauben (geht auch als Link ohne Konto). Bei Google Drive findest du einen Ordner, den dir jemand anderes geteilt hat, mit der Einstellung „Mit mir geteilt“.",
    "Share the cloud folder with edit rights and everyone can add photos from their phone: <b>Google Drive</b> folder &gt; Share &gt; add person as editor. <b>Dropbox</b> folder &gt; Share &gt; can edit. <b>OneDrive</b> folder &gt; Share &gt; allow editing. <b>Nextcloud</b> folder &gt; Share &gt; allow upload (also works as a link without an account). In Google Drive, a folder someone else shared with you is found with the “Shared with me” option.",
    "Comparte la carpeta en la nube con permiso de edición y todos podrán añadir fotos desde su móvil: <b>Google Drive</b> carpeta &gt; Compartir &gt; persona como editor. <b>Dropbox</b> carpeta &gt; Compartir &gt; puede editar. <b>OneDrive</b> carpeta &gt; Compartir &gt; permitir edición. <b>Nextcloud</b> carpeta &gt; Compartir &gt; permitir subida (también como enlace sin cuenta). En Google Drive, una carpeta que otra persona te compartió se encuentra con la opción «Compartido conmigo»."],
  moreTitle: ["Abgleich", "Sync", "Sincronización"],
  interval: ["Alle wie viele Minuten nachsehen", "Check every how many minutes", "Comprobar cada cuántos minutos"],
  minFree: ["Mindestens frei lassen (MB)", "Keep at least this free (MB)", "Dejar libre al menos (MB)"],
  minFreeHint: ["Wird der Platz auf dem Rahmen knapper, hält das Plugin den Abgleich an, damit DynaFrame weiterläuft.",
    "If space on the frame gets tighter, the plugin pauses syncing so DynaFrame keeps running.",
    "Si el espacio en el marco se reduce más, el plugin pausa la sincronización para que DynaFrame siga funcionando."],
  baseFolder: ["Ordner auf dem Rahmen", "Folder on the frame", "Carpeta en el marco"],
  baseFolderHint: ["Leer lassen: ein Ordner „Cloud Folder Sync“ in DynaFrames Bilder-Ordner. Darin bekommt jeder Cloud-Ordner einen Unterordner mit seinem Namen; du kannst ihn wie jeden Ordner in eigene Playlists aufnehmen.",
    "Leave empty: a folder “Cloud Folder Sync” in DynaFrame's pictures folder. Inside, every cloud folder gets a subfolder with its name; add it to your own playlists like any folder.",
    "Déjalo vacío: una carpeta «Cloud Folder Sync» en la carpeta de imágenes de DynaFrame. Dentro, cada carpeta en la nube tiene una subcarpeta con su nombre; puedes añadirla a tus listas como cualquier carpeta."],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „Cloud Folder Sync“ anlegen", "Create the playlist “Cloud Folder Sync”", "Crear la lista «Cloud Folder Sync»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistHint: ["Die Playlist enthält den Ordner mit allen Cloud-Fotos (mit Unterordnern) und ist eingeschaltet. Du kannst den Ordner auch selbst in jede Playlist aufnehmen.",
    "The playlist holds the folder with all cloud photos (with subfolders) and is switched on. You can also add the folder to any playlist yourself.",
    "La lista contiene la carpeta con todas las fotos de la nube (con subcarpetas) y está activada. También puedes añadir la carpeta a cualquier lista."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  oclock: ["{time} Uhr", "{time}", "{time}"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  built.clear();   // Quellen in der neuen Sprache neu aufbauen
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}
const post = (path, body = {}) => api(path, { method: "POST", body: JSON.stringify(body) });

function setStatus(text, tone = "", id = "statusNote") {
  const node = typeof id === "string" ? el(id) : id;
  if (!node) return;
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(epoch) {
  if (!epoch) return "—";
  const date = new Date(epoch * 1000);
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang]);

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await post("./api/settings", changes);
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

// ------------------------------------------------------------ Quellen

const seen = new Set();        // Quellen, die schon einmal angezeigt wurden
const collapsed = new Set();   // eingeklappte Quellen
const built = new Map();   // id -> Signatur, mit der der Block gebaut wurde

function signature(src) {
  return [lang, src.provider, src.connected].join("|");
}

function connectHtml(src) {
  const p = esc(src.label);
  if (src.provider === "webdav") {
    return `<div class="grid">
      <label class="field"><span>${t("davUrl")}</span><input type="url" data-f="url" value="${esc(src.webdavUrl)}" placeholder="https://cloud.example.de" spellcheck="false" autocomplete="off"></label>
      <label class="field"><span>${t("davVendor")}</span><select data-f="vendor">
        <option value="nextcloud"${src.webdavVendor === "nextcloud" ? " selected" : ""}>Nextcloud</option>
        <option value="owncloud"${src.webdavVendor === "owncloud" ? " selected" : ""}>ownCloud</option>
        <option value="other"${src.webdavVendor === "other" ? " selected" : ""}>WebDAV</option></select></label>
      <label class="field"><span>${t("davUser")}</span><input type="text" data-f="user" value="${esc(src.webdavUser)}" spellcheck="false" autocomplete="off"></label>
      <label class="field"><span>${t("davPass")}</span><input type="password" data-f="password" autocomplete="new-password" placeholder="${src.connected ? esc(t("passSaved")) : ""}"></label>
    </div>
    <p class="hint">${t("davHint")}</p>
    <button type="button" data-a="dav">${t("davSave")}</button>`;
  }
  if (src.provider === "mega" || src.provider === "koofr") {
    return `<div class="grid">
      <label class="field"><span>${t("loginUser")}</span><input type="email" data-f="user" value="${esc(src.webdavUser)}" spellcheck="false" autocomplete="off"></label>
      <label class="field"><span>${t(src.provider === "koofr" ? "koofrPass" : "megaPass")}</span><input type="password" data-f="password" autocomplete="new-password" placeholder="${src.connected ? esc(t("passSaved")) : ""}"></label>
    </div>
    <p class="hint">${t(src.provider === "koofr" ? "koofrHint" : "megaHint")}</p>
    <button type="button" data-a="loginpw">${t("davSave")}</button>`;
  }
  if (src.provider === "icloud") {
    const form = `<div class="grid">
      <label class="field"><span>${t("icService")}</span><select data-f="icService">
        <option value="photos"${src.icloudService !== "drive" ? " selected" : ""}>${t("icPhotos")}</option>
        <option value="drive"${src.icloudService === "drive" ? " selected" : ""}>iCloud Drive</option></select></label>
      <label class="field"><span>${t("icId")}</span><input type="email" data-f="appleId" value="${esc(src.appleId)}" spellcheck="false" autocomplete="off"></label>
      <label class="field"><span>${t("icPass")}</span><input type="password" data-f="password" autocomplete="new-password" placeholder="${src.appleId ? esc(t("passSaved")) : ""}"></label>
    </div>
    <p class="hint">${t("icHint")}</p>
    <button type="button" data-a="icloud">${t("icLogin")}</button>
    <div class="ask" data-x="ask" hidden></div>`;
    if (src.connected) {
      return `<p class="hint">${esc(icExpiry(src))}</p><details class="relogin"><summary>${t("reconnect")}</summary>${form}</details>`;
    }
    return form;
  }
  if (src.provider === "icloudalbum") {
    return `<label class="field"><span>${t("albumUrl")}</span><input type="url" data-f="albumUrl" value="${esc(src.albumUrl)}" placeholder="https://www.icloud.com/sharedalbum/#B0…" spellcheck="false" autocomplete="off"></label>
      <p class="hint">${t("albumHint")}</p>
      <button type="button" data-a="album">${t("davSave")}</button>`;
  }
  if (src.provider === "custom") {
    return `<p class="hint">${t("customHint")}</p>
      <textarea data-f="config" spellcheck="false" placeholder="[meine-quelle]&#10;type = sftp&#10;host = …"></textarea>
      ${src.connected ? `<p class="hint">${t("customSaved")}</p>` : ""}
      <button type="button" data-a="custom">${t("customSave")}</button>`;
  }
  const backend = { drive: "drive", dropbox: "dropbox", onedrive: "onedrive", pcloud: "pcloud" }[src.provider];
  const steps = `<button type="button" data-a="login">${t("step1", { provider: p })}</button>
      <p class="hint">${t("step1Hint", { provider: p })}</p>
      <p class="hint">${t("step2Hint")}</p>
      <div class="inline"><input type="url" data-f="callback" placeholder="${esc(t("callbackPh"))}" spellcheck="false" autocomplete="off">
      <button type="button" data-a="finish">${t("step2")}</button></div>
      <details><summary>${t("tokenWay")}</summary>
        <p class="hint">${t("tokenHint", { cmd: `<code>rclone authorize "${backend}"${backend === "drive" && current && current.google && current.google.clientId ? ` "${esc(current.google.clientId)}" "${esc(t("gkeySecret"))}"` : ""}</code>` })}</p>
        <textarea data-f="token" spellcheck="false"></textarea>
        <button type="button" class="secondary" data-a="token">${t("tokenSave")}</button>
      </details>`;
  const key = src.provider === "drive" ? googleKeyHtml() : "";
  if (src.connected) {
    return `${key}<details class="relogin"><summary>${t("reconnect")}</summary>${steps}</details>`;
  }
  return key + steps;
}

function googleKeyHtml() {
  const cid = (current && current.google && current.google.clientId) || "";
  return `<details class="gkey"${cid ? "" : " open"}><summary>${cid ? t("gkeySet") : t("gkeyTitle")}</summary>
    <p class="hint">${t("gkeyWhy")}</p>
    <ol class="hint steps">${t("gkeySteps")}</ol>
    <label class="field"><span>${t("gkeyId")}</span><input type="text" data-f="gClientId" value="${esc(cid)}" placeholder="123-abc.apps.googleusercontent.com" spellcheck="false" autocomplete="off"></label>
    <label class="field"><span>${t("gkeySecret")}</span><input type="password" data-f="gClientSecret" autocomplete="new-password" placeholder="${cid ? esc(t("passSaved")) : "GOCSPX-…"}"></label>
    <button type="button" class="secondary" data-a="gkey">${t("gkeySave")}</button>
  </details>`;
}

function icExpiry(src) {
  if (!src.authExpires) return "";
  const days = Math.ceil((src.authExpires - Date.now() / 1000) / 86400);
  return days > 0 ? t("icDays", { n: days }) : t("icExpired");
}

function renderAsk(box, ask) {
  const view = box.querySelector('[data-x="ask"]');
  if (!view) return;
  if (!ask) { view.hidden = true; view.innerHTML = ""; return; }
  view.hidden = false;
  view.dataset.state = ask.state;
  const choose = ask.choices && ask.choices.length && ask.kind === "phone";
  view.innerHTML = choose
    ? `<p class="hint">${t("icPhone")}</p>
       <div class="inline"><select data-f="askValue">${ask.choices.map((c) => `<option value="${esc(c.value)}">${esc(c.label)}</option>`).join("")}</select>
       <button type="button" data-a="icode">${t("icSend")}</button></div>`
    : `<p class="hint">${ask.kind === "sms" ? esc(ask.help) : t("icCode")}</p>
       <div class="inline"><input type="text" data-f="askValue" inputmode="numeric" autocomplete="one-time-code" maxlength="12" placeholder="123456">
       <button type="button" data-a="icode">${t("icConfirm")}</button></div>
       ${ask.kind === "code" ? `<button type="button" class="link" data-a="icsms">${t("icSms")}</button>` : ""}`;
}

function buildSource(src) {
  const box = document.createElement("article");
  box.className = "source";
  box.dataset.id = src.id;
  box.innerHTML = `
    <div class="source-head">
      <div><b data-x="title"></b> <span class="badge" data-x="badge"></span></div>
      <span class="tag" data-x="label"></span>
    </div>
    <div class="details" data-x="details">
    <label class="field"><span>${t("srcName")}</span><input type="text" data-f="name" value="${esc(src.name)}" maxlength="60" spellcheck="false"></label>
    <div class="connect">${connectHtml(src)}</div>
    <p class="status" data-x="connectNote"></p>
    <div class="folder-pick"${src.connected ? "" : " hidden"}>
      <div${src.provider === "icloudalbum" ? " hidden" : ""}>
      <h3 class="sub">${t("folderTitle")}</h3>
      ${src.provider === "icloud" && src.icloudService !== "drive" ? `<p class="hint">${t("icFolderHint")}</p>` : ""}
      <div class="inline"><input type="text" data-f="remotePath" value="${esc(src.remotePath)}" placeholder="${esc(t("folderAll"))}" spellcheck="false">
        <button type="button" class="secondary" data-a="browse">${t("pickFolder")}</button></div>
      <div class="browser" data-x="browser" hidden></div>
      </div>
      <h3 class="sub step2">${t("localPath")}</h3>
      <p class="hint">${t("localFirst")}</p>
      <div class="inline"><input type="text" data-f="localPath" aria-label="${esc(t("localPath"))}" value="${esc(src.localPath)}" placeholder="${esc(current ? current.folder + "/" + src.folder : "")}" spellcheck="false" autocomplete="off">
        <button type="button" class="secondary" data-a="localBrowse">${t("pickFolder")}</button></div>
      <div class="browser" data-x="localBrowser" hidden></div>
      <p class="hint">${t("localPathHint")}</p>
      <div class="grid">
        <label class="field"><span>${t("mode")}</span><select data-f="mode">
          <option value="mirror">${t("modeMirror")}</option><option value="add">${t("modeAdd")}</option></select></label>
      </div>
      <div class="checks">
        <label><input type="checkbox" data-f="enabled"> <span>${t("enabled")}</span></label>
        <label><input type="checkbox" data-f="videos"> <span>${t("videos")}</span></label>
        ${src.provider === "drive" ? `<label><input type="checkbox" data-f="sharedWithMe"> <span>${t("shared")}</span></label>` : ""}
      </div>
    </div>
    </div>
    <p class="hint" data-x="where"></p>
    <p class="status" data-x="syncNote"></p>
    <div class="source-actions">
      <button type="button" class="secondary" data-a="toggle" data-x="toggle">${t("collapse")}</button>
      <button type="button" class="secondary" data-a="sync"${src.connected ? "" : " hidden"}>${t("syncOne")}</button>
      <button type="button" class="secondary" data-a="remove">${t("remove")}</button>
      <span data-x="confirm" hidden>
        <button type="button" class="secondary" data-a="removeKeep">${t("removeKeep")}</button>
        <button type="button" class="danger" data-a="removeDelete">${t("removeDelete")}</button>
        <button type="button" class="secondary" data-a="removeCancel">${t("cancel")}</button>
      </span>
    </div>`;
  for (const input of box.querySelectorAll("input, textarea")) {
    input.addEventListener("focus", () => { editing = true; });
    input.addEventListener("blur", () => { editing = false; });
  }
  wireSource(box);
  return box;
}

function fillSource(box, src) {
  const q = (name) => box.querySelector(`[data-x="${name}"]`);
  const f = (name) => box.querySelector(`[data-f="${name}"]`);
  q("title").textContent = src.name;
  if (!seen.has(src.id)) {   // Beim Öffnen der Seite: fertige Quellen eingeklappt
    seen.add(src.id);
    if (src.connected && src.folderChosen) collapsed.add(src.id);
  }
  const shut = collapsed.has(src.id);
  q("details").hidden = shut;
  box.classList.toggle("collapsed", shut);
  q("toggle").textContent = shut ? t("expand") : t("collapse");
  q("label").textContent = src.label + (src.remotePath ? ` · /${src.remotePath}` : "");
  const badge = q("badge");
  badge.className = "badge " + (!src.connected || !src.folderChosen ? "warn" : src.syncing ? "busy" : !src.enabled ? "" : src.last.ok === false ? "bad" : "ok");
  badge.textContent = !src.connected ? t("notConnected") : !src.folderChosen ? t("chooseFirst") : src.syncing ? t("syncing") : !src.enabled ? t("paused")
    : src.account ? t("connectedAs", { who: src.account }) : t("connected");
  q("where").textContent = t("onFrame", { path: src.target });
  const p = src.progress || {};
  const note = src.syncing ? (p.total ? t("nowSyncCount", { name: src.name, a: fmt(p.done), b: fmt(p.total) }) : t("syncing"))
    : src.last.text || (src.connected ? (src.folderChosen ? t("never") : t("chooseHint")) : "");
  if (!q("syncNote").dataset.sticky) setStatus(note, src.syncing ? "busy" : src.last.ok === false ? "bad" : "", q("syncNote"));
  for (const name of ["name", "remotePath", "localPath"]) {
    const input = f(name);
    if (input && document.activeElement !== input) input.value = src[name] || "";
  }
  const mode = f("mode");
  if (mode && document.activeElement !== mode) mode.value = src.mode;
  for (const name of ["enabled", "videos", "sharedWithMe"]) {
    const box2 = f(name);
    if (box2) box2.checked = Boolean(src[name]);
  }
}

function sourceById(id) {
  return (current?.sources || []).find((s) => s.id === id);
}

function wireSource(box) {
  const id = box.dataset.id;
  const f = (name) => box.querySelector(`[data-f="${name}"]`);
  const q = (name) => box.querySelector(`[data-x="${name}"]`);
  const note = (text, tone) => setStatus(text, tone, q("connectNote"));
  box.querySelector(".source-head").addEventListener("click", (e) => {
    if (!e.target.closest("button, a, input")) q("toggle").click();
  });
  const edit = async (changes) => {
    try {
      await post("./api/source/edit", { id, ...changes });
      setStatus(t("saved"), "ok", q("syncNote"));
      await refresh();
    } catch (error) {
      setStatus(error.message, "bad", q("syncNote"));
    }
  };
  f("name").addEventListener("change", (e) => edit({ name: e.target.value }));
  box.addEventListener("change", (e) => {
    const name = e.target.dataset.f;
    if (name === "remotePath" || name === "mode" || name === "localPath") edit({ [name]: e.target.value });
    if (["enabled", "videos", "sharedWithMe"].includes(name)) edit({ [name]: e.target.checked });
  });
  box.addEventListener("click", async (e) => {
    const action = e.target.closest("button")?.dataset.a;
    if (!action) return;
    const button = e.target.closest("button");
    if (action === "login") {
      // Tab sofort öffnen (sonst blockt der Browser das Popup), Adresse danach setzen
      const tab = window.open("about:blank", "_blank");
      note(t("opening"), "busy");
      try {
        const result = await post("./api/auth/start", { id });
        if (tab && !tab.closed) tab.location.href = result.url;
        const node = q("connectNote");
        node.className = "status busy";
        node.innerHTML = esc(t("openedTab", { link: "" })) + `<a href="${esc(result.url)}" target="_blank" rel="noopener">${esc(t("openLink"))}</a>`;
      } catch (error) {
        if (tab && !tab.closed) tab.close();
        note(error.message, "bad");
      }
    } else if (action === "finish") {
      note(t("connecting"), "busy");
      button.disabled = true;
      try {
        await post("./api/auth/finish", { id, callback: f("callback").value });
        built.delete(id);
        await refresh();
      } catch (error) {
        note(error.message, "bad");
      }
      button.disabled = false;
    } else if (action === "token") {
      note(t("connecting"), "busy");
      try {
        await post("./api/auth/token", { id, token: f("token").value });
        built.delete(id);
        await refresh();
      } catch (error) {
        note(error.message, "bad");
      }
    } else if (action === "dav" || action === "custom") {
      note(t("testing"), "busy");
      button.disabled = true;
      try {
        const body = action === "dav"
          ? { id, url: f("url").value, user: f("user").value, password: f("password").value, vendor: f("vendor").value }
          : { id, config: f("config").value };
        const result = await post(action === "dav" ? "./api/webdav" : "./api/custom", body);
        if (f("password")) f("password").value = "";
        if (result.ok) {
          built.delete(id);
          await refresh();
        } else {
          note(result.message, "bad");
        }
      } catch (error) {
        note(error.message, "bad");
      }
      button.disabled = false;
    } else if (action === "toggle") {
      if (collapsed.has(id)) collapsed.delete(id); else collapsed.add(id);
      const shut = collapsed.has(id);
      q("details").hidden = shut;
      box.classList.toggle("collapsed", shut);
      button.textContent = shut ? t("expand") : t("collapse");
    } else if (action === "localBrowse") {
      openLocalBrowser(box, f("localPath").value);
    } else if (action === "icloud" || action === "icode" || action === "icsms") {
      note(action === "icloud" ? t("icWait") : t("testing"), "busy");
      button.disabled = true;
      try {
        const askView = q("ask");
        const result = action === "icloud"
          ? await post("./api/icloud/start", { id, appleId: f("appleId").value, password: f("password").value, service: f("icService").value })
          : await post("./api/icloud/code", { id, state: askView.dataset.state, code: action === "icsms" ? "sms" : f("askValue").value });
        if (f("password")) f("password").value = "";
        if (result.ok) {
          note(result.message, "ok");
          built.delete(id);
          await refresh();
        } else {
          renderAsk(box, result.ask);
          note(result.message || (result.ask ? t("icAsk") : ""), result.message ? "bad" : "");
        }
      } catch (error) {
        note(error.message, "bad");
      }
      button.disabled = false;
    } else if (action === "gkey") {
      try {
        const result = await post("./api/google", { clientId: f("gClientId").value, clientSecret: f("gClientSecret").value });
        f("gClientSecret").value = "";
        note(result.message, "ok");
        for (const other of built.keys()) built.delete(other);
        await refresh();
      } catch (error) {
        note(error.message, "bad");
      }
    } else if (action === "loginpw") {
      note(t("testing"), "busy");
      button.disabled = true;
      try {
        const result = await post("./api/login", { id, user: f("user").value, password: f("password").value });
        f("password").value = "";
        if (result.ok) {
          built.delete(id);
          await refresh();
        } else {
          note(result.message, "bad");
        }
      } catch (error) {
        note(error.message, "bad");
      }
      button.disabled = false;
    } else if (action === "album") {
      note(t("testing"), "busy");
      button.disabled = true;
      try {
        const result = await post("./api/album", { id, url: f("albumUrl").value });
        if (result.ok) {
          built.delete(id);
          await refresh();
        } else {
          note(result.message, "bad");
        }
      } catch (error) {
        note(error.message, "bad");
      }
      button.disabled = false;
    } else if (action === "browse") {
      openBrowser(box, f("remotePath").value);
    } else if (action === "sync") {
      try {
        const result = await post("./api/sync", { id });
        setStatus(result.message, "busy", q("syncNote"));
        setTimeout(refresh, 1500);
      } catch (error) {
        setStatus(error.message, "bad", q("syncNote"));
      }
    } else if (action === "remove") {
      q("confirm").hidden = false;
      button.hidden = true;
    } else if (action === "removeCancel") {
      q("confirm").hidden = true;
      box.querySelector('[data-a="remove"]').hidden = false;
    } else if (action === "removeKeep" || action === "removeDelete") {
      try {
        await post("./api/source/remove", { id, deleteFiles: action === "removeDelete" });
        built.delete(id);
        box.remove();
        await refresh();
      } catch (error) {
        setStatus(error.message, "bad", q("syncNote"));
      }
    }
  });
}

async function openBrowser(box, path) {
  const id = box.dataset.id;
  const view = box.querySelector('[data-x="browser"]');
  view.hidden = false;
  view.innerHTML = `<p class="hint">${t("loading")}</p>`;
  try {
    const result = await api(`./api/browse?id=${encodeURIComponent(id)}&path=${encodeURIComponent(path || "")}`);
    const here = result.path || "";
    const parent = here.includes("/") ? here.slice(0, here.lastIndexOf("/")) : "";
    view.innerHTML = `<div class="crumb"><b>/${esc(here)}</b> · ${esc(t("browseMedia", { n: fmt(result.media) }))}</div>
      <ul class="dirs">${result.dirs.map((d) => `<li><button type="button" class="link" data-dir="${esc(here ? here + "/" + d : d)}">📁 ${esc(d)}</button></li>`).join("") || `<li class="hint">${t("browseEmpty")}</li>`}</ul>
      <div class="source-actions">
        ${here ? `<button type="button" class="secondary" data-dir="${esc(parent)}">${t("up")}</button>` : ""}
        <button type="button" data-use="${esc(here)}">${t("useFolder")}</button>
        <button type="button" class="secondary" data-close="1">${t("close")}</button>
      </div>`;
    view.onclick = async (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      if (b.dataset.dir !== undefined) openBrowser(box, b.dataset.dir);
      else if (b.dataset.close) view.hidden = true;
      else if (b.dataset.use !== undefined) {
        view.hidden = true;
        await post("./api/source/edit", { id, remotePath: b.dataset.use });
        box.querySelector('[data-f="remotePath"]').value = b.dataset.use;
        await post("./api/sync", { id });
        await refresh();
      }
    };
  } catch (error) {
    view.innerHTML = `<p class="status bad">${esc(error.message)}</p><button type="button" class="secondary" data-close="1">${t("close")}</button>`;
    view.onclick = (e) => { if (e.target.dataset.close) view.hidden = true; };
  }
}

async function openLocalBrowser(box, path) {
  const id = box.dataset.id;
  const view = box.querySelector('[data-x="localBrowser"]');
  view.hidden = false;
  view.innerHTML = `<p class="hint">${t("loading")}</p>`;
  const choose = async (value) => {
    view.hidden = true;
    const input = box.querySelector('[data-f="localPath"]');
    input.value = value;
    await post("./api/source/edit", { id, localPath: value });
    await post("./api/sync", { id });
    await refresh();
  };
  try {
    const result = await api(`./api/localbrowse?path=${encodeURIComponent(path || "")}`);
    const here = result.path;
    view.innerHTML = `<div class="crumb"><b>${esc(here)}</b> · ${esc(t("browseMedia", { n: fmt(result.media) }))}</div>
      <ul class="dirs">${result.dirs.map((d) => `<li><button type="button" class="link" data-dir="${esc(here.replace(/\/$/, "") + "/" + d)}">📁 ${esc(d)}</button></li>`).join("") || `<li class="hint">${t("browseEmpty")}</li>`}</ul>
      <div class="inline"><input type="text" data-x="newDir" placeholder="${esc(t("newDirName"))}" maxlength="80" spellcheck="false">
        <button type="button" class="secondary" data-mk="1">${t("newDir")}</button></div>
      <p class="status" data-x="localNote"></p>
      <div class="source-actions">
        ${result.parent ? `<button type="button" class="secondary" data-dir="${esc(result.parent)}">${t("up")}</button>` : ""}
        <button type="button" data-use="${esc(here)}">${t("useFolder")}</button>
        <button type="button" class="secondary" data-reset="1">${t("useDefault")}</button>
        <button type="button" class="secondary" data-close="1">${t("close")}</button>
      </div>
      ${result.roots.length > 0 ? `<p class="hint">${t("otherPlaces")}</p><ul class="dirs">${result.roots.map((r) => `<li><button type="button" class="link" data-dir="${esc(r)}">💾 ${esc(r)}</button></li>`).join("")}</ul>` : ""}`;
    view.onclick = async (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      try {
        if (b.dataset.dir !== undefined) openLocalBrowser(box, b.dataset.dir);
        else if (b.dataset.close) view.hidden = true;
        else if (b.dataset.reset) await choose("");
        else if (b.dataset.use !== undefined) await choose(b.dataset.use);
        else if (b.dataset.mk) {
          const name = view.querySelector('[data-x="newDir"]').value.trim();
          if (!name) return;
          const made = await post("./api/localmkdir", { parent: here, name });
          openLocalBrowser(box, made.path);
        }
      } catch (error) {
        setStatus(error.message, "bad", view.querySelector('[data-x="localNote"]'));
      }
    };
  } catch (error) {
    view.innerHTML = `<p class="status bad">${esc(error.message)}</p><button type="button" class="secondary" data-close="1">${t("close")}</button>`;
    view.onclick = (e) => { if (e.target.dataset.close) view.hidden = true; };
  }
}

function renderSources(state) {
  const list = el("sourceList");
  const ids = new Set(state.sources.map((s) => s.id));
  for (const box of [...list.children]) {
    if (!box.dataset.id || !ids.has(box.dataset.id)) box.remove();
  }
  if (!state.sources.length) {
    list.innerHTML = `<p class="hint empty">${t("noSources")}</p>`;
    return;
  }
  list.querySelector(".empty")?.remove();
  for (const src of state.sources) {
    let box = list.querySelector(`[data-id="${CSS.escape(src.id)}"]`);
    const sig = signature(src);
    if (box && built.get(src.id) !== sig && !box.contains(document.activeElement)) {
      const fresh = buildSource(src);
      box.replaceWith(fresh);
      box = fresh;
      built.set(src.id, sig);
    }
    if (!box) {
      box = buildSource(src);
      list.appendChild(box);
      built.set(src.id, sig);
    }
    fillSource(box, src);
  }
}

// ------------------------------------------------------------ Verbindungen

function renderServices(sv) {
  if (!sv || !sv.rows || !sv.rows.length) return;
  el("servicesList").innerHTML = sv.rows.map((r) => `<li class="svc ${esc(r.state)}"><span class="dot"></span>
    <div><b>${esc(r.name)}</b> <span class="tag">${esc(t("svc_" + r.state))}</span><div class="txt">${esc(r.text)}</div>
    ${r.hint && r.state !== "ok" ? `<div class="hint2">${esc(r.hint)}</div>` : ""}</div></li>`).join("");
  if (el("servicesNote").dataset.sticky) return;
  const time = clock(sv.at);
  setStatus(sv.bad || sv.warn ? t("servicesSome", { bad: sv.bad, warn: sv.warn, time }) : t("servicesAllOk", { time }),
    sv.bad ? "bad" : sv.warn ? "" : "ok", "servicesNote");
}
el("servicesButton").addEventListener("click", async () => {
  const button = el("servicesButton");
  button.disabled = true;
  el("servicesNote").dataset.sticky = "1";
  setStatus(t("servicesWait"), "busy", "servicesNote");
  try {
    const result = await api("./api/services");
    delete el("servicesNote").dataset.sticky;
    renderServices(result.services);
  } catch (error) {
    setStatus(error.message, "bad", "servicesNote");
    delete el("servicesNote").dataset.sticky;
  }
  button.disabled = false;
});

// ------------------------------------------------------------ Seite

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  const syncing = state.sources.find((x) => x.syncing);
  const p = syncing?.progress || {};
  el("factNow").textContent = state.rclone.busy ? t("nowRclone")
    : syncing ? (p.total ? t("nowSyncCount", { name: syncing.name, a: fmt(p.done), b: fmt(p.total) }) : t("nowSync", { name: syncing.name }))
    : t("nowIdle");
  el("factSources").textContent = state.sources.length ? fmt(state.sources.length) : "—";
  el("factFiles").textContent = state.files ? fmt(state.files) : "—";
  el("factLast").textContent = clock(state.lastSync);
  el("factVersion").textContent = state.version;
  if (state.rclone.error) setStatus(state.rclone.error, "bad");
  if (document.activeElement !== el("MakePlaylist")) el("MakePlaylist").value = String(Boolean(s.MakePlaylist));
  el("playlistNote").textContent = state.ownPlaylist || "";
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Cloud Folder Sync ${state.version}] `);
  if (!editing) {
    for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    el("Language").value = lang;
    el("BaseFolder").placeholder = state.folder;
  }
  renderSources(state);
  renderServices(state.services);
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
}
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
el("BaseFolder").addEventListener("change", (e) => save({ BaseFolder: e.target.value }));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save({ Language: e.target.value });
});
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));
el("syncButton").addEventListener("click", async () => {
  try {
    const result = await post("./api/sync");
    setStatus(result.message || "", "busy");
    setTimeout(refresh, 1500);
  } catch (error) {
    setStatus(error.message, "bad");
  }
});
el("addButton").addEventListener("click", async () => {
  try {
    await post("./api/source/add", { provider: el("newProvider").value });
    setStatus("", "", "sourcesNote");
    await refresh();
    el("sourceList").lastElementChild?.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    setStatus(error.message, "bad", "sourcesNote");
  }
});

refresh();
setInterval(refresh, 4000);
