"""Ticker Wall - region presets.

A region fills feeds, watchlist, crypto currency, cities and the market
bells with sensible defaults. The owner can change every list afterwards;
choosing a region again on the plugin page fills them anew.
"""

REGIONS = ("intl", "us", "uk", "de", "es")

FEEDS = {
    "intl": [
        ("BBC World", "https://feeds.bbci.co.uk/news/world/rss.xml"),
        ("The Guardian", "https://www.theguardian.com/world/rss"),
        ("Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml"),
        ("DW", "https://rss.dw.com/rdf/rss-en-all"),
        ("France 24", "https://www.france24.com/en/rss"),
        ("NYT World", "https://rss.nytimes.com/services/xml/rss/nyt/World.xml"),
        ("NPR", "https://feeds.npr.org/1001/rss.xml"),
        ("CNBC", "https://search.cnbc.com/rs/search/combinedcms/view.xml?partnerId=wrss01&id=100003114"),
        ("UN News", "https://news.un.org/feed/subscribe/en/news/all/rss.xml"),
    ],
    "us": [
        ("NPR", "https://feeds.npr.org/1001/rss.xml"),
        ("NYT", "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml"),
        ("CBS News", "https://www.cbsnews.com/latest/rss/main"),
        ("ABC News", "https://abcnews.go.com/abcnews/topstories"),
        ("CNBC", "https://search.cnbc.com/rs/search/combinedcms/view.xml?partnerId=wrss01&id=100003114"),
        ("MarketWatch", "https://feeds.content.dowjones.io/public/rss/mw_topstories"),
        ("Yahoo Finance", "https://finance.yahoo.com/news/rssindex"),
        ("BBC World", "https://feeds.bbci.co.uk/news/world/rss.xml"),
        ("The Verge", "https://www.theverge.com/rss/index.xml"),
    ],
    "uk": [
        ("BBC News", "https://feeds.bbci.co.uk/news/rss.xml"),
        ("The Guardian", "https://www.theguardian.com/uk/rss"),
        ("Sky News", "https://feeds.skynews.com/feeds/rss/home.xml"),
        ("The Independent", "https://www.independent.co.uk/news/uk/rss"),
        ("BBC Business", "https://feeds.bbci.co.uk/news/business/rss.xml"),
        ("BBC World", "https://feeds.bbci.co.uk/news/world/rss.xml"),
        ("Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml"),
        ("CNBC", "https://search.cnbc.com/rs/search/combinedcms/view.xml?partnerId=wrss01&id=100003114"),
    ],
    "de": [
        ("tagesschau", "https://www.tagesschau.de/index~rss2.xml"),
        ("SPIEGEL", "https://www.spiegel.de/schlagzeilen/index.rss"),
        ("ZEIT", "https://newsfeed.zeit.de/index"),
        ("n-tv", "https://www.n-tv.de/rss"),
        ("FAZ", "https://www.faz.net/rss/aktuell/"),
        ("tagesschau Wirtschaft", "https://www.tagesschau.de/wirtschaft/index~rss2.xml"),
        ("heise", "https://www.heise.de/rss/heise-atom.xml"),
        ("DW", "https://rss.dw.com/rdf/rss-de-all"),
        ("BBC World", "https://feeds.bbci.co.uk/news/world/rss.xml"),
        ("Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml"),
        ("CNBC", "https://search.cnbc.com/rs/search/combinedcms/view.xml?partnerId=wrss01&id=100003114"),
    ],
    "es": [
        ("El País", "https://feeds.elpais.com/mrss-s/pages/ep/site/elpais.com/portada"),
        ("El Mundo", "https://e00-elmundo.uecdn.es/elmundo/rss/portada.xml"),
        ("20minutos", "https://www.20minutos.es/rss/"),
        ("Expansión", "https://e00-expansion.uecdn.es/rss/portada.xml"),
        ("DW Español", "https://rss.dw.com/rdf/rss-sp-all"),
        ("France 24 ES", "https://www.france24.com/es/rss"),
        ("BBC World", "https://feeds.bbci.co.uk/news/world/rss.xml"),
    ],
}

# Finnhub's free plan has US stocks and ETFs. Indices, other countries and
# commodities come through ETFs that follow them (shown with the ETF name in
# brackets, the move is the ETF's in US dollars); European companies through
# their US listings (ADRs). Currencies (=X) come from the ECB.
# symbol, display name, kind
_US_INDEX = [("SPY", "S&P 500 (SPY)", "index"), ("QQQ", "Nasdaq 100 (QQQ)", "index"), ("DIA", "Dow Jones (DIA)", "index")]
_WORLD = [("VGK", "Europe (VGK)", "index"), ("EWG", "Germany (EWG)", "index"), ("EWU", "UK (EWU)", "index"),
          ("EWJ", "Japan (EWJ)", "index"), ("FXI", "China (FXI)", "index"), ("INDA", "India (INDA)", "index")]
_COMMOD = [("GLD", "Gold (GLD)", "commodity"), ("USO", "Oil (USO)", "commodity"), ("TLT", "US bonds 20Y (TLT)", "bond")]
_BIG_US = [("AAPL", "Apple", "stock"), ("MSFT", "Microsoft", "stock"), ("NVDA", "NVIDIA", "stock"),
           ("AMZN", "Amazon", "stock"), ("GOOGL", "Alphabet", "stock"), ("META", "Meta", "stock"), ("TSLA", "Tesla", "stock")]

WATCHLISTS = {
    "intl": _US_INDEX + _WORLD + _BIG_US + [("TSM", "TSMC", "stock"), ("ASML", "ASML", "stock")] + _COMMOD
            + [("EURUSD=X", "EUR/USD", "fx"), ("USDJPY=X", "USD/JPY", "fx")],
    "us": _US_INDEX + [("IWM", "Russell 2000 (IWM)", "index"), ("VIXY", "Volatility (VIXY)", "index")] + _BIG_US
          + [("JPM", "JPMorgan", "stock"), ("BRK.B", "Berkshire", "stock"), ("XOM", "Exxon", "stock"),
             ("WMT", "Walmart", "stock"), ("NFLX", "Netflix", "stock")] + _COMMOD + [("EURUSD=X", "EUR/USD", "fx")],
    "uk": [("EWU", "UK (EWU)", "index"), ("VGK", "Europe (VGK)", "index")] + _US_INDEX[:2]
          + [("SHEL", "Shell", "stock"), ("AZN", "AstraZeneca", "stock"), ("HSBC", "HSBC", "stock"),
             ("UL", "Unilever", "stock"), ("BP", "BP", "stock"), ("RIO", "Rio Tinto", "stock"), ("BCS", "Barclays", "stock"),
             ("LYG", "Lloyds", "stock"), ("GSK", "GSK", "stock"), ("NVDA", "NVIDIA", "stock"), ("AAPL", "Apple", "stock")]
          + _COMMOD[:2] + [("GBPUSD=X", "GBP/USD", "fx"), ("EURGBP=X", "EUR/GBP", "fx")],
    "de": [("EWG", "Deutschland (EWG)", "index"), ("FEZ", "Euro Stoxx 50 (FEZ)", "index")] + _US_INDEX
          + [("EWJ", "Japan (EWJ)", "index"), ("SAP", "SAP", "stock"), ("SIEGY", "Siemens", "stock"),
             ("ALIZY", "Allianz", "stock"), ("DTEGY", "Dt. Telekom", "stock"), ("RNMBY", "Rheinmetall", "stock"),
             ("MBGYY", "Mercedes-Benz", "stock"), ("BMWYY", "BMW", "stock"), ("BASFY", "BASF", "stock"),
             ("EADSY", "Airbus", "stock"), ("DB", "Deutsche Bank", "stock"), ("NVDA", "NVIDIA", "stock"),
             ("AAPL", "Apple", "stock"), ("GLD", "Gold (GLD)", "commodity"), ("USO", "Öl (USO)", "commodity"),
             ("EURUSD=X", "EUR/USD", "fx"), ("EURCHF=X", "EUR/CHF", "fx")],
    "es": [("EWP", "España (EWP)", "index"), ("FEZ", "Euro Stoxx 50 (FEZ)", "index")] + _US_INDEX[:2]
          + [("SAN", "Santander", "stock"), ("BBVA", "BBVA", "stock"), ("TEF", "Telefónica", "stock"),
             ("IBDRY", "Iberdrola", "stock"), ("IDEXY", "Inditex", "stock"), ("NVDA", "NVIDIA", "stock"),
             ("AAPL", "Apple", "stock"), ("GLD", "Oro (GLD)", "commodity"), ("USO", "Petróleo (USO)", "commodity"),
             ("EURUSD=X", "EUR/USD", "fx")],
}

COINS = ["bitcoin", "ethereum", "solana", "ripple", "binancecoin", "dogecoin", "cardano"]
COIN_CURRENCY = {"intl": "usd", "us": "usd", "uk": "gbp", "de": "eur", "es": "eur"}

# name, latitude, longitude, time zone: world clocks and weather.
CITIES = {
    "intl": [("New York", 40.71, -74.01, "America/New_York"), ("London", 51.51, -0.13, "Europe/London"),
             ("Frankfurt", 50.11, 8.68, "Europe/Berlin"), ("Dubai", 25.20, 55.27, "Asia/Dubai"),
             ("Hong Kong", 22.32, 114.17, "Asia/Hong_Kong"), ("Tokyo", 35.68, 139.69, "Asia/Tokyo")],
    "us": [("Los Angeles", 34.05, -118.24, "America/Los_Angeles"), ("Chicago", 41.88, -87.63, "America/Chicago"),
           ("New York", 40.71, -74.01, "America/New_York"), ("London", 51.51, -0.13, "Europe/London"),
           ("Tokyo", 35.68, 139.69, "Asia/Tokyo")],
    "uk": [("London", 51.51, -0.13, "Europe/London"), ("Edinburgh", 55.95, -3.19, "Europe/London"),
           ("New York", 40.71, -74.01, "America/New_York"), ("Frankfurt", 50.11, 8.68, "Europe/Berlin"),
           ("Hong Kong", 22.32, 114.17, "Asia/Hong_Kong"), ("Tokyo", 35.68, 139.69, "Asia/Tokyo")],
    "de": [("Berlin", 52.52, 13.40, "Europe/Berlin"), ("Frankfurt", 50.11, 8.68, "Europe/Berlin"),
           ("London", 51.51, -0.13, "Europe/London"), ("New York", 40.71, -74.01, "America/New_York"),
           ("Tokio", 35.68, 139.69, "Asia/Tokyo"), ("Sydney", -33.87, 151.21, "Australia/Sydney")],
    "es": [("Madrid", 40.42, -3.70, "Europe/Madrid"), ("Barcelona", 41.39, 2.17, "Europe/Madrid"),
           ("Londres", 51.51, -0.13, "Europe/London"), ("Nueva York", 40.71, -74.01, "America/New_York"),
           ("Ciudad de México", 19.43, -99.13, "America/Mexico_City"), ("Tokio", 35.68, 139.69, "Asia/Tokyo")],
}

# Market bells: id, name, local opening time, time zone.
EXCHANGES = {
    "nyse": ("NYSE", "09:30", "America/New_York"),
    "xetra": ("Xetra", "09:00", "Europe/Berlin"),
    "lse": ("LSE", "08:00", "Europe/London"),
    "bme": ("BME", "09:00", "Europe/Madrid"),
    "tse": ("Tokyo", "09:00", "Asia/Tokyo"),
}
BELLS = {"intl": ["nyse"], "us": ["nyse"], "uk": ["lse"], "de": ["xetra", "nyse"], "es": ["bme"]}
# The index whose big moves count as crash or rally.
MAIN_INDEX = {"intl": "SPY", "us": "SPY", "uk": "EWU", "de": "EWG", "es": "EWP"}


def kind_of(symbol, given=""):
    given = str(given or "").strip().lower()
    if given in ("index", "stock", "fx", "commodity", "bond"):
        return given
    if symbol.upper().endswith("=X"):
        return "fx"
    return "stock"


def feeds_text(region):
    return "\n".join(f"{name} | {address}" for name, address in FEEDS.get(region, FEEDS["intl"]))


def watchlist_text(region):
    return "\n".join(f"{symbol} | {name}" + (f" | {kind}" if kind != "stock" else "")
                     for symbol, name, kind in WATCHLISTS.get(region, WATCHLISTS["intl"]))


def cities_text(region):
    return "\n".join(f"{n} | {lat} | {lon} | {tz}" for n, lat, lon, tz in CITIES.get(region, CITIES["intl"]))


def preset(region):
    region = region if region in REGIONS else "intl"
    return {"Feeds": feeds_text(region), "Watchlist": watchlist_text(region), "Coins": ", ".join(COINS),
            "CoinCurrency": COIN_CURRENCY[region], "Cities": cities_text(region),
            "Bells": list(BELLS[region]), "MainIndex": MAIN_INDEX[region]}


def parse_lines(text, parts):
    """'a | b | c' per line -> list of tuples with `parts` items (missing = '')."""
    rows = []
    for line in str(text or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        cells = [c.strip() for c in line.split("|")]
        rows.append(tuple((cells + [""] * parts)[:parts]))
    return rows
