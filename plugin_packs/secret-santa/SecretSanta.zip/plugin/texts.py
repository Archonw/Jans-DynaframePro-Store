"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt nur die übergebenen Platzhalter; fehlt eine
Übersetzung, bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Die Auflösung läuft schon. Fang erst eine neue Runde an.": (
        "The reveal has started already. Start a new round first.",
        "La revelación ya ha empezado. Empieza primero una ronda nueva."),
    "Die Auflösung lief schon. Fang erst eine neue Runde an.": (
        "The reveal has happened already. Start a new round first.",
        "La revelación ya se ha hecho. Empieza primero una ronda nueva."),
    "Zum Auslosen braucht es mindestens drei Leute.": (
        "The draw needs at least three people.", "Para el sorteo hacen falta al menos tres personas."),
    "So geht die Auslosung nicht auf. Lass bei den Haushalten etwas weg.": (
        "The draw cannot work out like this. Remove some of the households.",
        "Así el sorteo no sale. Quita algunos de los hogares."),
    "Es ist noch nicht ausgelost.": ("Nothing has been drawn yet.", "Todavía no se ha hecho el sorteo."),
    "Es läuft keine Auflösung.": ("No reveal is running.", "No hay ninguna revelación en marcha."),
    "Die Anmeldung ist geschlossen.": ("Sign-up is closed.", "La inscripción está cerrada."),
    "Zu viele Versuche. Warte zehn Minuten.": (
        "Too many tries. Wait ten minutes.", "Demasiados intentos. Espera diez minutos."),
    "Name oder PIN stimmen nicht.": ("Name or PIN is not right.", "El nombre o el PIN no son correctos."),
    "Nach der Auslosung kann man nicht mehr aussteigen. Sag der Spielleitung Bescheid.": (
        "After the draw you cannot leave any more. Tell the organiser.",
        "Después del sorteo ya no puedes salirte. Díselo a quien organiza."),
    "Für dich gibt es kein Los. Sag der Spielleitung Bescheid.": (
        "There is no lot for you. Tell the organiser.", "No hay papelito para ti. Díselo a quien organiza."),
    "Nachrichten sind ausgeschaltet.": ("Messages are switched off.", "Los mensajes están desactivados."),
    "Das sind genug Nachrichten.": ("That is enough messages.", "Ya hay suficientes mensajes."),
    "Schreib erst etwas.": ("Write something first.", "Escribe algo primero."),
    "Die Lose sind schon gezogen.": ("The lots have been drawn already.", "El sorteo ya se ha hecho."),
    "Bitte schreib deinen Namen dazu.": ("Please add your name.", "Escribe tu nombre, por favor."),
    "Die PIN hat genau vier Ziffern.": ("The PIN has exactly four digits.", "El PIN tiene exactamente cuatro cifras."),
    "Diesen Namen gibt es schon. Wenn du das bist: melde dich mit deiner PIN an. Sonst nimm einen anderen, z. B. mit Nachnamen.": (
        "This name is taken. If that is you, sign in with your PIN. Otherwise pick another one, e.g. with your surname.",
        "Ese nombre ya existe. Si eres tú, entra con tu PIN. Si no, elige otro, p. ej. con tu apellido."),
    "Mehr Leute gehen nicht.": ("No more people can join.", "No caben más personas."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.", "El marco no ha creado la lista {name}."),
    "„Allow takeover“ ist für Secret Santa auf der Plugins-Seite aus. Schalte es ein, sonst kann die Auflösung nicht von selbst auf den Fernseher.": (
        "“Allow takeover” is off for Secret Santa on the Plugins page. Switch it on, otherwise the reveal cannot come onto the TV by itself.",
        "«Allow takeover» está desactivado para Secret Santa en la página de plugins. Actívalo; si no, la revelación no puede salir sola en la tele."),
    "Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The scene is not installed on this frame. Install the pack again.",
        "La escena no está instalada en este marco. Vuelve a instalar el paquete."),
    "Konnte die Takeover-Playlist nicht anlegen: {exc}": (
        "Could not create the takeover playlist: {exc}", "No se pudo crear la lista de takeover: {exc}"),
    "Konnte Secret Santa nicht zeigen: {exc}": ("Could not show Secret Santa: {exc}", "No se pudo mostrar Secret Santa: {exc}"),
    "Etwas anderes hat gerade den Bildschirm.": (
        "Something else has the screen right now.", "Otra cosa está usando la pantalla ahora."),
    "Der Rahmen hat Secret Santa nicht rechtzeitig gezeigt.": (
        "The frame did not show Secret Santa in time.", "El marco no ha mostrado Secret Santa a tiempo."),
    "Zum ausgemachten Zeitpunkt waren weniger als drei Leute angemeldet; lose von Hand aus.": (
        "At the agreed time fewer than three people had joined; draw by hand.",
        "A la hora acordada había menos de tres personas apuntadas; haz el sorteo a mano."),
    "Kein Abspielprogramm auf dem Rahmen gefunden.": (
        "No audio player found on the frame.", "No se encontró ningún reproductor de audio en el marco."),
    "Konnte den Klang nicht abspielen ({problem}).": (
        "Could not play the sound ({problem}).", "No se pudo reproducir el sonido ({problem})."),
    "Den Klang gibt es nicht.": ("That sound does not exist.", "Ese sonido no existe."),
    "DynaFrame auf diesem Rahmen": ("DynaFrame on this frame", "DynaFrame en este marco"),
    "Nicht erreichbar: {exc}": ("Not reachable: {exc}", "No disponible: {exc}"),
    "Starte den Rahmen neu, wenn das rot bleibt.": (
        "Restart the frame if this stays red.", "Reinicia el marco si sigue en rojo."),
    "Erreichbar ({ms} ms).": ("Reachable ({ms} ms).", "Disponible ({ms} ms)."),
    "Szene „Secret Santa“": ("Scene “Secret Santa”", "Escena «Secret Santa»"),
    "Nicht installiert.": ("Not installed.", "No instalada."),
    "Installiere das Paket noch einmal.": ("Install the pack again.", "Vuelve a instalar el paquete."),
    "Installiert.": ("Installed.", "Instalada."),
    "Von selbst auf den Fernseher": ("Onto the TV by itself", "Sale sola en la tele"),
    "„Allow takeover“ ist aus.": ("“Allow takeover” is off.", "«Allow takeover» está desactivado."),
    "Ohne das zeigt der Fernseher die Auslosung und die Auflösung nur, wenn die Playlist „Secret Santa“ läuft. Einschalten auf der Plugins-Seite.": (
        "Without it the TV only shows the draw and the reveal while the playlist “Secret Santa” is playing. Switch it on on the Plugins page.",
        "Sin esto, la tele solo muestra el sorteo y la revelación cuando se reproduce la lista «Secret Santa». Actívalo en la página de plugins."),
    "Erlaubt.": ("Allowed.", "Permitido."),
    "Handy-Seite": ("Phone page", "Página del móvil"),
    "Kein freier Port gefunden.": ("No free port found.", "No se encontró ningún puerto libre."),
    "Trag unten einen freien Port ein.": ("Enter a free port below.", "Indica abajo un puerto libre."),
    "{url} antwortet nicht.": ("{url} does not answer.", "{url} no responde."),
    "Ist das WLAN des Rahmens verbunden?": ("Is the frame connected to the Wi-Fi?", "¿Está el marco conectado a la wifi?"),
    "Läuft unter {url} ({ms} ms).": ("Running at {url} ({ms} ms).", "Funciona en {url} ({ms} ms)."),
    "Mit Web Login und strenger Firewall muss der Port dort offen sein.": (
        "With Web Login and a strict firewall the port has to be allowed there.",
        "Con Web Login y cortafuegos estricto, el puerto debe estar permitido allí."),
    "Ton (Trommelwirbel, Applaus)": ("Sound (drum roll, applause)", "Sonido (redoble, aplausos)"),
    "Spielt über {player}.": ("Plays through {player}.", "Suena con {player}."),
    "Uhr auf dem Rahmen": ("Clock on the frame", "Reloj del marco"),
    "Heute ist der {date}.": ("Today is {date}.", "Hoy es {date}."),
    "Das Datum stimmt nicht; der Countdown wäre falsch.": (
        "The date is wrong; the countdown would be off.", "La fecha no es correcta; la cuenta atrás saldría mal."),
    "Die Uhr ist nicht mit dem Internet abgeglichen.": (
        "The clock is not synchronised with the internet.", "El reloj no está sincronizado con internet."),
    "Prüfung": ("Check", "Comprobación"),
    "Wichteln: wer mitmacht, der Countdown zur Bescherung und die Auflösung.": (
        "Secret Santa: who is in, the countdown to gift-giving and the reveal.",
        "Amigo invisible: quién participa, la cuenta atrás hasta la entrega y la revelación."),
    "Weil jemand entfernt wurde, ist die Auslosung zurückgenommen. Lose neu aus.": (
        "Because someone was removed, the draw was undone. Draw again.",
        "Como se ha quitado a alguien, el sorteo se ha deshecho. Vuelve a sortear."),
    "Wichteln {year}": ("Secret Santa {year}", "Amigo invisible {year}"),
    "Nicht alle konnten jemand anderen als letztes Jahr bekommen.": (
        "Not everyone could get someone other than last year.",
        "No todos han podido tocarle a alguien distinto del año pasado."),
    "Mit den Haushalten ging es nicht auf; einige beschenken jemanden aus dem eigenen Haushalt.": (
        "It did not work out with the households; some give to someone from their own household.",
        "Con los hogares no salía; a algunos les toca alguien de su propio hogar."),
    "Eine einzige große Kette ging nicht auf, darum gibt es mehrere kleine Kreise.": (
        "One single big chain did not work out, so there are several small circles.",
        "Una sola cadena grande no salía, así que hay varios círculos pequeños."),
}


def t(lang, template, **values):
    row = _TEXTS.get(template)
    text = template
    if row and lang in LANGUAGES[1:]:
        text = row[LANGUAGES.index(lang) - 1] or template
    for key, value in values.items():
        text = text.replace("{" + key + "}", str(value))
    return text
