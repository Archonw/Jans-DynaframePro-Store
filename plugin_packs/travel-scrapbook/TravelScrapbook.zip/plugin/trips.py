"""Reisen in den eigenen Fotos finden (reines Python, keine Abhängigkeiten).

Eingabe sind Fotos als dicts mit mindestens
- k:   Schlüssel des Fotos (beliebig, eindeutig),
- t:   Aufnahmezeit "YYYY-MM-DDTHH:MM:SS" (Ortszeit),
- lat, lon: GPS oder None,
optional stars (0-5), fav (bool), place (Ortsname).

- find_home(rows): der Wohnort = der Ort, an dem an den meisten verschiedenen
  Tagen fotografiert wurde (0,1°-Raster, dann Mittel der Fotos dort).
- find_trips(rows, home, ...): Reisen = mehrere Tage am Stück weit weg von zu
  Hause. Ein Tag ist "weg", wenn ein Foto mit GPS weiter als min_km vom
  Wohnort entfernt ist, "zu Hause", wenn alle Fotos mit GPS nah dran sind.
  Tage ohne GPS-Fotos und kurze Lücken (max_gap Tage) unterbrechen eine Reise
  nicht, ein Tag zu Hause schon.
- pick_photos(rows, n, ...): die Abzüge für eine Reise: Sterne zuerst, dann
  Favoriten, über die Tage verteilt, keine Serienbilder.

- find_homes(rows): Wohnorte je Jahr (Umzüge), find_trips nimmt auch diese Liste.

Gemeinsam genutzt von Reise-Scrapbook und Leben als U-Bahn-Plan.
"""

import datetime
import math
import random

EARTH_KM = 6371.0088
BURST_SECONDS = 900


def haversine(lat1, lon1, lat2, lon2):
    """Entfernung in km auf der Kugel."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * EARTH_KM * math.asin(min(1.0, math.sqrt(a)))


def _located(row):
    return row.get("lat") is not None and row.get("lon") is not None


def _date(text):
    try:
        return datetime.date(int(text[:4]), int(text[5:7]), int(text[8:10]))
    except (TypeError, ValueError):
        return None


def _seconds(text):
    try:
        return int(text[11:13]) * 3600 + int(text[14:16]) * 60 + int(text[17:19] or 0)
    except (TypeError, ValueError):
        return 43200


def _median(values):
    values = sorted(values)
    if not values:
        return None
    mid = len(values) // 2
    return values[mid] if len(values) % 2 else (values[mid - 1] + values[mid]) / 2


def _cell(lat, lon, step):
    return (math.floor(lat / step), math.floor(lon / step))


# --------------------------------------------------------------------------
# Wohnort
# --------------------------------------------------------------------------

def find_home(rows, step=0.1):
    """{"lat", "lon", "share", "days", "photos"} oder None (keine Fotos mit GPS).

    Gezählt werden verschiedene Tage je Rasterfeld, nicht Fotos: ein Urlaub
    mit 2000 Fotos soll den Wohnort nicht überstimmen. Nachbarfelder zählen
    mit, damit ein Wohnort auf einer Feldgrenze nicht zerfällt."""
    days_by_cell, photos_by_cell = {}, {}
    all_days = set()
    for row in rows:
        if not _located(row) or len(row.get("t") or "") < 10:
            continue
        cell = _cell(row["lat"], row["lon"], step)
        day = row["t"][:10]
        days_by_cell.setdefault(cell, set()).add(day)
        photos_by_cell.setdefault(cell, []).append((row["lat"], row["lon"]))
        all_days.add(day)
    if not days_by_cell:
        return None

    def around(cell):
        out = set()
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                out |= days_by_cell.get((cell[0] + dy, cell[1] + dx), set())
        return out

    best = max(days_by_cell, key=lambda c: (len(around(c)), len(days_by_cell[c]), len(photos_by_cell[c])))
    points = []
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            points += photos_by_cell.get((best[0] + dy, best[1] + dx), [])
    # Mittelpunkt: Median der Fotos im Kernfeld (robust gegen Ausreißer am Rand)
    core = photos_by_cell[best]
    lat = _median([p[0] for p in core])
    lon = _median([p[1] for p in core])
    days = around(best)
    return {"lat": round(lat, 4), "lon": round(lon, 4), "share": round(len(days) / max(1, len(all_days)), 3),
            "days": len(days), "photos": len(points)}


# --------------------------------------------------------------------------
# Reisen
# --------------------------------------------------------------------------

def _compress(points, merge_km=2.0):
    """Zeitlich sortierte Punkte (lat, lon, t): nahe Folgepunkte zusammenlegen."""
    out = []
    for point in points:
        if out and haversine(out[-1][0], out[-1][1], point[0], point[1]) < merge_km:
            continue
        out.append(point)
    return out


def _simplify(points, limit):
    """Höchstens limit Punkte, Anfang und Ende bleiben (gleichmäßig ausdünnen)."""
    if len(points) <= limit:
        return points
    step = (len(points) - 1) / (limit - 1)
    return [points[round(i * step)] for i in range(limit)]


def _path_km(points):
    return sum(haversine(a[0], a[1], b[0], b[1]) for a, b in zip(points, points[1:]))


def _places(rows, home, min_km, limit=5):
    """Die meistfotografierten Orte der Reise (0,05°-Raster, mind. 15 km auseinander)."""
    cells = {}
    for row in rows:
        if not _located(row):
            continue
        if home and haversine(home["lat"], home["lon"], row["lat"], row["lon"]) < min_km:
            continue
        cell = _cell(row["lat"], row["lon"], 0.05)
        entry = cells.setdefault(cell, {"n": 0, "lats": [], "lons": [], "days": set(), "names": {}})
        entry["n"] += 1
        entry["lats"].append(row["lat"])
        entry["lons"].append(row["lon"])
        entry["days"].add(row["t"][:10])
        if row.get("place"):
            entry["names"][row["place"]] = entry["names"].get(row["place"], 0) + 1
    ranked = sorted(cells.values(), key=lambda e: (len(e["days"]), e["n"]), reverse=True)
    out = []
    for entry in ranked:
        lat, lon = _median(entry["lats"]), _median(entry["lons"])
        if any(haversine(lat, lon, o["lat"], o["lon"]) < 15 for o in out):
            near = min(out, key=lambda o: haversine(lat, lon, o["lat"], o["lon"]))
            near["photos"] += entry["n"]
            near["days"] = sorted(set(near["days"]) | entry["days"])
            continue
        name = max(entry["names"], key=entry["names"].get) if entry["names"] else ""
        out.append({"lat": round(lat, 4), "lon": round(lon, 4), "photos": entry["n"],
                    "days": sorted(entry["days"]), "place": name})
        if len(out) >= limit:
            break
    out.sort(key=lambda o: (len(o["days"]), o["photos"]), reverse=True)
    return out


def find_homes(rows, step=0.1, merge_km=30, min_days=20):
    """Wohnorte über die Jahre (für Umzüge): je Kalenderjahr find_home(), Jahre
    mit weniger als min_days Fototagen erben den Nachbarn, gleiche Orte (unter
    merge_km) werden zusammengelegt. Liste von {"from", "to" (Jahre), "lat", "lon", ...}."""
    by_year = {}
    for row in rows:
        if _located(row) and len(row.get("t") or "") >= 10:
            by_year.setdefault(int(row["t"][:4]), []).append(row)
    periods = []
    for year in sorted(by_year):
        found = find_home(by_year[year], step)
        if not found or found["days"] < min_days:
            continue
        if periods and haversine(periods[-1]["lat"], periods[-1]["lon"], found["lat"], found["lon"]) < merge_km:
            periods[-1]["to"] = year
            continue
        periods.append(dict(found, **{"from": year, "to": year}))
    if not periods:
        overall = find_home(rows, step)
        return [dict(overall, **{"from": 1900, "to": 2200})] if overall else []
    periods[0]["from"] = 1900
    periods[-1]["to"] = 2200
    for a, b in zip(periods, periods[1:]):
        a["to"] = b["from"] - 1
    return periods


def home_at(home, day):
    """Der Wohnort an einem Tag: home ist ein dict (ein Wohnort) oder eine Liste aus find_homes()."""
    if isinstance(home, dict) or not home:
        return home
    year = day.year if hasattr(day, "year") else int(str(day)[:4])
    for period in home:
        if period["from"] <= year <= period["to"]:
            return period
    return home[-1]


def find_trips(rows, home, min_km=50, min_days=2, max_gap=2, min_photos=10, max_days=90, route_points=160):
    """Reisen, älteste zuerst.

    Jede Reise: {"id", "start", "end", "days", "nights", "rows" (alle Fotos
    der Reise, zeitlich sortiert), "located", "route" ([lat, lon] zeitlich, ausgedünnt),
    "dayPoints" ([{date, lat, lon, photos}]), "km" (Strecke inkl. Hin- und
    Rückweg von zu Hause), "farKm" (weiteste Entfernung von zu Hause),
    "bbox" [south, west, north, east], "places" (meistfotografierte Orte),
    "home" (der Wohnort zu der Zeit)}.

    home: ein Wohnort (find_home) oder Wohnorte über die Jahre (find_homes).
    Die Zeilen werden unverändert durchgereicht (auch Zusatzfelder)."""
    if not home:
        return []
    by_day = {}
    near = lambda h, r: haversine(h["lat"], h["lon"], r["lat"], r["lon"]) < min_km  # noqa: E731
    for row in rows:
        day = _date(row.get("t") or "")
        if day is None:
            continue
        by_day.setdefault(day, []).append(row)

    state = {}
    for day, day_rows in by_day.items():
        located = [r for r in day_rows if _located(r)]
        if not located:
            continue
        here = home_at(home, day)
        state[day] = "home" if all(near(here, r) for r in located) else "away"

    trips, current = [], None
    for day in sorted(state):
        if state[day] == "home":
            if current:
                trips.append(current)
                current = None
            continue
        if current and (day - current[-1]).days <= max_gap + 1:
            current.append(day)
        else:
            if current:
                trips.append(current)
            current = [day]
    if current:
        trips.append(current)

    out = []
    for away_days in trips:
        start, end = away_days[0], away_days[-1]
        days = (end - start).days + 1
        if days < min_days or days > max_days:
            continue
        here = home_at(home, start)
        trip_rows = []
        for offset in range(days):
            day = start + datetime.timedelta(days=offset)
            for row in by_day.get(day, []):
                if _located(row) and near(here, row):
                    continue        # Abfahrt/Ankunft noch zu Hause fotografiert
                trip_rows.append(row)
        if len(trip_rows) < min_photos:
            continue
        trip_rows.sort(key=lambda r: r["t"])
        trip = _describe(trip_rows, start, end, here, min_km, route_points)
        trip["home"] = {"lat": here["lat"], "lon": here["lon"]}
        out.append(trip)
    return out


def _describe(trip_rows, start, end, home, min_km, route_points):
    located = [r for r in trip_rows if _located(r)]
    points = _compress([(r["lat"], r["lon"], r["t"]) for r in located])
    km = _path_km(points)
    if points:
        km += haversine(home["lat"], home["lon"], points[0][0], points[0][1])
        km += haversine(points[-1][0], points[-1][1], home["lat"], home["lon"])
    far = max((haversine(home["lat"], home["lon"], r["lat"], r["lon"]) for r in located), default=0.0)
    day_points = []
    for offset in range((end - start).days + 1):
        day = (start + datetime.timedelta(days=offset)).isoformat()
        mine = [r for r in located if r["t"][:10] == day]
        count = sum(1 for r in trip_rows if r["t"][:10] == day)
        entry = {"date": day, "photos": count, "lat": None, "lon": None}
        if mine:
            entry["lat"] = round(_median([r["lat"] for r in mine]), 4)
            entry["lon"] = round(_median([r["lon"] for r in mine]), 4)
        day_points.append(entry)
    lats = [p[0] for p in points] or [home["lat"]]
    lons = [p[1] for p in points] or [home["lon"]]
    return {
        "id": start.isoformat(),
        "start": start.isoformat(),
        "end": end.isoformat(),
        "days": (end - start).days + 1,
        "nights": (end - start).days,
        "rows": trip_rows,
        "located": len(located),
        "route": [[round(p[0], 4), round(p[1], 4)] for p in _simplify(points, route_points)],
        "dayPoints": day_points,
        "km": round(km),
        "farKm": round(far),
        "bbox": [round(min(lats), 4), round(min(lons), 4), round(max(lats), 4), round(max(lons), 4)],
        "places": _places(trip_rows, home, min_km),
    }


# --------------------------------------------------------------------------
# Abzüge auswählen
# --------------------------------------------------------------------------

def pick_photos(rows, count, min_stars=0, seed=""):
    """Bis zu count Fotos: die meisten Sterne zuerst, dann Favoriten; bei
    gleichen Sternen bevorzugt Tage, die noch kein Foto haben; keine zwei
    Fotos binnen 15 Minuten (Serien). Ergebnis zeitlich sortiert; das erste
    gewählte (das beste) steht in "best"."""
    rnd = random.Random(str(seed))
    pool = [dict(r, _r=rnd.random()) for r in rows if int(r.get("stars") or 0) >= min_stars]
    chosen, per_day = [], {}
    while pool and len(chosen) < count:
        def key(row):
            day = row["t"][:10]
            burst = any(c["t"][:10] == day and abs(_seconds(c["t"]) - _seconds(row["t"])) < BURST_SECONDS
                        for c in chosen)
            return (burst, -int(row.get("stars") or 0), not row.get("fav"), per_day.get(day, 0),
                    not _located(row), row["_r"])
        best = min(pool, key=key)
        pool.remove(best)
        chosen.append(best)
        per_day[best["t"][:10]] = per_day.get(best["t"][:10], 0) + 1
    best_key = chosen[0]["k"] if chosen else None
    for row in chosen:
        row.pop("_r", None)
    chosen.sort(key=lambda r: r["t"])
    return {"photos": chosen, "best": best_key}
