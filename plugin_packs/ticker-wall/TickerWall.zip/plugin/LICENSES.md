# Third-party notes

- Fonts in the scene: Barlow Condensed (Copyright 2017 The Barlow Project Authors) and JetBrains Mono (Copyright 2020 The JetBrains Mono Project Authors), both SIL Open Font License 1.1. Licence texts in dynamic/fonts.
- Market data from Finnhub (with the owner's key), CoinGecko, the European Central Bank via Frankfurter; weather from Open-Meteo (CC BY 4.0); earthquakes from the USGS (public domain). News headlines belong to their publishers and are shown with a link to the source feed only.
- Ticker Wall is not affiliated with any of these services or news outlets and uses no logos.
