# Third-party notes

- Emoji graphics from Twemoji (`phone/emoji/`, and a copy in the scene `dynamic/emoji/`), © Twitter, Inc. and other contributors, licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Taken unchanged from the npm package @twemoji/svg 15.0.0 (jdecked/twemoji).
- QR Code Generator for JavaScript (`phone/qrcode.js`, and a copy in the scene), © 2009 Kazuhiko Arase, MIT licence. The word "QR Code" is a registered trademark of DENSO WAVE INCORPORATED.
- The scene bundles the fonts Fraunces and Inter under the SIL Open Font License 1.1 (see `dynamic/fonts/OFL-*.txt`).
- Images are read with Pillow (HPND licence) and pillow-heif (BSD-3-Clause), installed from PyPI.
