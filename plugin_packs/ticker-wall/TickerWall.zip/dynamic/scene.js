/* Ticker Wall - the scene.
 *
 * A news-channel / trading-floor wall: world clocks, a stock tape, market
 * tiles that flip through the watchlist, the lead stories, topic radar, news
 * pace, a newswire, crypto and three crawls at the bottom. The data comes
 * from the Ticker Wall plugin via the WebUI proxy (same origin on port 80,
 * else :8003). ?plugin=<url> points it elsewhere (local tests), ?look=,
 * ?lang= override the settings.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "TickerWall";
  const POLL_MS = 15000;
  const LEAD_MS = 12000;
  const PAGE_MS = 9000;
  const FLASH_MS = 9000;
  const BAND_MS = 5 * 60 * 1000;
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const sameOrigin = (location.protocol === "http:" && (location.port === "" || location.port === "80"))
    || (location.protocol === "https:" && (location.port === "" || location.port === "443"));
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set(sameOrigin ? [
    `${location.origin}${advanced}`,
    `${location.protocol}//${location.hostname}:8003${advanced}`
  ] : [
    `${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`,
    `http://${location.hostname || "localhost"}${advanced}`
  ])];
  let baseIndex = 0;

  const el = (id) => document.getElementById(id);
  const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const TEXT = {
    de: {
      markets: "Märkte", topStory: "Top-Thema", radar: "Themen-Radar", pace: "Nachrichtenlage", wire: "Newsticker", crypto: "Krypto",
      sources: "{n} Quellen", source1: "1 Quelle", page: "Seite {a}/{b}", mood: "Marktstimmung", winners: "Gewinner", losers: "Verlierer",
      panic: "Panik", fear: "Angst", neutral: "Neutral", greed: "Gier", euphoria: "Euphorie",
      calm: "Ruhig", normal: "Normal", busy: "Lebhaft", hectic: "Hektisch",
      paceNote: "{n} Meldungen in der letzten Stunde · üblich {m}", ago: "vor {n} Min.", agoH: "vor {n} Std.", now: "gerade eben",
      fresh: "Neu", newTopic: "NEU", headlines: "{n} Meldungen", news: "NEWS", breaking: "EILMELDUNG",
      quake: "Erdbeben", weather: "Wetter", topicOfHour: "Thema der Stunde", feeds: "{a} von {b} Feeds aktiv",
      loading: "Die Ticker Wall lädt …", unreachable: "Das Plugin Ticker Wall antwortet gerade nicht.", login: "Web Login ist aktiv: Bitte die Rahmen-Seite über https öffnen und anmelden, dann neu laden.",
      empty: "Noch keine Daten. Die ersten Feeds und Kurse kommen gleich.", closed: "geschl.", fx: "Devisen", commodity: "Rohstoffe",
      sky: { clear: "☀", cloudy: "⛅", overcast: "☁", fog: "🌫", drizzle: "🌦", rain: "🌧", snow: "❄", storm: "⛈" }
    },
    en: {
      markets: "Markets", topStory: "Top story", radar: "Topic radar", pace: "News pace", wire: "Newswire", crypto: "Crypto",
      sources: "{n} sources", source1: "1 source", page: "Page {a}/{b}", mood: "Market mood", winners: "Gainers", losers: "Losers",
      panic: "Panic", fear: "Fear", neutral: "Neutral", greed: "Greed", euphoria: "Euphoria",
      calm: "Calm", normal: "Normal", busy: "Busy", hectic: "Hectic",
      paceNote: "{n} stories in the last hour · usual {m}", ago: "{n} min ago", agoH: "{n} h ago", now: "just now",
      fresh: "New", newTopic: "NEW", headlines: "{n} stories", news: "NEWS", breaking: "BREAKING",
      quake: "Earthquake", weather: "Weather", topicOfHour: "Topic of the hour", feeds: "{a} of {b} feeds live",
      loading: "Ticker Wall is loading …", unreachable: "The Ticker Wall plugin is not answering right now.", login: "Web Login is on: open the frame page via https, sign in, then reload.",
      empty: "No data yet. The first feeds and prices are on their way.", closed: "closed", fx: "Currencies", commodity: "Commodities",
      sky: { clear: "☀", cloudy: "⛅", overcast: "☁", fog: "🌫", drizzle: "🌦", rain: "🌧", snow: "❄", storm: "⛈" }
    },
    es: {
      markets: "Mercados", topStory: "Noticia principal", radar: "Radar de temas", pace: "Ritmo informativo", wire: "Teletipo", crypto: "Cripto",
      sources: "{n} fuentes", source1: "1 fuente", page: "Página {a}/{b}", mood: "Ánimo del mercado", winners: "Suben", losers: "Bajan",
      panic: "Pánico", fear: "Miedo", neutral: "Neutral", greed: "Codicia", euphoria: "Euforia",
      calm: "Tranquilo", normal: "Normal", busy: "Animado", hectic: "Frenético",
      paceNote: "{n} noticias en la última hora · lo normal {m}", ago: "hace {n} min", agoH: "hace {n} h", now: "ahora mismo",
      fresh: "Nuevo", newTopic: "NUEVO", headlines: "{n} noticias", news: "NOTICIAS", breaking: "ÚLTIMA HORA",
      quake: "Terremoto", weather: "Tiempo", topicOfHour: "Tema de la hora", feeds: "{a} de {b} fuentes activas",
      loading: "Ticker Wall se está cargando …", unreachable: "El plugin Ticker Wall no responde ahora mismo.", login: "Web Login está activo: abre la página del marco por https, inicia sesión y recarga.",
      empty: "Aún no hay datos. Las primeras noticias y cotizaciones llegan enseguida.", closed: "cerrado", fx: "Divisas", commodity: "Materias primas",
      sky: { clear: "☀", cloudy: "⛅", overcast: "☁", fog: "🌫", drizzle: "🌦", rain: "🌧", snow: "❄", storm: "⛈" }
    }
  };
  const LOCALE = { de: "de-DE", en: "en-US", es: "es-ES" };

  let data = null;
  let lang = params.get("lang") || "en";
  let readySent = false;
  let portrait = false;
  let leadIndex = 0;
  let leadTimer = null;
  let pageIndex = 0;
  let pageTimer = null;
  let flashKey = "";
  let flashTimer = null;

  const T = (key, vars) => {
    let text = (TEXT[lang] || TEXT.en)[key] ?? TEXT.en[key] ?? key;
    if (vars) for (const [k, v] of Object.entries(vars)) text = text.replace(`{${k}}`, v);
    return text;
  };

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* browser preview */ }
  }

  // ---- Layout -------------------------------------------------------------
  function fit() {
    const w = window.innerWidth, h = window.innerHeight;
    const wasPortrait = portrait;
    portrait = h > w * 1.05;
    document.body.classList.toggle("portrait", portrait);
    const sw = portrait ? 1080 : 1920, sh = portrait ? 1920 : 1080;
    const scale = Math.min(w / sw, h / sh);
    const stage = el("stage");
    stage.style.transform = `translate(${(w - sw * scale) / 2}px, ${(h - sh * scale) / 2}px) scale(${scale})`;
    if (wasPortrait !== portrait && data) render(true);
  }
  window.addEventListener("resize", fit);

  function applyLook() {
    let look = params.get("look") || data?.look || "news";
    if (look === "auto") look = Math.floor(Date.now() / 600000) % 2 ? "terminal" : "news";
    document.body.classList.toggle("look-news", look === "news");
    document.body.classList.toggle("look-terminal", look === "terminal");
    document.querySelectorAll("[data-t]").forEach((node) => { node.textContent = T(node.dataset.t); });
  }

  // ---- Formatting ------------------------------------------------------
  const nf = {};
  function num(value, digits) {
    if (value == null || Number.isNaN(value)) return "–";
    const key = `${lang}:${digits}`;
    nf[key] ||= new Intl.NumberFormat(LOCALE[lang] || "en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits });
    return nf[key].format(value);
  }
  function price(q) {
    const v = q.price;
    if (v == null) return "–";
    const digits = q.kind === "fx" ? (v < 20 ? 4 : 2) : v >= 10000 ? 0 : v >= 1000 ? 1 : v < 1 ? 4 : 2;
    return num(v, digits);
  }
  function pct(v) {
    if (v == null) return "";
    return `${v > 0 ? "+" : v < 0 ? "−" : "±"}${num(Math.abs(v), 2)} %`;
  }
  const dir = (v) => (v == null || Math.abs(v) < 0.005 ? "flat" : v > 0 ? "up" : "down");
  const arrow = (v) => (v == null || Math.abs(v) < 0.005 ? "▪" : v > 0 ? "▲" : "▼");
  function ago(at) {
    const min = Math.max(0, Math.round((Date.now() / 1000 - at) / 60));
    if (min < 1) return T("now");
    if (min < 60) return T("ago", { n: min });
    return T("agoH", { n: Math.round(min / 60) });
  }
  function hhmm(at) {
    return new Date(at * 1000).toLocaleTimeString(LOCALE[lang] || "en-US", { hour: "2-digit", minute: "2-digit" });
  }

  function spark(values, cls, w = 100, h = 30, fill = true) {
    if (!values || values.length < 2) return "";
    const min = Math.min(...values), max = Math.max(...values), span = max - min || 1;
    const pts = values.map((v, i) => `${(i / (values.length - 1) * w).toFixed(1)},${(h - 2 - (v - min) / span * (h - 4)).toFixed(1)}`);
    const color = cls === "up" ? "var(--up)" : cls === "down" ? "var(--down)" : "var(--muted)";
    const area = fill ? `<path d="M0,${h} L${pts.join(" L")} L${w},${h} Z" fill="${color}" opacity=".16"/>` : "";
    return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">${area}<polyline points="${pts.join(" ")}" fill="none" stroke="${color}" stroke-width="1.6" vector-effect="non-scaling-stroke"/></svg>`;
  }

  // ---- Tickers -----------------------------------------------------------
  // Content is doubled and moves by half its width; new content swaps in at
  // the end of a run so nothing jumps.
  const tickers = new Map();
  function setTicker(container, html, pxPerSec) {
    const move = container.querySelector(".ticker-move");
    const state = tickers.get(container) || { html: "", pending: null };
    tickers.set(container, state);
    if (state.html === html) return;
    const apply = () => {
      state.html = html;
      state.pending = null;
      move.innerHTML = `<span>${html}</span><span>${html}</span>`;
      requestAnimationFrame(() => {
        const half = move.scrollWidth / 2;
        const speed = pxPerSec * ((data?.speed || 100) / 100);
        move.style.setProperty("--dur", `${Math.max(8, half / speed)}s`);
        move.style.animation = "none";
        void move.offsetWidth;
        move.style.animation = "";
      });
    };
    if (!state.html) { apply(); return; }
    if (!state.pending) {
      state.pending = true;
      move.addEventListener("animationiteration", () => apply(), { once: true });
    }
  }

  // ---- Pieces -----------------------------------------------------------
  function renderClocks() {
    const clocks = data?.clocks || [];
    const sky = T("sky");
    el("clocks").innerHTML = clocks.map((c, i) => `<div class="clock" data-i="${i}"><span class="city">${esc(c.name)}</span>
      <span><span class="time" data-tz="${esc(c.tz)}">--:--</span>${c.temp != null ? `<span class="wx">${sky[c.sky] || ""} ${c.temp}°</span>` : ""}</span></div>`).join("");
    tickClock();
  }

  function tickClock() {
    const now = new Date();
    const loc = LOCALE[lang] || "en-US";
    el("nowTime").textContent = now.toLocaleTimeString(loc, { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    el("nowDate").textContent = now.toLocaleDateString(loc, { weekday: "short", day: "numeric", month: "short", year: "numeric" });
    document.querySelectorAll(".clock .time").forEach((node) => {
      try {
        node.textContent = now.toLocaleTimeString(loc, { hour: "2-digit", minute: "2-digit", timeZone: node.dataset.tz });
      } catch (_) { node.textContent = "--:--"; }
    });
  }

  function quoteSpan(q, withName) {
    const d = dir(q.pct);
    return `<span class="q"><span class="s">${esc(withName ? q.name : shortName(q))}</span><span class="p">${price(q)}</span>` +
      `<span class="c ${d}">${arrow(q.pct)} ${pct(q.pct)}</span></span>`;
  }
  function shortName(q) {
    if (q.kind === "stock") return q.symbol.replace(/\.[A-Z]+$/, "");
    if (q.kind === "crypto") return q.symbol;
    return q.name || q.symbol;
  }

  function renderTape() {
    let rows = (data.markets || []).filter((q) => q.kind === "index" || q.kind === "stock");
    if (!rows.length) rows = data.crypto || [];
    setTicker(el("tape"), rows.map((q) => quoteSpan(q, q.kind === "index")).join(""), 95);
  }

  function tilesPerPage() { return portrait ? 8 : 12; }
  function tileRows() {
    const markets = data.markets || [];
    // Without stock prices (no key yet) the tiles show crypto instead of staying empty.
    return markets.some((q) => q.kind !== "fx") ? markets : markets.concat(data.crypto || []);
  }

  function renderTiles(flip) {
    const rows = tileRows();
    const per = tilesPerPage();
    const pages = Math.max(1, Math.ceil(rows.length / per));
    pageIndex %= pages;
    const slice = rows.slice(pageIndex * per, pageIndex * per + per);
    el("marketsPage").textContent = pages > 1 ? T("page", { a: pageIndex + 1, b: pages }) : "";
    el("tiles").innerHTML = slice.map((q, i) => {
      const d = dir(q.pct);
      return `<div class="tile ${d}${flip ? " flip" : ""}" style="animation-delay:${i * 60}ms">
        <span class="badge">${q.open === false && q.kind !== "fx" && q.kind !== "crypto" ? esc(T("closed")) : esc(q.currency || "")}</span>
        <span class="n">${esc(q.name)}</span><span class="p">${price(q)}</span>
        <span class="c ${d}">${arrow(q.pct)} ${pct(q.pct)}</span>${spark(q.curve, d)}</div>`;
    }).join("");
  }

  function renderMood() {
    const m = data.mood;
    if (!m) { el("mood").innerHTML = ""; return; }
    const angle = -90 + m.score * 1.8;
    const segs = ["#d62839", "#f28c28", "#9aa5b1", "#7bc950", "#1fbf5f"].map((c, i) => {
      const a0 = Math.PI * (1 - i / 5), a1 = Math.PI * (1 - (i + 1) / 5);
      const p = (a, r) => `${(105 + r * Math.cos(a)).toFixed(1)},${(105 - r * Math.sin(a)).toFixed(1)}`;
      return `<path d="M${p(a0, 92)} A92,92 0 0 1 ${p(a1, 92)} L${p(a1, 70)} A70,70 0 0 0 ${p(a0, 70)} Z" fill="${c}" opacity=".85"/>`;
    }).join("");
    el("mood").innerHTML = `<div class="title">${esc(T("mood"))}</div><svg viewBox="0 0 210 112">${segs}
      <g style="transform-origin:105px 105px;transform:rotate(${angle}deg);transition:transform 1.5s"><line x1="105" y1="105" x2="105" y2="28" stroke="var(--ink)" stroke-width="4" stroke-linecap="round"/></g>
      <circle cx="105" cy="105" r="8" fill="var(--ink)"/></svg>
      <div class="score">${m.score}</div><div class="label">${esc(T(m.label))}</div>`;
    const mv = data.movers || { up: [], down: [] };
    const col = (title, rows) => `<div class="col"><h3>${esc(title)}</h3>${rows.map((q) =>
      `<div class="mv"><span>${esc(q.kind === "crypto" ? q.symbol : q.name)}</span><b class="${dir(q.pct)}">${pct(q.pct)}</b></div>`).join("")}</div>`;
    el("movers").innerHTML = col(T("winners"), mv.up.slice(0, 4)) + col(T("losers"), mv.down.slice(0, 4));
  }

  function renderLead(swap) {
    const leads = data.leads || [];
    const lead = el("lead");
    if (!leads.length) return;
    leadIndex %= leads.length;
    const item = leads[leadIndex];
    const img = el("leadImg");
    const showImage = data.images !== false && item.image;
    img.className = "lead-img" + (showImage ? "" : " none");
    img.style.backgroundImage = showImage ? `url("${item.image.replace(/"/g, "%22")}")` : "";
    img.style.animation = "none"; void img.offsetWidth; img.style.animation = "";
    el("leadTopic").textContent = item.topic || "";
    el("leadSources").textContent = item.sources > 1 ? T("sources", { n: item.sources }) : esc(item.source);
    el("leadTitle").textContent = item.title;
    el("leadSummary").textContent = item.summary && item.summary.toLowerCase().indexOf(item.title.toLowerCase().slice(0, 30)) !== 0 ? item.summary : "";
    el("leadMeta").textContent = `${item.source} · ${hhmm(item.at)} · ${ago(item.at)}`;
    el("leadDots").innerHTML = leads.map((_, i) => `<i class="${i === leadIndex ? "on" : ""}"></i>`).join("");
    lead.style.setProperty("--lead-ms", `${LEAD_MS}ms`);
    if (swap) { lead.classList.remove("swap"); void lead.offsetWidth; lead.classList.add("swap"); }
  }

  function renderRadar() {
    const rows = (data.radar || []).slice(0, portrait ? 8 : 10);
    el("radar").innerHTML = rows.map((r, i) => {
      const tr = r.trend === "new" ? `<span class="tr new">${esc(T("newTopic"))}</span>` :
        `<span class="tr ${r.trend}">${r.trend === "up" ? "▲" : r.trend === "down" ? "▼" : "▶"}</span>`;
      return `<li><span class="bar" style="width:${Math.round(25 + r.weight * 75)}%;animation-delay:${i * 70}ms"></span>
        <span class="t">${esc(r.term)}</span><span class="k">${r.sources}×</span>${tr}</li>`;
    }).join("");
  }

  function renderPace() {
    const p = data.pace;
    if (!p) return;
    el("paceLevel").textContent = T(p.level);
    el("paceLevel").className = `pace-level ${p.level}`;
    const max = Math.max(1, ...p.hours);
    el("paceBars").innerHTML = p.hours.map((h, i) => `<i style="height:${Math.max(3, h / max * 100)}%;animation-delay:${i * 25}ms"></i>`).join("");
    el("paceNote").textContent = T("paceNote", { n: p.lastHour, m: p.median });
    el("sources").innerHTML = (data.activity || []).slice(0, portrait ? 6 : 8).map((s) => `<span>${esc(s.source)}<b>${s.count}</b></span>`).join("");
  }

  function renderWire() {
    const items = (data.headlines || []).slice(0, 40);
    el("wireCount").textContent = T("headlines", { n: (data.headlines || []).length >= 70 ? "70+" : (data.headlines || []).length });
    const now = Date.now() / 1000;
    const html = items.map((h) => `<div class="w"><div class="m">${now - h.at < 1200 ? `<span class="fresh">${esc(T("fresh"))}</span>` : ""}
      <span>${hhmm(h.at)}</span><b>${esc(h.source)}</b></div><div class="h">${esc(h.title)}</div></div>`).join("");
    const list = el("wire");
    if (list.dataset.html === html) return;
    list.dataset.html = html;
    list.innerHTML = html + html;
    requestAnimationFrame(() => list.style.setProperty("--wire-dur", `${Math.max(30, list.scrollHeight / 2 / 28)}s`));
  }

  function renderCrypto() {
    const rows = (data.crypto || []).slice(0, portrait ? 9 : 7);
    el("crypto").innerHTML = rows.map((q) => {
      const d = dir(q.pct);
      return `<div class="cr"><span class="s">${esc(q.symbol)}</span><span class="p">${price(q)}</span>${spark(q.curve, d, 92, 26, false)}<span class="c ${d}">${pct(q.pct)}</span></div>`;
    }).join("");
    el("crypto").previousElementSibling.hidden = !rows.length;
  }

  function breakingNow() {
    const b = (data.breaking || []).filter((x) => Date.now() / 1000 - x.at < 3600);
    return b;
  }

  function renderCrawl() {
    const br = breakingNow();
    const label = el("crawlLabel");
    label.textContent = br.length ? T("breaking") : T("news");
    label.classList.toggle("breaking", br.length > 0);
    const seen = new Set();
    const rows = [];
    br.forEach((b) => { seen.add(b.title); rows.push(`<span class="h1"><small>${esc(b.term || b.source)}</small>${esc(b.title)}</span>`); });
    (data.headlines || []).slice(0, 30).forEach((h) => {
      if (seen.has(h.title)) return;
      rows.push(`<span class="h1"><small>${esc(h.source)}</small>${esc(h.title)}</span>`);
    });
    setTicker(el("crawl"), rows.join(""), 140);
  }

  function renderRow2() {
    const rest = (data.markets || []).filter((q) => q.kind === "fx" || q.kind === "commodity" || q.kind === "bond");
    const spans = (data.crypto || []).map((q) => quoteSpan(q, false)).concat(rest.map((q) => quoteSpan(q, true)));
    setTicker(el("row2"), spans.join(""), 80);
  }

  function renderRow3() {
    const parts = [];
    const sky = T("sky");
    const top = (data.radar || [])[0];
    if (top) parts.push(`<span class="i"><span class="tag">${esc(T("topicOfHour"))}</span><b>${esc(top.term)}</b> · ${esc(T("sources", { n: top.sources }))}</span>`);
    (data.clocks || []).filter((c) => c.temp != null).forEach((c) =>
      parts.push(`<span class="i"><span class="tag">${esc(T("weather"))}</span>${esc(c.name)} <b>${sky[c.sky] || ""} ${c.temp}°C</b></span>`));
    (data.quakes || []).slice(0, 6).forEach((q) =>
      parts.push(`<span class="i"><span class="tag">${esc(T("quake"))}</span><b>M${num(q.mag, 1)}</b> ${esc(q.place)} · ${hhmm(q.at)}</span>`));
    if (data.feeds) parts.push(`<span class="i"><span class="tag">RSS</span>${esc(T("feeds", { a: data.feeds.ok, b: data.feeds.total }))}</span>`);
    if (data.pace) parts.push(`<span class="i"><span class="tag">${esc(T("pace"))}</span><b>${esc(T(data.pace.level))}</b> · ${esc(T("paceNote", { n: data.pace.lastHour, m: data.pace.median }))}</span>`);
    setTicker(el("row3"), parts.join(""), 70);
  }

  // ---- Alerts -----------------------------------------------------------
  function currentAlert() {
    if (data.focus) return data.focus;
    const a = (data.alerts || [])[0];
    if (a && Date.now() - a.at * 1000 < BAND_MS) return a;
    return null;
  }

  function renderAlert() {
    const a = currentAlert();
    const band = el("alertBand");
    if (!a) { band.hidden = true; return; }
    band.hidden = false;
    el("alertLabel").textContent = a.label;
    el("alertTitle").textContent = a.title;
    el("alertDetail").textContent = [a.detail, a.source].filter(Boolean).join(" · ");
    if (data.focus && data.focus.key !== flashKey) {
      flashKey = data.focus.key;
      el("flashLabel").textContent = a.label;
      el("flashTitle").textContent = a.title;
      el("flashDetail").textContent = [a.detail, a.source].filter(Boolean).join(" · ");
      const flash = el("flash");
      flash.classList.remove("out");
      flash.hidden = false;
      clearTimeout(flashTimer);
      flashTimer = setTimeout(() => {
        flash.classList.add("out");
        setTimeout(() => { flash.hidden = true; }, 600);
      }, FLASH_MS);
    }
  }

  // ---- Main ---------------------------------------------------------------
  function render(full) {
    lang = params.get("lang") || data.lang || "en";
    document.documentElement.lang = lang;
    applyLook();
    const nothing = !(data.headlines || []).length && !(data.markets || []).length && !(data.crypto || []).length;
    message(nothing ? T("empty") : "");
    renderClocks();
    renderTape();
    renderTiles(false);
    renderMood();
    if (full || !leadTimer) renderLead(false);
    renderRadar();
    renderPace();
    renderWire();
    renderCrypto();
    renderCrawl();
    renderRow2();
    renderRow3();
    renderAlert();
    if (!leadTimer) leadTimer = setInterval(() => { leadIndex += 1; renderLead(true); }, LEAD_MS);
    if (!pageTimer) pageTimer = setInterval(() => { pageIndex += 1; renderTiles(true); }, PAGE_MS);
  }

  function message(text) {
    const box = el("message");
    box.hidden = !text;
    box.textContent = text;
  }

  async function poll() {
    let loginNeeded = false;
    for (let attempt = 0; attempt < pluginBases.length; attempt += 1) {
      const base = pluginBases[(baseIndex + attempt) % pluginBases.length];
      try {
        const response = await fetch(`${base}api/scene`, { cache: "no-store", credentials: "same-origin" });
        if (response.redirected && response.url.includes("/dfr-login/")) { loginNeeded = true; throw new Error("login"); }
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        data = await response.json();
        baseIndex = (baseIndex + attempt) % pluginBases.length;
        render(false);
        ready();
        return;
      } catch (_) { /* try the next way */ }
    }
    if (!data) {
      applyLook();
      message(T(loginNeeded ? "login" : "unreachable"));
      ready();
    }
  }

  fit();
  applyLook();
  message(T("loading"));
  setInterval(tickClock, 1000);
  setInterval(() => { if (data) applyLook(); }, 60000);
  poll();
  setInterval(poll, POLL_MS);
})();
