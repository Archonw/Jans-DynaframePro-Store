/* Growing Up - the scene.
 *
 * Plays the portraits the Growing Up plugin cut out of the owner's Immich
 * photos: a time-lapse in which the face grows up (crossfade, faces lined
 * up), a contact sheet of all periods, then and now, and several people at
 * the same age. The data comes from the plugin via the WebUI proxy (same
 * origin on port 80/443, else :8003). ?plugin=<url> points it elsewhere
 * (local tests), ?view=film|grid|thennow|sameage shows one view only.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "GrowingUp";
  const POLL_MS = 30000;
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const sameOrigin = (location.protocol === "http:" && (location.port === "" || location.port === "80")) ||
    (location.protocol === "https:" && (location.port === "" || location.port === "443"));
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set(sameOrigin ? [
    `${location.origin}${advanced}`,
    `${location.protocol}//${location.hostname}:8003${advanced}`
  ] : [
    `http://${location.hostname || "localhost"}:8003${advanced}`,
    `http://${location.hostname || "localhost"}${advanced}`
  ])];
  let baseIndex = 0;
  const onlyView = params.get("view") || "";

  const stage = document.getElementById("stage");
  const glow = document.getElementById("glow");

  let data = null;
  let readySent = false;
  let running = false;
  let lastError = "";

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* browser preview */ }
  }

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const TEXT = {
    de: {
      eyebrow: "Groß geworden", newborn: "Neugeboren", day: "{n} Tag", days: "{n} Tage", week: "{n} Woche", weeks: "{n} Wochen",
      month: "{n} Monat", months: "{n} Monate", year: "{n} Jahr", years: "{n} Jahre", ym: "{y}, {m}",
      shortM: "{n} M.", shortY: "{n} J.", count: "{i} / {n}", portraits: "{n} Porträts", span: "{from} – {to}",
      then: "Damals", now: "Heute", later: "später", between: "{n} Jahre", between1: "1 Jahr", betweenM: "{n} Monate",
      sameAge: "Im gleichen Alter", atMonths: "Mit {n} Monaten", atYear: "Mit einem Jahr", atYears: "Mit {n} Jahren", birthday: "Alles Gute zum Geburtstag, {name}!", birthdayAge: "Alles Gute zum {n}. Geburtstag, {name}!",
      loading: "Die Porträts werden geladen …", unreachable: "Das Plugin Growing Up antwortet gerade nicht.",
      setup: "Noch nicht eingerichtet", setupLong: "Öffne auf der Plugins-Seite „Open Growing Up“, verbinde deinen Immich-Server und wähle Personen aus.",
      pick: "Noch keine Person ausgewählt", pickLong: "Wähle auf der Seite „Open Growing Up“ aus, wessen Gesicht hier groß werden soll.",
      busy: "Die Porträts werden vorbereitet", busyLong: "Growing Up sucht in Immich die besten Gesichter heraus und schneidet sie aus."
    },
    en: {
      eyebrow: "Growing up", newborn: "Newborn", day: "{n} day", days: "{n} days", week: "{n} week", weeks: "{n} weeks",
      month: "{n} month", months: "{n} months", year: "{n} year", years: "{n} years", ym: "{y}, {m}",
      shortM: "{n} mo", shortY: "{n} y", count: "{i} / {n}", portraits: "{n} portraits", span: "{from} – {to}",
      then: "Then", now: "Now", later: "later", between: "{n} years", between1: "1 year", betweenM: "{n} months",
      sameAge: "At the same age", atMonths: "At {n} months", atYear: "At one year", atYears: "At {n} years", birthday: "Happy birthday, {name}!", birthdayAge: "Happy {n} birthday, {name}!",
      loading: "Loading the portraits …", unreachable: "The Growing Up plugin is not answering right now.",
      setup: "Not set up yet", setupLong: "On the Plugins page open “Open Growing Up”, connect your Immich server and pick people.",
      pick: "No person picked yet", pickLong: "On “Open Growing Up” pick whose face should grow up here.",
      busy: "Preparing the portraits", busyLong: "Growing Up is picking the best faces in Immich and cutting them out."
    },
    es: {
      eyebrow: "Creciendo", newborn: "Recién nacido", day: "{n} día", days: "{n} días", week: "{n} semana", weeks: "{n} semanas",
      month: "{n} mes", months: "{n} meses", year: "{n} año", years: "{n} años", ym: "{y} y {m}",
      shortM: "{n} m", shortY: "{n} a", count: "{i} / {n}", portraits: "{n} retratos", span: "{from} – {to}",
      then: "Antes", now: "Ahora", later: "después", between: "{n} años", between1: "1 año", betweenM: "{n} meses",
      sameAge: "A la misma edad", atMonths: "Con {n} meses", atYear: "Con un año", atYears: "Con {n} años", birthday: "¡Feliz cumpleaños, {name}!", birthdayAge: "¡Feliz {n}.º cumpleaños, {name}!",
      loading: "Cargando los retratos …", unreachable: "El plugin Growing Up no responde ahora mismo.",
      setup: "Aún sin configurar", setupLong: "En la página de plugins abre «Open Growing Up», conecta tu servidor Immich y elige personas.",
      pick: "Aún no hay ninguna persona", pickLong: "En «Open Growing Up» elige de quién es la cara que crecerá aquí.",
      busy: "Preparando los retratos", busyLong: "Growing Up está buscando las mejores caras en Immich y recortándolas."
    }
  };
  const LOCALE = { de: "de-DE", en: "en-GB", es: "es-ES" };
  let lang = "en";
  const t = (key, values = {}) => (TEXT[lang][key] ?? TEXT.en[key] ?? key).replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");
  const plural = (one, many, n) => t(n === 1 ? one : many, { n });

  function ageText(age) {
    if (!age) return "";
    const { months, days } = age;
    if (days < 1) return t("newborn");
    if (days < 14) return plural("day", "days", days);
    if (days < 61) return plural("week", "weeks", Math.floor(days / 7));
    if (months < 24) return plural("month", "months", months);
    const y = Math.floor(months / 12), m = months % 12;
    if (months < 72 && m) return t("ym", { y: plural("year", "years", y), m: plural("month", "months", m) });
    return plural("year", "years", y);
  }

  function ageShort(age) {
    if (!age) return "";
    if (age.months < 24) return t("shortM", { n: age.months });
    return t("shortY", { n: Math.floor(age.months / 12) });
  }

  function dateText(iso, style = "long") {
    const d = new Date(`${iso}T12:00:00`);
    if (Number.isNaN(d.getTime())) return iso;
    const opts = style === "year" ? { year: "numeric" } : style === "short" ? { month: "short", year: "numeric" } : { month: "long", year: "numeric" };
    return d.toLocaleDateString(LOCALE[lang], opts);
  }

  function yearsBetween(a, b) {
    const da = new Date(`${a}T12:00:00`), db = new Date(`${b}T12:00:00`);
    const months = (db.getFullYear() - da.getFullYear()) * 12 + db.getMonth() - da.getMonth() - (db.getDate() < da.getDate() ? 1 : 0);
    if (months < 12) return plural("betweenM", "betweenM", Math.max(months, 0));
    const y = Math.floor(months / 12);
    return y === 1 ? t("between1") : t("between", { n: y });
  }

  // ---- data -----------------------------------------------------------------

  async function load() {
    for (let i = 0; i < pluginBases.length; i++) {
      const index = (baseIndex + i) % pluginBases.length;
      try {
        const response = await fetch(`${pluginBases[index]}api/scene`, { cache: "no-store" });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const body = await response.json();
        baseIndex = index;
        lastError = "";
        return body;
      } catch (error) {
        lastError = String(error);
      }
    }
    return null;
  }

  const imageUrl = (src) => pluginBases[baseIndex] + src;
  const preloaded = new Map();
  function preload(frames, timeout = 9000) {
    const jobs = frames.map((f) => {
      const url = imageUrl(f.src);
      if (!preloaded.has(url)) {
        preloaded.set(url, new Promise((resolve) => {
          const img = new Image();
          img.onload = () => resolve(true);
          img.onerror = () => { preloaded.delete(url); resolve(false); };
          img.src = url;
        }));
      }
      return preloaded.get(url);
    });
    return Promise.race([Promise.all(jobs), sleep(timeout)]);
  }

  // ---- building blocks --------------------------------------------------------

  /* Line the face up: same size and place in every portrait. The picture
     always covers its box (never smaller than the box, never moved so far
     that an edge shows), so a face near a photo's edge sits a bit off. */
  function medianFace(frames) {
    const sizes = frames.map((f) => (f.face || [0, 0, 0.42])[2]).sort((a, b) => a - b);
    return sizes.length ? sizes[Math.floor(sizes.length / 2)] : 0.42;
  }

  function placeImage(img, frame, side, target) {
    const [fx, fy, fs] = frame.face || [0.5, 0.45, 0.42];
    const k = Math.max(1.04, Math.min(1.8, (target || fs) / Math.max(fs, 0.05)));
    const clamp = (v) => Math.min(0, Math.max(side - side * k, v));
    const tx = clamp((0.5 - fx * k) * side), ty = clamp((0.47 - fy * k) * side);
    img.style.width = `${side}px`;
    img.style.height = `${side}px`;
    img.style.transform = `translate(${tx.toFixed(1)}px, ${ty.toFixed(1)}px) scale(${k.toFixed(4)})`;
  }

  function photoBox(frame, side, target) {
    const box = document.createElement("div");
    box.className = "photo";
    box.style.width = `${side}px`;
    box.style.height = `${side}px`;
    const img = document.createElement("img");
    img.alt = "";
    img.decoding = "async";
    img.src = imageUrl(frame.src);
    placeImage(img, frame, side, target);
    box.appendChild(img);
    return box;
  }

  function setGlow(frame) {
    glow.style.setProperty("--glow-img", frame ? `url("${imageUrl(frame.src)}")` : "none");
  }

  function caption(frame) {
    const mode = data.captions;
    const age = frame.age ? ageText(frame.age) : "";
    const when = dateText(frame.date);
    if (mode === "none") return { big: "", small: "" };
    if (mode === "date" || !age) return { big: when, small: "" };
    if (mode === "age") return { big: age, small: "" };
    return { big: age, small: when };
  }

  async function showView(build, seconds) {
    const view = build();
    stage.appendChild(view.el);
    const old = [...stage.children].filter((c) => c !== view.el);
    await sleep(30);
    view.el.classList.add("on");
    ready();
    setTimeout(() => old.forEach((o) => o.remove()), 1000);
    if (view.run) await view.run();
    else await sleep(seconds * 1000);
  }

  function banner(person) {
    if (!person.birthday) return "";
    const age = person.birthDate ? Number(data.today.slice(0, 4)) - Number(person.birthDate.slice(0, 4)) : 0;
    const n = lang === "en" ? `${age}${ordinal(age)}` : String(age);
    const text = age > 0 ? t("birthdayAge", { n, name: person.name }) : t("birthday", { name: person.name });
    return `<div class="banner">${esc(text)}</div>`;
  }

  function ordinal(n) {
    const s = ["th", "st", "nd", "rd"], v = n % 100;
    return s[(v - 20) % 10] || s[v] || s[0];
  }

  // ---- the views ----------------------------------------------------------------

  function filmView(person) {
    const frames = person.frames;
    const el = document.createElement("section");
    el.className = "view film" + (person.birthday ? " has-banner" : "");
    const portrait = innerHeight > innerWidth;
    const side = Math.round(portrait ? Math.min(innerWidth * 0.84, innerHeight * 0.5) : Math.min(innerHeight * 0.64, innerWidth * 0.5));
    el.innerHTML = `${banner(person)}
      <div class="wrap">
        <div class="photo" style="width:${side}px;height:${side}px"></div>
        <div class="text">
          <p class="eyebrow">${esc(t("eyebrow"))}</p>
          <h1 class="name">${esc(person.name)}</h1>
          <p class="age"></p>
          <p class="when"></p>
          <p class="count"></p>
        </div>
      </div>
      <div class="timeline"><div class="rail"></div><div class="fill"></div><div class="now"></div></div>`;
    const box = el.querySelector(".photo");
    const target = medianFace(frames);
    const imgs = [document.createElement("img"), document.createElement("img")];
    imgs.forEach((img) => { img.alt = ""; box.appendChild(img); });
    const fadeMs = Math.max(0, data.fadeMs ?? 1500);
    const holdMs = Math.max(200, data.holdMs ?? 2000);
    imgs.forEach((img) => { img.style.transition = `opacity ${fadeMs}ms ease-in-out`; });

    // Time line: years and one dot per portrait.
    const line = el.querySelector(".timeline");
    const t0 = Date.parse(frames[0].date), t1 = Date.parse(frames[frames.length - 1].date);
    const pos = (iso) => (t1 > t0 ? (Date.parse(iso) - t0) / (t1 - t0) : 0.5) * 100;
    const y0 = Number(frames[0].date.slice(0, 4)), y1 = Number(frames[frames.length - 1].date.slice(0, 4));
    const every = Math.max(1, Math.ceil((y1 - y0 + 1) / 12));
    for (let y = y0 + 1; y <= y1; y++) {
      const p = pos(`${y}-01-01`);
      line.insertAdjacentHTML("beforeend", `<div class="tick" style="left:${p}%"></div>` +
        ((y - y0) % every === 0 ? `<div class="year" style="left:${p}%">${y}</div>` : ""));
    }
    if (y1 === y0) line.insertAdjacentHTML("beforeend", `<div class="year" style="left:50%">${y0}</div>`);
    const dots = frames.map((f) => {
      const dot = document.createElement("div");
      dot.className = "dot";
      dot.style.left = `${pos(f.date)}%`;
      line.insertBefore(dot, line.querySelector(".now"));
      return dot;
    });
    const fill = line.querySelector(".fill"), now = line.querySelector(".now");
    const ageEl = el.querySelector(".age"), whenEl = el.querySelector(".when"), countEl = el.querySelector(".count");

    function show(i, layer) {
      const frame = frames[i];
      const img = imgs[layer], other = imgs[1 - layer];
      img.src = imageUrl(frame.src);
      placeImage(img, frame, side, target);
      img.style.zIndex = 2;
      other.style.zIndex = 1;
      img.classList.add("on");
      setTimeout(() => other.classList.remove("on"), fadeMs);
      const cap = caption(frame);
      ageEl.textContent = cap.big;
      ageEl.classList.toggle("small", cap.big.length > 14);
      whenEl.textContent = cap.small;
      countEl.textContent = t("count", { i: i + 1, n: frames.length });
      fill.style.width = `${pos(frame.date)}%`;
      now.style.left = `${pos(frame.date)}%`;
      dots.forEach((d, k) => d.classList.toggle("done", k <= i));
      if (i % 4 === 0 || i === frames.length - 1) setGlow(frame);
    }

    return {
      el,
      run: async () => {
        await preload(frames);
        for (let i = 0; i < frames.length; i++) {
          show(i, i % 2);
          // Each portrait: the crossfade into it, then it stays fully visible.
          await sleep(i === 0 ? Math.max(holdMs, 2500) : fadeMs + holdMs);
        }
        await sleep(3200);
      }
    };
  }

  function gridView(person) {
    const frames = person.frames;
    const el = document.createElement("section");
    el.className = "view sheet";
    const first = frames[0].date, last = frames[frames.length - 1].date;
    el.innerHTML = `<header><h1 class="name">${esc(person.name)}</h1>
      <p class="sub">${esc(t("span", { from: dateText(first, "year"), to: dateText(last, "year") }))} · ${esc(t("portraits", { n: frames.length }))}</p></header>
      <div class="grid"></div>`;
    const u = Math.min(innerWidth / 100, innerHeight / 56.2);
    const width = innerWidth - u * 10, height = innerHeight - u * 8 - u * 7.5;
    const gap = u * 1.4;
    const capH = data.captions === "none" ? 0 : Math.max(12, u * 1.35) * 1.5;
    let best = { side: 0, cols: 1 };
    for (let cols = 1; cols <= frames.length; cols++) {
      const rows = Math.ceil(frames.length / cols);
      const side = Math.min((width - gap * (cols - 1)) / cols, (height - gap * (rows - 1)) / rows - capH);
      if (side > best.side) best = { side, cols };
    }
    const side = Math.floor(best.side);
    const grid = el.querySelector(".grid");
    grid.style.gridTemplateColumns = `repeat(${best.cols}, ${side}px)`;
    grid.style.setProperty("--cap", `${Math.max(11, Math.min(u * 1.35, side / 7))}px`);
    const step = Math.min(90, 2400 / frames.length);
    const target = medianFace(frames);
    frames.forEach((frame, i) => {
      const cell = document.createElement("div");
      cell.className = "cell";
      cell.style.animationDelay = `${300 + i * step}ms`;
      cell.appendChild(photoBox(frame, side, target));
      if (data.captions !== "none") {
        const cap = document.createElement("div");
        cap.className = "cap";
        const age = frame.age && data.captions !== "date" ? ageShort(frame.age) : "";
        const year = data.captions !== "age" || !age ? dateText(frame.date, "year") : "";
        cap.innerHTML = age && year ? `<b>${esc(age)}</b> · ${esc(year)}` : `<b>${esc(age || year)}</b>`;
        cell.appendChild(cap);
      }
      grid.appendChild(cell);
    });
    setGlow(frames[frames.length - 1]);
    return { el, run: async () => { await preload(frames, 5000); await sleep(data.viewSeconds * 1000); } };
  }

  const ARROW = `<svg viewBox="0 0 120 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h108M100 3l11 9-11 9"/></svg>`;

  function cardHtml(frame, label, meta, side, cls = "", delay = 0) {
    return `<div class="card" style="--side:${side}px;animation-delay:${delay}ms" data-src="${esc(frame.src)}">
      <div class="slot"></div><div class="label ${cls}">${esc(label)}</div><div class="meta">${esc(meta)}</div></div>`;
  }

  function fillSlots(el, frames, side) {
    const target = medianFace(frames);
    el.querySelectorAll(".card").forEach((card, i) => {
      card.querySelector(".slot").replaceWith(photoBox(frames[i], side, target));
    });
  }

  function thenNowView(person) {
    const frames = person.frames;
    const a = frames[0], b = frames[frames.length - 1];
    const el = document.createElement("section");
    el.className = "view pair";
    const portrait = innerHeight > innerWidth;
    const side = Math.round(portrait ? Math.min(innerWidth * 0.6, innerHeight * 0.24) : Math.min(innerHeight * 0.55, innerWidth * 0.3));
    const label = (f, word) => (f.age && data.captions !== "date" ? ageText(f.age) : word);
    const meta = (f, word) => (f.age && data.captions !== "date" ? `${word} · ${dateText(f.date)}` : dateText(f.date));
    el.innerHTML = `<p class="eyebrow">${esc(t("eyebrow"))}</p><h2>${esc(person.name)}</h2>
      <div class="row two">
        ${cardHtml(a, label(a, t("then")), meta(a, t("then")), side, "", 200)}
        <div class="between"><span class="years">${esc(yearsBetween(a.date, b.date))}</span><span class="later">${esc(t("later"))}</span>${ARROW}</div>
        ${cardHtml(b, label(b, t("now")), meta(b, t("now")), side, "", 1100)}
      </div>`;
    fillSlots(el, [a, b], side);
    setGlow(b);
    return { el, run: async () => { await preload([a, b], 5000); await sleep(data.viewSeconds * 1000); } };
  }

  function nearest(frames, months, tolerance) {
    let best = null;
    for (const f of frames) {
      if (!f.age) continue;
      const diff = Math.abs(f.age.months - months);
      if (diff <= tolerance && (!best || diff < best.diff)) best = { diff, f };
    }
    return best ? best.f : null;
  }

  function sameAgeView(people, months) {
    const tolerance = months < 24 ? 2 : months < 72 ? 4 : 7;
    const picks = people.map((p) => ({ p, f: nearest(p.frames, months, tolerance) })).filter((x) => x.f).slice(0, 4);
    const el = document.createElement("section");
    el.className = "view pair";
    const portrait = innerHeight > innerWidth;
    const n = picks.length;
    const side = Math.round(portrait
      ? Math.min(innerWidth * 0.4, innerHeight * (n > 2 ? 0.2 : 0.26))
      : Math.min(innerHeight * 0.5, (innerWidth * 0.84) / n - innerWidth * 0.03));
    const heading = months < 24 ? t("atMonths", { n: months }) : months === 12 ? t("atYear") : t("atYears", { n: months / 12 });
    el.innerHTML = `<p class="eyebrow">${esc(t("sameAge"))}</p><h2>${esc(heading)}</h2>
      <div class="row ${portrait && n > 2 ? "wrapgrid" : ""}">${picks.map((x, i) =>
        cardHtml(x.f, x.p.name, `${ageText(x.f.age)} · ${dateText(x.f.date, "year")}`, side, "who", 200 + i * 450)).join("")}</div>`;
    if (portrait && n > 2) {
      const row = el.querySelector(".row");
      row.style.flexWrap = "wrap";
      row.style.maxWidth = `${side * 2 + innerWidth * 0.08}px`;
    }
    fillSlots(el, picks.map((x) => x.f), side);
    setGlow(picks[0].f);
    return { el, run: async () => { await preload(picks.map((x) => x.f), 5000); await sleep(data.viewSeconds * 1000); } };
  }

  function messageView(title, text) {
    const el = document.createElement("section");
    el.className = "view message";
    el.innerHTML = `<svg class="mark" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2"><circle cx="17" cy="20" r="7"/><circle cx="33" cy="15" r="4.5"/><path d="M5 42c1.5-8 6.5-12 12-12s10.5 4 12 12M27 31c1.5-5 4-7.5 6-7.5 4 0 7 3.5 8.5 9.5"/></svg>
      <h1>${esc(title)}</h1><p>${esc(text)}</p>`;
    return { el };
  }

  // ---- the programme --------------------------------------------------------------

  function store(key, value) {
    try {
      if (value === undefined) return Number(localStorage.getItem(`growing-up.${key}`) || 0);
      localStorage.setItem(`growing-up.${key}`, String(value));
    } catch (_) { /* private mode */ }
    return 0;
  }

  function programme() {
    const focus = data.focus || {};
    let people = data.people.filter((p) => p.frames && p.frames.length);
    const birthdays = new Set(focus.birthday || []);
    if (focus.person) people = people.filter((p) => p.id === focus.person);
    if (birthdays.size) people = people.filter((p) => birthdays.has(p.id));
    people.forEach((p) => { p.birthday = birthdays.has(p.id); });
    const views = onlyView ? [onlyView] : data.views;
    const steps = [];
    if (!people.length) return steps;
    // Each time the scene starts it begins with the next person.
    const offset = focus.person || birthdays.size ? 0 : store("person") % people.length;
    const ordered = people.slice(offset).concat(people.slice(0, offset));
    if (!focus.person && !birthdays.size) store("person", offset + 1);
    for (const person of ordered) {
      if (views.includes("film") && person.frames.length >= 2) steps.push(() => filmView(person));
      if (views.includes("grid") && person.frames.length >= 3) steps.push(() => gridView(person));
      if (views.includes("thennow") && person.frames.length >= 2) steps.push(() => thenNowView(person));
      if (person.frames.length === 1 && views.length) steps.push(() => gridView(person));
    }
    const ages = data.sameAges || [];
    if (views.includes("sameage") && ages.length && !focus.person && !birthdays.size) {
      const withBirth = data.people.filter((p) => p.birthDate && p.frames.length);
      const index = store("age") % ages.length;
      store("age", index + 1);
      steps.splice(Math.min(steps.length, Math.max(1, Math.ceil(steps.length / 2))), 0, () => sameAgeView(withBirth, ages[index]));
    }
    return steps;
  }

  async function loop() {
    if (running) return;
    running = true;
    while (true) {
      if (!data) {
        await showView(() => messageView(lastError ? t("unreachable") : t("loading"), lastError ? lastError : ""), 0);
        await sleep(5000);
        data = await load() || data;
        continue;
      }
      lang = TEXT[data.language] ? data.language : "en";
      document.documentElement.lang = lang;
      const steps = programme();
      if (!steps.length) {
        const busy = data.people.some((p) => p.busy);
        const msg = !data.configured ? ["setup", "setupLong"] : !data.people.length ? ["pick", "pickLong"] : ["busy", "busyLong"];
        const err = data.people.map((p) => p.error).find(Boolean);
        await showView(() => messageView(t(msg[0]), err && !busy ? err : t(msg[1])), 0);
        await sleep(8000);
        data = await load() || data;
        continue;
      }
      for (const step of steps) {
        await showView(step, data.viewSeconds);
      }
    }
  }

  async function poll() {
    const fresh = await load();
    if (fresh) data = fresh;
  }

  (async () => {
    data = await load();
    if (!data) ready();
    setInterval(poll, POLL_MS);
    loop();
  })();
})();
