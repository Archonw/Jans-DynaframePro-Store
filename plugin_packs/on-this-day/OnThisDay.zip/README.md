# On This Day

Your photos of this day in earlier years, shown as a journey through time. Next to every photo you see the weather back then at that place and the weather today.

## Photos

One or more sources, merged:

- **All photos in DynaFrame**: the DynaFrame media database (also WebDAV) plus its media folders and extra folders you enter. Date and GPS come from the database or, if missing, from the photo file (read once, then cached).
- **A DynaFrame playlist**.
- **All photos in Immich** or **an Immich album**: the plugin only asks Immich for the photos around today's date in each earlier year. You need the server address and an API key (`asset.read`, `asset.view`, `album.read`). If Immich Slideshow or Growing Up already has a server, it is taken over.
- **Immich filters** (like Growing Up), so nothing private ends up on the frame: only photos from ticked albums, with at least a number of stars, only favourites, and archived photos left out unless you allow them. After a change the photos on show disappear at once and are looked up again.

For each year the plugin picks up to a few photos (default 3) spread over the day, skipping bursts; Immich favourites and photos with a location come first. If there are no photos on exactly this day, it can look a few days around it (up to ± 7). On 28 February in non-leap years, photos of the 29th count too.

## Weather

From Open-Meteo, free and without a key:

- **Back then**: the weather archive (ERA5, from 1940) for the hour and place of the photo: temperature, sky, high/low and rain of that day. Photos without GPS take the place of another photo of that day, otherwise your home town. Fetched once and cached for good.
- **Today**: at your home town (search it on the plugin page) or at the place of the photo.

Place names come from the photo (Immich, DynaFrame) or from OpenStreetMap (Nominatim, cached). If you use an ad blocker like Pi-hole, allow `archive-api.open-meteo.com`, `api.open-meteo.com`, `geocoding-api.open-meteo.com` and `nominatim.openstreetmap.org`.

## Scene

- **Time travel**: one photo after another, year by year, with date, time, place, a weather card (then and today, how much warmer or colder) and a timeline with the temperature of each year.
- **Side by side**: all years as photo cards, one after another highlighted.
- **Summary** after the last year: one photo per year, the temperatures of all years next to today's, the warmest, coldest and wettest year, the average and the place you were most often on this day.
- Adjustable: seconds per photo, transition, slow zoom, summary duration, order of the years, °C/°F, language (English, German, Spanish).

Settings are on the plugin page (Plugins > On This Day > Open On This Day). "Create playlist" adds a playlist with the scene.

## Licences

Fonts Fraunces and Inter (SIL Open Font License, `dynamic/fonts`). Weather data by Open-Meteo.com (CC BY 4.0), place names © OpenStreetMap contributors (ODbL). Problems or wishes: https://github.com/Archonw/Jans-DynaframePro-Store/issues
