# Third-party notes

- QR Code Generator for JavaScript (`phone/qrcode.js`, and a copy in the scene), © 2009 Kazuhiko Arase, MIT licence. The word "QR Code" is a registered trademark of DENSO WAVE INCORPORATED.
- The scene bundles the fonts Fraunces, Inter and Caveat under the SIL Open Font License 1.1 (see `dynamic/fonts/OFL-*.txt`).
- `sounds/drumroll.wav` and `sounds/tada.wav` come from Photo Gala (same store): composed for that plugin and played with the FluidR3 GM SoundFont by Frank Wen (MIT License).
- The cheering in `sounds/applause.wav` contains a recording from freesound.org (sound 528799), released under CC0 1.0.
- `sounds/bells.wav` is the melody of "Jingle Bells" (James Lord Pierpont, 1857, public domain), synthesised for this plugin.
- `own_playlist.py`, `plugin_ports.py` and `playback_guard.py` are shared with other plugins of this store (own code).
