/* Foto Quiz: die Seite fürs Handy.
 * Fragt jede Sekunde ./api/game?id=<Mitspieler>, zeigt je nach Phase Raten,
 * Auflösung oder Endstand und schickt Tipps mit POST ./api/guess. */
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const QT = window.QuizText;
  const T = {
    joinTitle: ["Mitspielen", "Play along", "Jugar"],
    joinLead: ["Rate, wann und wo die Fotos auf dem Rahmen entstanden sind. Gib den Code vom Bildschirm und deinen Namen ein.",
      "Guess when and where the photos on the frame were taken. Enter the code from the screen and your name.",
      "Adivina cuándo y dónde se hicieron las fotos del marco. Escribe el código de la pantalla y tu nombre."],
    code: ["Code vom Bildschirm", "Code from the screen", "Código de la pantalla"],
    name: ["Dein Name", "Your name", "Tu nombre"],
    join: ["Mitspielen", "Join", "Jugar"],
    badCode: ["Der Code stimmt nicht. Er steht auf dem Bildschirm neben dem QR-Code.", "That code is wrong. It is on the screen next to the QR code.", "El código no es correcto. Está en la pantalla junto al código QR."],
    noName: ["Bitte einen Namen eingeben.", "Please enter a name.", "Escribe un nombre."],
    off: ["Das Mitspielen mit dem Handy ist auf der Plugin-Seite ausgeschaltet.", "Playing with phones is switched off on the plugin page.", "Jugar con el móvil está desactivado en la página del plugin."],
    noAnswer: ["Der Rahmen antwortet nicht. Bist du im selben WLAN?", "The frame does not answer. Are you on the same Wi-Fi?", "El marco no responde. ¿Estás en la misma wifi?"],
    when: ["Wann?", "When?", "¿Cuándo?"],
    where: ["Wo?", "Where?", "¿Dónde?"],
    whereHint: ["Tippe auf die Karte, wo das Foto entstanden ist.", "Tap the map where the photo was taken.", "Toca el mapa donde se hizo la foto."],
    send: ["Tipp abgeben", "Send my guess", "Enviar respuesta"],
    resend: ["Tipp ändern", "Change my guess", "Cambiar respuesta"],
    sent: ["Tipp ist angekommen. Du kannst ihn noch ändern.", "Guess received. You can still change it.", "Respuesta recibida. Aún puedes cambiarla."],
    pickPlace: ["Tippe noch auf die Karte.", "Tap the map first.", "Toca primero el mapa."],
    late: ["Zu spät, die Runde ist schon vorbei.", "Too late, the round is over.", "Demasiado tarde, la ronda ha terminado."],
    hintWait: ["Hinweis {n} kommt gleich …", "Hint {n} is coming …", "La pista {n} llega enseguida …"],
    round: ["Runde {a} von {b}", "Round {a} of {b}", "Ronda {a} de {b}"],
    guessLine: ["Schau auf den Fernseher: Wann und wo war das?", "Look at the screen: when and where was this?", "Mira la pantalla: ¿cuándo y dónde fue?"],
    waitLine: ["Das nächste Foto wird geholt …", "Fetching the next photo …", "Buscando la siguiente foto …"],
    revealLine: ["Auflösung", "The answer", "La solución"],
    finalTitle: ["Endstand", "Final score", "Resultado final"],
    nextGame: ["Gleich beginnt das nächste Spiel.", "The next game starts in a moment.", "La siguiente partida empieza enseguida."],
    offLine: ["Das Quiz läuft gerade nicht auf dem Rahmen.", "The quiz is not on the frame right now.", "El quiz no está ahora en el marco."],
    offStart: ["Du kannst es von hier aus starten.", "You can start it from here.", "Puedes iniciarlo desde aquí."],
    offNoStart: ["Nimm die Szene „Foto Quiz“ in eine Playlist auf oder starte die Playlist „Foto Quiz“ auf dem Rahmen.", "Add the scene “Foto Quiz” to a playlist or start the “Foto Quiz” playlist on the frame.", "Añade la escena «Foto Quiz» a una lista o inicia la lista «Foto Quiz» en el marco."],
    start: ["Quiz jetzt auf den Rahmen holen", "Show the quiz on the frame now", "Mostrar el quiz en el marco ahora"],
    starting: ["Das Quiz kommt gleich auf den Rahmen …", "The quiz is coming to the frame …", "El quiz llega enseguida al marco …"],
    end: ["Quiz auf dem Rahmen beenden", "End the quiz on the frame", "Terminar el quiz en el marco"],
    rename: ["Namen ändern", "Change name", "Cambiar nombre"],
    yourPoints: ["Deine Punkte", "Your points", "Tus puntos"],
    noGuess: ["Du hast diesmal nicht getippt.", "You did not guess this time.", "Esta vez no has respondido."],
    yearOff: ["Jahr {y}: {p}", "Year {y}: {p}", "Año {y}: {p}"],
    placeOff: ["{km} daneben: {p}", "{km} off: {p}", "a {km}: {p}"],
    exact: ["genau", "spot on", "exacto"],
    yearsOff: ["{n} J. daneben", "{n} yr off", "{n} años de diferencia"]
  };
  let lang = (document.documentElement.lang || "en").slice(0, 2);
  const tx = (key, values) => {
    const row = T[key] || [key, key, key];
    let text = row[{ de: 0, en: 1, es: 2 }[lang] ?? 1];
    for (const [k, v] of Object.entries(values || {})) text = text.replace(`{${k}}`, v);
    return text;
  };

  function applyLanguage() {
    document.documentElement.lang = lang;
    document.querySelectorAll("[data-t]").forEach((node) => { node.textContent = tx(node.dataset.t); });
  }

  // ------------------------------------------------------------ Speicher

  const store = {
    get(key) { try { return localStorage.getItem("fotoquiz." + key) || ""; } catch (_) { return ""; } },
    set(key, value) { try { localStorage.setItem("fotoquiz." + key, value); } catch (_) { /* privat */ } }
  };
  let me = store.get("id");
  const params = new URLSearchParams(location.search);
  if (params.get("c")) $("code").value = params.get("c").replace(/\D/g, "").slice(0, 4);
  $("name").value = store.get("name");

  async function api(path, body) {
    const response = await fetch(path, body === undefined ? { cache: "no-store" } : {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
    });
    if (response.status === 403) return { success: false, error: "off" };
    return response.json();
  }

  // ------------------------------------------------------------ Beitreten

  function showJoin(text, bad) {
    $("joinScreen").hidden = false;
    $("gameScreen").hidden = true;
    $("me").hidden = true;
    $("joinNote").textContent = text || "";
    $("joinNote").classList.toggle("bad", !!bad);
  }

  $("joinButton").addEventListener("click", async () => {
    const name = $("name").value.trim();
    if (!name) return showJoin(tx("noName"), true);
    $("joinButton").disabled = true;
    try {
      const reply = await api("api/join", { code: $("code").value.trim(), name, id: me || undefined });
      if (reply.success) {
        me = reply.id;
        store.set("id", me);
        store.set("name", name);
        $("joinScreen").hidden = true;
        poll();
      } else {
        showJoin(tx(reply.error === "code" ? "badCode" : reply.error === "name" ? "noName" : reply.error === "off" ? "off" : "noAnswer"), true);
      }
    } catch (_) {
      showJoin(tx("noAnswer"), true);
    } finally {
      $("joinButton").disabled = false;
    }
  });

  $("renameButton").addEventListener("click", () => showJoin(""));

  // ------------------------------------------------------------ Karte

  let map = null, marker = null, others = [], pick = null, mapIdent = -1;

  function pinIcon(color) {
    return L.divIcon({ className: "", html: `<div class="pin" style="background:${color}"></div>`, iconSize: [22, 22], iconAnchor: [11, 26] });
  }

  function zoomFor(scale) {
    if (scale < 15) return 11;
    if (scale < 60) return 9;
    if (scale < 250) return 7;
    if (scale < 800) return 5;
    return 3;
  }

  function ensureMap(state) {
    if (map) return;
    map = L.map("map", { worldCopyJump: true, zoomControl: true, attributionControl: true, preferCanvas: true });
    const data = window.WORLD_MAP;     // Küsten, falls keine Kacheln kommen
    if (data && data.land) {
      const rings = data.land.map((ring) => {
        const out = [];
        let lon = ring[0], lat = ring[1];
        out.push([lat / 100, lon / 100]);
        for (let i = 2; i < ring.length; i += 2) { lon += ring[i]; lat += ring[i + 1]; out.push([lat / 100, lon / 100]); }
        return out;
      });
      L.polygon(rings, { color: "#53627e", weight: 1, fillColor: "#33405a", fillOpacity: 1, interactive: false }).addTo(map);
    }
    L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png", {
      maxZoom: 18, subdomains: "abcd",
      attribution: "© OpenStreetMap, © CARTO"
    }).addTo(map);
    const centre = state.center || state.home || [50, 10];
    map.setView(centre, state.center ? zoomFor(state.scale || 300) : 4);
    map.on("click", (event) => {
      pick = event.latlng.wrap();
      if (!marker) marker = L.marker(pick, { icon: pinIcon(state.me?.color || "#ffcc4d") }).addTo(map);
      marker.setLatLng(pick);
      $("sendNote").textContent = "";
    });
  }

  // ------------------------------------------------------------ Raten

  let state = null, yearDirty = false, sentIdent = -1;

  function setYear(value) {
    const box = $("year");
    const v = Math.max(+box.min, Math.min(+box.max, value));
    box.value = v;
    $("yearOut").textContent = v;
  }
  $("year").addEventListener("input", () => { yearDirty = true; setYear(+$("year").value); });
  $("yearDown").addEventListener("click", () => { yearDirty = true; setYear(+$("year").value - 1); });
  $("yearUp").addEventListener("click", () => { yearDirty = true; setYear(+$("year").value + 1); });

  $("sendButton").addEventListener("click", async () => {
    if (!state || state.phase !== "guess") return;
    const wantWhere = state.mode !== "when";
    const wantWhen = state.mode !== "where";
    if (wantWhere && !pick) {
      $("sendNote").textContent = tx("pickPlace");
      $("sendNote").classList.add("bad");
      return;
    }
    const body = { id: me, ident: state.ident };
    if (wantWhen) body.year = +$("year").value;
    if (wantWhere) { body.lat = pick.lat; body.lon = pick.lng; }
    try {
      const reply = await api("api/guess", body);
      $("sendNote").classList.toggle("bad", !reply.success);
      $("sendNote").textContent = tx(reply.success ? "sent" : "late");
      if (reply.success) { sentIdent = state.ident; }
      $("sendButton").classList.toggle("done", reply.success);
      $("sendButton").textContent = tx(reply.success ? "resend" : "send");
    } catch (_) {
      $("sendNote").textContent = tx("noAnswer");
    }
  });

  function newRound(s) {
    mapIdent = s.ident;
    pick = null;
    if (marker) { marker.remove(); marker = null; }
    others.forEach((m) => m.remove());
    others = [];
    yearDirty = false;
    const [lo, hi] = s.years || [2000, new Date().getFullYear()];
    $("year").min = lo - 2;
    $("year").max = Math.max(hi, lo + 1);
    $("yearMin").textContent = lo - 2;
    $("yearMax").textContent = Math.max(hi, lo + 1);
    setYear(Math.round((lo + hi) / 2));
    $("sendButton").classList.remove("done");
    $("sendButton").textContent = tx("send");
    $("sendNote").textContent = "";
    if (map && (s.center || s.home)) map.setView(s.center || s.home, zoomFor(s.scale || 300));
  }

  function renderHints(s) {
    const list = $("hints");
    const shown = s.hints || [];
    const total = s.hintCount || shown.length;
    const html = shown.map((h) => {
      const [label, text] = QT.hint(h, lang, s.units);
      return `<li>${label ? `<b>${esc(label)}:</b> ` : ""}${esc(text)}</li>`;
    });
    for (let i = shown.length; i < total; i += 1) html.push(`<li class="wait">${esc(tx("hintWait", { n: i + 1 }))}</li>`);
    const joined = html.join("");
    if (list.dataset.html !== joined) { list.innerHTML = joined; list.dataset.html = joined; }
  }

  const esc = (text) => String(text ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  function board(list, rows, key) {
    list.innerHTML = rows.map((r) => `<li class="${r.mine ? "me-row" : ""}"><i style="background:${esc(r.color)}"></i><span>${esc(r.name)}</span><b>${r[key]}</b></li>`).join("");
  }

  // ------------------------------------------------------------ Anzeige

  function show(id) {
    for (const box of ["offBox", "guessBox", "revealBox", "finalBox"]) $(box).hidden = box !== id;
  }

  function render(s) {
    state = s;
    if (s.lang && s.lang !== lang) { lang = s.lang; applyLanguage(); }
    $("gameScreen").hidden = false;
    if (s.me) {
      $("me").hidden = false;
      $("meDot").style.background = s.me.color;
      $("meName").textContent = s.me.name;
      $("meScore").textContent = s.me.score;
    }
    const timed = ["guess", "reveal", "final"].includes(s.phase) && s.dur > 0;
    $("timer").style.visibility = timed ? "visible" : "hidden";
    if (timed) $("timerBar").style.transform = `scaleX(${Math.max(0, Math.min(1, s.left / s.dur))})`;
    $("endButton").hidden = !s.takeover;
    const roundText = s.round ? tx("round", { a: s.round, b: s.rounds }) + " · " : "";

    if (s.phase === "off") {
      show("offBox");
      $("phaseLine").textContent = "";
      $("offText").textContent = tx("offLine") + " " + (s.canStart ? tx("offStart") : tx("offNoStart"));
      $("startButton").hidden = !s.canStart;
      if (s.note) $("offText").textContent += " " + s.note;
    } else if (s.phase === "wait") {
      show("offBox");
      $("startButton").hidden = true;
      $("phaseLine").textContent = "";
      $("offText").textContent = tx("waitLine");
    } else if (s.phase === "guess") {
      show("guessBox");
      if (s.ident !== mapIdent) {
        $("whenBox").hidden = s.mode === "where";
        $("whereBox").hidden = s.mode === "when";
        if (s.mode !== "when") ensureMap(s);
        newRound(s);
        if (map) setTimeout(() => map.invalidateSize(), 50);
      }
      $("phaseLine").textContent = roundText + tx("guessLine");
      renderHints(s);
      if (s.myGuess && sentIdent !== s.ident) {   // Seite neu geladen: den Tipp wieder zeigen
        sentIdent = s.ident;
        if (s.myGuess.year && !yearDirty) setYear(s.myGuess.year);
        $("sendButton").classList.add("done");
        $("sendButton").textContent = tx("resend");
      }
    } else if (s.phase === "reveal") {
      show("revealBox");
      $("phaseLine").textContent = roundText + tx("revealLine");
      const a = s.answer || {};
      $("answerDate").textContent = QT.date(a.t, lang);
      $("answerPlace").textContent = a.place || "";
      const mine = (s.results || []).find((r) => r.mine);
      if (mine) {
        const parts = [];
        if (mine.year != null) {
          const off = Math.abs(mine.year - +String(a.t).slice(0, 4));
          parts.push(tx("yearOff", { y: mine.year, p: off ? tx("yearsOff", { n: off }) + ", " + mine.yearPoints : tx("exact") + ", " + mine.yearPoints }));
        }
        if (mine.km != null) parts.push(tx("placeOff", { km: QT.distance(mine.km, lang), p: mine.placePoints }));
        $("mine").innerHTML = `${esc(tx("yourPoints"))}: <b>+${mine.points}</b><br><span class="small">${esc(parts.join(" · "))}</span>`;
      } else {
        $("mine").textContent = tx("noGuess");
      }
      board($("roundBoard"), (s.results || []).map((r) => ({ ...r, pts: `+${r.points}` })), "pts");
    } else if (s.phase === "final") {
      show("finalBox");
      $("phaseLine").textContent = "";
      board($("finalBoard"), s.final || [], "score");
    }
  }

  $("startButton").addEventListener("click", async () => {
    $("startButton").disabled = true;
    try {
      const reply = await api("api/start", { id: me });
      $("offText").textContent = reply.success ? tx("starting") : tx("noAnswer");
    } finally {
      setTimeout(() => { $("startButton").disabled = false; }, 4000);
    }
  });
  $("endButton").addEventListener("click", () => api("api/end", { id: me }).catch(() => {}));

  // ------------------------------------------------------------ Abfrage

  let failures = 0;
  async function poll() {
    if (!me) return;
    try {
      const s = await api("api/game?id=" + encodeURIComponent(me));
      failures = 0;
      if (s.success === false && s.error === "off") return showJoin(tx("off"), true);
      if (!s.me) {          // auf dem Rahmen entfernt: neu beitreten
        me = "";
        store.set("id", "");
        return showJoin("");
      }
      render(s);
    } catch (_) {
      failures += 1;
      if (failures > 3) $("phaseLine").textContent = tx("noAnswer");
    }
  }

  applyLanguage();
  if (me) poll(); else showJoin("");
  setInterval(poll, 1000);
})();
