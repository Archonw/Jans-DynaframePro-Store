"""Party Wall: die Party selbst (Fotos, Gäste, Reaktionen), ohne HTTP und ohne Engine.

Eine Party liegt in data/parties/<id>/:
  meta.json    Titel, Code, Beginn, Rückschau an/aus
  photos.json  alle Fotos mit Reaktionen
  guests.json  Gäste (Name, Farbe)
  photos/      <foto>.jpg (lange Seite 1920) und <foto>.t.jpg (Vorschau 480)

Reaktionen zählen für die Hitliste höchstens CAP je Gast und Foto, damit
niemand ein Foto allein nach oben tippt. Fliegen dürfen alle (mit Bremse).
"""

import collections
import json
import os
import random
import re
import secrets
import shutil
import threading
import time
from pathlib import Path

EMOJIS = ("heart", "laugh", "love", "fire", "clap", "party", "wow")
CAP = 3                 # so viele Reaktionen je Gast und Foto zählen für die Hitliste
BURST = 8               # so viele fliegende Emojis je Gast in BURST_SECONDS
BURST_SECONDS = 3.0
ACTIVE_SECONDS = 120    # so lange gilt ein Gast nach seiner letzten Frage als da
MAX_GUESTS = 300
COLORS = ("#ff5d8f", "#ffb347", "#7bdff2", "#b28dff", "#5ee6a8", "#ffd84d", "#ff7b54", "#4cc9f0",
          "#f15bb5", "#9ef01a", "#c77dff", "#00f5d4", "#fb8500", "#e9c46a", "#90e0ef", "#ff99c8")


def now():
    return time.time()


def clean_text(value, limit):
    text = re.sub(r"[\x00-\x1f\x7f<>]", "", str(value or ""))
    return re.sub(r"\s+", " ", text).strip()[:limit]


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return default


def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)


def new_code():
    return f"{secrets.randbelow(9000) + 1000}"


def score(photo):
    return sum(min(int(n), CAP) for n in (photo.get("by") or {}).values())


class Party:
    """Die laufende Party. Alle Methoden halten self.lock selbst."""

    def __init__(self, folder):
        self.folder = Path(folder)
        self.lock = threading.RLock()
        self.meta = read_json(self.folder / "meta.json", {}) or {}
        photos = read_json(self.folder / "photos.json", []) or []
        self.photos = [p for p in photos if isinstance(p, dict) and p.get("id")]
        guests = read_json(self.folder / "guests.json", {}) or {}
        self.guests = guests if isinstance(guests, dict) else {}
        self.events = collections.deque(maxlen=400)
        self.seq = int(self.meta.get("seq") or 0)
        self.seen = {}           # Gast -> letzte Frage
        self.bursts = {}         # Gast -> Zeiten der letzten fliegenden Emojis
        self.requests = []       # Fotos, die Gäste auf den Fernseher gewünscht haben
        self.dirty = 0.0
        # Was gerade auf der Wand ist
        self.current = None
        self.since = 0.0
        self.until = 0.0
        self.recent = collections.deque(maxlen=12)
        self.top_until = 0.0
        self.last_top = now()

    # ---- Anlegen, Speichern ---------------------------------------------

    @classmethod
    def create(cls, root, title=""):
        ident = time.strftime("%Y%m%d-%H%M%S-") + secrets.token_hex(2)
        folder = Path(root) / ident
        (folder / "photos").mkdir(parents=True, exist_ok=True)
        write_json(folder / "meta.json", {"id": ident, "title": clean_text(title, 60), "code": new_code(),
                                          "started": now(), "recap": False, "seq": 0})
        write_json(folder / "photos.json", [])
        write_json(folder / "guests.json", {})
        return cls(folder)

    @property
    def ident(self):
        return self.meta.get("id") or self.folder.name

    @property
    def code(self):
        return str(self.meta.get("code") or "")

    def save(self, what=("meta", "photos", "guests")):
        with self.lock:
            self.meta["seq"] = self.seq
            if "meta" in what:
                write_json(self.folder / "meta.json", self.meta)
            if "photos" in what:
                write_json(self.folder / "photos.json", self.photos)
            if "guests" in what:
                write_json(self.folder / "guests.json", self.guests)
            self.dirty = 0.0

    def save_later(self):
        if not self.dirty:
            self.dirty = now()

    def flush(self, force=False):
        if self.dirty and (force or now() - self.dirty > 5):
            self.save()

    def set_meta(self, **fields):
        with self.lock:
            self.meta.update(fields)
            self.save(("meta",))

    # ---- Gäste --------------------------------------------------------------

    def join(self, name, ident=None):
        with self.lock:
            if ident and ident in self.guests:
                guest = self.guests[ident]
                if name is not None and clean_text(name, 24):
                    guest["name"] = clean_text(name, 24)
                    self.save(("guests",))
                return ident, guest
            if len(self.guests) >= MAX_GUESTS:
                return None, None
            ident = secrets.token_urlsafe(9)
            number = len(self.guests) + 1
            guest = {"name": clean_text(name, 24), "n": number, "color": COLORS[(number - 1) % len(COLORS)],
                     "at": now()}
            self.guests[ident] = guest
            self.save(("guests",))
            return ident, guest

    def guest(self, ident):
        return self.guests.get(ident) if ident else None

    def guest_name(self, ident, fallback="Gast {n}"):
        guest = self.guests.get(ident) or {}
        return guest.get("name") or fallback.format(n=guest.get("n", "?"))

    def touch(self, ident, t=None):
        if ident in self.guests:
            self.seen[ident] = t or now()

    def active_guests(self, t=None):
        t = t or now()
        return sum(1 for v in self.seen.values() if t - v <= ACTIVE_SECONDS)

    # ---- Fotos --------------------------------------------------------------

    def photo_dir(self):
        return self.folder / "photos"

    def find(self, photo_id):
        with self.lock:
            return next((p for p in self.photos if p["id"] == photo_id), None)

    def add_photo(self, guest_id, width, height, caption, approved):
        """Platz für ein neues Foto: liefert die Zeile (Dateien schreibt der Aufrufer davor)."""
        photo_id = time.strftime("%H%M%S-") + secrets.token_hex(3)
        row = {"id": photo_id, "g": guest_id, "at": now(), "w": int(width), "h": int(height),
               "cap": clean_text(caption, 80), "st": "ok" if approved else "wait",
               "r": {}, "by": {}, "shown": 0}
        with self.lock:
            self.photos.append(row)
            guest = self.guests.get(guest_id)
            if guest is not None:
                guest["uploads"] = guest.get("uploads", 0) + 1
            self.save(("photos", "guests"))
        return row

    def set_state(self, photo_id, state):
        with self.lock:
            photo = self.find(photo_id)
            if not photo or state not in ("ok", "hidden", "wait"):
                return False
            photo["st"] = state
            if state != "ok" and self.current == photo_id:
                self.until = 0.0
            if state != "ok":
                self.requests = [r for r in self.requests if r != photo_id]
            self.save(("photos",))
            return True

    def delete(self, photo_id):
        with self.lock:
            photo = self.find(photo_id)
            if not photo:
                return False
            self.photos.remove(photo)
            self.requests = [r for r in self.requests if r != photo_id]
            if self.current == photo_id:
                self.current, self.until = None, 0.0
            self.save(("photos",))
        for suffix in (".jpg", ".t.jpg"):
            try:
                (self.photo_dir() / f"{photo_id}{suffix}").unlink()
            except OSError:
                pass
        return True

    def visible(self):
        with self.lock:
            return [p for p in self.photos if p.get("st") == "ok"]

    def ranking(self, limit=10):
        rows = [p for p in self.visible() if score(p) > 0]
        rows.sort(key=lambda p: (-score(p), -len(p.get("by") or {}), p["at"]))
        return rows[:limit]

    # ---- Reaktionen -----------------------------------------------------------

    def react(self, guest_id, photo_id, emoji, t=None):
        """(ok, fliegt) - zählt die Reaktion und meldet sie der Szene, wenn der Gast nicht zu schnell tippt."""
        t = t or now()
        if emoji not in EMOJIS:
            return False, False
        with self.lock:
            photo = self.find(photo_id)
            if not photo or photo.get("st") != "ok" or guest_id not in self.guests:
                return False, False
            times = [x for x in self.bursts.get(guest_id, []) if t - x < BURST_SECONDS]
            flies = len(times) < BURST
            if flies:
                times.append(t)
            self.bursts[guest_id] = times
            by = photo.setdefault("by", {})
            if by.get(guest_id, 0) < 99:
                by[guest_id] = by.get(guest_id, 0) + 1
                reactions = photo.setdefault("r", {})
                reactions[emoji] = reactions.get(emoji, 0) + 1
            if flies:
                self.seq += 1
                guest = self.guests[guest_id]
                self.events.append({"s": self.seq, "e": emoji, "p": photo_id, "g": guest_id,
                                    "c": guest.get("color", "#fff"), "t": t})
            self.save_later()
            return True, flies

    def events_since(self, seq):
        with self.lock:
            if seq < 0 or seq > self.seq:
                return [], self.seq      # Szene neu geladen: nichts Altes nachholen
            return [e for e in self.events if e["s"] > seq], self.seq

    def request(self, photo_id):
        with self.lock:
            photo = self.find(photo_id)
            if not photo or photo.get("st") != "ok":
                return False
            if photo_id != self.current and photo_id not in self.requests:
                self.requests.append(photo_id)
                del self.requests[:-5]
            return True

    # ---- Was die Wand zeigt -------------------------------------------------

    def fresh(self):
        with self.lock:
            return [p for p in self.photos if p.get("st") == "ok" and not p.get("shown")]

    def pick_next(self, t, seconds):
        """Das nächste Foto: zuerst neue, dann gewünschte, sonst gewichtet nach Beliebtheit."""
        with self.lock:
            pool = self.visible()
            if not pool:
                self.current, self.until = None, 0.0
                return None
            chosen = None
            fresh = [p for p in pool if not p.get("shown") and p["id"] != self.current]
            if fresh:
                chosen = min(fresh, key=lambda p: p["at"])
            while chosen is None and self.requests:
                chosen = self.find(self.requests.pop(0))
                if chosen and chosen.get("st") != "ok":
                    chosen = None
            if chosen is None:
                recent = set(self.recent)
                candidates = [p for p in pool if p["id"] not in recent] or \
                             [p for p in pool if p["id"] != self.current] or pool
                weights = [(1.0 + score(p)) ** 0.8 / (1.0 + 0.5 * p.get("shown", 0)) for p in candidates]
                chosen = random.choices(candidates, weights=weights, k=1)[0]
            chosen["shown"] = chosen.get("shown", 0) + 1
            chosen["last"] = t
            self.current = chosen["id"]
            self.since = t
            self.until = t + seconds
            self.recent.append(chosen["id"])
            self.save_later()
            return chosen

    # ---- Zahlen für Szene und Seiten --------------------------------------

    def stats(self):
        with self.lock:
            shown = self.visible()
            reactions = sum(sum((p.get("r") or {}).values()) for p in self.photos)
            uploads = collections.Counter(p.get("g") for p in shown)
            top_guest = uploads.most_common(1)[0] if uploads else None
            return {
                "photos": len(shown),
                "waiting": sum(1 for p in self.photos if p.get("st") == "wait"),
                "guests": len(self.guests),
                "uploaders": len(uploads),
                "reactions": reactions,
                "topGuest": ({"name": self.guest_name(top_guest[0]), "n": top_guest[1]} if top_guest else None),
            }


# ---- Frühere Partys -------------------------------------------------------

def list_parties(root):
    out = []
    for folder in sorted(Path(root).glob("*/meta.json"), reverse=True):
        meta = read_json(folder, {}) or {}
        photos = read_json(folder.parent / "photos.json", []) or []
        size = 0
        for file in (folder.parent / "photos").glob("*.jpg"):
            try:
                size += file.stat().st_size
            except OSError:
                pass
        out.append({"id": meta.get("id") or folder.parent.name, "title": meta.get("title") or "",
                    "started": meta.get("started") or 0, "photos": len(photos), "bytes": size})
    return out


def remove_party(root, ident):
    if not re.match(r"^[0-9A-Za-z-]{6,40}$", ident or ""):
        return False
    folder = Path(root) / ident
    if not (folder / "meta.json").exists():
        return False
    shutil.rmtree(folder, ignore_errors=True)
    return True


def free_bytes(path):
    try:
        stat = os.statvfs(path)
        return stat.f_bavail * stat.f_frsize
    except OSError:
        return 1 << 40
