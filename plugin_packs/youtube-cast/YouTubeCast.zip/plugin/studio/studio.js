"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/YouTubeCast/ aus, die Senden-Seite unter :8090/.

const el = (id) => document.getElementById(id);
const PHONE = document.documentElement.hasAttribute("data-phone");
let current = null;
let editing = false;
let draggingVolume = false;

// Texte der Seite auf Deutsch, Englisch und Spanisch. Die Sprache ist eine
// Einstellung des Plugins und gilt auch für die Szene.
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Schick Videos vom Handy auf den Rahmen: mit dem Streamen-Knopf der YouTube-App wie an einen Fernseher, oder als Link. Danach läuft deine Playlist weiter. Jede Änderung hier wird sofort gespeichert.",
    "Send videos from your phone to the frame: with the cast button of the YouTube app, just like to a TV, or as a link. Afterwards your playlist carries on. Every change here is saved immediately.",
    "Envía vídeos del móvil al marco: con el botón de enviar de la app de YouTube, como a un televisor, o como enlace. Después tu lista sigue. Cada cambio aquí se guarda al instante."],
  phoneLede: ["Link einfügen und abspielen. Am einfachsten geht es mit dem Streamen-Knopf in der YouTube-App.",
    "Paste a link and play it. The easiest way is the cast button in the YouTube app.",
    "Pega un enlace y reprodúcelo. Lo más fácil es el botón de enviar de la app de YouTube."],
  language: ["Sprache", "Language", "Idioma"],
  nowTitle: ["Jetzt auf dem Rahmen", "Now on the frame", "Ahora en el marco"],
  test: ["Probe-Video", "Test video", "Vídeo de prueba"],
  nothing: ["Gerade läuft nichts.", "Nothing is playing right now.", "Ahora mismo no se reproduce nada."],
  pause: ["Pause", "Pause", "Pausa"],
  resume: ["Weiter", "Resume", "Seguir"],
  next: ["Nächstes", "Next", "Siguiente"],
  stop: ["Stopp", "Stop", "Parar"],
  volume: ["Lautstärke", "Volume", "Volumen"],
  sendTitle: ["Link senden", "Send a link", "Enviar un enlace"],
  send: ["Abspielen", "Play", "Reproducir"],
  sendHint: ["In der YouTube-App unter einem Video auf Teilen und dann auf Link kopieren tippen, hier einfügen. Eine Startzeit im Link (t=) wird übernommen.",
    "In the YouTube app tap Share below a video, then Copy link, and paste it here. A start time in the link (t=) is used.",
    "En la app de YouTube pulsa Compartir bajo un vídeo y luego Copiar enlace, y pégalo aquí. Se respeta un tiempo de inicio en el enlace (t=)."],
  sending: ["Sende …", "Sending …", "Enviando …"],
  castTitle: ["Streamen-Knopf der YouTube-App", "Cast button of the YouTube app", "Botón de enviar de la app de YouTube"],
  castHint: ["Im selben WLAN zeigt die YouTube-App den Rahmen wie einen Fernseher an: im Video oben auf das <b>Streamen-Symbol</b> (Bildschirm mit Wellen) tippen und den Rahmen auswählen. Die App wird dann zur Fernbedienung: Pause, Spulen, Lautstärke, Warteschlange.",
    "On the same Wi-Fi the YouTube app lists the frame like a TV: tap the <b>cast icon</b> (screen with waves) at the top of a video and choose the frame. The app then becomes the remote: pause, seek, volume, queue.",
    "En la misma wifi la app de YouTube muestra el marco como un televisor: pulsa el <b>icono de enviar</b> (pantalla con ondas) arriba en el vídeo y elige el marco. La app pasa a ser el mando: pausa, avanzar, volumen, cola."],
  factWifi: ["Im WLAN sichtbar", "Visible on Wi-Fi", "Visible en la wifi"],
  factSenders: ["Verbunden", "Connected", "Conectado"],
  yes: ["Ja", "Yes", "Sí"],
  noWifi: ["Nein ({error}); TV-Code benutzen", "No ({error}); use the TV code", "No ({error}); usa el código de TV"],
  nobody: ["Niemand", "Nobody", "Nadie"],
  deviceName: ["Name in der YouTube-App", "Name in the YouTube app", "Nombre en la app de YouTube"],
  codeTitle: ["Findet die App den Rahmen nicht? Mit TV-Code verknüpfen", "App doesn't find the frame? Link with TV code",
    "¿La app no encuentra el marco? Vincular con código de TV"],
  codeHint: ["Einmal verknüpft, steht der Rahmen immer im Streamen-Menü, auch auf dem iPhone und wenn das WLAN ihn nicht weitermeldet. In der YouTube-App: <b>Du</b> (Profil) → <b>Einstellungen</b> → <b>Auf TV ansehen</b> → <b>Mit TV-Code verknüpfen</b>, dann diesen Code eingeben.",
    "Once linked, the frame always shows up in the cast menu, also on an iPhone and when the Wi-Fi does not pass it on. In the YouTube app: <b>You</b> (profile) → <b>Settings</b> → <b>Watch on TV</b> → <b>Link with TV code</b>, then enter this code.",
    "Una vez vinculado, el marco aparece siempre en el menú de enviar, también en iPhone y aunque la wifi no lo anuncie. En la app de YouTube: <b>Tú</b> (perfil) → <b>Ajustes</b> → <b>Ver en la TV</b> → <b>Vincular con código de TV</b> y escribe este código."],
  showCode: ["TV-Code anzeigen", "Show TV code", "Mostrar código de TV"],
  newCode: ["Neuer Code", "New code", "Código nuevo"],
  codeValid: ["Der Code gilt ein paar Minuten.", "The code is valid for a few minutes.", "El código vale unos minutos."],
  shareTitle: ["Aus dem Teilen-Menü (ohne YouTube-App-Streamen)", "From the share menu (without casting)",
    "Desde el menú compartir (sin enviar)"],
  shareHint: ["Die Senden-Seite fürs Handy, im WLAN erreichbar. Auf dem Handy öffnen und zum Home-Bildschirm hinzufügen: Link einfügen, abspielen, pausieren.",
    "The send page for your phone, reachable on your Wi-Fi. Open it on the phone and add it to the home screen: paste a link, play, pause.",
    "La página de envío para el móvil, accesible en tu wifi. Ábrela en el móvil y añádela a la pantalla de inicio: pega un enlace, reproduce, pausa."],
  iosTitle: ["iPhone: eigener Eintrag „Auf DynaFrame“ im Teilen-Menü", "iPhone: an “On DynaFrame” entry in the share menu",
    "iPhone: una entrada «En DynaFrame» en el menú compartir"],
  ios1: ["App <b>Kurzbefehle</b> öffnen, oben rechts auf <b>+</b> tippen.", "Open the <b>Shortcuts</b> app and tap <b>+</b> at the top right.",
    "Abre la app <b>Atajos</b> y pulsa <b>+</b> arriba a la derecha."],
  ios2: ["<b>Aktion hinzufügen</b>, nach <b>Inhalte von URL abrufen</b> suchen und antippen.",
    "<b>Add Action</b>, search for <b>Get Contents of URL</b> and tap it.",
    "<b>Añadir acción</b>, busca <b>Obtener contenido de URL</b> y púlsala."],
  ios3: ["Als URL eintragen: <code class=\"inline\">{url}</code>", "Enter this as the URL: <code class=\"inline\">{url}</code>",
    "Escribe como URL: <code class=\"inline\">{url}</code>"],
  ios4: ["Den Pfeil der Aktion aufklappen: Methode <b>POST</b>, Anfragetext <b>Formular</b>, <b>Neues Feld</b> → Text, Schlüssel <b>url</b>, als Wert die Variable <b>Kurzbefehleingabe</b>.",
    "Expand the action's arrow: method <b>POST</b>, request body <b>Form</b>, <b>Add new field</b> → Text, key <b>url</b>, value the variable <b>Shortcut Input</b>.",
    "Despliega la flecha de la acción: método <b>POST</b>, cuerpo <b>Formulario</b>, <b>Añadir campo</b> → Texto, clave <b>url</b>, valor la variable <b>Entrada del atajo</b>."],
  ios5: ["Oben den Namen auf <b>Auf DynaFrame</b> ändern, unten auf <b>ⓘ</b> und <b>Im Share-Sheet anzeigen</b> einschalten.",
    "Rename it at the top to <b>On DynaFrame</b>, tap <b>ⓘ</b> at the bottom and switch on <b>Show in Share Sheet</b>.",
    "Arriba cambia el nombre a <b>En DynaFrame</b>, abajo pulsa <b>ⓘ</b> y activa <b>Mostrar en hoja para compartir</b>."],
  ios6: ["In YouTube: <b>Teilen</b> → <b>Auf DynaFrame</b>. Beim ersten Mal fragt das iPhone, ob es Geräte im lokalen Netzwerk erreichen darf: <b>Erlauben</b>.",
    "In YouTube: <b>Share</b> → <b>On DynaFrame</b>. The first time the iPhone asks whether it may reach devices on the local network: <b>Allow</b>.",
    "En YouTube: <b>Compartir</b> → <b>En DynaFrame</b>. La primera vez el iPhone pregunta si puede acceder a dispositivos de la red local: <b>Permitir</b>."],
  androidTitle: ["Android", "Android", "Android"],
  androidHint: ["Auf Android ist der Streamen-Knopf der einfachste Weg. Wer lieber teilt: die Senden-Seite oben in Chrome öffnen, Menü → Zum Startbildschirm hinzufügen, dann Link kopieren und dort einfügen.",
    "On Android the cast button is the easiest way. If you prefer sharing: open the send page above in Chrome, menu → Add to home screen, then copy a link and paste it there.",
    "En Android el botón de enviar es lo más fácil. Si prefieres compartir: abre la página de envío en Chrome, menú → Añadir a pantalla de inicio, copia un enlace y pégalo allí."],
  settingsTitle: ["Einstellungen", "Settings", "Ajustes"],
  wake: ["Ausgeschalteten Bildschirm für ein Video einschalten", "Switch an off screen on for a video", "Encender la pantalla apagada para un vídeo"],
  sound: ["Mit Ton abspielen", "Play with sound", "Reproducir con sonido"],
  pauseMinutes: ["Nach … Minuten Pause zurück zur Playlist", "Back to the playlist after … minutes of pause",
    "Volver a la lista tras … minutos de pausa"],
  importantTitle: ["Wichtig", "Important", "Importante"],
  importantHint: ["Damit YouTube Cast ein Video zeigen darf, muss auf der Plugins-Seite des Rahmens <b>Allow takeover</b> eingeschaltet sein. Die Playlist „YouTube Cast (takeover)“ benutzt das Plugin selbst; lass sie ausgeschaltet.",
    "For YouTube Cast to show a video, <b>Allow takeover</b> must be on for it on the frame's Plugins page. The playlist “YouTube Cast (takeover)” is used by the plugin itself; leave it switched off.",
    "Para que YouTube Cast pueda mostrar un vídeo, <b>Allow takeover</b> debe estar activado en la página de plugins del marco. La lista «YouTube Cast (takeover)» la usa el propio plugin; déjala desactivada."],
  embedHint: ["Abgespielt wird mit dem eingebetteten Player von YouTube, so wie auf anderen Webseiten. Manche Videos, oft Musikvideos, erlauben das nicht; dann erscheint ein Hinweis und die Playlist läuft weiter. Werbung kann vorkommen.",
    "Videos play in YouTube's embedded player, as on other websites. Some videos, often music videos, do not allow that; then a note appears and the playlist carries on. Ads may appear.",
    "Se reproduce con el reproductor insertado de YouTube, como en otras webs. Algunos vídeos, a menudo musicales, no lo permiten; entonces aparece un aviso y la lista sigue. Puede haber anuncios."],
  recent: ["Zuletzt gesendet", "Recently sent", "Enviados recientemente"],
  noRecent: ["Noch nichts gesendet.", "Nothing sent yet.", "Todavía no se ha enviado nada."],
  again: ["Nochmal", "Again", "Otra vez"],
  fromCast: ["Gestreamt von {who}", "Cast from {who}", "Enviado desde {who}"],
  fromLink: ["Als Link gesendet", "Sent as a link", "Enviado como enlace"],
  st_loading: ["Lädt …", "Loading …", "Cargando …"],
  st_playing: ["Läuft", "Playing", "Reproduciendo"],
  st_paused: ["Pausiert", "Paused", "En pausa"],
  st_stopped: ["Beendet", "Stopped", "Terminado"],
  st_idle: ["Bereit", "Ready", "Listo"],
  notShown: ["Der Rahmen zeigt das Video noch nicht an.", "The frame is not showing the video yet.", "El marco aún no muestra el vídeo."],
  mutedNote: ["Ohne Ton gestartet: der Rahmen lässt Ton ohne Berührung nicht zu.", "Started without sound: the frame does not allow sound without a touch.",
    "Empezó sin sonido: el marco no permite sonido sin un toque."],
  errorNote: ["Der Player meldet Fehler {code}.", "The player reports error {code}.", "El reproductor indica el error {code}."],
  version: ["Version {v}", "Version {v}", "Versión {v}"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noAnswer: ["Das Plugin antwortet nicht. Läuft es?", "The plugin does not answer. Is it running?", "El plugin no responde. ¿Está en marcha?"],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}). Gleich noch einmal.", "The plugin is restarting (HTTP {status}). Try again in a moment.",
    "El plugin se está reiniciando (HTTP {status}). Inténtalo de nuevo en un momento."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
};
const LANGS = ["de", "en", "es"];
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return false;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  renderIosUrl();
  return true;
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([502, 503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setNote(id, text, tone = "") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

function mmss(seconds) {
  seconds = Math.max(0, Math.floor(seconds || 0));
  const h = Math.floor(seconds / 3600), m = Math.floor((seconds % 3600) / 60), s = seconds % 60;
  const pad = (n) => String(n).padStart(2, "0");
  return h ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

function sendUrl() {
  const url = current && current.phoneUrl;
  return url ? `${url.replace(/\/$/, "")}/send` : "http://…:8090/send";
}

function renderIosUrl() {
  const item = document.querySelector('[data-i18n-html="ios3"]');
  if (item) item.innerHTML = t("ios3", { url: sendUrl() });
}

// ---------------------------------------------------------------- Anzeige

function render(state) {
  current = state;
  applyTheme(state.theme);
  applyLanguage(state.settings.Language);
  const p = state.player;
  const playing = !!p.videoId;
  el("nowEmpty").hidden = playing;
  el("nowBox").hidden = !playing;
  if (playing) {
    const thumb = `https://i.ytimg.com/vi/${encodeURIComponent(p.videoId)}/mqdefault.jpg`;
    if (el("nowThumb").getAttribute("src") !== thumb) el("nowThumb").src = thumb;
    el("nowTitle").textContent = p.title || p.videoId;
    const from = p.source === "cast" ? t("fromCast", { who: p.sender || "YouTube" }) : t("fromLink");
    el("nowMeta").textContent = [t(`st_${p.status}`), p.author, from].filter(Boolean).join(" · ");
    el("nowTime").textContent = mmss(p.position);
    el("nowDuration").textContent = mmss(p.duration);
    el("nowFill").style.width = p.duration ? `${Math.min(100, (p.position / p.duration) * 100)}%` : "0";
    const paused = p.desired === "pause";
    el("playPause").textContent = paused ? t("resume") : t("pause");
    el("playPause").dataset.action = paused ? "play" : "pause";
    el("nextButton").hidden = !p.hasNext;
    if (!draggingVolume) el("volume").value = p.muted ? 0 : p.volume;
  }
  let note = "", tone = "";
  if (p.error) { note = t("errorNote", { code: p.error }); tone = "bad"; }
  else if (state.note) { note = state.note; tone = "bad"; }
  else if (playing && p.blocked) { note = t("mutedNote"); tone = "busy"; }
  else if (playing && !state.showing && p.status === "loading") { note = t("notShown"); tone = "busy"; }
  else if (state.lastError) { note = state.lastError; tone = "bad"; }
  setNote("statusNote", note, tone);
  el("permissionNote").hidden = !state.permission;
  el("permissionNote").textContent = state.permission || "";

  if (PHONE) return;
  const cast = state.cast;
  el("factCast").textContent = cast.text;
  el("factCast").className = cast.state === "ready" ? "ok" : cast.state === "error" ? "bad" : "busy";
  el("factWifi").textContent = cast.wifi ? t("yes") : t("noWifi", { error: cast.wifiError || "?" });
  el("factWifi").className = cast.wifi ? "ok" : "bad";
  el("factSenders").textContent = cast.senders.length ? cast.senders.join(", ") : t("nobody");
  if (!editing) {
    el("DeviceName").value = state.settings.DeviceName;
    el("PauseMinutes").value = state.settings.PauseMinutes;
  }
  el("WakeScreen").checked = state.settings.WakeScreen;
  el("Sound").checked = state.settings.Sound;
  el("Language").value = lang;
  const link = el("phoneUrl");
  link.textContent = state.phoneUrl || "—";
  link.href = state.phoneUrl || "#";
  renderIosUrl();
  const list = el("recentList");
  list.replaceChildren();
  if (!state.recent.length) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = t("noRecent");
    list.append(li);
  }
  for (const row of state.recent) {
    const li = document.createElement("li");
    const what = document.createElement("span");
    what.className = "what";
    what.textContent = row.title || row.videoId;
    const again = document.createElement("button");
    again.type = "button";
    again.className = "secondary";
    again.textContent = t("again");
    again.addEventListener("click", () => play(row.videoId));
    li.append(what, again);
    list.append(li);
  }
  el("versionNote").textContent = t("version", { v: state.version });
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setNote("statusNote", error.message, "bad");
  }
}

async function save(changes) {
  try {
    await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    setNote("statusNote", t("saved"), "ok");
    await refresh();
  } catch (error) {
    setNote("statusNote", error.message, "bad");
  }
}

async function control(body) {
  try {
    await api("./api/control", { method: "POST", body: JSON.stringify(body) });
    setTimeout(refresh, 400);
  } catch (error) {
    setNote("statusNote", error.message, "bad");
  }
}

async function play(text) {
  setNote("sendNote", t("sending"), "busy");
  try {
    const result = await api("./api/send", { method: "POST", body: JSON.stringify({ url: text }) });
    setNote("sendNote", result.message || "", "ok");
    el("sendUrl").value = "";
    setTimeout(refresh, 500);
  } catch (error) {
    setNote("sendNote", error.message, "bad");
  }
}

// ---------------------------------------------------------------- Eingaben

el("sendForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const text = el("sendUrl").value.trim();
  if (text) play(text);
});
for (const button of document.querySelectorAll(".controls button")) {
  button.addEventListener("click", () => {
    const action = button.dataset.action;
    control(action === "skip" ? { action, by: Number(button.dataset.by) } : { action });
  });
}
el("nowFill").parentElement.addEventListener("click", (event) => {
  const p = current && current.player;
  if (!p || !p.duration) return;
  const box = event.currentTarget.getBoundingClientRect();
  control({ action: "seek", to: ((event.clientX - box.left) / box.width) * p.duration });
});
el("volume").addEventListener("input", () => { draggingVolume = true; });
el("volume").addEventListener("change", () => {
  draggingVolume = false;
  const volume = Number(el("volume").value);
  control({ action: "volume", volume, muted: volume === 0 });
});
el("testButton").addEventListener("click", () => control({ action: "test" }));

if (!PHONE) {
  el("Language").addEventListener("change", (e) => {
    applyLanguage(e.target.value);
    save({ Language: e.target.value });
  });
  for (const id of ["WakeScreen", "Sound"]) el(id).addEventListener("change", (e) => save({ [id]: e.target.checked }));
  for (const id of ["DeviceName", "PauseMinutes"]) {
    el(id).addEventListener("focus", () => { editing = true; });
    el(id).addEventListener("blur", () => { editing = false; });
    el(id).addEventListener("change", (e) => save({ [id]: id === "PauseMinutes" ? Number(e.target.value) : e.target.value }));
  }
  el("codeButton").addEventListener("click", async () => {
    const fresh = el("codeOut").textContent ? "?fresh=1" : "";
    setNote("codeNote", "…", "busy");
    try {
      const result = await api(`./api/pairing${fresh}`);
      el("codeOut").textContent = result.code;
      el("codeButton").textContent = t("newCode");
      setNote("codeNote", t("codeValid"), "");
    } catch (error) {
      setNote("codeNote", error.message, "bad");
    }
  });
}

refresh();
setInterval(refresh, 2000);
