/* Sing-along - die Szene.
 *
 * Fragt jede Sekunde beim Plugin nach (api/scene?have=<key>): was läuft, die
 * Position im Lied zum Zeitpunkt der Antwort, ob gerade gespielt wird, und
 * (nur wenn neu) die Zeilen des Liedtexts mit Zeitstempeln. Dazwischen rechnet
 * die Szene die Position selbst weiter (requestAnimationFrame), schiebt die
 * aktuelle Zeile in die Mitte und färbt sie wie beim Karaoke von links nach
 * rechts ein. Instrumentale Pausen zeigen drei Punkte, die nacheinander
 * aufleuchten. Das Cover kommt über das Plugin (api/cover/<key>).
 *
 * Zum Ausprobieren im Browser: ?demo=1 (&look=cover|backdrop|lyrics
 * &size=small|normal|large &lang=de|en|es &state=idle|none|plain|paused)
 * &plugin=<URL>.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "SingAlong";
  const POLL_MS = 1000;
  const params = new URLSearchParams(location.search);
  const DEMO = params.get("demo");
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const sameOrigin = (location.protocol === "http:" && (location.port === "" || location.port === "80"))
    || (location.protocol === "https:" && (location.port === "" || location.port === "443"));
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set(sameOrigin ? [
    `${location.origin}${advanced}`,
    `${location.protocol}//${location.hostname}:8003${advanced}`
  ] : [
    `${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`,
    `http://${location.hostname || "localhost"}${advanced}`
  ])];
  let baseIndex = 0;
  let base = pluginBases[0];

  const TEXT = {
    de: { idle: "Gerade läuft keine Musik", idleHint: "Starte Musik über Music Assistant, Spotify oder Jellyfin, dann erscheint hier der Liedtext.",
      none: "Kein Liedtext gefunden", noneHint: "Für dieses Lied hat LRCLIB noch keinen Text. Einfach mitsummen.",
      instrumental: "Instrumental", instrumentalHint: "Dieses Stück hat keinen Gesang. Einfach zuhören.",
      loading: "Suche den Liedtext …", error: "LRCLIB ist gerade nicht erreichbar", errorHint: "Der Text kommt, sobald die Verbindung wieder steht.",
      paused: "Pause", plain: "Text ohne Zeitangaben",
      unreachable: "Sing-along antwortet nicht.", login: "Bitte zuerst im Browser beim Rahmen anmelden." },
    en: { idle: "No music is playing", idleHint: "Start music via Music Assistant, Spotify or Jellyfin and the lyrics appear here.",
      none: "No lyrics found", noneHint: "LRCLIB has no lyrics for this song yet. Just hum along.",
      instrumental: "Instrumental", instrumentalHint: "This track has no vocals. Just listen.",
      loading: "Looking for the lyrics …", error: "LRCLIB cannot be reached right now", errorHint: "The lyrics appear as soon as the connection is back.",
      paused: "Paused", plain: "Lyrics without timing",
      unreachable: "Sing-along is not responding.", login: "Please sign in to the frame in the browser first." },
    es: { idle: "No suena música", idleHint: "Pon música en Music Assistant, Spotify o Jellyfin y la letra aparecerá aquí.",
      none: "No se encontró la letra", noneHint: "LRCLIB aún no tiene la letra de esta canción. Tararéala.",
      instrumental: "Instrumental", instrumentalHint: "Esta pieza no tiene voz. Solo escucha.",
      loading: "Buscando la letra …", error: "LRCLIB no está accesible ahora", errorHint: "La letra aparecerá en cuanto vuelva la conexión.",
      paused: "Pausa", plain: "Letra sin tiempos",
      unreachable: "Sing-along no responde.", login: "Inicia sesión primero en el marco desde el navegador." }
  };
  let lang = params.get("lang") || "en";
  const tx = (key) => (TEXT[lang] || TEXT.en)[key];
  const el = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const mmss = (s) => { s = Math.max(0, Math.floor(s || 0)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; };

  const MIC = `<svg viewBox="0 0 120 120" aria-hidden="true"><rect x="40" y="10" width="40" height="64" rx="20" fill="#f4efff"/>
    <path d="M26 56 a34 34 0 0 0 68 0" fill="none" stroke="#f4efff" stroke-width="8" stroke-linecap="round"/>
    <path d="M60 92 v16 M44 110 h32" stroke="#f4efff" stroke-width="8" stroke-linecap="round"/></svg>`;
  const NOTE = `<svg viewBox="0 0 120 120" aria-hidden="true"><path d="M48 90 V28 l46 -10 v58" fill="none" stroke="#f4efff" stroke-width="8" stroke-linejoin="round"/>
    <circle cx="36" cy="90" r="14" fill="#f4efff"/><circle cx="82" cy="78" r="14" fill="#f4efff"/></svg>`;
  el("micIcon").innerHTML = MIC;
  el("coverEmpty").innerHTML = NOTE;

  // ------------------------------------------------------------ Bühne skalieren

  function fit() {
    const s = Math.min(innerWidth / 1920, innerHeight / 1080);
    el("stage").style.transform = `translate(-50%, -50%) scale(${s})`;
  }
  addEventListener("resize", fit);
  fit();

  // ------------------------------------------------------------ Zustand

  let data = null;          // letzte Antwort
  let receivedAt = 0;       // performance.now() bei der Antwort
  let lyricsKey = "";
  let rows = [];            // [{t, text}] mit eingefügten Pausen
  let plain = [];
  let kind = "idle";
  let current = -2;
  let trackId = null;
  let coverSrc = "";

  function position() {
    if (!data || !data.track) return 0;
    const run = data.playing ? (performance.now() - receivedAt) / 1000 : 0;
    const dur = data.track.duration || 0;
    const pos = data.position + run;
    return dur ? Math.min(pos, dur) : pos;
  }

  // Pausen: leere Zeilen und lange Vorspiele werden zu "Punkten"
  function prepare(lines) {
    const out = [];
    const list = (lines || []).filter((r) => r && typeof r.t === "number");
    if (list.length && list[0].t > 4) out.push({ t: 0, text: "", gap: true, end: list[0].t });
    list.forEach((row, i) => {
      const next = list[i + 1];
      const end = next ? next.t : row.t + 6;
      if (!row.text) {
        if (end - row.t >= 4) out.push({ t: row.t, text: "", gap: true, end });
        return;
      }
      out.push({ t: row.t, text: row.text, end });
    });
    return out;
  }

  // Jedes Wort ein eigenes <span>: so läuft die Karaoke-Farbe bei einer
  // umgebrochenen Zeile erst durch die erste, dann durch die zweite Zeile.
  function words(text) {
    return String(text).split(/(\s+)/).map((part) => /^\s+$/.test(part) ? " "
      : part ? `<span class="w">${esc(part)}</span>` : "").join("");
  }

  function fillWords(node, p) {
    const list = node._words || (node._words = Array.from(node.querySelectorAll(".w")).map((w) => [w, w.textContent.length]));
    const total = list.reduce((sum, [, n]) => sum + n, 0) || 1;
    let done = p * total;
    for (const [w, n] of list) {
      const f = Math.max(0, Math.min(1, done / n));
      done -= n;
      const value = `${(f * 100).toFixed(1)}%`;
      if (w._f !== value) { w._f = value; w.style.setProperty("--w", value); }
    }
  }

  function buildLines() {
    const box = el("lines");
    current = -2;
    if (kind === "synced") {
      box.innerHTML = rows.map((r, i) => r.gap
        ? `<p class="ln gap" data-i="${i}"><i></i><i></i><i></i></p>`
        : `<p class="ln" data-i="${i}">${words(r.text)}</p>`).join("");
    } else if (kind === "plain") {
      box.innerHTML = plain.map((line) => `<p class="ln plain">${esc(line) || "&nbsp;"}</p>`).join("");
    } else {
      box.innerHTML = "";
    }
    box.style.transform = "translateY(0)";
  }

  function indexAt(pos) {
    let lo = 0, hi = rows.length - 1, found = -1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      if (rows[mid].t <= pos) { found = mid; lo = mid + 1; } else hi = mid - 1;
    }
    return found;
  }

  function centre(node) {
    const view = el("lyrics");
    const y = node.offsetTop + node.offsetHeight / 2;
    el("lines").style.transform = `translateY(${Math.round(view.clientHeight / 2 - y)}px)`;
  }

  function setCurrent(i) {
    if (i === current) return;
    current = i;
    const nodes = el("lines").children;
    for (let k = 0; k < nodes.length; k += 1) {
      const n = nodes[k];
      n.classList.toggle("cur", k === i);
      n.classList.toggle("near", k === i + 1 || k === i - 1);
      n.classList.toggle("past", k < i - 1);
      n.classList.toggle("timed", k === i && !rows[k].gap);
    }
    const target = nodes[Math.max(0, i)];
    if (target) centre(target);
  }

  function frame() {
    requestAnimationFrame(frame);
    if (!data || !data.track) return;
    const pos = position();
    const dur = data.track.duration || 0;
    el("bar").style.width = dur ? `${Math.min(100, (pos / dur) * 100).toFixed(2)}%` : "0%";
    el("elapsed").textContent = mmss(pos);
    el("total").textContent = dur ? mmss(dur) : "";
    if (kind === "synced" && rows.length) {
      const lpos = pos + (data.offset || 0);
      const i = indexAt(lpos);
      setCurrent(i);
      if (i >= 0) {
        const row = rows[i];
        const node = el("lines").children[i];
        const span = Math.max(0.3, (row.end - row.t));
        const p = Math.max(0, Math.min(1, (lpos - row.t) / Math.min(span, row.gap ? span : Math.max(1.2, span * .92))));
        if (row.gap) {
          const dots = node.children;
          for (let d = 0; d < dots.length; d += 1) dots[d].classList.toggle("on", p > (d + 1) / (dots.length + 1));
        } else {
          fillWords(node, p);
        }
      }
    } else if (kind === "plain" && plain.length && dur) {
      // Ohne Zeiten: gleichmäßig mitscrollen
      const box = el("lines");
      const view = el("lyrics");
      const travel = Math.max(0, box.scrollHeight - view.clientHeight * .5);
      const frac = Math.max(0, Math.min(1, (pos - 8) / Math.max(30, dur - 20)));
      box.style.transform = `translateY(${Math.round(view.clientHeight * .3 - travel * frac)}px)`;
    }
  }
  requestAnimationFrame(frame);

  // ------------------------------------------------------------ Anzeige

  function setCover(url) {
    if (url === coverSrc) return;
    coverSrc = url;
    const box = el("cover");
    const old = box.querySelector("img");
    if (!url) {
      if (old) old.remove();
      el("coverEmpty").hidden = false;
      el("bgImg").style.backgroundImage = "";
      document.documentElement.style.removeProperty("--accent");
      return;
    }
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      if (coverSrc !== url) return;
      box.appendChild(img);
      requestAnimationFrame(() => img.classList.add("on"));
      if (old) setTimeout(() => old.remove(), 900);
      el("coverEmpty").hidden = true;
      el("bgImg").style.backgroundImage = `url("${url}")`;
      accentFrom(img);
    };
    img.onerror = () => { if (coverSrc === url) el("coverEmpty").hidden = false; };
    img.src = url;
  }

  // Leuchtfarbe für Karaoke und Fortschritt aus dem Cover
  function accentFrom(img) {
    try {
      const c = document.createElement("canvas");
      c.width = c.height = 24;
      const g = c.getContext("2d");
      g.drawImage(img, 0, 0, 24, 24);
      const px = g.getImageData(0, 0, 24, 24).data;
      let best = null, bestScore = -1;
      for (let k = 0; k < px.length; k += 4) {
        const r = px[k], gg = px[k + 1], b = px[k + 2];
        const max = Math.max(r, gg, b), min = Math.min(r, gg, b);
        const sat = max ? (max - min) / max : 0;
        const score = sat * 0.7 + (max / 255) * 0.3;
        if (score > bestScore && max > 70) { bestScore = score; best = [r, gg, b]; }
      }
      if (!best || bestScore < 0.35) { document.documentElement.style.removeProperty("--accent"); return; }
      // aufhellen, damit es auf dunklem Grund leuchtet
      const lift = (v) => Math.round(v + (255 - v) * 0.35);
      document.documentElement.style.setProperty("--accent", `rgb(${lift(best[0])}, ${lift(best[1])}, ${lift(best[2])})`);
    } catch (_) { /* Cover ohne CORS: Standardfarbe */ }
  }

  function message(big, small, withTrack) {
    const show = Boolean(big);
    el("message").hidden = !show;
    document.body.classList.toggle("with-message", show);
    document.body.classList.toggle("track", Boolean(withTrack));
    el("messageBig").textContent = big || "";
    el("messageSmall").textContent = small || "";
  }

  function apply(next) {
    data = next;
    receivedAt = performance.now();
    if (next.lang && TEXT[next.lang]) lang = next.lang;
    document.documentElement.lang = lang;
    const body = document.body;
    body.className = body.className.replace(/\b(look|size)-\w+/g, "").trim();
    body.classList.add(`look-${next.look || "cover"}`, `size-${next.size || "normal"}`);
    body.classList.toggle("no-progress", next.progress === false);
    body.classList.toggle("karaoke", next.karaoke !== false);

    const track = next.track;
    body.classList.toggle("idle", !track);
    if (!track) {
      trackId = null;
      setCover("");
      kind = "idle";
      rows = []; plain = []; lyricsKey = "";
      buildLines();
      message(tx("idle"), tx("idleHint"), false);
      ready();
      return;
    }
    if (track.id !== trackId) trackId = track.id;
    el("title").textContent = track.title || "";
    el("artist").textContent = track.artist || "";
    el("pausePill").hidden = next.playing;
    el("pausePill").textContent = tx("paused");
    setCover(next.cover ? (/^(https?:|data:|\/)/.test(next.cover) ? next.cover : base + next.cover) : "");

    const lyr = next.lyrics || {};
    const newKind = lyr.kind || "none";
    if (lyr.lines || lyr.plain) {
      lyricsKey = lyr.key || "";
      kind = newKind;
      rows = newKind === "synced" ? prepare(lyr.lines) : [];
      plain = newKind === "plain" ? (lyr.plain || []) : [];
      if (kind === "synced" && !rows.length) kind = "none";
      buildLines();
    } else if (!lyr.key && newKind !== kind) {
      lyricsKey = "";
      kind = newKind;
      rows = []; plain = [];
      buildLines();
    }
    if (kind === "synced" || kind === "plain") message("", "", true);
    else if (kind === "loading") message(tx("loading"), "", true);
    else if (kind === "instrumental") message(tx("instrumental"), tx("instrumentalHint"), true);
    else if (kind === "error") message(tx("error"), tx("errorHint"), true);
    else message(tx("none"), tx("noneHint"), true);
    ready();
  }

  // ------------------------------------------------------------ Mit dem Plugin reden

  let readySent = false;
  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 8000);

  function note(text) {
    el("note").hidden = !text;
    el("note").textContent = text || "";
  }

  async function poll() {
    let loginNeeded = false;
    for (let attempt = 0; attempt < pluginBases.length; attempt += 1) {
      const candidate = pluginBases[(baseIndex + attempt) % pluginBases.length];
      try {
        const response = await fetch(`${candidate}api/scene?have=${encodeURIComponent(lyricsKey)}`,
          { cache: "no-store", credentials: "same-origin" });
        if (response.redirected && response.url.includes("/dfr-login/")) { loginNeeded = true; throw new Error("login"); }
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const next = await response.json();
        baseIndex = (baseIndex + attempt) % pluginBases.length;
        base = candidate;
        note("");
        apply(next);
        return;
      } catch (_) { /* nächster Weg */ }
    }
    if (!data) {
      message(tx("idle"), "", false);
      note(tx(loginNeeded ? "login" : "unreachable"));
      ready();
    }
  }

  // ------------------------------------------------------------ Vorschau

  function demo() {
    // Eigener Beispieltext (frei erfunden), damit die Vorschau ohne fremde Liedtexte auskommt
    const words = {
      de: ["Der Rahmen hängt im Flur und summt", "die Fotos tanzen hin und her", "und wenn das Radio leise brummt",
        "dann singen wir ein bisschen mehr", "", "La la la, im Takt der Zeit", "jede Zeile leuchtet auf",
        "wer nicht mitsingt, ist bereit", "für den nächsten Refrain-Lauf"],
      en: ["The frame is humming in the hall", "the photos swaying to the beat", "and when the radio starts to call",
        "we sing along and tap our feet", "", "La la la, in time we go", "every line lights up in gold",
        "if you don't know the words, just hum", "the chorus waits for everyone"],
      es: ["El marco canta en el pasillo", "las fotos bailan sin parar", "y cuando suena un estribillo",
        "nos ponemos a cantar", "", "La la la, al compás", "cada línea brilla más",
        "quien no sepa la canción", "que tararee el corazón"]
    }[lang] || [];
    const lines = [];
    let t = 6;
    for (const w of words) { lines.push({ t, text: w }); t += w ? 4.2 : 6; }
    const state = params.get("state") || "";
    const startPos = Number(params.get("pos") || 13);
    const started = performance.now();
    const make = () => {
      const pos = startPos + (performance.now() - started) / 1000;
      const d = { lang, look: params.get("look") || "cover", size: params.get("size") || "normal", progress: true, karaoke: true, offset: 0,
        playing: state !== "paused", position: pos % 48,
        track: { id: "demo", title: "Hallway Humming", artist: "Sing-along", duration: 48, sourceLabel: "Demo" },
        cover: params.get("cover") || "",
        lyrics: { kind: state === "none" ? "none" : state === "plain" ? "plain" : "synced", key: `demo-${state}` } };
      if (lyricsKey !== d.lyrics.key) Object.assign(d.lyrics, { lines, plain: words });
      if (state === "idle") d.track = null;
      return d;
    };
    apply(make());
    setInterval(() => apply(make()), POLL_MS);
  }

  if (DEMO) demo();
  else {
    poll();
    setInterval(poll, POLL_MS);
  }
})();
