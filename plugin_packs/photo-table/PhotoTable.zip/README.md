# Photo Table

Viele deiner Fotos liegen als Abzüge verstreut auf einem Tisch (Holz, Leinen oder dunkel). Der ganze Tisch dreht sich langsam, mal mehr, mal weniger, mal links, mal rechts herum. Jedes Mal, wenn er stillsteht, liegen andere Fotos oben, fast gerade vor dir. Abzüge mit weißem Rand oder als Sofortbild mit Monat, Jahr und Ort in Handschrift.

Inspiriert von Geektoolkit.

Fotos aus der ganzen DynaFrame-Mediathek, aus Ordnern, Playlists oder von einem Immich-Server, mit den Filtern aus Photo Mosaic. Gezeichnet auf der Grafikkarte (WebGL), nur während sich der Tisch dreht.

Einstellungen: Plugins → Photo Table → „Open Photo Table“. Dort kannst du auch eine Playlist „Photo Table“ anlegen lassen.

Problem melden: https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=%5BPhoto%20Table%5D%20
