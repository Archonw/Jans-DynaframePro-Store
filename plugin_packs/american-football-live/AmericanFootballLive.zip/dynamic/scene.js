/* American Football Live - die Szene.
 *
 * Daten kommen vom Plugin American Football Live, über den Proxy der
 * Weboberfläche auf :8003 (der Proxy der Engine lehnt lokale Adressen ab).
 * Antwortet das Plugin nicht, liest die Szene die NFL (ESPN) selbst über
 * DynaFrameScene.fetchExternalJson.
 * Mit ?demo=1 zeigt sie Beispieldaten (zum Ansehen im Browser).
 *
 * Die Seiten (eine je Liga) wechseln im eingestellten Takt. Die Szene
 * braucht keine Eingabe.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "AmericanFootballLive";
  const POLL_MS = 15000;
  const FALLBACK_POLL_MS = 60000;
  const params = new URLSearchParams(location.search);
  const DEMO = params.has("demo");
  // Über Port 80 (RemoteFrame, WebUI) gleicher Ursprung: Port 8003 lehnt fremde Origins ab.
  const pluginBase = params.get("plugin") ||
    (location.protocol.startsWith("http") && (location.port === "" || location.port === "80")
      ? `${location.origin}/Plugins/Advanced/${PLUGIN_ID}/`
      : `${location.protocol}//${location.hostname}:8003/Plugins/Advanced/${PLUGIN_ID}/`);

  const el = (id) => document.getElementById(id);
  const ui = {
    stage: el("stage"), accent: el("accent"), leagueName: el("leagueName"), roundName: el("roundName"),
    clock: el("clock"), updated: el("updated"), dots: el("dots"), page: el("page"),
    matches: el("matches"), table: el("table"), foot: el("foot")
  };

  let snapshot = null;      // {pages, pageSeconds, focus, at, mode}
  let pageIndex = 0;
  let scoredMatch = null;   // Spiel, dessentwegen das Plugin die Szene zeigt: roter Rahmen
  let holdPage = false;     // bei einer Tor-Anzeige bleibt die Seite der Liga stehen
  let focusId = null;       // die zuletzt befolgte Liga-Vorgabe des Plugins
  let pageTimer = null;
  let readySent = false;
  let lastScores = {};      // Spiel-id -> "21:17", um Punkte kurz aufleuchten zu lassen
  let flash = new Set();
  let mode = DEMO ? "demo" : "plugin";
  let pluginFailures = 0;

  // ---------------------------------------------------------------- helpers

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  function esc(text) {
    return String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  // Sprache: kommt mit den Daten vom Plugin (Einstellung auf der Plugin-Seite),
  // zum Ansehen im Browser auch als ?lang=en.
  const TEXT = {
    de: { loading: "Ergebnisse werden geladen …", noLeague: "Keine Liga gewählt",
      noLeagueLong: "In den Einstellungen von American Football Live ist keine Liga gewählt.", moment: "Einen Moment …",
      match: "Spiel", matches: "Spiele", unreachable: "Die Ergebnisse sind gerade nicht erreichbar.",
      noMatches: "Diese Woche keine Spiele.", asOf: "Stand", data: "Daten",
      direct: "Plugin nicht erreichbar – Notbetrieb", demo: "Beispieldaten", today: "Heute", end: "Ende",
      ht: "Halbzeit", endQ: "Ende Q", ot: "n. V.", postponed: "verlegt", cancelled: "abgesagt", table: "Tabelle",
      club: "Team", played: "S-N", diff: "Diff", points: "%", live: "Live", liveCount: "live",
      week: "Woche", preseason: "Vorbereitung Woche", playoffs: "Play-offs" },
    en: { loading: "Loading results …", noLeague: "No league selected",
      noLeagueLong: "No league is selected in the American Football Live settings.", moment: "One moment …",
      match: "game", matches: "games", unreachable: "Results are not available right now.",
      noMatches: "No games this week.", asOf: "As of", data: "Data",
      direct: "Plugin not reachable – fallback mode", demo: "Sample data", today: "Today", end: "Final",
      ht: "Halftime", endQ: "End Q", ot: "OT", postponed: "postponed", cancelled: "canceled", table: "Standings",
      club: "Team", played: "W-L", diff: "Diff", points: "Pct", live: "Live", liveCount: "live",
      week: "Week", preseason: "Preseason week", playoffs: "Playoffs" },
    es: { loading: "Cargando resultados …", noLeague: "Ninguna liga elegida",
      noLeagueLong: "No hay ninguna liga elegida en los ajustes de American Football Live.", moment: "Un momento …",
      match: "partido", matches: "partidos", unreachable: "Los resultados no están disponibles ahora mismo.",
      noMatches: "No hay partidos esta semana.", asOf: "Act.", data: "Datos",
      direct: "Plugin no disponible – modo de emergencia", demo: "Datos de ejemplo", today: "Hoy", end: "Final",
      ht: "Descanso", endQ: "Fin C", ot: "Prór.", postponed: "aplazado", cancelled: "suspendido", table: "Clasificación",
      club: "Equipo", played: "G-P", diff: "Dif", points: "%", live: "En vivo", liveCount: "en vivo",
      week: "Semana", preseason: "Pretemporada, semana", playoffs: "Playoffs" }
  };
  const LOCALE = { de: "de-DE", en: "en-GB", es: "es-ES" };
  let lang = TEXT[params.get("lang")] ? params.get("lang") : "en";
  let T = TEXT[lang];
  let dayFmt, dateFmt, timeFmt;
  function setLanguage(next) {
    if (dayFmt && next === lang) return;
    lang = TEXT[next] ? next : "en";
    T = TEXT[lang];
    document.documentElement.lang = lang;
    dayFmt = new Intl.DateTimeFormat(LOCALE[lang], { weekday: "short" });
    dateFmt = new Intl.DateTimeFormat(LOCALE[lang], { day: "2-digit", month: "2-digit" });
    timeFmt = new Intl.DateTimeFormat(LOCALE[lang], { hour: "2-digit", minute: "2-digit" });
  }
  setLanguage(lang);
  // Das Plugin schickt die Woche schon übersetzt; im Notbetrieb kommt sie
  // auf Deutsch ("Woche 7").
  function roundText(text) {
    const m = /^\s*(Vorbereitung )?Woche (\d+)\s*$/.exec(text || "");
    if (m) return `${m[1] ? T.preseason : T.week} ${m[2]}`;
    return text === "Play-offs" ? T.playoffs : (text || "");
  }
  // Viertel und Uhr kommen sprachneutral ("Q3 4:21"), dazu einige Wörter.
  function minuteText(text) {
    const end = /^EQ(\d)$/.exec(text || "");
    if (end) return `${T.endQ}${end[1]}`;
    return { HZ: T.ht, EOT: `${T.end} OT`, verlegt: T.postponed, abgesagt: T.cancelled }[text] || text;
  }

  function initials(name) {
    const words = String(name || "?").replace(/[^\p{L}\p{N} ]/gu, "").split(/\s+/).filter((w) => w.length > 2 || /\d/.test(w));
    return (words.length ? words : [String(name || "?")]).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
  }

  function logoUrl(path) {
    if (!path) return "";
    if (/^https?:\/\//.test(path)) return path;
    return new URL(path, pluginBase).toString();
  }

  function logo(team) {
    const url = logoUrl(team.logo);
    const badge = `<span class="badge">${esc(initials(team.name))}</span>`;
    if (!url) return badge;
    // Ein Wappen, das nicht lädt, wird zum Kürzel (siehe den error-Listener
    // unten); kein Inline-Handler, dessen Anführungszeichen das Markup brechen.
    return `<img class="logo" src="${esc(url)}" alt="" data-badge="${esc(initials(team.name))}">`;
  }

  document.addEventListener("error", (event) => {
    const img = event.target;
    if (!(img instanceof HTMLImageElement) || !img.classList.contains("logo")) return;
    const badge = document.createElement("span");
    badge.className = "badge";
    badge.textContent = img.dataset.badge || "";
    img.replaceWith(badge);
  }, true);

  async function getJson(url) {
    if (window.DynaFrameScene?.fetchExternalJson) return window.DynaFrameScene.fetchExternalJson(url);
    const response = await fetch(url, { headers: { Accept: "application/json" } });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  }

  // ------------------------------------------------------------ data: plugin

  async function loadFromPlugin() {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
      const response = await fetch(new URL("api/scene", pluginBase), { signal: controller.signal, cache: "no-store" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      if (!data || !Array.isArray(data.pages)) throw new Error("unerwartete Antwort");
      data.mode = "plugin";
      return data;
    } finally {
      clearTimeout(timer);
    }
  }

  // ------------------------------------------------- data: direkt (Notfall)

  function espnMatch(event) {
    const comp = (event.competitions || [{}])[0];
    const cs = comp.competitors || [];
    const home = cs.find((c) => c.homeAway === "home") || cs[0] || {};
    const away = cs.find((c) => c.homeAway === "away") || cs[1] || {};
    const status = comp.status || event.status || {};
    const type = status.type || {};
    const off = ["STATUS_POSTPONED", "STATUS_CANCELED", "STATUS_ABANDONED", "STATUS_SUSPENDED"].includes(type.name);
    const state = off ? "off" : type.state === "in" ? "live" : (type.state === "post" || type.completed) ? "post" : "pre";
    const period = parseInt(status.period, 10) || 0;
    let minute = "";
    if (state === "live") {
      if (type.name === "STATUS_HALFTIME") minute = "HZ";
      else if (type.name === "STATUS_END_PERIOD") minute = period <= 4 ? `EQ${period}` : "EOT";
      else if (period) minute = `${period <= 4 ? `Q${period}` : "OT"} ${status.displayClock || ""}`.trim();
    } else if (off) minute = "verlegt";
    else if (state === "post" && period > 4) minute = "OT";
    const side = (c) => ({
      name: c.team?.displayName || "?", short: c.team?.shortDisplayName || c.team?.displayName || "?",
      logo: c.team?.logo || c.team?.logos?.[0]?.href || "", record: c.records?.[0]?.summary || ""
    });
    const score = (c) => (state === "live" || state === "post") ? parseInt(c.score, 10) : null;
    const holder = String(comp.situation?.possession || "");
    const possession = state !== "live" || !holder ? "" : holder === String(home.team?.id) ? "home" : holder === String(away.team?.id) ? "away" : "";
    return {
      id: `espn-${event.id}`, kickoff: Date.parse(event.date) / 1000 || 0, state, minute,
      home: side(home), away: side(away), scoreHome: score(home), scoreAway: score(away), possession,
      down: state === "live" ? (comp.situation?.shortDownDistanceText || comp.situation?.downDistanceText || "") : ""
    };
  }

  async function loadDirect() {
    const page = { id: "nfl", name: "NFL", color: "#1d4ed8", round: "", matches: [], table: null, source: "ESPN", updatedAt: Date.now() / 1000, error: "" };
    try {
      const data = await getJson("https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard");
      page.matches = (data?.events || []).map(espnMatch).sort((a, b) => a.kickoff - b.kickoff);
      const week = data?.week?.number;
      page.round = week ? (data?.season?.type === 3 ? "Play-offs" : `Woche ${week}`) : "";
    } catch (error) {
      page.error = String(error.message || error);
    }
    return { mode: "direct", pageSeconds: 20, focus: null, at: Date.now() / 1000, pages: [page] };
  }

  // ------------------------------------------------------------ data: demo

  function demoData() {
    const t = Date.now() / 1000;
    const m = (id, h, a, sh, sa, state, offset, minute, extra) => ({
      id, kickoff: t + offset, state, minute: minute || "",
      home: { name: h, short: h, logo: "", record: "5-1" }, away: { name: a, short: a, logo: "", record: "3-3" },
      scoreHome: sh, scoreAway: sa, possession: "", down: "", ...(extra || {})
    });
    const teams = ["Chiefs", "Bills", "Ravens", "Steelers", "Texans", "Broncos", "Chargers", "Colts", "Bengals", "Jaguars",
      "Dolphins", "Jets", "Patriots", "Raiders", "Browns", "Titans"];
    const table = [];
    teams.forEach((name, i) => table.push({ rank: i + 1, team: { name, short: name, logo: "" }, played: `${6 - (i >> 2)}-${i >> 2}`, diff: 60 - i * 8, points: (1 - (i >> 2) / 6).toFixed(3).replace(/^0/, ""), group: "AFC" }));
    ["Lions", "Eagles", "Packers", "Vikings", "49ers", "Commanders", "Buccaneers", "Rams", "Seahawks", "Cardinals",
      "Falcons", "Bears", "Cowboys", "Saints", "Giants", "Panthers"].forEach((name, i) =>
      table.push({ rank: i + 1, team: { name, short: name, logo: "" }, played: `${6 - (i >> 2)}-${i >> 2}`, diff: 55 - i * 8, points: (1 - (i >> 2) / 6).toFixed(3).replace(/^0/, ""), group: "NFC" }));
    return {
      mode: "demo", pageSeconds: 12, focus: null, at: t,
      pages: [
        { id: "nfl", name: "NFL", color: "#1d4ed8", round: "Woche 7", source: "Demo", updatedAt: t, error: "", table,
          matches: [
            m("1", "Chiefs", "Bills", 21, 17, "live", -7200, "Q3 4:21", { possession: "home", down: "3rd & 7 at BUF 35" }),
            m("2", "Lions", "Packers", 10, 10, "live", -5400, "HZ"),
            m("3", "Eagles", "Cowboys", 27, 24, "post", -86400, "OT"),
            m("4", "Ravens", "Steelers", 31, 14, "post", -80000),
            m("5", "Texans", "Colts", 20, 23, "post", -80000),
            m("6", "Broncos", "Raiders", 17, 9, "post", -80000),
            m("7", "49ers", "Rams", null, null, "pre", 9000),
            m("8", "Vikings", "Bears", null, null, "pre", 9000),
            m("9", "Dolphins", "Jets", null, null, "pre", 86400 + 5400)
          ] },
        { id: "ncaaf", name: "College Football (Top 25)", color: "#c8102e", round: "Woche 8", source: "Demo", updatedAt: t, error: "", table: null,
          matches: ["Georgia|Alabama", "Ohio State|Michigan", "Texas|Oklahoma", "Oregon|USC", "Penn State|Iowa", "Notre Dame|Navy",
            "LSU|Ole Miss", "Clemson|Miami", "Tennessee|Florida", "Utah|BYU", "Missouri|Auburn", "Kansas State|Iowa State"].map((pair, i) => {
            const [h, a] = pair.split("|");
            return i < 6 ? m(`c${i}`, h, a, 14 + i * 3, 10 + i * 2, "post", -86400) : m(`c${i}`, h, a, null, null, "pre", 2 * 86400);
          }) }
      ]
    };
  }

  // ----------------------------------------------------------------- render

  function kickoffText(match) {
    if (!match.kickoff) return "";
    const date = new Date(match.kickoff * 1000);
    const today = new Date();
    const sameDay = date.toDateString() === today.toDateString();
    const day = sameDay ? T.today : dayFmt.format(date).replace(".", "");
    return { top: day, bottom: timeFmt.format(date), date: dateFmt.format(date) };
  }

  function whenCell(match) {
    if (match.state === "live") return `<div class="when"><b><span class="pulse"></span>${esc(minuteText(match.minute) || T.live)}</b>${esc(T.live)}</div>`;
    if (match.state === "off") return `<div class="when"><b>${esc(minuteText(match.minute) || T.postponed)}</b></div>`;
    const k = kickoffText(match);
    if (match.state === "post") {
      return `<div class="when"><b>${esc(match.minute === "OT" ? `${T.end}/${T.ot}` : T.end)}</b>${esc(k ? `${k.top} ${k.date}` : "")}</div>`;
    }
    return `<div class="when"><b>${esc(k.top || "")}</b>${esc(k.date || "")}</div>`;
  }

  function scoreCell(match) {
    if (match.state === "pre" || match.state === "off" || match.scoreHome === null || match.scoreHome === undefined) {
      const k = kickoffText(match);
      return `<div class="score pre">${esc(match.state === "off" ? "–:–" : (k.bottom || "–:–"))}</div>`;
    }
    return `<div class="score">${esc(match.scoreHome)}:${esc(match.scoreAway)}</div>`;
  }

  // Unter dem Namen: im Spiel Ballbesitz und Down, sonst die Bilanz.
  function infoLine(match, side) {
    if (match.state === "live") {
      if (match.possession !== side) return "";
      return `<small class="ball">🏈${match.down ? " " + esc(match.down) : ""}</small>`;
    }
    const record = match[side].record;
    return record ? `<small>${esc(record)}</small>` : "";
  }

  function matchRow(match) {
    const decided = match.state === "post" && match.scoreHome !== null;
    const homeLost = decided && match.scoreHome < match.scoreAway;
    const awayLost = decided && match.scoreAway < match.scoreHome;
    const classes = ["match", match.state, flash.has(match.id) ? "goal" : "",
      scoredMatch !== null && String(match.id) === scoredMatch ? "scored" : ""].join(" ");
    return `<div class="${classes}">
      ${whenCell(match)}
      <div class="team home${homeLost ? " lost" : ""}"><span class="name">${esc(match.home.short || match.home.name)}${infoLine(match, "home")}</span>${logo(match.home)}</div>
      ${scoreCell(match)}
      <div class="team away${awayLost ? " lost" : ""}">${logo(match.away)}<span class="name">${esc(match.away.short || match.away.name)}${infoLine(match, "away")}</span></div>
    </div>`;
  }

  // Grün markiert: Play-off-Plätze (7 je Conference in der NFL), bei den
  // College-Conferences die zwei Plätze fürs Championship Game, bei kleinen
  // Gruppen (Divisions) der Erste.
  const COLLEGE = new Set(["sec", "b1g", "b12", "acc"]);
  function zoneClass(page, rank, groupSize) {
    const places = COLLEGE.has(page.id) ? 2 : groupSize > 8 ? 7 : 1;
    return rank <= places ? "zone-cl" : "";
  }

  function tableHtml(page, liveNames) {
    const rows = page.table.slice(0, 40);
    const sizes = {};
    rows.forEach((r) => { sizes[r.group || ""] = (sizes[r.group || ""] || 0) + 1; });
    const groups = Object.keys(sizes).filter(Boolean).length;
    const lines = rows.length + (groups > 1 ? groups : 0);
    const font = lines > 30 ? .74 : lines > 22 ? .84 : lines > 18 ? .92 : 1;
    let last = null;
    const html = rows.map((r) => {
      let head = "";
      if (groups > 1 && r.group !== last) {
        last = r.group;
        head = `<div class="row group"><span></span><span></span><span class="name">${esc(r.group)}</span></div>`;
      }
      const live = liveNames.has(r.team.name) || liveNames.has(r.team.short);
      return `${head}<div class="row ${zoneClass(page, r.rank, sizes[r.group || ""])}${live ? " live" : ""}">
        <span class="rank">${esc(r.rank)}</span>${logo(r.team)}<span class="name">${esc(r.team.short || r.team.name)}</span>
        <span class="num">${esc(r.played)}</span><span class="num">${r.diff > 0 ? "+" : ""}${esc(r.diff)}</span><span class="pts">${esc(r.points)}</span>
      </div>`;
    }).join("");
    return `<h2>${esc(T.table)}</h2>
      <div class="rows" style="--row-font:${font}rem">
        <div class="row head"><span>#</span><span></span><span>${esc(T.club)}</span><span class="num">${esc(T.played)}</span><span class="num">${esc(T.diff)}</span><span class="pts">${esc(T.points)}</span></div>
        ${html}
      </div>`;
  }

  function render() {
    const pages = (snapshot?.pages || []).filter(Boolean);
    if (!pages.length) {
      ui.leagueName.textContent = "American Football Live";
      ui.roundName.textContent = snapshot ? T.noLeague : T.loading;
      ui.matches.className = "matches";
      ui.matches.innerHTML = `<div class="empty">${esc(snapshot ? T.noLeagueLong : T.moment)}</div>`;
      ui.table.hidden = true;
      ui.page.classList.remove("with-table");
      return;
    }
    pageIndex %= pages.length;
    const page = pages[pageIndex];
    const team = snapshot.team;
    document.documentElement.style.setProperty("--accent", (team?.useColors && team.accent) || page.color || "#d20515");
    ui.leagueName.textContent = page.name;
    const round = roundText(page.round);
    ui.roundName.textContent = round;

    const matches = page.matches || [];
    const liveCount = matches.filter((m) => m.state === "live").length;
    if (liveCount) ui.roundName.textContent = `${round ? round + " · " : ""}${liveCount} ${liveCount === 1 ? T.match : T.matches} ${T.liveCount}`;

    const hasTable = Array.isArray(page.table) && page.table.length > 0;
    const portrait = innerHeight > innerWidth;
    ui.page.classList.toggle("with-table", hasTable);
    // Eine NFL-Woche hat bis zu 16 Spiele: zwei Spalten nur ohne Tabelle im
    // Querformat, sonst eine Spalte mit engeren Zeilen.
    const two = !portrait && !hasTable && matches.length > 12;
    const dense = (two ? Math.ceil(matches.length / 2) : matches.length) > 10;
    ui.matches.className = `matches${two ? " two" : ""}${dense ? " dense" : ""}${matches.length && matches.length < 6 ? " few" : ""}`;
    if (matches.length) {
      ui.matches.innerHTML = matches.map(matchRow).join("");
      if (two) ui.matches.style.gridTemplateRows = `repeat(${Math.ceil(matches.length / 2)}, minmax(0, 1fr))`;
      else ui.matches.style.gridTemplateRows = "";
    } else {
      ui.matches.style.gridTemplateRows = "";
      ui.matches.innerHTML = `<div class="empty">${esc(page.error ? T.unreachable : T.noMatches)}</div>`;
    }
    if (hasTable) {
      const liveNames = new Set();
      matches.filter((m) => m.state === "live").forEach((m) => {
        [m.home.name, m.home.short, m.away.name, m.away.short].forEach((n) => liveNames.add(n));
      });
      ui.table.innerHTML = tableHtml(page, liveNames);
    }
    ui.table.hidden = !hasTable;

    ui.dots.innerHTML = pages.length > 1 ? pages.map((_, i) => `<span class="${i === pageIndex ? "on" : ""}"></span>`).join("") : "";
    renderMeta(page);
  }

  function renderMeta(page) {
    const at = page?.updatedAt || snapshot?.at;
    const age = at ? Date.now() / 1000 - at : Infinity;
    const stale = age > 15 * 60 || (page && page.error);
    ui.updated.textContent = at ? `${T.asOf} ${timeFmt.format(new Date(at * 1000))}` : "";
    ui.updated.classList.toggle("stale", Boolean(stale));
    const source = page?.source ? `${T.data}: ${page.source}` : "";
    const note = mode === "direct" ? T.direct : mode === "demo" ? T.demo : "";
    ui.foot.innerHTML = `<span>${esc(source)}</span><span class="${note && mode !== "demo" ? "warn" : ""}">${esc(note)}</span>`;
  }

  function tickClock() {
    ui.clock.textContent = timeFmt.format(new Date());
  }

  // --------------------------------------------------------------- rotation

  function schedulePage() {
    clearTimeout(pageTimer);
    const pages = snapshot?.pages || [];
    if (pages.length < 2 || holdPage) return;
    const seconds = Math.max(5, Number(snapshot.pageSeconds) || 20);
    pageTimer = setTimeout(() => {
      ui.page.classList.add("fade");
      setTimeout(() => {
        pageIndex = (pageIndex + 1) % pages.length;
        render();
        ui.page.classList.remove("fade");
        schedulePage();
      }, 450);
    }, seconds * 1000);
  }

  let crestUrl = "";
  function applyCrest(team) {
    const url = team?.logo ? logoUrl(team.logo) : "";
    if (url === crestUrl) return;
    crestUrl = url;
    if (!url) {
      ui.stage.classList.remove("crested");
      ui.stage.style.removeProperty("--crest");
      return;
    }
    // Erst zeigen, wenn das Bild wirklich lädt.
    const probe = new Image();
    probe.onload = () => {
      if (crestUrl !== url) return;
      ui.stage.style.setProperty("--crest", `url("${url.replace(/["\\]/g, "")}")`);
      ui.stage.classList.add("crested");
    };
    probe.src = url;
  }

  function applySnapshot(data, first) {
    const before = snapshot;
    // Tore seit dem letzten Stand kurz aufleuchten lassen.
    const now = {};
    flash = new Set();
    for (const page of data.pages || []) {
      for (const m of page.matches || []) {
        const score = `${m.scoreHome}:${m.scoreAway}`;
        now[m.id] = score;
        if (!first && m.state === "live" && lastScores[m.id] && lastScores[m.id] !== score) flash.add(m.id);
      }
    }
    lastScores = now;
    if (data.lang) setLanguage(data.lang);
    applyCrest(data.team);
    snapshot = data;
    // Bei einer Übernahme wegen eines Touchdowns mit dieser Liga beginnen. Die
    // Szene kann schon laufen, bevor das Plugin die Liga nennt; deshalb
    // springt sie bei jeder neuen Vorgabe, nicht nur beim ersten Stand.
    const focus = data.focus && data.focus.league;
    scoredMatch = data.focus && data.focus.match != null ? String(data.focus.match) : null;
    const focusIndex = focus ? (data.pages || []).findIndex((p) => p.id === focus) : -1;
    const newFocus = focusIndex >= 0 && String(data.focus.id ?? focus) !== focusId;
    const holdChanged = holdPage !== (focusIndex >= 0);
    holdPage = focusIndex >= 0;
    if (newFocus) {
      focusId = String(data.focus.id ?? focus);
      pageIndex = focusIndex;
    } else if (first) {
      pageIndex = parseInt(params.get("page"), 10) || 0;
    }
    const pageCountChanged = !before || (before.pages || []).length !== (data.pages || []).length ||
      before.pageSeconds !== data.pageSeconds;
    render();
    if (first || newFocus || holdChanged || pageCountChanged) schedulePage();
  }

  // ------------------------------------------------------------------ loop

  async function poll(first) {
    let data = null;
    if (mode === "demo") {
      data = demoData();
    } else {
      try {
        data = await loadFromPlugin();
        pluginFailures = 0;
        mode = "plugin";
      } catch (_) {
        pluginFailures += 1;
        if (first || pluginFailures >= 3 || mode === "direct") {
          try {
            data = await loadDirect();
            mode = "direct";
          } catch (_) {
            data = null;
          }
        }
      }
    }
    if (data) applySnapshot(data, first || !snapshot);
    else if (snapshot) renderMeta((snapshot.pages || [])[pageIndex]);
    else render();
    ready();
    const wait = mode === "direct" ? FALLBACK_POLL_MS : POLL_MS;
    setTimeout(() => poll(false), wait);
  }

  function start() {
    tickClock();
    setInterval(tickClock, 5000);
    render();
    // Spätestens nach 5 s ist der erste Stand (oder "Einen Moment …") da.
    setTimeout(ready, 5000);
    poll(true);
    window.addEventListener("resize", () => render());
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
