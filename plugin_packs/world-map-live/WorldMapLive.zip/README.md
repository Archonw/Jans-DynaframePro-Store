# World Map Live

World Map Live zeigt eine ruhige Weltkarte mit Ländergrenzen, Tag und Nacht (die Tagseite leicht aufgehellt) und der Tag-Nacht-Grenze als warmer Linie. Darauf sind echte Live-Daten zu sehen:

- **Flugzeuge** (kleine gelbe Flugzeuge in Flugrichtung) vom OpenSky Network,
- **Schiffe** (kleine türkise Schiffe in Fahrtrichtung; dunkler, wenn sie stehen) aus bis zu fünf Quellen, die du einzeln an- und abwählst,
- **Blitze** von Blitzortung.org: ein neuer Blitz leuchtet kurz auf und verblasst dann von Gelb über Orange zu Rot.
- **Die ISS** mit ihrer Bahn: gestrichelt, wo sie in den nächsten 45 Minuten entlangfliegt, blasser, wo sie herkam.

World Map Live besteht aus zwei Teilen, die zusammen installiert werden:

- **Die Szene World Map Live** zeichnet die Karte. Sie kommt wie ein Bild in eine Playlist (empfohlene Dauer 5 Minuten).
- **Das Plugin** holt die Daten und hält die Einstellungen.

## Einrichten

1. Paket installieren (Plugins > Hochladen, oder über den Store).
2. **World Map Live öffnen**. Flugzeuge, Blitze und die Schiffe vor Norwegen und in der Ostsee laufen sofort, ohne Anmeldung.
3. Für Schiffe auf der ganzen Welt einen kostenlosen API-Key von [aisstream.io](https://aisstream.io) eintragen (Anmeldung mit GitHub, dann *API Keys* > *Create New API Key*).
4. **Playlist anlegen** drücken, oder die Szene selbst in eine Playlist aufnehmen.

## Einstellungen

- **Ausschnitt:** ganze Welt, Europa, Deutschland/Österreich/Schweiz, Nordamerika, Südamerika, Ostasien oder Australien und Ozeanien. Im Hochformat zeigt die ganze Welt drei Globen: oben groß Europa und Afrika, darunter Amerika und Asien mit Australien.
- **Ebenen:** Flugzeuge, Schiffe, Blitze, Tag und Nacht, ISS, Legende und Uhr lassen sich einzeln ausschalten.
- **Blitze zeigen für … Minuten** (Standard 30).
- **Sprache** der Plugin-Seite und der Szene: Deutsch, Englisch, Spanisch.

## Woher die Daten kommen

- **OpenSky Network** (opensky-network.org): Ohne Konto gibt es 400 Abfragen-Credits am Tag; ein Blick auf die ganze Welt kostet 4, also aktualisiert das Plugin etwa alle 16 Minuten. Dazwischen rechnet die Szene jedes Flugzeug mit Kurs und Geschwindigkeit weiter. Mit einem kostenlosen OpenSky-Konto und einem *API Client* (Client-ID und Secret auf der Plugin-Seite eintragen) sind es 4000 Credits, also etwa alle 2 Minuten. Kleinere Ausschnitte kosten weniger und werden öfter geladen. Die Daten sind für nicht kommerzielle Nutzung frei.
- **Schiffe** kommen aus fünf Quellen, jede lässt sich unter *Schiffe* einzeln an- und abwählen. Meldet ein Schiff bei mehreren, gilt die neueste Meldung.
- **AISStream.io** (weltweit, kostenloser Key): Schiffe melden ihre Position per AIS; AISStream sammelt die Meldungen von Küstenstationen. Weltweit sind das sehr viele Meldungen pro Sekunde, darum hört das Plugin nur 45 Sekunden alle 10 Minuten zu (einstellbar unter *Datenmenge*) und behält jedes Schiff bis zu einer Stunde. Auf hoher See ohne Küstenstation sieht man keine Schiffe.
- **Kystverket** (norwegische Küstenverwaltung): ein offener Strom aller AIS-Meldungen vor Norwegen und Svalbard, ohne Anmeldung (Lizenz NLOD 2.0). Kleine Fischerboote und Sportboote fehlen darin.
- **Digitraffic** (Fintraffic, Finnland): alle Schiffe in der Ostsee rund um Finnland, ohne Anmeldung, alle 5 Minuten (Lizenz CC BY 4.0).
- **AISHub**: ein Tauschnetz für Leute mit eigenem AIS-Empfänger. Einen Benutzernamen für die Abfrage bekommt nur, wer selbst Daten schickt.
- **Eigener AIS-Empfänger**: Hast du einen (zum Beispiel einen USB-Stick mit AIS-catcher), trag ein, wo er die AIS-Sätze über TCP anbietet, etwa `192.168.178.20:5012`.
- **Blitzortung.org**: ein Netz von Freiwilligen mit eigenen Empfängern. Das Plugin ist mit der Live-Karte verbunden und bekommt jeden Blitz innerhalb weniger Sekunden. Die Daten sind nur für den privaten, nicht kommerziellen Gebrauch freigegeben.
- **ISS:** Die Bahndaten (wie ein TLE) holt das Plugin alle 6 Stunden von CelesTrak (Ersatz: wheretheiss.at), ohne Key. Position und Bahn rechnet die Szene daraus selbst; auf einen Tag ist das auf etwa 10 km genau.
- **Küsten und Grenzen:** Natural Earth (gemeinfrei), in der Szene enthalten.

## Wenn etwas nicht stimmt

- Die Plugin-Seite zeigt unter *Status* für jede Quelle, wie viele Objekte gerade da sind und wann die nächsten Daten kommen, oder warum nicht (keine Verbindung, Key abgelehnt, Tageskontingent erschöpft).
- **„World Map Live antwortet nicht“ unten links in der Szene:** Das Plugin läuft nicht. Prüfe es auf der Plugins-Seite.
- **„Flugdaten von … Uhr“:** OpenSky hat länger als 30 Minuten nichts geliefert, meist weil das Tageskontingent aufgebraucht ist. Mit einem kostenlosen Konto passiert das nicht.
- Das Log steht auf dem Rahmen in `~/.local/share/dfr/logs/plugins.log`.
