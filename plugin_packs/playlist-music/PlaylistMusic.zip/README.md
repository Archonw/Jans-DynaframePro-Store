# Playlist Music

Plays music while certain DynaFrame playlists are running. Every playlist can
have its own music, plus one for "all other playlists" (also used for a Quick
Mix).

## Sources

- **Internet radio**: station search via [radio-browser.info](https://www.radio-browser.info), no account.
- **Own stream address**: MP3, AAC, HLS, `.m3u` or `.pls`, e.g. a SHOUTcast station (link of its `.pls` file on shoutcast.com, or `http://server:port/;stream`).
- **Jellyfin**: playlists, albums, artists, genres or all music. Uses the
  access of the Jellyfin Now Playing plugin if it is set up.
- **Folder on the frame**: music files in a folder (or a mounted share), subfolders included.
- **Spotify** (Premium): the frame becomes a Spotify Connect speaker through the
  free program [go-librespot](https://github.com/devgianlu/go-librespot)
  (GPL-3.0), which the plugin downloads from GitHub when you switch Spotify on.
  Pair once with a code at spotify.com/pair; no developer key needed. It can
  also start your other Spotify Connect devices (Sonos, Echo, TV …).
- **Music Assistant** (optional): everything set up there, e.g. YouTube Music,
  Spotify, Sonos, AirPlay, Chromecast. Needs a long-lived token.

## Music from the time of the photos

Instead of fixed music, a playlist can get music that matches the photos on
screen: the plugin looks up the year and country of the next photos (in the
real playing order, also when the playlist is shuffled) or, if you prefer, of
the photos shown last, in DynaFrame's media database and

- **Radio** finds a station for that decade (and country, if you like),
- **Jellyfin** plays your own songs from those years,
- **Spotify** plays your liked songs (or a playlist you pick) whose album came out then,
- **Music Assistant** looks for a matching hits playlist (e.g. "80s hits").

Match on the decade or the year (± 1); the music changes at the earliest after
the minutes you set, so it doesn't jump with every photo.

## Where the music plays

On the frame (the sound output set in DynaFrame, e.g. HDMI), on a Spotify
Connect device, or on a Music Assistant speaker. The plugin only changes its
own volume on the frame; the frame's volume stays as it is. On other speakers
it sets the chosen volume and puts the old one back afterwards.

## Rules

- When the playlist ends or changes: fade out, or keep playing until other music is due.
- Fade in/out time, pause or get quieter during videos and while another
  plugin shows something (e.g. a goal or the doorbell).
- Don't start if music is already playing on that speaker.
- Only at certain times. When the frame sleeps or playback stops, the music always ends.

Playing on the frame needs `ffmpeg` and a sound output (`pacat`, `pw-cat`,
ffmpeg with PulseAudio, or `aplay`); the status card shows what was found.

Problems or wishes: https://github.com/Archonw/Jans-DynaframePro-Store/issues
