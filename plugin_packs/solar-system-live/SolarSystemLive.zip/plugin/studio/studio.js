"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/SolarSystemLive/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["StopSeconds", "PlaylistSeconds"];
const CHECK_FIELDS = ["ShowOverview", "ShowSun", "ShowInner", "ShowOuter", "ShowDwarf", "ShowProbes", "ShowComets",
  "Labels", "Panel", "Orbits", "Belts", "EvEclipses", "EvPlanets", "EvMoon", "EvMeteors", "EvComets", "EvSeasons",
  "Banner", "Preview", "WakeScreen", "FetchProbes", "FetchComets"];
const SELECT_FIELDS = ["Blur", "Quality", "LeadDays", "Takeover", "TakeoverMinutes"];
const TEXT_FIELDS = ["PlaceName"];
let current = null;
let editing = false;

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["Solar System Live", "Solar System Live", "Solar System Live"],
  lede: ["Das Sonnensystem in Echtzeit als Modell: Alle Planeten stehen an ihrem echten Ort von heute, mit Monden, Raumsonden und Kometen. Die Kamera fliegt langsam von Planet zu Planet. Finsternisse und andere Himmelsereignisse kündigt die Szene vorher an, zeigt sie im Zeitraffer und live, wenn sie passieren. Jede Änderung hier wird sofort gespeichert.",
    "The Solar System in real time as a model: all planets stand at their real position today, with moons, space probes and comets. The camera flies slowly from planet to planet. The scene announces eclipses and other sky events ahead, shows them as a time-lapse and live while they happen. Every change here is saved immediately.",
    "El sistema solar en tiempo real como maqueta: todos los planetas en su posición real de hoy, con lunas, sondas espaciales y cometas. La cámara vuela despacio de planeta en planeta. La escena anuncia los eclipses y otros eventos del cielo, los muestra a cámara rápida y en directo cuando ocurren. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  demo: ["Nächstes Ereignis vorführen", "Preview the next event", "Mostrar el próximo evento"],
  factNext: ["Nächstes großes Ereignis", "Next big event", "Próximo gran evento"],
  factProbes: ["Raumsonden", "Space probes", "Sondas espaciales"],
  factComets: ["Kometen", "Comets", "Cometas"],
  factFps: ["Bildrate auf dem Rahmen", "Frame rate on the frame", "Fotogramas en el marco"],
  factVersion: ["Version", "Version", "Versión"],
  eventsTitle: ["Die nächsten Himmelsereignisse", "The next sky events", "Los próximos eventos del cielo"],
  statusHint: ["Die Orte der Planeten und Monde und alle Ereignisse rechnet der Rahmen selbst (Astronomy Engine), ohne Internet. „Nächstes Ereignis vorführen“ zeigt das nächste große Ereignis zwei Minuten lang im Zeitraffer.",
    "The frame computes the positions of the planets and moons and all events itself (Astronomy Engine), without the internet. “Preview the next event” shows the next big event as a time-lapse for two minutes.",
    "El marco calcula por sí mismo las posiciones de planetas y lunas y todos los eventos (Astronomy Engine), sin internet. «Mostrar el próximo evento» muestra el próximo gran evento a cámara rápida durante dos minutos."],
  probesLive: ["{n} von JPL Horizons", "{n} from JPL Horizons", "{n} de JPL Horizons"],
  probesModel: ["4 aus dem Ersatzmodell", "4 from the simple model", "4 del modelo simple"],
  cometsValue: ["{n}, davon {live} neu von JPL", "{n}, {live} of them new from JPL", "{n}, {live} nuevos de JPL"],
  fpsValue: ["{fps} Bilder/s ({tier}, Auflösung {scale} %)", "{fps} fps ({tier}, resolution {scale} %)", "{fps} fps ({tier}, resolución {scale} %)"],
  fpsNone: ["noch keine Meldung", "no report yet", "aún sin datos"],
  noEvent: ["keins gefunden", "none found", "ninguno"],
  visibleHere: ["bei dir sichtbar", "visible from your place", "visible desde tu lugar"],
  takeoverBadge: ["über die Playlist", "over the playlist", "sobre la playlist"],
  today: ["heute", "today", "hoy"],
  tomorrow: ["morgen", "tomorrow", "mañana"],
  inDays: ["in {n} Tagen", "in {n} days", "en {n} días"],
  live: ["jetzt", "now", "ahora"],
  placeTitle: ["Dein Ort", "Your place", "Tu lugar"],
  placeHint: ["Damit die Szene sagen kann, ob eine Finsternis bei dir zu sehen ist und wie sie von dir aus aussieht. Ohne Ort zeigt sie alles, nur ohne „bei dir“. Der Ort bleibt auf dem Rahmen.",
    "So the scene can tell whether an eclipse is visible from your place and what it looks like from there. Without a place it shows everything, just without “at your place”. The place stays on the frame.",
    "Para que la escena pueda decir si un eclipse se ve desde tu lugar y cómo se ve desde allí. Sin lugar lo muestra todo, solo que sin «en tu lugar». El lugar se queda en el marco."],
  placeSearch: ["Ort suchen", "Find a place", "Buscar un lugar"],
  placeSearchHint: ["z. B. Hamburg", "e.g. Hamburg", "p. ej. Madrid"],
  placeFind: ["Suchen", "Search", "Buscar"],
  placeSearching: ["Suche …", "Searching …", "Buscando …"],
  placeNone: ["Nichts gefunden.", "Nothing found.", "No se ha encontrado nada."],
  placeName: ["Name", "Name", "Nombre"],
  lat: ["Breitengrad", "Latitude", "Latitud"],
  lon: ["Längengrad", "Longitude", "Longitud"],
  placeMissing: ["Noch kein Ort eingetragen: Die Szene sagt nicht, was bei dir zu sehen ist.",
    "No place entered yet: the scene does not say what is visible from your place.",
    "Aún no hay lugar: la escena no dice qué se ve desde tu lugar."],
  placeSet: ["Ort: {place} ({lat}, {lon})", "Place: {place} ({lat}, {lon})", "Lugar: {place} ({lat}, {lon})"],
  tourTitle: ["Der Rundflug", "The camera tour", "El recorrido"],
  tourHint: ["Die Kamera fliegt der Reihe nach zu diesen Stationen, bleibt jeweils eine Weile und fährt dabei langsam zurück, bis die Monde im Bild sind.",
    "The camera flies to these stops in turn, stays a while at each and slowly pulls back until the moons are in the picture.",
    "La cámara vuela por turnos a estas paradas, se queda un rato en cada una y se aleja despacio hasta que las lunas entran en la imagen."],
  sOverview: ["Übersicht (inneres und ganzes Sonnensystem)", "Overview (inner and whole Solar System)", "Vista general (sistema solar interior y completo)"],
  sSun: ["Sonne", "Sun", "Sol"],
  sInner: ["Merkur, Venus, Erde mit Mond, Mars", "Mercury, Venus, Earth with the Moon, Mars", "Mercurio, Venus, la Tierra con la Luna, Marte"],
  sOuter: ["Jupiter, Saturn, Uranus, Neptun mit ihren Monden", "Jupiter, Saturn, Uranus, Neptune with their moons", "Júpiter, Saturno, Urano, Neptuno con sus lunas"],
  sDwarf: ["Pluto mit Charon", "Pluto with Charon", "Plutón con Caronte"],
  sProbes: ["Raumsonden (Voyager, New Horizons, Webb …)", "Space probes (Voyager, New Horizons, Webb …)", "Sondas espaciales (Voyager, New Horizons, Webb …)"],
  sComets: ["Kometen in Sonnennähe", "Comets near the Sun", "Cometas cerca del Sol"],
  stopSeconds: ["Verweilen je Station (Sekunden)", "Time at each stop (seconds)", "Tiempo en cada parada (segundos)"],
  labels: ["Namen an Planeten, Monden, Sonden und Kometen", "Names on planets, moons, probes and comets", "Nombres en planetas, lunas, sondas y cometas"],
  panel: ["Infokasten (Entfernung, Lichtlaufzeit, Fakt) und „Demnächst am Himmel“", "Info box (distance, light time, a fact) and “Coming up in the sky”", "Cuadro de información (distancia, tiempo de luz, un dato) y «Próximamente en el cielo»"],
  orbits: ["Bahnen einzeichnen", "Draw the orbits", "Dibujar las órbitas"],
  belts: ["Asteroidengürtel und Kuipergürtel", "Asteroid belt and Kuiper belt", "Cinturón de asteroides y de Kuiper"],
  lookTitle: ["Aussehen", "Look", "Aspecto"],
  lookHint: ["Ein Modell unter einer Lampe: gemalte Kugeln, echtes Licht der Sonne, Schatten der Saturnringe, und Unschärfe wie bei einer Kamera, die nah an eine Modelllandschaft heran geht. Größen und Abstände sind nicht maßstäblich, sonst wäre fast alles unsichtbar klein; die Richtungen stimmen.",
    "A model under a lamp: painted spheres, real light from the Sun, the shadow of Saturn's rings, and blur like a camera close to a model landscape. Sizes and distances are not to scale, otherwise almost everything would be invisibly small; the directions are real.",
    "Una maqueta bajo una lámpara: esferas pintadas, luz real del Sol, la sombra de los anillos de Saturno y desenfoque como una cámara cerca de una maqueta. Tamaños y distancias no están a escala, si no casi todo sería invisible; las direcciones son reales."],
  blur: ["Unschärfe (Miniatur-Look)", "Blur (miniature look)", "Desenfoque (aspecto de maqueta)"],
  blurOff: ["Aus", "Off", "Desactivado"],
  blurLight: ["Leicht", "Light", "Ligero"],
  blurNormal: ["Normal", "Normal", "Normal"],
  blurStrong: ["Stark", "Strong", "Fuerte"],
  quality: ["Qualität", "Quality", "Calidad"],
  qAuto: ["Automatisch (erkennt Pi 4 und Pi 5)", "Automatic (detects Pi 4 and Pi 5)", "Automática (detecta Pi 4 y Pi 5)"],
  qPi4: ["Sparsam (Pi 4)", "Light (Pi 4)", "Ligera (Pi 4)"],
  qPi5: ["Mittel (Pi 5)", "Medium (Pi 5)", "Media (Pi 5)"],
  qHigh: ["Hoch (schneller Rechner)", "High (fast computer)", "Alta (ordenador rápido)"],
  qualityHint: ["Die Szene passt die Auflösung selbst an, damit sie flüssig läuft. Die Bildrate meldet sie oben im Status.",
    "The scene adjusts its resolution itself so it runs smoothly. It reports the frame rate in the status above.",
    "La escena ajusta su resolución sola para ir fluida. Informa de los fotogramas en el estado de arriba."],
  eventsCard: ["Himmelsereignisse", "Sky events", "Eventos del cielo"],
  eventsHint: ["Steht ein Ereignis bevor, zeigt die Szene es oben an und spielt es zu Beginn des Rundflugs im Zeitraffer vor. Während es passiert, zeigt sie es live, mit einem Bild, wie es bei dir am Himmel aussieht.",
    "When an event is coming up, the scene shows it at the top and plays it as a time-lapse at the start of the tour. While it happens, it shows it live, with a picture of what it looks like in your sky.",
    "Cuando se acerca un evento, la escena lo muestra arriba y lo reproduce a cámara rápida al principio del recorrido. Mientras ocurre, lo muestra en directo, con una imagen de cómo se ve en tu cielo."],
  eEclipses: ["Mond- und Sonnenfinsternisse, Merkur- und Venustransit", "Lunar and solar eclipses, transits of Mercury and Venus", "Eclipses de Luna y de Sol, tránsitos de Mercurio y Venus"],
  ePlanets: ["Planeten: Oppositionen, enge Paare, Morgen- und Abendstern", "Planets: oppositions, close pairs, morning and evening star", "Planetas: oposiciones, parejas cercanas, lucero del alba y vespertino"],
  eMoon: ["Supermond", "Supermoon", "Superluna"],
  eMeteors: ["Sternschnuppen-Nächte (Perseiden, Geminiden …)", "Meteor shower nights (Perseids, Geminids …)", "Noches de estrellas fugaces (Perseidas, Gemínidas …)"],
  eComets: ["Kometen an der Sonne", "Comets near the Sun", "Cometas junto al Sol"],
  eSeasons: ["Frühlings-, Sommer-, Herbst- und Winteranfang", "First day of spring, summer, autumn and winter", "Comienzo de primavera, verano, otoño e invierno"],
  leadDays: ["Ankündigen ab", "Announce from", "Anunciar desde"],
  lead1: ["1 Tag vorher", "1 day before", "1 día antes"],
  lead3: ["3 Tage vorher", "3 days before", "3 días antes"],
  lead7: ["1 Woche vorher", "1 week before", "1 semana antes"],
  lead14: ["2 Wochen vorher", "2 weeks before", "2 semanas antes"],
  lead30: ["1 Monat vorher", "1 month before", "1 mes antes"],
  banner: ["Ankündigung oben einblenden", "Show the announcement at the top", "Mostrar el aviso arriba"],
  preview: ["Bevorstehendes Ereignis vorher im Zeitraffer zeigen", "Show an upcoming event ahead as a time-lapse", "Mostrar antes el próximo evento a cámara rápida"],
  takeoverTitle: ["Über die Playlist legen", "Put over the playlist", "Poner sobre la playlist"],
  takeoverHint: ["Läuft gerade etwas anderes, kann das Plugin eine Finsternis für ein paar Minuten über die Playlist legen, rund um ihren Höhepunkt, und danach zurückgeben. Dafür muss auf der Plugins-Seite bei Solar System Live „Übernahme erlauben“ eingeschaltet sein.",
    "If something else is playing, the plugin can put an eclipse over the playlist for a few minutes around its peak and then hand the screen back. For that, switch on “Allow takeover” for Solar System Live on the Plugins page.",
    "Si se está reproduciendo otra cosa, el plugin puede poner un eclipse sobre la playlist unos minutos alrededor de su máximo y luego devolver la pantalla. Para ello activa «Permitir toma de control» para Solar System Live en la página de plugins."],
  takeover: ["Über die Playlist legen", "Put over the playlist", "Poner sobre la playlist"],
  toOff: ["Nein", "No", "No"],
  toEclipses: ["Finsternisse, die bei dir zu sehen sind", "Eclipses visible from your place", "Eclipses visibles desde tu lugar"],
  toBig: ["Alle großen Ereignisse", "All big events", "Todos los grandes eventos"],
  takeoverMinutes: ["Wie lange", "How long", "Cuánto tiempo"],
  wake: ["Dafür auch einen ausgeschalteten Bildschirm einschalten", "Also switch on a screen that is off", "Encender también una pantalla apagada"],
  servicesTitle: ["Verbindungen", "Connections", "Conexiones"],
  refresh: ["Jetzt neu holen", "Fetch again now", "Volver a cargar"],
  servicesHint: ["Planeten, Monde und Ereignisse brauchen kein Internet. Nur die Raumsonden und neu entdeckte Kometen holt das Plugin einmal am Tag von der NASA (JPL). Ohne sie zeigt die Szene Voyager, New Horizons, Webb und BepiColombo aus einem einfachen Modell und die bekannten Kometen.",
    "Planets, moons and events need no internet. Only the space probes and newly found comets are fetched once a day from NASA (JPL). Without them the scene shows Voyager, New Horizons, Webb and BepiColombo from a simple model, plus the well-known comets.",
    "Planetas, lunas y eventos no necesitan internet. Solo las sondas y los cometas nuevos se cargan una vez al día de la NASA (JPL). Sin ellos la escena muestra Voyager, New Horizons, Webb y BepiColombo con un modelo simple y los cometas conocidos."],
  servicesWait: ["Wird geprüft …", "Checking …", "Comprobando …"],
  svcHorizons: ["JPL Horizons (Raumsonden)", "JPL Horizons (space probes)", "JPL Horizons (sondas)"],
  svcSbdb: ["JPL Small-Body Database (Kometen)", "JPL Small-Body Database (comets)", "JPL Small-Body Database (cometas)"],
  svcGeo: ["Open-Meteo Ortssuche", "Open-Meteo place search", "Búsqueda de lugares Open-Meteo"],
  svc_ok: ["OK", "OK", "OK"],
  svc_bad: ["Problem", "Problem", "Problema"],
  svc_off: ["Aus", "Off", "Desactivado"],
  svc_wait: ["Noch nicht gefragt", "Not asked yet", "Aún sin consultar"],
  svcOkText: ["Zuletzt {time}{count}", "Last {time}{count}", "Última vez {time}{count}"],
  svcCount: [", {n} Einträge", ", {n} entries", ", {n} entradas"],
  svcBadText: ["{time}: {error}", "{time}: {error}", "{time}: {error}"],
  svcGeoWait: ["Wird nur bei der Ortssuche gefragt.", "Only asked when you search for a place.", "Solo se consulta al buscar un lugar."],
  fetchProbes: ["Raumsonden von JPL Horizons holen", "Fetch space probes from JPL Horizons", "Cargar sondas de JPL Horizons"],
  fetchComets: ["Hell werdende Kometen aus der JPL Small-Body Database holen", "Fetch comets that get bright from the JPL Small-Body Database", "Cargar cometas que se vuelven brillantes de la JPL Small-Body Database"],
  piholeHint: ["Wer Pi-hole oder einen anderen Werbeblocker nutzt, muss ssd.jpl.nasa.gov und ssd-api.jpl.nasa.gov erlauben, für die Ortssuche auch geocoding-api.open-meteo.com.",
    "If you use Pi-hole or another ad blocker, allow ssd.jpl.nasa.gov and ssd-api.jpl.nasa.gov, and geocoding-api.open-meteo.com for the place search.",
    "Si usas Pi-hole u otro bloqueador, permite ssd.jpl.nasa.gov y ssd-api.jpl.nasa.gov y, para buscar el lugar, geocoding-api.open-meteo.com."],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una playlist para ello"],
  makePlaylist: ["Playlist „Solar System Live“ anlegen", "Create the “Solar System Live” playlist", "Crear la playlist «Solar System Live»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistSeconds: ["Dauer in der Playlist (Sekunden)", "Duration in the playlist (seconds)", "Duración en la playlist (segundos)"],
  playlistHint: ["Die Playlist enthält nur die Szene und ist eingeschaltet. Die Dauer gilt beim Anlegen; danach änderst du sie in der Playlist selbst. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist contains only the scene and is switched on. The duration applies when it is created; after that you change it in the playlist itself. You can also add the scene to any playlist yourself.",
    "La playlist contiene solo la escena y está activada. La duración se aplica al crearla; después la cambias en la propia playlist. También puedes añadir la escena a cualquier playlist."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or wishes?", "¿Problemas, preguntas o deseos?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre un issue en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", ", with plugin name and version.", ", con el nombre y la versión del plugin."],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin is not responding.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status}).", "Error (HTTP {status}).", "Error (HTTP {status})."]
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? row[LANGS.indexOf(lang)] ?? row[0] : key;
  if (typeof text !== "string") return text;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

const esc = (text) => String(text).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang]);

function when(epoch, start) {
  const now = Date.now() / 1000;
  if (start <= now) return t("live");
  const days = Math.round((new Date(epoch * 1000).setHours(0, 0, 0, 0) - new Date().setHours(0, 0, 0, 0)) / 86400000);
  const date = new Date(epoch * 1000).toLocaleDateString(LOCALES[lang], { weekday: "short", day: "numeric", month: "short", year: days > 300 ? "numeric" : undefined });
  const time = new Date(epoch * 1000).toLocaleTimeString(LOCALES[lang], { hour: "2-digit", minute: "2-digit" });
  const rel = days <= 0 ? t("today") : days === 1 ? t("tomorrow") : t("inDays", { n: days });
  return `${date}, ${time} (${rel})`;
}
function stamp(epoch) {
  if (!epoch) return "—";
  return new Date(epoch * 1000).toLocaleString(LOCALES[lang], { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

function renderServices(state) {
  const s = state.settings;
  const rows = [
    ["svcHorizons", state.conn.horizons, s.FetchProbes],
    ["svcSbdb", state.conn.sbdb, s.FetchComets],
    ["svcGeo", state.conn.geocoding, true]
  ].map(([name, c, on]) => {
    let cls, text;
    if (!on) { cls = "off"; text = ""; }
    else if (c.ok === true) { cls = "ok"; text = t("svcOkText", { time: stamp(c.at), count: c.count != null ? t("svcCount", { n: c.count }) : "" }); }
    else if (c.ok === false) { cls = "bad"; text = t("svcBadText", { time: stamp(c.at), error: c.error || "?" }); }
    else { cls = "wait"; text = name === "svcGeo" ? t("svcGeoWait") : ""; }
    const tag = t("svc_" + cls);
    return `<li class="svc ${cls}"><span class="dot"></span><div><b>${esc(t(name))}</b> <span class="tag">${esc(tag)}</span>${text ? `<div class="txt">${esc(text)}</div>` : ""}</div></li>`;
  });
  el("servicesList").innerHTML = rows.join("");
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  const hasPlace = s.Lat !== null && s.Lon !== null;
  const evs = state.events || [];
  const big = state.nextBig;
  el("factNext").textContent = big ? `${big.title}, ${when(big.peak, big.start)}` : t("noEvent");
  el("factProbes").textContent = state.probes ? t("probesLive", { n: state.probes }) : t("probesModel");
  el("factComets").textContent = t("cometsValue", { n: state.comets, live: state.liveComets });
  const g = state.gpu || {};
  el("factFps").textContent = g.fps ? t("fpsValue", { fps: g.fps.toFixed(0), tier: g.tier || "?", scale: Math.round((g.scale || 0) * 100) }) : t("fpsNone");
  el("factVersion").textContent = state.version;
  const rows = evs.filter((e) => !e.demo).slice(0, 10);
  el("eventBox").hidden = !rows.length;
  el("eventList").innerHTML = rows.map((e) => {
    const badges = [e.visible === true ? t("visibleHere") : "", e.sub && e.visible !== true ? e.sub : ""].filter(Boolean).join(" · ");
    return `<li><span>${esc(e.title)}<span class="w">${esc(when(e.peak, e.start))}</span></span><span class="v${e.visible ? " hi" : ""}">${esc(badges)}</span></li>`;
  }).join("");
  el("placeNote").textContent = hasPlace ? t("placeSet", { place: s.PlaceName || "—", lat: s.Lat, lon: s.Lon }) : t("placeMissing");
  el("takeoverNote").textContent = state.takeoverNote || "";
  renderServices(state);
  if (document.activeElement !== el("MakePlaylist")) el("MakePlaylist").value = String(Boolean(s.MakePlaylist));
  el("playlistNote").textContent = state.ownPlaylist || "";
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Solar System Live ${state.version}] `);
  if (!editing) {
    for (const name of NUMBER_FIELDS) if (document.activeElement !== el(name)) el(name).value = s[name];
    for (const name of TEXT_FIELDS) if (document.activeElement !== el(name)) el(name).value = s[name] || "";
    for (const name of ["Lat", "Lon"]) if (document.activeElement !== el(name)) el(name).value = s[name] === null ? "" : String(s[name]);
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) if (document.activeElement !== el(name)) el(name).value = String(s[name]);
    el("Language").value = lang;
  }
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

async function findPlace() {
  const q = el("PlaceSearch").value.trim();
  const box = el("PlaceResults");
  if (q.length < 2) return;
  box.hidden = false;
  box.textContent = t("placeSearching");
  try {
    const result = await api("./api/places?q=" + encodeURIComponent(q));
    box.textContent = "";
    if (!result.places.length) { box.textContent = t("placeNone"); return; }
    for (const place of result.places) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "secondary place";
      button.textContent = place.region ? `${place.name} (${place.region})` : place.name;
      button.addEventListener("click", async () => {
        box.hidden = true;
        box.textContent = "";
        el("PlaceSearch").value = "";
        await save({ PlaceName: place.name, Lat: place.lat, Lon: place.lon });
      });
      box.appendChild(button);
    }
  } catch (error) {
    box.textContent = error.message;
  }
}

for (const name of [...NUMBER_FIELDS, ...TEXT_FIELDS, "Lat", "Lon"]) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
  input.addEventListener("change", (e) => {
    const value = e.target.value;
    save({ [name]: NUMBER_FIELDS.includes(name) ? Number(value) : value });
  });
}
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save({ Language: e.target.value });
});
el("placeButton").addEventListener("click", findPlace);
el("PlaceSearch").addEventListener("keydown", (e) => { if (e.key === "Enter") findPlace(); });
for (const [id, path] of [["refreshButton", "./api/refresh"], ["demoButton", "./api/demo"]]) {
  el(id).addEventListener("click", async () => {
    try {
      const result = await api(path, { method: "POST" });
      setStatus(result.message || "", "busy");
      setTimeout(refresh, 3000);
    } catch (error) {
      setStatus(error.message, "bad");
    }
  });
}
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));

refresh();
setInterval(refresh, 5000);

// ---- accordion:start
// ------------------------------------------------------------ Aufklappen (tools/plugin-vorlage/accordion)
// Karten und Abschnitte auf- und zuklappen, damit lange Plugin-Seiten übersichtlich
// bleiben. Gesteuert nur über Attribute im HTML (Anleitung: accordion/README.md):
//   <section class="card" data-fold="immich" data-fold-when="uses:immich"> …
//   <h3 class="sub" data-fold="immichFilter" data-fold-start="closed" data-fold-badge="count">
// Eigene Texte (DE/EN/ES) stehen hier, die Sprache kommt aus <html lang>.
(() => {
  const TEXT = {
    open: ["Aufklappen", "Expand", "Desplegar"],
    close: ["Zuklappen", "Collapse", "Plegar"],
    active: ["{n} aktiv", "{n} active", "{n} activos"],
    none: ["Keine Filter", "No filters", "Sin filtros"],
    set: ["Eingerichtet", "Set up", "Configurado"],
    optional: ["Optional", "Optional", "Opcional"],
    lines: ["{n} eingetragen", "{n} entered", "{n} introducidos"],
    svcOk: ["Alles erreichbar", "All reachable", "Todo accesible"],
    svcBad: ["{n} Problem", "{n} problem", "{n} problema"],
    svcBads: ["{n} Probleme", "{n} problems", "{n} problemas"],
    svcWarn: ["Teilweise", "Partly", "Parcial"],
    svcWait: ["Wird geprüft", "Checking", "Comprobando"],
    "off:immich": ["Nur mit Immich als Quelle nötig", "Only needed with Immich as source", "Solo con Immich como fuente"],
    "off:dynaframe": ["Nur mit Fotos aus DynaFrame nötig", "Only needed with photos from DynaFrame", "Solo con fotos de DynaFrame"],
    "off:library": ["Nur mit „Alle Fotos in DynaFrame“ nötig", "Only needed with “All photos in DynaFrame”", "Solo con «Todas las fotos de DynaFrame»"],
    off: ["Gerade nicht gebraucht", "Not needed right now", "No se necesita ahora"],
  };
  const LANGS = ["de", "en", "es"];
  const say = (key, n) => {
    const row = TEXT[key] || TEXT.off;
    const i = Math.max(0, LANGS.indexOf(document.documentElement.lang));
    return (row[i] ?? row[0]).replace("{n}", String(n));
  };
  const store = (() => {
    try { return window.localStorage; } catch (_) { return null; }
  })();
  const keyOf = (id) => `fold:${location.pathname}:${id}`;
  const remembered = (id) => {
    try { return JSON.parse(store?.getItem(keyOf(id)) || "null"); } catch (_) { return null; }
  };
  const remember = (id, value) => {
    try { store?.setItem(keyOf(id), JSON.stringify(value)); } catch (_) { /* privat */ }
  };

  // Quellen-Auswahl: jedes <select>, das eine Immich-Option hat (auch Quellen-Zeilen, die studio.js erst später baut)
  const DF_KINDS = ["library", "folders", "playlist", "same"];
  function sourceValues() {
    const values = [];
    for (const select of document.querySelectorAll("select")) {
      if ([...select.options].some((o) => o.value.startsWith("immich"))) values.push(select.value);
    }
    return values;
  }
  function holds(rule) {
    // "uses:immich", "uses:dynaframe", "uses:library" oder "Feld=wert1,wert2", mehrere mit "|"
    return rule.split("|").some((part) => {
      part = part.trim();
      if (part.startsWith("uses:")) {
        const values = sourceValues();
        if (!values.length) return true; // keine Quellen-Auswahl auf der Seite: immer gebraucht
        const what = part.slice(5);
        if (what === "immich") return values.some((v) => v.startsWith("immich"));
        if (what === "dynaframe") return values.some((v) => DF_KINDS.includes(v));
        return values.includes(what);
      }
      const [id, list] = part.split("=");
      const field = document.getElementById(id);
      if (!field) return true;
      const value = field.type === "checkbox" ? String(field.checked) : field.value;
      return (list || "").split(",").map((v) => v.trim()).includes(value);
    });
  }

  // Wie viele Einstellungen in einem Bereich vom Standard abweichen (Felder mit Wert, Häkchen, Auswahl ≠ erste Option)
  function activeCount(nodes) {
    let n = 0;
    for (const node of nodes) {
      for (const field of node.querySelectorAll("input, select, textarea")) {
        if (field.closest(".checks") || field.type === "password" || field.type === "button") continue;
        if (field.type === "checkbox") n += field.checked ? 1 : 0;
        else if (field.tagName === "SELECT") n += field.selectedIndex > 0 ? 1 : 0;
        else n += field.value.trim() && field.value.trim() !== "0" ? 1 : 0;
      }
      for (const list of node.querySelectorAll(".checks")) n += list.querySelector("input:checked") ? 1 : 0;
    }
    return n;
  }

  function badgeFor(fold) {
    if (!fold.needed) return [say(`off:${fold.rule.replace(/^uses:/, "").split("|")[0]}`), "off"];
    const nodes = fold.body();
    switch (fold.badge) {
      case "count": {
        const n = activeCount(nodes);
        return n ? [say("active", n), "on"] : [say("none"), ""];
      }
      case "filled": {
        const filled = nodes.some((node) => [...node.querySelectorAll('input[type="url"], input[type="text"]')].some((f) => f.value.trim()));
        return filled ? [say("set"), "on"] : [say("optional"), ""];
      }
      case "lines": {
        const n = nodes.reduce((sum, node) => sum + [...node.querySelectorAll("textarea")]
          .reduce((s, area) => s + area.value.split("\n").filter((line) => line.trim()).length, 0), 0);
        return n ? [say("lines", n), "on"] : [say("optional"), ""];
      }
      case "services": {
        const bad = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.bad").length, 0);
        const warn = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.warn").length, 0);
        const ok = nodes.reduce((s, node) => s + node.querySelectorAll(".svc.ok").length, 0);
        if (bad) return [say(bad === 1 ? "svcBad" : "svcBads", bad), "bad"];
        if (warn) return [say("svcWarn"), "warn"];
        return ok ? [say("svcOk"), "ok"] : [say("svcWait"), ""];
      }
      default:
        return ["", ""];
    }
  }

  const folds = [];

  function setup(head, id, isCard) {
    const host = isCard ? head : head.parentElement;
    const title = isCard ? (head.querySelector(":scope > .card-head") || head.querySelector(":scope > h2")) : head;
    if (!title) return;
    const bar = document.createElement("div");
    bar.className = "fold-bar" + (isCard ? " fold-bar-card" : " fold-bar-sub");
    bar.setAttribute("role", "button");
    bar.tabIndex = 0;
    title.replaceWith(bar);
    bar.append(title);
    const badge = document.createElement("span");
    badge.className = "fold-badge";
    const chevron = document.createElement("span");
    chevron.className = "fold-chevron";
    chevron.setAttribute("aria-hidden", "true");
    bar.append(badge, chevron);
    let body = null;
    if (!isCard) {
      // Unterabschnitt: alles bis zum nächsten h3.sub / <details> / Kartenende
      body = document.createElement("div");
      body.className = "fold-body";
      let next = bar.nextElementSibling;
      while (next && !(next.matches("h3.sub, .fold-bar, details"))) {
        const after = next.nextElementSibling;
        body.append(next);
        next = after;
      }
      bar.after(body);
    }
    const src = head;
    const fold = {
      id, host, bar, body: () => (isCard ? [...host.children].filter((c) => c !== bar) : [body]),
      rule: src.dataset.foldWhen || "",
      startClosed: src.dataset.foldStart === "closed",
      badge: src.dataset.foldBadge || "", badgeEl: badge,
      needed: true, open: true, isCard, sub: body,
    };
    const toggle = (e) => {
      if (e.type === "click" && e.target.closest("button, a, input, select, textarea, label")) return;
      if (e.type === "keydown" && (e.target !== bar || (e.key !== "Enter" && e.key !== " "))) return;
      if (e.type === "keydown") e.preventDefault();
      show(fold, !fold.open);
      remember(id, { open: fold.open, needed: fold.needed });
    };
    bar.addEventListener("click", toggle);
    bar.addEventListener("keydown", toggle);
    folds.push(fold);
    if (fold.rule) show(fold, false); // erst entscheiden, wenn studio.js den Stand gesetzt hat
    else start(fold);
  }

  function start(fold) {
    const saved = remembered(fold.id);
    fold.needed = fold.rule ? holds(fold.rule) : true;
    fold.wasNeeded = fold.needed;
    fold.started = true;
    show(fold, saved && saved.needed === fold.needed ? saved.open : wanted(fold));
  }

  function wanted(fold) {
    if (!fold.needed) return false;
    if (fold.badge === "services") {
      const [, tone] = badgeFor(fold);
      if (tone === "bad") return true;
    }
    return !fold.startClosed;
  }

  function show(fold, open) {
    fold.open = open;
    fold.host.classList.toggle("fold-closed", fold.isCard && !open);
    if (fold.sub) fold.sub.hidden = !open;
    fold.bar.setAttribute("aria-expanded", String(open));
    fold.bar.title = say(open ? "close" : "open");
  }

  // Bereit, sobald studio.js den ersten Stand gezeigt hat (Version steht da) oder nach 5 s
  const born = Date.now();
  function stateShown() {
    const version = document.getElementById("factVersion");
    return !version || /\d/.test(version.textContent) || Date.now() - born > 5000;
  }

  function refresh() {
    const ready = stateShown();
    for (const fold of folds) {
      if (!fold.started) {
        if (!ready) continue;
        start(fold);
      }
      fold.needed = fold.rule ? holds(fold.rule) : true;
      if (fold.needed !== fold.wasNeeded) {
        // Quelle gewechselt: Karte auf- bzw. zuklappen, eigene Wahl vergessen
        fold.wasNeeded = fold.needed;
        remember(fold.id, null);
        show(fold, wanted(fold));
      }
      fold.host.classList.toggle("fold-unused", fold.isCard && !fold.needed);
      const [text, tone] = badgeFor(fold);
      // Verbindungen: bei einem neuen Problem von selbst aufklappen
      if (fold.badge === "services" && tone === "bad" && fold.lastTone !== "bad") show(fold, true);
      fold.lastTone = tone;
      if (fold.badgeEl.textContent !== text) fold.badgeEl.textContent = text;
      fold.badgeEl.className = "fold-badge" + (tone ? ` ${tone}` : "");
      fold.badgeEl.hidden = !text;
      fold.bar.title = say(fold.open ? "close" : "open");
    }
  }

  function init() {
    for (const card of document.querySelectorAll(".card[data-fold]")) setup(card, card.dataset.fold, true);
    for (const head of document.querySelectorAll("h3.sub[data-fold]")) setup(head, head.dataset.fold, false);
    refresh();
    document.addEventListener("change", refresh);
    document.addEventListener("input", refresh);
    setInterval(refresh, 1000); // studio.js setzt Werte beim Abfragen des Stands
  }

  window.Fold = { refresh, open: (id, value = true) => { const f = folds.find((x) => x.id === id); if (f) show(f, value); } };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
// ---- accordion:end
