# Cloud Folder Sync

Brings photos from a cloud folder onto your DynaFrame. Family members put photos into a shared folder with the provider's own app, from anywhere; the frame fetches new photos every 15 minutes (adjustable) and DynaFrame shows them like any other folder.

Supported: Google Drive (also "Shared with me"), Dropbox, OneDrive, pCloud, MEGA, Koofr, Nextcloud/ownCloud/WebDAV, iCloud Photos and iCloud Drive (Apple ID + two-factor code), shared iCloud albums (public link, no sign-in), and any other service rclone knows (paste an rclone.conf section).

- Each cloud folder gets its own subfolder under `Pictures/Cloud Folder Sync/` on the frame.
- Mirror (deleted in the cloud = removed from the frame) or add only.
- Photos (jpg, png, webp, gif, heic …), videos optional.
- Optional playlist "Cloud Folder Sync" with the whole folder.
- Stops syncing when free space on the frame drops below a limit (default 1000 MB).
- The frame opens no port; sign-ins stay in the plugin folder (readable only by the plugin).

## Signing in (Google, Dropbox, Microsoft, pCloud)

1. Click "Sign in" on the plugin page; the provider's sign-in opens in a new tab.
2. After allowing access the tab shows an error page whose address starts with `http://127.0.0.1:53682/` or `http://localhost:53682/`. That is expected: copy the whole address and paste it on the plugin page. The plugin hands it to rclone on the frame, which finishes the sign-in.

Alternative: run `rclone authorize "drive"` (or dropbox, onedrive, pcloud) on a computer and paste the output.

## Own Google key (Google Drive)

rclone's shared Google client ID is being retired by Google during 2026. The plugin page has a box "Own Google key" with step-by-step instructions: create a free project in the Google Cloud Console, enable the Google Drive API, add the scope `drive.readonly`, publish the app (otherwise sign-ins expire after 7 days) and create an OAuth client of type "Desktop app". Paste client ID and secret, then sign in to Drive again. The key is stored only on the frame (data/google_client.json, readable only by the plugin).

## iCloud

Two ways for Apple users:

- **Shared iCloud album (recommended, no sign-in):** in Photos on the iPhone open a shared album, tap "People", turn on "Public Website" and paste the link. Every member of the album can add photos; the frame fetches them. Anyone who knows the link can view the album. Shared albums store photos at reduced size (up to 2048 px on the long side), which is fine for a frame.
- **iCloud Photos / iCloud Drive with the Apple ID:** uses rclone's iCloud backend. Enter the Apple ID and the normal password (not an app-specific password), then the six-digit code Apple shows on your iPhone (or an SMS code). On the iPhone, Settings > Apple Account > iCloud > "Access iCloud Data on the Web" must be on. Apple only allows this sign-in for 30 days; afterwards the plugin asks for a new code. Password and session are stored only on the frame (data/rclone.conf, readable only by the plugin). Photos come in their original format, from iPhones usually HEIC.

## Network (Pi-hole etc.)

- `downloads.rclone.org` (rclone is downloaded once, checked against the official SHA-256 list)
- Google Drive: `accounts.google.com`, `oauth2.googleapis.com`, `www.googleapis.com`
- Dropbox: `www.dropbox.com`, `api.dropboxapi.com`, `content.dropboxapi.com`
- OneDrive: `login.microsoftonline.com`, `graph.microsoft.com`, plus download hosts `*.1drv.com`, `*.sharepoint.com`, `my.microsoftpersonalcontent.com`
- pCloud: `api.pcloud.com` / `eapi.pcloud.com` and `*.pcloud.com`
- MEGA: `mega.nz`, `g.api.mega.co.nz`, `*.userstorage.mega.co.nz` (MEGA accounts with two-factor sign-in cannot be used; take a separate account without 2FA)
- Koofr: `app.koofr.net` (app password from Koofr settings)
- Nextcloud/WebDAV: your own server
- iCloud with Apple ID: `idmsa.apple.com`, `setup.icloud.com`, `*.icloud.com`, `*.icloud-content.com`, `*.apple.com`
- Shared iCloud albums: `*-sharedstreams.icloud.com`, `*.icloud-content.com`

rclone is © Nick Craig-Wood and contributors, MIT licence (https://rclone.org).
