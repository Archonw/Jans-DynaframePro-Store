# Photo Quiz

A guessing game with your own photos: the TV shows a photo, everyone guesses on their phone **when** (year) and **where** (tap on a map) it was taken. Then the TV reveals date and place on a map with everyone's pins and points.

## How a game works

1. The TV shows a QR code and a 4-digit code (changes daily). Scan it, enter a name, you are in. No app needed.
2. Each round shows one photo, at first pixelated, zoomed in or blurred; it gets clearer over the round. A clock runs down (default 45 s).
3. Hints appear one after another (up to three): season and time of day, weather back then (Open-Meteo archive), camera, distance and direction from home, country.
4. Everybody guesses a year and a place. The round ends when the time is up or everybody has guessed.
5. Reveal: date, place, map with the photo (star) and all guesses (pins), points per player.
6. After the last round (default 5): final standings with the winner. Then a new game starts.

Points: year exact 1000, 1 year off 600, 2 years 300, 3 years 100. Place up to 1000, fewer the further away; the scale adapts to how far your photos are from home, so a quiz of local photos is just as fair as one of travel photos.

You can play with the year only, the place only or both.

## Starting a quiz

- **As a playlist**: the scene runs in a DynaFrame playlist (option "Eine Playlist dafür" on the plugin page creates one), the quiz runs whenever the scene is visible.
- **From the phone**: open the phone page and tap "Quiz starten". The frame switches to the quiz (takeover) and goes back after the set minutes or 5 minutes with nobody playing. Needs "Allow takeover" for the plugin.

## Photos

Only photos with a date are used; for "where" only photos with GPS. Sources like the other photo plugins: the whole DynaFrame library (with the filter card "Welche Fotos aus DynaFrame": stars, dates, camera …), a playlist, folders, or Immich (random sample, with album/star/favourite/archive filters; takes over the login of Immich Slideshow and others). The plugin draws years evenly so not every round is from last year, and avoids photos from the same day in a row.

## Phone page

Runs on port 8099 of the frame (8100-8102 if taken). Phone and frame must be in the same network. If you use Web Login, tick port 8099 there or play only at home. Map tiles come from CARTO/OpenStreetMap; without internet a simple world outline is shown.

## Privacy

Player names and scores stay on the frame (`data/players.json`). Place names come from OpenStreetMap Nominatim, weather from Open-Meteo, both without a key and cached.
