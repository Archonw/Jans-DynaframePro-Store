# Solar System Live

The Solar System in real time, as a model under a lamp: every planet stands at
its real position of today, with moons, space probes and comets. The camera
flies slowly from planet to planet, and sky events such as an eclipse are
announced ahead, previewed as a time-lapse and shown live when they happen.

## What it shows

- **The tour.** Overview of the inner and the whole Solar System, the Sun,
  Mercury, Venus, Earth with Moon, Mars, Jupiter, Saturn, Uranus and Neptune with
  their large moons, Pluto with Charon, the space probes and comets near the
  Sun. At each stop the camera starts close and slowly pulls back until the
  moons are in the picture. A panel shows the distance from Earth, how long the
  light takes, the length of a year and a day and a short fact.
- **Miniature look.** Painted spheres lit by the Sun, the shadow of Saturn on
  its rings and of the rings on Saturn, clouds on Earth, and a camera blur like
  a lens close to a model landscape. Sizes and distances are not to scale
  (otherwise nearly everything would be invisibly small); the directions are
  real.
- **Sky events** for the coming months: lunar and solar eclipses (with how much
  of the Sun is covered at your place), transits of Mercury and Venus,
  oppositions, close planet pairs, Mercury and Venus as morning or evening star,
  supermoons, meteor showers (with or without disturbing moonlight), comets
  closest to the Sun and, optionally, the seasons. The next event is announced
  at the top up to 30 days ahead and played as a time-lapse at the start of the
  tour; while it happens it is shown live. Eclipse shadows are computed in real
  geometry: the Moon's shadow moves over the Earth, the Moon turns copper red in
  the Earth's shadow, and a small picture shows how it looks from your place.
- **Over the playlist (optional).** An eclipse (or any big event) can be put
  over the running playlist for a few minutes around its peak. Needs "Allow
  takeover" for Solar System Live on the Plugins page.

## How it works

The positions of the planets and moons and all events are computed on the frame
with [Astronomy Engine](https://github.com/cosinekitty/astronomy) (MIT), without
the internet. Only the space probes (Voyager 1 and 2, New Horizons, Parker Solar
Probe, Webb, JUICE, Europa Clipper, Lucy, Psyche, BepiColombo, Solar Orbiter)
and newly discovered comets are fetched once a day from NASA JPL (Horizons and
the Small-Body Database). Without them the scene uses a simple model for the
probes and the known comets. The 3D scene is built with
[three.js](https://threejs.org) (MIT) and adapts its resolution so it stays
smooth on a Pi 4 and Pi 5.

No LAN port is opened. The scene talks to the plugin through the DynaFrame web
interface.

Pi-hole users: allow `ssd.jpl.nasa.gov`, `ssd-api.jpl.nasa.gov` and, for the
place search, `geocoding-api.open-meteo.com`.

## Settings (plugin page)

- **Your place**: search by name or enter latitude and longitude. Needed for
  "visible from your place" and the local view of an eclipse.
- **The tour**: which stops, how long to stay, labels, info panel, orbits,
  asteroid and Kuiper belt.
- **Look**: blur (off to strong) and quality (automatic for Pi 4 / Pi 5).
- **Sky events**: which kinds, how far ahead to announce, banner and preview.
- **Put over the playlist**: no, eclipses only, or all big events; how long;
  optionally wake a screen that is off.
- **Connections**: status of NASA JPL and the place search, fetch again now.
- **A playlist for it**: creates the playlist "Solar System Live" with the scene.
- "Preview the next event" shows the next big event as a time-lapse for two
  minutes (and tests the takeover, if it is switched on).

The plugin page and the scene speak English, German or Spanish.

## Problems?

Open an issue: https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=Solar%20System%20Live
