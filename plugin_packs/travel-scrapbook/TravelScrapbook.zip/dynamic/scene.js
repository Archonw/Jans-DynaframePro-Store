/* Reise-Scrapbook – die Szene.
 *
 * Zeigt eine Reise nach der anderen als Scrapbook-Seite: eingeklebte Abzüge
 * (das Plugin wählt sie nach Sternen), eine kleine Routenkarte, ein Ticket mit
 * Tagen, Kilometern und Fotos, das Wetter unterwegs, ein Stempel und
 * handschriftliche Notizen. Die Daten kommen vom Plugin TravelScrapbook über
 * den Proxy der Weboberfläche. Welche Reise als nächste dran ist, merkt sich
 * das Plugin; so zeigt der Rahmen nach und nach einen Urlaub nach dem anderen.
 *
 * ?plugin=<url> nimmt ein anderes Plugin (Tests), ?lang=, ?paper=, ?trip=<id>, ?cover=1, ?still=1.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "TravelScrapbook";
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set([
    `${location.protocol}//${location.hostname}:8003${advanced}`,
    `${location.protocol}//${location.hostname}${advanced}`,
    `${location.origin}${advanced}`,
  ])];
  // Kommt die Szene über Port 80/443 (RemoteFrame, Web Login), zuerst denselben Ursprung fragen.
  if (!params.get("plugin") && (location.port === "" || location.port === "80" || location.port === "443")) {
    pluginBases.sort((a, b) => (b.startsWith(location.origin) ? 1 : 0) - (a.startsWith(location.origin) ? 1 : 0));
  }
  let baseIndex = 0;
  const base = () => pluginBases[baseIndex];

  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const TEXT = {
    de: {
      day: "Tag", days: "Tage", night: "Nacht", nights: "Nächte", photos: "Fotos", km: "km", mi: "Meilen",
      trip: "REISE", tripNo: "REISE Nº {n}",
      coverTitle: "Unsere Reisen", coverKicker: "SCRAPBOOK", coverLine: "{trips} Reisen · {days} Tage unterwegs",
      coverLine2: "{km} · {countries} · {years}", countries1: "1 Land", countriesN: "{n} Länder",
      home: "Zuhause", homeArrow: "Zuhause {d}",
      nStations: "{list}", nHot: "Heißester Tag: {t} am {date}", nHotWow: "{t} am {date} – puh!",
      nCold: "Kälteste Nacht: {t}", nNoRain: "Kein einziger Regentag!", nRain1: "Nur ein Regentag",
      nRain: "{n} Regentage – egal.", nSun: "{h} Stunden Sonne", nBest: "{n} Fotos am {date}!",
      nFive: "{n}× fünf Sterne", nFar: "{d} Luftlinie von zu Hause", nEarly: "Erstes Foto: {weekday}, {time} Uhr",
      nWeekend: "Ein Wochenende in {place}", nLong: "{n} Nächte unterwegs", nPhotos: "{n} Fotos in {d} Tagen",
      nSnow: "Schnee an {n} Tagen", nSnow1: "Schnee!",
      someWhere: "Unterwegs", busyTitle: "Einen Moment …", busy: "Die Fotos werden gelesen und Reisen gesucht.",
      noneTitle: "Noch keine Reise gefunden",
      none: "Eine Reise sind mindestens {days} Tage weiter als {km} km von zu Hause, mit Fotos mit GPS. Einstellen kannst du das auf der Plugin-Seite.",
      offline: "Reise-Scrapbook antwortet nicht", offlineText: "Läuft das Plugin? Schau auf der Plugins-Seite nach.",
      noSource: "Wähle auf der Plugin-Seite, woher die Fotos kommen.",
    },
    en: {
      day: "day", days: "days", night: "night", nights: "nights", photos: "photos", km: "km", mi: "miles",
      trip: "TRIP", tripNo: "TRIP Nº {n}",
      coverTitle: "Our Travels", coverKicker: "SCRAPBOOK", coverLine: "{trips} trips · {days} days away",
      coverLine2: "{km} · {countries} · {years}", countries1: "1 country", countriesN: "{n} countries",
      home: "Home", homeArrow: "Home {d}",
      nStations: "{list}", nHot: "Hottest day: {t} on {date}", nHotWow: "{t} on {date} – phew!",
      nCold: "Coldest night: {t}", nNoRain: "Not a single rainy day!", nRain1: "Just one rainy day",
      nRain: "{n} rainy days – who cares.", nSun: "{h} hours of sunshine", nBest: "{n} photos on {date}!",
      nFive: "{n}× five stars", nFar: "{d} from home as the crow flies", nEarly: "First photo: {weekday}, {time}",
      nWeekend: "A weekend in {place}", nLong: "{n} nights away", nPhotos: "{n} photos in {d} days",
      nSnow: "Snow on {n} days", nSnow1: "Snow!",
      someWhere: "On the road", busyTitle: "One moment …", busy: "Reading your photos and looking for trips.",
      noneTitle: "No trips found yet",
      none: "A trip is at least {days} days more than {km} from home, with photos that have GPS. You can change this on the plugin page.",
      offline: "Travel Scrapbook is not responding", offlineText: "Is the plugin running? Have a look at the Plugins page.",
      noSource: "Pick on the plugin page where the photos come from.",
    },
    es: {
      day: "día", days: "días", night: "noche", nights: "noches", photos: "fotos", km: "km", mi: "millas",
      trip: "VIAJE", tripNo: "VIAJE Nº {n}",
      coverTitle: "Nuestros viajes", coverKicker: "ÁLBUM", coverLine: "{trips} viajes · {days} días fuera",
      coverLine2: "{km} · {countries} · {years}", countries1: "1 país", countriesN: "{n} países",
      home: "Casa", homeArrow: "Casa {d}",
      nStations: "{list}", nHot: "Día más caluroso: {t} el {date}", nHotWow: "¡{t} el {date}, uf!",
      nCold: "Noche más fría: {t}", nNoRain: "¡Ni un solo día de lluvia!", nRain1: "Solo un día de lluvia",
      nRain: "{n} días de lluvia, ¿y qué?", nSun: "{h} horas de sol", nBest: "¡{n} fotos el {date}!",
      nFive: "{n}× cinco estrellas", nFar: "{d} de casa en línea recta", nEarly: "Primera foto: {weekday}, {time}",
      nWeekend: "Un fin de semana en {place}", nLong: "{n} noches fuera", nPhotos: "{n} fotos en {d} días",
      nSnow: "Nieve {n} días", nSnow1: "¡Nieve!",
      someWhere: "De viaje", busyTitle: "Un momento …", busy: "Leyendo tus fotos y buscando viajes.",
      noneTitle: "Aún no hay viajes",
      none: "Un viaje son al menos {days} días a más de {km} de casa, con fotos con GPS. Puedes cambiarlo en la página del plugin.",
      offline: "Álbum de viajes no responde", offlineText: "¿Está funcionando el plugin? Mira en la página de plugins.",
      noSource: "Elige en la página del plugin de dónde vienen las fotos.",
    },
  };

  const el = (id) => document.getElementById(id);
  const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const NS = "http://www.w3.org/2000/svg";

  const state = {
    lang: params.get("lang") || "en",
    s: { PageSeconds: 45, Paper: params.get("paper") || "kraft", ShowMap: true, ShowWeather: true, ShowNotes: true,
      ShowCover: true, Animate: !params.get("still"), Units: "metric", HomeName: "" },
    ver: -1, trips: [], order: [], start: 0, totals: null, busy: true, sources: 1, minDays: 2, minKm: 60,
    loaded: false, failures: 0,
  };
  let readySent = false;
  let pos = -1;                 // Index in state.trips der gezeigten Reise
  let timer = 0;
  let current = null;           // die gezeigte Seite (DOM)
  let shownCover = false;

  const tx = (key, values = {}) => String((TEXT[state.lang] || TEXT.en)[key] ?? TEXT.en[key] ?? key)
    .replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");
  const locale = () => LOCALES[state.lang] || "en-GB";

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  function report(text) {
    try {
      fetch(`${base()}api/report?m=${encodeURIComponent(String(text).slice(0, 200))}`, { cache: "no-store" }).catch(() => {});
    } catch (_) { /* egal */ }
  }
  window.addEventListener("error", (e) => report(`Fehler: ${e.message} (${e.lineno})`));

  // ------------------------------------------------------------------ Zufall mit Samen (gleiche Reise, gleiche Seite)

  function rngFor(seed) {
    let h = 1779033703 ^ String(seed).length;
    for (const ch of String(seed)) { h = Math.imul(h ^ ch.charCodeAt(0), 3432918353); h = (h << 13) | (h >>> 19); }
    let a = h >>> 0;
    const next = () => {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
    next.range = (lo, hi) => lo + next() * (hi - lo);
    next.pick = (list) => list[Math.floor(next() * list.length)];
    next.sign = () => (next() < 0.5 ? -1 : 1);
    return next;
  }

  // ------------------------------------------------------------------ Formate

  const imperial = () => state.s.Units === "imperial";
  const num = (n) => Number(n || 0).toLocaleString(locale());
  const dist = (km) => imperial() ? `${num(Math.round(km * 0.621371))} ${tx("mi")}` : `${num(Math.round(km))} ${tx("km")}`;
  const deg = (c) => (c === null || c === undefined) ? "–" : `${Math.round(imperial() ? c * 9 / 5 + 32 : c)}°`;
  const date = (iso) => new Date(`${iso.slice(0, 10)}T12:00:00`);
  const fmt = (iso, opts) => date(iso).toLocaleDateString(locale(), opts);
  const dayMonth = (iso) => state.lang === "en" ? fmt(iso, { day: "numeric", month: "short" }) : fmt(iso, { day: "numeric", month: "numeric" }) + (state.lang === "de" ? "" : "");
  const shortDay = (iso) => fmt(iso, { day: "numeric", month: "short" });

  function range(trip) {
    const a = date(trip.start), b = date(trip.end);
    try {
      return new Intl.DateTimeFormat(locale(), { day: "numeric", month: "long", year: "numeric" }).formatRange(a, b);
    } catch (_) {
      return `${a.toLocaleDateString(locale())} – ${b.toLocaleDateString(locale())}`;
    }
  }

  function city(name) { return String(name || "").split(",")[0].trim(); }

  function titleOf(trip) {
    return trip.title || trip.autoTitle || city((trip.places[0] || {}).name) || tx("someWhere");
  }

  // ------------------------------------------------------------------ Daten vom Plugin

  async function fetchScene() {
    let lastError = null;
    for (let attempt = 0; attempt < pluginBases.length; attempt++) {
      try {
        const response = await fetch(`${base()}api/scene?v=${state.ver}`, { cache: "no-store" });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const data = await response.json();
        state.failures = 0;
        state.loaded = true;
        apply(data);
        return true;
      } catch (error) {
        lastError = error;
        baseIndex = (baseIndex + 1) % pluginBases.length;
      }
    }
    state.failures += 1;
    if (state.failures === 3) report(`Szene: Plugin nicht erreichbar (${lastError})`);
    return false;
  }

  function apply(data) {
    const s = data.settings || {};
    state.lang = TEXT[s.Language] ? s.Language : state.lang;
    state.s = Object.assign(state.s, s);
    if (params.get("paper")) state.s.Paper = params.get("paper");
    if (params.get("still")) state.s.Animate = false;
    document.body.className = ["kraft", "cream", "black"].includes(state.s.Paper) ? state.s.Paper : "kraft";
    document.documentElement.lang = state.lang;
    state.busy = Boolean(data.busy);
    state.sources = data.sources ?? 1;
    state.order = data.order || [];
    if (data.trips) {
      const wasId = pos >= 0 && state.trips[pos] ? state.trips[pos].id : null;
      state.trips = data.trips;
      state.totals = data.totals || null;
      state.ver = data.ver;
      if (wasId) pos = state.trips.findIndex((t) => t.id === wasId);
      if (pos < 0 && wasId) pos = Math.min(state.trips.length - 1, Math.max(0, (data.start || 0) - 1));
    }
    if (pos < 0) state.start = data.start || 0;
  }

  // ------------------------------------------------------------------ Bilder vorladen

  const imageCache = new Map();
  function loadImage(id) {
    if (imageCache.has(id)) return imageCache.get(id);
    const promise = new Promise((resolve) => {
      const img = new Image();
      img.decoding = "async";
      const done = (ok) => { clearTimeout(timeout); resolve(ok ? img : null); };
      const timeout = setTimeout(() => done(false), 20000);
      img.onload = () => done(true);
      img.onerror = () => { done(false); imageCache.delete(id); };
      img.src = `${base()}api/photo?p=${encodeURIComponent(id)}`;
    });
    imageCache.set(id, promise);
    if (imageCache.size > 40) imageCache.delete(imageCache.keys().next().value);
    return promise;
  }

  // ------------------------------------------------------------------ Seite: Grundgerüst

  let U = 10, W = 1920, H = 1080, LAND = true;

  function measure() {
    W = window.innerWidth || 1920;
    H = window.innerHeight || 1080;
    LAND = W >= H;
    U = LAND ? Math.min(W / 100, H / 56.25) : Math.min(W / 62, H / 100);
  }

  function newPage(kind) {
    const page = document.createElement("section");
    page.className = `page ${LAND ? "landscape" : "portrait"} ${kind || ""}`;
    page.style.setProperty("--u", `${U}px`);
    page.style.setProperty("--grain", GRAIN);
    if (state.s.Animate) page.classList.add("anim");
    return page;
  }

  function box(page, cls, x, y, w, h, extra = {}) {
    const node = document.createElement(extra.tag || "div");
    node.className = `el ${cls}`;
    node.style.left = `${x}px`;
    node.style.top = `${y}px`;
    if (w !== null && w !== undefined) node.style.width = `${w}px`;
    if (h !== null && h !== undefined) node.style.height = `${h}px`;
    if (extra.rot) node.style.setProperty("--rot", `${extra.rot}deg`);
    if (extra.z) node.style.zIndex = extra.z;
    page.appendChild(node);
    return node;
  }

  // Papier-Körnung, einmal als SVG-Rauschen
  const GRAIN = `url("data:image/svg+xml,${encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' width='420' height='420'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='3' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 .11 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>`
  ).replace(/%2523/g, "%23")}")`;

  // ------------------------------------------------------------------ Abzüge als Collage

  function gridFor(n, w, h, aspect) {
    let best = null;
    for (let cols = 1; cols <= n; cols++) {
      const rows = Math.ceil(n / cols);
      const cell = (w / cols) / (h / rows);
      const score = Math.abs(Math.log(cell / aspect)) + (cols * rows - n) * 0.22;
      if (!best || score < best.score) best = { cols, rows, score };
    }
    return best;
  }

  function placePrint(cell, aspect, polaroid, scale) {
    const pad = Math.max(U * 0.45, Math.min(cell.w, cell.h) * 0.035);
    const padb = polaroid ? Math.max(pad * 3.4, U * 2.6) : pad;
    let iw = Math.min(cell.w * 0.94 - 2 * pad, (cell.h * 0.94 - pad - padb) * aspect);
    iw *= scale;
    const ih = iw / aspect;
    const fw = iw + 2 * pad, fh = ih + pad + padb;
    return { x: cell.x + (cell.w - fw) / 2, y: cell.y + (cell.h - fh) / 2, w: fw, h: fh, pad, padb };
  }

  function layoutCollage(region, items, rng, tall) {
    const out = [];
    const hero = items[0];
    const rest = items.slice(1);
    const avg = rest.length ? rest.reduce((sum, i) => sum + i.aspect, 0) / rest.length : 1.4;
    const share = rest.length === 0 ? 1 : rest.length <= 2 ? 0.58 : rest.length <= 5 ? 0.52 : 0.46;
    let heroCell, restArea;
    if (tall) {
      const heroTop = rng() < 0.5;
      const hh = region.h * share;
      heroCell = { x: region.x, y: heroTop ? region.y : region.y + region.h - hh, w: region.w, h: hh };
      restArea = { x: region.x, y: heroTop ? region.y + hh : region.y, w: region.w, h: region.h - hh };
    } else {
      const heroLeft = rng() < 0.6;
      const hw = region.w * share;
      heroCell = { x: heroLeft ? region.x : region.x + region.w - hw, y: region.y, w: hw, h: region.h };
      restArea = { x: heroLeft ? region.x + hw : region.x, y: region.y, w: region.w - hw, h: region.h };
    }
    const heroP = placePrint(heroCell, hero.aspect, true, 1.0);
    heroP.rot = rng.range(1, 3.2) * rng.sign();
    heroP.polaroid = true;
    heroP.x += rng.range(-0.03, 0.03) * heroCell.w;
    heroP.y += rng.range(-0.02, 0.02) * heroCell.h;
    out.push(heroP);
    if (!rest.length) return out;
    const g = gridFor(rest.length, restArea.w, restArea.h, avg * 1.05);
    const cw = restArea.w / g.cols, ch = restArea.h / g.rows;
    rest.forEach((item, i) => {
      const row = Math.floor(i / g.cols);
      const inRow = Math.min(g.cols, rest.length - row * g.cols);
      const col = i % g.cols;
      const offset = (g.cols - inRow) * cw / 2;
      const cell = { x: restArea.x + offset + col * cw, y: restArea.y + row * ch, w: cw, h: ch };
      const polaroid = rng() < 0.45;
      const p = placePrint(cell, item.aspect, polaroid, rng.range(1.02, 1.12));
      p.x += rng.range(-0.06, 0.06) * cw;
      p.y += rng.range(-0.05, 0.05) * ch;
      p.rot = rng.range(1.5, 6) * rng.sign();
      p.polaroid = polaroid;
      out.push(p);
    });
    return out;
  }

  function collage(region, items, rng) {
    // items: [{aspect}] -> [{x, y, w, h, pad, padb, rot, polaroid}]
    // Beide Aufteilungen (Held daneben / Held darüber) durchrechnen und die nehmen,
    // bei der die Abzüge mehr von der Fläche füllen.
    const seed = rng();
    const variants = [false, true].map((tall) => layoutCollage(region, items, rngFor(`c${seed}`), tall));
    const area = (list) => list.reduce((sum, p) => sum + p.w * p.h, 0) * (list[0] ? Math.sqrt(list[0].w * list[0].h) : 1);
    const out = area(variants[1]) > area(variants[0]) ? variants[1] : variants[0];
    // nicht über den Rand der Seite hinaus
    for (const p of out) {
      p.x = Math.max(U * 0.6, Math.min(W - p.w - U * 0.6, p.x));
      p.y = Math.max(U * 0.6, Math.min(H - p.h - U * 0.6, p.y));
    }
    return out;
  }

  function stars(n) {
    return n > 0 ? "★".repeat(Math.min(5, n)) : "";
  }

  function addTape(node, p, rng, style) {
    const tw = Math.min(p.w * 0.42, U * 9);
    const th = Math.max(U * 1.5, tw * 0.28);
    const make = (left, top, rot, extra = "") => {
      const tape = document.createElement("i");
      tape.className = `tape ${extra}`;
      tape.style.width = `${tw}px`;
      tape.style.height = `${th}px`;
      tape.style.left = `${left}px`;
      tape.style.top = `${top}px`;
      tape.style.transform = `rotate(${rot}deg)`;
      node.appendChild(tape);
    };
    const kind = rng() < 0.5 ? "" : "b";
    const stripes = rng() < 0.3 ? " stripes" : "";
    if (style === "top") make(p.w / 2 - tw / 2 + rng.range(-U, U), -th * 0.55, rng.range(-7, 7), kind + stripes);
    else if (style === "corners") {
      make(-tw * 0.3, -th * 0.15, -38 + rng.range(-6, 6), kind + stripes);
      make(p.w - tw * 0.7, -th * 0.15, 38 + rng.range(-6, 6), kind + stripes);
    } else if (style === "photo-corners") {
      for (const c of ["tl", "tr", "bl", "br"]) {
        const corner = document.createElement("i");
        corner.className = `corner ${c}`;
        node.appendChild(corner);
      }
    } else if (style === "side") {
      make(-tw * 0.45, p.h * 0.5 - th / 2, 80 + rng.range(-8, 8), kind + stripes);
    }
  }

  function addPrints(page, region, trip, imgs, rng, zBase = 10) {
    const items = [];
    trip.photos.forEach((photo, i) => {
      const img = imgs[i];
      if (!img) return;
      const aspect = img.naturalWidth && img.naturalHeight ? img.naturalWidth / img.naturalHeight : 1.5;
      items.push({ photo, img, aspect: Math.max(0.5, Math.min(2.2, aspect)) });
    });
    if (!items.length) return [];
    const heroIndex = Math.max(0, items.findIndex((i) => i.photo.best));
    const ordered = [items[heroIndex], ...items.filter((_, i) => i !== heroIndex)];
    const spots = collage(region, ordered, rng);
    const nodes = [];
    ordered.forEach((item, i) => {
      const p = spots[i];
      const hero = i === 0;
      const node = box(page, `print pop${p.polaroid ? " polaroid" : ""}`, p.x, p.y, p.w, p.h,
        { tag: "figure", rot: p.rot, z: hero ? zBase + 1 : zBase + 2 + Math.floor(rng() * 8) });
      node.style.setProperty("--pad", `${p.pad}px`);
      node.style.setProperty("--padb", `${p.padb}px`);
      node.style.setProperty("--cap", `${Math.max(U * 1.2, Math.min(p.padb * 0.62, U * 2.4))}px`);
      const pic = document.createElement("div");
      pic.className = "pic";
      const img = item.img.cloneNode();
      img.alt = "";
      pic.appendChild(img);
      node.appendChild(pic);
      if (p.polaroid) {
        const cap = document.createElement("figcaption");
        // kleine Abzüge: nur Datum, Ort nur wenn Platz ist
        const roomy = p.w > U * 15;
        const where = roomy ? (item.photo.place || "") : "";
        const when = shortDay(item.photo.t);
        const capPx = Math.max(U * 1.2, Math.min(p.padb * 0.62, U * 2.4));
        const label = where ? `${where}, ${when}` : when;
        const room = p.w - 2 * p.pad;
        const need = textWidth(label, `${capPx}px Hand, cursive`) + capPx * 0.85 * Math.min(5, item.photo.stars || 0) + capPx;
        const st = item.photo.stars >= 4 && need <= room ? `<span class="stars">${stars(item.photo.stars)}</span>` : "";
        cap.innerHTML = `<span class="txt">${esc(label)}</span>${st}`;
        node.appendChild(cap);
      }
      addTape(node, p, rng, hero ? "corners" : rng.pick(["top", "top", "corners", "photo-corners", "side", "none"]));
      nodes.push(node);
    });
    return nodes;
  }

  // ------------------------------------------------------------------ Karte

  const worldCache = {};
  function worldFor(level) {
    if (worldCache[level]) return worldCache[level];
    const data = level === 1 ? window.WORLD_MAP : (window.WORLD_MAP_DETAIL || {})[level];
    if (!data) return null;
    const scale = data.scale || 100;
    const decode = (rings) => (rings || []).map((ring) => {
      const pts = new Float32Array(ring.length);
      let lon = ring[0] / scale, lat = ring[1] / scale;
      pts[0] = lon; pts[1] = lat;
      let x0 = lon, x1 = lon, y0 = lat, y1 = lat;
      for (let i = 2; i < ring.length; i += 2) {
        lon += ring[i] / scale; lat += ring[i + 1] / scale;
        pts[i] = lon; pts[i + 1] = lat;
        if (lon < x0) x0 = lon; if (lon > x1) x1 = lon; if (lat < y0) y0 = lat; if (lat > y1) y1 = lat;
      }
      return { pts, bb: [x0, y0, x1, y1] };
    });
    worldCache[level] = { land: decode(data.land), lakes: decode(data.lakes), rivers: decode(data.rivers), borders: decode(data.borders) };
    return worldCache[level];
  }

  const loadingLevels = {};
  function ensureLevel(level) {
    if (level === 1 || (window.WORLD_MAP_DETAIL || {})[level]) return Promise.resolve(true);
    if (loadingLevels[level]) return loadingLevels[level];
    loadingLevels[level] = new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = `land-${level}.js`;
      script.onload = () => resolve(true);
      script.onerror = () => { report(`Karte Stufe ${level} nicht ladbar`); resolve(false); };
      document.head.appendChild(script);
    });
    return loadingLevels[level];
  }

  function mapView(trip, w, h) {
    const pts = (trip.route || []).slice();
    for (const p of trip.places || []) pts.push([p.lat, p.lon]);
    if (!pts.length && trip.home) pts.push([trip.home.lat, trip.home.lon]);
    let s = 90, n = -90, west = 180, east = -180;
    for (const [lat, lon] of pts) { s = Math.min(s, lat); n = Math.max(n, lat); west = Math.min(west, lon); east = Math.max(east, lon); }
    // Zuhause mit drauf, wenn es nicht viel weiter weg ist als die Reise selbst
    let homeIn = false;
    if (trip.home) {
      const span = Math.max(n - s, (east - west) * Math.cos(((n + s) / 2) * Math.PI / 180), 0.4);
      const dLat = Math.max(0, s - trip.home.lat, trip.home.lat - n);
      const dLon = Math.max(0, west - trip.home.lon, trip.home.lon - east) * Math.cos(((n + s) / 2) * Math.PI / 180);
      if (Math.max(dLat, dLon) < span * 1.2) {
        homeIn = true;
        s = Math.min(s, trip.home.lat); n = Math.max(n, trip.home.lat);
        west = Math.min(west, trip.home.lon); east = Math.max(east, trip.home.lon);
      }
    }
    const latC = (s + n) / 2, lonC = (west + east) / 2;
    const k = Math.cos(latC * Math.PI / 180);
    let spanX = Math.max((east - west) * k, 0.8), spanY = Math.max(n - s, 0.8);
    spanX *= 1.45; spanY *= 1.45;
    const aspect = w / h;
    if (spanX / spanY > aspect) spanY = spanX / aspect; else spanX = spanY * aspect;
    const scale = w / spanX;
    const fwd = (lat, lon) => [w / 2 + (lon - lonC) * k * scale, h / 2 - (lat - latC) * scale];
    const bbox = [lonC - spanX / k / 2, latC - spanY / 2, lonC + spanX / k / 2, latC + spanY / 2];
    return { fwd, bbox, span: Math.max(spanX, spanY), scale, k, homeIn, latC, lonC };
  }

  function levelFor(span) {
    return span > 14 ? 1 : span > 2.5 ? 3 : 4;
  }

  function drawRings(ctx, rings, v, close) {
    const [bx0, by0, bx1, by1] = v.bbox;
    ctx.beginPath();
    for (const ring of rings) {
      const bb = ring.bb;
      if (bb[2] < bx0 || bb[0] > bx1 || bb[3] < by0 || bb[1] > by1) continue;
      const p = ring.pts;
      let [x, y] = v.fwd(p[1], p[0]);
      ctx.moveTo(x, y);
      for (let i = 2; i < p.length; i += 2) {
        [x, y] = v.fwd(p[i + 1], p[i]);
        ctx.lineTo(x, y);
      }
      if (close) ctx.closePath();
    }
  }

  async function drawMap(card, trip, rng) {
    const holder = card.querySelector(".map");
    const w = holder.clientWidth || card.clientWidth, h = holder.clientHeight || card.clientHeight;
    const v = mapView(trip, w, h);
    const level = levelFor(v.span);
    await ensureLevel(level);
    const world = worldFor(level) || worldFor(1);
    const css = getComputedStyle(card);
    const canvas = document.createElement("canvas");
    const ratio = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = Math.round(w * ratio);
    canvas.height = Math.round(h * ratio);
    const ctx = canvas.getContext("2d");
    ctx.scale(ratio, ratio);
    ctx.fillStyle = css.getPropertyValue("--sea").trim() || "#cfdcd6";
    ctx.fillRect(0, 0, w, h);
    if (world) {
      ctx.fillStyle = css.getPropertyValue("--land").trim() || "#efe4cb";
      ctx.strokeStyle = css.getPropertyValue("--coast").trim() || "rgba(60,50,40,.75)";
      ctx.lineWidth = Math.max(0.8, U * 0.09);
      ctx.lineJoin = "round";
      drawRings(ctx, world.land, v, true);
      ctx.fill("evenodd");
      ctx.stroke();
      if (world.lakes.length) {
        ctx.fillStyle = css.getPropertyValue("--sea").trim() || "#cfdcd6";
        drawRings(ctx, world.lakes, v, true);
        ctx.fill();
        ctx.lineWidth = Math.max(0.6, U * 0.06);
        ctx.stroke();
      }
      if (world.rivers.length) {
        ctx.strokeStyle = "rgba(90,140,170,.55)";
        ctx.lineWidth = Math.max(0.6, U * 0.07);
        drawRings(ctx, world.rivers, v, false);
        ctx.stroke();
      }
      if (world.borders.length) {
        ctx.strokeStyle = "rgba(120,60,60,.55)";
        ctx.setLineDash([U * 0.5, U * 0.35]);
        ctx.lineWidth = Math.max(0.7, U * 0.08);
        drawRings(ctx, world.borders, v, false);
        ctx.stroke();
        ctx.setLineDash([]);
      }
    }
    // Maßstab
    const kmPerPx = 111.32 / v.scale;
    const target = w * 0.22 * kmPerPx;
    const nice = [1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 5000].reduce((best, n) => Math.abs(n - target) < Math.abs(best - target) ? n : best, 1);
    const barPx = nice / kmPerPx;
    ctx.strokeStyle = "#2a2420";
    ctx.lineWidth = Math.max(1, U * 0.12);
    ctx.beginPath();
    const bx = w - barPx - U * 1.2, by = h - U * 1.1;
    ctx.moveTo(bx, by - U * 0.35); ctx.lineTo(bx, by); ctx.lineTo(bx + barPx, by); ctx.lineTo(bx + barPx, by - U * 0.35);
    ctx.stroke();
    ctx.font = `${U * 1.25}px Hand, cursive`;
    ctx.fillStyle = "#2a2420";
    ctx.textAlign = "center";
    ctx.fillText(imperial() ? `${Math.round(nice * 0.621371)} mi` : `${nice} km`, bx + barPx / 2, by - U * 0.5);
    holder.appendChild(canvas);

    // Route, Orte, Zuhause als SVG darüber (lässt sich zeichnen lassen)
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", `0 0 ${w} ${h}`);
    // Stadtreise: viele Punkte auf engem Raum ergeben nur Gekritzel, dann reicht ein Punkt pro Tag
    const b = trip.bbox || [0, 0, 0, 0];
    const spanKm = Math.hypot((b[2] - b[0]) * 111, (b[3] - b[1]) * 111 * Math.cos(((b[0] + b[2]) / 2) * Math.PI / 180));
    const line = spanKm < 12 ? [] : spanKm < 40 && (trip.dayPoints || []).length ? trip.dayPoints.map((p) => [p.lat, p.lon]) : (trip.route || []);
    const pts = line.map(([lat, lon]) => v.fwd(lat, lon));
    if (v.homeIn && trip.home && pts.length) {
      const home = v.fwd(trip.home.lat, trip.home.lon);
      pts.unshift(home);
      pts.push(home);
    }
    let d = "";
    if (pts.length) {
      d = `M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
      for (let i = 1; i < pts.length; i++) {
        const [x0, y0] = pts[i - 1], [x1, y1] = pts[i];
        // leicht gebogen, wie von Hand gezogen
        const mx = (x0 + x1) / 2 + (y1 - y0) * 0.12, my = (y0 + y1) / 2 - (x1 - x0) * 0.12;
        d += ` Q${mx.toFixed(1)},${my.toFixed(1)} ${x1.toFixed(1)},${y1.toFixed(1)}`;
      }
    }
    const sw = Math.max(1.5, U * 0.26);
    let html = "";
    if (d) {
      const id = `m${Math.floor(rng() * 1e9)}`;
      html += `<defs><mask id="${id}" maskUnits="userSpaceOnUse" x="0" y="0" width="${w}" height="${h}"><path class="draw" d="${d}" fill="none" stroke="#fff" stroke-width="${sw * 3}" stroke-linecap="round"/></mask></defs>`;
      html += `<path class="route" d="${d}" stroke-width="${sw}" stroke-dasharray="${sw * 2.6} ${sw * 1.8}" mask="url(#${id})"/>`;
    }
    const labelled = [];
    (trip.places || []).slice(0, 4).forEach((place, i) => {
      const [x, y] = v.fwd(place.lat, place.lon);
      if (x < 0 || y < 0 || x > w || y > h) return;
      html += `<circle class="dot" cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${(sw * (i === 0 ? 1.9 : 1.5)).toFixed(1)}" stroke-width="${(sw * 0.5).toFixed(1)}"/>`;
      const name = city(place.name);
      if (!name || i > 2) return;
      const size = U * (i === 0 ? 1.9 : 1.6);
      let ly = y - size * 0.7;
      if (labelled.some(([lx, lyy]) => Math.abs(lx - x) < size * 5 && Math.abs(lyy - ly) < size)) ly = y + size * 1.4;
      labelled.push([x, ly]);
      const anchor = x > w * 0.72 ? "end" : x < w * 0.28 ? "start" : "middle";
      html += `<text class="lbl" x="${x.toFixed(1)}" y="${ly.toFixed(1)}" text-anchor="${anchor}" font-size="${size.toFixed(1)}" stroke-width="${(U * 0.35).toFixed(1)}">${esc(name)}</text>`;
    });
    if (trip.home) {
      const [hx, hy] = v.fwd(trip.home.lat, trip.home.lon);
      const size = U * 1.5;
      if (v.homeIn) {
        // ein kleines Haus
        const s2 = size * 0.55;
        html += `<path class="home" stroke-width="${(U * 0.16).toFixed(1)}" d="M${hx - s2},${hy + s2 * 0.2} L${hx},${hy - s2} L${hx + s2},${hy + s2 * 0.2} M${hx - s2 * 0.7},${hy} V${hy + s2} H${hx + s2 * 0.7} V${hy}"/>`;
        html += `<text class="homelbl" x="${hx.toFixed(1)}" y="${(hy + size * 1.5).toFixed(1)}" text-anchor="middle" font-size="${size.toFixed(1)}" stroke-width="${(U * 0.3).toFixed(1)}">${esc(state.s.HomeName ? city(state.s.HomeName) : tx("home"))}</text>`;
      } else {
        // Pfeil am Rand in Richtung Zuhause
        const cx = w / 2, cy = h / 2;
        const dx = hx - cx, dy = hy - cy;
        const len = Math.hypot(dx, dy) || 1;
        const ux = dx / len, uy = dy / len;
        const t = Math.min((w / 2 - U * 3) / Math.max(1e-6, Math.abs(ux)), (h / 2 - U * 3) / Math.max(1e-6, Math.abs(uy)));
        const ax = cx + ux * t, ay = cy + uy * t;
        const tail = U * 3.2;
        const a0x = ax - ux * tail, a0y = ay - uy * tail;
        const hs = U * 0.9;
        html += `<path class="home" stroke-width="${(U * 0.2).toFixed(1)}" d="M${a0x.toFixed(1)},${a0y.toFixed(1)} Q${((a0x + ax) / 2 + uy * U * 0.6).toFixed(1)},${((a0y + ay) / 2 - ux * U * 0.6).toFixed(1)} ${ax.toFixed(1)},${ay.toFixed(1)} M${(ax - ux * hs - uy * hs * 0.7).toFixed(1)},${(ay - uy * hs + ux * hs * 0.7).toFixed(1)} L${ax.toFixed(1)},${ay.toFixed(1)} L${(ax - ux * hs + uy * hs * 0.7).toFixed(1)},${(ay - uy * hs - ux * hs * 0.7).toFixed(1)}"/>`;
        // Beschriftung am Rand neben der Pfeilspitze, nicht über der Route
        // senkrechter Pfeil: Text daneben statt darunter
        const anchor = ux > 0.3 ? "end" : ux < -0.3 ? "start" : ax > w / 2 ? "end" : "start";
        const side = Math.abs(ux) <= 0.3 ? (anchor === "end" ? -U * 1.4 : U * 1.4) : (anchor === "end" ? -U * 0.4 : U * 0.4);
        const lx = Math.max(U * 1.2, Math.min(w - U * 1.2, ax + side));
        const ly = uy < 0 ? ay + U * 2.6 : Math.min(h - U * 0.6, ay + U * 2.2);
        html += `<text class="homelbl" x="${lx.toFixed(1)}" y="${ly.toFixed(1)}" text-anchor="${anchor}" font-size="${size.toFixed(1)}" stroke-width="${(U * 0.3).toFixed(1)}">${esc(tx("homeArrow", { d: dist(trip.farKm) }))}</text>`;
      }
    }
    // Nordpfeil
    const nx = U * 1.6, ny = U * 1.4;
    html += `<path class="home" stroke-width="${(U * 0.14).toFixed(1)}" d="M${nx},${ny + U * 2.2} L${nx},${ny} M${nx - U * 0.5},${ny + U * 0.7} L${nx},${ny} L${nx + U * 0.5},${ny + U * 0.7}"/>`;
    html += `<text class="homelbl" x="${nx + U * 0.8}" y="${ny + U * 1.9}" font-size="${(U * 1.3).toFixed(1)}" stroke-width="${(U * 0.25).toFixed(1)}">N</text>`;
    svg.innerHTML = html;
    holder.appendChild(svg);
    const draw = svg.querySelector("path.draw");
    if (draw) {
      const length = draw.getTotalLength ? draw.getTotalLength() : 2000;
      draw.style.strokeDasharray = `${length} ${length}`;
      draw.style.strokeDashoffset = state.s.Animate ? `${length}` : "0";
      card.dataset.routeLength = String(length);
    }
  }

  function startRoute(card) {
    const draw = card.querySelector("path.draw");
    if (!draw) return;
    const length = Number(card.dataset.routeLength || 2000);
    draw.style.transition = `stroke-dashoffset ${Math.min(6, 2 + length / 400)}s ease-in-out`;
    requestAnimationFrame(() => { draw.style.strokeDashoffset = "0"; });
  }

  // ------------------------------------------------------------------ Wetter

  function wxKind(code) {
    code = Number(code) || 0;
    if (code === 0) return "sun";
    if (code <= 2) return "partly";
    if (code === 3) return "cloud";
    if (code === 45 || code === 48) return "fog";
    if ((code >= 71 && code <= 77) || code === 85 || code === 86) return "snow";
    if (code >= 95) return "storm";
    return "rain";
  }

  function icon(kind, rng) {
    const j = () => (rng ? rng.range(-1.2, 1.2) : 0).toFixed(1);
    const cloud = (dx = 0, dy = 0) => `<path class="cloudfill" d="M${10 + dx},${30 + dy} C${3 + dx},${30 + dy} ${3 + dx},${19 + dy} ${11 + dx},${19 + dy} C${12 + dx},${11 + dy} ${23 + dx},${9 + dy} ${27 + dx},${16 + dy} C${34 + dx},${13 + dy} ${40 + dx},${20 + dy} ${36 + dx},${26 + dy} C${40 + dx},${29 + dy} ${37 + dx},${31 + dy} ${34 + dx},${30 + dy} Z"/>`;
    const sun = (cx, cy, r) => {
      let rays = "";
      for (let i = 0; i < 8; i++) {
        const a = i * Math.PI / 4;
        rays += `M${(cx + Math.cos(a) * r * 1.35).toFixed(1)},${(cy + Math.sin(a) * r * 1.35).toFixed(1)} L${(cx + Math.cos(a) * r * 1.85).toFixed(1)},${(cy + Math.sin(a) * r * 1.85).toFixed(1)} `;
      }
      return `<path d="${rays}"/><circle class="sunfill" cx="${cx}" cy="${cy}" r="${r}"/>`;
    };
    let body = "";
    if (kind === "sun") body = sun(22, 22, 8.5);
    else if (kind === "partly") body = sun(15, 15, 6.5) + cloud(3, 6);
    else if (kind === "cloud") body = cloud(-2, 0) + cloud(4, 6);
    else if (kind === "fog") body = `<path d="M6,14 H38 M3,21 H34 M8,28 H40 M5,35 H30"/>`;
    else if (kind === "rain") body = cloud(0, -3) + `<path class="rain" d="M14,32 l-3,7 M22,32 l-3,7 M30,32 l-3,7"/>`;
    else if (kind === "snow") body = cloud(0, -3) + `<path class="snow" d="M13,34 v6 M10,37 h6 M23,34 v6 M20,37 h6 M33,34 v6 M30,37 h6"/>`;
    else if (kind === "storm") body = cloud(0, -3) + `<path class="bolt" d="M22,28 L17,37 H22 L19,44 L28,33 H23 L26,28 Z"/>`;
    return `<svg viewBox="0 0 44 44" class="wx" style="transform:rotate(${j()}deg)">${body}</svg>`;
  }

  function weatherStrip(page, x, y, w, h, trip, rng) {
    const wx = trip.wx || [];
    if (!wx.length) return null;
    const node = box(page, "weather fade", x, y, w, h);
    const wi = Math.min(h * 0.62, U * 4);
    const maxDays = Math.max(4, Math.floor(w / (wi * 1.3)));
    node.style.setProperty("--wi", `${wi}px`);
    let html = "";
    if (wx.length <= maxDays) {
      for (const day of wx) {
        html += `<div class="day">${icon(wxKind(day.code), rng)}<b>${deg(day.tmax)}</b><small>${esc(fmt(day.date, { day: "numeric" }))}.</small></div>`;
      }
    } else {
      const counts = {};
      for (const day of wx) counts[wxKind(day.code)] = (counts[wxKind(day.code)] || 0) + 1;
      const orderKinds = ["sun", "partly", "cloud", "rain", "storm", "snow", "fog"];
      const kinds = orderKinds.filter((k) => counts[k]).length;
      // alles in eine Zeile: Symbole notfalls kleiner
      const fit = Math.max(U * 2.6, w / (kinds * 2.1 + 3.4));
      if (fit < wi) node.style.setProperty("--wi", `${fit}px`);
      node.classList.add("summary");
      for (const kind of orderKinds) {
        if (!counts[kind]) continue;
        html += `<div class="sum">${icon(kind, rng)}<b>×${counts[kind]}</b></div>`;
      }
      const tmax = Math.max(...wx.map((d) => d.tmax ?? -99));
      const tmin = Math.min(...wx.map((d) => d.tmin ?? 99));
      html += `<div class="sum"><b>${deg(tmin)} … ${deg(tmax)}</b></div>`;
    }
    node.innerHTML = html;
    return node;
  }

  // ------------------------------------------------------------------ Notizen

  function stations(trip) {
    const named = (trip.places || []).filter((p) => p.name).slice(0, 4)
      .sort((a, b) => String(a.first || "").localeCompare(String(b.first || "")));
    const names = [];
    for (const p of named) { const c = city(p.name); if (c && !names.includes(c)) names.push(c); }
    return names;
  }

  function notesFor(trip, rng, limit) {
    const out = [];
    if (trip.note) out.push({ text: trip.note, own: true });
    const wx = trip.wx || [];
    const pool = [];
    const list = stations(trip);
    if (list.length >= 2) pool.push({ p: 9, text: tx("nStations", { list: list.join(" → ") }) });
    if (trip.days <= 3 && list.length >= 1 && [5, 6].includes(date(trip.start).getDay())) {
      pool.push({ p: 8, text: tx("nWeekend", { place: list[0] }) });
    }
    if (wx.length) {
      const hot = wx.reduce((a, b) => ((b.tmax ?? -99) > (a.tmax ?? -99) ? b : a));
      const cold = wx.reduce((a, b) => ((b.tmin ?? 99) < (a.tmin ?? 99) ? b : a));
      const snowy = wx.filter((d) => wxKind(d.code) === "snow").length;
      const rainy = wx.filter((d) => ["rain", "storm"].includes(wxKind(d.code)) || (wxKind(d.code) !== "snow" && (d.rain ?? 0) >= 2)).length;
      if (snowy) pool.push({ p: 8, text: snowy === 1 ? tx("nSnow1") : tx("nSnow", { n: snowy }) });
      if (hot.tmax !== null && hot.tmax >= 18) {
        pool.push({ p: hot.tmax >= 30 ? 8 : 6, text: tx(hot.tmax >= 30 ? "nHotWow" : "nHot", { t: deg(hot.tmax), date: dayMonth(hot.date) }), accent: hot.tmax >= 30 });
      }
      if (cold.tmin !== null && cold.tmin <= 2) pool.push({ p: 7, text: tx("nCold", { t: deg(cold.tmin) }) });
      if (wx.length >= 3 && rainy === 0) pool.push({ p: 7, text: tx("nNoRain"), accent: true });
      else if (rainy === 1) pool.push({ p: 4, text: tx("nRain1") });
      else if (rainy > 1) pool.push({ p: 5, text: tx("nRain", { n: rainy }) });
      const sun = wx.reduce((sum, d) => sum + (d.sun || 0), 0);
      if (sun >= 20) pool.push({ p: 4, text: tx("nSun", { h: num(Math.round(sun)) }) });
    }
    if (trip.bestDay && trip.bestDay.photos >= 12 && trip.days > 1) {
      pool.push({ p: 6, text: tx("nBest", { n: num(trip.bestDay.photos), date: dayMonth(trip.bestDay.date) }) });
    }
    if (trip.fiveStars >= 3) pool.push({ p: 5, text: tx("nFive", { n: trip.fiveStars }), accent: true });
    if (trip.farKm >= 300) pool.push({ p: 5, text: tx("nFar", { d: dist(trip.farKm) }) });
    if (trip.firstShot) {
      const t = new Date(trip.firstShot);
      if (!Number.isNaN(t.getTime())) {
        pool.push({ p: t.getHours() < 7 ? 6 : 2, text: tx("nEarly", {
          weekday: t.toLocaleDateString(locale(), { weekday: "short" }),
          time: t.toLocaleTimeString(locale(), { hour: "2-digit", minute: "2-digit" }) }) });
      }
    }
    if (trip.nights >= 10) pool.push({ p: 3, text: tx("nLong", { n: trip.nights }) });
    pool.push({ p: 1, text: tx("nPhotos", { n: num(trip.count), d: trip.days }) });
    pool.forEach((item) => { item.score = item.p + rng() * 3; });
    pool.sort((a, b) => b.score - a.score);
    for (const item of pool) {
      if (out.length >= limit) break;
      out.push(item);
    }
    return out;
  }

  function addNotes(page, x, y, w, h, trip, rng) {
    const notes = notesFor(trip, rng, LAND ? 4 : 3);
    if (!notes.length) return [];
    const nodes = [];
    const lineH = Math.min(h / Math.max(3, notes.length + 0.5), U * 4.4);
    let fs = lineH * 0.78;
    let yy = y;
    notes.forEach((note, i) => {
      const node = box(page, `note write${note.accent ? " accent" : ""}`, x + rng.range(0, U * 2.5), yy, null, null, { rot: rng.range(-2.5, 2) });
      node.style.setProperty("--fs", `${note.own ? fs * 1.08 : fs}px`);
      node.style.transform = `rotate(${rng.range(-2.5, 2).toFixed(2)}deg)`;
      node.style.transformOrigin = "left center";
      node.style.setProperty("--wt", `${Math.min(3.2, 0.5 + note.text.length * 0.045).toFixed(2)}s`);
      node.textContent = note.text;
      if (note.own) node.style.color = state.s.Paper === "black" ? "#9cc3ff" : "#1d3f86";
      // zu lang? kleiner schreiben
      const width = w - (parseFloat(node.style.left) - x);
      const measured = textWidth(note.text, `${note.own ? fs * 1.08 : fs}px Hand, cursive`);
      if (measured > width) node.style.setProperty("--fs", `${(note.own ? fs * 1.08 : fs) * width / measured}px`);
      nodes.push(node);
      yy += lineH * (note.own ? 1.15 : 1);
    });
    return nodes;
  }

  const measureCtx = document.createElement("canvas").getContext("2d");
  function textWidth(text, font) {
    measureCtx.font = font;
    return measureCtx.measureText(text).width;
  }

  // ------------------------------------------------------------------ Ticket, Stempel, Überschrift

  function addTicket(page, x, y, w, h, trip, number) {
    const tu = U * Math.max(0.7, Math.min(1, w / (U * 34)));
    h = Math.min(h, tu * 7.6);
    const node = box(page, "ticket pop", x, y, w, h, { rot: -1.2 });
    const year = trip.start.slice(0, 4);
    const month = fmt(trip.start, { month: "short" }).replace(".", "").toUpperCase();
    node.innerHTML = `<div class="body"><div class="head">${esc(tx("tripNo", { n: number }))}</div>
      <div class="row">
        <div class="fig"><b>${trip.days}</b><span>${esc((trip.days === 1 ? tx("day") : tx("days")).toUpperCase())}</span></div>
        <div class="fig"><b>${esc(num(Math.round(imperial() ? trip.km * 0.621371 : trip.km)))}</b><span>${esc((imperial() ? tx("mi") : tx("km")).toUpperCase())}</span></div>
        <div class="fig"><b>${esc(num(trip.count))}</b><span>${esc(tx("photos").toUpperCase())}</span></div>
      </div></div>
      <div class="stub"><span>${esc(month)}</span><b>${esc(year)}</b></div>`;
    // Schrift an die Breite anpassen
    node.style.setProperty("--u", `${tu}px`);
    node.usedHeight = h;
    return node;
  }

  function addStamp(page, x, y, size, trip, rng) {
    const node = box(page, "stampbox stamp", x, y, size, size, { rot: rng.range(-18, 14), z: 40 });
    node.style.setProperty("--op", rng.range(0.62, 0.8).toFixed(2));
    const top = (trip.countries && trip.countries.length ? trip.countries.slice(0, 2).join(" · ") : titleOf(trip)).toUpperCase();
    const month = fmt(trip.start, { month: "short" }).replace(".", "").toUpperCase();
    const id = `s${Math.floor(rng() * 1e9)}`;
    const fsTop = Math.max(5, Math.min(9, 150 / Math.max(6, top.length)));
    node.innerHTML = `<svg viewBox="0 0 100 100">
      <defs><path id="${id}a" d="M50,50 m-36,0 a36,36 0 1,1 72,0"/><path id="${id}b" d="M50,50 m-36,0 a36,36 0 1,0 72,0"/>
      <filter id="${id}f"><feTurbulence type="fractalNoise" baseFrequency="1.6" numOctaves="2" seed="${Math.floor(rng() * 50)}"/><feColorMatrix values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -1.6 1.25"/><feComposite in="SourceGraphic" operator="in"/></filter></defs>
      <g filter="url(#${id}f)">
      <circle class="ring" cx="50" cy="50" r="47" stroke-width="3"/><circle class="ring" cx="50" cy="50" r="28" stroke-width="1.6"/>
      <text font-size="${fsTop}" letter-spacing="1.5" text-anchor="middle"><textPath href="#${id}a" startOffset="50%">${esc(top)}</textPath></text>
      <text font-size="7" letter-spacing="3" text-anchor="middle" dy="6"><textPath href="#${id}b" startOffset="50%">★ ${esc(tx("trip"))} ★</textPath></text>
      <text x="50" y="48" font-size="11" text-anchor="middle">${esc(month)}</text>
      <text x="50" y="62" font-size="14" text-anchor="middle">${esc(trip.start.slice(0, 4))}</text></g></svg>`;
    return node;
  }

  function addTitle(page, x, y, maxW, trip, rng) {
    const title = titleOf(trip);
    let size = U * (LAND ? 5.6 : 6.2);
    const width = textWidth(title, `700 ${size}px Hand, cursive`);
    if (width > maxW) size *= maxW / width;
    const node = box(page, "title write", x, y, null, null, { rot: rng.range(-2, 0.5) });
    node.style.transform = `rotate(${rng.range(-2, 0.5).toFixed(2)}deg)`;
    node.style.transformOrigin = "left center";
    node.style.fontSize = `${size}px`;
    node.style.setProperty("--wt", "1.2s");
    const tw = Math.min(maxW, textWidth(title, `700 ${size}px Hand, cursive`));
    const sub = range(trip);
    node.innerHTML = `${esc(title)}<svg class="line" width="${tw}" viewBox="0 0 100 10" preserveAspectRatio="none"><path d="M1,6 C20,3 40,8 60,5 S90,4 99,6" stroke-width="2.2" vector-effect="non-scaling-stroke" style="stroke-width:${Math.max(2, U * 0.28)}px"/></svg><span class="sub" style="font-size:${(U * (LAND ? 2.3 : 2.6)).toFixed(1)}px">${esc(sub)}</span>`;
    return node;
  }

  // ------------------------------------------------------------------ Eine Reise als Seite

  async function buildTrip(trip, number) {
    measure();
    const rng = rngFor(trip.id + (trip.title || ""));
    const imgs = await Promise.all((trip.photos || []).map((p) => loadImage(p.id)));
    if (!imgs.some(Boolean)) report(`Reise ${trip.id}: keine Abzüge geladen`);
    try { await document.fonts.ready; } catch (_) { /* egal */ }
    const page = newPage("trip");
    page.dataset.trip = trip.id;
    const steps = { prints: [], late: [], notes: [], map: null, stamp: null };
    const s = state.s;
    const pct = (v, total) => v * total / 100;

    if (LAND) {
      const fold = 61;
      page.style.setProperty("--fold", fold);
      steps.late.push(addTitle(page, pct(3.5, W), pct(3, H), pct(43, W), trip, rng));
      steps.prints = addPrints(page, { x: pct(2.5, W), y: pct(19, H), w: pct(56, W), h: pct(78, H) }, trip, imgs, rng);
      steps.stamp = addStamp(page, pct(47.5, W), pct(2, H), U * 10, trip, rng);
      const col = { x: pct(64, W), w: pct(33, W) };
      let y = pct(5, H);
      if (s.ShowMap) {
        const mh = pct(41, H);
        const card = box(page, "mapcard pop", col.x, y, col.w, mh, { rot: rng.range(-2.2, 2.2), z: 5 });
        card.innerHTML = `<div class="map"></div>`;
        addTape(card, { w: col.w, h: mh }, rng, rng.pick(["top", "corners"]));
        steps.map = card;
        y += mh + pct(4, H);
      }
      const ticket = addTicket(page, col.x + U * 0.5, y, col.w * 0.9, pct(12, H), trip, number);
      steps.late.push(ticket);
      y += ticket.usedHeight + pct(3.5, H);
      if (s.ShowWeather) {
        const strip = weatherStrip(page, col.x, y, col.w, pct(8.5, H), trip, rng);
        if (strip) { steps.late.push(strip); y += pct(11, H); }
      }
      if (s.ShowNotes) steps.notes = addNotes(page, col.x, y, col.w, H - y - pct(3, H), trip, rng);
    } else {
      steps.late.push(addTitle(page, pct(5, W), pct(2.5, H), pct(70, W), trip, rng));
      steps.stamp = addStamp(page, pct(76, W), pct(1.6, H), U * 9.5, trip, rng);
      steps.prints = addPrints(page, { x: pct(3, W), y: pct(12.5, H), w: pct(94, W), h: pct(46, H) }, trip, imgs, rng);
      const top = pct(61, H);
      const left = { x: pct(4, W), w: pct(48, W) };
      const right = { x: pct(55, W), w: pct(41, W) };
      if (s.ShowMap) {
        const mh = pct(25, H);
        const card = box(page, "mapcard pop", left.x, top, left.w, mh, { rot: rng.range(-2, 2), z: 5 });
        card.innerHTML = `<div class="map"></div>`;
        addTape(card, { w: left.w, h: mh }, rng, "top");
        steps.map = card;
      }
      let y = top;
      const ticket = addTicket(page, right.x, y, right.w, pct(9, H), trip, number);
      steps.late.push(ticket);
      y += ticket.usedHeight + pct(2.5, H);
      if (s.ShowWeather) {
        const strip = weatherStrip(page, right.x, y, right.w, pct(6, H), trip, rng);
        if (strip) { steps.late.push(strip); y += pct(8, H); }
      }
      if (s.ShowNotes) {
        const nx = s.ShowMap ? pct(5, W) : right.x;
        const ny = s.ShowMap ? pct(88, H) : y;
        steps.notes = addNotes(page, nx, ny, s.ShowMap ? pct(90, W) : right.w, H - ny - pct(1.5, H), trip, rng);
      }
    }
    page.steps = steps;
    return page;
  }

  async function buildCover() {
    measure();
    const t = state.totals || {};
    const rng = rngFor(`cover${t.trips}${t.days}`);
    const page = newPage("cover");
    const picks = state.trips.slice(0, 8).map((trip) => (trip.photos || []).find((p) => p.best) || (trip.photos || [])[0]).filter(Boolean).slice(0, 6);
    const imgs = await Promise.all(picks.map((p) => loadImage(p.id)));
    try { await document.fonts.ready; } catch (_) { /* egal */ }
    const steps = { prints: [], late: [], notes: [], map: null, stamp: null };
    const slots = LAND
      ? [[4, 5, 26, 40], [70, 4, 26, 40], [3, 55, 24, 40], [73, 55, 24, 40], [31, 64, 18, 32], [52, 64, 18, 32]]
      : [[4, 3, 44, 22], [52, 4, 44, 22], [3, 70, 44, 24], [53, 71, 44, 24], [6, 27, 30, 16], [64, 27, 30, 16]];
    picks.forEach((photo, i) => {
      const img = imgs[i];
      if (!img) return;
      const [x, y, w, h] = slots[i];
      const cell = { x: x * W / 100, y: y * H / 100, w: w * W / 100, h: h * H / 100 };
      const aspect = img.naturalWidth / img.naturalHeight || 1.5;
      const p = placePrint(cell, aspect, rng() < 0.5, 1);
      const node = box(page, "print pop", p.x, p.y, p.w, p.h, { tag: "figure", rot: rng.range(2, 7) * rng.sign(), z: 5 + i });
      node.style.setProperty("--pad", `${p.pad}px`);
      node.style.setProperty("--padb", `${p.padb}px`);
      const pic = document.createElement("div");
      pic.className = "pic";
      const clone = img.cloneNode();
      pic.appendChild(clone);
      node.appendChild(pic);
      addTape(node, p, rng, rng.pick(["top", "corners", "photo-corners"]));
      steps.prints.push(node);
    });
    const lw = LAND ? W * 0.4 : W * 0.8;
    const lh = LAND ? H * 0.42 : H * 0.3;
    const label = box(page, "label pop", (W - lw) / 2, (LAND ? H * 0.2 : H * 0.36), lw, lh, { rot: -1.5, z: 30 });
    const years = t.first && t.last && t.first !== t.last ? `${t.first}–${t.last}` : (t.first || "");
    label.innerHTML = `<div class="k">${esc(tx("coverKicker"))}</div><h1>${esc(tx("coverTitle"))}</h1>
      <p>${esc(tx("coverLine", { trips: num(t.trips), days: num(t.days) }))}</p>
      <p>${esc(tx("coverLine2", { km: dist(t.km || 0), countries: t.countries === 1 ? tx("countries1") : tx("countriesN", { n: t.countries || 0 }), years }))}</p>`;
    label.style.display = "flex";
    label.style.flexDirection = "column";
    label.style.justifyContent = "center";
    const tape = document.createElement("i");
    tape.className = "tape";
    tape.style.cssText = `width:${U * 12}px;height:${U * 2.6}px;left:${lw / 2 - U * 6}px;top:${-U * 1.3}px;transform:rotate(-3deg)`;
    label.appendChild(tape);
    steps.late.push(label);
    page.steps = steps;
    return page;
  }

  // ------------------------------------------------------------------ Zeigen und Abläufe

  function reveal(page) {
    const st = page.steps || {};
    if (!state.s.Animate) {
      if (st.map) startRoute(st.map);
      return;
    }
    let t = 600;
    const at = (node, delay) => { if (node) setTimeout(() => node.classList.add("in"), delay); };
    for (const node of st.late.slice(0, 1)) { at(node, t); t += 500; }
    for (const node of st.prints) { at(node, t); t += 420; }
    if (st.map) { at(st.map, t); setTimeout(() => startRoute(st.map), t + 700); t += 900; }
    for (const node of st.late.slice(1)) { at(node, t); t += 450; }
    for (const node of st.notes) {
      at(node, t);
      t += parseFloat(node.style.getPropertyValue("--wt") || "1.5") * 1000 + 250;
    }
    if (st.stamp) at(st.stamp, t + 300);
  }

  async function show(page) {
    el("message").hidden = true;
    const stage = el("stage");
    const old = current;
    const slide = state.s.Animate && old;
    page.classList.add(slide ? "enter" : "fade-enter");
    stage.appendChild(page);
    if (page.steps && page.steps.map && page.dataset.trip) {
      const trip = state.trips.find((t) => t.id === page.dataset.trip);
      try { await drawMap(page.steps.map, trip, rngFor(trip.id)); } catch (error) { report(`Karte: ${error.message}`); }
    }
    // zwei Frames warten, dann hereinschieben
    await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
    page.classList.remove("enter", "fade-enter");
    if (old) {
      old.classList.add(slide ? "leave" : "fade-leave");
      setTimeout(() => old.remove(), 1600);
    }
    current = page;
    setTimeout(() => reveal(page), slide ? 900 : 200);
    ready();
  }

  function showMessage(title, text) {
    el("msgTitle").textContent = title;
    el("msgText").textContent = text;
    el("message").hidden = false;
    document.querySelector(".message").style.setProperty("--grain", GRAIN);
    if (current) { current.remove(); current = null; }
    ready();
  }

  function tripNumber(trip) {
    const sorted = state.trips.map((t) => t.start).sort();
    return sorted.indexOf(trip.start) + 1;
  }

  async function next() {
    clearTimeout(timer);
    const seconds = Math.max(10, Number(state.s.PageSeconds) || 45);
    if (!state.trips.length) {
      if (!state.loaded) showMessage(tx("offline"), tx("offlineText"));
      else if (!state.sources) showMessage(tx("noneTitle"), tx("noSource"));
      else if (state.busy) showMessage(tx("busyTitle"), tx("busy"));
      else showMessage(tx("noneTitle"), tx("none", { days: state.minDays, km: dist(state.minKm) }));
      timer = setTimeout(async () => { await fetchScene(); next(); }, 15000);
      return;
    }
    const wanted = params.get("trip");
    if (params.get("cover") || (state.s.ShowCover && !shownCover && state.trips.length >= 2 && !wanted)) {
      shownCover = true;
      await show(await buildCover());
      timer = setTimeout(next, Math.min(seconds, 20) * 1000);
      if (params.get("cover")) clearTimeout(timer);
      return;
    }
    if (wanted) pos = Math.max(0, state.trips.findIndex((t) => t.id === wanted));
    else pos = pos < 0 ? Math.min(state.start, state.trips.length - 1) : (pos + 1) % state.trips.length;
    const trip = state.trips[pos];
    const page = await buildTrip(trip, tripNumber(trip));
    await show(page);
    if (!wanted) {
      fetch(`${base()}api/shown?id=${encodeURIComponent(trip.id)}`, { cache: "no-store" }).catch(() => {});
      timer = setTimeout(next, seconds * 1000);
      // die nächste Seite schon laden
      const upcoming = state.trips[(pos + 1) % state.trips.length];
      setTimeout(() => (upcoming.photos || []).forEach((p) => loadImage(p.id)), Math.max(2000, seconds * 1000 - 12000));
    }
  }

  async function start() {
    measure();
    await fetchScene();
    await next();
    setInterval(fetchScene, 60000);
    let resizeTimer = 0;
    window.addEventListener("resize", () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        const was = LAND;
        measure();
        if (was !== LAND && state.trips.length) { pos = (pos - 1 + state.trips.length) % state.trips.length; next(); }
      }, 600);
    });
  }

  setTimeout(() => { if (!readySent) ready(); }, 8000);
  start();
})();
