/* Satellite Swarm - die Szene.
 *
 * Alle aktiven Satelliten (Bahndaten von CelesTrak über das Plugin) als
 * Schwarm um die Erde oder als Himmel über dem eigenen Haus.
 *
 * Das Plugin liefert für jeden Satelliten mittlere Bahnelemente, alle auf die
 * gleiche Zeit t0 gebracht (api/scene, Spalten a, e, i, O, w, M, n, Od, wd,
 * dr). Alle 20 Sekunden rechnet die Szene daraus in doppelter Genauigkeit den
 * Stand für "jetzt" (rebase) und lädt ihn auf die Grafikkarte; die rechnet
 * dann in jedem Bild für jeden Punkt die Kepler-Gleichung (wenige Sekunden
 * weit, also auch in float32 genau). Die Erde dreht sich darunter mit der
 * Sternzeit, Tag und Nacht nach dem echten Sonnenstand; Satelliten im
 * Erdschatten leuchten schwächer.
 *
 * Überflüge (ISS, Tiangong, Hubble, frische Starlink-Züge) rechnet das
 * Plugin; die Szene sagt sie an ("Jetzt fliegt die ISS über dich").
 *
 * Zum Ausprobieren: ?plugin=<URL der Plugin-Seite> &lang=de|en|es
 * &view=globe|sky &shift=<Sekunden> (Uhr verstellen) &fps=1
 */
(function () {
  "use strict";

  const PLUGIN_ID = "SatelliteSwarm";
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const sameOrigin = (location.protocol === "http:" && (location.port === "" || location.port === "80"))
    || (location.protocol === "https:" && (location.port === "" || location.port === "443"));
  const pluginBases = params.get("plugin") ? [params.get("plugin").replace(/\/?$/, "/")] : [...new Set(sameOrigin ? [
    `${location.origin}${advanced}`,
    `${location.protocol}//${location.hostname}:8003${advanced}`
  ] : [
    `${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`,
    `http://${location.hostname || "localhost"}${advanced}`
  ])];
  let baseIndex = 0;
  const SHIFT = Number(params.get("shift") || 0) * 1000;
  const nowSec = () => (Date.now() + SHIFT) / 1000;

  const TEXT = {
    de: {
      globe: "Alle aktiven Satelliten", sky: "Der Himmel über {place}", skyNoPlace: "Der Himmel über dir",
      sats: "{n} Satelliten", above: "{n} gerade über dir", sunlit: "{n} davon in der Sonne",
      groups: ["Starlink", "OneWeb", "Navigation (GPS & Co.)", "Wetter & Erdbeobachtung", "Raumstationen",
        "Wissenschaft", "Kommunikation & GEO", "Sonstige"],
      next: "Nächste Überflüge", none: "Keine angesagten Überflüge in den nächsten 36 Stunden.",
      noPlace: "Trag auf der Plugin-Seite deinen Ort ein, dann zeigt die Szene den Himmel über dir und sagt Überflüge an.",
      visible: "sichtbar", credit: "Bahndaten: CelesTrak (celestrak.org) · Karte: Natural Earth",
      wait: "Satellite Swarm holt die Bahndaten von CelesTrak …", unreachable: "Satellite Swarm antwortet nicht.",
      login: "Bitte zuerst im Browser beim Rahmen anmelden.", error: "CelesTrak ist gerade nicht erreichbar.",
      home: "Zuhause", train: "Starlink-Zug ({n})",
      who: { iss: "die ISS", css: "die Raumstation Tiangong", hst: "das Hubble-Teleskop", train: "ein Starlink-Zug" },
      whoShort: { iss: "ISS", css: "Tiangong", hst: "Hubble", train: "Starlink-Zug" },
      nowTitle: "Jetzt fliegt {who} über dich", soonTitle: "In {m} Minuten fliegt {who} über dich",
      soonTitle1: "In einer Minute fliegt {who} über dich",
      kickerNow: "ÜBERFLUG", kickerSoon: "GLEICH", kickerVisible: "MIT BLOSSEM AUGE SICHTBAR",
      lookNow: "Schau nach {dir}, {el}° über dem Horizont", lookSoon: "Kommt aus dem {dir}, am höchsten um {time} im {dirMax} ({el}°)",
      trainNote: "{n} Satelliten wie an einer Perlenkette", seen: "gut zu sehen", day: "am Tag nicht zu sehen",
      shadow: "im Erdschatten, nicht zu sehen", hour: "{t} Uhr",
      dirs: ["Norden", "Nordosten", "Osten", "Südosten", "Süden", "Südwesten", "Westen", "Nordwesten"],
      dirsTo: ["Norden", "Nordosten", "Osten", "Südosten", "Süden", "Südwesten", "Westen", "Nordwesten"],
      compass: ["N", "NO", "O", "SO", "S", "SW", "W", "NW"], today: "heute", tomorrow: "morgen"
    },
    en: {
      globe: "All active satellites", sky: "The sky above {place}", skyNoPlace: "The sky above you",
      sats: "{n} satellites", above: "{n} above you right now", sunlit: "{n} of them in sunlight",
      groups: ["Starlink", "OneWeb", "Navigation (GPS etc.)", "Weather & Earth observation", "Space stations",
        "Science", "Communication & GEO", "Other"],
      next: "Next passes", none: "No announced passes in the next 36 hours.",
      noPlace: "Enter your place on the plugin page, then the scene shows the sky above you and announces passes.",
      visible: "visible", credit: "Orbit data: CelesTrak (celestrak.org) · Map: Natural Earth",
      wait: "Satellite Swarm is fetching the orbit data from CelesTrak …", unreachable: "Satellite Swarm is not responding.",
      login: "Please sign in to the frame in the browser first.", error: "CelesTrak cannot be reached right now.",
      home: "Home", train: "Starlink train ({n})",
      who: { iss: "the ISS", css: "the Tiangong space station", hst: "the Hubble telescope", train: "a Starlink train" },
      whoShort: { iss: "ISS", css: "Tiangong", hst: "Hubble", train: "Starlink train" },
      nowTitle: "Right now {who} is passing over you", soonTitle: "In {m} minutes {who} passes over you",
      soonTitle1: "In one minute {who} passes over you",
      kickerNow: "PASS", kickerSoon: "COMING UP", kickerVisible: "VISIBLE TO THE NAKED EYE",
      lookNow: "Look {dir}, {el}° above the horizon", lookSoon: "Rises in the {dir}, highest at {time} in the {dirMax} ({el}°)",
      trainNote: "{n} satellites like a string of pearls", seen: "easy to see", day: "not visible in daylight",
      shadow: "in the Earth's shadow, not visible", hour: "{t}",
      dirs: ["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"],
      dirsTo: ["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"],
      compass: ["N", "NE", "E", "SE", "S", "SW", "W", "NW"], today: "today", tomorrow: "tomorrow"
    },
    es: {
      globe: "Todos los satélites activos", sky: "El cielo sobre {place}", skyNoPlace: "El cielo sobre ti",
      sats: "{n} satélites", above: "{n} sobre ti ahora", sunlit: "{n} de ellos al sol",
      groups: ["Starlink", "OneWeb", "Navegación (GPS y otros)", "Meteorología y observación", "Estaciones espaciales",
        "Ciencia", "Comunicaciones y GEO", "Otros"],
      next: "Próximos pasos", none: "Ningún paso anunciado en las próximas 36 horas.",
      noPlace: "Introduce tu lugar en la página del plugin; entonces la escena muestra el cielo sobre ti y anuncia los pasos.",
      visible: "visible", credit: "Datos orbitales: CelesTrak (celestrak.org) · Mapa: Natural Earth",
      wait: "Satellite Swarm está cargando los datos de CelesTrak …", unreachable: "Satellite Swarm no responde.",
      login: "Inicia sesión primero en el marco desde el navegador.", error: "No se puede acceder a CelesTrak ahora mismo.",
      home: "Casa", train: "Tren Starlink ({n})",
      who: { iss: "la ISS", css: "la estación espacial Tiangong", hst: "el telescopio Hubble", train: "un tren de Starlink" },
      whoShort: { iss: "ISS", css: "Tiangong", hst: "Hubble", train: "Tren Starlink" },
      nowTitle: "Ahora pasa {who} sobre ti", soonTitle: "En {m} minutos pasa {who} sobre ti",
      soonTitle1: "En un minuto pasa {who} sobre ti",
      kickerNow: "PASO", kickerSoon: "ENSEGUIDA", kickerVisible: "VISIBLE A SIMPLE VISTA",
      lookNow: "Mira hacia el {dir}, a {el}° sobre el horizonte", lookSoon: "Sale por el {dir}, punto más alto a las {time} hacia el {dirMax} ({el}°)",
      trainNote: "{n} satélites como un collar de perlas", seen: "fácil de ver", day: "no se ve de día",
      shadow: "en la sombra de la Tierra, no se ve", hour: "{t}",
      dirs: ["norte", "noreste", "este", "sureste", "sur", "suroeste", "oeste", "noroeste"],
      dirsTo: ["norte", "noreste", "este", "sureste", "sur", "suroeste", "oeste", "noroeste"],
      compass: ["N", "NE", "E", "SE", "S", "SO", "O", "NO"], today: "hoy", tomorrow: "mañana"
    }
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  let lang = params.get("lang") || "en";
  const T = () => TEXT[lang] || TEXT.en;
  const tx = (key, values) => {
    let text = T()[key] ?? key;
    for (const [k, v] of Object.entries(values || {})) text = text.replace(`{${k}}`, v);
    return text;
  };
  const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang] || "en-GB");

  // Farben der Gruppen (Reihenfolge wie orbit.GROUPS im Plugin)
  const GROUP_KEYS = ["starlink", "oneweb", "navigation", "earth", "stations", "science", "comms", "other"];
  const GROUP_COLORS = [[0.62, 0.86, 1.0], [0.78, 0.6, 1.0], [1.0, 0.8, 0.35], [0.45, 0.95, 0.6],
    [1.0, 0.42, 0.32], [1.0, 0.55, 0.85], [0.5, 0.68, 1.0], [0.7, 0.72, 0.76]];
  const GROUP_SIZE = [1.9, 2.3, 3.4, 2.8, 6.0, 3.2, 2.9, 2.3];
  const GROUP_SETTING = GROUP_KEYS.map((g) => "Show" + g[0].toUpperCase() + g.slice(1));
  const css = (c, a = 1) => `rgba(${Math.round(c[0] * 255)},${Math.round(c[1] * 255)},${Math.round(c[2] * 255)},${a})`;

  const $ = (id) => document.getElementById(id);
  const bgCanvas = $("bg"), glCanvas = $("gl"), uiCanvas = $("ui");
  const bg = bgCanvas.getContext("2d"), ui = uiCanvas.getContext("2d");
  const note = $("note"), panel = $("panel"), banner = $("banner");
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const smooth = (k) => k * k * (3 - 2 * k);
  const TWO_PI = Math.PI * 2, DEG = Math.PI / 180, RE_KM = 6378.135;

  // ------------------------------------------------------------ Plugin

  async function api(path) {
    let lastError = null;
    for (let i = 0; i < pluginBases.length; i += 1) {
      const base = pluginBases[(baseIndex + i) % pluginBases.length];
      try {
        const response = await fetch(base + path, { cache: "no-store", credentials: "same-origin" });
        if ((response.redirected && /login/i.test(response.url)) || response.status === 401) throw new Error("login");
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const body = await response.json();
        baseIndex = (baseIndex + i) % pluginBases.length;
        return body;
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error("unreachable");
  }

  // Remote Frame ohne Anmeldung: /Plugins/Advanced/ gibt dann 401. Das Plugin
  // legt seinen Stand zusätzlich als Dateien in den Ordner der Szene
  // (data/live.json, data/catalog.json), den DynaFrame ohne Anmeldung ausliefert.
  let useFiles = false;
  async function readFile(name) {
    const response = await fetch(`data/${name}?t=${Date.now()}`, { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return response.json();
  }

  async function fromFiles() {
    const body = await readFile("live.json");
    if (body.ver && body.ver !== cat.ver) {
      const catalog = await readFile("catalog.json");
      if (catalog.ver === body.ver) Object.assign(body, catalog);
    }
    delete body.now;
    return body;
  }

  async function sceneData(path) {
    if (useFiles) {
      try { return await fromFiles(); } catch (_) { useFiles = false; }
    }
    try {
      return await api(path);
    } catch (error) {
      try {
        const body = await fromFiles();
        useFiles = true;
        return body;
      } catch (_) {
        throw error;
      }
    }
  }

  function report(message) {
    api("api/report?m=" + encodeURIComponent(String(message).slice(0, 180))).catch(() => {});
  }

  // DynaFrame wartet, bis die Szene meldet, dass sie steht; sonst bricht der
  // Fernseher nach einer Frist ab ("scene readiness deadline expired").
  let readySent = false;
  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 8000);

  function showNote(text) {
    note.textContent = text || "";
    note.hidden = !text;
  }

  // ------------------------------------------------------------ Astronomie

  function julian(unix) { return unix / 86400 + 2440587.5; }

  function gmst(unix) {
    const t = (julian(unix) - 2451545.0) / 36525.0;
    const temp = -6.2e-6 * t * t * t + 0.093104 * t * t + (876600.0 * 3600 + 8640184.812866) * t + 67310.54841;
    return (((temp * DEG / 240.0) % TWO_PI) + TWO_PI) % TWO_PI;
  }

  function sunDir(unix) {
    const n = julian(unix) - 2451545.0;
    const L = (280.460 + 0.9856474 * n) % 360;
    const g = ((357.528 + 0.9856003 * n) % 360) * DEG;
    const lam = (L + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)) * DEG;
    const eps = (23.439 - 0.0000004 * n) * DEG;
    return [Math.cos(lam), Math.cos(eps) * Math.sin(lam), Math.sin(eps) * Math.sin(lam)];
  }

  const F = 1 / 298.257223563;
  function observer(lat, lon, unix) {
    const phi = lat * DEG, e2 = F * (2 - F);
    const c = 1 / Math.sqrt(1 - e2 * Math.sin(phi) ** 2), s = (1 - e2) * c;
    const theta = gmst(unix) + lon * DEG;
    const ct = Math.cos(theta), st = Math.sin(theta), cl = Math.cos(phi), sl = Math.sin(phi);
    return {
      pos: [c * cl * ct, c * cl * st, s * sl],
      east: [-st, ct, 0],
      north: [-sl * ct, -sl * st, cl],
      up: [cl * ct, cl * st, sl]
    };
  }

  const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];

  function lookAngles(p, obs) {
    const r = [p[0] - obs.pos[0], p[1] - obs.pos[1], p[2] - obs.pos[2]];
    const d = Math.hypot(r[0], r[1], r[2]);
    const el = Math.asin(clamp(dot(r, obs.up) / d, -1, 1)) / DEG;
    const az = ((Math.atan2(dot(r, obs.east), dot(r, obs.north)) / DEG) + 360) % 360;
    return { az, el, km: d * RE_KM };
  }

  function sunlit(p, sun) {
    const d = dot(p, sun);
    return d > 0 || dot(p, p) - d * d > 1;
  }

  // ------------------------------------------------------------ Bahnen

  const cat = { n: 0, ver: -1, t0: 0, cols: null, notable: {}, trains: [], base: 0, bufA: null, bufB: null,
    bufC: null, pos: null, counts: null, above: null, sunlitAbove: 0 };

  function elementsAt(k, t) {
    const c = cat.cols, dt = (t - cat.t0) / 60;
    return {
      a: c.a[k], e: c.e[k], i: c.i[k],
      O: c.O[k] + c.Od[k] * dt,
      w: c.w[k] + c.wd[k] * dt,
      M: c.M[k] + c.n[k] * dt + c.dr[k] * dt * dt
    };
  }

  function kepler(a, e, i, O, w, M) {
    M %= TWO_PI;
    let E = e < 0.8 ? M + e * Math.sin(M) : Math.PI;
    for (let k = 0; k < 10; k += 1) {
      const d = (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E));
      E -= d;
      if (Math.abs(d) < 1e-9) break;
    }
    const x = a * (Math.cos(E) - e), y = a * Math.sqrt(1 - e * e) * Math.sin(E);
    const co = Math.cos(O), so = Math.sin(O), cw = Math.cos(w), sw = Math.sin(w), ci = Math.cos(i), si = Math.sin(i);
    const px = x * cw - y * sw, py = x * sw + y * cw;
    return [px * co - py * ci * so, px * so + py * ci * co, py * si];
  }

  function satPos(k, t) {
    const el = elementsAt(k, t);
    return kepler(el.a, el.e, el.i, el.O, el.w, el.M);
  }

  function acceptCatalog(body) {
    const c = body.cols;
    const n = c.a.length;
    cat.cols = c; cat.n = n; cat.ver = body.ver; cat.t0 = body.t0;
    cat.notable = body.notable || {}; cat.trains = body.trains || [];
    cat.bufA = new Float32Array(n * 4);
    cat.bufB = new Float32Array(n * 4);
    cat.bufC = new Float32Array(n * 2);
    cat.pos = new Float32Array(n * 3);
    cat.counts = new Array(GROUP_KEYS.length).fill(0);
    for (let k = 0; k < n; k += 1) {
      cat.bufA.set([c.a[k], c.e[k], c.i[k], c.g[k]], k * 4);
      cat.bufC.set([c.Od[k], c.wd[k]], k * 2);
      cat.counts[c.g[k]] += 1;
    }
    cat.base = 0;
    if (gl) uploadStatic();
    rebase(nowSec());
  }

  // Alle 20 s: Stand "jetzt" in doppelter Genauigkeit, dann auf die Karte
  function rebase(t) {
    if (!cat.n) return;
    const c = cat.cols, dt = (t - cat.t0) / 60;
    const B = cat.bufB, P = cat.pos;
    const sun = sunDir(t);
    const obs = place() ? observer(place().lat, place().lon, t) : null;
    const above = new Array(GROUP_KEYS.length).fill(0);
    let lit = 0;
    for (let k = 0; k < cat.n; k += 1) {
      const O = (c.O[k] + c.Od[k] * dt) % TWO_PI;
      const w = (c.w[k] + c.wd[k] * dt) % TWO_PI;
      const M = (c.M[k] + c.n[k] * dt + c.dr[k] * dt * dt) % TWO_PI;
      const nn = c.n[k] + 2 * c.dr[k] * dt;
      B[k * 4] = O; B[k * 4 + 1] = w; B[k * 4 + 2] = M; B[k * 4 + 3] = nn;
      const p = kepler(c.a[k], c.e[k], c.i[k], O, w, M);
      P[k * 3] = p[0]; P[k * 3 + 1] = p[1]; P[k * 3 + 2] = p[2];
      if (obs) {
        const r0 = p[0] - obs.pos[0], r1 = p[1] - obs.pos[1], r2 = p[2] - obs.pos[2];
        if (r0 * obs.up[0] + r1 * obs.up[1] + r2 * obs.up[2] > 0) {
          above[c.g[k]] += 1;
          if (sunlit(p, sun)) lit += 1;
        }
      }
    }
    cat.base = t;
    cat.above = obs ? above : null;
    cat.sunlitAbove = lit;
    if (gl) {
      gl.bindBuffer(gl.ARRAY_BUFFER, buffers.B);
      gl.bufferData(gl.ARRAY_BUFFER, B, gl.DYNAMIC_DRAW);
    }
    buildTracks(t);
    panelKey = "";
  }

  // ------------------------------------------------------------ Daten holen

  let settingsNow = { View: params.get("view") || "both", SwitchSeconds: 60, Camera: "cycle", Labels: true,
    Orbits: true, Panel: true, DotSize: "normal", LeadMinutes: "5", SkyOnPass: true, PlaceName: "", Lat: null, Lon: null };
  let passes = [], focusId = null, lastError = "", busy = "";
  let clockSkew = 0;

  function place() {
    const s = settingsNow;
    if (s.Lat === null || s.Lat === undefined || s.Lon === null || s.Lon === undefined) return null;
    return { lat: Number(s.Lat), lon: Number(s.Lon), name: s.PlaceName || "" };
  }

  async function poll() {
    let wait = 30000;
    try {
      const body = await sceneData("api/scene?v=" + cat.ver);
      if (body.settings) {
        const before = JSON.stringify(settingsNow);
        settingsNow = Object.assign(settingsNow, body.settings);
        if (params.get("view")) settingsNow.View = params.get("view");
        if (params.get("camera")) settingsNow.Camera = params.get("camera");
        if (settingsNow.Language && settingsNow.Language !== lang && !params.get("lang")) lang = settingsNow.Language;
        if (before !== JSON.stringify(settingsNow)) { panelKey = ""; layout(); if (cat.n) rebase(nowSec()); }
      }
      if (typeof body.now === "number") clockSkew = body.now - Date.now() / 1000;
      passes = Array.isArray(body.passes) ? body.passes : [];
      focusId = body.focus || null;
      lastError = body.error || ""; busy = body.busy || "";
      if (body.cols) acceptCatalog(body);
      if (!cat.n) {
        showNote(lastError ? tx("error") : tx("wait"));
        wait = 5000;
      } else {
        showNote("");
      }
      buildTracks(nowSec());
    } catch (error) {
      if (!cat.n) { showNote(error.message === "login" ? tx("login") : tx("unreachable")); wait = 5000; }
    }
    setTimeout(poll, focusId ? 5000 : wait);
  }

  // ------------------------------------------------------------ WebGL

  let gl = null, programs = {}, buffers = {}, earthTex = null, sphere = null;

  const VS_SATS = `
    precision highp float;
    attribute vec4 aA;   // a, e, i, Gruppe
    attribute vec4 aB;   // Knoten, Perigäum, mittlere Anomalie (zur Basiszeit), Winkelgeschw. (rad/min)
    attribute vec2 aC;   // Knoten- und Perigäumsdrehung (rad/min)
    uniform float uDt;   // Minuten seit der Basiszeit
    uniform float uMode; // 0 Erde, 1 Himmel
    uniform mat4 uMVP;
    uniform vec2 uShift;
    uniform vec3 uSun, uObs, uEast, uNorth, uUp;
    uniform vec3 uSky;   // Mitte x, y (Pixel), Radius
    uniform vec2 uRes;
    uniform float uMask[8];
    uniform vec3 uColor[8];
    uniform float uSize[8];
    uniform float uScale;
    varying vec4 vCol;
    void main() {
      int g = int(aA.w + 0.5);
      float mask = uMask[g];
      float e = aA.y;
      float M = aB.z + aB.w * uDt;
      float O = aB.x + aC.x * uDt;
      float w = aB.y + aC.y * uDt;
      float E = M + e * sin(M);
      for (int k = 0; k < 6; k++) { E -= (E - e * sin(E) - M) / (1.0 - e * cos(E)); }
      float x = aA.x * (cos(E) - e);
      float y = aA.x * sqrt(1.0 - e * e) * sin(E);
      float cw = cos(w), sw = sin(w), co = cos(O), so = sin(O), ci = cos(aA.z), si = sin(aA.z);
      float px = x * cw - y * sw, py = x * sw + y * cw;
      vec3 p = vec3(px * co - py * ci * so, px * so + py * ci * co, py * si);
      float d = dot(p, uSun);
      float lit = (d > 0.0 || dot(p, p) - d * d > 1.0) ? 1.0 : 0.0;
      vec3 col = uColor[g];
      if (uMode < 0.5) {
        gl_Position = uMVP * vec4(p, 1.0);
        gl_Position.xy += uShift * gl_Position.w;
        gl_PointSize = mask * uSize[g] * uScale * clamp(5.0 / gl_Position.w, 0.85, 1.35);
        vCol = vec4(col, mix(0.32, 1.0, lit));
      } else {
        vec3 r = p - uObs;
        float dist = length(r);
        float up = dot(r, uUp) / dist;
        if (up <= 0.0 || mask < 0.5) {
          gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
          gl_PointSize = 0.0;
          vCol = vec4(0.0);
          return;
        }
        float el = asin(up);
        float az = atan(dot(r, uEast), dot(r, uNorth));
        float rr = (1.0 - el / 1.5707963) * uSky.z;
        vec2 s = vec2(uSky.x - rr * sin(az), uSky.y - rr * cos(az));
        gl_Position = vec4(s.x / uRes.x * 2.0 - 1.0, 1.0 - s.y / uRes.y * 2.0, 0.0, 1.0);
        gl_PointSize = uSize[g] * uScale * clamp(0.32 / (dist + 0.02), 0.7, 2.6);
        vCol = vec4(col, mix(0.22, 1.0, lit));
      }
    }`;

  const FS_SATS = `
    precision mediump float;
    varying vec4 vCol;
    void main() {
      float d = length(gl_PointCoord - vec2(0.5));
      float core = smoothstep(0.5, 0.1, d);
      float a = core * vCol.a;
      if (a < 0.01) discard;
      gl_FragColor = vec4(vCol.rgb * a + vec3(0.25) * smoothstep(0.18, 0.0, d) * vCol.a, a);
    }`;

  const VS_EARTH = `
    precision highp float;
    attribute vec3 aPos;
    uniform mat4 uMVP;
    uniform vec2 uShift;
    uniform float uR;
    varying vec3 vN;
    void main() {
      vN = aPos;
      gl_Position = uMVP * vec4(aPos * uR, 1.0);
      gl_Position.xy += uShift * gl_Position.w;
    }`;

  const FS_EARTH = `
    precision highp float;
    varying vec3 vN;
    uniform sampler2D uTex;
    uniform float uGmst;
    uniform vec3 uSun, uCam;
    uniform float uHalo;
    void main() {
      vec3 n = normalize(vN);
      vec3 v = normalize(uCam - n);
      float d = dot(n, uSun);
      float day = smoothstep(-0.1, 0.2, d);
      if (uHalo > 0.5) {
        float facing = max(dot(n, normalize(uCam)), 0.0);
        float rim = pow(1.0 - facing, 2.2);
        float a = pow(rim, 1.6) * (0.06 + 0.32 * smoothstep(-0.3, 0.4, d));
        gl_FragColor = vec4(vec3(0.3, 0.55, 1.0) * a, a);
        return;
      }
      float lon = atan(n.y, n.x) - uGmst;
      vec2 uv = vec2(fract(lon / 6.2831853 + 0.5), 0.5 - asin(clamp(n.z, -1.0, 1.0)) / 3.1415927);
      vec3 base = texture2D(uTex, uv).rgb;
      vec3 col = base * (0.42 + 0.9 * day * (0.55 + 0.45 * max(d, 0.0)));
      col += vec3(0.008, 0.016, 0.04) * (1.0 - day);
      float rim = pow(1.0 - max(dot(n, v), 0.0), 3.0);
      col += vec3(0.25, 0.5, 1.0) * rim * (0.08 + 0.35 * day);
      col += vec3(0.55, 0.28, 0.08) * exp(-pow(d / 0.07, 2.0)) * 0.22;
      gl_FragColor = vec4(col, 1.0);
    }`;

  const VS_LINE = `
    precision highp float;
    attribute vec3 aPos;
    attribute float aAlpha;
    uniform mat4 uMVP;
    uniform vec2 uShift;
    varying float vA;
    void main() {
      vA = aAlpha;
      gl_Position = uMVP * vec4(aPos, 1.0);
      gl_Position.xy += uShift * gl_Position.w;
    }`;

  const FS_LINE = `
    precision mediump float;
    uniform vec4 uColor;
    varying float vA;
    void main() { gl_FragColor = vec4(uColor.rgb * uColor.a * vA, uColor.a * vA); }`;

  function compile(vs, fs) {
    const make = (type, src) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, src);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) || "shader");
      return s;
    };
    const p = gl.createProgram();
    gl.attachShader(p, make(gl.VERTEX_SHADER, vs));
    gl.attachShader(p, make(gl.FRAGMENT_SHADER, fs));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p) || "link");
    const loc = {};
    const nu = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
    for (let k = 0; k < nu; k += 1) {
      const info = gl.getActiveUniform(p, k);
      const name = info.name.replace(/\[0\]$/, "");
      loc[name] = gl.getUniformLocation(p, name);
    }
    const na = gl.getProgramParameter(p, gl.ACTIVE_ATTRIBUTES);
    for (let k = 0; k < na; k += 1) {
      const info = gl.getActiveAttrib(p, k);
      loc[info.name] = gl.getAttribLocation(p, info.name);
    }
    return { p, loc };
  }

  function initGL() {
    try {
      gl = glCanvas.getContext("webgl", { antialias: true, alpha: true, premultipliedAlpha: true, depth: true })
        || glCanvas.getContext("experimental-webgl");
      if (!gl) return false;
      programs.sats = compile(VS_SATS, FS_SATS);
      programs.earth = compile(VS_EARTH, FS_EARTH);
      programs.line = compile(VS_LINE, FS_LINE);
    } catch (error) {
      report("WebGL: " + error.message);
      gl = null;
      return false;
    }
    buffers.A = gl.createBuffer(); buffers.B = gl.createBuffer(); buffers.C = gl.createBuffer();
    buffers.line = gl.createBuffer();
    sphere = makeSphere(96, 48);
    earthTex = makeEarthTexture();
    return true;
  }

  function uploadStatic() {
    gl.bindBuffer(gl.ARRAY_BUFFER, buffers.A);
    gl.bufferData(gl.ARRAY_BUFFER, cat.bufA, gl.STATIC_DRAW);
    gl.bindBuffer(gl.ARRAY_BUFFER, buffers.C);
    gl.bufferData(gl.ARRAY_BUFFER, cat.bufC, gl.STATIC_DRAW);
  }

  function makeSphere(seg, rings) {
    const pos = [], idx = [];
    for (let r = 0; r <= rings; r += 1) {
      const lat = Math.PI / 2 - Math.PI * r / rings;
      for (let s = 0; s <= seg; s += 1) {
        const lon = TWO_PI * s / seg;
        pos.push(Math.cos(lat) * Math.cos(lon), Math.cos(lat) * Math.sin(lon), Math.sin(lat));
      }
    }
    for (let r = 0; r < rings; r += 1) {
      for (let s = 0; s < seg; s += 1) {
        const a = r * (seg + 1) + s, b = a + seg + 1;
        idx.push(a, b, a + 1, b, b + 1, a + 1);
      }
    }
    const vb = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vb);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(pos), gl.STATIC_DRAW);
    const ib = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(idx), gl.STATIC_DRAW);
    return { vb, ib, count: idx.length };
  }

  // Erde als Textur: Natural-Earth-Küsten (land.js) auf eine Plattkarte
  function makeEarthTexture() {
    const W = 2048, H = 1024;
    const c = document.createElement("canvas");
    c.width = W; c.height = H;
    const g = c.getContext("2d");
    const grad = g.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, "#0d2238"); grad.addColorStop(0.5, "#0b2440"); grad.addColorStop(1, "#0d2238");
    g.fillStyle = grad;
    g.fillRect(0, 0, W, H);
    const data = window.WORLD_MAP || { land: [], lakes: [], borders: [] };
    const X = (lon) => (lon + 180) / 360 * W, Y = (lat) => (90 - lat) / 180 * H;
    const ring = (path, flat, open) => {
      let lon = flat[0] / 100, lat = flat[1] / 100, minLon = lon, maxLon = lon;
      const pts = [[lon, lat]];
      for (let k = 2; k < flat.length; k += 2) {
        lon += flat[k] / 100; lat += flat[k + 1] / 100;
        pts.push([lon, lat]);
        minLon = Math.min(minLon, lon); maxLon = Math.max(maxLon, lon);
      }
      path.moveTo(X(pts[0][0]), Y(pts[0][1]));
      for (const [a, b] of pts.slice(1)) path.lineTo(X(a), Y(b));
      if (!open && maxLon - minLon > 300) {
        // Antarktis: über den Südpol schließen
        path.lineTo(X(pts[pts.length - 1][0]), H);
        path.lineTo(X(pts[0][0]), H);
      }
      if (!open) path.closePath();
    };
    const land = new Path2D(), lakes = new Path2D(), borders = new Path2D();
    for (const r of data.land) ring(land, r);
    for (const r of data.lakes) ring(lakes, r);
    for (const r of data.borders || []) ring(borders, r, true);
    g.fillStyle = "#2c4a55";
    g.fill(land, "evenodd");
    g.fillStyle = "#0c2541";
    g.fill(lakes);
    g.strokeStyle = "rgba(160, 205, 220, 0.55)";
    g.lineWidth = 1.4;
    g.stroke(land);
    g.strokeStyle = "rgba(160, 200, 210, 0.18)";
    g.lineWidth = 1;
    g.stroke(borders);
    // feines Gradnetz
    g.strokeStyle = "rgba(120, 170, 220, 0.10)";
    g.lineWidth = 1;
    for (let lon = -180; lon <= 180; lon += 30) { g.beginPath(); g.moveTo(X(lon), 0); g.lineTo(X(lon), H); g.stroke(); }
    for (let lat = -60; lat <= 60; lat += 30) { g.beginPath(); g.moveTo(0, Y(lat)); g.lineTo(W, Y(lat)); g.stroke(); }
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return tex;
  }

  // ------------------------------------------------------------ Matrizen

  function perspective(fovy, aspect, near, far) {
    const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
    return [f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0];
  }

  function lookAt(eye, target, up) {
    let zx = eye[0] - target[0], zy = eye[1] - target[1], zz = eye[2] - target[2];
    let l = Math.hypot(zx, zy, zz); zx /= l; zy /= l; zz /= l;
    let xx = up[1] * zz - up[2] * zy, xy = up[2] * zx - up[0] * zz, xz = up[0] * zy - up[1] * zx;
    l = Math.hypot(xx, xy, xz); xx /= l; xy /= l; xz /= l;
    const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
    return [xx, yx, zx, 0, xy, yy, zy, 0, xz, yz, zz, 0,
      -(xx * eye[0] + xy * eye[1] + xz * eye[2]), -(yx * eye[0] + yy * eye[1] + yz * eye[2]),
      -(zx * eye[0] + zy * eye[1] + zz * eye[2]), 1];
  }

  function mul(a, b) {
    const o = new Array(16);
    for (let c = 0; c < 4; c += 1) {
      for (let r = 0; r < 4; r += 1) {
        o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
      }
    }
    return o;
  }

  // ------------------------------------------------------------ Aufteilung

  let W = 0, H = 0, DPR = 1, portrait = false;
  const view = { cx: 0, cy: 0, w: 0, h: 0 };  // freie Fläche neben der Leiste

  function layout() {
    DPR = Math.min(window.devicePixelRatio || 1, 1.5);
    W = window.innerWidth; H = window.innerHeight;
    portrait = H > W * 1.05;
    for (const c of [bgCanvas, glCanvas, uiCanvas]) {
      c.width = Math.round(W * DPR); c.height = Math.round(H * DPR);
    }
    const showPanel = settingsNow.Panel !== false;
    panel.hidden = !showPanel;
    panel.className = portrait ? "port" : "land";
    if (!showPanel) Object.assign(view, { cx: W / 2, cy: H / 2, w: W, h: H });
    else if (portrait) Object.assign(view, { cx: W / 2, cy: H * 0.37, w: W, h: H * 0.74 });
    else Object.assign(view, { cx: W * 0.365, cy: H / 2, w: W * 0.73, h: H });
    banner.className = portrait ? "port" : "land";
    banner.style.left = `${view.cx - view.w / 2}px`;
    banner.style.width = `${view.w}px`;
    starfield = null;
    panelKey = "";
  }

  // ------------------------------------------------------------ Ansicht wählen

  let mode = "globe", modeSince = 0, fade = 1;

  function activePass(t) {
    for (const p of passes) if (p.announce && p.start <= t && t <= p.end) return p;
    return null;
  }

  function soonPass(t) {
    const lead = Number(settingsNow.LeadMinutes || 0) * 60;
    if (!lead) return null;
    for (const p of passes) if (p.announce && p.start - lead <= t && t < p.start) return p;
    return null;
  }

  function wantedMode(t) {
    const hasPlace = Boolean(place());
    if (focusId && hasPlace) return "sky";
    if (hasPlace && settingsNow.SkyOnPass !== false && activePass(t)) return "sky";
    const v = settingsNow.View;
    if (v === "globe" || !hasPlace) return "globe";
    if (v === "sky") return "sky";
    const every = Math.max(20, Number(settingsNow.SwitchSeconds) || 60);
    return Math.floor(t / every) % 2 ? "sky" : "globe";
  }

  // ------------------------------------------------------------ Erde zeichnen

  let camAngle0 = null;

  function camera(t, frameT) {
    const s = settingsNow;
    const home = place();
    if (camAngle0 === null) camAngle0 = home ? gmst(t) + home.lon * DEG : 0;
    const az = camAngle0 + frameT / 1000 * TWO_PI / 300;
    const elev = (home ? 12 + 0.35 * home.lat : 18) * DEG + 0.12 * Math.sin(frameT / 1000 * TWO_PI / 170);
    const NEAR = 4.3, FAR = 16;
    let dist;
    if (s.Camera === "near") dist = NEAR;
    else if (s.Camera === "far") dist = FAR;
    else {
      // 50 s nah, 14 s hinaus, 30 s weit, 14 s zurück
      const cyc = (frameT / 1000) % 108;
      let k = 0;
      if (cyc < 50) k = 0;
      else if (cyc < 64) k = smooth((cyc - 50) / 14);
      else if (cyc < 94) k = 1;
      else k = 1 - smooth((cyc - 94) / 14);
      dist = Math.exp(Math.log(NEAR) + (Math.log(FAR) - Math.log(NEAR)) * k);
    }
    const eye = [dist * Math.cos(elev) * Math.cos(az), dist * Math.cos(elev) * Math.sin(az), dist * Math.sin(elev)];
    // Brennweite so, dass der Blickwinkel auf die kürzere Seite der freien Fläche passt
    const fpx = Math.min(view.w, view.h) / 2 / Math.tan(18 * DEG);
    const proj = perspective(36 * DEG, 1, 0.05, 200);
    proj[0] = fpx / (W / 2); proj[5] = fpx / (H / 2);
    const shift = [(view.cx - W / 2) / W * 2, -(view.cy - H / 2) / H * 2];
    return { eye, mvp: mul(proj, lookAt(eye, [0, 0, 0], [0, 0, 1])), shift, dist };
  }

  function project(cam, p) {
    const m = cam.mvp;
    const x = m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12];
    const y = m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13];
    const w = m[3] * p[0] + m[7] * p[1] + m[11] * p[2] + m[15];
    if (w <= 0) return null;
    return [((x / w + cam.shift[0]) + 1) / 2 * W, (1 - (y / w + cam.shift[1])) / 2 * H];
  }

  // Verdeckt die Erde den Punkt p von der Kamera aus?
  function hidden(cam, p) {
    const e = cam.eye, d = [p[0] - e[0], p[1] - e[1], p[2] - e[2]];
    const len = Math.hypot(d[0], d[1], d[2]);
    d[0] /= len; d[1] /= len; d[2] /= len;
    const b = dot(e, d), c = dot(e, e) - 1;
    const disc = b * b - c;
    if (disc < 0) return false;
    const t = -b - Math.sqrt(disc);
    return t > 0 && t < len;
  }

  function groupMask() {
    return GROUP_SETTING.map((k) => (settingsNow[k] === false ? 0 : 1));
  }

  function dotScale() {
    const base = { small: 0.75, normal: 1, large: 1.4 }[settingsNow.DotSize] || 1;
    return base * DPR * clamp(Math.min(W, H) / 1080, 0.6, 2);
  }

  function setSatUniforms(prog, t, modeNum, cam, obs, sky) {
    const L = prog.loc;
    gl.uniform1f(L.uDt, (t - cat.base) / 60);
    gl.uniform1f(L.uMode, modeNum);
    gl.uniformMatrix4fv(L.uMVP, false, new Float32Array(cam ? cam.mvp : new Array(16).fill(0)));
    gl.uniform2fv(L.uShift, cam ? cam.shift : [0, 0]);
    gl.uniform3fv(L.uSun, sunDir(t));
    if (obs) {
      gl.uniform3fv(L.uObs, obs.pos); gl.uniform3fv(L.uEast, obs.east);
      gl.uniform3fv(L.uNorth, obs.north); gl.uniform3fv(L.uUp, obs.up);
    }
    gl.uniform3fv(L.uSky, sky ? [sky.x * DPR, sky.y * DPR, sky.r * DPR] : [0, 0, 1]);
    gl.uniform2fv(L.uRes, [glCanvas.width, glCanvas.height]);
    gl.uniform1fv(L.uMask, groupMask());
    gl.uniform3fv(L.uColor, GROUP_COLORS.flat());
    gl.uniform1fv(L.uSize, GROUP_SIZE);
    gl.uniform1f(L.uScale, dotScale() * (modeNum > 0.5 ? 1.25 : 1));
  }

  function drawSats(prog) {
    const L = prog.loc;
    gl.bindBuffer(gl.ARRAY_BUFFER, buffers.A);
    gl.enableVertexAttribArray(L.aA); gl.vertexAttribPointer(L.aA, 4, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, buffers.B);
    gl.enableVertexAttribArray(L.aB); gl.vertexAttribPointer(L.aB, 4, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, buffers.C);
    gl.enableVertexAttribArray(L.aC); gl.vertexAttribPointer(L.aC, 2, gl.FLOAT, false, 0, 0);
    gl.drawArrays(gl.POINTS, 0, cat.n);
    gl.disableVertexAttribArray(L.aA); gl.disableVertexAttribArray(L.aB); gl.disableVertexAttribArray(L.aC);
  }

  function drawEarth(cam, t, halo) {
    const prog = programs.earth, L = prog.loc;
    gl.useProgram(prog.p);
    gl.uniformMatrix4fv(L.uMVP, false, new Float32Array(cam.mvp));
    gl.uniform2fv(L.uShift, cam.shift);
    gl.uniform1f(L.uR, halo ? 1.03 : 1.0);
    gl.uniform1f(L.uGmst, gmst(t));
    gl.uniform3fv(L.uSun, sunDir(t));
    gl.uniform3fv(L.uCam, cam.eye);
    gl.uniform1f(L.uHalo, halo ? 1 : 0);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, earthTex);
    gl.uniform1i(L.uTex, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, sphere.vb);
    gl.enableVertexAttribArray(L.aPos);
    gl.vertexAttribPointer(L.aPos, 3, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, sphere.ib);
    gl.drawElements(gl.TRIANGLES, sphere.count, gl.UNSIGNED_SHORT, 0);
    gl.disableVertexAttribArray(L.aPos);
  }

  // Bahnen von ISS & Co. (eine Runde) als Linien
  let tracks = [];
  function buildTracks(t) {
    tracks = [];
    if (!cat.n || settingsNow.Orbits === false) return;
    const wanted = [];
    for (const key of ["iss", "css"]) if (cat.notable[key] !== undefined) wanted.push({ idx: cat.notable[key], color: GROUP_COLORS[4] });
    for (const tr of cat.trains.slice(0, 2)) wanted.push({ idx: tr.idx, color: [0.75, 0.92, 1.0] });
    for (const w of wanted) {
      const period = TWO_PI / cat.cols.n[w.idx] * 60;   // Sekunden
      const pts = [], alpha = [];
      const steps = 160;
      for (let s = 0; s <= steps; s += 1) {
        const tt = t - period * 0.5 + period * s / steps;
        pts.push(...satPos(w.idx, tt));
        alpha.push(0.12 + 0.6 * Math.sin(Math.PI * s / steps) ** 2);
      }
      tracks.push({ data: new Float32Array(pts), alpha: new Float32Array(alpha), color: w.color, n: steps + 1 });
    }
  }

  function drawTracks(cam) {
    if (!tracks.length) return;
    const prog = programs.line, L = prog.loc;
    gl.useProgram(prog.p);
    gl.uniformMatrix4fv(L.uMVP, false, new Float32Array(cam.mvp));
    gl.uniform2fv(L.uShift, cam.shift);
    for (const tr of tracks) {
      const buf = new Float32Array(tr.n * 4);
      for (let k = 0; k < tr.n; k += 1) {
        buf[k * 4] = tr.data[k * 3]; buf[k * 4 + 1] = tr.data[k * 3 + 1]; buf[k * 4 + 2] = tr.data[k * 3 + 2];
        buf[k * 4 + 3] = tr.alpha[k];
      }
      gl.bindBuffer(gl.ARRAY_BUFFER, buffers.line);
      gl.bufferData(gl.ARRAY_BUFFER, buf, gl.DYNAMIC_DRAW);
      gl.enableVertexAttribArray(L.aPos); gl.vertexAttribPointer(L.aPos, 3, gl.FLOAT, false, 16, 0);
      gl.enableVertexAttribArray(L.aAlpha); gl.vertexAttribPointer(L.aAlpha, 1, gl.FLOAT, false, 16, 12);
      gl.uniform4fv(L.uColor, [...tr.color, 0.75]);
      gl.drawArrays(gl.LINE_STRIP, 0, tr.n);
      gl.disableVertexAttribArray(L.aPos); gl.disableVertexAttribArray(L.aAlpha);
    }
  }

  // ------------------------------------------------------------ Hintergrund

  let starfield = null;
  function drawSpace() {
    if (!starfield) {
      starfield = document.createElement("canvas");
      starfield.width = bgCanvas.width; starfield.height = bgCanvas.height;
      const g = starfield.getContext("2d");
      const grad = g.createRadialGradient(view.cx * DPR, view.cy * DPR, 0, view.cx * DPR, view.cy * DPR, Math.max(W, H) * DPR);
      grad.addColorStop(0, "#0a1426"); grad.addColorStop(1, "#02040a");
      g.fillStyle = grad;
      g.fillRect(0, 0, starfield.width, starfield.height);
      let seed = 12345;
      const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
      const n = Math.round(W * H / 5200);
      for (let k = 0; k < n; k += 1) {
        const b = rnd() ** 3;
        g.fillStyle = `rgba(200,210,235,${0.06 + 0.3 * b})`;
        const s = (0.5 + 1.3 * b) * DPR;
        g.fillRect(rnd() * starfield.width, rnd() * starfield.height, s, s);
      }
    }
    bg.drawImage(starfield, 0, 0);
  }

  function skyGeometry() {
    let r = Math.min(view.w, view.h) * 0.41;
    let y = view.cy + (portrait ? H * 0.01 : H * 0.015);
    if (!banner.hidden) {
      // Platz für die Ansage oben lassen (Kreis + Himmelsrichtung darüber)
      const top = banner.offsetTop + banner.offsetHeight + 8;
      const bottom = view.cy + view.h / 2 - 8;
      const fit = (bottom - top) / (2 + 0.24);
      if (fit < r) { r = fit; y = top + r * 1.12; }
    }
    return { x: view.cx, y, r };
  }

  function skyXY(sky, az, el) {
    const rr = (1 - el / 90) * sky.r;
    return [sky.x - rr * Math.sin(az * DEG), sky.y - rr * Math.cos(az * DEG)];
  }

  function sunElevation(t) {
    const home = place();
    if (!home) return -20;
    const obs = observer(home.lat, home.lon, t);
    const s = sunDir(t);
    return Math.asin(clamp(dot(s, obs.up), -1, 1)) / DEG;
  }

  function drawSkyBackground(t, sky) {
    const sunEl = sunElevation(t);
    const dayK = smooth(clamp((sunEl + 12) / 18));
    bg.save();
    bg.scale(DPR, DPR);
    bg.fillStyle = "#03060c";
    bg.fillRect(0, 0, W, H);
    const top = mix3([6, 10, 22], [24, 58, 98], dayK), edge = mix3([12, 22, 44], [52, 98, 140], dayK);
    const grad = bg.createRadialGradient(sky.x, sky.y, 0, sky.x, sky.y, sky.r);
    grad.addColorStop(0, `rgb(${top})`);
    grad.addColorStop(0.85, `rgb(${edge})`);
    const dusk = clamp(1 - Math.abs(sunEl + 3) / 9);
    grad.addColorStop(1, `rgb(${mix3(edge.split(",").map(Number), [180, 110, 70], dusk * 0.6)})`);
    bg.fillStyle = grad;
    bg.beginPath(); bg.arc(sky.x, sky.y, sky.r, 0, TWO_PI); bg.fill();
    // Höhenkreise und Himmelsrichtungen
    bg.strokeStyle = "rgba(170, 200, 235, 0.16)";
    bg.lineWidth = 1;
    for (const el of [30, 60]) { bg.beginPath(); bg.arc(sky.x, sky.y, sky.r * (1 - el / 90), 0, TWO_PI); bg.stroke(); }
    for (let k = 0; k < 8; k += 1) {
      const [x, y] = skyXY(sky, k * 45, 0);
      bg.beginPath(); bg.moveTo(sky.x, sky.y); bg.lineTo(x, y); bg.stroke();
    }
    bg.strokeStyle = "rgba(190, 215, 240, 0.55)";
    bg.lineWidth = 1.6;
    bg.beginPath(); bg.arc(sky.x, sky.y, sky.r, 0, TWO_PI); bg.stroke();
    bg.font = `600 ${Math.round(sky.r * 0.062)}px -apple-system, "Segoe UI", Roboto, sans-serif`;
    bg.textAlign = "center"; bg.textBaseline = "middle";
    const comp = T().compass;
    for (let k = 0; k < 8; k += 1) {
      const [x, y] = skyXY(sky, k * 45, -9);
      bg.fillStyle = k % 2 ? "rgba(170, 195, 220, 0.55)" : "rgba(225, 238, 250, 0.9)";
      bg.fillText(comp[k], x, y);
    }
    bg.font = `${Math.round(sky.r * 0.035)}px -apple-system, "Segoe UI", Roboto, sans-serif`;
    bg.fillStyle = "rgba(170, 195, 220, 0.45)";
    for (const el of [30, 60]) {
      const [x, y] = skyXY(sky, 157, el);
      bg.fillText(`${el}°`, x, y);
    }
    // Sonne, wenn sie über dem Horizont steht
    if (sunEl > -1 && place()) {
      const obs = observer(place().lat, place().lon, t);
      const s = sunDir(t);
      const far = [s[0] * 23500, s[1] * 23500, s[2] * 23500];
      const la = lookAngles(far, obs);
      const [x, y] = skyXY(sky, la.az, Math.max(0, la.el));
      const g2 = bg.createRadialGradient(x, y, 0, x, y, sky.r * 0.09);
      g2.addColorStop(0, "rgba(255, 236, 170, 0.95)"); g2.addColorStop(0.25, "rgba(255, 210, 120, 0.55)");
      g2.addColorStop(1, "rgba(255, 190, 90, 0)");
      bg.fillStyle = g2;
      bg.beginPath(); bg.arc(x, y, sky.r * 0.09, 0, TWO_PI); bg.fill();
    }
    bg.restore();
  }

  function mix3(a, b, k) { return a.map((v, i) => Math.round(v + (b[i] - v) * k)).join(","); }

  // ------------------------------------------------------------ Beschriftung

  function labelFont(size) { return `600 ${Math.round(size)}px -apple-system, "Segoe UI", Roboto, Helvetica, sans-serif`; }

  function drawLabel(x, y, text, color, size, ring) {
    ui.save();
    ui.font = labelFont(size);
    ui.textBaseline = "middle";
    if (ring) {
      ui.strokeStyle = color;
      ui.lineWidth = Math.max(1.5, size * 0.1);
      ui.beginPath(); ui.arc(x, y, size * 0.55, 0, TWO_PI); ui.stroke();
    }
    const tx0 = x + size * 0.95, ty = y - size * 0.9;
    ui.strokeStyle = "rgba(0,0,0,0.65)";
    ui.lineWidth = size * 0.22;
    ui.lineJoin = "round";
    ui.strokeText(text, tx0, ty);
    ui.fillStyle = color;
    ui.fillText(text, tx0, ty);
    ui.restore();
  }

  function notableList() {
    const out = [];
    const short = T().whoShort;
    for (const key of ["iss", "css", "hst"]) {
      if (cat.notable[key] !== undefined) out.push({ idx: cat.notable[key], name: short[key], color: css(GROUP_COLORS[key === "hst" ? 5 : 4]) });
    }
    for (const tr of cat.trains.slice(0, 2)) out.push({ idx: tr.idx, name: tx("train", { n: tr.count }), color: "rgb(190,235,255)" });
    return out;
  }

  function drawGlobeLabels(cam, t) {
    const size = clamp(Math.min(W, H) / 52, 13, 32);
    if (settingsNow.Labels !== false && cam.dist < 9) {
      for (const s of notableList()) {
        const p = satPos(s.idx, t);
        if (hidden(cam, p)) continue;
        const xy = project(cam, p);
        if (xy) drawLabel(xy[0], xy[1], s.name, s.color, size, true);
      }
    }
    const home = place();
    if (home && cam.dist < 9) {
      const o = observer(home.lat, home.lon, t).pos;
      const n = Math.hypot(...o);
      const p = [o[0] / n * 1.002, o[1] / n * 1.002, o[2] / n * 1.002];
      if (!hidden(cam, [p[0] * 1.01, p[1] * 1.01, p[2] * 1.01])) {
        const xy = project(cam, p);
        if (xy) {
          const pulse = 0.5 + 0.5 * Math.sin(t * 2.2);
          ui.save();
          ui.strokeStyle = `rgba(255, 214, 120, ${0.55 + 0.4 * pulse})`;
          ui.lineWidth = 2 * DPR / DPR;
          ui.beginPath(); ui.arc(xy[0], xy[1], size * (0.32 + 0.18 * pulse), 0, TWO_PI); ui.stroke();
          ui.fillStyle = "rgba(255, 214, 120, 0.95)";
          ui.beginPath(); ui.arc(xy[0], xy[1], size * 0.13, 0, TWO_PI); ui.fill();
          ui.restore();
          drawLabel(xy[0], xy[1] + size * 1.55, tx("home"), "rgba(255, 224, 150, 0.95)", size * 0.85, false);
        }
      }
    }
  }

  let passTrack = null;
  function buildPassTrack(p) {
    const home = place();
    if (!p || !home || !cat.n || p.idx === undefined || p.idx < 0) { passTrack = null; return; }
    if (passTrack && passTrack.id === p.id) return;
    const pts = [];
    for (let tt = p.start; tt <= p.end; tt += 8) {
      const la = lookAngles(satPos(p.idx, tt), observer(home.lat, home.lon, tt));
      pts.push([la.az, Math.max(0, la.el), tt]);
    }
    passTrack = { id: p.id, pts };
  }

  function timeText(epoch) {
    const d = new Date(epoch * 1000);
    const hm = d.toLocaleTimeString(LOCALES[lang], { hour: "2-digit", minute: "2-digit" });
    return tx("hour", { t: hm });
  }

  function drawSkyLabels(t, sky) {
    const home = place();
    if (!home || !cat.n) return;
    const obs = observer(home.lat, home.lon, t);
    const size = clamp(Math.min(W, H) / 50, 13, 34);
    // Bahn des angesagten/nächsten Überflugs
    const p = passes.find((x) => x.id === focusId) || activePass(t) || soonPass(t);
    buildPassTrack(p && !p.test ? p : null);
    if (passTrack && passTrack.pts.length > 1) {
      ui.save();
      ui.strokeStyle = "rgba(255, 150, 120, 0.75)";
      ui.setLineDash([size * 0.5, size * 0.4]);
      ui.lineWidth = Math.max(2, size * 0.12);
      ui.beginPath();
      passTrack.pts.forEach(([az, el], k) => {
        const [x, y] = skyXY(sky, az, el);
        if (k) ui.lineTo(x, y); else ui.moveTo(x, y);
      });
      ui.stroke();
      ui.setLineDash([]);
      const first = passTrack.pts[0], last = passTrack.pts[passTrack.pts.length - 1];
      const [x0, y0] = skyXY(sky, first[0], first[1]);
      const [x1, y1] = skyXY(sky, last[0], last[1]);
      ui.fillStyle = "rgba(255, 170, 140, 0.95)";
      ui.font = labelFont(size * 0.75);
      ui.textAlign = "center";
      ui.fillText(timeText(first[2]), x0 + (sky.x - x0) * 0.08, y0 + (sky.y - y0) * 0.08 - size * 0.6);
      ui.fillText(timeText(last[2]), x1 + (sky.x - x1) * 0.08, y1 + (sky.y - y1) * 0.08 - size * 0.6);
      ui.restore();
    }
    if (settingsNow.Labels === false) return;
    for (const s of notableList()) {
      const pos = satPos(s.idx, t);
      const la = lookAngles(pos, obs);
      if (la.el <= 0) continue;
      const [x, y] = skyXY(sky, la.az, la.el);
      drawLabel(x, y, `${s.name} · ${Math.round(la.el)}°`, s.color, size, true);
    }
  }

  // ------------------------------------------------------------ Ansage

  let bannerKey = "";
  function dirName(az, list) { return list[Math.round(((az % 360) + 360) % 360 / 45) % 8]; }

  function whoOf(p) {
    if (String(p.key).startsWith("train")) return { who: T().who.train, train: p.train || 0 };
    return { who: T().who[p.key] || p.name, train: 0 };
  }

  function updateBanner(t) {
    const nowP = passes.find((x) => x.id === focusId) || activePass(t);
    const soon = nowP ? null : soonPass(t);
    const p = nowP || soon;
    if (!p) {
      if (bannerKey) { banner.hidden = true; bannerKey = ""; }
      return;
    }
    const { who, train } = whoOf(p);
    const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
    let title, sub, kicker;
    if (nowP) {
      title = tx("nowTitle", { who });
      let az = p.azMax, el = p.maxEl;
      const home = place();
      if (home && cat.n && p.idx >= 0 && !p.test) {
        const la = lookAngles(satPos(p.idx, t), observer(home.lat, home.lon, t));
        if (la.el > 0) { az = la.az; el = la.el; }
      }
      sub = tx("lookNow", { dir: dirName(az, T().dirsTo), el: Math.round(el) });
      kicker = tx("kickerNow");
    } else {
      const m = Math.max(1, Math.ceil((p.start - t) / 60));
      title = m === 1 ? tx("soonTitle1", { who }) : tx("soonTitle", { who, m });
      sub = tx("lookSoon", { dir: dirName(p.azStart, T().dirs), dirMax: dirName(p.azMax, T().dirs),
        time: timeText(p.max), el: Math.round(p.maxEl) });
      kicker = tx("kickerSoon");
    }
    let extra = "";
    if (p.visible) extra = tx("seen");
    else extra = sunElevation(p.max) > -6 ? tx("day") : tx("shadow");
    if (train) extra = tx("trainNote", { n: train }) + " · " + extra;
    const key = [title, sub, kicker, extra, p.visible].join("|");
    if (key === bannerKey) return;
    bannerKey = key;
    $("bannerKicker").innerHTML = `<span>${kicker}</span>${p.visible ? `<span class="vis">${tx("kickerVisible")}</span>` : ""}`;
    $("bannerTitle").textContent = cap(title);
    $("bannerSub").textContent = `${sub} · ${extra}`;
    banner.hidden = false;
  }

  // ------------------------------------------------------------ Leiste

  let panelKey = "";
  function updatePanel(t) {
    if (settingsNow.Panel === false) return;
    const d = new Date(t * 1000);
    $("clock").textContent = d.toLocaleTimeString(LOCALES[lang], { hour: "2-digit", minute: "2-digit" });
    const home = place();
    const key = [lang, mode, cat.ver, cat.base, passes.map((p) => p.id + p.announce).join(), JSON.stringify(settingsNow), Math.floor(t / 30)].join("|");
    if (key === panelKey) return;
    panelKey = key;
    const sky = mode === "sky";
    $("sub").textContent = sky ? (home && home.name ? tx("sky", { place: home.name }) : tx("skyNoPlace")) : tx("globe");
    const counts = sky && cat.above ? cat.above : cat.counts || [];
    const mask = groupMask();
    const total = counts.reduce((s, v, k) => s + (mask[k] ? v : 0), 0);
    $("mode").innerHTML = sky && cat.above
      ? `<b>${tx("above", { n: fmt(total) })}</b><br><span>${tx("sunlit", { n: fmt(cat.sunlitAbove) })}</span>`
      : `<b>${tx("sats", { n: fmt(total) })}</b>`;
    const names = T().groups;
    const rows = GROUP_KEYS.map((g, k) => ({ k, n: counts[k] || 0 })).filter((r) => r.n > 0 && mask[r.k]);
    $("groups").innerHTML = rows.map((r) =>
      `<div class="g"><i style="background:${css(GROUP_COLORS[r.k])};box-shadow:0 0 .6em ${css(GROUP_COLORS[r.k], 0.8)}"></i><span>${names[r.k]}</span><b>${fmt(r.n)}</b></div>`).join("");
    let html = "";
    if (!home) {
      html = `<p class="hint">${tx("noPlace")}</p>`;
    } else {
      const list = passes.filter((p) => p.announce && p.end > t && !p.test).slice(0, 4);
      html = `<h3>${tx("next")}</h3>`;
      if (!list.length) html += `<p class="hint">${tx("none")}</p>`;
      else {
        html += "<ol>" + list.map((p) => {
          const dd = new Date(p.max * 1000);
          const day = dd.toDateString() === d.toDateString() ? "" : (new Date(t * 1000 + 86400000).toDateString() === dd.toDateString() ? tx("tomorrow") + " " : dd.toLocaleDateString(LOCALES[lang], { weekday: "short" }) + " ");
          const name = String(p.key).startsWith("train") ? tx("train", { n: p.train || "" }) : (T().whoShort[p.key] || p.name);
          return `<li><span class="n">${name}</span><span class="t">${day}${timeText(p.start)}</span><span class="e">${Math.round(p.maxEl)}°${p.visible ? ` <em>${tx("visible")}</em>` : ""}</span></li>`;
        }).join("") + "</ol>";
      }
    }
    $("passes").innerHTML = html;
    $("credit").textContent = tx("credit");
  }

  // ------------------------------------------------------------ Bildschleife

  let lastFrame = 0, frames = 0, fpsSince = 0, fpsReported = false, lastRebase = 0;

  function frame(ts) {
    const t = nowSec();
    if (cat.n && t - cat.base > 20) rebase(t);
    const want = wantedMode(t);
    if (want !== mode) {
      fade -= 0.04;
      if (fade <= 0) { mode = want; modeSince = t; fade = 0; panelKey = ""; }
    } else if (fade < 1) fade = Math.min(1, fade + 0.04);
    for (const c of [bgCanvas, glCanvas, uiCanvas]) c.style.opacity = String(fade);

    bg.setTransform(1, 0, 0, 1, 0, 0);
    ui.setTransform(1, 0, 0, 1, 0, 0);
    ui.clearRect(0, 0, uiCanvas.width, uiCanvas.height);
    ui.scale(DPR, DPR);
    const sky = skyGeometry();
    if (mode === "sky") drawSkyBackground(t, sky); else drawSpace();

    if (gl) {
      gl.viewport(0, 0, glCanvas.width, glCanvas.height);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      if (mode === "globe") {
        const cam = camera(t, ts);
        gl.enable(gl.DEPTH_TEST);
        gl.depthFunc(gl.LEQUAL);
        gl.disable(gl.BLEND);
        gl.depthMask(true);
        drawEarth(cam, t, false);
        gl.enable(gl.BLEND);
        gl.blendFunc(gl.ONE, gl.ONE);
        gl.depthMask(false);
        drawEarth(cam, t, true);
        drawTracks(cam);
        if (cat.n) {
          gl.useProgram(programs.sats.p);
          setSatUniforms(programs.sats, t, 0, cam, null, null);
          drawSats(programs.sats);
        }
        gl.depthMask(true);
        drawGlobeLabels(cam, t);
      } else if (cat.n && place()) {
        const home = place();
        const obs = observer(home.lat, home.lon, t);
        gl.disable(gl.DEPTH_TEST);
        gl.enable(gl.BLEND);
        gl.blendFunc(gl.ONE, gl.ONE);
        gl.useProgram(programs.sats.p);
        setSatUniforms(programs.sats, t, 1, null, obs, sky);
        drawSats(programs.sats);
        drawSkyLabels(t, sky);
      }
    }
    updateBanner(t);
    updatePanel(t);

    frames += 1;
    if (!fpsSince) fpsSince = ts;
    if (ts - fpsSince > 10000) {
      const fps = frames * 1000 / (ts - fpsSince);
      if (params.get("fps")) showNote(`${fps.toFixed(1)} fps`);
      if (!fpsReported && cat.n) { fpsReported = true; report(`Bildrate ${fps.toFixed(1)} fps, ${cat.n} Satelliten, ${W}x${H}`); }
      frames = 0; fpsSince = ts;
    }
    lastFrame = ts;
    requestAnimationFrame(frame);
  }

  function start() {
    layout();
    window.addEventListener("resize", layout);
    if (!initGL()) showNote("WebGL fehlt / WebGL missing");
    requestAnimationFrame((ts) => { frame(ts); requestAnimationFrame(() => ready()); });
    poll();
  }

  start();
})();
