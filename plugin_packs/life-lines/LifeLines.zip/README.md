# Life Lines

Your life as a metro map. The years are drawn as a line diagram: lines stand for people or places, stations for trips, big days and moves, and where lines meet there are photos together. A train travels along the map and stops at every station for a moment with a few photos.

## Photos

One or more sources, merged:

- **All photos in DynaFrame**: the DynaFrame media database (also WebDAV) plus its media folders and extra folders you enter. Date and GPS come from the database or, if missing, from the photo file (read once, then cached).
- **A DynaFrame playlist**.
- **All photos in Immich** or **an Immich album**: needs the server address and an API key (`asset.read`, `asset.view`, `album.read`, `person.read`, `tag.read`). If Immich Slideshow, Growing Up, On This Day or Travel Map already has a server, it is taken over. People come from Immich's face recognition (only people with a name), birthdays from the person's birth date in Immich.
- **Filters** like Photo Mosaic (stars, favourites, albums, places, cameras …), for Immich and for DynaFrame photos, so nothing private ends up on the frame. After a change the map is cleared at once and drawn again.

## The map

- **Home** is where you took photos on the most different days, year by year, so a move is noticed (optionally as its own station).
- **Trips**: runs of days at least 50 km (adjustable) away from home with enough photos; short gaps without photos do not end a trip. Trips are found with GPS data.
- **Big days**: days at home with many photos (birthday, Christmas, New Year's Eve, Easter are recognised).
- **Names** come from the place of the photos (Immich, DynaFrame), from the folder or album (e.g. "2015-08 Rome"), otherwise from OpenStreetMap (Nominatim, cached, one request per second). If you use an ad blocker like Pi-hole, allow `nominatim.openstreetmap.org`.
- **Lines**: the main line stops everywhere. Person lines stop wherever that person is in the photos; place lines wherever you went to that place again ("places you return to"). Automatic: people if Immich knows faces, otherwise places. You can pick the people yourself.

## Scene

- Metro map in landscape (time from left to right) or portrait (top to bottom), light like a printed map or dark.
- The train runs along the main line; at every station the camera stops, a few photos fly out of the station with name, dates and who was there. Every visit shows other photos (stars and favourites first).
- Now and then the whole map with a legend.
- Start where it stopped last time, at a random station or at the station closest to today's date.
- Language English, German, Spanish.

Settings are on the plugin page (Plugins > Life Lines > Open Life Lines). "Create playlist" adds a playlist with the scene.

## Licences

Font Inter (SIL Open Font License, `dynamic/fonts`). Place names © OpenStreetMap contributors (ODbL). Problems or wishes: https://github.com/Archonw/Jans-DynaframePro-Store/issues
