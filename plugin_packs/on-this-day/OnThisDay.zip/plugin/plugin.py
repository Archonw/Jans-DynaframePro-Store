#!/usr/bin/env python3
"""On This Day - der Plugin-Teil des Pakets "On This Day".

Die Szene "on-this-day" zeigt die Fotos, die am heutigen Tag in früheren
Jahren entstanden sind, als Zeitreise durch die Jahre. Zu jedem Foto steht
das Wetter von damals an diesem Ort (aus Datum, Uhrzeit und GPS des Fotos,
Open-Meteo-Archiv) und das Wetter von heute daneben.

Dieses Plugin
- sammelt die Fotos des Tages: aus einer Playlist von DynaFrame, der ganzen
  Mediendatenbank (und eingehängten Ordnern) oder von Immich (alle Fotos
  oder ein Album),
- wählt je Jahr ein paar Fotos aus (über den Tag verteilt, keine Serienbilder),
- holt das Wetter damals und heute und die Ortsnamen,
- verkleinert die Fotos für die Szene und rechnet ein paar Vergleiche aus
  (wärmster, kältester, nassester Tag, Unterschied zu heute).
"""

import datetime
import hashlib
import io
import json
import os
import re
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import exif_gps  # noqa: E402
import dynaframe_filters  # noqa: E402
import immich_filters  # noqa: E402
import sources  # noqa: E402
import own_playlist  # noqa: E402
import renamed_playlists  # noqa: E402
import texts  # noqa: E402
import weather  # noqa: E402

try:
    from PIL import Image, ImageOps
except ImportError:  # pragma: no cover - kommt mit requirements.txt
    Image = ImageOps = None

HEIF = False
if Image is not None:
    try:
        from pillow_heif import register_heif_opener  # type: ignore

        register_heif_opener()
        HEIF = True
    except Exception:  # noqa: BLE001 - optional
        HEIF = False

plugin = create_plugin()

PLUGIN_ID = "OnThisDay"
SCENE_ID = "on-this-day"           # id in scene.dynamic - nie ändern
PLAYLIST_NAME = "On This Day"   # in allen Sprachen englisch (Jans Wunsch, 12.11.2026)
OLD_PLAYLIST_NAMES = ("Heute vor X Jahren", "Hoy hace X años")   # bis 0.1.5
PLAYLIST_NAMES = {"de": PLAYLIST_NAME, "en": PLAYLIST_NAME, "es": PLAYLIST_NAME}
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen, Caches; bleibt bei Updates
PHOTO_DIR = DATA_DIR / "photos"

CONNECT_TIMEOUT = 10
MAX_SOURCES = 6
MAX_YEARS = 40
WIDEN_MAX = 7                       # so weit sucht "Nachbartage nehmen" höchstens
PHOTO_EDGE = 1920                   # lange Seite der Fotos für die Szene
BURST_SECONDS = 600                 # Fotos so dicht beieinander gelten als Serie

KINDS = ("library", "playlist", "immich_all", "immich_album")
LAYOUTS = ("journey", "wall")


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def as_float(value, default=None):
    try:
        number = float(str(value).strip().replace(",", "."))
    except (TypeError, ValueError):
        return default
    return default if number != number else number


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält den API-Schlüssel
        except OSError:
            pass


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

def default_sources():
    return [{"id": "s1", "kind": "library", "ref": "", "name": ""}]


SCHEMA = {
    "Language":        {"kind": "choice", "default": "en", "choices": texts.LANGUAGES},
    "ServerUrl":       {"kind": "url", "default": ""},
    "ApiKey":          {"kind": "secret", "default": ""},
    "Sources":         {"kind": "sources", "default": None},
    "Folders":         {"kind": "folders", "default": ""},
    # Welche Immich-Fotos überhaupt (wie Growing Up)
    "Albums":          {"kind": "albums", "default": []},
    # Immich-Filter wie Photo Mosaic (ohne „Wann“: das Plugin sucht die Tage selbst)
    **immich_filters.schema(without=immich_filters.WHEN),
    # DynaFrame-Filter wie Photo Mosaic (Sterne, Kamera … aus der Mediendatenbank; die Tage wählt das Plugin)
    **dynaframe_filters.schema(without=dynaframe_filters.WHEN),
    "Layout":          {"kind": "choice", "default": "journey", "choices": LAYOUTS},
    "YearOrder":       {"kind": "choice", "default": "oldest", "choices": ("oldest", "newest")},
    "PerYear":         {"kind": "int", "default": 3, "min": 1, "max": 8},
    "DayWindow":       {"kind": "int", "default": 0, "min": 0, "max": 7},
    "AutoWiden":       {"kind": "bool", "default": True},
    "PhotoSeconds":    {"kind": "float", "default": 8.0, "min": 2.0, "max": 120.0},
    "FadeSeconds":     {"kind": "float", "default": 1.5, "min": 0.0, "max": 6.0},
    "KenBurns":        {"kind": "bool", "default": True},
    "ShowSummary":     {"kind": "bool", "default": True},
    "SummarySeconds":  {"kind": "float", "default": 15.0, "min": 4.0, "max": 120.0},
    "ShowWeather":     {"kind": "bool", "default": True},
    "TodayAt":         {"kind": "choice", "default": "home", "choices": ("home", "there")},
    "HomeName":        {"kind": "text", "default": ""},
    "HomeLat":         {"kind": "coord", "default": None},
    "HomeLon":         {"kind": "coord", "default": None},
    "Units":           {"kind": "choice", "default": "c", "choices": ("c", "f")},
    "ShowPlace":       {"kind": "bool", "default": True},
    "RefreshHours":    {"kind": "int", "default": 6, "min": 1, "max": 168},
    "PlaylistSeconds": {"kind": "int", "default": 180, "min": 10, "max": 86400},
    "MakePlaylist":        {"kind": "bool", "default": False},
}
SECRETS = [name for name, spec in SCHEMA.items() if spec["kind"] == "secret"]
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()


def coerce_sources(raw):
    if raw is None:
        return default_sources()
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return default_sources()
    out, ids = [], set()
    for row in raw if isinstance(raw, list) else []:
        if not isinstance(row, dict) or len(out) >= MAX_SOURCES:
            continue
        ident = re.sub(r"[^A-Za-z0-9]", "", str(row.get("id") or ""))[:16] or uuid.uuid4().hex[:8]
        while ident in ids:
            ident = uuid.uuid4().hex[:8]
        ids.add(ident)
        out.append({
            "id": ident,
            "kind": row.get("kind") if row.get("kind") in KINDS else "library",
            "ref": re.sub(r"[^A-Za-z0-9_-]", "", str(row.get("ref") or ""))[:64],
            "name": re.sub(r"\s+", " ", str(row.get("name") or "")).strip()[:60],
        })
    return out


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind in ("ref", "date", "name"):
        return immich_filters.coerce(spec, raw)
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "float":
        return round(max(spec["min"], min(spec["max"], as_float(raw, spec["default"]))), 1)
    if kind == "coord":
        value = as_float(raw, None)
        return None if value is None or abs(value) > 180 else round(value, 4)
    if kind == "choice":
        value = str(raw or "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "sources":
        return coerce_sources(raw)
    if kind == "albums":
        if isinstance(raw, str):
            raw = [part for part in raw.split(",") if part]
        ids = []
        for item in raw if isinstance(raw, list) else []:
            ident = re.sub(r"[^A-Za-z0-9_-]", "", str(item or ""))[:64]
            if ident and ident not in ids:
                ids.append(ident)
        return ids[:50]
    if kind == "url":
        return sources.normalize_url(raw)[:300]
    if kind == "text":
        return re.sub(r"\s+", " ", str(raw or "")).strip()[:80]
    if kind == "folders":
        lines = [line.strip() for line in str(raw or "").replace(";", "\n").splitlines()]
        return "\n".join(line for line in lines if line.startswith("/"))[:2000]
    return re.sub(r"\s+", "", str(raw or ""))[:400]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


def adopt_immich():
    """Server und Schlüssel aus einem anderen Immich-Plugin übernehmen, wenn hier keiner steht."""
    values = settings()
    if values["ServerUrl"] and values["ApiKey"]:
        return ""
    for name, title in (("ImmichSlideshow", "Immich Slideshow"), ("GrowingUp", "Growing Up"),
                        ("ColorCalendar", "Colour Calendar"), ("PhotoMosaic", "Photo Mosaic")):
        other = read_json(PLUGIN_DIR.parent / name / "data" / "settings.json", {}) or {}
        if not isinstance(other, dict):
            continue
        url, key = sources.normalize_url(other.get("ServerUrl")), str(other.get("ApiKey") or "").strip()
        if url and key:
            save_settings({"ServerUrl": url, "ApiKey": key})
            log(f"Immich-Server und API-Schlüssel aus {title} übernommen.")
            return title
    return ""


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 120))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def engine_image(media_id, path=""):
    """Das Vorschaubild, das die Engine für die Weboberfläche erzeugt (auf Jans Rahmen 512 Pixel)."""
    candidates = []
    if path:
        candidates += [("/media/thumbnail", {"path": path, "purpose": "preview"}),
                       ("/media/thumbnail", {"path": path})]
    if media_id:
        candidates += [(f"/media/thumbnail/{media_id}", {"purpose": "preview"}),
                       (f"/media/thumbnail/{media_id}", None)]
    failures = []
    for route, params in candidates:
        try:
            response = requests.get(f"{engine_base()}{route}", params=params, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 60))
        except requests.RequestException as exc:
            failures.append(f"{route}: {exc}")
            continue
        kind = response.headers.get("Content-Type", "").split(";")[0]
        if response.status_code == 200 and kind.startswith("image/"):
            return response.content
        failures.append(f"{route}{'?path' if params and 'path' in params else ''}: HTTP {response.status_code} {kind}")
    raise sources.SourceError(f"Vorschaubild {media_id}: " + "; ".join(failures))


# --------------------------------------------------------------------------
# Index der DynaFrame-Fotos (Datum + GPS), mit Cache für Dateien
# --------------------------------------------------------------------------

immich = sources.Immich(tr)
dynaframe = sources.DynaFrame(engine_call, EngineError, log)
sky = weather.Weather(DATA_DIR, log)

EXIF_FILE = DATA_DIR / "exif.json"
_exif = {"data": None, "dirty": 0}
_exif_lock = threading.Lock()


def exif_lookup(path, stamp):
    """(taken, lat, lon) aus der Datei, mit Cache (key = Pfad, Stempel muss passen)."""
    with _exif_lock:
        if _exif["data"] is None:
            stored = read_json(EXIF_FILE, {})
            _exif["data"] = stored if isinstance(stored, dict) else {}
        row = _exif["data"].get(path)
    if isinstance(row, list) and len(row) == 4 and row[0] == stamp:
        return row[1], row[2], row[3]
    lat, lon, taken = exif_gps.read(path)
    taken = sources.clean_taken(taken)
    with _exif_lock:
        _exif["data"][path] = [stamp, taken, lat, lon]
        _exif["dirty"] += 1
    return taken, lat, lon


def exif_save(keep=None):
    with _exif_lock:
        if _exif["data"] is None:
            return
        if keep is not None:
            for key in [k for k in _exif["data"] if k not in keep]:
                del _exif["data"][key]
                _exif["dirty"] += 1
        if _exif["dirty"]:
            write_json(EXIF_FILE, _exif["data"])
            _exif["dirty"] = 0


def key_path(key):
    if key.startswith("d:"):
        return key.partition("|")[2]
    if key.startswith("f:"):
        return key[2:]
    return ""


_stop_requested = threading.Event()
_work_stop = threading.Event()
_wake = threading.Event()
_index_lock = threading.Lock()
_index = {"rows": [], "status": {}, "at": 0.0, "signature": "", "busy": False,
          "progress": {"done": 0, "todo": 0, "phase": ""}, "undated": 0, "total": 0}


def index_signature(values):
    wanted = [(s["id"], s["kind"], s["ref"]) for s in values["Sources"] if not s["kind"].startswith("immich")]
    return json.dumps([wanted, values["Folders"], dynaframe_filters.signature(values), version()], sort_keys=True)


def build_index(reason=""):
    """Alle DynaFrame-Quellen einlesen: Datum und GPS jedes Fotos."""
    values = settings()
    wanted = [s for s in values["Sources"] if not s["kind"].startswith("immich")]
    with _index_lock:
        if _index["busy"]:
            return
        _index["busy"] = True
    started = now()
    status, rows = {}, {}
    match = None
    if wanted and dynaframe_filters.active(values):
        match = dynaframe_filters.Matcher(values, lambda: dynaframe.library_rows(_work_stop),
                                          cache_file=str(DATA_DIR / "file_meta.json"), log=log)
    try:
        if wanted:
            log(f"Lese die DynaFrame-Fotos ein{' - ' + reason if reason else ''}.")
        _index["progress"] = {"done": 0, "todo": 0, "phase": "list"}
        for source in wanted:
            sid = source["id"]
            _index["status"][sid] = dict(_index["status"].get(sid) or {}, state="busy")
            try:
                if source["kind"] == "playlist":
                    if not source["ref"]:
                        raise sources.SourceError(tr("Wähle eine Playlist."))
                    try:
                        found, total = dynaframe.playlist(source["ref"], _work_stop)
                    except EngineError as exc:
                        if exc.status == 404:
                            raise sources.SourceError(tr("Die Playlist gibt es nicht mehr.")) from exc
                        raise
                else:
                    folders = [f for f in values["Folders"].splitlines() if f]
                    found, total = dynaframe.library(folders, _work_stop)
                if match is not None:
                    found = [row for row in found if match.keep(row["k"])]
                for row in found:
                    row["src"] = sid
                    rows.setdefault(row["k"], row)
                status[sid] = {"state": "ok", "total": total, "dated": 0, "located": 0, "error": "", "at": now()}
            except EngineError as exc:
                status[sid] = {"state": "error", "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except sources.SourceError as exc:
                status[sid] = {"state": "error", "error": str(exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except Exception as exc:  # pragma: no cover - darf den Durchlauf nicht beenden
                status[sid] = {"state": "error", "error": str(exc)[:200], "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc!r}", "warning")
            _index["status"][sid] = status[sid]
            if _work_stop.is_set() or _stop_requested.is_set():
                return

        if match is not None:
            match.save()
        _index["dfCount"] = match.counts() if match is not None else None
        # Datum/GPS aus den Dateien, wo die Engine keins mitliefert
        todo = [r for r in rows.values() if (not r["t"] or r["lat"] is None) and os.path.isfile(key_path(r["k"]))]
        _index["progress"] = {"done": 0, "todo": len(todo), "phase": "exif"}
        for count, row in enumerate(todo, 1):
            if _work_stop.is_set() or _stop_requested.is_set():
                exif_save()
                return
            taken, lat, lon = exif_lookup(key_path(row["k"]), row["stamp"])
            row["t"] = row["t"] or taken
            if row["lat"] is None and lat is not None and lon is not None:
                row["lat"], row["lon"] = lat, lon
            _index["progress"]["done"] = count
            if count % 200 == 0:
                time.sleep(0.05)
        exif_save(keep={key_path(r["k"]) for r in rows.values() if key_path(r["k"])})
        dated = [r for r in rows.values() if len(r["t"]) >= 10]
        for sid, row in status.items():
            if row.get("state") == "ok":
                mine = [r for r in rows.values() if r.get("src") == sid]
                row["dated"] = sum(1 for r in mine if len(r["t"]) >= 10)
                row["located"] = sum(1 for r in mine if r["lat"] is not None)
        with _index_lock:
            _index.update(rows=dated, status=dict(_index["status"], **status), at=now(),
                          signature=index_signature(values), undated=len(rows) - len(dated), total=len(rows))
        if wanted:
            log(f"{len(dated)} DynaFrame-Fotos mit Datum ({len(rows) - len(dated)} ohne), {now() - started:.0f} s.")
    finally:
        _index["progress"] = {"done": 0, "todo": 0, "phase": ""}
        with _index_lock:
            _index["busy"] = False


# --------------------------------------------------------------------------
# Der Tag: Fotos auswählen, Wetter, Orte, Vergleiche
# --------------------------------------------------------------------------

_day_lock = threading.Lock()
_day = {"ver": 0, "date": "", "signature": "", "busy": False, "years": [], "photos": [], "facts": {},
        "window": 0, "next": "", "candidates": 0, "at": 0.0, "weatherError": "", "immich": {}}
_today = {"home": None, "there": {}, "at": 0.0, "error": ""}
_immich_cache = {}          # signature -> (time, rows, first_year)


def day_signature(values, date):
    keep = ("Sources", "ServerUrl", "ApiKey", "Albums", *immich_filters.SCHEMA.keys() - set(immich_filters.WHEN), "PerYear", "DayWindow", "AutoWiden", "HomeLat", "HomeLon",
            "Language", "ShowPlace")
    return json.dumps([date, {k: values[k] for k in keep}, _index["signature"], _index["at"], version()],
                      sort_keys=True, default=str)


def md_distance(taken, month, day, year):
    """Abstand in Tagen zwischen dem Aufnahmetag und month/day im Jahr des Fotos."""
    try:
        shot = datetime.date(int(taken[:4]), int(taken[5:7]), int(taken[8:10]))
    except ValueError:
        return 99
    try:
        target = datetime.date(shot.year, month, day)
    except ValueError:                # 29.2. in einem Nicht-Schaltjahr: der 28.
        target = datetime.date(shot.year, month, 28)
    return abs((shot - target).days)


def immich_rows(values, month, day, window):
    """Fotos von Immich um diesen Tag (alle Immich-Quellen), mit Cache für eine Stunde."""
    wanted = [s for s in values["Sources"] if s["kind"].startswith("immich")]
    out, status = [], {}
    if not wanted:
        return out, status
    immich.configure(values["ServerUrl"], values["ApiKey"])
    for source in wanted:
        sid = source["id"]
        if source["kind"] == "immich_album":
            if not source["ref"]:
                status[sid] = {"state": "error", "error": tr("Wähle ein Album."), "at": now()}
                continue
            albums = [source["ref"]]
        else:
            albums = list(values["Albums"])      # leer = alle Fotos
        filters = immich_filters.from_settings(values)
        key = json.dumps([values["ServerUrl"], albums, filters, month, day, window, datetime.date.today().isoformat()],
                         sort_keys=True)
        hit = _immich_cache.get(key)
        try:
            if hit and now() - hit[0] < 3600:
                rows, first = hit[1], hit[2]
            else:
                rows, first = immich.on_day(albums, month, day, window, _work_stop, filters)
                _immich_cache.clear() if len(_immich_cache) > 20 else None
                _immich_cache[key] = (now(), rows, first)
            for row in rows:
                row["src"] = sid
            out += rows
            status[sid] = {"state": "ok", "total": len(rows), "first": first, "error": "", "at": now()}
        except sources.SourceError as exc:
            status[sid] = {"state": "error", "error": str(exc), "at": now()}
            log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
    return out, status


def pick_year(rows, count):
    """Bis zu count Fotos eines Jahres: genauer Tag zuerst, Favoriten und GPS bevorzugt,
    über den Tag verteilt, keine Serienbilder."""
    def seconds(row):
        text = row["t"]
        try:
            return int(text[11:13]) * 3600 + int(text[14:16]) * 60 + int(text[17:19] or 0)
        except ValueError:
            return 43200

    best_dist = min(r["dist"] for r in rows)
    pool = [r for r in rows if r["dist"] == best_dist]
    pool.sort(key=lambda r: (not r.get("fav"), r["lat"] is None, seconds(r)))
    chosen = []
    for row in pool:
        if len(chosen) >= count:
            break
        if all(abs(seconds(row) - seconds(c)) >= BURST_SECONDS for c in chosen):
            chosen.append(row)
    for row in pool:                    # zu wenige? Dann doch Serienbilder, aber verschiedene Fotos
        if len(chosen) >= count:
            break
        if row not in chosen:
            chosen.append(row)
    if len(chosen) > count:
        chosen = chosen[:count]
    chosen.sort(key=lambda r: r["t"])
    return chosen


def next_memory(month, day):
    """Der nächste Kalendertag (bis 60 Tage), an dem es in früheren Jahren Fotos gibt (nur DynaFrame)."""
    today = datetime.date.today()
    days = {r["t"][5:10] for r in _index["rows"] if r["t"][:4] < str(today.year)}
    for step in range(1, 61):
        when = today + datetime.timedelta(days=step)
        if when.strftime("%m-%d") in days:
            return when.isoformat()
    return ""


def weather_then(row, day_rows, values):
    """(wetter, wo) für ein Foto: am Foto-Ort, sonst an einem Ort vom selben Tag, sonst zu Hause."""
    where, lat, lon = "photo", row["lat"], row["lon"]
    if lat is None:
        near = [r for r in day_rows if r["lat"] is not None and r["t"][:10] == row["t"][:10]]
        if near:
            near.sort(key=lambda r: abs(int(r["t"][11:13] or 12) - int(row["t"][11:13] or 12)))
            where, lat, lon = "near", near[0]["lat"], near[0]["lon"]
        elif values["HomeLat"] is not None and values["HomeLon"] is not None:
            where, lat, lon = "home", values["HomeLat"], values["HomeLon"]
        else:
            return None, ""
    try:
        found = sky.then(lat, lon, row["t"][:10], as_int(row["t"][11:13], 12))
    except weather.WeatherError as exc:
        _day["weatherError"] = str(exc)
        return None, ""
    return found, where


def build_day(reason=""):
    values = settings()
    today = datetime.date.today()
    date = today.isoformat()
    with _day_lock:
        if _day["busy"]:
            return
        _day["busy"] = True
    started = now()
    try:
        _day["weatherError"] = ""
        month, day = today.month, today.day
        widest = max(values["DayWindow"], WIDEN_MAX if values["AutoWiden"] else 0)
        candidates = []
        for row in _index["rows"]:
            if row["t"][:4] >= str(today.year) or row["t"][:4] < str(today.year - MAX_YEARS):
                continue
            dist = md_distance(row["t"], month, day, 0)
            if dist <= widest:
                candidates.append(dict(row, dist=dist))
        more, status = immich_rows(values, month, day, widest)
        for row in more:
            if row["t"][:4] < str(today.year):
                dist = md_distance(row["t"], month, day, 0)
                if dist <= widest:
                    candidates.append(dict(row, dist=dist))
        _day["immich"] = status
        seen, unique = set(), []
        for row in candidates:
            if row["k"] not in seen:
                seen.add(row["k"])
                unique.append(row)

        # Fenster: so eng wie eingestellt; findet sich gar nichts, Schritt für Schritt weiter
        window = values["DayWindow"]
        inside = [r for r in unique if r["dist"] <= window]
        while not inside and values["AutoWiden"] and window < WIDEN_MAX:
            window += 1
            inside = [r for r in unique if r["dist"] <= window]

        by_year = {}
        for row in inside:
            by_year.setdefault(int(row["t"][:4]), []).append(row)
        chosen_years = []
        for year in sorted(by_year):
            rows = by_year[year]
            chosen_years.append((year, rows, pick_year(rows, values["PerYear"])))

        photos, years = [], []
        lang = values["Language"]
        for year, rows, chosen in chosen_years:
            entry = {"y": year, "ago": today.year - year, "n": len(rows), "photos": []}
            for row in chosen:
                then, where = (None, "")
                then, where = weather_then(row, rows, values)
                place = row.get("place") or ""
                if values["ShowPlace"] and not place and row["lat"] is not None:
                    place = sky.place(row["lat"], row["lon"], lang)
                idx = len(photos)
                photos.append({"k": row["k"], "stamp": row.get("stamp") or "", "w": row.get("w"), "h": row.get("h")})
                entry["photos"].append({
                    "i": idx, "t": row["t"], "place": place, "lat": row["lat"], "lon": row["lon"],
                    "w": then, "where": where, "days": row["dist"],
                })
            years.append(entry)
        sky.save()

        signature = day_signature(values, date)
        with _day_lock:
            _day.update(ver=_day["ver"] + 1, date=date, signature=signature, years=years, photos=photos,
                        window=window, candidates=len(inside), at=now(),
                        next="" if years else next_memory(month, day))
            _day["facts"] = facts(years)
        log(f"{date}: {sum(len(y['photos']) for y in years)} Fotos aus {len(years)} Jahren"
            f" (Fenster ± {window} Tage, {len(inside)} Kandidaten, {now() - started:.0f} s"
            + (f", Wetter: {_day['weatherError']}" if _day["weatherError"] else "") + f"){' - ' + reason if reason else ''}.")
        refresh_today(force=True)
        threading.Thread(target=prepare_all, name=f"{PLUGIN_ID}-photos", daemon=True).start()
    finally:
        with _day_lock:
            _day["busy"] = False


def facts(years):
    """Vergleiche über die Jahre (die Szene macht daraus Sätze)."""
    per_year = []
    for entry in years:
        weathers = [p["w"] for p in entry["photos"] if p.get("w")]
        if not weathers:
            continue
        main = weathers[0]
        temps = [w["t"] for w in weathers if w.get("t") is not None]
        place = next((p["place"] for p in entry["photos"] if p.get("place")), "")
        per_year.append({"y": entry["y"], "t": round(sum(temps) / len(temps), 1) if temps else None,
                         "tmax": main.get("tmax"), "tmin": main.get("tmin"), "rain": main.get("rain"),
                         "sun": main.get("sun"), "code": main.get("dcode"), "place": place})
    out = {"years": len(years), "photos": sum(e["n"] for e in years), "first": years[0]["y"] if years else None,
           "perYear": per_year}
    hot = [p for p in per_year if p["tmax"] is not None]
    if hot:
        out["warmest"] = max(hot, key=lambda p: p["tmax"])
        out["coldest"] = min(hot, key=lambda p: p["tmin"] if p["tmin"] is not None else p["tmax"])
        out["avgMax"] = round(sum(p["tmax"] for p in hot) / len(hot), 1)
    wet = [p for p in per_year if p["rain"] is not None and p["rain"] > 0.2]
    if wet:
        out["wettest"] = max(wet, key=lambda p: p["rain"])
    out["dry"] = sum(1 for p in per_year if p["rain"] is not None and p["rain"] <= 0.2)
    places = {}
    for entry in years:
        for photo in entry["photos"]:
            if photo.get("place"):
                places.setdefault(photo["place"], set()).add(entry["y"])
    if places:
        name, seen = max(places.items(), key=lambda item: len(item[1]))
        if len(seen) >= 2:
            out["place"] = {"name": name, "years": len(seen)}
    return out


def refresh_today(force=False):
    """Das Wetter jetzt: zu Hause und (wenn eingestellt) an den Orten der Fotos."""
    values = settings()
    if not values["ShowWeather"]:
        return
    if not force and now() - _today["at"] < 900:
        return
    _today["at"] = now()
    error = ""
    if values["HomeLat"] is not None and values["HomeLon"] is not None:
        try:
            _today["home"] = sky.today(values["HomeLat"], values["HomeLon"])
        except weather.WeatherError as exc:
            error = str(exc)
    else:
        _today["home"] = None
    there = {}
    if values["TodayAt"] == "there" or _today["home"] is None:
        spots = {}
        for entry in _day["years"]:
            for photo in entry["photos"]:
                if photo["lat"] is not None:
                    spots[f"{round(photo['lat'], 1)},{round(photo['lon'], 1)}"] = (photo["lat"], photo["lon"])
        for key, (lat, lon) in list(spots.items())[:30]:
            try:
                there[key] = sky.today(lat, lon)
            except weather.WeatherError as exc:
                error = str(exc)
                break
    _today["there"] = there
    _today["error"] = error


# --------------------------------------------------------------------------
# Fotos für die Szene
# --------------------------------------------------------------------------

PHOTO_MAX = 40 * 1024 * 1024
SHOWABLE = (".jpg", ".jpeg", ".jpe", ".png", ".webp", ".gif", ".bmp", ".tif", ".tiff")


def webdav_dirs():
    seen = []
    for home in (Path.home(), Path("/home/pi")):
        folder = home / ".local/share/dfr/webdav-cache"
        if folder not in seen and folder.is_dir():
            seen.append(folder)
    return seen


def webdav_cached(path, size):
    """Fotos aus WebDAV (/webdav-media/<Quelle>/...) liefert die Engine nur als
    512-Pixel-Vorschau. Das Original legt DynaFrame aber in webdav-cache ab,
    als <Quelle>-<Hash>.<Endung>. Den Hash kennen wir nicht, also: gleiche
    Quelle, gleiche Endung, gleiche Dateigröße (wie bei Halloween Scare)."""
    if not path.startswith("/webdav-media/"):
        return None
    size = as_int(size, 0)
    if size <= 0 or size > PHOTO_MAX:
        return None
    parts = path.split("/")
    source = parts[2] if len(parts) > 2 else ""
    suffix = Path(path).suffix.lower()
    best = None
    for folder in webdav_dirs():
        try:
            entries = list(os.scandir(folder))
        except OSError:
            continue
        for entry in entries:
            name = entry.name
            if source and not name.startswith(source + "-"):
                continue
            if suffix and not name.lower().endswith(suffix):
                continue
            try:
                info = entry.stat()
            except OSError:
                continue
            if info.st_size == size and (best is None or info.st_mtime > best[0]):
                best = (info.st_mtime, Path(entry.path))
    return best[1] if best else None


def shrink(source):
    """Bild (Pfad oder Bytes) gedreht nach Exif und verkleinert als JPEG-Bytes, dazu (w, h)."""
    if Image is None:
        raise sources.SourceError("Pillow fehlt")
    handle = io.BytesIO(source) if isinstance(source, (bytes, bytearray)) else source
    with Image.open(handle) as image:
        try:
            image.draft("RGB", (PHOTO_EDGE, PHOTO_EDGE))
        except Exception:  # noqa: BLE001 - nur JPEG kennt draft
            pass
        image = ImageOps.exif_transpose(image)
        image = image.convert("RGB")
        image.thumbnail((PHOTO_EDGE, PHOTO_EDGE), Image.LANCZOS)
        out = io.BytesIO()
        image.save(out, "JPEG", quality=86, optimize=True, progressive=True)
        return out.getvalue(), image.size


def photo_file(item):
    name = hashlib.sha1(f"{item['k']}|{item.get('stamp') or ''}".encode("utf-8")).hexdigest()[:20]
    return PHOTO_DIR / f"{name}.jpg"


def prepare(item):
    """Das Foto als JPEG im Cache ablegen; liefert den Pfad."""
    target = photo_file(item)
    if target.is_file():
        return target
    key = item["k"]
    data = None
    if key.startswith("i:"):
        values = settings()
        immich.configure(values["ServerUrl"], values["ApiKey"])
        raw, _kind = immich.photo(key[2:], size="preview")
        try:
            data, _size = shrink(raw)
        except Exception:  # noqa: BLE001 - dann so, wie Immich es schickt
            data = raw
    else:
        path = key_path(key)
        local = path and os.path.isfile(path)
        if local and (path.lower().endswith(SHOWABLE) or HEIF):
            try:
                data, _size = shrink(path)
            except Exception as exc:  # noqa: BLE001 - kaputte Datei: über die Engine
                log(f"Foto {path}: {exc}", "warning")
        if data is None and path.startswith("/webdav-media/"):
            cached = webdav_cached(path, str(item.get("stamp") or "").split(":")[0])
            if cached:
                try:
                    data, _size = shrink(str(cached))
                except Exception:  # noqa: BLE001
                    data = None
        if data is None and key.startswith("d:"):
            raw = engine_image(key[2:].partition("|")[0], path)
            try:
                data, _size = shrink(raw)
            except Exception:  # noqa: BLE001
                data = raw
        if data is None:
            raise sources.SourceError("Foto nicht gefunden")
    PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(f".{threading.get_ident()}.tmp")
    temp.write_bytes(data)
    temp.replace(target)
    return target


_prepare_lock = threading.Lock()


def prepare_all():
    with _prepare_lock:
        photos = list(_day["photos"])
        keep = set()
        failed = 0
        for item in photos:
            if _stop_requested.is_set():
                return
            try:
                keep.add(prepare(item).name)
            except Exception as exc:  # noqa: BLE001 - ein Foto darf den Rest nicht aufhalten
                failed += 1
                if failed <= 3:
                    log(f"Foto für die Szene ({item['k'][:100]}): {exc}", "warning")
        # alte Fotos weg (die von heute bleiben)
        try:
            for entry in os.scandir(PHOTO_DIR):
                if entry.name not in keep and now() - entry.stat().st_mtime > 2 * 86400:
                    os.unlink(entry.path)
        except OSError:
            pass


def photo_bytes(query):
    idx = as_int((query.get("i") or ["-1"])[0], -1)
    ver = as_int((query.get("v") or ["-1"])[0], -1)
    if ver != _day["ver"] or not 0 <= idx < len(_day["photos"]):
        return None
    try:
        return prepare(_day["photos"][idx]).read_bytes()
    except Exception as exc:  # noqa: BLE001
        log(f"Foto für die Szene: {exc}", "warning")
        return None


# --------------------------------------------------------------------------
# Der Arbeitsfaden
# --------------------------------------------------------------------------

def work_loop():
    while not _stop_requested.is_set():
        values = settings()
        try:
            due = now() - _index["at"] >= values["RefreshHours"] * 3600
            if due or _index["signature"] != index_signature(values):
                build_index("geplant" if due and _index["at"] else "Einstellungen")
            date = datetime.date.today().isoformat()
            if _day["signature"] != day_signature(values, date):
                _work_stop.clear()
                build_day("neuer Tag" if _day["date"] != date else "Einstellungen")
            refresh_today()
        except Exception as exc:  # noqa: BLE001 - der Faden darf nicht sterben
            log(f"Fehler: {exc!r}", "warning")
        _wake.wait(30)
        _wake.clear()


def reload_now():
    _work_stop.set()
    _index["at"] = 0.0
    _day["signature"] = ""
    _immich_cache.clear()
    _today["at"] = 0.0

    def later():
        time.sleep(1)
        _work_stop.clear()
        _wake.set()

    threading.Thread(target=later, daemon=True).start()
    return {"success": True, "message": tr("Die Fotos werden neu eingelesen.")}


# --------------------------------------------------------------------------
# Playlist für die Szene
# --------------------------------------------------------------------------

def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=(PLAYLIST_NAME,) + OLD_PLAYLIST_NAMES,
    name=lambda: PLAYLIST_NAMES.get(settings()["Language"], PLAYLIST_NAMES["en"]),
    description=lambda: tr("Deine Fotos von heute aus früheren Jahren, mit dem Wetter von damals."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()


# --------------------------------------------------------------------------
# Was die Szene bekommt
# --------------------------------------------------------------------------

SCENE_SETTINGS = ("Language", "Layout", "YearOrder", "PhotoSeconds", "FadeSeconds", "KenBurns", "ShowSummary",
                  "SummarySeconds", "ShowWeather", "TodayAt", "HomeName", "Units", "ShowPlace")


def today_for(photo):
    if photo.get("lat") is None:
        return None
    return _today["there"].get(f"{round(photo['lat'], 1)},{round(photo['lon'], 1)}")


def scene_payload(query):
    values = settings()
    have = as_int((query.get("v") or ["-1"])[0], -1)
    payload = {
        "success": True,
        "ver": _day["ver"],
        "date": _day["date"] or datetime.date.today().isoformat(),
        "settings": {k: values[k] for k in SCENE_SETTINGS},
        "busy": _day["busy"] or _index["busy"],
        "hasHome": values["HomeLat"] is not None,
        "today": {"home": _today["home"], "at": _today["at"]},
        "sources": len(values["Sources"]),
    }
    if values["TodayAt"] == "there" or _today["home"] is None:
        payload["today"]["there"] = {}
        for entry in _day["years"]:
            for photo in entry["photos"]:
                found = today_for(photo)
                if found:
                    payload["today"]["there"][str(photo["i"])] = found
    if have != _day["ver"]:
        payload.update(years=_day["years"], facts=_day["facts"], window=_day["window"], next=_day["next"])
    return payload


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    status = {}
    for source in values["Sources"]:
        row = dict(_index["status"].get(source["id"]) or _day["immich"].get(source["id"]) or {})
        if (_index["busy"] or _day["busy"]) and not row:
            row = {"state": "wait"}
        row["kind"] = source["kind"]
        status[source["id"]] = row
    preview = []
    for entry in _day["years"]:
        for photo in entry["photos"][:1]:
            preview.append({"y": entry["y"], "i": photo["i"], "n": entry["n"],
                            "t": (photo.get("w") or {}).get("t"), "code": (photo.get("w") or {}).get("code"),
                            "place": photo.get("place") or ""})
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "status": status,
        "busy": _index["busy"] or _day["busy"],
        "progress": _index["progress"],
        "indexAt": _index["at"],
        "indexed": len(_index["rows"]),
        "dfCount": _index.get("dfCount"),
        "undated": _index["undated"],
        "date": _day["date"],
        "ver": _day["ver"],
        "years": len(_day["years"]),
        "photos": len(_day["photos"]),
        "window": _day["window"],
        "next": _day["next"],
        "preview": preview,
        "weatherError": _day["weatherError"] or _today["error"],
        "home": _today["home"],
        "heif": HEIF,
        "theme": {"id": theme_id()},
    }


def test_immich():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        info = immich.test()
    except sources.SourceError as exc:
        return {"success": True, "ok": False, "message": str(exc)}
    return {"success": True, "ok": True,
            "message": tr("Verbunden als {user} (Immich {version}).", user=info["user"] or "?",
                          version=info["version"] or "?")}


def list_albums():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, "albums": immich.albums()}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_immich(what):
    """Personen bzw. Tags für die Immich-Filter."""
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, what: getattr(immich_filters, what)(immich)}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_playlists():
    try:
        rows = [p for p in dynaframe.playlists() if p["name"] not in (PLAYLIST_NAME,) + OLD_PLAYLIST_NAMES]
        return {"success": True, "playlists": sorted(rows, key=lambda p: str(p["name"]).lower())}
    except EngineError as exc:
        return {"success": False, "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc)}


def search_place(query):
    name = re.sub(r"\s+", " ", (query.get("q") or [""])[0]).strip()[:80]
    if len(name) < 2:
        return {"success": True, "places": []}
    try:
        return {"success": True, "places": sky.search(name, settings()["Language"])}
    except weather.WeatherError as exc:
        return {"success": False, "error": tr("Die Ortssuche (Open-Meteo) antwortet nicht: {exc}", exc=exc)}


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(query), cors=True)
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            if path == "/api/photo":
                found = photo_bytes(query)
                if found is None:
                    self._json({"success": False}, 404, cors=True)
                else:
                    self._send(found, "image/jpeg", cache="private, max-age=86400", cors=True)
                return
            if path == "/api/albums":
                self._json(list_albums())
                return
            if path in ("/api/people", "/api/tags"):
                self._json(list_immich(path.rsplit("/", 1)[1]))
                return
            if path == "/api/playlists":
                self._json(list_playlists())
                return
            if path == "/api/places":
                self._json(search_place(query))
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                for name in SECRETS:
                    # Ein leeres Feld heißt: das alte behalten. Löschen geht mit "-".
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)
                    elif name in body and str(body[name]).strip() == "-":
                        body[name] = ""
                changed = save_settings(body)
                if "MakePlaylist" in changed:
                    OWN.changed()
                if changed:
                    if any(n in changed for n in ("Albums", *immich_filters.SCHEMA)):
                        # Nichts Ausgefiltertes mehr zeigen, bis neu gesucht ist
                        _immich_cache.clear()
                        with _day_lock:
                            _day.update(ver=_day["ver"] + 1, years=[], photos=[], facts={})
                    if any(n in changed for n in ("HomeLat", "HomeLon", "TodayAt", "ShowWeather")):
                        _today["at"] = 0.0
                    _wake.set()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(reload_now())
                return
            if path == "/api/test":
                self._json(test_immich())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}" + ("" if HEIF else " (ohne HEIC-Unterstützung, HEIC über die Engine)"))
    renamed_playlists.start(engine_call, log, {name: PLAYLIST_NAME for name in OLD_PLAYLIST_NAMES})

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: reload_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    adopt_immich()
    try:
        os.nice(5)   # das Einlesen soll die Wiedergabe nicht stören
    except OSError:
        pass
    threading.Thread(target=work_loop, name=f"{PLUGIN_ID}-work", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _work_stop.set()
    _wake.set()
    try:
        exif_save()
        sky.save()
    except Exception:
        pass
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
