#!/usr/bin/env python3
"""Reise-Scrapbook - der Plugin-Teil des Pakets "Travel Scrapbook".

Die Szene "travel-scrapbook" zeigt eine Reise nach der anderen als
Scrapbook-Seite: eingeklebte Abzüge (nach Sternen ausgewählt), eine kleine
Routenkarte, Tage, Kilometer, das Wetter unterwegs und handschriftliche Notizen.

Dieses Plugin
- liest alle Fotos mit Datum und Ort: aus einer Playlist von DynaFrame, der
  ganzen Mediendatenbank (und eingehängten Ordnern) oder von Immich,
- findet den Wohnort (wo an den meisten Tagen fotografiert wurde, je Jahr,
  also auch nach einem Umzug) oder nimmt den auf der Seite eingestellten,
- findet die Reisen (mehrere Tage am Stück weit weg von zu Hause, trips.py),
- wählt je Reise die Abzüge (meiste Sterne zuerst, über die Tage verteilt),
- holt Ortsnamen (OpenStreetMap) und das Wetter jedes Reisetags (Open-Meteo-Archiv),
- merkt sich, welche Reise zuletzt gezeigt wurde, damit der Rahmen nach und
  nach einen Urlaub nach dem anderen zeigt.
"""

import datetime
import hashlib
import io
import json
import os
import random
import re
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import exif_gps  # noqa: E402
import dynaframe_filters  # noqa: E402
import immich_filters  # noqa: E402
import sources  # noqa: E402
import own_playlist  # noqa: E402
import texts  # noqa: E402
import trips  # noqa: E402
import weather  # noqa: E402

try:
    from PIL import Image, ImageOps
except ImportError:  # pragma: no cover - kommt mit requirements.txt
    Image = ImageOps = None

HEIF = False
if Image is not None:
    try:
        from pillow_heif import register_heif_opener  # type: ignore

        register_heif_opener()
        HEIF = True
    except Exception:  # noqa: BLE001 - optional
        HEIF = False

plugin = create_plugin()

PLUGIN_ID = "TravelScrapbook"
SCENE_ID = "travel-scrapbook"        # id in scene.dynamic - nie ändern
PLAYLIST_NAMES = {"de": "Reise-Scrapbook", "en": "Travel Scrapbook", "es": "Álbum de viajes"}
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen, Caches; bleibt bei Updates
PHOTO_DIR = DATA_DIR / "photos"

CONNECT_TIMEOUT = 10
MAX_SOURCES = 6
PHOTO_EDGE = 1400                   # lange Seite der Abzüge für die Szene
PHOTO_KEEP = 500                    # so viele Abzüge bleiben im Cache

KINDS = ("library", "playlist", "immich_all", "immich_album")


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def as_float(value, default=None):
    try:
        number = float(str(value).strip().replace(",", "."))
    except (TypeError, ValueError):
        return default
    return default if number != number else number


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält den API-Schlüssel
        except OSError:
            pass


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


def sha(text):
    return hashlib.sha256(str(text).encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

def default_sources():
    return [{"id": "s1", "kind": "library", "ref": "", "name": ""}]


SCHEMA = {
    "Language":        {"kind": "choice", "default": "en", "choices": texts.LANGUAGES},
    "ServerUrl":       {"kind": "url", "default": ""},
    "ApiKey":          {"kind": "secret", "default": ""},
    "Sources":         {"kind": "sources", "default": None},
    "Folders":         {"kind": "folders", "default": ""},
    # Welche Immich-Fotos überhaupt (wie Heute vor X Jahren)
    "Albums":          {"kind": "albums", "default": []},
    # Immich-Filter wie Foto Mosaik (ohne „Wann“: die Reisen findet das Plugin selbst)
    **immich_filters.schema(without=immich_filters.WHEN),
    # DynaFrame-Filter wie Foto Mosaik (Sterne, Kamera … aus der Mediendatenbank)
    **dynaframe_filters.schema(without=dynaframe_filters.WHEN),
    # Was als Reise zählt
    "HomeName":        {"kind": "text", "default": ""},
    "HomeLat":         {"kind": "coord", "default": None},
    "HomeLon":         {"kind": "coord", "default": None},
    "MinKm":           {"kind": "int", "default": 60, "min": 5, "max": 3000},
    "MinDays":         {"kind": "int", "default": 2, "min": 1, "max": 30},
    "MaxGap":          {"kind": "int", "default": 2, "min": 0, "max": 10},
    "MinPhotos":       {"kind": "int", "default": 10, "min": 1, "max": 1000},
    # Die Seite
    "PhotosPerPage":   {"kind": "int", "default": 6, "min": 3, "max": 9},
    "MinStars":        {"kind": "int", "default": 0, "min": 0, "max": 5},
    "TripOrder":       {"kind": "choice", "default": "season", "choices": ("season", "newest", "oldest", "random")},
    "PageSeconds":     {"kind": "int", "default": 45, "min": 10, "max": 900},
    "Paper":           {"kind": "choice", "default": "kraft", "choices": ("kraft", "cream", "black")},
    "ShowMap":         {"kind": "bool", "default": True},
    "ShowWeather":     {"kind": "bool", "default": True},
    "ShowNotes":       {"kind": "bool", "default": True},
    "ShowCover":       {"kind": "bool", "default": True},
    "Animate":         {"kind": "bool", "default": True},
    "Units":           {"kind": "choice", "default": "metric", "choices": ("metric", "imperial")},
    "RefreshHours":    {"kind": "int", "default": 12, "min": 1, "max": 168},
    "PlaylistSeconds": {"kind": "int", "default": 300, "min": 10, "max": 86400},
    "MakePlaylist":    {"kind": "bool", "default": False},
}
SECRETS = [name for name, spec in SCHEMA.items() if spec["kind"] == "secret"]
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()


def coerce_sources(raw):
    if raw is None:
        return default_sources()
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return default_sources()
    out, ids = [], set()
    for row in raw if isinstance(raw, list) else []:
        if not isinstance(row, dict) or len(out) >= MAX_SOURCES:
            continue
        ident = re.sub(r"[^A-Za-z0-9]", "", str(row.get("id") or ""))[:16] or uuid.uuid4().hex[:8]
        while ident in ids:
            ident = uuid.uuid4().hex[:8]
        ids.add(ident)
        out.append({
            "id": ident,
            "kind": row.get("kind") if row.get("kind") in KINDS else "library",
            "ref": re.sub(r"[^A-Za-z0-9_-]", "", str(row.get("ref") or ""))[:64],
            "name": re.sub(r"\s+", " ", str(row.get("name") or "")).strip()[:60],
        })
    return out


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind in ("ref", "date", "name"):
        return immich_filters.coerce(spec, raw)
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "float":
        return round(max(spec["min"], min(spec["max"], as_float(raw, spec["default"]))), 1)
    if kind == "coord":
        value = as_float(raw, None)
        return None if value is None or abs(value) > 180 else round(value, 4)
    if kind == "choice":
        value = str(raw or "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "sources":
        return coerce_sources(raw)
    if kind == "albums":
        if isinstance(raw, str):
            raw = [part for part in raw.split(",") if part]
        ids = []
        for item in raw if isinstance(raw, list) else []:
            ident = re.sub(r"[^A-Za-z0-9_-]", "", str(item or ""))[:64]
            if ident and ident not in ids:
                ids.append(ident)
        return ids[:50]
    if kind == "url":
        return sources.normalize_url(raw)[:300]
    if kind == "text":
        return re.sub(r"\s+", " ", str(raw or "")).strip()[:80]
    if kind == "folders":
        lines = [line.strip() for line in str(raw or "").replace(";", "\n").splitlines()]
        return "\n".join(line for line in lines if line.startswith("/"))[:2000]
    return re.sub(r"\s+", "", str(raw or ""))[:400]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


def adopt_immich():
    """Server und Schlüssel aus einem anderen Immich-Plugin übernehmen, wenn hier keiner steht."""
    values = settings()
    if values["ServerUrl"] and values["ApiKey"]:
        return ""
    for name, title in (("ImmichSlideshow", "Immich Slideshow"), ("GrowingUp", "Growing Up"),
                        ("OnThisDay", "On This Day"), ("PhotoMosaic", "Foto Mosaik"),
                        ("ColorCalendar", "Colour Calendar"), ("TravelMap", "Travel Map")):
        other = read_json(PLUGIN_DIR.parent / name / "data" / "settings.json", {}) or {}
        if not isinstance(other, dict):
            continue
        url, key = sources.normalize_url(other.get("ServerUrl")), str(other.get("ApiKey") or "").strip()
        if url and key:
            save_settings({"ServerUrl": url, "ApiKey": key})
            log(f"Immich-Server und API-Schlüssel aus {title} übernommen.")
            return title
    return ""


# --------------------------------------------------------------------------
# Eigene Angaben zu den Reisen (Titel, Notiz, ausblenden)
# --------------------------------------------------------------------------

EDITS_FILE = DATA_DIR / "trip_edits.json"
_edits_lock = threading.Lock()


def load_edits():
    stored = read_json(EDITS_FILE, {})
    return stored if isinstance(stored, dict) else {}


def edit_key(trip, edits):
    """Welche gespeicherte Angabe zu dieser Reise gehört. Gemerkt wird mit Start
    und Ende; verschiebt sich die Reise durch neue Fotos um ein paar Tage, gilt
    die Angabe weiter, solange sich die Zeiträume überschneiden."""
    if isinstance(edits.get(trip["id"]), dict):
        return trip["id"]
    for key, value in edits.items():
        if isinstance(value, dict) and value.get("start", "9") <= trip["end"] and value.get("end", "0") >= trip["start"]:
            return key
    return None


def save_edit(body):
    trip_id = str(body.get("id") or "")
    with _trips_lock:
        trip = next((t for t in _trips["list"] if t["id"] == trip_id), None)
    if trip is None:
        return {"success": False, "error": tr("Diese Reise gibt es nicht mehr.")}
    with _edits_lock:
        edits = load_edits()
        old = edit_key(trip, edits)
        current = dict(edits.pop(old, {}) if old else {})
        if "title" in body:
            current["title"] = re.sub(r"\s+", " ", str(body.get("title") or "")).strip()[:60]
        if "note" in body:
            current["note"] = re.sub(r"[ \t]+", " ", str(body.get("note") or "")).strip()[:240]
        if "hidden" in body:
            current["hidden"] = as_bool(body.get("hidden"))
        current.update(start=trip["start"], end=trip["end"])
        if current.get("title") or current.get("note") or current.get("hidden"):
            edits[trip["id"]] = current
        write_json(EDITS_FILE, edits)
    apply_edits()
    return {"success": True}


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 120))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def engine_image(media_id, path=""):
    """Das Vorschaubild, das die Engine für die Weboberfläche erzeugt (auf Jans Rahmen 512 Pixel)."""
    candidates = []
    if path:
        candidates += [("/media/thumbnail", {"path": path, "purpose": "preview"}),
                       ("/media/thumbnail", {"path": path})]
    if media_id:
        candidates += [(f"/media/thumbnail/{media_id}", {"purpose": "preview"}),
                       (f"/media/thumbnail/{media_id}", None)]
    failures = []
    for route, params in candidates:
        try:
            response = requests.get(f"{engine_base()}{route}", params=params, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 60))
        except requests.RequestException as exc:
            failures.append(f"{route}: {exc}")
            continue
        kind = response.headers.get("Content-Type", "").split(";")[0]
        if response.status_code == 200 and kind.startswith("image/"):
            return response.content
        failures.append(f"{route}{'?path' if params and 'path' in params else ''}: HTTP {response.status_code} {kind}")
    raise sources.SourceError(f"Vorschaubild {media_id}: " + "; ".join(failures))


# --------------------------------------------------------------------------
# Alle Fotos mit Datum und Ort (DynaFrame und Immich), mit Cache für Dateien
# --------------------------------------------------------------------------

immich = sources.Immich(tr)
dynaframe = sources.DynaFrame(engine_call, EngineError, log)
sky = weather.Weather(DATA_DIR, log)

EXIF_FILE = DATA_DIR / "exif.json"
_exif = {"data": None, "dirty": 0}
_exif_lock = threading.Lock()


def exif_lookup(path, stamp):
    """(taken, lat, lon) aus der Datei, mit Cache (key = Pfad, Stempel muss passen)."""
    with _exif_lock:
        if _exif["data"] is None:
            stored = read_json(EXIF_FILE, {})
            _exif["data"] = stored if isinstance(stored, dict) else {}
        row = _exif["data"].get(path)
    if isinstance(row, list) and len(row) == 4 and row[0] == stamp:
        return row[1], row[2], row[3]
    lat, lon, taken = exif_gps.read(path)
    taken = sources.clean_taken(taken)
    with _exif_lock:
        _exif["data"][path] = [stamp, taken, lat, lon]
        _exif["dirty"] += 1
    return taken, lat, lon


def exif_save(keep=None):
    with _exif_lock:
        if _exif["data"] is None:
            return
        if keep is not None:
            for key in [k for k in _exif["data"] if k not in keep]:
                del _exif["data"][key]
                _exif["dirty"] += 1
        if _exif["dirty"]:
            write_json(EXIF_FILE, _exif["data"])
            _exif["dirty"] = 0


STARS_FILE = DATA_DIR / "stars.json"
_stars = {"data": None, "dirty": False}


def file_stars(path, stamp):
    """Sterne einer Datei, die die Mediendatenbank nicht kennt (XMP daneben/darin, EXIF)."""
    if _stars["data"] is None:
        stored = read_json(STARS_FILE, {})
        _stars["data"] = stored if isinstance(stored, dict) else {}
    hit = _stars["data"].get(path)
    if isinstance(hit, list) and len(hit) == 2 and hit[0] == stamp:
        return hit[1]
    stars = as_int((dynaframe_filters.file_meta(path) or {}).get("r"), 0)
    _stars["data"][path] = [stamp, stars]
    _stars["dirty"] = True
    return stars


def stars_save():
    if _stars["dirty"] and _stars["data"] is not None:
        write_json(STARS_FILE, _stars["data"])
        _stars["dirty"] = False


def key_path(key):
    if key.startswith("d:"):
        return key.partition("|")[2]
    if key.startswith("f:"):
        return key[2:]
    return ""


_stop_requested = threading.Event()
_work_stop = threading.Event()
_wake = threading.Event()
_index_lock = threading.Lock()
_index = {"rows": [], "status": {}, "at": 0.0, "signature": "", "busy": False,
          "progress": {"done": 0, "todo": 0, "phase": ""}, "undated": 0, "total": 0, "located": 0}


def index_signature(values):
    keep = [(s["id"], s["kind"], s["ref"]) for s in values["Sources"]]
    immich_part = [values["ServerUrl"], values["ApiKey"], values["Albums"], immich_filters.signature(values)] \
        if any(s["kind"].startswith("immich") for s in values["Sources"]) else []
    return sha(json.dumps([keep, values["Folders"], dynaframe_filters.signature(values), immich_part, version()],
                          sort_keys=True, default=str))


def read_immich(values, source, status):
    sid = source["id"]
    immich.configure(values["ServerUrl"], values["ApiKey"])
    if source["kind"] == "immich_album":
        if not source["ref"]:
            raise sources.SourceError(tr("Wähle ein Album."))
        albums = [source["ref"]]
    else:
        albums = list(values["Albums"])      # leer = alle Fotos

    def progress(count):
        _index["progress"] = {"done": count, "todo": 0, "phase": "immich"}

    rows = immich.all_rows(albums, _work_stop, immich_filters.from_settings(values), progress)
    located = sum(1 for r in rows if r["lat"] is not None)
    status[sid] = {"state": "ok", "total": len(rows), "dated": len(rows), "located": located, "error": "", "at": now()}
    return rows


def build_index(reason=""):
    """Alle Quellen einlesen: Datum, GPS und Sterne jedes Fotos."""
    values = settings()
    wanted = list(values["Sources"])
    with _index_lock:
        if _index["busy"]:
            return False
        _index["busy"] = True
    started = now()
    status, rows = {}, {}
    match = None
    if any(not s["kind"].startswith("immich") for s in wanted) and dynaframe_filters.active(values):
        match = dynaframe_filters.Matcher(values, lambda: dynaframe.library_rows(_work_stop),
                                          cache_file=str(DATA_DIR / "file_meta.json"), log=log)
    try:
        log(f"Lese die Fotos ein{' - ' + reason if reason else ''}.")
        _index["progress"] = {"done": 0, "todo": 0, "phase": "list"}
        for source in wanted:
            sid = source["id"]
            _index["status"][sid] = dict(_index["status"].get(sid) or {}, state="busy")
            try:
                if source["kind"].startswith("immich"):
                    found = read_immich(values, source, status)
                else:
                    if source["kind"] == "playlist":
                        if not source["ref"]:
                            raise sources.SourceError(tr("Wähle eine Playlist."))
                        try:
                            found, total = dynaframe.playlist(source["ref"], _work_stop)
                        except EngineError as exc:
                            if exc.status == 404:
                                raise sources.SourceError(tr("Die Playlist gibt es nicht mehr.")) from exc
                            raise
                    else:
                        folders = [f for f in values["Folders"].splitlines() if f]
                        found, total = dynaframe.library(folders, _work_stop)
                    if match is not None:
                        found = [row for row in found if match.keep(row["k"])]
                    status[sid] = {"state": "ok", "total": total, "dated": 0, "located": 0, "error": "", "at": now()}
                for row in found:
                    row["src"] = sid
                    rows.setdefault(row["k"], row)
            except EngineError as exc:
                status[sid] = {"state": "error", "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except sources.SourceError as exc:
                status[sid] = {"state": "error", "error": str(exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except Exception as exc:  # pragma: no cover - darf den Durchlauf nicht beenden
                status[sid] = {"state": "error", "error": str(exc)[:200], "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc!r}", "warning")
            _index["status"][sid] = status[sid]
            if _work_stop.is_set() or _stop_requested.is_set():
                return False

        if match is not None:
            match.save()
        _index["dfCount"] = match.counts() if match is not None else None
        # Datum/GPS aus den Dateien, wo die Engine keins mitliefert
        todo = [r for r in rows.values() if (not r["t"] or r["lat"] is None) and os.path.isfile(key_path(r["k"]))]
        _index["progress"] = {"done": 0, "todo": len(todo), "phase": "exif"}
        for count, row in enumerate(todo, 1):
            if _work_stop.is_set() or _stop_requested.is_set():
                exif_save()
                return False
            taken, lat, lon = exif_lookup(key_path(row["k"]), row["stamp"])
            row["t"] = row["t"] or taken
            if row["lat"] is None and lat is not None and lon is not None:
                row["lat"], row["lon"] = lat, lon
            _index["progress"]["done"] = count
            if count % 200 == 0:
                time.sleep(0.05)
        exif_save(keep={key_path(r["k"]) for r in rows.values() if key_path(r["k"])})
        dated = [r for r in rows.values() if len(r["t"]) >= 10]
        immich_ids = {s["id"] for s in wanted if s["kind"].startswith("immich")}
        for sid, row in status.items():
            if row.get("state") == "ok" and sid not in immich_ids:
                mine = [r for r in rows.values() if r.get("src") == sid]
                row["dated"] = sum(1 for r in mine if len(r["t"]) >= 10)
                row["located"] = sum(1 for r in mine if r["lat"] is not None)
        with _index_lock:
            _index.update(rows=dated, status=dict(_index["status"], **status), at=now(),
                          signature=index_signature(values), undated=len(rows) - len(dated), total=len(rows),
                          located=sum(1 for r in dated if r["lat"] is not None))
        log(f"{len(dated)} Fotos mit Datum ({len(rows) - len(dated)} ohne), davon {_index['located']} mit Ort, "
            f"{now() - started:.0f} s.")
        return True
    finally:
        _index["progress"] = {"done": 0, "todo": 0, "phase": ""}
        with _index_lock:
            _index["busy"] = False


# --------------------------------------------------------------------------
# Reisen finden, Abzüge wählen, Orte und Wetter
# --------------------------------------------------------------------------

TRIPS_FILE = DATA_DIR / "trips.json"
_trips_lock = threading.RLock()
_trips = {"ver": 0, "list": [], "home": None, "homes": [], "signature": "", "at": 0.0, "busy": False,
          "enriched": 0, "weatherError": "", "photos": {}}


def trips_signature(values):
    keep = ("HomeLat", "HomeLon", "MinKm", "MinDays", "MaxGap", "MinPhotos", "PhotosPerPage", "MinStars", "Language")
    return sha(json.dumps([{k: values[k] for k in keep}, _index["signature"], _index["at"], version()],
                          sort_keys=True, default=str))


def photo_id(row):
    return hashlib.sha1(f"{row['k']}|{row.get('stamp') or ''}".encode("utf-8")).hexdigest()[:20]


def split_place(name):
    """"Stadt, Land" -> (stadt, land)."""
    parts = [p.strip() for p in str(name or "").split(",") if p.strip()]
    if not parts:
        return "", ""
    if len(parts) == 1:
        return parts[0], ""
    return parts[0], parts[-1]


def place_name(lat, lon, lang, fetch=True):
    return sky.place(lat, lon, lang, allow_fetch=fetch)


def auto_title(places):
    """Ein Titel aus den Orten: eine Stadt, zwei Städte, ein Land oder zwei Länder."""
    named = [p for p in places if p.get("name")]
    cities, countries = [], []
    for p in named:
        city, country = split_place(p["name"])
        if city and city not in cities:
            cities.append(city)
        if country and country not in countries:
            countries.append(country)
    if not cities and not countries:
        return ""
    if len(countries) >= 2:
        return " & ".join(countries[:2]) + (" …" if len(countries) > 2 else "")
    total = sum(p.get("photos", 0) for p in named) or 1
    if len(cities) == 1 or named[0].get("photos", 0) >= 0.75 * total:
        return cities[0]
    if len(cities) == 2:
        firsts = {split_place(p["name"])[0]: p.get("first") or "" for p in reversed(named)}
        cities.sort(key=lambda c: firsts.get(c, ""))
        return f"{cities[0]} & {cities[1]}"
    return countries[0] if countries else cities[0]


def stars_of(row):
    if row.get("stars") is not None:
        return as_int(row["stars"], 0)
    path = key_path(row["k"])
    if path and os.path.isfile(path):
        return file_stars(path, row.get("stamp") or "")
    return 0


def build_trips(reason=""):
    values = settings()
    with _trips_lock:
        if _trips["busy"]:
            return
        _trips["busy"] = True
    started = now()
    try:
        rows = list(_index["rows"])
        if values["HomeLat"] is not None and values["HomeLon"] is not None:
            homes = [{"lat": values["HomeLat"], "lon": values["HomeLon"], "from": 1900, "to": 2200,
                      "manual": True, "share": None}]
        else:
            homes = trips.find_homes(rows)
        found = trips.find_trips(rows, homes, min_km=values["MinKm"], min_days=values["MinDays"],
                                 max_gap=values["MaxGap"], min_photos=values["MinPhotos"])
        lang = values["Language"]
        listed, photos = [], {}
        for trip in found:
            for row in trip["rows"]:
                row["stars"] = stars_of(row)
            picked = trips.pick_photos(trip["rows"], values["PhotosPerPage"], values["MinStars"], seed=trip["id"])
            if not picked["photos"]:
                continue
            chosen = []
            for row in picked["photos"]:
                pid = photo_id(row)
                photos[pid] = {"k": row["k"], "stamp": row.get("stamp") or ""}
                chosen.append({"id": pid, "t": row["t"], "lat": row["lat"], "lon": row["lon"],
                               "stars": row["stars"], "fav": bool(row.get("fav")),
                               "place": split_place(row.get("place") or "")[0],
                               "w": row.get("w"), "h": row.get("h"), "best": row["k"] == picked["best"]})
            by_day = {}
            for row in trip["rows"]:
                by_day[row["t"][:10]] = by_day.get(row["t"][:10], 0) + 1
            best_day = max(by_day.items(), key=lambda item: item[1]) if by_day else ("", 0)
            stars = [r["stars"] for r in trip["rows"]]
            listed.append({
                "id": trip["id"], "start": trip["start"], "end": trip["end"], "days": trip["days"],
                "nights": trip["nights"], "count": len(trip["rows"]), "located": trip["located"],
                "km": trip["km"], "farKm": trip["farKm"], "bbox": trip["bbox"], "route": trip["route"],
                "dayPoints": trip["dayPoints"], "home": trip["home"],
                "places": [{"lat": p["lat"], "lon": p["lon"], "photos": p["photos"], "days": len(p["days"]),
                            "first": p["days"][0] if p["days"] else "", "name": p.get("place") or ""}
                           for p in trip["places"]],
                "photos": chosen,
                "bestDay": {"date": best_day[0], "photos": best_day[1]},
                "firstShot": trip["rows"][0]["t"], "lastShot": trip["rows"][-1]["t"],
                "fiveStars": sum(1 for s in stars if s >= 5), "rated": sum(1 for s in stars if s > 0),
                "wx": [],
            })
        stars_save()
        # Ortsnamen und Wetter aus dem Cache (ohne Netz) gleich mitnehmen. Fehlt ein Name (z. B. nach
        # einem Sprachwechsel), bleibt bis zum Nachladen der alte stehen statt "Unterwegs".
        with _trips_lock:
            before = {(round(p["lat"], 3), round(p["lon"], 3)): p.get("name") or ""
                      for t in _trips["list"] for p in t.get("places") or []}
            old_wx = {t["id"]: t.get("wx") or [] for t in _trips["list"]}
        for trip in listed:
            enrich(trip, lang, fetch=False)
            for place in trip["places"]:
                if not place["name"] and before.get((round(place["lat"], 3), round(place["lon"], 3))):
                    place["name"] = before[(round(place["lat"], 3), round(place["lon"], 3))]
                    place["stale"] = True
            if trip["places"] and any(p.get("stale") for p in trip["places"]):
                trip["autoTitle"] = auto_title(trip["places"][:4])
            if len(trip["wx"]) < trip["days"] == len(old_wx.get(trip["id"], [])):
                trip["wx"] = old_wx[trip["id"]]
        with _trips_lock:
            _trips.update(list=listed, homes=homes, home=homes[-1] if homes else None, photos=photos,
                          signature=trips_signature(values), at=now(), ver=_trips["ver"] + 1, enriched=0)
        apply_edits()
        save_trips()
        where = ", ".join(f"{h['lat']:.2f},{h['lon']:.2f}" for h in homes) or "unbekannt"
        log(f"{len(listed)} Reisen gefunden ({len(rows)} Fotos, Wohnort {where}, {now() - started:.1f} s)"
            f"{' - ' + reason if reason else ''}.")
    finally:
        with _trips_lock:
            _trips["busy"] = False
    threading.Thread(target=enrich_all, name=f"{PLUGIN_ID}-enrich", daemon=True).start()


def weather_segments(trip):
    """Reisetage nach Ort gruppiert (0,5°): je Gruppe eine Anfrage beim Archiv."""
    segments, last = [], None
    known = [d for d in trip["dayPoints"] if d["lat"] is not None]
    fallback = known[0] if known else {"lat": trip["home"]["lat"], "lon": trip["home"]["lon"]}
    for day in trip["dayPoints"]:
        where = day if day["lat"] is not None else (last or fallback)
        cell = (round(where["lat"] * 2) / 2, round(where["lon"] * 2) / 2)
        if segments and segments[-1]["cell"] == cell:
            segments[-1]["end"] = day["date"]
        else:
            segments.append({"cell": cell, "lat": where["lat"], "lon": where["lon"],
                             "start": day["date"], "end": day["date"]})
        if day["lat"] is not None:
            last = day
    return segments


def enrich(trip, lang, fetch=True):
    """Ortsnamen, Titel und Wetter. fetch=False: nur aus dem Cache. True, wenn alles da ist."""
    complete = True
    for place in trip["places"][:4]:
        if not place.get("name") or place.get("stale"):
            name = place_name(place["lat"], place["lon"], lang, fetch)
            if name:
                place["name"] = name
                place.pop("stale", None)
            complete = complete and bool(name or (place.get("name") and not fetch))
    named = [p for p in trip["places"] if p.get("name")]
    for photo in trip["photos"]:
        if photo["lat"] is None or (photo.get("place") and not any(p.get("stale") for p in trip["places"])):
            continue
        # erst die Orte der Reise (spart Anfragen bei Nominatim), sonst nachschlagen
        near = min(named, key=lambda p: trips.haversine(p["lat"], p["lon"], photo["lat"], photo["lon"]), default=None)
        if near and trips.haversine(near["lat"], near["lon"], photo["lat"], photo["lon"]) <= 20:
            photo["place"] = split_place(near["name"])[0]
        else:
            photo["place"] = split_place(place_name(photo["lat"], photo["lon"], lang, fetch))[0] or photo.get("place") or ""
    trip["autoTitle"] = auto_title(trip["places"][:4])
    countries = []
    for place in trip["places"]:
        country = split_place(place.get("name"))[1]
        if country and country not in countries:
            countries.append(country)
    trip["countries"] = countries
    if len(trip.get("wx") or []) < trip["days"]:
        wx = []
        for segment in weather_segments(trip):
            try:
                found = sky.days(segment["lat"], segment["lon"], segment["start"], segment["end"], fetch=fetch)
            except weather.WeatherError as exc:
                _trips["weatherError"] = str(exc)
                complete = False
                break
            for day, row in sorted(found.items()):
                wx.append(dict(row, date=day))
        if len(wx) > len(trip.get("wx") or []):
            trip["wx"] = wx
        if len(wx) < trip["days"]:
            complete = False
    return complete


def enrich_all():
    """Im Hintergrund: Ortsnamen (höchstens 1 pro Sekunde) und Wetter für alle Reisen."""
    lang = settings()["Language"]
    ver = _trips["ver"]
    with _trips_lock:
        todo = sorted(_trips["list"], key=lambda t: t["start"], reverse=True)
    done = 0
    _trips["weatherError"] = ""
    for home in list(_trips["homes"] or []):
        place_name(home["lat"], home["lon"], lang, True)
    for trip in todo:
        if _stop_requested.is_set() or _trips["busy"]:
            return
        try:
            enrich(trip, lang, fetch=True)
        except Exception as exc:  # noqa: BLE001 - eine Reise darf den Rest nicht aufhalten
            log(f"Reise {trip['id']}: {exc!r}", "warning")
        done += 1
        _trips["enriched"] = done
        if done % 5 == 0:
            sky.save()
            with _trips_lock:
                _trips["ver"] += 1           # die Szene holt die Namen und das Wetter
            save_trips()
    sky.save()
    with _trips_lock:
        _trips["ver"] += 1
    save_trips()
    log(f"Ortsnamen und Wetter für {done} Reisen da (seit Start der Runde ver {ver}).")


def apply_edits():
    edits = load_edits()
    with _trips_lock:
        for trip in _trips["list"]:
            key = edit_key(trip, edits)
            mine = edits.get(key) or {} if key else {}
            trip["title"] = mine.get("title") or ""
            trip["note"] = mine.get("note") or ""
            trip["hidden"] = bool(mine.get("hidden"))
        _trips["ver"] += 1


def save_trips():
    with _trips_lock:
        payload = {"list": _trips["list"], "homes": _trips["homes"], "photos": _trips["photos"], "at": _trips["at"]}
    write_json(TRIPS_FILE, payload)


def load_trips():
    """Beim Start die Reisen vom letzten Mal zeigen, bis neu eingelesen ist."""
    stored = read_json(TRIPS_FILE, {})
    if not isinstance(stored, dict) or not isinstance(stored.get("list"), list):
        return
    with _trips_lock:
        _trips.update(list=stored["list"], homes=stored.get("homes") or [], photos=stored.get("photos") or {},
                      home=(stored.get("homes") or [None])[-1], at=stored.get("at") or 0.0, ver=1)
    apply_edits()
    log(f"{len(stored['list'])} Reisen vom letzten Mal geladen.")


# --------------------------------------------------------------------------
# Reihenfolge: nach und nach eine Reise nach der anderen
# --------------------------------------------------------------------------

CURSOR_FILE = DATA_DIR / "cursor.json"
_cursor_lock = threading.Lock()


def visible_trips():
    return [t for t in _trips["list"] if not t.get("hidden")]


def ordered_ids(values=None):
    values = values or settings()
    trips_now = visible_trips()
    order = values["TripOrder"]
    if order == "newest":
        return [t["id"] for t in sorted(trips_now, key=lambda t: t["start"], reverse=True)]
    if order == "oldest":
        return [t["id"] for t in sorted(trips_now, key=lambda t: t["start"])]
    if order == "random":
        state = read_json(CURSOR_FILE, {}) or {}
        ids = sorted(t["id"] for t in trips_now)
        random.Random(state.get("seed") or "start").shuffle(ids)
        return ids
    # season: Reisen um diese Jahreszeit zuerst (Abstand im Jahreskreis, in 2-Wochen-Schritten), Neueste zuerst
    today = datetime.date.today().timetuple().tm_yday

    def distance(trip):
        start = datetime.date.fromisoformat(trip["start"])
        middle = start + datetime.timedelta(days=trip["days"] // 2)
        gap = abs(middle.timetuple().tm_yday - today)
        return min(gap, 365 - gap)

    return [t["id"] for t in sorted(trips_now, key=lambda t: (distance(t) // 14, -int(t["start"][:4])))]


def cursor_start(ids):
    """Index der Reise, die als nächste dran ist (nach der zuletzt gezeigten)."""
    state = read_json(CURSOR_FILE, {}) or {}
    last = state.get("last")
    if last in ids:
        return (ids.index(last) + 1) % len(ids)
    return 0


def mark_shown(trip_id):
    with _cursor_lock:
        state = read_json(CURSOR_FILE, {}) or {}
        ids = ordered_ids()
        if trip_id not in ids:
            return
        state["last"] = trip_id
        state["at"] = now()
        if settings()["TripOrder"] == "random" and ids.index(trip_id) == len(ids) - 1:
            state["seed"] = uuid.uuid4().hex[:8]       # einmal durch: neu mischen
            state.pop("last", None)
        write_json(CURSOR_FILE, state)
    threading.Thread(target=prefetch, args=(2,), daemon=True).start()


# --------------------------------------------------------------------------
# Fotos für die Szene
# --------------------------------------------------------------------------

PHOTO_MAX = 40 * 1024 * 1024
SHOWABLE = (".jpg", ".jpeg", ".jpe", ".png", ".webp", ".gif", ".bmp", ".tif", ".tiff")


def webdav_dirs():
    seen = []
    for home in (Path.home(), Path("/home/pi")):
        folder = home / ".local/share/dfr/webdav-cache"
        if folder not in seen and folder.is_dir():
            seen.append(folder)
    return seen


def webdav_cached(path, size):
    """Fotos aus WebDAV (/webdav-media/<Quelle>/...) liefert die Engine nur als
    512-Pixel-Vorschau. Das Original legt DynaFrame aber in webdav-cache ab,
    als <Quelle>-<Hash>.<Endung>. Den Hash kennen wir nicht, also: gleiche
    Quelle, gleiche Endung, gleiche Dateigröße (wie bei Halloween Scare)."""
    if not path.startswith("/webdav-media/"):
        return None
    size = as_int(size, 0)
    if size <= 0 or size > PHOTO_MAX:
        return None
    parts = path.split("/")
    source = parts[2] if len(parts) > 2 else ""
    suffix = Path(path).suffix.lower()
    best = None
    for folder in webdav_dirs():
        try:
            entries = list(os.scandir(folder))
        except OSError:
            continue
        for entry in entries:
            name = entry.name
            if source and not name.startswith(source + "-"):
                continue
            if suffix and not name.lower().endswith(suffix):
                continue
            try:
                info = entry.stat()
            except OSError:
                continue
            if info.st_size == size and (best is None or info.st_mtime > best[0]):
                best = (info.st_mtime, Path(entry.path))
    return best[1] if best else None


def shrink(source):
    """Bild (Pfad oder Bytes) gedreht nach Exif und verkleinert als JPEG-Bytes, dazu (w, h)."""
    if Image is None:
        raise sources.SourceError("Pillow fehlt")
    handle = io.BytesIO(source) if isinstance(source, (bytes, bytearray)) else source
    with Image.open(handle) as image:
        try:
            image.draft("RGB", (PHOTO_EDGE, PHOTO_EDGE))
        except Exception:  # noqa: BLE001 - nur JPEG kennt draft
            pass
        image = ImageOps.exif_transpose(image)
        image = image.convert("RGB")
        image.thumbnail((PHOTO_EDGE, PHOTO_EDGE), Image.LANCZOS)
        out = io.BytesIO()
        image.save(out, "JPEG", quality=85, optimize=True, progressive=True)
        return out.getvalue(), image.size


def photo_file(pid):
    return PHOTO_DIR / f"{pid}.jpg"


def prepare(pid):
    """Den Abzug als JPEG im Cache ablegen; liefert den Pfad."""
    target = photo_file(pid)
    if target.is_file():
        return target
    item = _trips["photos"].get(pid)
    if not item:
        raise sources.SourceError("unbekanntes Foto")
    key = item["k"]
    data = None
    if key.startswith("i:"):
        values = settings()
        immich.configure(values["ServerUrl"], values["ApiKey"])
        raw, _kind = immich.photo(key[2:], size="preview")
        try:
            data, _size = shrink(raw)
        except Exception:  # noqa: BLE001 - dann so, wie Immich es schickt
            data = raw
    else:
        path = key_path(key)
        local = path and os.path.isfile(path)
        if local and (path.lower().endswith(SHOWABLE) or HEIF):
            try:
                data, _size = shrink(path)
            except Exception as exc:  # noqa: BLE001 - kaputte Datei: über die Engine
                log(f"Foto {path}: {exc}", "warning")
        if data is None and path.startswith("/webdav-media/"):
            cached = webdav_cached(path, str(item.get("stamp") or "").split(":")[0])
            if cached:
                try:
                    data, _size = shrink(str(cached))
                except Exception:  # noqa: BLE001
                    data = None
        if data is None and key.startswith("d:"):
            raw = engine_image(key[2:].partition("|")[0], path)
            try:
                data, _size = shrink(raw)
            except Exception:  # noqa: BLE001
                data = raw
        if data is None:
            raise sources.SourceError("Foto nicht gefunden")
    PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(f".{threading.get_ident()}.tmp")
    temp.write_bytes(data)
    temp.replace(target)
    return target


_prepare_lock = threading.Lock()


def prefetch(count=2):
    """Die Abzüge der nächsten Reisen vorbereiten; alte Abzüge aufräumen."""
    with _prepare_lock:
        ids = ordered_ids()
        if not ids:
            return
        start = cursor_start(ids)
        by_id = {t["id"]: t for t in _trips["list"]}
        failed = 0
        for offset in range(min(count, len(ids))):
            trip = by_id.get(ids[(start + offset) % len(ids)])
            for photo in (trip or {}).get("photos", []):
                if _stop_requested.is_set():
                    return
                try:
                    prepare(photo["id"])
                except Exception as exc:  # noqa: BLE001
                    failed += 1
                    if failed <= 3:
                        log(f"Abzug für die Szene: {exc}", "warning")
        try:
            entries = sorted(os.scandir(PHOTO_DIR), key=lambda e: e.stat().st_mtime, reverse=True)
            for entry in entries[PHOTO_KEEP:]:
                os.unlink(entry.path)
        except OSError:
            pass


def photo_bytes(query):
    pid = re.sub(r"[^0-9a-f]", "", (query.get("p") or [""])[0])[:20]
    if not pid or pid not in _trips["photos"]:
        return None
    try:
        return prepare(pid).read_bytes()
    except Exception as exc:  # noqa: BLE001
        log(f"Abzug für die Szene: {exc}", "warning")
        return None


# --------------------------------------------------------------------------
# Der Arbeitsfaden
# --------------------------------------------------------------------------

def work_loop():
    while not _stop_requested.is_set():
        values = settings()
        try:
            due = now() - _index["at"] >= values["RefreshHours"] * 3600
            if due or _index["signature"] != index_signature(values):
                build_index("geplant" if due and _index["at"] else "Einstellungen")
            if _index["at"] and _trips["signature"] != trips_signature(values):
                build_trips()
                prefetch(2)
        except Exception as exc:  # noqa: BLE001 - der Faden darf nicht sterben
            log(f"Fehler: {exc!r}", "warning")
        _wake.wait(30)
        _wake.clear()


def reload_now():
    _work_stop.set()
    _index["at"] = 0.0
    _trips["signature"] = ""

    def later():
        time.sleep(1)
        _work_stop.clear()
        _wake.set()

    threading.Thread(target=later, daemon=True).start()
    return {"success": True, "message": tr("Die Fotos werden neu eingelesen.")}


# --------------------------------------------------------------------------
# Playlist für die Szene
# --------------------------------------------------------------------------

def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=PLAYLIST_NAMES.values(),
    name=lambda: PLAYLIST_NAMES.get(settings()["Language"], PLAYLIST_NAMES["en"]),
    description=lambda: tr("Deine Reisen als Scrapbook-Seiten, eine nach der anderen."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()


# --------------------------------------------------------------------------
# Was die Szene bekommt
# --------------------------------------------------------------------------

SCENE_SETTINGS = ("Language", "PageSeconds", "Paper", "ShowMap", "ShowWeather", "ShowNotes", "ShowCover",
                  "Animate", "Units", "HomeName")
SCENE_TRIP = ("id", "start", "end", "days", "nights", "count", "located", "km", "farKm", "bbox", "route",
              "dayPoints", "home", "places", "photos", "bestDay", "firstShot", "lastShot", "fiveStars", "rated",
              "wx", "autoTitle", "countries", "title", "note")


def totals(trip_list):
    countries = set()
    for trip in trip_list:
        countries.update(trip.get("countries") or [])
    years = sorted({t["start"][:4] for t in trip_list})
    return {"trips": len(trip_list), "days": sum(t["days"] for t in trip_list),
            "km": sum(t["km"] for t in trip_list), "countries": len(countries),
            "photos": sum(t["count"] for t in trip_list),
            "first": years[0] if years else "", "last": years[-1] if years else ""}


def scene_payload(query):
    values = settings()
    have = as_int((query.get("v") or ["-1"])[0], -1)
    ids = ordered_ids(values)
    payload = {
        "success": True,
        "ver": _trips["ver"],
        "settings": {k: values[k] for k in SCENE_SETTINGS},
        "busy": _index["busy"] or _trips["busy"] or not _index["at"],
        "sources": len(values["Sources"]),
        "order": ids,
        "start": cursor_start(ids) if ids else 0,
        "located": _index["located"],
        "indexed": len(_index["rows"]),
    }
    if have != _trips["ver"]:
        by_id = {t["id"]: t for t in visible_trips()}
        payload["trips"] = [{k: by_id[i].get(k) for k in SCENE_TRIP} for i in ids if i in by_id]
        payload["totals"] = totals(list(by_id.values()))
    return payload


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    status = {}
    for source in values["Sources"]:
        row = dict(_index["status"].get(source["id"]) or {})
        if _index["busy"] and not row:
            row = {"state": "wait"}
        row["kind"] = source["kind"]
        status[source["id"]] = row
    homes = []
    for home in _trips["homes"] or []:
        homes.append({"lat": home["lat"], "lon": home["lon"], "share": home.get("share"),
                      "from": home.get("from"), "to": home.get("to"), "manual": bool(home.get("manual")),
                      "name": place_name(home["lat"], home["lon"], values["Language"], fetch=False)})
    trip_rows = []
    for trip in sorted(_trips["list"], key=lambda t: t["start"], reverse=True):
        best = next((p for p in trip["photos"] if p.get("best")), trip["photos"][0] if trip["photos"] else None)
        trip_rows.append({"id": trip["id"], "start": trip["start"], "end": trip["end"], "days": trip["days"],
                          "km": trip["km"], "count": trip["count"], "autoTitle": trip.get("autoTitle") or "",
                          "title": trip.get("title") or "", "note": trip.get("note") or "",
                          "hidden": bool(trip.get("hidden")), "photo": best["id"] if best else "",
                          "countries": trip.get("countries") or [], "wx": len(trip.get("wx") or [])})
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "status": status,
        "busy": _index["busy"] or _trips["busy"],
        "progress": _index["progress"],
        "indexAt": _index["at"],
        "indexed": len(_index["rows"]),
        "located": _index["located"],
        "dfCount": _index.get("dfCount"),
        "undated": _index["undated"],
        "homes": homes,
        "trips": trip_rows,
        "totals": totals(visible_trips()),
        "enriched": _trips["enriched"],
        "weatherError": _trips["weatherError"],
        "heif": HEIF,
        "theme": {"id": theme_id()},
    }


def test_immich():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        info = immich.test()
    except sources.SourceError as exc:
        return {"success": True, "ok": False, "message": str(exc)}
    return {"success": True, "ok": True,
            "message": tr("Verbunden als {user} (Immich {version}).", user=info["user"] or "?",
                          version=info["version"] or "?")}


def list_albums():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, "albums": immich.albums()}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_immich(what):
    """Personen bzw. Tags für die Immich-Filter."""
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, what: getattr(immich_filters, what)(immich)}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_playlists():
    try:
        rows = [p for p in dynaframe.playlists() if p["name"] not in PLAYLIST_NAMES.values()]
        return {"success": True, "playlists": sorted(rows, key=lambda p: str(p["name"]).lower())}
    except EngineError as exc:
        return {"success": False, "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc)}


def search_place(query):
    name = re.sub(r"\s+", " ", (query.get("q") or [""])[0]).strip()[:80]
    if len(name) < 2:
        return {"success": True, "places": []}
    try:
        return {"success": True, "places": sky.search(name, settings()["Language"])}
    except weather.WeatherError as exc:
        return {"success": False, "error": tr("Die Ortssuche (Open-Meteo) antwortet nicht: {exc}", exc=exc)}


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}

# Einstellungen, nach denen die Fotos neu eingelesen werden müssen
SOURCE_SETTINGS = ("Albums", "Sources", "Folders", "ServerUrl", "ApiKey",
                   *immich_filters.SCHEMA, *dynaframe_filters.SCHEMA)


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(query), cors=True)
                return
            if path == "/api/shown":
                mark_shown(re.sub(r"[^0-9-]", "", (query.get("id") or [""])[0])[:10])
                self._json({"success": True}, cors=True)
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            if path == "/api/photo":
                found = photo_bytes(query)
                if found is None:
                    self._json({"success": False}, 404, cors=True)
                else:
                    self._send(found, "image/jpeg", cache="private, max-age=86400", cors=True)
                return
            if path == "/api/albums":
                self._json(list_albums())
                return
            if path in ("/api/people", "/api/tags"):
                self._json(list_immich(path.rsplit("/", 1)[1]))
                return
            if path == "/api/playlists":
                self._json(list_playlists())
                return
            if path == "/api/places":
                self._json(search_place(query))
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                for name in SECRETS:
                    # Ein leeres Feld heißt: das alte behalten. Löschen geht mit "-".
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)
                    elif name in body and str(body[name]).strip() == "-":
                        body[name] = ""
                changed = save_settings(body)
                if "MakePlaylist" in changed:
                    OWN.changed()
                if changed:
                    if any(n in changed for n in SOURCE_SETTINGS):
                        # Nichts Ausgefiltertes mehr zeigen, bis neu eingelesen ist
                        with _trips_lock:
                            _trips.update(ver=_trips["ver"] + 1, list=[], photos={}, signature="")
                        reload_now()
                    if "TripOrder" in changed:
                        with _trips_lock:
                            _trips["ver"] += 1
                    _wake.set()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/trip":
                self._json(save_edit(self._body()))
                return
            if path == "/api/refresh":
                self._json(reload_now())
                return
            if path == "/api/test":
                self._json(test_immich())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}" + ("" if HEIF else " (ohne HEIC-Unterstützung, HEIC über die Engine)"))

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: reload_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    adopt_immich()
    load_trips()
    try:
        os.nice(5)   # das Einlesen soll die Wiedergabe nicht stören
    except OSError:
        pass
    threading.Thread(target=work_loop, name=f"{PLUGIN_ID}-work", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _work_stop.set()
    _wake.set()
    try:
        exif_save()
        stars_save()
        sky.save()
    except Exception:
        pass
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
