"""Was läuft gerade? Music Assistant, Spotify und Jellyfin.

Jede Quelle hat now() und gibt None (nichts läuft) oder ein dict zurück:
    {source, state: playing|paused, title, artist, album, duration (s),
     position (s, zum Zeitpunkt at), at (epoch), cover (URL), coverHeaders,
     player, id (eindeutig pro Stück)}
Fehler kommen als SourceError(code, detail) mit code in
no-setup | unreachable | auth | format.

- Music Assistant: HTTP-API POST <server>/api mit Bearer-Token (wie Playlist
  Music), players/all + player_queues/all; Auswahl wie das Magic-Mirror-Modul.
- Spotify auf diesem Rahmen: go-librespot von Playlist Music (localhost,
  Port aus dessen config.yml), GET /status. Kein Konto nötig.
- Spotify-Konto: Web API /me/player/currently-playing mit eigener Client ID
  (PKCE, ohne Geheimnis). So sieht das Plugin auch, was auf dem Handy, dem
  Echo oder dem Rechner läuft.
- Jellyfin: /Sessions mit API-Schlüssel (wie Jellyfin Now Playing).
"""

import base64
import hashlib
import json
import os
import re
import secrets
import threading
import time
from pathlib import Path
from urllib.parse import parse_qs, quote, urlencode, urlparse

import requests

TIMEOUT = (4, 8)
TICKS = 10_000_000


class SourceError(Exception):
    def __init__(self, code, detail=""):
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code = code
        self.detail = str(detail or "")


def normalize_url(raw, default_port=None):
    value = str(raw or "").strip().rstrip("/")
    if not value:
        return ""
    if not re.match(r"^https?://", value, re.I):
        value = "http://" + value
    parts = urlparse(value)
    if default_port and parts.port is None and parts.scheme == "http" and not parts.path.strip("/"):
        value += f":{default_port}"
    return value[:300]


def read_json(path):
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _iso_epoch(text):
    """Jellyfin-Zeitstempel (UTC, 7 Nachkommastellen) in Sekunden."""
    if not text:
        return None
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?", str(text))
    if not m:
        return None
    import calendar
    whole = calendar.timegm(tuple(int(m.group(i)) for i in range(1, 7)) + (0, 0, 0))
    frac = m.group(7) or "0"
    return whole + int(frac[:6]) / (10 ** len(frac[:6]))


# --------------------------------------------------------------------------
# Music Assistant
# --------------------------------------------------------------------------

class MusicAssistant:
    name = "ma"

    def __init__(self, url, token, player="", user_agent="DynaFrame"):
        self.url = normalize_url(url, 8095)
        self.token = str(token or "").strip()
        self.player = str(player or "").strip()
        self.user_agent = user_agent
        self.players_seen = []
        self._schema = None

    def ok(self):
        return bool(self.url)

    def call(self, command, **args):
        if not self.url:
            raise SourceError("no-setup")
        headers = {"Content-Type": "application/json", "User-Agent": self.user_agent}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        body = {"message_id": str(int(time.time() * 1000)), "command": command, "args": args}
        try:
            answer = requests.post(self.url + "/api", data=json.dumps(body), headers=headers, timeout=TIMEOUT)
        except requests.RequestException as exc:
            raise SourceError("unreachable", exc) from exc
        if answer.status_code in (401, 403):
            raise SourceError("auth", f"HTTP {answer.status_code}")
        if answer.status_code >= 400:
            raise SourceError("format", f"HTTP {answer.status_code} {answer.text[:120]}")
        try:
            return answer.json() if answer.content else None
        except ValueError as exc:
            raise SourceError("format", "no JSON") from exc

    def schema(self):
        if self._schema is None:
            try:
                info = requests.get(self.url + "/info", timeout=TIMEOUT).json()
                self._schema = int(info.get("schema_version") or 0)
            except (requests.RequestException, ValueError, AttributeError):
                self._schema = 0
        return self._schema

    def test(self):
        players = self.call("players/all") or []
        names = sorted({str(p.get("display_name") or p.get("name") or "") for p in players if isinstance(p, dict)} - {""})
        self.players_seen = names[:40]
        return names

    def _image(self, item, media):
        for image in ((item or {}).get("image"), (media or {}).get("image"),
                      ((media or {}).get("album") or {}).get("image")):
            if isinstance(image, dict) and image.get("path"):
                break
        else:
            return ""
        if self.schema() >= 31 and image.get("proxy_id"):
            return f"{self.url}/imageproxy/{image['proxy_id']}?size=600"
        if image.get("remotely_accessible") and str(image.get("path", "")).startswith("http"):
            return image["path"]
        return (f"{self.url}/imageproxy?path={quote(quote(image['path'], safe=''), safe='')}"
                f"&provider={quote(str(image.get('provider') or ''), safe='')}&size=600")

    def now(self):
        players = [p for p in (self.call("players/all") or []) if isinstance(p, dict)]
        queues = [q for q in (self.call("player_queues/all") or []) if isinstance(q, dict)]
        self.players_seen = sorted({str(p.get("display_name") or p.get("name") or "") for p in players} - {""})[:40]
        want = self.player.lower()
        by_id = {q.get("queue_id"): q for q in queues}

        def queue_for(player):
            if not player:
                return None
            return by_id.get(player.get("active_source") or player.get("player_id")) or by_id.get(player.get("player_id"))

        candidates = []
        if want:
            pinned = next((p for p in players if str(p.get("player_id") or "").lower() == want
                           or str(p.get("display_name") or p.get("name") or "").lower() == want), None)
            queue = queue_for(pinned)
            candidates = [queue] if queue else []
        else:
            candidates = [q for q in queues if q.get("state") == "playing" and q.get("active") is not False]
            candidates += [q for q in queues if q.get("state") == "paused" and q.get("current_item")]
        queue = next((q for q in candidates if q and q.get("state") in ("playing", "paused") and q.get("current_item")),
                     None)
        if not queue:
            return None
        item = queue.get("current_item") or {}
        media = item.get("media_item") or {}
        stream = (item.get("streamdetails") or {})
        radio = media.get("media_type") == "radio" or stream.get("media_type") == "radio"
        title = media.get("name") or ""
        artist = ", ".join(a.get("name") for a in media.get("artists") or [] if isinstance(a, dict) and a.get("name"))
        album = ((media.get("album") or {}).get("name")) or ""
        if (radio or not title) and stream.get("stream_title"):
            text = stream["stream_title"]
            if " - " in text:
                first, rest = text.split(" - ", 1)
                artist, title = first.strip(), rest.strip()
            else:
                title = text
        if not title:
            title = item.get("name") or ""
        player = next((p for p in players if p.get("player_id") == queue.get("queue_id")), {})
        playing = queue.get("state") == "playing"
        elapsed = float(queue.get("elapsed_time") or 0)
        at = float(queue.get("elapsed_time_last_updated") or time.time())
        if at > time.time() + 5 or at < time.time() - 3600:
            at = time.time()   # Uhr des Servers unbrauchbar
        return {"source": self.name, "state": "playing" if playing else "paused",
                "title": title, "artist": artist, "album": "" if radio else album, "radio": bool(radio),
                "duration": float(item.get("duration") or media.get("duration") or 0),
                "position": elapsed, "at": at, "cover": self._image(item, media), "coverHeaders": {},
                "player": player.get("display_name") or player.get("name") or queue.get("display_name") or "",
                "id": f"ma:{queue.get('queue_id')}:{item.get('queue_item_id') or media.get('uri') or title}"}


# --------------------------------------------------------------------------
# Jellyfin
# --------------------------------------------------------------------------

def jellyfin_from_other_plugins(plugins_dir):
    """Adresse/Schlüssel aus Jellyfin Now Playing oder Playlist Music, falls da."""
    plugins_dir = Path(plugins_dir)
    a = read_json(plugins_dir / "JellyfinNowPlaying" / "data" / "settings.json")
    if a.get("ServerUrl") and a.get("ApiKey"):
        return {"url": a.get("ServerUrl"), "key": a.get("ApiKey"), "user": a.get("UserName") or "",
                "from": "Jellyfin Now Playing"}
    b = read_json(plugins_dir / "PlaylistMusic" / "data" / "settings.json")
    if b.get("JellyfinUrl") and b.get("JellyfinKey"):
        return {"url": b.get("JellyfinUrl"), "key": b.get("JellyfinKey"), "user": b.get("JellyfinUser") or "",
                "from": "Playlist Music"}
    return {}


def ma_from_other_plugins(plugins_dir):
    b = read_json(Path(plugins_dir) / "PlaylistMusic" / "data" / "settings.json")
    if b.get("MaUrl"):
        return {"url": b.get("MaUrl"), "token": b.get("MaToken") or "", "from": "Playlist Music"}
    return {}


class Jellyfin:
    name = "jellyfin"

    def __init__(self, url, key, user=""):
        self.url = normalize_url(url, 8096)
        self.key = str(key or "").strip()
        self.user = str(user or "").strip().lower()
        self.users_seen = []

    def ok(self):
        return bool(self.url and self.key)

    def headers(self):
        return {"Authorization": f'MediaBrowser Client="DynaFrame Sing-along", Device="DynaFrame", '
                                 f'DeviceId="dynaframe-sing-along", Version="1.0.0", Token="{self.key}"',
                "X-Emby-Token": self.key, "Accept": "application/json"}

    def get(self, path, params=None):
        if not self.ok():
            raise SourceError("no-setup")
        try:
            answer = requests.get(self.url + path, params=params, headers=self.headers(), timeout=TIMEOUT)
        except requests.RequestException as exc:
            raise SourceError("unreachable", exc) from exc
        if answer.status_code in (401, 403):
            raise SourceError("auth", f"HTTP {answer.status_code}")
        if answer.status_code >= 400:
            raise SourceError("format", f"HTTP {answer.status_code}")
        try:
            return answer.json()
        except ValueError as exc:
            raise SourceError("format", "no JSON") from exc

    def test(self):
        info = self.get("/System/Info")
        return (info or {}).get("ServerName") or "Jellyfin", (info or {}).get("Version") or ""

    def now(self):
        sessions = self.get("/Sessions", {"activeWithinSeconds": 960})
        if not isinstance(sessions, list):
            raise SourceError("format", "no list")
        self.users_seen = sorted({str(s.get("UserName") or "") for s in sessions} - {""})[:30]
        found = []
        for s in sessions:
            item = s.get("NowPlayingItem") or {}
            if not item or (self.user and str(s.get("UserName") or "").lower() != self.user):
                continue
            if item.get("Type") != "Audio" and item.get("MediaType") != "Audio":
                continue
            found.append(s)
        if not found:
            return None
        found.sort(key=lambda s: (not (s.get("PlayState") or {}).get("IsPaused"), str(s.get("LastActivityDate") or "")),
                   reverse=True)
        session = found[0]
        item = session["NowPlayingItem"]
        play = session.get("PlayState") or {}
        artists = item.get("Artists") or [a.get("Name") for a in item.get("ArtistItems") or [] if a.get("Name")]
        artist = ", ".join(a for a in artists if a) or item.get("AlbumArtist") or ""
        cover = ""
        for item_id, tag in ((item.get("AlbumId"), item.get("AlbumPrimaryImageTag")),
                             (item.get("Id"), (item.get("ImageTags") or {}).get("Primary"))):
            if item_id and tag:
                cover = f"{self.url}/Items/{item_id}/Images/Primary?{urlencode({'tag': tag, 'maxHeight': 600, 'quality': 90})}"
                break
        checkin = _iso_epoch(session.get("LastPlaybackCheckIn"))
        at = checkin if checkin and abs(time.time() - checkin) < 120 else None
        return {"source": self.name, "state": "paused" if play.get("IsPaused") else "playing",
                "title": item.get("Name") or "", "artist": artist, "album": item.get("Album") or "",
                "duration": (item.get("RunTimeTicks") or 0) / TICKS,
                "position": (play.get("PositionTicks") or 0) / TICKS, "at": at,
                "cover": cover, "coverHeaders": {},
                "player": session.get("DeviceName") or session.get("Client") or "",
                "id": f"jellyfin:{session.get('Id')}:{item.get('Id')}"}


# --------------------------------------------------------------------------
# Spotify auf diesem Rahmen (go-librespot von Playlist Music)
# --------------------------------------------------------------------------

class SpotifyHere:
    name = "spotifyhere"

    def __init__(self, plugins_dir):
        self.plugins_dir = Path(plugins_dir)

    def installed(self):
        return (self.plugins_dir / "PlaylistMusic").is_dir()

    def port(self):
        config = read_json(self.plugins_dir / "PlaylistMusic" / "data" / "spotify" / "config" / "config.yml")
        try:
            return int((config.get("server") or {}).get("port") or 36783)
        except (TypeError, ValueError):
            return 36783

    def status(self):
        try:
            answer = requests.get(f"http://127.0.0.1:{self.port()}/status", timeout=(2, 4))
        except requests.RequestException as exc:
            raise SourceError("unreachable", exc) from exc
        if answer.status_code == 204 or not answer.content:
            return {}
        if answer.status_code >= 400:
            raise SourceError("format", f"HTTP {answer.status_code}")
        try:
            return answer.json()
        except ValueError as exc:
            raise SourceError("format", "no JSON") from exc

    def now(self):
        status = self.status()
        track = status.get("track") or {}
        if not track or status.get("stopped") or not track.get("name"):
            return None
        return {"source": self.name, "state": "paused" if status.get("paused") else "playing",
                "title": track.get("name") or "", "artist": ", ".join(track.get("artist_names") or []),
                "album": track.get("album_name") or "", "duration": (track.get("duration") or 0) / 1000,
                "position": (track.get("position") or 0) / 1000, "at": time.time(),
                "cover": track.get("album_cover_url") or "", "coverHeaders": {},
                "player": status.get("device_name") or "DynaFrame",
                "id": f"spotify:{track.get('uri') or track.get('name')}"}


# --------------------------------------------------------------------------
# Spotify-Konto (Web API, PKCE)
# --------------------------------------------------------------------------

SPOTIFY_AUTH = "https://accounts.spotify.com/authorize"
SPOTIFY_TOKEN = "https://accounts.spotify.com/api/token"
SPOTIFY_API = "https://api.spotify.com/v1"
SPOTIFY_REDIRECT = "http://127.0.0.1:8888/callback"
SPOTIFY_SCOPES = "user-read-currently-playing user-read-playback-state"


class SpotifyAccount:
    """Tokens liegen in data/spotify_token.json (nur für den Plugin-Benutzer lesbar)."""
    name = "spotify"

    def __init__(self, token_file, client_id):
        self.token_file = Path(token_file)
        self.client_id = str(client_id or "").strip()
        self._lock = threading.Lock()
        self.retry_after = 0.0

    def ok(self):
        return bool(self.client_id and self.load().get("refresh_token"))

    def load(self):
        return read_json(self.token_file)

    def save(self, data):
        self.token_file.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.token_file.with_suffix(".tmp")
        tmp.write_text(json.dumps(data), encoding="utf-8")
        try:
            os.chmod(tmp, 0o600)
        except OSError:
            pass
        tmp.replace(self.token_file)

    def forget(self):
        self.token_file.unlink(missing_ok=True)

    # ---- Anmelden ----------------------------------------------------------

    def start_login(self):
        if not self.client_id:
            raise SourceError("no-setup")
        verifier = base64.urlsafe_b64encode(secrets.token_bytes(48)).decode().rstrip("=")
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")
        state = secrets.token_urlsafe(12)
        data = self.load()
        data.update(verifier=verifier, state=state, clientId=self.client_id)
        self.save(data)
        return SPOTIFY_AUTH + "?" + urlencode({
            "client_id": self.client_id, "response_type": "code", "redirect_uri": SPOTIFY_REDIRECT,
            "code_challenge_method": "S256", "code_challenge": challenge, "scope": SPOTIFY_SCOPES, "state": state})

    def finish_login(self, pasted):
        """pasted = die ganze Adresse aus der Adresszeile nach der Anmeldung (oder nur der Code)."""
        text = str(pasted or "").strip()
        data = self.load()
        if not data.get("verifier"):
            raise SourceError("format", "start")
        code = text
        if "code=" in text or "error=" in text:
            query = parse_qs(urlparse(text).query or text.split("?", 1)[-1])
            if query.get("error"):
                raise SourceError("auth", query["error"][0])
            code = (query.get("code") or [""])[0]
            state = (query.get("state") or [""])[0]
            if state and data.get("state") and state != data["state"]:
                raise SourceError("format", "state")
        if not re.match(r"^[\w-]{20,}$", code or ""):
            raise SourceError("format", "code")
        try:
            answer = requests.post(SPOTIFY_TOKEN, data={
                "grant_type": "authorization_code", "code": code, "redirect_uri": SPOTIFY_REDIRECT,
                "client_id": self.client_id, "code_verifier": data["verifier"]}, timeout=TIMEOUT)
        except requests.RequestException as exc:
            raise SourceError("unreachable", exc) from exc
        if answer.status_code >= 400:
            raise SourceError("auth", answer.text[:200])
        token = answer.json()
        self.save({"clientId": self.client_id, "access_token": token.get("access_token"),
                   "refresh_token": token.get("refresh_token"),
                   "expires": time.time() + int(token.get("expires_in") or 3600) - 60})
        return True

    def access_token(self):
        with self._lock:
            data = self.load()
            if not data.get("refresh_token") or data.get("clientId") != self.client_id:
                raise SourceError("no-setup")
            if data.get("access_token") and time.time() < float(data.get("expires") or 0):
                return data["access_token"]
            try:
                answer = requests.post(SPOTIFY_TOKEN, data={"grant_type": "refresh_token",
                                                            "refresh_token": data["refresh_token"],
                                                            "client_id": self.client_id}, timeout=TIMEOUT)
            except requests.RequestException as exc:
                raise SourceError("unreachable", exc) from exc
            if answer.status_code == 400:
                self.save({"clientId": self.client_id})
                raise SourceError("auth", answer.text[:200])
            if answer.status_code >= 400:
                raise SourceError("format", f"HTTP {answer.status_code}")
            token = answer.json()
            data.update(access_token=token.get("access_token"),
                        refresh_token=token.get("refresh_token") or data["refresh_token"],
                        expires=time.time() + int(token.get("expires_in") or 3600) - 60)
            self.save(data)
            return data["access_token"]

    def get(self, path):
        if time.time() < self.retry_after:
            raise SourceError("unreachable", "rate limited")
        token = self.access_token()
        try:
            answer = requests.get(SPOTIFY_API + path, headers={"Authorization": f"Bearer {token}"}, timeout=TIMEOUT)
        except requests.RequestException as exc:
            raise SourceError("unreachable", exc) from exc
        if answer.status_code == 429:
            self.retry_after = time.time() + int(answer.headers.get("Retry-After") or 30)
            raise SourceError("unreachable", "rate limited")
        if answer.status_code == 401:
            data = self.load()
            data["expires"] = 0
            self.save(data)
            raise SourceError("auth", "HTTP 401")
        if answer.status_code == 403:
            raise SourceError("auth", "HTTP 403 " + answer.text[:160])
        if answer.status_code == 204 or not answer.content:
            return None
        if answer.status_code >= 400:
            raise SourceError("format", f"HTTP {answer.status_code}")
        return answer.json()

    def test(self):
        me = self.get("/me") or {}
        return me.get("display_name") or me.get("id") or "Spotify"

    def now(self):
        started = time.time()
        data = self.get("/me/player/currently-playing?additional_types=track")
        if not data or not isinstance(data, dict):
            return None
        item = data.get("item") or {}
        if not item or item.get("type") not in (None, "track"):
            return None
        images = (item.get("album") or {}).get("images") or []
        images = sorted((i for i in images if i.get("url")), key=lambda i: abs((i.get("width") or 640) - 600))
        device = (data.get("device") or {}).get("name") or ""
        return {"source": self.name, "state": "playing" if data.get("is_playing") else "paused",
                "title": item.get("name") or "",
                "artist": ", ".join(a.get("name") for a in item.get("artists") or [] if a.get("name")),
                "album": (item.get("album") or {}).get("name") or "",
                "duration": (item.get("duration_ms") or 0) / 1000,
                "position": (data.get("progress_ms") or 0) / 1000, "at": (started + time.time()) / 2,
                "cover": images[0]["url"] if images else "", "coverHeaders": {}, "player": device,
                "id": f"spotify:{item.get('uri') or item.get('id')}"}
