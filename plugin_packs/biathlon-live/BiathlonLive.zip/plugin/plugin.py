#!/usr/bin/env python3
"""Biathlon Live - der Plugin-Teil des Biathlon-Live-Pakets.

Ein Nachbau des MagicMirror-Moduls MMM-Biathlon von 2hdlockness
(https://github.com/2hdlockness/MMM-Biathlon, MIT-Lizenz) für DynaFrame:
dieselbe Quelle (biathlonresults.com, das IBU Datacenter), dieselben Serien
(EventClassificationId), Ergebnisse mit Platz, Nation, Zeit und Schießen,
dazu die nächste Station.

Die Szene "biathlon-live" zeichnet Ergebnisse, Zwischenstand, Programm und
Gesamtwertung. Dieses Plugin macht, was eine Szene nicht kann:

- Es liest Stationen, Rennen und Ergebnisse (biathlon.py) in seinem eigenen
  Takt: alle 30 Sekunden, solange ein Rennen läuft, sonst seltener.
- Es holt die Szene alle X Minuten für Y Sekunden über die laufende
  Playlist (Display-Takeover), wahlweise nur an Renntagen oder während eines
  Rennens, und auf Wunsch beim Start oder beim Ergebnis eines Rennens.
- Show, Cancel und Toggle machen dasselbe von Hand oder aus einer
  Automation.
- Alle Einstellungen liegen auf einer Seite (Plugins > Biathlon Live öffnen).

Die Szene erreicht die Seite dieses Plugins über den Proxy der Weboberfläche
auf :8003 oder direkt auf Port 80 (der Proxy der Engine lehnt lokale Adressen
ab). Antwortet das Plugin nicht, liest die Szene den Weltcup selbst.
"""

import json
import os
import re
import sys
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import biathlon  # noqa: E402
import nations  # noqa: E402
import texts  # noqa: E402

try:
    # Umgeht einen Dynaframe-Fehler, der einen Quick Mix nach einem Takeover
    # gestoppt lassen kann (siehe dort). Ohne die Datei läuft alles weiter.
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None

plugin = create_plugin()

PLUGIN_ID = "BiathlonLive"
DISPLAY_NAME = "Biathlon Live"
SCENE_ID = "biathlon-live"       # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"   # Einstellungen und Zustand; bleibt bei Updates
CACHE_DIR = PLUGIN_DIR / "cache"  # letzte Ergebnisse; darf gelöscht werden

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30
SERVICE_STATUS = f"{PLUGIN_ID}.Status"

EVENT_RACE_STARTED = "biathlon_rennen_gestartet"
EVENT_RESULT = "biathlon_ergebnis"
EVENT_STARTED = "biathlon_anzeige_gestartet"
EVENT_ENDED = "biathlon_anzeige_beendet"


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        pass
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def ensure_dirs():
    for folder in (DATA_DIR, CACHE_DIR):
        folder.mkdir(parents=True, exist_ok=True)


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    ensure_dirs()
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=1, ensure_ascii=False)
    temp.replace(path)


def local_text(epoch):
    if not epoch:
        return ""
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Einstellungen (alle auf der Plugin-Seite; das Manifest deklariert keine)
# --------------------------------------------------------------------------

CATEGORY_GROUPS = {"women": {"SW", "JW", "YW"}, "men": {"SM", "JM", "YM"}, "mixed": {"MX", "JX", "YX"}}

SETTINGS = {
    # Wie in MMM-Biathlon: welche Serien (EventClassificationId).
    "Series":         {"kind": "series", "default": list(biathlon.DEFAULT_SERIES)},
    "Categories":     {"kind": "categories", "default": ["women", "men", "mixed"]},
    "MaxEntries":     {"kind": "number", "default": 10, "min": 3, "max": 30},   # maximumEntries
    "RaceCount":      {"kind": "number", "default": 4, "min": 1, "max": 12},
    "ShowTime":       {"kind": "bool", "default": True},                        # showtime
    "ShowShooting":   {"kind": "bool", "default": True},                        # showshoot
    "ShowSchedule":   {"kind": "bool", "default": True},                        # showNextEvent
    "ShowStandings":  {"kind": "bool", "default": True},
    "PageSeconds":    {"kind": "number", "default": 20, "min": 5, "max": 300},  # transitionInterval
    "Nation":         {"kind": "nation", "default": ""},
    # Wann die Szene von selbst über die Playlist geholt wird.
    "AutoMode":       {"kind": "choice", "default": "raceday",
                       "options": ["off", "always", "raceday", "live"]},
    "EveryMinutes":   {"kind": "number", "default": 15, "min": 2, "max": 720},
    "ShowForSeconds": {"kind": "number", "default": 60, "min": 10, "max": 3600},
    "ActiveFrom":     {"kind": "number", "default": 8, "min": 0, "max": 23},
    "ActiveTo":       {"kind": "number", "default": 23, "min": 1, "max": 24},
    # Beim Start und/oder beim Ergebnis eines Rennens sofort zeigen.
    "RaceAlert":      {"kind": "choice", "default": "off", "options": ["off", "start", "result", "both"]},
    "AlertSeconds":   {"kind": "number", "default": 60, "min": 10, "max": 600},
    "MakePlaylist":   {"kind": "bool", "default": False},
    "Language":       {"kind": "choice", "default": "de", "options": list(texts.LANGUAGES)},
}

SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return list(default) if isinstance(default, list) else default
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "number":
        return max(spec["min"], min(spec["max"], as_int(raw, default)))
    if kind == "choice":
        value = str(raw).strip().lower()
        return value if value in spec["options"] else default
    if kind in ("series", "categories"):
        allowed = biathlon.SERIES if kind == "series" else CATEGORY_GROUPS
        items = raw if isinstance(raw, list) else str(raw).split(",")
        chosen = []
        for item in items:
            key = str(item).strip()
            key = key.upper() if kind == "series" else key.lower()
            if key in allowed and key not in chosen:
                chosen.append(key)
        # Feste Reihenfolge, damit die Seiten immer gleich laufen.
        return [k for k in allowed if k in chosen]
    if kind == "nation":
        value = str(raw).strip().upper()
        return value if value in nations.NATIONS else ""
    return str(raw)[:200]


def settings():
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
    return {name: coerce(name, stored.get(name)) for name in SETTINGS}


def tr(template, **values):
    """Ein Text in der eingestellten Sprache (siehe texts.py)."""
    return texts.t(settings()["Language"], template, **values)


def save_settings(changes):
    changed = []
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            value = coerce(name, raw)
            if stored.get(name) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, stored)
    return changed


_state_lock = threading.Lock()


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**fields):
    with _state_lock:
        state = read_json(STATE_FILE, {}) or {}
        if all(k in state and state[k] == v for k, v in fields.items()):
            return state  # nichts Neues, also kein Schreiben auf die SD-Karte
        state.update(fields)
        write_json(STATE_FILE, state)
    return state


# --------------------------------------------------------------------------
# Die Engine auf diesem Rahmen
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "note": ""}


def find_scene():
    """Die installierte Szene. Ihre numerische id braucht ein Playlist-Eintrag."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else
                      tr("Die Szene Biathlon Live ist auf der Plugins-Seite ausgeschaltet."))
        return row
    _scene.update(dbId=None, note=tr("Die Szene Biathlon Live ist auf diesem Rahmen nicht installiert. "
                                     "Installiere das Biathlon-Live-Paket noch einmal."))
    return None


# --------------------------------------------------------------------------
# Daten: Stationen, Rennen, Ergebnisse, Gesamtwertung
# --------------------------------------------------------------------------

_data_lock = threading.Lock()
_events = {}    # Saison -> {"events": [...], "at": t, "error": ""}
_comps = {}     # EventId -> {"races": [...], "at": t, "error": ""}
_results = {}   # RaceId -> {"result": {...}, "at": t, "error": "", "state": "..."}
_cups = {}      # "BTSWRLCP:SW" -> {"rows": [...], "at": t, "error": ""}
_cup_ids = {}   # "Saison:Serie" -> {"SW": id, "SM": id} oder {}
_seen = {}      # RaceId -> zuletzt gesehener Zustand, um Start und Ergebnis zu erkennen
_alerts = []    # [{"race": id, "kind": "start"|"result", "at": t}]
_version = {"n": 0}
_errors = {"last": ""}

EVENTS_SECONDS = 6 * 3600
CUP_SECONDS = 6 * 3600


def bump():
    with _data_lock:
        _version["n"] += 1


def season_events(season, force=False):
    """Die Stationen einer Saison, höchstens alle sechs Stunden gelesen."""
    with _data_lock:
        row = _events.get(season)
    age = now() - (row or {}).get("at", 0)
    due = force or row is None or age >= EVENTS_SECONDS or ((row or {}).get("error") and age >= 300)
    if not due:
        return row["events"]
    try:
        events = biathlon.fetch_events(season)
        row = {"events": events, "at": now(), "error": ""}
    except biathlon.SourceError as exc:
        plugin.log(f"Stationen {season}: {exc}", level="warning")
        row = {"events": (row or {}).get("events") or [], "at": now(), "error": str(exc)}
    with _data_lock:
        _events[season] = row
    bump()
    return row["events"]


def pick_events(series_list, force=False):
    """Je Serie die laufende oder letzte Station (mit Rennen) und die nächste.

    Gibt [{"series", "current": event|None, "next": event|None}] zurück. Gibt
    es in dieser Saison noch keine gelaufene Station (Sommer, Herbst), zählt
    die letzte der Vorsaison, damit die Szene nicht leer ist."""
    t = now()
    season = biathlon.season_id()
    events = season_events(season, force)
    older = None
    out = []
    for series in series_list:
        mine = [e for e in events if e["series"] == series]
        started = [e for e in mine if e["start"] <= t]
        upcoming = [e for e in mine if e["start"] > t]
        current = started[-1] if started else None
        if current is None:
            if older is None:
                older = season_events(biathlon.previous_season(season), force)
            past = [e for e in older if e["series"] == series and e["start"] <= t]
            current = past[-1] if past else None
        out.append({"series": series, "current": current, "next": upcoming[0] if upcoming else None})
    return out


def race_day(races, t=None):
    t = t or now()
    today = datetime.fromtimestamp(t).date()
    return any(r["start"] and datetime.fromtimestamp(r["start"]).date() == today for r in races)


def comps_due(row, event, t):
    age = t - (row or {}).get("at", 0)
    if row is None:
        return True
    if row.get("error"):
        return age >= 120
    if event["start"] - 86400 <= t <= event["end"]:
        # Während der Station: Programmänderungen kommen kurzfristig.
        return age >= (300 if race_day(row["races"], t) else 1800)
    return age >= 6 * 3600


def event_races(event, force=False):
    t = now()
    with _data_lock:
        row = _comps.get(event["id"])
    if force or comps_due(row, event, t):
        try:
            races = biathlon.fetch_competitions(event["id"])
            row = {"races": races, "at": t, "error": ""}
        except biathlon.SourceError as exc:
            plugin.log(f"Rennen {event['place']}: {exc}", level="warning")
            row = {"races": (row or {}).get("races") or [], "at": t, "error": str(exc)}
        with _data_lock:
            _comps[event["id"]] = row
        bump()
    return row["races"]


def results_due(race, row, t):
    """Wie oft ein Ergebnis gelesen wird: alle 30 s im Rennen, danach noch
    einige Male (Korrekturen, Proteste), ein altes Ergebnis nur einmal."""
    if not race["start"] or race["start"] > t + 300:
        return False
    if row is None:
        return True
    age = t - row.get("at", 0)
    if row.get("error"):
        return age >= 90
    state = row.get("state")
    if state in ("live", "pre"):
        return age >= 30
    if t - race["start"] < 6 * 3600:
        return age >= 600
    return False


def read_results(race, force=False):
    t = now()
    with _data_lock:
        row = _results.get(race["id"])
    if force or results_due(race, row, t):
        try:
            result = biathlon.fetch_results(race["id"], relay=race["relay"])
            row = {"result": result, "at": t, "error": ""}
        except biathlon.SourceError as exc:
            plugin.log(f"Ergebnis {race['id']}: {exc}", level="warning")
            row = dict(row or {"result": None}, at=t, error=str(exc))
        row["state"] = biathlon.race_state(race, row.get("result"), t)
        with _data_lock:
            _results[race["id"]] = row
        bump()
    elif row is not None:
        # Der Zustand hängt auch an der Uhr (ein Rennen beginnt).
        row["state"] = biathlon.race_state(race, row.get("result"), t)
    return row


def wanted_category(race, values):
    return any(race["category"] in CATEGORY_GROUPS[g] for g in values["Categories"])


def refresh_cups(values, picks, force=False):
    if not values["ShowStandings"]:
        return
    season = biathlon.season_id()
    t = now()
    for pick in picks:
        series = pick["series"]
        if not biathlon.SERIES[series]["cup"]:
            continue
        # Die Wertung der Saison, aus der die gezeigte Station stammt.
        cup_season = pick["current"]["id"][2:6] if pick["current"] else season
        key = f"{cup_season}:{series}"
        if key not in _cup_ids or (force and not _cup_ids[key]):
            try:
                _cup_ids[key] = biathlon.find_cups(cup_season, series)
            except biathlon.SourceError as exc:
                plugin.log(f"Gesamtwertungen {series}: {exc}", level="warning")
                continue
        for gender, cup_id in _cup_ids[key].items():
            ckey = f"{series}:{gender}"
            with _data_lock:
                row = _cups.get(ckey)
            due = force or row is None or row.get("cup") != cup_id or \
                t - row.get("at", 0) >= (300 if row.get("error") else row.get("ttl", CUP_SECONDS))
            if not due:
                continue
            try:
                rows = biathlon.fetch_cup(cup_id)
                row = {"rows": rows, "at": t, "error": "", "cup": cup_id, "ttl": CUP_SECONDS}
            except biathlon.SourceError as exc:
                row = dict(row or {"rows": []}, at=t, error=str(exc), cup=cup_id)
            with _data_lock:
                _cups[ckey] = row
            bump()


def note_state(race, state):
    """Start und Ergebnis eines Rennens erkennen. Beim ersten Blick (nach
    einem Neustart) wird nichts gemeldet."""
    before = _seen.get(race["id"])
    _seen[race["id"]] = state
    if before is None or before == state:
        return
    if state == "live" and before == "pre":
        announce_start(race)
        with _data_lock:
            _alerts.append({"race": race["id"], "kind": "start", "at": now()})
    elif state == "post" and before in ("pre", "live"):
        announce_result(race)
        with _data_lock:
            _alerts.append({"race": race["id"], "kind": "result", "at": now()})
        # Die Gesamtwertung ändert sich mit diesem Ergebnis.
        with _data_lock:
            for row in _cups.values():
                row["ttl"] = 1800


_races_index = {}   # RaceId -> race (der zuletzt gelesenen Stationen)
_picks = {"list": []}


def refresh_data(force=False):
    values = settings()
    picks = pick_events(values["Series"], force)
    index = {}
    for pick in picks:
        for key in ("current", "next"):
            event = pick[key]
            if not event:
                continue
            for race in event_races(event, force):
                index[race["id"]] = dict(race, series=pick["series"], place=event["place"], nat=event["nat"])
    current = {p["current"]["id"] for p in picks if p["current"]}
    for race in index.values():
        if race["event"] not in current or not wanted_category(race, values):
            continue
        row = read_results(race, force)
        if row is not None:
            note_state(race, row["state"])
        elif race["start"] > now():
            note_state(race, "pre")  # damit der Start erkannt wird
    with _data_lock:
        _races_index.clear()
        _races_index.update(index)
        _picks["list"] = picks
        # Alte Ergebnisse vergessen (andere Station).
        for race_id in [k for k in _results if k not in index]:
            del _results[race_id]
    refresh_cups(values, picks, force)
    save_cache()


CACHE_FILE = CACHE_DIR / "results.json"


def save_cache():
    with _data_lock:
        payload = {"events": _events, "comps": _comps, "results": _results, "cups": _cups, "version": _version["n"]}
    if payload["version"] == _cache_saved["version"]:
        return
    try:
        write_json(CACHE_FILE, payload)
        _cache_saved["version"] = payload["version"]
    except OSError as exc:
        plugin.log(f"Konnte die Ergebnisse nicht zwischenspeichern: {exc}", level="warning")


_cache_saved = {"version": -1}


def load_cache():
    """Der letzte Stand, damit die Szene nach einem Neustart sofort etwas
    zeigt. Alles gilt als veraltet und wird beim ersten Lesen ersetzt."""
    stored = read_json(CACHE_FILE, {}) or {}
    with _data_lock:
        for target, name in ((_events, "events"), (_comps, "comps"), (_results, "results"), (_cups, "cups")):
            for key, row in (stored.get(name) or {}).items():
                if isinstance(row, dict):
                    row["at"] = 0
                    target[key] = row


def emit(event, **data):
    try:
        plugin.emit_event(event, {key: str(value) for key, value in data.items()})
    except Exception as exc:  # pragma: no cover
        plugin.log(f"Konnte das Ereignis {event} nicht senden: {exc}", level="warning")


def race_title(race, lang=None):
    return biathlon.race_name(race, lang or settings()["Language"])


def announce_start(race):
    plugin.log(f"Rennen gestartet: {race['raw']} ({race['place']})")
    emit(EVENT_RACE_STARTED, rennen=race_title(race), serie=biathlon.series_name(race["series"], settings()["Language"]),
         ort=race["place"])


def podium_name(row, lang):
    if not row:
        return ""
    return nations.name(row["nat"], lang, row["name"]) if row["team"] else row["name"]


def announce_result(race):
    lang = settings()["Language"]
    with _data_lock:
        result = (_results.get(race["id"]) or {}).get("result") or {}
    rows = [r for r in result.get("rows") or [] if r["rank"] is not None]
    top = rows[:3] + [None] * (3 - len(rows[:3]))
    nation = settings()["Nation"]
    best = next((r for r in rows if r["nat"] == nation), None) if nation else None
    plugin.log(f"Ergebnis {race['raw']}: " + ", ".join(f"{r['rank']}. {r['name']} ({r['nat']})" for r in rows[:3]))
    emit(EVENT_RESULT, rennen=race_title(race), ort=race["place"],
         sieger=podium_name(top[0], lang), nation=(top[0] or {}).get("nat", ""),
         zweiter=podium_name(top[1], lang), dritter=podium_name(top[2], lang),
         bester_der_nation=f"{best['rank']}. {podium_name(best, lang)}" if best else "")


# ---- Was die Szene bekommt ------------------------------------------------

def race_rows(rows, values):
    """Die ersten N, dazu der oder die Beste der eigenen Nation, wenn sie
    nicht dabei ist."""
    ranked = [r for r in rows if r["rank"] is not None]
    top = ranked[:values["MaxEntries"]]
    extra = None
    nation = values["Nation"]
    if nation and not any(r["nat"] == nation for r in top):
        extra = next((r for r in ranked[values["MaxEntries"]:] if r["nat"] == nation), None)
    return top, extra


def nation_view(code, lang):
    return {"code": code, "name": nations.name(code, lang)} if code else None


def race_page(race, row, values):
    lang = values["Language"]
    result = (row or {}).get("result") or {}
    top, extra = race_rows(result.get("rows") or [], values)

    def view(r):
        out = dict(r)
        if r["team"]:
            out["name"] = out["short"] = nations.name(r["nat"], lang, r["name"])
        out["mine"] = bool(values["Nation"] and r["nat"] == values["Nation"])
        return out

    return {"kind": "race", "id": race["id"], "series": race["series"],
            "seriesName": biathlon.series_name(race["series"], lang),
            "color": biathlon.SERIES[race["series"]]["color"],
            "place": race["place"], "placeNat": race["nat"],
            "name": race_title(race, lang), "start": race["start"], "relay": race["relay"],
            "state": (row or {}).get("state") or "pre",
            "rows": [view(r) for r in top], "extra": view(extra) if extra else None,
            "finished": result.get("ranked", 0), "open": result.get("open", 0),
            "updatedAt": (row or {}).get("at") or 0, "error": (row or {}).get("error") or ""}


def upcoming(values, picks, limit=10):
    """Die nächsten Rennen der gewählten Serien, und je Serie die nächste
    Station (das "Next event" von MMM-Biathlon)."""
    t = now()
    lang = values["Language"]
    with _data_lock:
        races = list(_races_index.values())
    items = sorted((r for r in races if r["start"] > t - 600 and wanted_category(r, values)
                    and (_results.get(r["id"]) or {}).get("state", "pre") == "pre"), key=lambda r: r["start"])
    stations = []
    for pick in picks:
        event = pick["next"]
        if event:
            stations.append({"series": pick["series"], "seriesName": biathlon.series_name(pick["series"], lang),
                             "color": biathlon.SERIES[pick["series"]]["color"], "place": event["place"],
                             "nat": event["nat"], "natName": nations.name(event["nat"], lang),
                             "start": event["start"], "end": event["end"] - 86399})
    stations.sort(key=lambda e: e["start"])
    return [{"id": r["id"], "start": r["start"], "name": race_title(r, lang), "place": r["place"], "nat": r["nat"],
             "series": r["series"], "color": biathlon.SERIES[r["series"]]["color"]} for r in items[:limit]], stations


def standings_pages(values, picks):
    lang = values["Language"]
    pages = []
    if not values["ShowStandings"]:
        return pages
    for pick in picks:
        series = pick["series"]
        if not biathlon.SERIES[series]["cup"]:
            continue
        columns = []
        for gender, group in (("SW", "women"), ("SM", "men")):
            if group not in values["Categories"]:
                continue
            with _data_lock:
                row = _cups.get(f"{series}:{gender}")
            if not row or not row.get("rows"):
                continue
            rows = row["rows"]
            top = rows[:values["MaxEntries"]]
            extra = None
            if values["Nation"] and not any(r["nat"] == values["Nation"] for r in top):
                extra = next((r for r in rows if r["nat"] == values["Nation"]), None)
            mark = lambda r: dict(r, mine=bool(values["Nation"] and r["nat"] == values["Nation"]))  # noqa: E731
            columns.append({"gender": gender, "rows": [mark(r) for r in top], "extra": mark(extra) if extra else None,
                            "updatedAt": row["at"]})
        if columns:
            season = (pick["current"] or {}).get("id", "")[2:6] or biathlon.season_id()
            pages.append({"kind": "standings", "id": f"cup-{series}", "series": series,
                          "seriesName": biathlon.series_name(series, lang),
                          "color": biathlon.SERIES[series]["color"],
                          "season": f"20{season[:2]}/{season[2:]}", "columns": columns})
    return pages


def race_order(values, picks):
    """Die Rennen der laufenden oder letzten Station: laufende zuerst,
    dann die jüngsten. Höchstens RaceCount."""
    current = {(p["current"] or {}).get("id") for p in picks if p["current"]}
    with _data_lock:
        races = [r for r in _races_index.values() if r["event"] in current and wanted_category(r, values)]
        states = {k: v.get("state") for k, v in _results.items()}
    shown = [r for r in races if states.get(r["id"]) in ("live", "post")]
    shown.sort(key=lambda r: (states.get(r["id"]) != "live", -r["start"]))
    return shown[:values["RaceCount"]]


def snapshot():
    """Alles, was die Szene braucht. Unter /api/scene abgerufen."""
    values = settings()
    with _data_lock:
        picks = list(_picks["list"])
        version_n = _version["n"]
    pages = []
    next_races, stations = upcoming(values, picks)
    for race in race_order(values, picks):
        with _data_lock:
            row = dict(_results.get(race["id"]) or {})
        pages.append(race_page(race, row, values))
    if values["ShowSchedule"] and (next_races or stations):
        pages.append({"kind": "schedule", "id": "schedule"})
    pages.extend(standings_pages(values, picks))
    with _takeover_lock:
        focus = _takeover["focus"] if _takeover["handle"] is not None else None
    with _data_lock:
        errors = sorted({r.get("error") for r in list(_events.values()) + list(_comps.values()) if r.get("error")})
    return {"version": version_n, "at": now(), "pageSeconds": values["PageSeconds"], "focus": focus,
            "lang": values["Language"], "nation": nation_view(values["Nation"], values["Language"]),
            "showTime": values["ShowTime"], "showShooting": values["ShowShooting"],
            "next": next_races, "stations": stations if values["ShowSchedule"] else [],
            "pages": pages, "error": errors[0] if errors else ""}


# --------------------------------------------------------------------------
# Playlists: die Takeover-Playlist und auf Wunsch eine für den Besitzer
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = "Biathlon Live (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Wird vom Plugin Biathlon Live abgespielt, wenn es den Bildschirm "
                                 "übernimmt. Bleibt ausgeschaltet, damit es nicht im Quick Mix landet. "
                                 "Das Plugin legt sie neu an, wenn sie gelöscht wird.")
OWNER_PLAYLIST_NAME = "Biathlon Live"
OWNER_PLAYLIST_DESCRIPTION = ("Vom Plugin Biathlon Live angelegt. Ausschalten, planen oder löschen "
                              "wie jede Playlist.")
TAKEOVER_ITEM_SECONDS = 6 * 3600  # das Plugin beendet die Anzeige lange vorher
SCENE_SECONDS = 60                # recommendedDurationSec in scene.dynamic

_playlists = {"at": 0.0, "takeoverId": None, "note": "", "ownerNote": ""}
_playlist_lock = threading.Lock()


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    """Hat irgendetwas den Bildschirm? Playlists werden nur angelegt, solange
    nichts ihn hält: der Rahmen baut den Quick Mix nach einem Takeover neu,
    und eine inzwischen angelegte Playlist ändert, was er wiederherstellt."""
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError as exc:
        return exc.status != 404
    return bool(status.get("active"))


def create_playlist(name, description, seconds, enabled):
    created = engine_call("POST", "/playlists", {"name": name, "description": description}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=name))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": seconds})
    if not enabled:
        engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    return playlist_id


def ensure_takeover_playlist():
    """Ein Takeover spielt eine Playlist, keine einzelne Szene. Also: die
    Szene allein, sechs Stunden, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if i.get("dynamicSceneId") == _scene["dbId"]]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    playlist_id = create_playlist(TAKEOVER_PLAYLIST_NAME, TAKEOVER_PLAYLIST_DESCRIPTION,
                                  TAKEOVER_ITEM_SECONDS, enabled=False)
    save_state(takeoverPlaylistId=playlist_id)
    plugin.log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def maintain_owner_playlist(values):
    state = load_state()
    playlist_id = state.get("ownerPlaylistId")
    if playlist_id:
        if get_playlist(playlist_id) is None:
            save_state(ownerPlaylistId=None, ownerPlaylistDeleted=bool(values["MakePlaylist"]))
            if values["MakePlaylist"]:
                save_settings({"MakePlaylist": False})
                plugin.log("Die Playlist Biathlon Live wurde gelöscht; sie wird nicht neu angelegt.")
        return ""
    if not values["MakePlaylist"]:
        return ""
    if screen_held():
        return tr("Wartet, bis der Bildschirm wieder frei ist.")
    playlist_id = create_playlist(OWNER_PLAYLIST_NAME, OWNER_PLAYLIST_DESCRIPTION, SCENE_SECONDS, enabled=True)
    save_state(ownerPlaylistId=playlist_id, ownerPlaylistDeleted=False)
    plugin.log(f"Playlist {OWNER_PLAYLIST_NAME} angelegt ({playlist_id}), eingeschaltet.")
    return ""


def maintain_playlists(force=False):
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        find_scene()
        if _scene["dbId"] is None:
            _playlists.update(note=_scene["note"], ownerNote=_scene["note"])
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc)
            plugin.log(_playlists["note"], level="warning")
        try:
            _playlists["ownerNote"] = maintain_owner_playlist(settings())
        except EngineError as exc:
            _playlists["ownerNote"] = tr("Konnte die Playlist Biathlon Live nicht pflegen: {exc}", exc=exc)


def owner_playlist_text(values, state):
    if values["MakePlaylist"]:
        if state.get("ownerPlaylistId"):
            return tr("Angelegt: die Playlist Biathlon Live steht unter Playlists.")
        return _playlists["ownerNote"] or tr("Noch nicht angelegt; das passiert innerhalb einer Minute.")
    if state.get("ownerPlaylistDeleted"):
        return tr("Die Playlist wurde gelöscht, deshalb steht das wieder auf Nein.")
    if state.get("ownerPlaylistId"):
        return tr("Die früher angelegte Playlist steht noch unter Playlists; das Plugin pflegt sie nicht mehr.")
    return ""


# --------------------------------------------------------------------------
# Den Bildschirm übernehmen und zurückgeben
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
ENDED_REASON = {"released": "abgebrochen", "expired": "abgelaufen", "failed": "fehlgeschlagen",
                "preempted": "verdraengt"}

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "reason": None, "since": None, "until": None, "started": False,
             "token": 0, "note": "", "focus": None}
_schedule = {"nextAt": 0.0, "lastAt": 0.0}
_stop_requested = threading.Event()
_wake = threading.Event()


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform") or {}
    except EngineError:
        return True  # nicht entscheidbar: der Versuch selbst sagt es dann
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Biathlon Live ist auf der Plugins-Seite ausgeschaltet.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Biathlon Live auf der Plugins-Seite aus, deshalb kann es "
                  "den Bildschirm nicht übernehmen.")
    return ""


def display_is_off():
    """Nur wahr, wenn der Rahmen sagt, dass der Bildschirm aus ist. Biathlon Live
    weckt keinen Bildschirm."""
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def scene_turn_on_screen():
    """Läuft die Szene gerade als normaler Playlist-Eintrag? Ein Takeover
    darüber lässt den Rahmen danach gestoppt zurück (bekannter Fehler), und
    die Ergebnisse sind ohnehin zu sehen."""
    if _scene["dbId"] is None:
        return False
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", read_timeout=5) or {}
    except EngineError:
        return False
    item = status.get("currentItem") or {}
    return bool(status.get("isRunning") and item.get("dynamicSceneId") == _scene["dbId"]
                and not same_id(status.get("activePlaylistId"), _playlists["takeoverId"]))


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        plugin.log(text)
    return False


def _on_session_state(handle_or_state):
    """Das SDK ruft das mit dem Handle auf, nicht mit dem neuen Zustand."""
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        started = _takeover["started"]
        _takeover.update(handle=None, reason=None, since=None, until=None, started=False, focus=None,
                         note=tr("Der Rahmen hat die Anzeige beendet ({state}).", state=new_state))
    plugin.log(f"Der Rahmen hat Biathlon Live beendet: {new_state}.")
    if started:
        emit(EVENT_ENDED, grund=ENDED_REASON.get(new_state, new_state))
    publish_status()
    threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason, token=None):
    """Bildschirm zurückgeben. Mehrfach aufrufbar."""
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        started = _takeover["started"]
        _takeover.update(handle=None, reason=None, since=None, until=None, started=False, focus=None, note="")
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:
        plugin.log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", level="warning")
    plugin.log(f"Bildschirm zurückgegeben ({reason}).")
    if started:
        emit(EVENT_ENDED, grund=reason)
    publish_status()
    if reason != "gestoppt":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def _release_after(seconds, token):
    if _stop_requested.wait(max(1, int(seconds))):
        return
    end_takeover("fertig", token)


def show_scene(reason="show", seconds=None, focus=None):
    """Die Szene für `seconds` über alles legen. True, wenn der Rahmen den
    Bildschirm hergegeben hat."""
    if _takeover["handle"] is not None:
        return _note(tr("Biathlon Live ist schon auf dem Bildschirm."))
    if not takeover_supported():
        return _note(tr("Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen."))
    if _scene["dbId"] is None:
        find_scene()
    if _scene["dbId"] is None or _scene["note"]:
        return _note(_scene["note"] or tr("Die Szene Biathlon Live wurde nicht gefunden."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("Die Takeover-Playlist ist noch nicht angelegt."))
    if scene_turn_on_screen():
        return _note(tr("Biathlon Live läuft gerade in deiner Playlist; die Anzeige bleibt so."))
    if display_is_off():
        return _note(tr("Der Bildschirm ist aus. Biathlon Live weckt ihn nicht."))
    seconds = int(seconds or settings()["ShowForSeconds"])
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             # Die Szene hat ihre eigene Schrift; eine Bildunterschrift stört nur.
             "overlay": {"enabled": False}}
    try:
        handle = plugin.acquire_display_session(
            session_key=reason, state=state, display_name=DISPLAY_NAME,
            # Etwas länger als gewünscht: der Timer unten ist das ordentliche
            # Ende, die Grenze der Engine greift nur, wenn das Plugin stirbt.
            max_duration_seconds=seconds + 10, wake_if_off=False)
    except Exception as exc:
        return _note(f"Konnte Biathlon Live nicht anzeigen: {exc}")
    if handle is None:
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    t = now()
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, reason=reason, since=t, until=t + seconds, started=False,
                         note="", focus=focus)
    try:
        handle.on_state_change(_on_session_state)
    except Exception:
        pass
    try:
        if not handle.wait_until_active(timeout=10):
            end_takeover("fehlgeschlagen", token)
            return _note(tr("Der Rahmen hat Biathlon Live nicht rechtzeitig angezeigt."))
    except Exception as exc:
        end_takeover("fehlgeschlagen", token)
        return _note(f"Konnte Biathlon Live nicht anzeigen: {exc}")
    with _takeover_lock:
        if _takeover["token"] != token or _takeover["handle"] is None:
            return False
        _takeover["started"] = True
    emit(EVENT_STARTED, grund=reason)
    plugin.log(f"Biathlon Live für {seconds} Sekunden auf dem Bildschirm ({reason}).")
    publish_status()
    threading.Thread(target=_release_after, args=(seconds, token),
                     name=f"{PLUGIN_ID}-timer", daemon=True).start()
    return True


def cancel_scene():
    if not end_takeover("abgebrochen"):
        _note(tr("Biathlon Live hatte den Bildschirm nicht."))


def toggle_scene():
    if _takeover["handle"] is not None:
        cancel_scene()
    else:
        show_scene("show")


_action_lock = threading.Lock()


def run_action(name):
    """Show, Cancel und Toggle antworten sofort und arbeiten in einem Thread."""
    work = {"show": lambda: show_scene("show"), "cancel": cancel_scene, "toggle": toggle_scene}[name]
    showing = _takeover["handle"] is not None
    asking, returning = tr("Bitte den Rahmen um den Bildschirm."), tr("Gebe den Bildschirm zurück.")
    message = {"show": asking, "cancel": returning, "toggle": returning if showing else asking}[name]

    def run():
        with _action_lock:
            try:
                work()
            except Exception as exc:  # pragma: no cover
                _note(tr("{name} hat nicht geklappt: {exc}", name=name, exc=exc))
    threading.Thread(target=run, name=f"{PLUGIN_ID}-{name}", daemon=True).start()
    return {"success": True, "message": message}


def check_playback_resumed():
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log,
                                                    stop_event=_stop_requested)
        if outcome == "not-requested":
            save_state(playbackStalled="")
            return
    elif _stop_requested.wait(12):
        return
    if _stop_requested.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
    except EngineError:
        return
    if status.get("isRunning") or _takeover["handle"] is not None:
        save_state(playbackStalled="")
        return
    message = tr("Der Rahmen ist nach Biathlon Live nicht zu deiner Playlist zurückgekehrt. Starte sie auf "
                 "der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix "
                 "passiert das nicht.")
    save_state(playbackStalled=message)
    plugin.log(message, level="warning")


# ---- Der Zeitplan ----------------------------------------------------------

def in_active_hours(values, moment=None):
    hour = (moment or datetime.now()).hour
    start, end = values["ActiveFrom"], values["ActiveTo"]
    if start == end:
        return True
    if start < end:
        return start <= hour < end
    return hour >= start or hour < end  # über Mitternacht, z.B. 18 bis 2


def any_live():
    with _data_lock:
        return any(r.get("state") == "live" for r in _results.values())


def raceday_today(values):
    """Hat eine gewählte Serie heute ein Rennen (in den gewählten Kategorien)?"""
    with _data_lock:
        races = [r for r in _races_index.values() if wanted_category(r, values)]
    return race_day(races) or any_live()


def auto_wanted(values):
    """(ja/nein, Grund) für die regelmäßige Anzeige."""
    mode = values["AutoMode"]
    if mode == "off":
        return False, tr("Regelmäßige Anzeige ist aus.")
    if not values["Series"]:
        return False, tr("Keine Serie gewählt.")
    if not in_active_hours(values):
        return False, tr("Außerhalb von {start}–{end} Uhr.", start=values["ActiveFrom"], end=values["ActiveTo"])
    if mode == "live" and not any_live():
        return False, tr("Gerade läuft kein Rennen.")
    if mode == "raceday" and not raceday_today(values):
        return False, tr("Heute ist in den gewählten Serien kein Renntag.")
    return True, ""


_auto = {"note": ""}


def decide_takeover():
    values = settings()
    if _takeover["handle"] is not None:
        with _takeover_lock:
            handle = _takeover["handle"]
        if handle is not None and str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
        return
    t = now()
    # Start oder Ergebnis eines Rennens, wenn gewünscht. Was niemand binnen
    # fünf Minuten zeigen konnte, ist keine Nachricht mehr.
    with _data_lock:
        _alerts[:] = [a for a in _alerts if t - a["at"] < 300]
        wanted = {"start": {"start"}, "result": {"result"}, "both": {"start", "result"}}.get(values["RaceAlert"], set())
        alert = next((a for a in _alerts if a["kind"] in wanted), None)
        if alert is not None:
            _alerts.remove(alert)
    if alert is not None and in_active_hours(values):
        reason = "rennstart" if alert["kind"] == "start" else "ergebnis"
        if show_scene(reason, values["AlertSeconds"], focus={"race": alert["race"]}):
            _schedule["lastAt"] = t
            return
    wanted, why = auto_wanted(values)
    _auto["note"] = why
    if not wanted:
        _schedule["nextAt"] = 0.0
        return
    if not _schedule["nextAt"]:
        # Erste Runde nach dem Start oder nach einer Pause: nicht sofort,
        # sondern eine Minute später, damit der Rahmen fertig starten kann.
        _schedule["nextAt"] = max(t + 60, _schedule["lastAt"] + values["EveryMinutes"] * 60)
    if t < _schedule["nextAt"]:
        return
    if show_scene("zeitplan"):
        _schedule["lastAt"] = t
        _schedule["nextAt"] = t + values["EveryMinutes"] * 60
    else:
        # Nicht bekommen (Bildschirm aus, anderes Plugin, eigene Runde):
        # in zwei Minuten noch einmal versuchen.
        _schedule["nextAt"] = t + 120


# --------------------------------------------------------------------------
# Overlay-Text
# --------------------------------------------------------------------------

_overlay = {"text": None}


def status_line():
    values = settings()
    lang = values["Language"]
    with _data_lock:
        races = dict(_races_index)
        results = {k: dict(v) for k, v in _results.items()}
    live = [races[k] for k, v in results.items() if v.get("state") == "live" and k in races]
    if live:
        race = max(live, key=lambda r: r["start"])
        rows = [r for r in ((results[race["id"]].get("result") or {}).get("rows") or []) if r["rank"] is not None]
        lead = ""
        if rows:
            first = rows[0]
            lead = f" – 1. {nations.name(first['nat'], lang, first['name']) if first['team'] else first['short']} ({first['nat']})"
        return tr("Live: {race}{lead}", race=race_title(race, lang), lead=lead)
    pending = sorted((r for r in races.values() if r["start"] > now() and wanted_category(r, values)),
                     key=lambda r: r["start"])
    if pending:
        race = pending[0]
        when = datetime.fromtimestamp(race["start"]).strftime("%d.%m. %H:%M")
        return tr("Nächstes Rennen: {when} {race} ({place})", when=when, race=race_title(race, lang), place=race["place"])
    return tr("Keine Rennen angesetzt")


def publish_status():
    text = status_line()
    if _overlay["text"] == text:
        return
    _overlay["text"] = text
    try:
        plugin.update_overlay_text(SERVICE_STATUS, text)
    except Exception:
        pass


# --------------------------------------------------------------------------
# Die Schleife
# --------------------------------------------------------------------------

TICK_SECONDS = 15
_loop = {"lastCheckAt": None, "lastError": "", "force": False}


def tick(force=False):
    try:
        maintain_playlists(force)
        refresh_data(force)
        decide_takeover()
        _loop.update(lastCheckAt=local_text(now()), lastError="")
    except Exception as exc:  # pragma: no cover - die Schleife muss weiterlaufen
        _loop["lastError"] = str(exc)
        plugin.log(f"Durchlauf fehlgeschlagen: {exc}", level="error")
    publish_status()


def main_loop():
    _stop_requested.wait(3)
    while not _stop_requested.is_set():
        _wake.clear()
        force, _loop["force"] = _loop["force"], False
        tick(force)
        _wake.wait(TICK_SECONDS)


def check_now():
    _loop["force"] = True
    _wake.set()
    return {"success": True, "message": tr("Lese die Ergebnisse jetzt neu.")}


# --------------------------------------------------------------------------
# Die Plugin-Seite und die Daten für die Szene
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


def state_payload():
    values = settings()
    state = load_state()
    lang = values["Language"]
    with _data_lock:
        picks = list(_picks["list"])
        comps = {k: dict(v) for k, v in _comps.items()}
        results = {k: dict(v) for k, v in _results.items()}
        events_error = next((r.get("error") for r in _events.values() if r.get("error")), "")
    with _takeover_lock:
        takeover = {"active": _takeover["handle"] is not None, "reason": _takeover["reason"],
                    "until": local_text(_takeover["until"]), "note": _takeover["note"]}
    rows = []
    for pick in picks:
        event = pick["current"]
        comp = comps.get(event["id"]) if event else None
        races = (comp or {}).get("races") or []
        mine = [r for r in races if wanted_category(r, values)]
        rows.append({"id": pick["series"], "name": biathlon.series_name(pick["series"], lang),
                     "place": event["place"] if event else "", "nat": event["nat"] if event else "",
                     "races": len(mine),
                     "done": sum(1 for r in mine if (results.get(r["id"]) or {}).get("state") == "post"),
                     "live": sum(1 for r in mine if (results.get(r["id"]) or {}).get("state") == "live"),
                     "next": pick["next"]["place"] if pick["next"] else "",
                     "nextStart": local_text(pick["next"]["start"]) if pick["next"] else "",
                     "at": local_text((comp or {}).get("at")), "error": (comp or {}).get("error") or events_error})
    return {
        "success": True,
        "version": version(),
        "settings": values,
        "series": [{"id": k, "name": biathlon.series_name(k, lang), "cup": v["cup"]} for k, v in biathlon.SERIES.items()],
        "nations": nations.choices(lang),
        "sources": rows,
        "season": biathlon.season_id(),
        "status": status_line(),
        "scene": {"found": _scene["dbId"] is not None, "note": _scene["note"]},
        "takeover": takeover,
        "permission": takeover_permission_note(),
        "next": local_text(_schedule["nextAt"]) if _schedule["nextAt"] else "",
        "autoNote": _auto["note"],
        "ownerPlaylist": owner_playlist_text(values, state),
        "lastCheckAt": _loop["lastCheckAt"],
        "lastError": _loop["lastError"] or state.get("playbackStalled") or "",
        "theme": {"id": theme_id()},
        "pages": len(snapshot()["pages"]),
    }


def settings_saved(changed):
    if "MakePlaylist" in changed:
        if settings()["MakePlaylist"]:
            save_state(ownerPlaylistDeleted=False)
        threading.Thread(target=maintain_playlists, kwargs={"force": True}, daemon=True).start()
    if set(changed) & {"Series", "Categories", "ShowStandings"}:
        check_now()
    if "Language" in changed:
        bump()  # die Szene holt sich die Daten mit der neuen Sprache
        publish_status()
    if set(changed) & {"AutoMode", "EveryMinutes", "ActiveFrom", "ActiveTo"}:
        _schedule["nextAt"] = 0.0
    bump()
    _wake.set()


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über :8003.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        """Den ganzen Body lesen: ungelesene Bytes würden auf einer offenen
        Verbindung zum Anfang der nächsten Anfrage."""
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(snapshot(), cors=True)
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                changed = save_settings(self._body())
                if changed:
                    settings_saved(changed)
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(check_now())
                return
            if path in ("/api/show", "/api/cancel", "/api/toggle"):
                self._json(run_action(path.rsplit("/", 1)[-1]))
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    ensure_dirs()
    plugin.log(f"Starte {PLUGIN_ID} {version()}")
    load_cache()

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: check_now())
    plugin.on_action("show", lambda _context=None: run_action("show"))
    plugin.on_action("cancel", lambda _context=None: run_action("cancel"))
    plugin.on_action("toggle", lambda _context=None: run_action("toggle"))

    start_studio()
    publish_status()
    plugin.connect_sse()
    plugin.ready()

    threading.Thread(target=main_loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    end_takeover("gestoppt")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    plugin.log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
