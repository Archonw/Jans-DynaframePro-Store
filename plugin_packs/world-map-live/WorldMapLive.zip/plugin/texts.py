"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Ausgeschaltet": ("Switched off", "Desactivado"),
    "Anmeldung abgelehnt. Stimmen Client-ID und Secret?": (
        "Login refused. Are the client ID and secret right?",
        "Inicio de sesión rechazado. ¿Son correctos el client ID y el secret?"),
    "Das Paket websocket-client fehlt. Installiere Weltkarte Live noch einmal.": (
        "The websocket-client package is missing. Install World Map Live again.",
        "Falta el paquete websocket-client. Vuelve a instalar Mapa del mundo en vivo."),
    "Der API-Key wird nicht angenommen.": ("The API key is not accepted.", "La clave API no se acepta."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.",
        "El marco no ha creado la lista {name}."),
    "Der Server hat die Verbindung beendet.": (
        "The server closed the connection.", "El servidor ha cerrado la conexión."),
    "Der Server meldet einen Fehler.": ("The server reports an error.", "El servidor informa de un error."),
    "Die Daten werden neu geladen.": ("Reloading the data.", "Recargando los datos."),
    "Die Playlist {name} gibt es schon.": (
        "The playlist {name} already exists.", "La lista {name} ya existe."),
    "Die Szene Weltkarte Live ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The World Map Live scene is not installed on this frame. Install the package again.",
        "La escena Mapa del mundo en vivo no está instalada en este marco. Vuelve a instalar el paquete."),
    "Die Weltkarte mit Flugzeugen, Schiffen und Blitzen.": (
        "The world map with aircraft, ships and lightning.",
        "El mapa del mundo con aviones, barcos y rayos."),
    "Bahndaten von {time}": ("Orbit data from {time}", "Datos de órbita de las {time}"),
    "Fehler: {code}": ("Error: {code}", "Error: {code}"),
    "Keine Daten mehr; verbinde neu.": ("No more data; reconnecting.", "No llegan datos; reconectando."),
    "Keine Verbindung.": ("No connection.", "Sin conexión."),
    "Konnte die Playlist nicht anlegen: {exc}": (
        "Could not create the playlist: {exc}", "No se ha podido crear la lista: {exc}"),
    "Lädt …": ("Loading …", "Cargando …"),
    "Noch kein API-Key": ("No API key yet", "Aún sin clave API"),
    "Noch kein Benutzername": ("No user name yet", "Aún sin nombre de usuario"),
    "Noch keine Adresse": ("No address yet", "Aún sin dirección"),
    "Verbunden, {n} Schiffe": ("Connected, {n} ships", "Conectado, {n} barcos"),
    "aus {n} Quellen": ("from {n} sources", "de {n} fuentes"),
    "Benutzername wird nicht angenommen.": ("The user name is not accepted.", "El nombre de usuario no se acepta."),
    "Playlist {name} angelegt. Starte sie auf der Startseite des Rahmens oder nimm die Szene in eine andere Playlist auf.": (
        "Playlist {name} created. Start it on the frame's home page, or add the scene to another playlist.",
        "Lista {name} creada. Iníciala en la página principal del marco o añade la escena a otra lista."),
    "Tageskontingent erschöpft; es geht später von selbst weiter.": (
        "Daily quota used up; it continues by itself later.",
        "Cuota diaria agotada; seguirá sola más tarde."),
    "nächste um {time}": ("next at {time}", "siguiente a las {time}"),
    "{n} in {m} Min.": ("{n} in {m} min", "{n} en {m} min"),
    "{n} um {time}": ("{n} at {time}", "{n} a las {time}"),
}


def t(lang, template, **values):
    text = template
    if lang in LANGUAGES and lang != "de":
        row = _TEXTS.get(template)
        if row:
            text = row[LANGUAGES.index(lang) - 1]
    try:
        return text.format(**values) if values else text
    except (KeyError, IndexError, ValueError):
        return text


def number(lang, n):
    return f"{n:,}".replace(",", "," if lang == "en" else ".")
