# Web Login

A password login in front of the DynaFrame web page.

## What it does

- **Port 80** (the normal web page): every visitor has to sign in, except the
  frame itself and the devices you trust. NFC readers (`/nfc/`, `/automations/`)
  keep working without a login.
- **Side doors**: the web page is also reachable directly on port 8003, the
  Engine on 8001 and the renderer on 8080, all past the login. The plugin closes
  the ports you tick (these three by default) with a firewall table of its own.
  The frame itself and trusted devices may still use them. All other ports stay
  open, so plugins you add later (YouTube Cast, Foto Cast and so on) keep working.
  SSH (22) and port 80 are never closed.
- **Trusted devices**: Home Assistant (the DynaFrame integration uses port 80
  without a login) and other frames you sync with. Devices that were turned
  away recently are listed on the plugin page and can be trusted with one tap.
- **Updates**: a DynaFrame update rewrites the web server setup. The login
  service notices and puts the login back, usually within a minute.

## Locked out?

Over SSH:

    sudo python3 /usr/local/lib/dfr-weblogin/weblogin_root.py off

Disabling or uninstalling the plugin also switches the login off after about
a minute and a half. Your settings stay in the plugin.

## How it works

- `authd.py`: the login service on 127.0.0.1:8097, a system service
  (`dfr-weblogin.service`) running as the frame user. nginx asks it about every
  request (`auth_request`). Passwords are stored as PBKDF2 hashes; a login is a
  signed cookie, and wrong passwords slow down after five tries.
- `weblogin_root.py`: the root part (through the frame user's passwordless sudo).
  DynaFrame's own site `/etc/nginx/sites-available/dynaframe` is never edited:
  a copy with the login goes to `/etc/nginx/dfr-weblogin/site.conf` and the
  `sites-enabled` link points to it. `nginx -t` checks every switch; if it
  fails, DynaFrame's own site is put back. The firewall is the nftables table
  `inet dfr_weblogin`.
- `plugin.py` + `studio/`: the plugin page.

## HTTPS

With HTTPS on, nginx also serves the site on port 443 and browsers always sign
in there; the login cookie is then marked Secure. The frame makes its own
certificate (valid for its name, name.local and its addresses, renewed when an
address changes) or uses one you paste. Home Assistant, trusted devices and NFC
readers keep using plain http on port 80.

## API keys

Apps that control the frame (Home Assistant, scripts) can get their own key
instead of being trusted by address. Create a key on the plugin page (it is
shown once), then send it as `Authorization: Bearer dfk_...` or
`X-DynaFrame-Key: dfk_...`. By default keys are accepted over HTTPS only, so
they never travel in plain text; requests with a key get a plain 401 instead
of the login page. The DynaFrame Home Assistant integration (1.3.0 and later)
takes the key and pins the frame's certificate. Optionally the NFC/automation
paths can be protected too, then readers need a key or a trusted address.

## Single sign-on (OIDC)

`oidc.py` (standard library only) signs in with any OpenID Connect provider:
authorization code flow with PKCE, state bound to a cookie, nonce, issuer,
audience and expiry checked, RS256 signatures checked against the provider's
keys. Optional allow lists for users (user name, e-mail, subject) and groups.
Register the redirect URIs shown on the plugin page at the provider. Password
sign-in can stay on as a fallback or be switched off.
