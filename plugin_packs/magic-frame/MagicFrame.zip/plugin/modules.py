"""Die Module von Dynaframe's Magic Mirror.

Ein Modul ist ein Eintrag in MODULES: Name und Beschreibung in drei Sprachen,
die Felder für die Plugin-Seite, die Region, in der es neu landet, und wenn es
Daten aus dem Netz braucht eine fetch-Funktion samt Abfrageabstand. Die Seite
baut ihre Formulare aus FIELDS, die Szene zeichnet jedes Modul mit dem
Renderer gleichen Namens in modules.js.

Ein neues Modul braucht also: einen Eintrag hier, einen Renderer in der Szene
und, falls es Daten holt, eine Funktion in sources.py. Jedes Modul kann
mehrmals auf dem Bildschirm stehen (z. B. zwei Kalender oder zwei Uhren).
"""

import threading
import time

import sources

LANGS = ("de", "en", "es")

# Wie bei MagicMirror: Leisten über die ganze Breite oben und unten, dazwischen
# drei Spalten in drei Höhen.
REGIONS = [
    ("top_bar", "Oben, ganze Breite", "Top, full width", "Arriba, todo el ancho"),
    ("top_left", "Oben links", "Top left", "Arriba a la izquierda"),
    ("top_center", "Oben Mitte", "Top centre", "Arriba en el centro"),
    ("top_right", "Oben rechts", "Top right", "Arriba a la derecha"),
    ("middle_left", "Links", "Left", "Izquierda"),
    ("middle_center", "Mitte", "Centre", "Centro"),
    ("middle_right", "Rechts", "Right", "Derecha"),
    ("bottom_left", "Unten links", "Bottom left", "Abajo a la izquierda"),
    ("bottom_center", "Unten Mitte", "Bottom centre", "Abajo en el centro"),
    ("bottom_right", "Unten rechts", "Bottom right", "Abajo a la derecha"),
    ("bottom_bar", "Unten, ganze Breite", "Bottom, full width", "Abajo, todo el ancho"),
]
REGION_IDS = [r[0] for r in REGIONS]


def L(de, en, es):
    return [de, en, es]


def F(key, kind, label, default=None, **extra):
    """kind: text, textarea, number, bool, select, secret, stop."""
    field = {"key": key, "kind": kind, "label": label, "default": default}
    field.update(extra)
    return field


def opt(value, de, en, es):
    return {"value": value, "label": [de, en, es]}


HEADER = F("header", "text", L("Überschrift (leer = keine)", "Heading (empty = none)", "Título (vacío = ninguno)"), "")


# --------------------------------------------------------------------------
# Wetter: eine Abfrage für Wetter, Vorhersage und Regen, 10 Minuten geteilt
# --------------------------------------------------------------------------

_weather = {"key": None, "at": 0.0, "value": None}
_weather_lock = threading.Lock()


def shared_weather(ctx):
    key = (round(ctx["lat"], 3), round(ctx["lon"], 3), ctx["imperial"])
    with _weather_lock:
        if _weather["key"] == key and time.time() - _weather["at"] < 540:
            return _weather["value"]
        value = sources.weather(ctx["lat"], ctx["lon"], ctx["imperial"])
        _weather.update(key=key, at=time.time(), value=value)
        return value


def need_place(ctx):
    if ctx.get("lat") is None:
        raise sources.SourceError("no-place")


def fetch_weather(cfg, ctx):
    need_place(ctx)
    value = shared_weather(ctx)
    today = value["daily"][0] if value["daily"] else {}
    return {"current": value["current"], "sunrise": today.get("sunrise"), "sunset": today.get("sunset"),
            "max": today.get("max"), "min": today.get("min"), "imperial": value["imperial"]}


def fetch_forecast(cfg, ctx):
    need_place(ctx)
    value = shared_weather(ctx)
    return {"daily": value["daily"], "imperial": value["imperial"]}


def fetch_rain(cfg, ctx):
    need_place(ctx)
    value = shared_weather(ctx)
    return {"rain": value["rain"], "imperial": value["imperial"]}


def fetch_warnings(cfg, ctx):
    need_place(ctx)
    return sources.dwd_alerts(ctx["lat"], ctx["lon"], ctx["lang"])


def lines_of(text, limit=20):
    return [line.strip() for line in str(text or "").splitlines() if line.strip()][:limit]


def fetch_calendar(cfg, ctx):
    urls = lines_of(cfg.get("urls"), 5)
    if not urls:
        raise sources.SourceError("no-url")
    events = sources.calendar_events(urls, cfg.get("user") or "", cfg.get("password") or "",
                                     days=int(cfg.get("days") or 14))
    return {"events": events[:int(cfg.get("count") or 8) * 3]}


def news_url(cfg):
    feed = cfg.get("feed") or "tagesschau"
    if feed == "custom":
        return str(cfg.get("url") or "").strip()
    return sources.NEWS_FEEDS.get(feed, sources.NEWS_FEEDS["tagesschau"])


def fetch_news(cfg, ctx):
    url = news_url(cfg)
    if not url:
        raise sources.SourceError("no-url")
    return sources.news(url)


def fetch_departures(cfg, ctx):
    stop = cfg.get("stop") or {}
    if not stop.get("id"):
        raise sources.SourceError("no-stop")
    rows = sources.transitous_departures(stop["id"], ctx["lang"])
    wanted = {part.strip().lower() for part in str(cfg.get("lines") or "").split(",") if part.strip()}
    if wanted:
        rows = [row for row in rows if row["line"].lower() in wanted]
    cutoff = time.time() - 60
    rows = [row for row in rows if row["when"] >= cutoff]
    return {"stop": stop.get("name") or "", "rows": rows[:max(int(cfg.get("count") or 6) * 2, 10)]}


def ha_entities(text):
    """Eine Zeile je Entität: "sensor.x" oder "Name = sensor.x"."""
    out = []
    for line in lines_of(text, 20):
        name, _, entity = line.rpartition("=")
        out.append({"id": entity.strip(), "label": name.strip()})
    return [row for row in out if "." in row["id"]]


def fetch_homeassistant(cfg, ctx):
    rows = ha_entities(cfg.get("entities"))
    if not rows:
        raise sources.SourceError("no-entities")
    value = sources.ha_states(cfg.get("url"), cfg.get("token") or "", [r["id"] for r in rows])
    labels = {r["id"]: r["label"] for r in rows}
    for entity in value["entities"]:
        if labels.get(entity["id"]):
            entity["name"] = labels[entity["id"]]
    return value


# --------------------------------------------------------------------------
# Der Katalog
# --------------------------------------------------------------------------

MODULES = {
    "clock": {
        "name": L("Uhr", "Clock", "Reloj"),
        "description": L("Uhrzeit und Datum.", "Time and date.", "Hora y fecha."),
        "region": "top_left",
        "fields": [
            F("seconds", "bool", L("Sekunden zeigen", "Show seconds", "Mostrar segundos"), False),
            F("date", "bool", L("Datum zeigen", "Show date", "Mostrar fecha"), True),
            F("week", "bool", L("Kalenderwoche zeigen", "Show week number", "Mostrar número de semana"), False),
            F("size", "select", L("Größe", "Size", "Tamaño"), "large", options=[
                opt("small", "klein", "small", "pequeño"), opt("medium", "mittel", "medium", "mediano"),
                opt("large", "groß", "large", "grande"), opt("xlarge", "riesig", "huge", "enorme")]),
        ],
    },
    "weather": {
        "name": L("Wetter jetzt", "Current weather", "Tiempo actual"),
        "description": L("Temperatur, Himmel, Wind und Sonnenauf- und -untergang am eingestellten Ort.",
                         "Temperature, sky, wind and sunrise/sunset at your location.",
                         "Temperatura, cielo, viento y salida/puesta del sol en tu ubicación."),
        "region": "top_right",
        "fetch": fetch_weather, "every": 600, "place": True,
        "fields": [
            F("feels", "bool", L("Gefühlte Temperatur", "Feels like", "Sensación térmica"), True),
            F("wind", "bool", L("Wind", "Wind", "Viento"), True),
            F("sun", "bool", L("Sonnenauf- und -untergang", "Sunrise and sunset", "Salida y puesta del sol"), True),
            F("today", "bool", L("Höchst- und Tiefstwert heute", "Today's high and low", "Máxima y mínima de hoy"), False),
        ],
    },
    "forecast": {
        "name": L("Wettervorhersage", "Weather forecast", "Previsión del tiempo"),
        "description": L("Die nächsten Tage mit Höchst- und Tiefstwerten.", "The next days with highs and lows.",
                         "Los próximos días con máximas y mínimas."),
        "region": "top_right",
        "fetch": fetch_forecast, "every": 1800, "place": True,
        "fields": [
            F("days", "number", L("Tage", "Days", "Días"), 5, min=2, max=7),
            F("pop", "bool", L("Regenwahrscheinlichkeit", "Chance of rain", "Probabilidad de lluvia"), True),
            F("fade", "bool", L("Nach unten ausblenden", "Fade out towards the bottom", "Desvanecer hacia abajo"), True),
        ],
    },
    "rain": {
        "name": L("Regen in den nächsten 3 Stunden", "Rain in the next 3 hours", "Lluvia en las próximas 3 horas"),
        "description": L("Wann es anfängt oder aufhört zu regnen, mit kleinem Balkendiagramm.",
                         "When rain starts or stops, with a small bar chart.",
                         "Cuándo empieza o para de llover, con un pequeño gráfico de barras."),
        "region": "top_right",
        "fetch": fetch_rain, "every": 600, "place": True,
        "fields": [
            F("hideDry", "bool", L("Ausblenden, wenn es trocken bleibt", "Hide while it stays dry",
                                   "Ocultar mientras no llueva"), False),
        ],
    },
    "calendar": {
        "name": L("Termine", "Calendar", "Calendario"),
        "description": L("Die nächsten Termine aus Nextcloud, Google oder jedem ICS-Link.",
                         "Upcoming events from Nextcloud, Google or any ICS link.",
                         "Próximas citas de Nextcloud, Google o cualquier enlace ICS."),
        "region": "top_left",
        "fetch": fetch_calendar, "every": 900,
        "fields": [
            F("urls", "textarea", L("Kalender-Links (einer pro Zeile, bis zu 5)", "Calendar links (one per line, up to 5)",
                                    "Enlaces de calendario (uno por línea, hasta 5)"), "",
              hint=L("Nextcloud: „Link teilen“ und den öffentlichen Link kopieren. Google: „Privatadresse im iCal-Format“.",
                     "Nextcloud: switch on “Share link” and copy the public link. Google: “Secret address in iCal format”.",
                     "Nextcloud: activa «Compartir enlace» y copia el enlace público. Google: «Dirección secreta en formato iCal».")),
            F("user", "text", L("Benutzername (nur für private Links)", "User name (private links only)",
                                "Usuario (solo enlaces privados)"), ""),
            F("password", "secret", L("App-Passwort", "App password", "Contraseña de aplicación"), ""),
            F("days", "number", L("Zeitraum (Tage)", "Period (days)", "Periodo (días)"), 14, min=1, max=90),
            F("count", "number", L("Höchstens … Termine", "At most … events", "Como máximo … citas"), 8, min=1, max=25),
            F("location", "bool", L("Ort zeigen", "Show location", "Mostrar lugar"), False),
            F("fade", "bool", L("Nach unten ausblenden", "Fade out towards the bottom", "Desvanecer hacia abajo"), True),
        ],
    },
    "news": {
        "name": L("Nachrichten", "News", "Noticias"),
        "description": L("Schlagzeilen aus einem RSS-Feed, als Laufband, einzeln nacheinander oder als Liste.",
                         "Headlines from an RSS feed as a ticker, one after another, or as a list.",
                         "Titulares de un feed RSS como cinta, uno tras otro o en lista."),
        "region": "bottom_bar",
        "fetch": fetch_news, "every": 900,
        "fields": [
            F("feed", "select", L("Quelle", "Source", "Fuente"), "tagesschau", options=[
                opt("tagesschau", "tagesschau.de", "tagesschau.de", "tagesschau.de"),
                opt("bbc", "BBC News", "BBC News", "BBC News"),
                opt("elpais", "El País", "El País", "El País"),
                opt("custom", "Eigener RSS-Link", "Own RSS link", "Enlace RSS propio")]),
            F("url", "text", L("RSS-Link", "RSS link", "Enlace RSS"), "", showIf={"feed": "custom"}),
            F("style", "select", L("Darstellung", "Style", "Estilo"), "rotate", options=[
                opt("rotate", "eine Schlagzeile nach der anderen", "one headline at a time", "un titular tras otro"),
                opt("ticker", "Laufband", "ticker", "cinta"),
                opt("list", "Liste", "list", "lista")]),
            F("count", "number", L("Schlagzeilen", "Headlines", "Titulares"), 8, min=1, max=15),
            F("seconds", "number", L("Sekunden je Schlagzeile", "Seconds per headline", "Segundos por titular"), 15,
              min=5, max=120, showIf={"style": "rotate"}),
        ],
    },
    "departures": {
        "name": L("Abfahrten", "Departures", "Salidas"),
        "description": L("Die nächsten Busse und Bahnen an einer Haltestelle, mit Echtzeit (Transitous).",
                         "The next buses and trains at a stop, with real-time data (Transitous).",
                         "Los próximos autobuses y trenes en una parada, en tiempo real (Transitous)."),
        "region": "middle_right",
        "fetch": fetch_departures, "every": 60, "visibleOnly": True,
        "fields": [
            F("stop", "stop", L("Haltestelle", "Stop", "Parada"), None),
            F("count", "number", L("Abfahrten", "Departures", "Salidas"), 6, min=1, max=15),
            F("lines", "text", L("Nur diese Linien (mit Komma, leer = alle)", "Only these lines (comma separated, empty = all)",
                                 "Solo estas líneas (separadas por comas, vacío = todas)"), ""),
            F("walk", "number", L("Fußweg zur Haltestelle (Minuten)", "Walk to the stop (minutes)",
                                  "Camino a la parada (minutos)"), 0, min=0, max=30,
              hint=L("Abfahrten, die du nicht mehr schaffst, werden blass.", "Departures you can no longer make are dimmed.",
                     "Las salidas que ya no alcanzas aparecen atenuadas.")),
        ],
    },
    "compliments": {
        "name": L("Sprüche", "Compliments", "Frases"),
        "description": L("Ein freundlicher Satz je nach Tageszeit, wie die Komplimente bei MagicMirror. Eigene Sätze gehen auch.",
                         "A friendly line depending on the time of day, like MagicMirror's compliments. Add your own too.",
                         "Una frase amable según la hora del día, como los cumplidos de MagicMirror. También las tuyas."),
        "region": "middle_center",
        "fields": [
            F("own", "textarea", L("Eigene Sätze (einer pro Zeile)", "Your own lines (one per line)",
                                   "Tus frases (una por línea)"), "",
              hint=L("Mit „morgens:“, „mittags:“, „abends:“ oder „nachts:“ davor nur zu dieser Tageszeit.",
                     "Start a line with “morning:”, “afternoon:”, “evening:” or “night:” to show it only then.",
                     "Empieza con «mañana:», «tarde:», «noche:» o «madrugada:» para mostrarla solo entonces.")),
            F("builtin", "bool", L("Mitgelieferte Sätze dazunehmen", "Include the built-in lines",
                                   "Incluir las frases incluidas"), True),
            F("seconds", "number", L("Wechsel alle … Sekunden", "Change every … seconds", "Cambiar cada … segundos"), 30,
              min=5, max=3600),
            F("size", "select", L("Größe", "Size", "Tamaño"), "large", options=[
                opt("medium", "mittel", "medium", "mediano"), opt("large", "groß", "large", "grande"),
                opt("xlarge", "riesig", "huge", "enorme")]),
        ],
    },
    "warnings": {
        "name": L("Unwetterwarnungen (DWD)", "Weather warnings (DWD)", "Avisos meteorológicos (DWD)"),
        "description": L("Warnungen des Deutschen Wetterdienstes für den Ort. Nur in Deutschland; ohne Warnung unsichtbar.",
                         "Warnings from the German Weather Service for your location. Germany only; invisible without a warning.",
                         "Avisos del servicio meteorológico alemán para tu ubicación. Solo Alemania; invisible sin aviso."),
        "region": "top_bar",
        "fetch": fetch_warnings, "every": 600, "place": True,
        "fields": [
            F("level", "select", L("Ab Stufe", "From level", "A partir del nivel"), "2", options=[
                opt("1", "Wetterwarnung", "minor", "leve"), opt("2", "markantes Wetter", "moderate", "moderado"),
                opt("3", "Unwetter", "severe", "severo"), opt("4", "extremes Unwetter", "extreme", "extremo")]),
        ],
    },
    "homeassistant": {
        "name": L("Home Assistant", "Home Assistant", "Home Assistant"),
        "description": L("Werte aus Home Assistant: Temperaturen, Fenster, Strom, alles mit einer Entität.",
                         "Values from Home Assistant: temperatures, windows, power, anything with an entity.",
                         "Valores de Home Assistant: temperaturas, ventanas, energía, cualquier entidad."),
        "region": "middle_left",
        "fetch": fetch_homeassistant, "every": 30, "visibleOnly": True,
        "fields": [
            F("url", "text", L("Adresse von Home Assistant", "Home Assistant address", "Dirección de Home Assistant"),
              "http://homeassistant.local:8123"),
            F("token", "secret", L("Langzeit-Zugangstoken", "Long-lived access token", "Token de acceso de larga duración"), "",
              hint=L("In Home Assistant: Profil → Sicherheit → „Token erstellen“.",
                     "In Home Assistant: Profile → Security → “Create token”.",
                     "En Home Assistant: Perfil → Seguridad → «Crear token».")),
            F("entities", "textarea", L("Entitäten (eine pro Zeile)", "Entities (one per line)", "Entidades (una por línea)"),
              "", picker="homeassistant", hint=L("z. B. sensor.wohnzimmer_temperatur oder mit eigenem Namen: Wohnzimmer = sensor.wohnzimmer_temperatur",
                         "e.g. sensor.living_room_temperature or with your own name: Living room = sensor.living_room_temperature",
                         "p. ej. sensor.salon_temperatura o con nombre propio: Salón = sensor.salon_temperatura")),
            F("icons", "bool", L("Symbole zeigen", "Show icons", "Mostrar iconos"), True),
        ],
    },
    "webpage": {
        "name": L("Webseite", "Web page", "Página web"),
        "description": L("Eine Webseite in einem Rahmen, z. B. ein Dashboard oder eine Kamera. Manche Seiten verbieten das Einbetten.",
                         "A web page in a box, e.g. a dashboard or a camera. Some sites refuse to be embedded.",
                         "Una página web en un recuadro, p. ej. un panel o una cámara. Algunos sitios no permiten incrustarse."),
        "region": "middle_center",
        "fields": [
            F("url", "text", L("Adresse", "Address", "Dirección"), "https://"),
            F("height", "number", L("Höhe (% des Bildschirms)", "Height (% of the screen)", "Altura (% de la pantalla)"), 30,
              min=5, max=100),
            F("zoom", "number", L("Zoom (%)", "Zoom (%)", "Zoom (%)"), 100, min=25, max=200),
            F("reload", "number", L("Neu laden alle … Minuten (0 = nie)", "Reload every … minutes (0 = never)",
                                    "Recargar cada … minutos (0 = nunca)"), 0, min=0, max=1440),
        ],
    },
}

for _spec in MODULES.values():
    _spec["fields"] = [HEADER] + _spec["fields"]


# Zusatzmodule (addons.py) landen hier, solange sie installiert sind.
EXTRA = {}


def get(module_type):
    return MODULES.get(module_type) or EXTRA.get(module_type)


def known(module_type):
    return get(module_type) is not None


def catalog():
    """Was die Plugin-Seite braucht, ohne die Funktionen."""
    rows = []
    for name, spec in list(MODULES.items()) + sorted(EXTRA.items()):
        addon = spec.get("addon")
        rows.append({"type": name, "name": spec["name"], "description": spec["description"], "region": spec["region"],
                     "place": bool(spec.get("place")), "fields": spec["fields"],
                     "addon": {k: addon[k] for k in ("origin", "version", "author", "url")} if addon else None})
    return {"regions": [{"id": r[0], "label": list(r[1:])} for r in REGIONS], "modules": rows}


def defaults(module_type):
    return {field["key"]: field["default"] for field in get(module_type)["fields"]}


def secret_keys(module_type):
    spec = get(module_type)
    return [field["key"] for field in spec["fields"] if field["kind"] == "secret"] if spec else []


def coerce(module_type, config):
    """Nur bekannte Felder, mit den richtigen Typen und Grenzen."""
    out = defaults(module_type)
    for field in get(module_type)["fields"]:
        key, kind = field["key"], field["kind"]
        if key not in (config or {}):
            continue
        raw = config[key]
        if kind == "bool":
            out[key] = raw is True or str(raw).lower() in ("1", "true", "on", "yes")
        elif kind == "number":
            try:
                number = int(float(str(raw).replace(",", ".")))
            except (TypeError, ValueError):
                continue
            out[key] = max(field.get("min", number), min(field.get("max", number), number))
        elif kind == "select":
            values = [o["value"] for o in field["options"]]
            out[key] = str(raw) if str(raw) in values else field["default"]

        elif kind == "stop":
            if isinstance(raw, dict) and raw.get("id"):
                out[key] = {"id": str(raw["id"])[:120], "name": str(raw.get("name") or "")[:80]}
            else:
                out[key] = None
        elif kind == "textarea":
            out[key] = str(raw or "")[:4000]
        else:
            out[key] = str(raw or "").strip()[:2000]
    return out


# Mitgelieferte Sprüche, wie die Komplimente von MagicMirror. Die Szene wählt
# nach Tageszeit: morning 5-12, afternoon 12-18, evening 18-23, night sonst.
COMPLIMENTS = {
    "de": {
        "any": ["Schön, dass du da bist.", "Heute wird ein guter Tag.", "Du schaffst das.", "Einfach mal durchatmen."],
        "morning": ["Guten Morgen!", "Genieß deinen Kaffee.", "Hast du gut geschlafen?", "Auf geht's!"],
        "afternoon": ["Hallo!", "Läuft bei dir.", "Zeit für eine kleine Pause?"],
        "evening": ["Guten Abend!", "Schön, dass du zu Hause bist.", "Feierabend!"],
        "night": ["Gute Nacht.", "Schlaf gut.", "Morgen ist auch noch ein Tag."],
    },
    "en": {
        "any": ["Nice to see you.", "Today is going to be a good day.", "You've got this.", "Take a deep breath."],
        "morning": ["Good morning!", "Enjoy your coffee.", "Did you sleep well?", "Let's go!"],
        "afternoon": ["Hello there!", "You're doing great.", "Time for a little break?"],
        "evening": ["Good evening!", "Welcome home.", "Time to relax."],
        "night": ["Good night.", "Sleep well.", "Tomorrow is another day."],
    },
    "es": {
        "any": ["Qué bien verte.", "Hoy va a ser un buen día.", "Tú puedes.", "Respira hondo."],
        "morning": ["¡Buenos días!", "Disfruta tu café.", "¿Has dormido bien?", "¡Vamos allá!"],
        "afternoon": ["¡Hola!", "Lo estás haciendo genial.", "¿Una pausa?"],
        "evening": ["¡Buenas tardes!", "Bienvenido a casa.", "Hora de descansar."],
        "night": ["Buenas noches.", "Que duermas bien.", "Mañana será otro día."],
    },
}
