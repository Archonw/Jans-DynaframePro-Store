/* Photo Universe - die Szene.
 *
 * Jedes Foto ist ein Stern. Das Plugin liefert je Stern die Bewertung (0-5)
 * und für jede Ordnung (Jahr, Ort, Person) die Nummer seines Sternbilds
 * (api/universe). Wo die Sterne stehen, rechnet die Szene: die Sternbilder
 * liegen auf zwei Spiralarmen (nach Jahr: die Zeit läuft nach außen), Sterne
 * ohne Sternbild sind Sternenstaub in den Armen.
 *
 * Ablauf: Überblick -> Flug zu einem Sternbild -> Anflug auf einen Stern ->
 * das Foto öffnet sich aus dem Stern (api/star, api/photo) -> zurück in den
 * Stern -> nächster Stern im selben Sternbild -> nächstes Sternbild. Ab und
 * zu ein Überblick; bei "Im Wechsel" ordnen sich die Sterne dabei neu.
 *
 * Gezeichnet wird mit WebGL (Punkte mit additivem Leuchten); ohne WebGL eine
 * einfachere Fassung mit Canvas 2D und weniger Sternen.
 *
 * Zum Ausprobieren: ?plugin=<URL der Plugin-Seite> &speed=4 &lang=de|en|es
 * &demo=1 (ausgedachtes Universum ohne Plugin) &mode=year|place|person
 * &nogl=1 (Canvas-2D-Fassung) &shot=overview|group|photo (Standbild)
 */
(function () {
  "use strict";

  const PLUGIN_ID = "PhotoUniverse";
  const params = new URLSearchParams(location.search);
  const SPEED = Math.max(0.1, Number(params.get("speed")) || 1);
  const DEMO = params.get("demo") === "1";
  const SHOT = params.get("shot") || "";
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const sameOrigin = (location.protocol === "http:" && (location.port === "" || location.port === "80"))
    || (location.protocol === "https:" && (location.port === "" || location.port === "443"));
  const pluginBases = params.get("plugin") ? [params.get("plugin").replace(/\/?$/, "/")] : [...new Set(sameOrigin ? [
    `${location.origin}${advanced}`,
    `${location.protocol}//${location.hostname}:8003${advanced}`
  ] : [
    `${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`,
    `http://${location.hostname || "localhost"}${advanced}`
  ])];
  let baseIndex = 0;

  const TEXT = {
    de: {
      wait: "Photo Universe zählt die Sterne …", none: "Photo Universe findet keine Fotos. Wähle auf der Plugin-Seite eine Quelle.",
      unreachable: "Photo Universe antwortet nicht.", login: "Bitte zuerst im Browser beim Rahmen anmelden.",
      year: "Sternbilder der Jahre", place: "Sternbilder der Orte", person: "Sternbilder der Menschen", dust: "Sternenstaub",
      stars: "{n} Sterne", photos: "{n} Fotos", with: "mit {names}", constellation: "Sternbild {name}",
      months: ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"]
    },
    en: {
      wait: "Photo Universe is counting the stars …", none: "Photo Universe finds no photos. Pick a source on the plugin page.",
      unreachable: "Photo Universe is not responding.", login: "Please sign in to the frame in the browser first.",
      year: "Constellations of the years", place: "Constellations of places", person: "Constellations of people", dust: "Stardust",
      stars: "{n} stars", photos: "{n} photos", with: "with {names}", constellation: "Constellation {name}",
      months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    },
    es: {
      wait: "Photo Universe está contando las estrellas …", none: "Photo Universe no encuentra fotos. Elige una fuente en la página del plugin.",
      unreachable: "Photo Universe no responde.", login: "Inicia sesión primero en el marco desde el navegador.",
      year: "Constelaciones de los años", place: "Constelaciones de los lugares", person: "Constelaciones de las personas", dust: "Polvo de estrellas",
      stars: "{n} estrellas", photos: "{n} fotos", with: "con {names}", constellation: "Constelación {name}",
      months: ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
    }
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  let lang = params.get("lang") || "en";
  const tx = (key, values) => {
    let text = (TEXT[lang] || TEXT.en)[key] || key;
    for (const [k, v] of Object.entries(values || {})) text = text.replace(`{${k}}`, v);
    return text;
  };
  const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang] || "en-GB");

  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const lerp = (a, b, k) => a + (b - a) * k;
  const ease = (k) => k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
  const sine = (k) => 0.5 - Math.cos(Math.PI * k) / 2;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms / SPEED));

  function rng(seed) {   // mulberry32: gleiche Zahl -> gleicher Platz im All
    let a = seed >>> 0;
    return () => {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function gauss(r) {
    const u = Math.max(1e-9, r());
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * r());
  }

  // ------------------------------------------------------------ Plugin

  async function api(path) {
    let lastError = null;
    for (let i = 0; i < pluginBases.length; i += 1) {
      const base = pluginBases[(baseIndex + i) % pluginBases.length];
      try {
        const response = await fetch(base + path, { cache: "no-store", credentials: "same-origin" });
        if (response.redirected && /login/i.test(response.url)) throw new Error("login");
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const body = await response.json();
        baseIndex = (baseIndex + i) % pluginBases.length;
        return body;
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error("unreachable");
  }
  const url = (path) => pluginBases[baseIndex] + path;

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.decoding = "async";
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("image"));
      img.src = src;
    });
  }

  function report(message) {
    if (!DEMO) api("api/report?m=" + encodeURIComponent(String(message).slice(0, 180))).catch(() => {});
  }

  // DynaFrame wartet, bis die Szene meldet, dass sie steht; sonst bricht der
  // Fernseher nach einer Frist ab ("scene readiness deadline expired").
  let readySent = false;
  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 8000);

  const note = document.getElementById("note");
  function showNote(text) {
    note.textContent = text || "";
    note.hidden = !text;
  }

  // ------------------------------------------------------------ Einstellungen

  const cfg = {
    Grouping: params.get("mode") || "rotate", Glow: "normal", PreferRated: true, PhotoSeconds: 10, PhotosPerVisit: 3,
    Tempo: "normal", Captions: true, ShowLines: true, ShowNames: true, Overview: true
  };
  const tempo = () => ({ slow: 1.45, normal: 1, fast: 0.7 })[cfg.Tempo] || 1;

  // ------------------------------------------------------------ Das Universum

  const R = 1000;                      // Radius der Galaxie
  const MODES = ["year", "place", "person"];
  const U = {
    ver: -1, n: 0,
    rating: new Uint8Array(0),
    groups: {},                         // mode -> {names, of: Int16Array}
    mode: "year",
    layouts: {},                        // mode -> {pos, centers}
    pos: new Float32Array(0),           // aktuell gezeichnete Plätze
    from: null, to: null, morphAt: 0, morphDur: 0
  };
  const DECOR = 4000;                  // Hintergrundsterne ohne Foto

  function setUniverse(data) {
    const ratingText = data.rating || "";
    const n = ratingText.length;
    U.n = n;
    U.ver = data.ver;
    U.rating = new Uint8Array(n);
    for (let i = 0; i < n; i += 1) U.rating[i] = ratingText.charCodeAt(i) - 48;
    U.groups = {};
    for (const mode of MODES) {
      const g = (data.groups || {})[mode] || { names: [], g: "" };
      const of = new Int16Array(n).fill(-1);
      for (let i = 0; i < n && i < g.g.length; i += 1) {
        const c = g.g.charCodeAt(i);
        of[i] = c === 46 ? -1 : c - 48;
      }
      const counts = new Array(g.names.length).fill(0);
      for (let i = 0; i < n; i += 1) if (of[i] >= 0) counts[of[i]] += 1;
      U.groups[mode] = { names: g.names, of, counts };
    }
    U.layouts = {};
  }

  function availableModes() {
    return MODES.filter((m) => (U.groups[m]?.names.length || 0) >= 2);
  }

  function chooseMode(current) {
    const have = availableModes();
    if (!have.length) return "year";
    if (cfg.Grouping !== "rotate") return have.includes(cfg.Grouping) ? cfg.Grouping : have[0];
    if (!current || !have.includes(current)) return have[0];
    return have[(have.indexOf(current) + 1) % have.length];
  }

  // Sternbild j liegt auf Arm j % 2, weiter außen je später (Jahr) bzw. je kleiner
  function groupCenter(j, G, r) {
    const s = (j + 0.5) / Math.max(1, G);
    const arm = j % 2;
    const radius = 170 + 760 * s;
    const angle = arm * Math.PI + s * 3.5 + 0.4 + (r() - 0.5) * 0.25;
    return [radius * Math.cos(angle), (r() - 0.5) * 70, radius * Math.sin(angle)];
  }

  function layout(mode) {
    if (U.layouts[mode]) return U.layouts[mode];
    const g = U.groups[mode];
    const G = g.names.length;
    const r = rng(7 + MODES.indexOf(mode) * 101);
    const centers = [];
    for (let j = 0; j < G; j += 1) {
      const c = groupCenter(j, G, r);
      const radius = clamp(26 + 6.5 * Math.sqrt(g.counts[j]), 34, 135);
      centers.push({ x: c[0], y: c[1], z: c[2], r: radius, count: g.counts[j], name: g.names[j], hue: (j * 137.508 + 205) % 360 });
    }
    const pos = new Float32Array(U.n * 3);
    for (let i = 0; i < U.n; i += 1) {
      const sr = rng(i * 2654435761 + MODES.indexOf(mode) * 977 + 13);
      const j = g.of[i];
      let x, y, z;
      if (j >= 0) {
        const c = centers[j];
        const s = c.r * 0.42;
        x = c.x + gauss(sr) * s;
        y = c.y + gauss(sr) * s * 0.55;
        z = c.z + gauss(sr) * s;
      } else {
        [x, y, z] = dustPoint(sr, i);
      }
      pos[i * 3] = x; pos[i * 3 + 1] = y; pos[i * 3 + 2] = z;
    }
    U.layouts[mode] = { pos, centers };
    return U.layouts[mode];
  }

  function dustPoint(sr, i) {
    if (sr() < 0.16) {   // Kern der Galaxie
      const rad = Math.abs(gauss(sr)) * 120;
      const a = sr() * Math.PI * 2;
      return [rad * Math.cos(a), gauss(sr) * 40, rad * Math.sin(a)];
    }
    const t = Math.pow(sr(), 0.85);
    const radius = 70 + 960 * t;
    const arm = i % 2;
    const s = (radius - 170) / 760;
    const angle = arm * Math.PI + s * 3.5 + 0.4 + gauss(sr) * 0.32;
    return [radius * Math.cos(angle), gauss(sr) * (12 + 34 * (1 - t)), radius * Math.sin(angle)];
  }

  // Farben: Sternbilder in eigenen Tönen, Staub weiß bis bläulich/warm
  function hsl(h, s, l) {
    const a = s * Math.min(l, 1 - l);
    const f = (n) => { const k = (n + h / 30) % 12; return l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); };
    return [f(0), f(8), f(4)];
  }

  function brightness(r) {
    if (cfg.Glow === "even") return [0.62, 1.7];
    if (cfg.Glow === "strong") return [0.14 + 0.172 * r, 1.0 + 0.8 * r];
    return [0.32 + 0.136 * r, 1.3 + 0.5 * r];
  }

  // ------------------------------------------------------------ Kamera

  const cam = { pos: [0, 900, 1600], look: [0, 0, 0], fov: 55 };
  const view = { W: 1, H: 1, vp: new Float32Array(16), scale: 1 };

  function perspective(fovy, aspect, near, far) {
    const f = 1 / Math.tan(fovy / 2);
    const nf = 1 / (near - far);
    return [f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0];
  }
  function lookAt(e, c) {
    let zx = e[0] - c[0], zy = e[1] - c[1], zz = e[2] - c[2];
    let l = Math.hypot(zx, zy, zz) || 1;
    zx /= l; zy /= l; zz /= l;
    let xx = zz, xy = 0, xz = -zx;               // up x z mit up = (0,1,0)
    l = Math.hypot(xx, xy, xz) || 1;
    xx /= l; xy /= l; xz /= l;
    const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
    return [xx, yx, zx, 0, xy, yy, zy, 0, xz, yz, zz, 0,
      -(xx * e[0] + xy * e[1] + xz * e[2]), -(yx * e[0] + yy * e[1] + yz * e[2]), -(zx * e[0] + zy * e[1] + zz * e[2]), 1];
  }
  function mul(a, b) {
    const o = new Float32Array(16);
    for (let i = 0; i < 4; i += 1) {
      for (let j = 0; j < 4; j += 1) {
        o[j * 4 + i] = a[i] * b[j * 4] + a[4 + i] * b[j * 4 + 1] + a[8 + i] * b[j * 4 + 2] + a[12 + i] * b[j * 4 + 3];
      }
    }
    return o;
  }
  function updateView() {
    const p = perspective(cam.fov * Math.PI / 180, view.W / view.H, 2, 9000);
    view.vp = mul(p, lookAt(cam.pos, cam.look));
    view.scale = view.H / (2 * Math.tan(cam.fov * Math.PI / 360));
  }
  function project(x, y, z) {
    const m = view.vp;
    const w = m[3] * x + m[7] * y + m[11] * z + m[15];
    if (w <= 1) return null;
    const px = (m[0] * x + m[4] * y + m[8] * z + m[12]) / w;
    const py = (m[1] * x + m[5] * y + m[9] * z + m[13]) / w;
    return { x: (px * 0.5 + 0.5) * view.W, y: (0.5 - py * 0.5) * view.H, w };
  }

  // Ein Flug: Bezier von A über B nach C, Blick von L0 nach L1
  let shot = null;
  function fly(to, look, seconds, via) {
    return new Promise((resolve) => {
      const from = cam.pos.slice();
      const dist = Math.hypot(to[0] - from[0], to[1] - from[1], to[2] - from[2]);
      const mid = via || [(from[0] + to[0]) / 2, (from[1] + to[1]) / 2 + dist * 0.18, (from[2] + to[2]) / 2];
      shot = { from, mid, to, look0: cam.look.slice(), look1: look.slice(), t0: performance.now(),
        dur: Math.max(0.05, seconds) * 1000 / SPEED, done: resolve, curve: seconds > 6 ? ease : sine };
    });
  }
  function stepShot(now) {
    if (!shot) return;
    const k = clamp((now - shot.t0) / shot.dur);
    const e = shot.curve(k);
    const u = 1 - e;
    for (let i = 0; i < 3; i += 1) {
      cam.pos[i] = u * u * shot.from[i] + 2 * u * e * shot.mid[i] + e * e * shot.to[i];
      cam.look[i] = lerp(shot.look0[i], shot.look1[i], ease(clamp(k * 1.35)));
    }
    if (k >= 1) {
      const done = shot.done;
      shot = null;
      done();
    }
  }

  // ------------------------------------------------------------ Zeichnen (WebGL)

  let sky = document.getElementById("sky");
  const labels = document.getElementById("labels");
  const lctx = labels.getContext("2d");
  let gl = null;
  if (params.get("nogl") !== "1") {
    try {
      gl = sky.getContext("webgl", { alpha: true, premultipliedAlpha: true, antialias: false, depth: false, powerPreference: "high-performance" });
    } catch (_) { gl = null; }
  }
  let ctx2d = gl ? null : sky.getContext("2d");
  let renderScale = 1;

  const VS = `
    attribute vec3 aPos; attribute vec4 aCol; attribute vec3 aMeta;
    uniform mat4 uVP; uniform float uScale; uniform float uTime; uniform float uActive; uniform float uBoost;
    uniform float uDim; uniform float uMaxSize; uniform float uSoft;
    varying vec4 vCol; varying float vSpike; varying float vSoft; varying float vSize;
    void main() {
      vSoft = uSoft;
      vec4 p = uVP * vec4(aPos, 1.0);
      gl_Position = p;
      float d = max(p.w, 1.0);
      float px = aMeta.x * uScale / d;
      float b = aCol.a;
      bool active = abs(aMeta.y - uActive) < 0.5;
      b *= active ? uBoost : uDim;
      if (uSoft < 0.5) {
        float tw = 1.0 + 0.18 * sin(uTime * (1.3 + fract(aMeta.z * 7.31) * 2.2) + aMeta.z * 43.0) * step(3.5, aMeta.x);
        b *= tw;
      }
      float s = clamp(px, 2.2, uMaxSize);
      b *= clamp(px / 2.2, 0.55, 1.0);
      gl_PointSize = s;
      vSize = s;
      vCol = vec4(aCol.rgb, b);
      vSpike = (uSoft < 0.5 && aMeta.x > 2.8 && s > 10.0) ? 1.0 : 0.0;
    }`;
  const FS = `
    precision mediump float;
    varying vec4 vCol; varying float vSpike; varying float vSoft; varying float vSize;
    void main() {
      vec2 c = gl_PointCoord * 2.0 - 1.0;
      float r2 = dot(c, c);
      if (r2 > 1.0) discard;
      float a;
      if (vSoft > 0.5) {
        a = exp(-r2 * 3.2) * (1.0 - r2);
      } else {
        // kleine Punkte: fast flach, sonst verschwinden ferne Sterne
        a = vSize < 4.5 ? (1.0 - r2 * 0.7) * 0.95 : exp(-r2 * 10.0) + 0.3 * exp(-r2 * 3.0) * (1.0 - r2);
        if (vSpike > 0.5) {
          a += 0.5 * (exp(-abs(c.x) * 28.0) * exp(-abs(c.y) * 3.0) + exp(-abs(c.y) * 28.0) * exp(-abs(c.x) * 3.0)) * (1.0 - r2);
        }
      }
      a *= vCol.a;
      gl_FragColor = vec4(vCol.rgb * a, a);
    }`;
  const LVS = `
    attribute vec3 aPos; attribute vec4 aCol; uniform mat4 uVP; varying vec4 vCol;
    void main() { gl_Position = uVP * vec4(aPos, 1.0); vCol = aCol; }`;
  const LFS = `
    precision mediump float; varying vec4 vCol; uniform float uAlpha;
    void main() { gl_FragColor = vec4(vCol.rgb * vCol.a * uAlpha, vCol.a * uAlpha); }`;

  function program(vs, fs) {
    const make = (type, text) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, text);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
      return s;
    };
    const p = gl.createProgram();
    gl.attachShader(p, make(gl.VERTEX_SHADER, vs));
    gl.attachShader(p, make(gl.FRAGMENT_SHADER, fs));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
    const loc = {};
    for (const name of ["aPos", "aCol", "aMeta"]) loc[name] = gl.getAttribLocation(p, name);
    for (const name of ["uVP", "uScale", "uTime", "uActive", "uBoost", "uDim", "uMaxSize", "uSoft", "uAlpha"]) loc[name] = gl.getUniformLocation(p, name);
    return { p, loc };
  }

  let P = null, L = null, maxPoint = 64, maxSoft = 64;
  const buf = {};
  if (gl) {
    try {
      P = program(VS, FS);
      L = program(LVS, LFS);
      for (const name of ["starPos", "starCol", "starMeta", "decoPos", "decoCol", "decoMeta", "nebPos", "nebCol", "nebMeta", "linePos", "lineCol"]) buf[name] = gl.createBuffer();
      const hw = gl.getParameter(gl.ALIASED_POINT_SIZE_RANGE)[1] || 64;
      maxPoint = Math.min(160, hw);
      maxSoft = Math.min(380, hw);   // Nebel: große Punkte kosten auf dem Pi Füllrate
    } catch (error) {
      console.warn("WebGL", error.message);
      report("WebGL: " + error.message);
      gl = null;
    }
  }
  if (!gl && !ctx2d) {
    // WebGL ging an, aber die Shader nicht: frische Leinwand für Canvas 2D
    const fresh = document.createElement("canvas");
    fresh.id = "sky";
    sky.replaceWith(fresh);
    sky = fresh;
    ctx2d = sky.getContext("2d");
  }
  const counts = { deco: 0, neb: 0, lines: 0 };
  let starCol = new Float32Array(0), starMeta = new Float32Array(0);
  let lineIdx = [], lineGroup = [], lineCol = new Float32Array(0);

  function upload(name, data, dynamic) {
    if (!gl) return;
    gl.bindBuffer(gl.ARRAY_BUFFER, buf[name]);
    gl.bufferData(gl.ARRAY_BUFFER, data, dynamic ? gl.DYNAMIC_DRAW : gl.STATIC_DRAW);
  }

  // Hintergrund: ferne Sterne in einer großen Kugel und Dunst in den Armen
  let decoPos, decoCol, decoMeta;
  function buildDecor() {
    const r = rng(99);
    decoPos = new Float32Array(DECOR * 3);
    decoCol = new Float32Array(DECOR * 4);
    decoMeta = new Float32Array(DECOR * 3);
    for (let i = 0; i < DECOR; i += 1) {
      const u = r() * 2 - 1, a = r() * Math.PI * 2, d = 3200 + r() * 2600;
      const s = Math.sqrt(1 - u * u);
      decoPos.set([d * s * Math.cos(a), d * u, d * s * Math.sin(a)], i * 3);
      const warm = r();
      decoCol.set([0.75 + 0.25 * warm, 0.8 + 0.1 * r(), 1.0 - 0.25 * warm, 0.25 + 0.5 * r() * r()], i * 4);
      decoMeta.set([5 + r() * 9, -9, r()], i * 3);
    }
    counts.deco = DECOR;
    upload("decoPos", decoPos); upload("decoCol", decoCol); upload("decoMeta", decoMeta);
  }

  let nebPos, nebCol, nebMeta;
  function buildNebulae(mode) {
    const lay = layout(mode);
    const r = rng(5 + MODES.indexOf(mode));
    const list = [];
    // Kern und Dunst entlang der Arme
    list.push([0, 0, 0, 1.0, 0.82, 0.6, 0.13, 700]);
    list.push([0, 0, 0, 1.0, 0.9, 0.75, 0.16, 300]);
    for (let i = 0; i < 36; i += 1) {
      const p = dustPoint(r, i);
      const h = 220 + r() * 90;
      const c = hsl(h, 0.6, 0.55);
      list.push([p[0], p[1] * 0.4, p[2], c[0], c[1], c[2], 0.035 + r() * 0.04, 260 + r() * 260]);
    }
    for (const c of lay.centers) {
      const col = hsl(c.hue, 0.7, 0.55);
      list.push([c.x, c.y, c.z, col[0], col[1], col[2], 0.07, c.r * 2.8]);
    }
    nebPos = new Float32Array(list.length * 3);
    nebCol = new Float32Array(list.length * 4);
    nebMeta = new Float32Array(list.length * 3);
    list.forEach((n, i) => {
      nebPos.set(n.slice(0, 3), i * 3);
      nebCol.set([n[3], n[4], n[5], n[6]], i * 4);
      nebMeta.set([n[7], i >= list.length - lay.centers.length ? i - (list.length - lay.centers.length) : -9, 0], i * 3);
    });
    counts.neb = list.length;
    upload("nebPos", nebPos); upload("nebCol", nebCol); upload("nebMeta", nebMeta);
  }

  function colorStars(mode) {
    const g = U.groups[mode];
    const lay = layout(mode);
    starCol = new Float32Array(U.n * 4);
    starMeta = new Float32Array(U.n * 3);
    for (let i = 0; i < U.n; i += 1) {
      const sr = rng(i * 7919 + 3);
      const j = g.of[i];
      const [b, size] = brightness(U.rating[i]);
      let c;
      if (j >= 0) {
        const h = hsl(lay.centers[j].hue, 0.75, 0.72);
        const w = 0.45 + 0.25 * sr();
        c = [lerp(1, h[0], w), lerp(1, h[1], w), lerp(1, h[2], w)];
      } else {
        const t = sr();
        c = t < 0.5 ? [0.78 + 0.2 * t, 0.86 + 0.1 * t, 1.0] : [1.0, 0.92 - 0.1 * (t - 0.5), 0.78 - 0.12 * (t - 0.5)];
      }
      starCol.set([c[0], c[1], c[2], b], i * 4);
      starMeta.set([size, j, sr()], i * 3);
    }
    upload("starCol", starCol); upload("starMeta", starMeta);
  }

  // Linien: die hellsten Sterne eines Sternbilds, verbunden zum kürzesten Baum
  function buildLines(mode) {
    const g = U.groups[mode];
    const lay = layout(mode);
    const members = lay.centers.map(() => []);
    for (let i = 0; i < U.n; i += 1) if (g.of[i] >= 0) members[g.of[i]].push(i);
    lineIdx = [];
    lineGroup = [];
    members.forEach((list, j) => {
      const pick = list.slice().sort((a, b) => (U.rating[b] - U.rating[a]) || ((a * 2654435761) % 997 - (b * 2654435761) % 997)).slice(0, 11);
      if (pick.length < 2) return;
      const p = lay.pos;
      const inTree = [pick[0]];
      const rest = pick.slice(1);
      while (rest.length) {
        let best = Infinity, bi = 0, bj = 0;
        for (let a = 0; a < inTree.length; a += 1) {
          for (let b = 0; b < rest.length; b += 1) {
            const s = inTree[a] * 3, t = rest[b] * 3;
            const d = (p[s] - p[t]) ** 2 + (p[s + 1] - p[t + 1]) ** 2 + (p[s + 2] - p[t + 2]) ** 2;
            if (d < best) { best = d; bi = a; bj = b; }
          }
        }
        lineIdx.push(inTree[bi], rest[bj]);
        lineGroup.push(j, j);
        inTree.push(rest[bj]);
        rest.splice(bj, 1);
      }
    });
    counts.lines = lineIdx.length;
    lineCol = new Float32Array(lineIdx.length * 4);
    colorLines(-1);
    updateLinePositions();
  }

  function colorLines(active) {
    if (!U.groups[U.mode]) return;
    const lay = layout(U.mode);
    for (let v = 0; v < lineIdx.length; v += 1) {
      const j = lineGroup[v];
      const h = hsl(lay.centers[j].hue, 0.6, 0.75);
      lineCol.set([h[0], h[1], h[2], j === active ? 0.55 : 0.09], v * 4);
    }
    upload("lineCol", lineCol);
  }

  function updateLinePositions() {
    const out = new Float32Array(lineIdx.length * 3);
    for (let v = 0; v < lineIdx.length; v += 1) {
      const i = lineIdx[v] * 3;
      out[v * 3] = U.pos[i]; out[v * 3 + 1] = U.pos[i + 1]; out[v * 3 + 2] = U.pos[i + 2];
    }
    upload("linePos", out, true);
  }

  function useMode(mode, morph) {
    const lay = layout(mode);
    U.mode = mode;
    if (morph && U.pos.length === lay.pos.length) {
      U.from = U.pos.slice();
      U.to = lay.pos;
      U.morphAt = performance.now();
      U.morphDur = 7000 / SPEED;
    } else {
      U.pos = lay.pos.slice();
      U.from = U.to = null;
      upload("starPos", U.pos, true);
    }
    colorStars(mode);
    buildNebulae(mode);
    buildLines(mode);
    state.active = -1;
  }

  function stepMorph(now) {
    if (!U.from) return;
    const k = ease(clamp((now - U.morphAt) / U.morphDur));
    const a = U.from, b = U.to, p = U.pos;
    for (let i = 0; i < p.length; i += 1) p[i] = a[i] + (b[i] - a[i]) * k;
    upload("starPos", p, true);
    updateLinePositions();
    if (k >= 1) U.from = U.to = null;
  }

  function resize() {
    const long = Math.max(innerWidth, innerHeight);
    const cap = Math.min(1, 1920 / long) * renderScale;
    view.W = innerWidth;
    view.H = innerHeight;
    sky.width = Math.round(innerWidth * cap);
    sky.height = Math.round(innerHeight * cap);
    labels.width = Math.round(innerWidth * Math.min(1, 1920 / long));
    labels.height = Math.round(innerHeight * Math.min(1, 1920 / long));
    if (gl) gl.viewport(0, 0, sky.width, sky.height);
  }
  addEventListener("resize", resize);

  const state = { active: -1, boost: 1, dim: 1, lineAlpha: 1, labelAlpha: 1, activeAt: 0, fade: 0 };
  let activeWant = -1;

  function drawPoints(names, count, soft, active, boost, dim) {
    const { loc } = P;
    gl.bindBuffer(gl.ARRAY_BUFFER, buf[names[0]]);
    gl.enableVertexAttribArray(loc.aPos);
    gl.vertexAttribPointer(loc.aPos, 3, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, buf[names[1]]);
    gl.enableVertexAttribArray(loc.aCol);
    gl.vertexAttribPointer(loc.aCol, 4, gl.FLOAT, false, 0, 0);
    gl.bindBuffer(gl.ARRAY_BUFFER, buf[names[2]]);
    gl.enableVertexAttribArray(loc.aMeta);
    gl.vertexAttribPointer(loc.aMeta, 3, gl.FLOAT, false, 0, 0);
    gl.uniform1f(loc.uSoft, soft ? 1 : 0);
    gl.uniform1f(loc.uActive, active);
    gl.uniform1f(loc.uBoost, boost);
    gl.uniform1f(loc.uDim, dim);
    gl.uniform1f(loc.uMaxSize, soft ? maxSoft * sky.height / 1080 : Math.min(maxPoint, 110 * (sky.height / 1080 + 0.2)));
    gl.drawArrays(gl.POINTS, 0, count);
  }

  function renderGL(now) {
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.ONE, gl.ONE);
    gl.useProgram(P.p);
    gl.uniformMatrix4fv(P.loc.uVP, false, view.vp);
    gl.uniform1f(P.loc.uScale, view.scale * sky.height / view.H);
    gl.uniform1f(P.loc.uTime, now / 1000);
    const fade = state.fade;
    if (counts.neb) drawPoints(["nebPos", "nebCol", "nebMeta"], counts.neb, true, state.active, (1 + state.boost) / 2 * fade, state.dim * fade);
    if (counts.deco) drawPoints(["decoPos", "decoCol", "decoMeta"], counts.deco, false, -5, 1, fade);
    if (cfg.ShowLines && counts.lines && state.lineAlpha > 0.01) {
      gl.useProgram(L.p);
      gl.uniformMatrix4fv(L.loc.uVP, false, view.vp);
      gl.uniform1f(L.loc.uAlpha, state.lineAlpha * fade);
      gl.bindBuffer(gl.ARRAY_BUFFER, buf.linePos);
      gl.enableVertexAttribArray(L.loc.aPos);
      gl.vertexAttribPointer(L.loc.aPos, 3, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, buf.lineCol);
      gl.enableVertexAttribArray(L.loc.aCol);
      gl.vertexAttribPointer(L.loc.aCol, 4, gl.FLOAT, false, 0, 0);
      gl.drawArrays(gl.LINES, 0, counts.lines);
      gl.disableVertexAttribArray(L.loc.aCol);
      gl.useProgram(P.p);
    }
    if (U.n) drawPoints(["starPos", "starCol", "starMeta"], U.n, false, state.active, state.boost * fade, state.dim * fade);
  }

  // Ohne WebGL: dieselbe Kamera, Punkte mit Canvas 2D (höchstens 3500 Sterne)
  let order2d = null;
  function render2D(now) {
    const c = ctx2d;
    const sx = sky.width / view.W, sy = sky.height / view.H;
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.clearRect(0, 0, sky.width, sky.height);
    c.globalCompositeOperation = "lighter";
    if (!order2d || order2d.length !== Math.min(U.n, 3500)) {
      order2d = Array.from({ length: U.n }, (_, i) => i).sort((a, b) => U.rating[b] - U.rating[a]).slice(0, 3500);
    }
    const draw = (x, y, z, rgb, b, size) => {
      const p = project(x, y, z);
      if (!p || p.x < -20 || p.y < -20 || p.x > view.W + 20 || p.y > view.H + 20) return;
      const px = clamp(size * view.scale / p.w, 1.2, 40);
      c.fillStyle = `rgba(${rgb[0] * 255 | 0},${rgb[1] * 255 | 0},${rgb[2] * 255 | 0},${clamp(b * clamp(px / 1.6, 0.3, 1))})`;
      c.beginPath();
      c.arc(p.x * sx, p.y * sy, px * 0.32 * sx, 0, Math.PI * 2);
      c.fill();
    };
    for (let i = 0; i < DECOR; i += 4) draw(decoPos[i * 3], decoPos[i * 3 + 1], decoPos[i * 3 + 2], [1, 1, 1], decoCol[i * 4 + 3] * state.fade, 8);
    if (cfg.ShowLines && state.lineAlpha > 0.01) {
      c.lineWidth = 1;
      for (let v = 0; v < lineIdx.length; v += 2) {
        const a = lineIdx[v] * 3, b = lineIdx[v + 1] * 3;
        const p = project(U.pos[a], U.pos[a + 1], U.pos[a + 2]);
        const q = project(U.pos[b], U.pos[b + 1], U.pos[b + 2]);
        if (!p || !q) continue;
        c.strokeStyle = `rgba(180,190,255,${lineCol[v * 4 + 3] * state.lineAlpha * state.fade})`;
        c.beginPath(); c.moveTo(p.x * sx, p.y * sy); c.lineTo(q.x * sx, q.y * sy); c.stroke();
      }
    }
    for (const i of order2d) {
      const j = starMeta[i * 3 + 1];
      const f = (j === state.active ? state.boost : state.dim) * state.fade;
      draw(U.pos[i * 3], U.pos[i * 3 + 1], U.pos[i * 3 + 2], [starCol[i * 4], starCol[i * 4 + 1], starCol[i * 4 + 2]], starCol[i * 4 + 3] * f, starMeta[i * 3]);
    }
    c.globalCompositeOperation = "source-over";
  }

  // Namen der Sternbilder
  function drawLabels() {
    const c = lctx;
    const s = labels.width / view.W;
    c.setTransform(s, 0, 0, s, 0, 0);
    c.clearRect(0, 0, view.W, view.H);
    if (!cfg.ShowNames || state.labelAlpha < 0.01 || !U.n) return;
    const lay = layout(U.mode);
    const base = Math.min(view.W, view.H);
    c.textAlign = "center";
    c.textBaseline = "middle";
    lay.centers.forEach((g, j) => {
      const p = project(g.x, g.y + g.r * 0.95, g.z);
      if (!p || p.x < -200 || p.x > view.W + 200 || p.y < -100 || p.y > view.H + 100) return;
      const isActive = j === state.active;
      const size = clamp(base * 0.035 * (900 / p.w) * (isActive ? 1.25 : 1), base * 0.014, base * (isActive ? 0.06 : 0.034));
      if (isActive) {   // der eigene Name bleibt ganz auf dem Schirm
        p.x = clamp(p.x, view.W * 0.12, view.W * 0.88);
        p.y = clamp(p.y, size * 1.3, view.H - size * 2.2);
      }
      let alpha = isActive ? 0.95 : clamp(0.75 - p.w / 4200, 0.18, 0.62) * (state.active >= 0 ? 0.6 : 1);
      if (U.from) alpha *= 0.35;
      alpha *= state.labelAlpha * state.fade;
      if (alpha < 0.03) return;
      const col = hsl(g.hue, 0.65, 0.8);
      c.font = `${isActive ? 400 : 300} ${size.toFixed(1)}px -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif`;
      c.shadowColor = `rgba(${col[0] * 255 | 0},${col[1] * 255 | 0},${col[2] * 255 | 0},0.9)`;
      c.shadowBlur = isActive ? size * 0.7 : size * 0.35;
      c.fillStyle = `rgba(${(lerp(255, col[0] * 255, 0.5)) | 0},${(lerp(255, col[1] * 255, 0.5)) | 0},${(lerp(255, col[2] * 255, 0.5)) | 0},${alpha})`;
      c.fillText(spaced(g.name), p.x, p.y);
      if (isActive) {
        c.shadowBlur = 0;
        c.font = `300 ${(size * 0.42).toFixed(1)}px -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif`;
        c.fillStyle = `rgba(210,215,240,${alpha * 0.8})`;
        c.fillText(tx("photos", { n: fmt(g.count) }), p.x, p.y + size * 0.85);
      }
    });
    c.shadowBlur = 0;
  }
  const spaced = (text) => String(text).toUpperCase().split("").join(" ");

  // Weiche Übergänge für Hervorhebung, Linien, Namen
  const want = { boost: 1, dim: 1, lineAlpha: 1, labelAlpha: 1, fade: 1 };
  function stepState(dt) {
    const k = 1 - Math.exp(-dt / 600 * SPEED);
    for (const key of Object.keys(want)) state[key] = lerp(state[key], want[key], key === "fade" ? 1 - Math.exp(-dt / 1200 * SPEED) : k);
    if (activeWant !== state.active) {
      state.active = activeWant;
      colorLines(activeWant);
    }
  }

  // Bildrate im Blick: wird der Pi zu langsam, rechnen wir mit weniger Pixeln
  const perf = { frames: 0, since: 0, slow: 0 };
  function watchPerf(now, dt) {
    perf.frames += 1;
    if (!perf.since) perf.since = now;
    if (now - perf.since > 3000) {
      const avg = (now - perf.since) / perf.frames;
      if (avg > 42 && renderScale > 0.55) {
        perf.slow += 1;
        if (perf.slow >= 2) {
          renderScale = Math.max(0.55, renderScale * 0.82);
          resize();
          perf.slow = 0;
        }
      } else {
        perf.slow = 0;
      }
      perf.since = now;
      perf.frames = 0;
    }
    return dt;
  }

  let last = performance.now();
  let firstFrame = true;
  function frame(now) {
    const dt = Math.min(100, now - last);
    last = now;
    watchPerf(now, dt);
    stepShot(now);
    stepMorph(now);
    stepState(dt);
    updateView();
    if (gl) renderGL(now);
    else render2D(now);
    drawLabels();
    if (firstFrame && U.n) {
      firstFrame = false;
      ready();
    }
    requestAnimationFrame(frame);
  }

  // ------------------------------------------------------------ Titel und Foto

  const titleBox = document.getElementById("title");
  function showTitle(main, sub) {
    document.getElementById("titleMain").textContent = main || "";
    document.getElementById("titleSub").textContent = sub || "";
    titleBox.classList.toggle("on", Boolean(main));
  }

  const photoBox = document.getElementById("photo");
  const photoImg = document.getElementById("photoImg");
  const caption = document.getElementById("caption");
  let photoStar = -1;
  let photoAnim = null;

  function starPos(i) {
    return [U.pos[i * 3], U.pos[i * 3 + 1], U.pos[i * 3 + 2]];
  }

  // Das Foto wächst aus dem Stern: Startpunkt ist der Stern auf dem Schirm
  function starOffset(i) {
    const p = starPos(i);
    const s = project(p[0], p[1], p[2]);
    return s ? [Math.round(s.x - view.W / 2), Math.round(s.y - view.H * 0.46)] : [0, 0];
  }

  function photoSize(w, h) {
    const maxW = view.W * 0.84, maxH = view.H * (cfg.Captions ? 0.74 : 0.84);
    const k = Math.min(maxW / w, maxH / h);
    return [Math.round(w * k), Math.round(h * k)];
  }

  function dateText(taken) {
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(taken || "");
    if (!m) return "";
    const months = tx("months");
    const day = Number(m[3]), month = months[Number(m[2]) - 1] || "";
    if (lang === "de") return `${day}. ${month} ${m[1]}`;
    if (lang === "es") return `${day} de ${month} de ${m[1]}`;
    return `${day} ${month} ${m[1]}`;
  }

  function fillCaption(info, group) {
    const lay = layout(U.mode);
    const g = group >= 0 ? lay.centers[group] : null;
    const tint = g ? hsl(g.hue, 0.7, 0.78) : [0.75, 0.8, 1];
    const css = `rgb(${tint[0] * 255 | 0},${tint[1] * 255 | 0},${tint[2] * 255 | 0})`;
    caption.style.setProperty("--tint", css);
    photoBox.style.setProperty("--glow", `rgba(${tint[0] * 255 | 0},${tint[1] * 255 | 0},${tint[2] * 255 | 0},0.5)`);
    document.getElementById("capGroup").textContent = g ? tx("constellation", { name: g.name }) : tx("dust");
    const main = document.getElementById("capMain");
    main.textContent = [dateText(info.taken), info.place].filter(Boolean).join(" · ");
    if (info.rating > 0) {
      const stars = document.createElement("span");
      stars.className = "stars";
      stars.textContent = "★".repeat(info.rating);
      main.appendChild(stars);
    }
    const people = (info.people || []).slice(0, 4);
    document.getElementById("capSub").textContent = people.length ? tx("with", { names: people.join(", ") }) : "";
  }

  async function openPhoto(i, info, img) {
    const [w, h] = photoSize(info.w, info.h);
    photoImg.src = img.src;
    photoBox.style.width = `${w}px`;
    photoBox.style.height = `${h}px`;
    photoStar = i;
    photoBox.hidden = false;
    const [ox, oy] = starOffset(i);
    const start = Math.max(4, Math.min(w, h) * 0.02);
    const keyframes = [
      { transform: `translate(calc(-50% + ${ox}px), calc(-50% + ${oy}px)) scale(${(start / w).toFixed(4)}, ${(start / h).toFixed(4)})`, borderRadius: "50%", opacity: 0, filter: "brightness(3) blur(6px)" },
      { offset: 0.35, opacity: 1, borderRadius: "50%", filter: "brightness(2) blur(3px)" },
      { transform: "translate(-50%, -50%) scale(1, 1)", borderRadius: "6px", opacity: 1, filter: "brightness(1) blur(0px)" }
    ];
    want.labelAlpha = 0;
    want.lineAlpha = 0;
    want.dim = 0.45;
    photoAnim = photoBox.animate(keyframes, { duration: 1700 / SPEED, easing: "cubic-bezier(.2,.7,.2,1)", fill: "forwards" });
    await photoAnim.finished.catch(() => {});
    if (cfg.Captions) {
      caption.hidden = false;
      requestAnimationFrame(() => caption.classList.add("on"));
    }
  }

  async function closePhoto() {
    caption.classList.remove("on");
    if (photoAnim) {
      photoAnim.reverse();
      photoAnim.updatePlaybackRate(1.25);
      await photoAnim.finished.catch(() => {});
    }
    photoBox.hidden = true;
    caption.hidden = true;
    photoStar = -1;
    photoAnim = null;
    want.labelAlpha = 1;
    want.lineAlpha = 1;
    want.dim = 1;
  }

  // ------------------------------------------------------------ Wohin fliegen

  const recent = [];
  const recentGroups = [];
  function remember(list, value, size) {
    list.push(value);
    if (list.length > size) list.shift();
  }

  function pickGroup() {
    const lay = layout(U.mode);
    const options = lay.centers.map((g, j) => j).filter((j) => !recentGroups.includes(j));
    const pool = options.length ? options : lay.centers.map((g, j) => j);
    if (!pool.length) return -1;
    let total = 0;
    const weights = pool.map((j) => { const w = Math.sqrt(lay.centers[j].count); total += w; return w; });
    let x = Math.random() * total;
    for (let k = 0; k < pool.length; k += 1) {
      x -= weights[k];
      if (x <= 0) return pool[k];
    }
    return pool[pool.length - 1];
  }

  function pickStar(group) {
    const of = U.groups[U.mode].of;
    const list = [];
    for (let i = 0; i < U.n; i += 1) if ((group < 0 || of[i] === group) && !recent.includes(i)) list.push(i);
    if (!list.length) return -1;
    let total = 0;
    const weights = list.map((i) => {
      const r = U.rating[i];
      const w = cfg.PreferRated ? 0.25 + r * r : 1;
      total += w;
      return w;
    });
    let x = Math.random() * total;
    for (let k = 0; k < list.length; k += 1) {
      x -= weights[k];
      if (x <= 0) return list[k];
    }
    return list[list.length - 1];
  }

  function viewpoint(group) {
    const g = layout(U.mode).centers[group];
    const out = Math.hypot(g.x, g.z) > 1 ? [g.x / Math.hypot(g.x, g.z), 0, g.z / Math.hypot(g.x, g.z)] : [1, 0, 0];
    const side = [-out[2], 0, out[0]];
    const d = g.r;
    return [g.x + out[0] * d * 1.5 + side[0] * d * 0.9, g.y + d * 1.05, g.z + out[2] * d * 1.5 + side[2] * d * 0.9];
  }

  function nearStar(i, distance) {
    const p = starPos(i);
    let dx = cam.pos[0] - p[0], dy = cam.pos[1] - p[1], dz = cam.pos[2] - p[2];
    const l = Math.hypot(dx, dy, dz) || 1;
    dx /= l; dy /= l; dz /= l;
    return [p[0] + dx * distance, p[1] + dy * distance + distance * 0.12, p[2] + dz * distance];
  }

  async function fetchPhoto(i) {
    if (DEMO) return demoPhoto(i);
    const w = Math.min(1920, Math.round(view.W * 0.84 * Math.min(1.5, devicePixelRatio || 1)));
    const h = Math.min(1440, Math.round(view.H * 0.84 * Math.min(1.5, devicePixelRatio || 1)));
    const info = await api(`api/star?v=${U.ver}&i=${i}&w=${w}&h=${h}`);
    if (!info.success) throw new Error(info.error || "photo");
    const img = await loadImage(url(`api/photo?id=${info.id}`));
    return { info, img };
  }

  // ------------------------------------------------------------ Ablauf

  let pending = null;   // neue Daten vom Plugin, eingebaut beim nächsten Überblick

  async function overview(switchMode) {
    want.labelAlpha = 1;
    want.lineAlpha = 1;
    activeWant = -1;
    const a = Math.random() * Math.PI * 2;
    const far = [Math.cos(a) * 1500, 1050 + Math.random() * 300, Math.sin(a) * 1500];
    await fly(far, [0, -40, 0], 7 * tempo());
    if (pending) {
      const data = pending;
      pending = null;
      want.fade = 0;
      await sleep(1300);
      setUniverse(data);
      useMode(chooseMode(U.mode), false);
      want.fade = 1;
    } else if (switchMode) {
      const next = chooseMode(U.mode);
      if (next !== U.mode) useMode(next, true);
    }
    showTitle(tx(U.mode), tx("stars", { n: fmt(U.n) }));
    // Langsam um die Galaxie kreisen
    const b = a + 0.5;
    await fly([Math.cos(b) * 1450, 980, Math.sin(b) * 1450], [0, -40, 0], 8 * tempo(),
      [Math.cos(a + 0.25) * 1600, 1050, Math.sin(a + 0.25) * 1600]);
    showTitle("");
  }

  async function visit() {
    const group = pickGroup();
    if (group >= 0) remember(recentGroups, group, Math.min(4, Math.max(0, layout(U.mode).centers.length - 2)));
    const first = pickStar(group);
    if (first < 0) return;
    activeWant = group;
    want.boost = 1.5;
    want.dim = 0.7;
    if (group >= 0) {
      const g = layout(U.mode).centers[group];
      const vp = viewpoint(group);
      const dist = Math.hypot(vp[0] - cam.pos[0], vp[1] - cam.pos[1], vp[2] - cam.pos[2]);
      await fly(vp, [g.x, g.y, g.z], clamp(dist / 260, 5, 11) * tempo());
      await sleep(1500 * tempo());
    }
    let star = first;
    for (let k = 0; k < cfg.PhotosPerVisit && star >= 0; k += 1) {
      remember(recent, star, 400);
      const loading = fetchPhoto(star).catch((error) => { report("Foto: " + error.message); return null; });
      const p = starPos(star);
      let via = null;
      if (k > 0 && group >= 0) {   // zwischen zwei Sternen ein Stück hinaus, damit man das Sternbild sieht
        const vp = viewpoint(group), to = nearStar(star, 16);
        via = [0, 1, 2].map((a) => lerp((cam.pos[a] + to[a]) / 2, vp[a], 0.55));
      }
      await fly(nearStar(star, 16), p, (k > 0 ? 5.5 : 4.6) * tempo(), via);
      const photo = await loading;
      if (photo) {
        fillCaption(photo.info, group);
        await openPhoto(star, photo.info, photo.img);
        await fly(nearStar(star, 12), p, cfg.PhotoSeconds);
        await closePhoto();
      }
      star = k + 1 < cfg.PhotosPerVisit ? pickStar(group) : -1;
    }
    want.boost = 1;
    want.dim = 1;
    // zurück auf Abstand
    if (group >= 0) {
      const g = layout(U.mode).centers[group];
      await fly(viewpoint(group), [g.x, g.y, g.z], 4 * tempo());
    }
    activeWant = -1;
  }

  async function director() {
    let visits = 0;
    await overview(false);
    for (;;) {
      if (U.ver < 0) {   // noch keine Fotos: um den Sternenstaub kreisen
        await overview(false);
        continue;
      }
      await visit();
      visits += 1;
      if ((cfg.Overview && visits % 3 === 0) || pending || (cfg.Grouping !== "rotate" && cfg.Grouping !== U.mode && availableModes().includes(cfg.Grouping))) {
        await overview(cfg.Grouping === "rotate" || cfg.Grouping !== U.mode);
      }
    }
  }

  // ------------------------------------------------------------ Daten holen

  function applySettings(s) {
    if (!s) return;
    Object.assign(cfg, s);
    if (params.get("mode")) cfg.Grouping = params.get("mode");
    if (!params.get("lang") && s.Language) lang = s.Language;
  }

  async function poll() {
    try {
      const data = await api(`api/universe?v=${U.ver}`);
      applySettings(data.settings);
      if (data.rating !== undefined && data.ver !== U.ver && data.count > 0) {
        if (U.ver < 0) {
          setUniverse(data);
          useMode(chooseMode(null), false);
        } else {
          pending = data;
        }
      }
      if (!data.count) {
        showNote(data.busy || data.status === "" ? tx("wait") : tx("none"));
        ready();
      } else {
        showNote("");
      }
    } catch (error) {
      showNote(error.message === "login" ? tx("login") : tx("unreachable"));
      ready();
    }
    setTimeout(poll, U.n ? 60000 : 8000);
  }

  // ------------------------------------------------------------ Ausgedachtes Universum (?demo=1)

  function demoData() {
    const r = rng(2024);
    const years = [];
    for (let y = 2009; y <= 2026; y += 1) years.push(String(y));
    const places = ["Lissabon", "München", "Rom", "Kopenhagen", "Hamburg", "Gardasee", "Wien", "Barcelona", "Sylt", "Paris", "Dolomiten", "Amsterdam", "New York", "Prag"];
    const people = ["Anna", "Ben", "Clara", "Jan", "Oma Ilse", "Lukas", "Mia", "Opa Karl", "Noah", "Lea"];
    const n = 9000;
    let rating = "", gy = "", gp = "", gq = "";
    for (let i = 0; i < n; i += 1) {
      const x = r();
      rating += String(x < 0.45 ? 0 : x < 0.6 ? 1 : x < 0.72 ? 2 : x < 0.82 ? 3 : x < 0.92 ? 4 : 5);
      const y = Math.min(years.length - 1, Math.floor(Math.pow(r(), 0.7) * years.length));
      gy += r() < 0.06 ? "." : String.fromCharCode(48 + y);
      const p = Math.floor(Math.pow(r(), 1.8) * places.length);
      gp += r() < 0.35 ? "." : String.fromCharCode(48 + p);
      const q = Math.floor(Math.pow(r(), 1.5) * people.length);
      gq += r() < 0.45 ? "." : String.fromCharCode(48 + q);
    }
    return { ver: 1, count: n, rating, groups: { year: { names: years, g: gy }, place: { names: places, g: gp }, person: { names: people, g: gq } } };
  }

  async function demoPhoto(i) {
    // Eine gemalte Landschaft (Himmel, Sonne, Bergketten, See), je Stern anders
    const canvas = document.createElement("canvas");
    canvas.width = 1500; canvas.height = 1000;
    const c = canvas.getContext("2d");
    const r = rng(i + 11);
    const h = [18, 28, 36, 345, 8][Math.floor(r() * 5)];
    const sky = c.createLinearGradient(0, 0, 0, 640);
    sky.addColorStop(0, `hsl(${228 + r() * 20},45%,${18 + r() * 8}%)`);
    sky.addColorStop(0.62, `hsl(${(h + 350) % 360},55%,${52 + r() * 8}%)`);
    sky.addColorStop(1, `hsl(${h + 20},85%,${70 + r() * 8}%)`);
    c.fillStyle = sky;
    c.fillRect(0, 0, 1500, 1000);
    const sx = 300 + r() * 900, sy = 380 + r() * 160;
    const sun = c.createRadialGradient(sx, sy, 10, sx, sy, 260);
    sun.addColorStop(0, "rgba(255,250,225,1)");
    sun.addColorStop(0.18, "rgba(255,225,170,.9)");
    sun.addColorStop(1, "rgba(255,200,150,0)");
    c.fillStyle = sun;
    c.fillRect(0, 0, 1500, 1000);
    for (let layer = 0; layer < 4; layer += 1) {
      const base = 520 + layer * 70;
      c.fillStyle = `hsl(${236 + layer * 6},${28 - layer * 4}%,${42 - layer * 10}%)`;
      c.beginPath();
      c.moveTo(0, 1000);
      let y = base - r() * 120;
      for (let x = 0; x <= 1500; x += 30) {
        y = clamp(y + (r() - 0.5) * (90 - layer * 15), base - 220 + layer * 40, base + 20);
        c.lineTo(x, y);
      }
      c.lineTo(1500, 1000);
      c.fill();
    }
    const lake = c.createLinearGradient(0, 780, 0, 1000);
    lake.addColorStop(0, `hsl(${h + 10},55%,58%)`);
    lake.addColorStop(1, "hsl(235,35%,14%)");
    c.fillStyle = lake;
    c.fillRect(0, 790, 1500, 210);
    c.fillStyle = "rgba(255,240,210,.35)";
    for (let k = 0; k < 14; k += 1) c.fillRect(sx - 120 + r() * 240, 800 + k * 14, 40 + r() * 120, 3);
    const img = await loadImage(canvas.toDataURL("image/jpeg", 0.88));
    const g = U.groups.year;
    const year = g.of[i] >= 0 ? g.names[g.of[i]] : "2019";
    const placeG = U.groups.place;
    return { info: { w: 1500, h: 1000, taken: `${year}-0${1 + (i % 9)}-1${i % 9}`, place: placeG.of[i] >= 0 ? placeG.names[placeG.of[i]] : "", rating: U.rating[i],
      people: U.groups.person.of[i] >= 0 ? [U.groups.person.names[U.groups.person.of[i]]] : [] }, img };
  }

  // ------------------------------------------------------------ Standbilder für den Store (?shot=)

  async function still() {
    U.mode = params.get("mode") || "year";
    useMode(U.mode, false);
    const lay = layout(U.mode);
    state.fade = want.fade = 1;
    if (SHOT === "overview") {
      cam.pos = [900, 1150, 1250]; cam.look = [0, -60, 0];
      showTitle(tx(U.mode), tx("stars", { n: fmt(U.n) }));
    } else {
      let best = 0;
      lay.centers.forEach((g, j) => { if (g.count > lay.centers[best].count) best = j; });
      const j = Number(params.get("group") || best);
      const g = lay.centers[j];
      activeWant = j;
      state.boost = want.boost = 1.5;
      state.dim = want.dim = 0.7;
      cam.pos = viewpoint(j); cam.look = [g.x, g.y, g.z];
      if (SHOT === "photo" || SHOT === "near") {
        const star = pickStar(j);
        cam.pos = nearStar(star, SHOT === "near" ? 60 : 12);
        cam.look = starPos(star);
        if (SHOT === "photo") {
          const photo = await fetchPhoto(star);
          fillCaption(photo.info, j);
          await openPhoto(star, photo.info, photo.img);
        }
      }
    }
    document.body.dataset.still = "1";
  }

  // ------------------------------------------------------------ Start

  resize();
  buildDecor();
  if (DEMO) {
    setUniverse(demoData());
    useMode(chooseMode(params.get("mode") || null), false);
  } else {
    // Bis die Fotos da sind: Sternenstaub ohne Sternbilder
    const r = rng(3);
    let rating = "";
    for (let i = 0; i < 3000; i += 1) rating += String(Math.floor(Math.pow(r(), 3) * 6));
    setUniverse({ ver: -1, rating, groups: {} });
    useMode("year", false);
  }
  requestAnimationFrame(frame);
  if (SHOT) {
    if (!DEMO) {
      api("api/universe?v=-1").then((data) => {
        applySettings(data.settings);
        setUniverse(data);
        still();
      });
    } else {
      still();
    }
  } else {
    if (!DEMO) poll();
    director();
  }
})();
