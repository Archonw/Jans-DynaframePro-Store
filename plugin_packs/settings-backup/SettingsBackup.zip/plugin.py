#!/usr/bin/env python3
"""Settings Backup - Einstellungen aller Plugins sichern und auf einen anderen
Rahmen übertragen.

Die Plugin-Seite (Plugins > Settings Backup öffnen) hat zwei Teile:
- Sichern: lädt eine Datei mit den Einstellungen aller (oder gewählter)
  Plugins und Szenen herunter. Mit Passwort sind auch Zugangsdaten dabei,
  verschlüsselt; ohne Passwort fehlen sie.
- Zurückspielen: Datei wählen, ansehen, was drin ist und was auf diesem
  Rahmen fehlt, dann die gewünschten Plugins übernehmen. Die Werte der
  Plugins-Seite setzt die Engine sofort, betroffene Plugins werden neu
  gestartet. Plugins, die aus keinem Store kommen, sind samt Code in der
  Sicherung und werden auf dem neuen Rahmen installiert. Was vorher da war,
  wird gemerkt und lässt sich mit "Rückgängig" wiederherstellen.

Die eigentliche Arbeit macht backup.py; hier sind nur die Seite und der Start.
"""

import os
import sys
import traceback
from datetime import datetime

_plugin_dir = os.environ.get("DYNAFRAME_PLUGIN_DIR") or os.path.dirname(os.path.abspath(__file__))
try:
    os.chdir(_plugin_dir)
except Exception:
    pass
_crash_log_path = os.path.join(_plugin_dir, "crash.log")


def _write_crash_log(exc_type, exc_value, exc_tb):
    try:
        with open(_crash_log_path, "a") as f:
            f.write(f"\n=== Crash at {datetime.now().isoformat()} ===\n")
            traceback.print_exception(exc_type, exc_value, exc_tb, file=f)
    except Exception:
        pass
    sys.__excepthook__(exc_type, exc_value, exc_tb)


sys.excepthook = _write_crash_log

import json
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import backup  # noqa: E402
import stores  # noqa: E402

PLUGIN_ID = "SettingsBackup"
PLUGIN_DIR = Path(__file__).resolve().parent
PLUGINS_ROOT = Path(os.environ.get("SETTINGS_BACKUP_PLUGINS_ROOT") or PLUGIN_DIR.parent)
DATA_DIR = PLUGIN_DIR / "data"
SETTINGS_FILE = DATA_DIR / "settings.json"
PENDING_FILE = DATA_DIR / "pending-import.json"
UNDO_DIR = DATA_DIR / "undo"
STUDIO_DIR = PLUGIN_DIR / "studio"
DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
LANGUAGES = ("de", "en", "es")
CONNECT_TIMEOUT = 4
READ_TIMEOUT = 15

WEBUI_URL = os.environ.get("SETTINGS_BACKUP_WEBUI", "http://127.0.0.1").rstrip("/")
INSTALL_TIMEOUT = 900

plugin = create_plugin()
_lock = threading.Lock()
_pending = {"payload": None, "summary": None, "result": None}
_packs = {"running": False, "total": 0, "done": [], "current": ""}


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return ""


# --------------------------------------------------------------------------
# Engine
# --------------------------------------------------------------------------

def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))
    if response.status_code >= 400:
        raise RuntimeError(f"{method} {path} returned HTTP {response.status_code}")
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def webui_call(method, path, payload=None, params=None):
    """Die Weboberfläche des Rahmens (Port 80): dort sitzt der Store."""
    slow = path.startswith("/Store/DownloadAndInstall") or path == "/Store/DownloadPack"
    response = requests.request(method, WEBUI_URL + path, json=payload, params=params,
                                headers={"Content-Type": "application/json", "Accept": "application/json"},
                                timeout=(CONNECT_TIMEOUT, INSTALL_TIMEOUT if slow else 60))
    try:
        body = response.json()
    except ValueError:
        body = None
    if response.status_code >= 400:
        message = body.get("error") or body.get("message") if isinstance(body, dict) else ""
        raise RuntimeError(message or f"{method} {path} returned HTTP {response.status_code}")
    return body


def log_engine_endpoints():
    """Einmal beim Start: welche Plugin- und Einstellungs-Endpunkte die Engine hat.
    Hilft später beim Neustarten einzelner Plugins nach dem Zurückspielen."""
    for path in ("/swagger/v1/swagger.json", "/openapi/v1.json"):
        try:
            spec = engine_call("GET", path)
        except Exception:
            continue
        if isinstance(spec, dict) and isinstance(spec.get("paths"), dict):
            found = sorted(p for p in spec["paths"] if re.search(r"plugin|setting|backup", p, re.I))
            plugin.log("Engine endpoints for plugins/settings: " + (", ".join(found) or "none"))
            return


# --------------------------------------------------------------------------
# Eigene Einstellung: nur die Sprache
# --------------------------------------------------------------------------

def language():
    stored = backup.read_json(SETTINGS_FILE, {}) or {}
    value = str(stored.get("Language") or "de").lower()
    return value if value in LANGUAGES else "de"


def save_language(value):
    value = str(value or "").lower()
    if value in LANGUAGES:
        stored = backup.read_json(SETTINGS_FILE, {}) or {}
        stored["Language"] = value
        backup.write_json(SETTINGS_FILE, stored, indent=1)
    return {"success": True, "settings": {"Language": language()}}


# --------------------------------------------------------------------------
# Was die Seite tun kann
# --------------------------------------------------------------------------

def overview():
    plugins = [backup.describe_plugin(name, folder, manifest)
               for name, folder, manifest in backup.list_plugins(PLUGINS_ROOT, PLUGIN_ID)]
    scenes = [{"id": key, "name": name} for key, name, _row in backup.list_scenes(engine_call)]
    return {"plugins": plugins, "scenes": scenes}


def state():
    with _lock:
        pending = _pending["summary"]
        result = _pending["result"]
    with _lock:
        packs = dict(_packs, done=list(_packs["done"]))
    return {
        "success": True,
        "packJob": packs,
        "settings": {"Language": language()},
        "version": version(),
        "frame": backup.hostname(),
        "theme": {"id": theme_id()},
        "pending": pending,
        "lastResult": result,
        "undoAt": backup.undo_available(UNDO_DIR),
    }


def action_export(body):
    password = str(body.get("password") or "")
    only = body.get("plugins")
    only = {str(n) for n in only} if isinstance(only, list) else None
    extra = {"storePacks": stores.installed_packs(webui_call) or [], "stores": stores.list_stores(webui_call)}
    made = backup.create_backup(PLUGINS_ROOT, PLUGIN_ID, engine_call, password=password, only=only,
                                with_scenes=body.get("scenes", True) is not False,
                                tool=f"Settings Backup {version()}", with_code=body.get("code", True) is not False,
                                extra=extra)
    plugin.log(f"Backup made: {made['plugins']} plugins, {made['scenes']} scenes, "
               f"{'encrypted with secrets' if made['encrypted'] else 'without secrets'}, "
               f"code of {made['withCode']} non-store plugins, {len(extra['storePacks'])} store packs listed, "
               f"{made['bytes']} bytes")
    return {"success": True, **made}


def summarize(payload):
    summary = backup.summarize(payload, PLUGINS_ROOT, PLUGIN_ID, engine_call)
    summary["packs"] = stores.missing_packs(payload, webui_call)
    summary["stores"] = stores.missing_stores(payload, webui_call) if summary["packs"] is not None else []
    return summary


def _keep_pending(payload):
    summary = summarize(payload)
    with _lock:
        _pending.update(payload=payload, summary=summary, result=None)
    try:
        backup.write_json(PENDING_FILE, payload, indent=None)
        os.chmod(PENDING_FILE, 0o600)
    except OSError as exc:
        plugin.log(f"Could not keep the opened backup: {exc}", level="warning")
    return summary


def action_inspect(body):
    payload = backup.open_backup(str(body.get("content") or ""), str(body.get("password") or ""))
    summary = _keep_pending(payload)
    plugin.log(f"Backup opened from {summary['frame'] or 'unknown frame'} ({summary['createdAt']}): "
               f"{len(summary['plugins'])} plugins, {len(summary['scenes'])} scenes")
    return {"success": True, "pending": summary}


def action_apply(body):
    with _lock:
        payload = _pending["payload"]
    if payload is None:
        raise backup.BackupError("no-pending")
    names = body.get("plugins")
    scenes = body.get("scenes")
    result = backup.apply_backup(
        payload, PLUGINS_ROOT, PLUGIN_ID, engine_call, UNDO_DIR,
        names={str(n) for n in names} if isinstance(names, list) else None,
        scene_ids={str(s) for s in scenes} if isinstance(scenes, list) else None,
        set_enabled=bool(body.get("setEnabled")))
    for row in result["plugins"]:
        plugin.log(f"Restore {row['name']}: {row['status']}"
                   + (f", {row['files']} files, {row['settings']} settings, "
                      f"{'live' if row.get('live') else 'needs a DynaFrame restart'}"
                      if row["status"] in ("done", "installed") else "")
                   + (f" ({row['error']})" if row.get("error") else ""))
    for row in result["scenes"]:
        plugin.log(f"Restore scene {row['id']}: {row['status']}")
    summary = summarize(payload)
    with _lock:
        _pending.update(summary=summary, result=result)
    return {"success": True, "result": result, "pending": summary}


def _install_packs(packs, store_list, payload):
    cache, added = {}, set()
    for store in store_list:
        with _lock:
            _packs["current"] = store["name"]
        try:
            ok, error = stores.add_store(webui_call, store), ""
        except Exception as exc:  # noqa: BLE001
            ok, error = False, str(exc)
        added.add(stores._norm(store["manifestUrl"]))
        plugin.log(f"Add store {store['name']} ({store['manifestUrl']}): " + ("done" if ok else f"failed ({error})"))
        with _lock:
            _packs["done"].append({"packId": "store:" + store["manifestUrl"], "title": store["name"], "ok": ok,
                                   "version": "", "error": error})
    for pack in packs:
        stores.ensure_store(webui_call, payload, pack["sourceStore"], added)
        with _lock:
            _packs["current"] = pack["title"]
        plugin.log(f"Installing {pack['type']} '{pack['title']}' ({pack['packId']}) from {pack['sourceStore']}")
        try:
            ok, got, error = stores.install_pack(webui_call, pack, cache)
        except Exception as exc:  # noqa: BLE001
            ok, got, error = False, "", str(exc)
        plugin.log(f"Install {pack['packId']}: " + (f"done, version {got}" if ok else f"failed ({error})"),
                   level="info" if ok else "warning")
        with _lock:
            _packs["done"].append({"packId": pack["packId"], "title": pack["title"], "ok": ok, "version": got,
                                   "error": error})
    with _lock:
        payload = _pending["payload"]
    summary = summarize(payload) if payload else None
    with _lock:
        _packs.update(running=False, current="")
        if payload is _pending["payload"]:
            _pending["summary"] = summary


def action_install_packs(body):
    with _lock:
        payload = _pending["payload"]
        busy = _packs["running"]
    if payload is None:
        raise backup.BackupError("no-pending")
    if busy:
        raise backup.BackupError("busy")
    wanted = {str(p).lower() for p in body.get("packs") or []}
    missing = stores.missing_packs(payload, webui_call)
    if missing is None:
        raise backup.BackupError("no-store")
    chosen = [p for p in missing if p["packId"].lower() in wanted and p["supported"]]
    wanted_stores = {stores._norm(u) for u in body.get("stores") or []}
    store_list = [s for s in stores.missing_stores(payload, webui_call) if stores._norm(s["manifestUrl"]) in wanted_stores]
    if not chosen and not store_list:
        raise backup.BackupError("nothing")
    with _lock:
        _packs.update(running=True, total=len(chosen) + len(store_list), done=[], current="")
    threading.Thread(target=_install_packs, args=(chosen, store_list, payload), name="install-packs", daemon=True).start()
    return {"success": True, "started": len(chosen) + len(store_list)}


def action_undo(_body):
    result = backup.undo_last(PLUGINS_ROOT, PLUGIN_ID, engine_call, UNDO_DIR)
    plugin.log(f"Restore undone: {result['restored']} files/scenes back as before")
    with _lock:
        _pending["result"] = None
    return {"success": True, **result}


def action_discard(_body):
    with _lock:
        _pending.update(payload=None, summary=None, result=None)
    try:
        PENDING_FILE.unlink()
    except OSError:
        pass
    return {"success": True}


def load_pending():
    payload = backup.read_json(PENDING_FILE)
    if isinstance(payload, dict) and payload.get("format") == backup.FORMAT:
        try:
            summary = summarize(payload)
        except Exception:
            return
        with _lock:
            _pending.update(payload=payload, summary=summary)


# --------------------------------------------------------------------------
# Die Seite
# --------------------------------------------------------------------------

def theme_id():
    stored = backup.read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def _page_html():
    html = (STUDIO_DIR / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio.js", "application/javascript; charset=utf-8"),
}
POST_ACTIONS = {
    "/api/settings": lambda body: save_language(body.get("Language")),
    "/api/export": action_export,
    "/api/inspect": action_inspect,
    "/api/apply": action_apply,
    "/api/undo": action_undo,
    "/api/install-packs": action_install_packs,
    "/api/discard": action_discard,
}
MAX_BODY = 80 * 1024 * 1024


class _Handler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        pass

    def _send(self, body, content_type, status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8", status)

    def _body(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length > MAX_BODY:
            raise backup.BackupError("too-large")
        # Immer ganz lesen: ungelesene Bytes landen sonst in der nächsten Anfrage.
        raw = self.rfile.read(length) if length > 0 else b""
        try:
            body = json.loads(raw.decode("utf-8")) if raw else {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                self._send(_page_html().encode("utf-8"), "text/html; charset=utf-8")
            elif path in STUDIO_FILES:
                name, kind = STUDIO_FILES[path]
                self._send((STUDIO_DIR / name).read_bytes(), kind)
            elif path == "/api/state":
                self._json(state())
            elif path == "/api/overview":
                self._json({"success": True, **overview()})
            else:
                self._json({"success": False, "error": "Not found"}, 404)
        except Exception as exc:
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        try:
            body = self._body()
            action = POST_ACTIONS.get(path)
            if action is None:
                self._json({"success": False, "error": "Not found"}, 404)
            else:
                self._json(action(body))
        except backup.BackupError as exc:
            self._json({"success": False, "code": exc.code, "error": str(exc)})
        except Exception as exc:
            plugin.log(f"{path} failed: {exc}", level="error")
            self._json({"success": False, "error": str(exc)}, 500)


_server = None


def start_page():
    global _server
    try:
        _server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        threading.Thread(target=_server.serve_forever, name="settings-page", daemon=True).start()
        url = f"http://127.0.0.1:{_server.server_address[1]}/"
        plugin.register_advanced_settings_page(url)
        plugin.log(f"Plugin page at {url}")
    except Exception as exc:
        plugin.log(f"Plugin page not available: {exc}", level="warning")


def stop_page():
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if _server is not None:
        try:
            _server.shutdown()
            _server.server_close()
        except Exception:
            pass


def main():
    DATA_DIR.mkdir(exist_ok=True)
    start_page()
    plugin.connect_sse()
    plugin.ready()
    plugin.log(f"Settings Backup {version()} started")
    load_pending()
    threading.Thread(target=log_engine_endpoints, name="engine-endpoints", daemon=True).start()
    try:
        while plugin.is_running():
            time.sleep(1)
    finally:
        stop_page()


if __name__ == "__main__":
    main()
