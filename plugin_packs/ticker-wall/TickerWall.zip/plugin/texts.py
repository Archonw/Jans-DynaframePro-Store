"""Texts of the plugin in German, English and Spanish.

The German text is also the key. t() looks up the translation in the chosen
language and fills in the placeholders; without a translation the German
text stays.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    '{symbol}: Devisen bitte als EURUSD=X schreiben': (
        '{symbol}: please write currencies like EURUSD=X',
        '{symbol}: escribe las divisas como EURUSD=X'),
    'Für Aktienkurse fehlt noch der kostenlose Finnhub-Schlüssel.': (
        'Stock prices need the free Finnhub key.',
        'Para las cotizaciones falta la clave gratuita de Finnhub.'),
    'Angelegt: die Playlist Ticker Wall steht unter Playlists.': (
        'Created: the Ticker Wall playlist is listed under Playlists.',
        'Creada: la lista Ticker Wall aparece en Playlists.'),
    'Ausgelöst auf der Plugin-Seite': (
        'Triggered on the plugin page',
        'Activada en la página del plugin'),
    'Außerhalb von {start}–{end} Uhr.': (
        'Outside {start}:00–{end}:00.',
        'Fuera de las {start}–{end} h.'),
    'Bitte den Rahmen um den Bildschirm.': (
        'Asking the frame for the screen.',
        'Pidiendo la pantalla al marco.'),
    'BÖRSENSTART': (
        'MARKET OPEN',
        'APERTURA DE MERCADO'),
    'CRASH-ALARM': (
        'CRASH ALERT',
        'ALERTA DE CAÍDA'),
    'Der Bildschirm ist aus. Ticker Wall weckt ihn nicht.': (
        'The screen is off. Ticker Wall does not wake it.',
        'La pantalla está apagada. Ticker Wall no la enciende.'),
    'Der Rahmen hat Ticker Wall nicht rechtzeitig angezeigt.': (
        'The frame did not show Ticker Wall in time.',
        'El marco no ha mostrado Ticker Wall a tiempo.'),
    'Der Rahmen hat die Anzeige beendet ({state}).': (
        'The frame ended the display ({state}).',
        'El marco ha terminado la visualización ({state}).'),
    'Der Rahmen hat die Playlist {name} nicht angelegt.': (
        'The frame did not create the playlist {name}.',
        'El marco no ha creado la lista {name}.'),
    'Der Rahmen ist nach Ticker Wall nicht zu deiner Playlist zurückgekehrt. Starte sie auf der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix passiert das nicht.': (
        "The frame did not return to your playlist after Ticker Wall. Start it again on the frame's home page. With a saved playlist instead of a Quick Mix this does not happen.",
        'El marco no ha vuelto a tu lista después de Ticker Wall. Vuelve a iniciarla en la página principal del marco. Con una lista guardada en lugar de un Quick Mix esto no pasa.'),
    'Die Playlist wurde gelöscht, deshalb steht das wieder auf Nein.': (
        'The playlist was deleted, so this is set back to No.',
        'La lista se ha borrado, por eso vuelve a estar en No.'),
    'Die Szene Ticker Wall ist auf der Plugins-Seite ausgeschaltet.': (
        'The Ticker Wall scene is switched off on the Plugins page.',
        'La escena Ticker Wall está desactivada en la página de plugins.'),
    'Die Szene Ticker Wall ist auf diesem Rahmen nicht installiert. Installiere das Ticker-Wall-Paket noch einmal.': (
        'The Ticker Wall scene is not installed on this frame. Install the Ticker Wall package again.',
        'La escena Ticker Wall no está instalada en este marco. Vuelve a instalar el paquete Ticker Wall.'),
    'Die Szene Ticker Wall wurde nicht gefunden.': (
        'The Ticker Wall scene was not found.',
        'No se ha encontrado la escena Ticker Wall.'),
    'Die Takeover-Playlist ist noch nicht angelegt.': (
        'The takeover playlist has not been created yet.',
        'La lista de takeover aún no se ha creado.'),
    'Die früher angelegte Playlist steht noch unter Playlists; das Plugin pflegt sie nicht mehr.': (
        'The playlist created earlier is still under Playlists; the plugin no longer maintains it.',
        'La lista creada antes sigue en Playlists; el plugin ya no la mantiene.'),
    'Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.': (
        'This frame is too old to hand the screen to a plugin.',
        'Este marco es demasiado antiguo para ceder la pantalla a un plugin.'),
    'EILMELDUNG': (
        'BREAKING NEWS',
        'ÚLTIMA HORA'),
    'EILMELDUNG: {term}': (
        'BREAKING: {term}',
        'ÚLTIMA HORA: {term}'),
    'ERDBEBEN M{mag}': (
        'EARTHQUAKE M{mag}',
        'TERREMOTO M{mag}'),
    'Etwas anderes hat gerade den Bildschirm.': (
        'Something else has the screen right now.',
        'Otra cosa está usando la pantalla ahora mismo.'),
    'Gebe den Bildschirm zurück.': (
        'Handing the screen back.',
        'Devolviendo la pantalla.'),
    'KURSALARM': (
        'PRICE ALERT',
        'ALERTA DE PRECIO'),
    'KURSRUTSCH': (
        'STOCK PLUNGE',
        'DESPLOME'),
    'KURSSPRUNG': (
        'STOCK SURGE',
        'SUBIDA FUERTE'),
    'Konnte Ticker Wall nicht anzeigen: {exc}': (
        'Could not show Ticker Wall: {exc}',
        'No se pudo mostrar Ticker Wall: {exc}'),
    'Konnte die Playlist Ticker Wall nicht pflegen: {exc}': (
        'Could not maintain the Ticker Wall playlist: {exc}',
        'No se pudo mantener la lista Ticker Wall: {exc}'),
    'Konnte die Takeover-Playlist nicht anlegen: {exc}': (
        'Could not create the takeover playlist: {exc}',
        'No se pudo crear la lista de takeover: {exc}'),
    'Kurs {price} {cur}': (
        'Price {price} {cur}',
        'Precio {price} {cur}'),
    'Kurs {price} {cur} ({rule})': (
        'Price {price} {cur} ({rule})',
        'Precio {price} {cur} ({rule})'),
    'Lese alle Quellen jetzt neu.': (
        'Reading all sources again now.',
        'Leyendo todas las fuentes de nuevo.'),
    'Noch keine Schlagzeilen': (
        'No headlines yet',
        'Aún no hay titulares'),
    'Noch nicht angelegt; das passiert innerhalb einer Minute.': (
        'Not created yet; this happens within a minute.',
        'Todavía no creada; se creará en menos de un minuto.'),
    'RALLYE': (
        'RALLY',
        'RALLY'),
    'Regelmäßige Anzeige ist aus.': (
        'Regular display is off.',
        'La visualización periódica está desactivada.'),
    'SCHLAGWORT: {word}': (
        'KEYWORD: {word}',
        'PALABRA CLAVE: {word}'),
    'So sieht ein Alarm auf der Ticker Wall aus': (
        'This is what an alert looks like on the Ticker Wall',
        'Así se ve una alerta en Ticker Wall'),
    'Stand {price}': (
        'At {price}',
        'En {price}'),
    'TESTALARM': (
        'TEST ALERT',
        'ALERTA DE PRUEBA'),
    'Testalarm ausgelöst.': (
        'Test alert triggered.',
        'Alerta de prueba activada.'),
    'Ticker Wall hatte den Bildschirm nicht.': (
        'Ticker Wall did not have the screen.',
        'Ticker Wall no tenía la pantalla.'),
    'Ticker Wall ist auf der Plugins-Seite ausgeschaltet.': (
        'Ticker Wall is switched off on the Plugins page.',
        'Ticker Wall está desactivado en la página de plugins.'),
    'Ticker Wall ist schon auf dem Bildschirm.': (
        'Ticker Wall is already on screen.',
        'Ticker Wall ya está en pantalla.'),
    'Ticker Wall läuft gerade in deiner Playlist; die Anzeige bleibt so.': (
        'Ticker Wall is playing in your playlist right now; the display stays as it is.',
        'Ticker Wall se está mostrando ahora en tu lista; la pantalla se queda así.'),
    'Tsunami-Hinweis': (
        'Tsunami information',
        'Aviso de tsunami'),
    'Wartet, bis der Bildschirm wieder frei ist.': (
        'Waiting until the screen is free again.',
        'Esperando a que la pantalla vuelva a estar libre.'),
    '{name} eröffnet den Handel': (
        '{name} opens for trading',
        '{name} abre la sesión'),
    '{name} hat nicht geklappt: {exc}': (
        '{name} did not work: {exc}',
        '{name} no ha funcionado: {exc}'),
    '{n} Quellen melden das gerade': (
        '{n} sources are reporting this right now',
        '{n} fuentes lo informan ahora'),
    '{pct} heute': (
        '{pct} today',
        '{pct} hoy'),
    '„Allow takeover“ ist für Ticker Wall auf der Plugins-Seite aus, deshalb kann es den Bildschirm nicht übernehmen.': (
        '“Allow takeover” is off for Ticker Wall on the Plugins page, so it cannot take over the screen.',
        '«Allow takeover» está desactivado para Ticker Wall en la página de plugins, así que no puede ocupar la pantalla.'),
}


def language(value):
    value = str(value or "").strip().lower()
    return value if value in LANGUAGES else "en"


def t(lang, template, **values):
    lang = language(lang)
    text = template
    if lang != "de":
        pair = _TEXTS.get(template)
        if pair:
            text = pair[LANGUAGES.index(lang) - 1]
    return text.format(**values) if values else text
