"""Die Datenquelle von Biathlon Live: die öffentliche Schnittstelle von
biathlonresults.com (IBU Datacenter), dieselbe wie im MagicMirror-Modul
MMM-Biathlon von 2hdlockness (MIT).

  Events?SeasonId=2627&Level=ALL   Weltcup-Stationen, WM, IBU-Cup ... einer Saison
  Competitions?EventId=...         die Rennen einer Station
  Results?RaceId=...               Ergebnis (im Rennen: der Zwischenstand)
  Cups?SeasonId=... / CupResults?CupId=...   Gesamtwertungen

Kein Konto. Seit November 2026 verlangt die Schnittstelle allerdings einen
Kopf "apikey". Der Schlüssel ist öffentlich: die Website selbst setzt ihn als
window.ApiKey in ihrem App-Skript. Das Plugin liest ihn dort aus, merkt ihn
sich und holt ihn bei HTTP 401 neu (Vorgehen wie im Hotfix von
prtkv/biathlonresults, MIT). Mit BIATHLON_API_KEY lässt er sich vorgeben.

Die Antworten werden hier in eine kleine, feste
Form gebracht, damit Plugin und Szene nicht an den Feldnamen der IBU hängen.
"""

import os
import re
import time
from datetime import datetime, timezone

import requests

API = os.environ.get("BIATHLON_API_URL", "https://biathlonresults.com/modules/sportapi/api/").rstrip("/") + "/"
SITE = os.environ.get("BIATHLON_SITE_URL", "https://biathlonresults.com/").rstrip("/") + "/"
BROWSER_HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"),
    "Accept-Language": "en-US,en;q=0.9,de;q=0.8",
    "sec-ch-ua": '"Chromium";v="131", "Not_A Brand";v="24", "Google Chrome";v="131"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
}
HTTP_HEADERS = dict(BROWSER_HEADERS, **{"Accept": "application/json, text/plain, */*",
                                        "Origin": SITE.rstrip("/"), "Referer": SITE})
TIMEOUT = (10, 30)
KEY_PATTERN = re.compile(r"""ApiKey["']?\s*[=:]\s*["']([0-9a-fA-F-]{36})["']""")
# Die Seite schreibt src auch ohne Anführungszeichen (src=/js/app.123.js).
SCRIPT_PATTERN = re.compile(r"""<script[^>]*\ssrc\s*=\s*["']?([^"'\s>]+)""", re.I)
KEY_RETRY_SECONDS = 300

_ENV_KEY = os.environ.get("BIATHLON_API_KEY", "").strip()
_key = {"value": _ENV_KEY, "fixed": bool(_ENV_KEY), "checked": 0.0, "error": ""}


class SourceError(Exception):
    pass


def _site_get(url):
    response = requests.get(url, headers=dict(BROWSER_HEADERS, Accept="text/html,application/javascript,*/*;q=0.8"),
                            timeout=TIMEOUT)
    response.raise_for_status()
    return response.text


def find_api_key():
    """Liest den öffentlichen Schlüssel aus der Startseite oder ihren Skripten."""
    page = _site_get(SITE)
    match = KEY_PATTERN.search(page)
    if match:
        return match.group(1)
    scripts = []
    for src in SCRIPT_PATTERN.findall(page):
        url = requests.compat.urljoin(SITE, src)
        if url not in scripts and ".js" in url.lower():
            scripts.append(url)
    # Das App-Skript zuerst, dort steht der Schlüssel bisher.
    scripts.sort(key=lambda url: 0 if "app" in url.rsplit("/", 1)[-1].lower() else 1)
    _key["scripts"] = len(scripts)
    for url in scripts[:40]:
        try:
            match = KEY_PATTERN.search(_site_get(url))
        except requests.RequestException:
            continue
        if match:
            return match.group(1)
    return ""


def api_key(refresh=False):
    """Schlüssel aus dem Speicher; neu geholt, wenn keiner da ist oder er abgelehnt wurde.
    Fehlversuche höchstens alle KEY_RETRY_SECONDS, damit die Website nicht dauernd geladen wird."""
    if _key["fixed"]:
        return _key["value"]
    if (refresh or not _key["value"]) and time.time() - _key["checked"] >= (30 if _key["value"] else KEY_RETRY_SECONDS) or not _key["checked"]:
        _key["checked"] = time.time()
        try:
            found = find_api_key()
            _key["error"] = "" if found else f"Schlüssel nicht auf biathlonresults.com gefunden, {_key.get('scripts', 0)} Skripte geprüft"
        except requests.RequestException as exc:
            found, _key["error"] = "", f"Schlüssel nicht abrufbar: {exc}"
        if found:
            _key["value"] = found
    return _key["value"]


def _request(method, params, key):
    headers = dict(HTTP_HEADERS, **{"Cache-Control": "no-cache", "Pragma": "no-cache"})
    if key:
        headers["apikey"] = key
    # Ohne eindeutigen Parameter kam für Results stundenlang eine alte,
    # zwischengespeicherte Antwort zurück (Startliste, "Running", während die
    # Website längst das Ergebnis zeigte). Darum wie im Browser "_=<ms>".
    params = dict(params, _=str(int(time.time() * 1000)))
    try:
        return requests.get(API + method, params=params, headers=headers, timeout=TIMEOUT)
    except requests.RequestException as exc:
        raise SourceError(f"biathlonresults.com nicht erreichbar: {exc}") from exc


def get(method, **params):
    key = api_key()
    response = _request(method, params, key)
    if response.status_code in (401, 403):
        fresh = api_key(refresh=True)
        if fresh and fresh != key:
            response = _request(method, params, fresh)
    if response.status_code >= 400:
        hint = ""
        if response.status_code in (401, 403):
            hint = "; Schlüssel abgelehnt" if _key["value"] else f"; {_key['error'] or 'kein Schlüssel'}"
        raise SourceError(f"biathlonresults.com lieferte HTTP {response.status_code} ({method}{hint})")
    try:
        return response.json()
    except ValueError as exc:
        raise SourceError(f"biathlonresults.com lieferte kein JSON ({method})") from exc


# --------------------------------------------------------------------------
# Serien (EventClassificationId, wie in MMM-Biathlon)
# --------------------------------------------------------------------------

# id -> Namen (de, en, es), Farbe, ob es eine Gesamtwertung gibt
SERIES = {
    "BTSWRLCP": {"names": ("BMW IBU Weltcup", "BMW IBU World Cup", "Copa del Mundo BMW IBU"), "color": "#1f6feb", "cup": True},
    "BTSWRLCH": {"names": ("Biathlon-WM", "World Championships", "Campeonato del Mundo"), "color": "#c8102e", "cup": False},
    "BTSIBUCP": {"names": ("IBU-Cup", "IBU Cup", "Copa IBU"), "color": "#0f9d8a", "cup": True},
    "BTSCEUCH": {"names": ("Europameisterschaften", "European Championships", "Campeonato de Europa"), "color": "#7c4dff", "cup": False},
    "BTJIBUCP": {"names": ("IBU Junior Cup", "IBU Junior Cup", "Copa IBU júnior"), "color": "#e08a00", "cup": True},
    "BTJWRLCH": {"names": ("Jugend-/Junioren-WM", "Youth/Junior World Championships", "Mundial júnior y juvenil"), "color": "#d6336c", "cup": False},
    "BTJCEUCH": {"names": ("Junioren-EM", "Junior European Championships", "Europeo júnior"), "color": "#9c36b5", "cup": False},
    "SBSWRLCH": {"names": ("Sommerbiathlon-WM", "Summer Biathlon World Championships", "Mundial de biatlón de verano"), "color": "#f59f00", "cup": False},
    "BTSWRLUG": {"names": ("Universiade", "World University Games", "Universiada"), "color": "#1c7ed6", "cup": False},
    "BTJCEUOF": {"names": ("EYOF", "European Youth Olympic Festival", "Festival Olímpico de la Juventud Europea"), "color": "#2f9e44", "cup": False},
}
DEFAULT_SERIES = ["BTSWRLCP", "BTSWRLCH"]
LANGS = ("de", "en", "es")


def series_name(series_id, lang):
    row = SERIES.get(series_id)
    if not row:
        return series_id
    return row["names"][LANGS.index(lang) if lang in LANGS else 0]


def season_id(moment=None):
    """Die Saison läuft von Herbst bis Frühjahr: im Oktober 2026 ist es 2627."""
    moment = moment or datetime.now()
    start = moment.year if moment.month >= 7 else moment.year - 1
    return f"{start % 100:02d}{(start + 1) % 100:02d}"


def previous_season(season):
    start = int(season[:2])
    return f"{(start - 1) % 100:02d}{start:02d}"


def parse_time(text):
    """ISO-Zeit der IBU ("2026-11-29T11:15:00Z", Daten auch ohne Zone) als epoch."""
    text = str(text or "").strip()
    if not text:
        return 0
    try:
        moment = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return 0
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    return moment.timestamp()


# --------------------------------------------------------------------------
# Stationen und Rennen
# --------------------------------------------------------------------------

def fetch_events(season):
    rows = get("Events", SeasonId=season, Level="ALL")
    if not isinstance(rows, list):
        raise SourceError("Unerwartete Antwort auf Events")
    events = []
    for row in rows:
        if not isinstance(row, dict) or not row.get("EventId"):
            continue
        events.append({
            "id": str(row["EventId"]),
            "series": str(row.get("EventClassificationId") or ""),
            "place": str(row.get("ShortDescription") or row.get("Organizer") or ""),
            "description": str(row.get("Description") or ""),
            "nat": str(row.get("Nat") or "")[:3].upper(),
            "start": parse_time(row.get("StartDate")),
            # Enddatum ohne Uhrzeit: der ganze Tag gehört noch dazu.
            "end": parse_time(row.get("EndDate")) + 86399,
        })
    events.sort(key=lambda e: e["start"])
    return events


# Kategorie und Disziplin stehen in den letzten vier Zeichen der RaceId:
# BT2425SWRLCP01SWSI = Frauen (SW), verkürztes Einzel (SI).
CATEGORIES = {
    "SW": ("Frauen", "Women", "Femenino"), "SM": ("Männer", "Men", "Masculino"),
    "MX": ("Mixed", "Mixed", "Mixto"),
    "JW": ("Juniorinnen", "Junior women", "Júnior femenino"), "JM": ("Junioren", "Junior men", "Júnior masculino"),
    "JX": ("Junioren Mixed", "Junior mixed", "Júnior mixto"),
    "YW": ("Jugend weiblich", "Youth women", "Juvenil femenino"), "YM": ("Jugend männlich", "Youth men", "Juvenil masculino"),
    "YX": ("Jugend Mixed", "Youth mixed", "Juvenil mixto"),
}
DISCIPLINES = {
    "SP": ("Sprint", "Sprint", "Sprint"),
    "PU": ("Verfolgung", "Pursuit", "Persecución"),
    "IN": ("Einzel", "Individual", "Individual"),
    "SI": ("Verkürztes Einzel", "Short Individual", "Individual corto"),
    "MS": ("Massenstart", "Mass Start", "Salida en masa"),
    "RL": ("Staffel", "Relay", "Relevos"),
    "SR": ("Single-Mixed-Staffel", "Single Mixed Relay", "Relevo mixto simple"),
    "SS": ("Super Sprint", "Super Sprint", "Super sprint"),
    "SF": ("Super Sprint Finale", "Super Sprint Final", "Final de super sprint"),
    "SQ": ("Super Sprint Quali", "Super Sprint Qualification", "Clasificación super sprint"),
}
RELAYS = {"RL", "SR"}


def race_codes(race_id):
    tail = str(race_id or "")[-4:].upper()
    return tail[:2], tail[2:]


def race_name(race, lang):
    """"Sprint 7,5 km · Frauen" aus den Codes, sonst der Name der IBU."""
    cat, disc = race.get("category"), race.get("discipline")
    i = LANGS.index(lang) if lang in LANGS else 0
    if disc not in DISCIPLINES or cat not in CATEGORIES:
        return race.get("raw") or race.get("id") or ""
    name = DISCIPLINES[disc][i]
    if disc == "RL" and cat == "MX":
        name = ("Mixed-Staffel", "Mixed Relay", "Relevo mixto")[i]
    km = race.get("km") or ""
    if km and lang in ("de", "es"):
        km = km.replace(".", ",")
    parts = [f"{name} {km}".strip()]
    if not (disc == "SR" or (disc == "RL" and cat == "MX")):
        parts.append(CATEGORIES[cat][i])
    elif cat != "MX":
        parts.append(CATEGORIES[cat][i])
    return " · ".join(parts)


DISTANCE = re.compile(r"(\d+\s*x\s*)?(\d+(?:[.,]\d+)?)\s*km", re.I)


def fetch_competitions(event_id):
    rows = get("Competitions", EventId=event_id)
    if not isinstance(rows, list):
        raise SourceError("Unerwartete Antwort auf Competitions")
    races = []
    for row in rows:
        if not isinstance(row, dict) or not row.get("RaceId"):
            continue
        raw = str(row.get("ShortDescription") or row.get("Description") or "")
        cat, disc = race_codes(row["RaceId"])
        distance = DISTANCE.search(raw)
        km = ""
        if distance:
            km = (distance.group(1) or "").replace(" ", "").replace("x", "×") + distance.group(2) + " km"
        races.append({
            "id": str(row["RaceId"]), "event": event_id, "start": parse_time(row.get("StartTime")),
            "raw": raw, "category": cat, "discipline": disc, "km": km,
            "relay": disc in RELAYS,
            "status": str(row.get("StatusText") or ""),
            "isLive": bool(row.get("IsLive")),
        })
    races.sort(key=lambda r: r["start"])
    return races


# --------------------------------------------------------------------------
# Ergebnisse
# --------------------------------------------------------------------------

IRM = {"DNF", "DNS", "DSQ", "LAP", "DNE", "OTL"}


def as_rank(value):
    try:
        return int(str(value).strip().rstrip("."))
    except (TypeError, ValueError):
        return None


def person_name(name):
    """"BOE Johannes Thingnes" -> ("Johannes Thingnes Boe", "J. Boe")."""
    text = str(name or "").strip()
    words = text.split()
    family = []
    for word in words:
        letters = re.sub(r"[^\w]", "", word)
        if letters and letters.isupper():
            family.append(word)
        else:
            break
    if not family:
        return text, text
    nice = " ".join("-".join(p[:1].upper() + p[1:].lower() for p in w.split("-")) for w in family)
    given = words[len(family):]
    if not given:
        return nice, nice
    return f"{' '.join(given)} {nice}", f"{given[0][:1]}. {nice}"


def shootings(text):
    """"0+1+0+0" -> [0, 1, 0, 0]. Staffeln ("0+2 1+3": Strafrunden+Nachlader)
    bekommen keine Liste; dort zeigt die Szene den Text."""
    text = str(text or "").strip()
    if not re.fullmatch(r"\d+(\+\d+){1,7}", text):
        return []
    return [int(x) for x in text.split("+")]


# Zielzeiten haben Zehntel ("48:12.3", "1:02:03.4", "+1:02.3"); Startzeiten
# in der Startliste ("17:15:30") nicht.
FINISH_TIME = re.compile(r"^\+?(\d+:)?\d{1,2}:\d{2}[.,]\d$|^\d{1,2}[.,]\d$")

# Die letzten Rohantworten je Rennen, für /api/raw (Fehlersuche).
RAW = {}


def finish_seconds(text):
    text = str(text or "").strip().lstrip("+").replace(",", ".")
    if not FINISH_TIME.match(text):
        return None
    total = 0.0
    for part in text.split(":"):
        total = total * 60 + float(part)
    return total


def parse_rows(rows, relay):
    if relay:
        teams = [r for r in rows if r.get("IsTeam") is True]
        if teams:
            rows = teams
        else:
            # Ohne IsTeam: je Platz nur die erste Zeile (wie MMM-Biathlon)
            seen, teams = set(), []
            for r in rows:
                key = r.get("Rank") or r.get("ResultOrder")
                if key not in seen:
                    seen.add(key)
                    teams.append(r)
            rows = teams
    out = []
    for r in rows:
        irm = str(r.get("IRM") or "").strip().upper()
        rank = as_rank(r.get("Rank"))
        time_text = str(r.get("TotalTime") or r.get("Result") or "")
        full, short = person_name(r.get("Name") or r.get("ShortName"))
        out.append({
            "rank": rank, "irm": irm[:4],
            "name": full, "short": short, "nat": str(r.get("Nat") or "")[:3].upper(),
            "bib": str(r.get("Bib") or ""),
            "time": time_text,
            "behind": str(r.get("Behind") or ""),
            "shootings": shootings(r.get("Shootings")),
            "shootingText": str(r.get("Shootings") or "")[:40],
            "shootingTotal": as_rank(r.get("ShootingTotal")),
            "team": bool(relay),
            "_secs": None if irm else finish_seconds(time_text),
            "_order": as_rank(r.get("ResultOrder")),
        })
    # Im Rennen vergibt die IBU den Platz offenbar erst spät. Wer schon eine
    # Zielzeit hat, bekommt dann einen vorläufigen Platz nach der Zeit.
    if not any(x["rank"] is not None for x in out):
        done = [x for x in out if x["_secs"] is not None]
        done.sort(key=lambda x: (x["_secs"], x["_order"] or 9999))
        best = done[0]["_secs"] if done else 0
        for i, x in enumerate(done):
            x["rank"] = i + 1 if i == 0 or x["_secs"] != done[i - 1]["_secs"] else done[i - 1]["rank"]
            if not x["behind"] and i:
                gap = x["_secs"] - best
                x["behind"] = "+" + (f"{int(gap // 60)}:{gap % 60:04.1f}" if gap >= 60 else f"{gap:.1f}")
    for x in out:
        x.pop("_secs", None)
        x.pop("_order", None)
    ranked = sorted((x for x in out if x["rank"] is not None), key=lambda x: x["rank"])
    others = [x for x in out if x["rank"] is None]
    return ranked, others


def fetch_results(race_id, relay=False):
    data = get("Results", RaceId=race_id)
    if not isinstance(data, dict):
        raise SourceError("Unerwartete Antwort auf Results")
    RAW[race_id] = {"at": time.time(), "Results": data}
    for old in sorted(RAW, key=lambda k: RAW[k]["at"])[:-6]:
        RAW.pop(old, None)
    rows = [r for r in data.get("Results") or [] if isinstance(r, dict)]
    ranked, others = parse_rows(rows, relay)
    # Hinweis: Im Rennen liefert die IBU hier nur die Startliste (IsStartList,
    # StatusText "Running", ohne Plätze und Zeiten). Live-Zwischenstände gibt
    # die öffentliche Schnittstelle nicht her; das Ergebnis kommt, sobald die
    # IBU es veröffentlicht (dann "Unofficial", später "Official").
    competition = data.get("Competition") if isinstance(data.get("Competition"), dict) else {}
    return {
        "rows": ranked + others,
        "ranked": len(ranked),
        "open": sum(1 for x in others if not x["irm"]),
        "isStartList": bool(data.get("IsStartList")),
        "status": str(competition.get("StatusText") or ""),
        "isLive": bool(competition.get("IsLive")),
    }


FINAL_WORDS = ("official", "final", "unofficial", "result")
LIVE_WORDS = ("started", "running", "live", "in progress")


def race_state(race, result, t=None):
    """pre, live, post oder off (abgesagt)."""
    t = t or time.time()
    status = " ".join(filter(None, [race.get("status"), (result or {}).get("status")])).lower()
    if any(w in status for w in ("cancel", "postpon", "abgesagt")):
        return "off"
    if not race.get("start") or t < race["start"]:
        return "pre"
    if any(w in status for w in FINAL_WORDS) and "start list" not in status:
        return "post"
    if race.get("isLive") or (result or {}).get("isLive") or any(w in status for w in LIVE_WORDS):
        return "live" if t - race["start"] < 4 * 3600 else "post"
    if result is not None and result["ranked"] and not result["open"]:
        return "post"
    # Gestartet, aber noch nicht alle im Ziel: bis zu drei Stunden lang live.
    return "live" if t - race["start"] < 3 * 3600 else "post"


# --------------------------------------------------------------------------
# Gesamtwertungen
# --------------------------------------------------------------------------

def find_cups(season, series):
    """{"SW": CupId, "SM": CupId} der Gesamtwertung einer Serie."""
    rows = get("Cups", SeasonId=season)
    if not isinstance(rows, list):
        raise SourceError("Unerwartete Antwort auf Cups")
    key = series[2:]  # BTSWRLCP -> SWRLCP
    found = {}
    for row in rows:
        cup_id = str((row or {}).get("CupId") or "")
        match = re.match(rf"^BT{season}{key}__(S|J)([WM])TS$", cup_id)
        if match:
            found[match.group(1) + match.group(2)] = cup_id
    return {("SW" if k.endswith("W") else "SM"): v for k, v in found.items()}


def fetch_cup(cup_id):
    data = get("CupResults", CupId=cup_id)
    rows = (data or {}).get("Rows") if isinstance(data, dict) else None
    if not isinstance(rows, list):
        raise SourceError("Unerwartete Antwort auf CupResults")
    out = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        full, short = person_name(r.get("Name"))
        out.append({"rank": as_rank(r.get("Rank")), "name": full, "short": short,
                    "nat": str(r.get("Nat") or "")[:3].upper(),
                    "score": str(r.get("Score") or r.get("Points") or "")})
    return [r for r in out if r["rank"] is not None]
