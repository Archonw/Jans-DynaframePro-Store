"""Texte des Plugins auf Englisch, Deutsch und Spanisch.

Der englische Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim englischen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "The frame did not return to your playlist after the lyrics. Start it again on the frame's home page. This does "
    "not happen with a saved playlist instead of a Quick Mix.": (
        "Der Rahmen ist nach dem Liedtext nicht zu deiner Playlist zurückgekehrt. Starte sie auf der Startseite des "
        "Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix passiert das nicht.",
        "El marco no volvió a tu lista después de la letra. Iníciala de nuevo en la página de inicio del marco. Con una "
        "lista guardada en lugar de un Quick Mix no pasa."),
    "Unexpected answer: {exc}": ("Unerwartete Antwort: {exc}", "Respuesta inesperada: {exc}"),
    "Showing the lyrics by themselves": ("Liedtext von selbst zeigen", "Mostrar la letra por sí sola"),
    "Lyrics (LRCLIB)": ("Liedtexte (LRCLIB)", "Letras (LRCLIB)"),
    "Reachable ({ms} ms), {n} players.": ("Erreichbar ({ms} ms), {n} Player.", "Accesible ({ms} ms), {n} reproductores."),
    "Spotify on this frame": ("Spotify auf diesem Rahmen", "Spotify en este marco"),
    "Spotify account": ("Spotify-Konto", "Cuenta de Spotify"),
    "Reachable ({ms} ms), {server} {version}.": ("Erreichbar ({ms} ms), {server} {version}.",
                                                 "Accesible ({ms} ms), {server} {version}."),
    "Sing-along is switched off on the Plugins page.": ("Sing-along ist auf der Seite Plugins ausgeschaltet.",
                                                        "Sing-along está desactivado en la página Plugins."),
    "“Allow takeover” is off for Sing-along on the Plugins page. Switch it on, otherwise the lyrics cannot appear by "
    "themselves while music plays.": (
        "„Takeover erlauben“ ist bei Sing-along auf der Seite Plugins aus. Schalte es ein, sonst kann der Liedtext "
        "nicht von selbst erscheinen, wenn Musik läuft.",
        "“Permitir takeover” está desactivado para Sing-along en la página Plugins. Actívalo; si no, la letra no "
        "puede aparecer sola cuando suena música."),
    "Handing the screen back. It comes back by itself after the music has paused for a minute.": (
        "Gebe den Bildschirm zurück. Hat die Musik eine Minute Pause gemacht, kommt der Liedtext wieder von selbst.",
        "Devolviendo la pantalla. Cuando la música pare un minuto, la letra vuelve sola."),
    "Not reachable: {exc}": ("Nicht erreichbar: {exc}", "No accesible: {exc}"),
    "Refuses the key or token. Enter it again.": ("Lehnt den Schlüssel bzw. Token ab. Gib ihn neu ein.",
                                                  "Rechaza la clave o el token. Introdúcelo de nuevo."),
    "Not set up yet.": ("Noch nicht eingerichtet.", "Aún sin configurar."),
    "DynaFrame on this frame": ("DynaFrame auf diesem Rahmen", "DynaFrame en este marco"),
    "Reachable ({ms} ms).": ("Erreichbar ({ms} ms).", "Accesible ({ms} ms)."),
    "Allowed, the scene is installed.": ("Erlaubt, die Szene ist installiert.", "Permitido, la escena está instalada."),
    "Reachable ({ms} ms). {n} songs remembered on the frame.": (
        "Erreichbar ({ms} ms). {n} Lieder auf dem Rahmen gemerkt.",
        "Accesible ({ms} ms). {n} canciones guardadas en el marco."),
    "Answers. Music that plays on the frame via Spotify is recognised.": (
        "Antwortet. Musik, die über Spotify auf dem Rahmen läuft, wird erkannt.",
        "Responde. Se reconoce la música que suena en el marco por Spotify."),
    "Signed in as {who}.": ("Angemeldet als {who}.", "Conectado como {who}."),
    "Connected, {n} players.": ("Verbunden, {n} Player.", "Conectado, {n} reproductores."),
    "Connected to {server} {version}.": ("Verbunden mit {server} {version}.", "Conectado a {server} {version}."),
    "Looking for the lyrics again …": ("Suche den Liedtext noch einmal …", "Buscando la letra otra vez …"),
    "The Sing-along scene is not installed on this frame. Install the pack again.": (
        "Die Szene Sing-along ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.",
        "La escena Sing-along no está instalada en este marco. Instala el paquete de nuevo."),
    "The frame did not create the playlist {name}.": ("Der Rahmen hat die Playlist {name} nicht angelegt.",
                                                      "El marco no creó la lista {name}."),
    "Shows the lyrics of the music that is playing, line by line.": (
        "Zeigt den Liedtext der Musik, die gerade läuft, Zeile für Zeile.",
        "Muestra la letra de la música que suena, línea a línea."),
    "This frame is too old to let a plugin take over the screen.": (
        "Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.",
        "Este marco es demasiado antiguo para dejar la pantalla a un plugin."),
    "The screen is off; the lyrics are not shown.": ("Der Bildschirm ist aus; der Liedtext wird nicht gezeigt.",
                                                     "La pantalla está apagada; no se muestra la letra."),
    "The lyrics are already on screen.": ("Der Liedtext ist schon zu sehen.", "La letra ya está en pantalla."),
    "Asking the frame for the screen …": ("Frage den Rahmen nach dem Bildschirm …", "Pidiendo la pantalla al marco …"),
    "Could not start.": ("Konnte nicht starten.", "No se pudo iniciar."),
    "Off: the lyrics only appear in a playlist with the scene.": (
        "Aus: Der Liedtext erscheint nur in einer Playlist mit der Szene.",
        "Desactivado: la letra solo aparece en una lista con la escena."),
    "Not set up.": ("Nicht eingerichtet.", "Sin configurar."),
    "Optional. Enter the address in the Music Assistant card.": (
        "Freiwillig. Trag die Adresse in der Karte Music Assistant ein.",
        "Opcional. Escribe la dirección en la tarjeta Music Assistant."),
    "Address taken from {plugin}.": ("Adresse aus {plugin} übernommen.", "Dirección tomada de {plugin}."),
    "Switched off.": ("Ausgeschaltet.", "Desactivado."),
    "Playlist Music is not installed.": ("Playlist Music ist nicht installiert.", "Playlist Music no está instalado."),
    "Optional. With Playlist Music and Spotify switched on there, music that plays on the frame via Spotify Connect "
    "is recognised without any setup.": (
        "Freiwillig. Mit Playlist Music und dort eingeschaltetem Spotify wird Musik, die per Spotify Connect auf dem "
        "Rahmen läuft, ohne Einrichtung erkannt.",
        "Opcional. Con Playlist Music y Spotify activado allí, la música que suena en el marco por Spotify Connect se "
        "reconoce sin configurar nada."),
    "Spotify is switched off in Playlist Music.": ("Spotify ist in Playlist Music ausgeschaltet.",
                                                   "Spotify está desactivado en Playlist Music."),
    "Optional. Needed to see what plays on your phone, an Echo or a computer.": (
        "Freiwillig. Nötig, um zu sehen, was auf dem Handy, einem Echo oder dem Rechner läuft.",
        "Opcional. Hace falta para ver lo que suena en el móvil, un Echo o el ordenador."),
    "Client ID saved, but not signed in yet.": ("Client ID gespeichert, aber noch nicht angemeldet.",
                                                "Client ID guardado, pero aún sin iniciar sesión."),
    "Sign in with Spotify in the Spotify card.": ("Melde dich in der Karte Spotify bei Spotify an.",
                                                  "Inicia sesión en Spotify en la tarjeta Spotify."),
    "Optional. Enter the address in the Jellyfin card.": ("Freiwillig. Trag die Adresse in der Karte Jellyfin ein.",
                                                          "Opcional. Escribe la dirección en la tarjeta Jellyfin."),
    "Address and key taken from {plugin}.": ("Adresse und Schlüssel aus {plugin} übernommen.",
                                             "Dirección y clave tomadas de {plugin}."),
    "Nothing is playing right now.": ("Gerade läuft nichts.", "Ahora no suena nada."),
    "Could not create the takeover playlist: {exc}": ("Konnte die Takeover-Playlist nicht anlegen: {exc}",
                                                      "No se pudo crear la lista de takeover: {exc}"),
    "The Sing-along scene was not found.": ("Die Szene Sing-along wurde nicht gefunden.",
                                            "No se encontró la escena Sing-along."),
    "The takeover playlist has not been created yet.": ("Die Takeover-Playlist ist noch nicht angelegt.",
                                                        "La lista de takeover aún no está creada."),
    "Could not show the lyrics: {exc}": ("Konnte den Liedtext nicht zeigen: {exc}", "No se pudo mostrar la letra: {exc}"),
    "Something else has the screen right now.": ("Gerade hat etwas anderes den Bildschirm.",
                                                 "Ahora otra cosa tiene la pantalla."),
    "The frame did not show the lyrics in time.": ("Der Rahmen hat den Liedtext nicht rechtzeitig gezeigt.",
                                                   "El marco no mostró la letra a tiempo."),
    "Restart the frame if this stays red.": ("Starte den Rahmen neu, wenn das rot bleibt.",
                                             "Reinicia el marco si sigue en rojo."),
    "LRCLIB answers with an error: {exc}": ("LRCLIB antwortet mit einem Fehler: {exc}", "LRCLIB responde con un error: {exc}"),
    "Usually this goes away by itself. Try again later.": ("Meist gibt sich das von selbst. Versuch es später noch mal.",
                                                           "Suele arreglarse solo. Inténtalo más tarde."),
    "The player {player} was not found.": ("Der Player {player} wurde nicht gefunden.",
                                           "No se encontró el reproductor {player}."),
    "Playlist Music's Spotify does not answer yet: {exc}": ("Spotify in Playlist Music antwortet noch nicht: {exc}",
                                                            "El Spotify de Playlist Music aún no responde: {exc}"),
    "Is your Spotify account listed under User Management in your Spotify app?": (
        "Steht dein Spotify-Konto in deiner Spotify-App unter User Management?",
        "¿Está tu cuenta de Spotify en User Management de tu app de Spotify?"),
    "Enter the Client ID of your Spotify app first.": ("Trag zuerst die Client ID deiner Spotify-App ein.",
                                                       "Escribe primero el Client ID de tu app de Spotify."),
    "The Sing-along scene is switched off on the Plugins page.": (
        "Die Szene Sing-along ist auf der Seite Plugins ausgeschaltet.",
        "La escena Sing-along está desactivada en la página Plugins."),
    "lrclib.net cannot be reached.": ("lrclib.net ist nicht erreichbar.", "No se puede acceder a lrclib.net."),
    "Is it blocked, e.g. by a Pi-hole? Allow lrclib.net.": (
        "Blockiert es etwas, z. B. ein Pi-hole? Gib lrclib.net frei.",
        "¿Lo bloquea algo, p. ej. un Pi-hole? Permite lrclib.net."),
    "Newer versions of Music Assistant need a token. You create it in Music Assistant in your user profile.": (
        "Neuere Versionen von Music Assistant brauchen ein Token. Du legst es in Music Assistant in deinem "
        "Benutzerprofil an.",
        "Las versiones nuevas de Music Assistant necesitan un token. Lo creas en Music Assistant en tu perfil."),
    "Music source": ("Musikquelle", "Fuente de música"),
    "No music source is set up yet.": ("Noch keine Musikquelle eingerichtet.", "Aún no hay ninguna fuente de música."),
    "Set up at least one: Music Assistant, Spotify or Jellyfin.": (
        "Richte mindestens eine ein: Music Assistant, Spotify oder Jellyfin.",
        "Configura al menos una: Music Assistant, Spotify o Jellyfin."),
    "That is not the address from the address bar. Copy the whole address that starts with "
    "http://127.0.0.1:8888/callback?code=": (
        "Das ist nicht die Adresse aus der Adresszeile. Kopiere die ganze Adresse, die mit "
        "http://127.0.0.1:8888/callback?code= beginnt.",
        "Esa no es la dirección de la barra. Copia la dirección completa que empieza por "
        "http://127.0.0.1:8888/callback?code="),
    "Check": ("Prüfung", "Comprobación"),
    "{n} remembered songs forgotten.": ("{n} gemerkte Lieder vergessen.", "{n} canciones guardadas olvidadas."),
    "Signed out of Spotify.": ("Bei Spotify abgemeldet.", "Sesión de Spotify cerrada."),
}


def t(lang, template, **values):
    text = template
    if lang in ("de", "es"):
        row = _TEXTS.get(template)
        if row:
            text = row[0 if lang == "de" else 1]
    try:
        return text.format(**values) if values else text
    except (KeyError, IndexError, ValueError):
        return text
