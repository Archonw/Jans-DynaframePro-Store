#!/usr/bin/env python3
"""Sing-along - der Plugin-Teil des Pakets.

Läuft Musik über Music Assistant, Spotify oder Jellyfin, holt das Plugin den
Liedtext von LRCLIB (zeilengenau mit Zeitstempeln, kostenlos, ohne Schlüssel)
und zeigt ihn in der Szene im Takt, mit Cover und Fortschritt.

- Ablauf: eine Schleife fragt alle 1,5 s (wenn etwas läuft, sonst alle 4 s)
  die eingerichteten Quellen ab (sources.py). Die Position des Liedes wird
  hier verankert (Position + Zeitpunkt) und nur neu gesetzt, wenn die Quelle
  deutlich abweicht; die Szene rechnet selbst weiter.
- Auf dem Bildschirm: auf Wunsch schiebt sich die Szene von selbst über die
  Playlist (Takeover), solange Musik mit Liedtext läuft, und gibt den
  Bildschirm zurück, wenn die Musik aufhört. Oder die Szene steht in einer
  eigenen Playlist "Sing-along" (Karte "Eine Playlist dafür").
- Cover lädt das Plugin selbst und reicht sie an die Szene weiter
  (api/cover/<key>), damit nichts an Anmeldung oder CORS scheitert.

Die Szene erreicht das Plugin über den Proxy der Weboberfläche (:80 bzw.
:8003). Kein eigener Port im WLAN.
"""

import hashlib
import json
import os
import re
import sys
import threading
import time
from collections import OrderedDict
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import lyrics as lyricslib  # noqa: E402
import own_playlist  # noqa: E402
import sources  # noqa: E402
import texts  # noqa: E402

try:
    import playback_guard  # noqa: E402  (Umgehung eines Quick-Mix-Fehlers nach Takeovers)
except ImportError:  # pragma: no cover
    playback_guard = None

plugin = create_plugin()

PLUGIN_ID = "SingAlong"
DISPLAY_NAME = "Sing-along"
SCENE_ID = "sing-along"               # id in scene.dynamic - nie ändern
PLUGIN_DIR = Path(plugin.plugin_dir)
PLUGINS_DIR = PLUGIN_DIR.parent
DATA_DIR = PLUGIN_DIR / "data"        # Einstellungen und Zustand; bleibt bei Updates

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30

TAKEOVER_PLAYLIST_NAME = "Sing-along (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = "Used by the Sing-along plugin to show the lyrics while music plays. Leave it switched off."
TAKEOVER_ITEM_SECONDS = 21600
OWN_PLAYLIST_NAME = "Sing-along"
MAX_SESSION_SECONDS = 3600
SOURCE_ORDER = ("spotifyhere", "ma", "spotify", "jellyfin")
SPOTIFY_ACCOUNT_EVERY = 3.0           # Web API nicht öfter fragen
DRIFT = 1.2                           # so weit darf die Quelle abweichen, bevor neu verankert wird


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_num(value, default=0.0):
    try:
        return float(str(value).strip().replace(",", "."))
    except (TypeError, ValueError):
        return default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Could not read {Path(path).name}: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream_:
        json.dump(payload, stream_, indent=1, ensure_ascii=False)
    if path.name == "settings.json":
        try:
            os.chmod(temp, 0o600)  # enthält Schlüssel
        except OSError:
            pass
    temp.replace(path)


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


USER_AGENT = f"DynaFrame-SingAlong/{version()} (+https://github.com/Archonw/Jans-DynaframePro-Store)"

# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

SETTINGS = {
    "Language":       {"kind": "choice", "default": "de", "options": list(texts.LANGUAGES)},
    # Wann der Liedtext erscheint
    "ShowMode":       {"kind": "choice", "default": "auto", "options": ["auto", "playlist"]},
    "Source":         {"kind": "choice", "default": "auto", "options": ["auto", "ma", "spotifyhere", "spotify", "jellyfin"]},
    "OnlyWithLyrics": {"kind": "bool", "default": True},
    "PauseSeconds":   {"kind": "int", "default": 20, "min": 5, "max": 600},
    "WakeScreen":     {"kind": "bool", "default": False},
    "QuietEnabled":   {"kind": "bool", "default": False},
    "QuietFrom":      {"kind": "int", "default": 22, "min": 0, "max": 23},
    "QuietTo":        {"kind": "int", "default": 7, "min": 0, "max": 23},
    # Aussehen
    "Look":           {"kind": "choice", "default": "cover", "options": ["cover", "backdrop", "lyrics"]},
    "TextSize":       {"kind": "choice", "default": "normal", "options": ["small", "normal", "large"]},
    "ShowProgress":   {"kind": "bool", "default": True},
    "Karaoke":        {"kind": "bool", "default": True},
    "OffsetMs":       {"kind": "int", "default": 0, "min": -5000, "max": 5000},
    # Music Assistant
    "MaUrl":          {"kind": "url", "default": ""},
    "MaToken":        {"kind": "secret", "default": ""},
    "MaPlayer":       {"kind": "text", "default": ""},
    # Spotify
    "SpotifyHere":    {"kind": "bool", "default": True},
    "SpotifyClientId": {"kind": "clientid", "default": ""},
    # Jellyfin
    "JellyfinUrl":    {"kind": "url", "default": ""},
    "JellyfinKey":    {"kind": "secret", "default": ""},
    "JellyfinUser":   {"kind": "text", "default": ""},
    # Eine Playlist dafür
    "MakePlaylist":   {"kind": "bool", "default": False},
    "PlaylistSeconds": {"kind": "int", "default": 600, "min": 30, "max": 21600},
}
SECRETS = ("MaToken", "JellyfinKey")
SCENE_SETTINGS = {"Language", "Look", "TextSize", "ShowProgress", "Karaoke", "OffsetMs"}

SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
_settings_lock = threading.Lock()
_settings_cache = {"at": 0.0, "values": None}


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return default
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "int":
        return int(max(spec["min"], min(spec["max"], round(as_num(raw, default)))))
    if kind == "choice":
        value = str(raw).strip()
        return value if value in spec["options"] else default
    if kind == "url":
        return sources.normalize_url(raw)[:300]
    if kind == "secret":
        return re.sub(r"\s+", "", str(raw))[:1000]
    if kind == "clientid":
        value = re.sub(r"\s+", "", str(raw))
        return value if re.match(r"^[0-9a-fA-F]{32}$", value) else ""
    if kind == "text":
        return re.sub(r"\s+", " ", str(raw)).strip()[:120]
    return str(raw)[:200]


def settings():
    with _settings_lock:
        if _settings_cache["values"] is not None and now() - _settings_cache["at"] < 2:
            return dict(_settings_cache["values"])
        stored = read_json(SETTINGS_FILE, {}) or {}
        values = {name: coerce(name, stored.get(name)) for name in SETTINGS}
        _settings_cache.update(at=now(), values=values)
        return dict(values)


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


def save_settings(changes):
    changed = []
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            value = coerce(name, raw)
            if stored.get(name) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, stored)
        _settings_cache["values"] = None
    return changed


_state_lock = threading.Lock()


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**fields):
    with _state_lock:
        state = read_json(STATE_FILE, {}) or {}
        if all(k in state and state[k] == v for k, v in fields.items()):
            return state  # nichts Neues, also kein Schreiben auf die SD-Karte
        state.update(fields)
        write_json(STATE_FILE, state)
    return state


def in_quiet_hours(values, moment=None):
    if not values["QuietEnabled"]:
        return False
    hour = (moment or datetime.now()).hour
    start, end = int(values["QuietFrom"]), int(values["QuietTo"])
    if start == end:
        return False
    return start <= hour < end if start < end else (hour >= start or hour < end)


# --------------------------------------------------------------------------
# Quellen
# --------------------------------------------------------------------------

def ma_config(values=None):
    values = values or settings()
    if values["MaUrl"]:
        return {"url": values["MaUrl"], "token": values["MaToken"], "from": ""}
    return sources.ma_from_other_plugins(PLUGINS_DIR)


def jellyfin_config(values=None):
    values = values or settings()
    if values["JellyfinUrl"] and values["JellyfinKey"]:
        return {"url": values["JellyfinUrl"], "key": values["JellyfinKey"], "user": values["JellyfinUser"], "from": ""}
    other = sources.jellyfin_from_other_plugins(PLUGINS_DIR)
    if other and values["JellyfinUser"]:
        other["user"] = values["JellyfinUser"]
    return other


def playlist_music_spotify():
    """(installiert?, in Playlist Music eingeschaltet?)"""
    folder = PLUGINS_DIR / "PlaylistMusic"
    if not folder.is_dir():
        return False, False
    data = read_json(folder / "data" / "settings.json", {}) or {}
    return True, bool(data.get("SpotifyEnabled"))


spotify_account = sources.SpotifyAccount(DATA_DIR / "spotify_token.json", "")


def build_sources(values=None):
    values = values or settings()
    out = OrderedDict()
    installed, enabled = playlist_music_spotify()
    if values["SpotifyHere"] and installed and enabled:
        out["spotifyhere"] = sources.SpotifyHere(PLUGINS_DIR)
    ma = ma_config(values)
    if ma.get("url"):
        out["ma"] = sources.MusicAssistant(ma["url"], ma.get("token"), values["MaPlayer"], USER_AGENT)
    spotify_account.client_id = values["SpotifyClientId"]
    if spotify_account.ok():
        out["spotify"] = spotify_account
    jf = jellyfin_config(values)
    if jf.get("url") and jf.get("key"):
        out["jellyfin"] = sources.Jellyfin(jf["url"], jf["key"], jf.get("user"))
    if values["Source"] != "auto":
        out = OrderedDict((k, v) for k, v in out.items() if k == values["Source"])
    return out


SOURCE_LABELS = {"ma": "Music Assistant", "spotifyhere": "Spotify (DynaFrame)", "spotify": "Spotify", "jellyfin": "Jellyfin"}


def source_label(key):
    if key == "spotifyhere":
        return tr("Spotify on this frame")
    return SOURCE_LABELS.get(key, key)


# --------------------------------------------------------------------------
# Was läuft: Abfrage, Verankerung, Liedtext, Cover
# --------------------------------------------------------------------------

lrclib = lyricslib.Lrclib(DATA_DIR / "lyrics", USER_AGENT, log=lambda text, level="info": plugin.log(text, level=level))

_np_lock = threading.Lock()
_np = {
    "track": None,            # aktuelles Stück (dict aus sources) oder None
    "anchorPos": 0.0, "anchorAt": 0.0, "rate": 0.0,
    "lastReading": None,      # (id, position) der letzten Rohdaten ohne Zeitstempel
    "lastPlayingAt": 0.0,     # wann zuletzt etwas lief
    "lastSeenAt": 0.0,
    "errors": {},             # Quelle -> SourceError
    "spotifyAt": 0.0, "spotifyLast": None,
    "lyrics": {"kind": "idle"}, "lyricsFor": "", "lyricsKey": "", "lyricsRetryAt": 0.0,
    "cover": "", "coverFor": "",
    "polls": 0,
}
_covers = OrderedDict()       # key -> (bytes, content type)
_covers_lock = threading.Lock()


def lyrics_key(track, data):
    raw = f"{track.get('id')}|{data.get('kind')}|{data.get('id')}|{len(data.get('lines') or data.get('plain') or [])}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]


def position_now():
    with _np_lock:
        track = _np["track"]
        if not track:
            return 0.0
        pos = _np["anchorPos"] + (now() - _np["anchorAt"]) * _np["rate"]
        duration = float(track.get("duration") or 0)
        return max(0.0, min(pos, duration) if duration else pos)


def poll_source(key, src):
    if key == "spotify" and now() - _np["spotifyAt"] < SPOTIFY_ACCOUNT_EVERY:
        return _np["spotifyLast"]
    reading = src.now()
    if key == "spotify":
        _np["spotifyAt"] = now()
        _np["spotifyLast"] = reading
    return reading


def pick(readings, current_source):
    playing = [r for r in readings if r and r.get("state") == "playing"]
    paused = [r for r in readings if r and r.get("state") == "paused"]
    for group in (playing, paused):
        if not group:
            continue
        same = next((r for r in group if r["source"] == current_source), None)
        if same:
            return same
        return sorted(group, key=lambda r: SOURCE_ORDER.index(r["source"]) if r["source"] in SOURCE_ORDER else 9)[0]
    return None


def poll_once():
    values = settings()
    srcs = build_sources(values)
    readings, errors = [], {}
    for key, src in srcs.items():
        try:
            reading = poll_source(key, src)
        except sources.SourceError as exc:
            errors[key] = exc
            continue
        except Exception as exc:  # noqa: BLE001 - eine Quelle darf die anderen nicht aufhalten
            errors[key] = sources.SourceError("format", exc)
            continue
        if key == "ma":
            _ma_players.update(names=list(src.players_seen), at=now())
        if reading and reading.get("title"):
            readings.append(reading)
    with _np_lock:
        current = _np["track"]
        _np["errors"] = errors
        _np["polls"] += 1
        chosen = pick(readings, current.get("source") if current else "")
        t = now()
        if chosen is None:
            if current is not None:
                plugin.log("Nothing is playing any more.")
            _np.update(track=None, rate=0.0)
            return
        _np["lastSeenAt"] = t
        if chosen["state"] == "playing":
            _np["lastPlayingAt"] = t
        reading_pos = float(chosen.get("position") or 0)
        if chosen.get("at"):
            measured = reading_pos + (t - float(chosen["at"])) * (1 if chosen["state"] == "playing" else 0)
            stamped = True
        else:
            measured = reading_pos
            stamped = False
        new_track = current is None or current.get("id") != chosen.get("id")
        rate = 1.0 if chosen["state"] == "playing" else 0.0
        if new_track:
            plugin.log(f"Now playing ({chosen['source']}): {chosen.get('artist')} - {chosen.get('title')}")
            _np.update(track=chosen, anchorPos=measured, anchorAt=t, rate=rate,
                       lastReading=(chosen.get("id"), reading_pos))
            return
        predicted = _np["anchorPos"] + (t - _np["anchorAt"]) * _np["rate"]
        if not stamped:
            # Ohne Zeitstempel (Jellyfin ohne LastPlaybackCheckIn): nur neu verankern,
            # wenn die Quelle eine neue Position meldet.
            if _np["lastReading"] == (chosen.get("id"), reading_pos) and rate == _np["rate"]:
                _np["track"] = chosen
                return
            _np["lastReading"] = (chosen.get("id"), reading_pos)
        if rate != _np["rate"] or abs(measured - predicted) > DRIFT:
            _np.update(anchorPos=measured, anchorAt=t, rate=rate)
        _np["track"] = chosen


def fetch_lyrics(track):
    try:
        data = lrclib.find(track.get("title"), track.get("artist"), track.get("album"), track.get("duration"))
    except lyricslib.LyricsError as exc:
        plugin.log(f"LRCLIB: {exc}", level="warning")
        data = {"kind": "error", "lines": [], "plain": [], "error": str(exc)}
        _np["lyricsRetryAt"] = now() + lyricslib.ERROR_AGAIN
    with _np_lock:
        current = _np["track"]
        if not current or current.get("id") != track.get("id"):
            return
        _np.update(lyrics=data, lyricsKey=lyrics_key(track, data))
    plugin.log(f"Lyrics for {track.get('title')}: {data.get('kind')} ({data.get('how', '')})")


def cover_key(url):
    return hashlib.sha1(url.encode("utf-8")).hexdigest()[:16]


def fetch_cover(track):
    url = track.get("cover") or ""
    key = cover_key(url) if url else ""
    if key and key not in _covers:
        try:
            answer = requests.get(url, headers=dict(track.get("coverHeaders") or {}, **{"User-Agent": USER_AGENT}),
                                  timeout=(5, 15))
            kind = answer.headers.get("Content-Type", "image/jpeg").split(";")[0].strip()
            if answer.status_code == 200 and kind.startswith("image/") and len(answer.content) < 8 * 1024 * 1024:
                with _covers_lock:
                    _covers[key] = (answer.content, kind)
                    while len(_covers) > 12:
                        _covers.popitem(last=False)
            else:
                key = ""
        except requests.RequestException as exc:
            plugin.log(f"Cover could not be loaded: {exc}", level="warning")
            key = ""
    with _np_lock:
        current = _np["track"]
        if current and current.get("id") == track.get("id"):
            _np["cover"] = key


def follow_track():
    """Nach jeder Abfrage: zu einem neuen Stück Liedtext und Cover holen."""
    with _np_lock:
        track = _np["track"]
        if not track:
            _np.update(lyrics={"kind": "idle"}, lyricsFor="", lyricsKey="", cover="", coverFor="")
            return
        need_lyrics = _np["lyricsFor"] != track["id"] or (
            _np["lyrics"].get("kind") == "error" and now() > _np["lyricsRetryAt"])
        need_cover = _np["coverFor"] != track["id"]
        if need_lyrics:
            _np.update(lyricsFor=track["id"], lyrics={"kind": "loading"}, lyricsKey="")
        if need_cover:
            _np.update(coverFor=track["id"], cover="")
    if need_lyrics:
        threading.Thread(target=fetch_lyrics, args=(dict(track),), name=f"{PLUGIN_ID}-lyrics", daemon=True).start()
    if need_cover:
        threading.Thread(target=fetch_cover, args=(dict(track),), name=f"{PLUGIN_ID}-cover", daemon=True).start()


def poll_loop():
    _stop_requested.wait(1.5)
    while not _stop_requested.is_set():
        try:
            poll_once()
            follow_track()
        except Exception as exc:  # pragma: no cover - die Schleife muss weiterlaufen
            plugin.log(f"Polling failed: {exc}", level="error")
        playing = _np["track"] is not None and _np["track"].get("state") == "playing"
        _poll_wake.wait(1.5 if playing or _takeover["handle"] is not None else 4)
        _poll_wake.clear()


# --------------------------------------------------------------------------
# Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} returned HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "note": ""}


def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else
                      tr("The Sing-along scene is switched off on the Plugins page."))
        return row
    _scene.update(dbId=None, note=tr("The Sing-along scene is not installed on this frame. Install the pack again."))
    return None


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    data = engine_call("GET", "/playlists") or []
    if isinstance(data, dict):
        data = data.get("playlists") or data.get("items") or []
    return [p for p in data if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError:
        return False
    return bool(status.get("active"))


_playlists = {"at": 0.0, "takeoverId": None, "note": ""}
_playlist_lock = threading.Lock()


def ensure_takeover_playlist():
    """Ein Takeover spielt eine Playlist: die Szene allein, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if same_id(i.get("dynamicSceneId"), _scene["dbId"])]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_PLAYLIST_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("The frame did not create the playlist {name}.", name=TAKEOVER_PLAYLIST_NAME))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    plugin.log(f"Created the playlist {TAKEOVER_PLAYLIST_NAME} ({playlist_id}).")
    return playlist_id


def maintain_playlists(force=False):
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        find_scene()
        if _scene["dbId"] is None:
            _playlists["note"] = _scene["note"]
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Could not create the takeover playlist: {exc}", exc=exc)
            plugin.log(_playlists["note"], level="warning")


OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=[OWN_PLAYLIST_NAME],
    name=lambda: OWN_PLAYLIST_NAME,
    description=lambda: tr("Shows the lyrics of the music that is playing, line by line."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": plugin.log(text, level=level),
    held=screen_held,
)


# --------------------------------------------------------------------------
# Auf den Bildschirm (Takeover)
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "since": None, "token": 0, "note": "", "manual": False, "dismissed": False,
             "backoffUntil": 0.0, "trackId": ""}
_stop_requested = threading.Event()
_wake = threading.Event()
_poll_wake = threading.Event()


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform") or {}
    except EngineError:
        return True
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Sing-along is switched off on the Plugins page.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("“Allow takeover” is off for Sing-along on the Plugins page. Switch it on, otherwise the lyrics "
                  "cannot appear by themselves while music plays.")
    return ""


def display_is_off():
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def scene_on_screen():
    """Läuft die Szene gerade ganz normal in einer Playlist? Dann braucht es keinen Takeover."""
    if _scene["dbId"] is None:
        return False
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", read_timeout=5) or {}
    except EngineError:
        return False
    item = status.get("currentItem") or {}
    return bool(status.get("isRunning") and same_id(item.get("dynamicSceneId"), _scene["dbId"])
                and not same_id(status.get("activePlaylistId"), _playlists["takeoverId"]))


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        plugin.log(text)
    return False


def _on_session_state(handle_or_state):
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _takeover.update(handle=None, since=None, manual=False)
        if new_state == "preempted":
            _takeover["backoffUntil"] = now() + 180   # jemand anderes wollte den Bildschirm
    plugin.log(f"The frame ended Sing-along: {new_state}.")
    threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason, token=None):
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        _takeover.update(handle=None, since=None, manual=False)
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:
        plugin.log(f"Could not hand back the screen: {exc}", level="warning")
    plugin.log(f"Screen handed back ({reason}).")
    if reason != "stopped":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def show_scene(force=False):
    if not takeover_supported():
        return _note(tr("This frame is too old to let a plugin take over the screen."))
    if _scene["dbId"] is None:
        find_scene()
    if _scene["dbId"] is None or _scene["note"]:
        return _note(_scene["note"] or tr("The Sing-along scene was not found."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("The takeover playlist has not been created yet."))
    wake = settings()["WakeScreen"] or force
    if not wake and display_is_off():
        return _note(tr("The screen is off; the lyrics are not shown."))
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             "overlay": {"enabled": False}}
    try:
        _leftover["askedAt"] = time.time()
        handle = plugin.acquire_display_session(
            session_key="lyrics", state=state, display_name=DISPLAY_NAME,
            max_duration_seconds=MAX_SESSION_SECONDS, wake_if_off=bool(wake))
    except Exception as exc:
        return _note(tr("Could not show the lyrics: {exc}", exc=exc))
    if handle is None:
        return _note(takeover_permission_note() or tr("Something else has the screen right now."))
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, since=now(), note="")
    try:
        handle.on_state_change(_on_session_state)
    except Exception:
        pass
    try:
        if not handle.wait_until_active(timeout=10):
            end_takeover("failed", token)
            return _note(tr("The frame did not show the lyrics in time."))
    except Exception as exc:
        end_takeover("failed", token)
        return _note(tr("Could not show the lyrics: {exc}", exc=exc))
    plugin.log("Sing-along on screen.")
    return True


def lyrics_ready_for_screen(values):
    kind = _np["lyrics"].get("kind")
    if kind == "loading":
        return None       # noch warten
    if not values["OnlyWithLyrics"]:
        return True
    return kind in ("synced", "plain")


def decide_takeover():
    values = settings()
    track = _np["track"]
    playing = bool(track) and track.get("state") == "playing"
    idle_for = now() - (_np["lastPlayingAt"] or 0)
    with _takeover_lock:
        handle = _takeover["handle"]
        manual = _takeover["manual"]
    if not playing and idle_for > 60:
        _takeover["dismissed"] = False       # nach einer Pause darf es wieder von selbst kommen
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        if not playing and idle_for > values["PauseSeconds"]:
            end_takeover("music stopped")
            return
        if not manual and values["ShowMode"] != "auto":
            end_takeover("switched to playlist only")
            return
        if not manual and playing and lyrics_ready_for_screen(values) is False:
            end_takeover("no lyrics for this song")
            return
        if not manual and in_quiet_hours(values):
            end_takeover("quiet hours")
        return
    if values["ShowMode"] != "auto" or not playing or _takeover["dismissed"]:
        return
    if now() < _takeover["backoffUntil"] or in_quiet_hours(values):
        return
    if not lyrics_ready_for_screen(values):
        return
    if scene_on_screen():
        return
    if not show_scene():
        _takeover["backoffUntil"] = now() + 60


def show_now():
    if _takeover["handle"] is not None:
        return {"success": True, "message": tr("The lyrics are already on screen.")}
    _takeover["dismissed"] = False
    _takeover["backoffUntil"] = 0.0
    if show_scene(force=True):
        with _takeover_lock:
            _takeover["manual"] = True
        _np["lastPlayingAt"] = max(_np["lastPlayingAt"], now())   # gleich nach dem Zeigen nicht wieder zu
        return {"success": True, "message": tr("Asking the frame for the screen …")}
    return {"success": False, "error": _takeover["note"] or tr("Could not start.")}


def cancel():
    _takeover["dismissed"] = True
    end_takeover("cancelled")
    return {"success": True, "message": tr("Handing the screen back. It comes back by itself after the music has paused for a minute.")}


# ---- Takeover-Playlist, die nach dem Zurückgeben weiterläuft ---------------
# Lief vor einem Takeover keine Playlist, stellt die Engine dieses "nichts"
# nicht wieder her, und die Takeover-Playlist läuft einfach weiter (Jans
# Rahmen, 2026-10-24). Jeder Durchlauf hält sie dann mit POST /slideshow/stop
# an: nur wenn sie läuft, niemand den Bildschirm hält und das Plugin nicht
# gerade selbst darum gebeten hat.
_leftover = {"askedAt": 0.0, "failed": False, "checkedAt": 0.0}


def stop_leftover_takeover():
    if now() - _leftover["checkedAt"] < 15:
        return False
    _leftover["checkedAt"] = now()
    try:
        playlist_id = _playlists["takeoverId"]
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status", read_timeout=5) or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status", read_timeout=5) or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop", read_timeout=10)
    except Exception as exc:  # noqa: BLE001 - darf die Schleife nie aufhalten
        if not _leftover["failed"]:
            plugin.log(f"The takeover playlist kept running and could not be stopped: {exc}", level="warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    plugin.log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def check_playback_resumed():
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log,
                                                    stop_event=_stop_requested)
        if outcome == "not-requested":
            save_state(playbackStalled="")
            return
    elif _stop_requested.wait(12):
        return
    if _stop_requested.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
    except EngineError:
        return
    if status.get("isRunning") or _takeover["handle"] is not None:
        save_state(playbackStalled="")
        return
    message = tr("The frame did not return to your playlist after the lyrics. Start it again on the frame's home "
                 "page. This does not happen with a saved playlist instead of a Quick Mix.")
    save_state(playbackStalled=message)
    plugin.log(message, level="warning")


# --------------------------------------------------------------------------
# Verbindungen prüfen (Karte auf der Einstellungsseite)
# --------------------------------------------------------------------------

SERVICES_EVERY = 5 * 60
_services = {"at": 0.0, "rows": [], "busy": False}
_services_lock = threading.Lock()


def _row(key, name, state, text, hint=""):
    return {"key": key, "name": name, "state": state, "text": text, "hint": hint}


def source_error_text(exc, host=""):
    code = getattr(exc, "code", "format")
    if code == "unreachable":
        return tr("Not reachable: {exc}", exc=getattr(exc, "detail", "") or exc)
    if code == "auth":
        return tr("Refuses the key or token. Enter it again.")
    if code == "no-setup":
        return tr("Not set up yet.")
    return tr("Unexpected answer: {exc}", exc=getattr(exc, "detail", "") or exc)


def _check_engine():
    started = time.time()
    try:
        engine_call("GET", "/plugins/platform", read_timeout=8)
    except EngineError as exc:
        return _row("engine", tr("DynaFrame on this frame"), "bad", tr("Not reachable: {exc}", exc=exc),
                    tr("Restart the frame if this stays red."))
    ms = int((time.time() - started) * 1000)
    return _row("engine", tr("DynaFrame on this frame"), "ok", tr("Reachable ({ms} ms).", ms=ms))


def _check_takeover(values):
    name = tr("Showing the lyrics by themselves")
    if values["ShowMode"] != "auto":
        return _row("takeover", name, "off", tr("Off: the lyrics only appear in a playlist with the scene."))
    if not takeover_supported():
        return _row("takeover", name, "bad", tr("This frame is too old to let a plugin take over the screen."))
    note = takeover_permission_note()
    if note:
        return _row("takeover", name, "bad", note)
    find_scene()
    if _scene["note"]:
        return _row("takeover", name, "bad", _scene["note"])
    return _row("takeover", name, "ok", tr("Allowed, the scene is installed."))


def _check_lrclib():
    name = tr("Lyrics (LRCLIB)")
    try:
        ms = lrclib.ping()
    except lyricslib.LyricsError as exc:
        if str(exc).startswith("unreachable"):
            return _row("lrclib", name, "bad", tr("lrclib.net cannot be reached."),
                        tr("Is it blocked, e.g. by a Pi-hole? Allow lrclib.net."))
        return _row("lrclib", name, "bad", tr("LRCLIB answers with an error: {exc}", exc=exc),
                    tr("Usually this goes away by itself. Try again later."))
    return _row("lrclib", name, "ok", tr("Reachable ({ms} ms). {n} songs remembered on the frame.", ms=ms,
                                         n=lrclib.cache_count()))


def _check_ma(values):
    name = "Music Assistant"
    cfg = ma_config(values)
    if not cfg.get("url"):
        return _row("ma", name, "off", tr("Not set up."), tr("Optional. Enter the address in the Music Assistant card."))
    src = sources.MusicAssistant(cfg["url"], cfg.get("token"), values["MaPlayer"], USER_AGENT)
    started = time.time()
    try:
        players = src.test()
    except sources.SourceError as exc:
        return _row("ma", name, "bad", source_error_text(exc),
                    tr("Newer versions of Music Assistant need a token. You create it in Music Assistant in "
                       "your user profile.") if exc.code == "auth" else "")
    ms = int((time.time() - started) * 1000)
    text = tr("Reachable ({ms} ms), {n} players.", ms=ms, n=len(players))
    if cfg.get("from"):
        text += " " + tr("Address taken from {plugin}.", plugin=cfg["from"])
    if values["MaPlayer"] and values["MaPlayer"].lower() not in [p.lower() for p in players]:
        return _row("ma", name, "warn", text + " " + tr("The player {player} was not found.",
                                                        player=values["MaPlayer"]))
    return _row("ma", name, "ok", text)


def _check_spotify_here(values):
    name = tr("Spotify on this frame")
    installed, enabled = playlist_music_spotify()
    if not values["SpotifyHere"]:
        return _row("spotifyhere", name, "off", tr("Switched off."))
    if not installed:
        return _row("spotifyhere", name, "off", tr("Playlist Music is not installed."),
                    tr("Optional. With Playlist Music and Spotify switched on there, music that plays on the frame "
                       "via Spotify Connect is recognised without any setup."))
    if not enabled:
        return _row("spotifyhere", name, "off", tr("Spotify is switched off in Playlist Music."))
    try:
        sources.SpotifyHere(PLUGINS_DIR).status()
    except sources.SourceError as exc:
        return _row("spotifyhere", name, "warn", tr("Playlist Music's Spotify does not answer yet: {exc}",
                                                    exc=exc.detail or exc.code))
    return _row("spotifyhere", name, "ok", tr("Answers. Music that plays on the frame via Spotify is recognised."))


def _check_spotify_account(values):
    name = tr("Spotify account")
    if not values["SpotifyClientId"]:
        return _row("spotify", name, "off", tr("Not set up."),
                    tr("Optional. Needed to see what plays on your phone, an Echo or a computer."))
    spotify_account.client_id = values["SpotifyClientId"]
    if not spotify_account.ok():
        return _row("spotify", name, "warn", tr("Client ID saved, but not signed in yet."),
                    tr("Sign in with Spotify in the Spotify card."))
    try:
        who = spotify_account.test()
    except sources.SourceError as exc:
        hint = tr("Is your Spotify account listed under User Management in your Spotify app?") \
            if "403" in str(exc.detail) else ""
        return _row("spotify", name, "bad", source_error_text(exc), hint)
    return _row("spotify", name, "ok", tr("Signed in as {who}.", who=who))


def _check_jellyfin(values):
    name = "Jellyfin"
    cfg = jellyfin_config(values)
    if not cfg.get("url"):
        return _row("jellyfin", name, "off", tr("Not set up."), tr("Optional. Enter the address in the Jellyfin card."))
    src = sources.Jellyfin(cfg["url"], cfg.get("key"), cfg.get("user"))
    started = time.time()
    try:
        server, ver = src.test()
        src.now()
    except sources.SourceError as exc:
        return _row("jellyfin", name, "bad", source_error_text(exc))
    ms = int((time.time() - started) * 1000)
    text = tr("Reachable ({ms} ms), {server} {version}.", ms=ms, server=server, version=ver)
    if cfg.get("from"):
        text += " " + tr("Address and key taken from {plugin}.", plugin=cfg["from"])
    return _row("jellyfin", name, "ok", text)


def check_services(force=False):
    with _services_lock:
        if _services["busy"] or (not force and now() - _services["at"] < SERVICES_EVERY and _services["rows"]):
            return _services["rows"]
        _services["busy"] = True
    try:
        values = settings()
        rows = []
        for fn in (_check_engine, lambda: _check_takeover(values), _check_lrclib, lambda: _check_ma(values),
                   lambda: _check_spotify_here(values), lambda: _check_spotify_account(values),
                   lambda: _check_jellyfin(values)):
            try:
                row = fn()
            except Exception as exc:  # noqa: BLE001 - eine kaputte Prüfung soll die anderen nicht aufhalten
                row = _row("error", tr("Check"), "bad", str(exc))
            if row:
                rows.append(row)
        if not any(r["key"] in ("ma", "spotifyhere", "spotify", "jellyfin") and r["state"] in ("ok", "warn")
                   for r in rows):
            rows.append(_row("music", tr("Music source"), "bad", tr("No music source is set up yet."),
                             tr("Set up at least one: Music Assistant, Spotify or Jellyfin.")))
        before = {r["key"]: r["state"] for r in _services["rows"]}
        for r in rows:
            if r["state"] == "bad" and before.get(r["key"]) != "bad":
                plugin.log(f"{r['name']}: {r['text']}", level="warning")
        _services.update(rows=rows, at=now())
        return rows
    finally:
        _services["busy"] = False


def services_payload():
    rows = _services["rows"]
    return {"at": _services["at"] or None, "busy": _services["busy"], "rows": rows,
            "bad": sum(1 for r in rows if r["state"] == "bad"),
            "warn": sum(1 for r in rows if r["state"] == "warn")}


# --------------------------------------------------------------------------
# Ablauf
# --------------------------------------------------------------------------

_loop = {"lastError": ""}


def tick():
    try:
        stop_leftover_takeover()
        maintain_playlists()
        decide_takeover()
        if now() - _services["at"] > SERVICES_EVERY and not _services["busy"]:
            _services["at"] = now()
            threading.Thread(target=check_services, args=(True,), name=f"{PLUGIN_ID}-services", daemon=True).start()
        _loop["lastError"] = ""
    except Exception as exc:  # pragma: no cover - die Schleife muss weiterlaufen
        _loop["lastError"] = str(exc)
        plugin.log(f"Loop failed: {exc}", level="error")


def main_loop():
    _stop_requested.wait(2)
    while not _stop_requested.is_set():
        _wake.clear()
        tick()
        _wake.wait(2)


# --------------------------------------------------------------------------
# Die Szene
# --------------------------------------------------------------------------

def track_public(track):
    if not track:
        return None
    return {"id": track.get("id"), "title": track.get("title") or "", "artist": track.get("artist") or "",
            "album": track.get("album") or "", "duration": round(float(track.get("duration") or 0), 2),
            "state": track.get("state"), "source": track.get("source"), "sourceLabel": source_label(track.get("source")),
            "player": track.get("player") or "", "radio": bool(track.get("radio"))}


def scene_payload(have=""):
    values = settings()
    with _np_lock:
        track = _np["track"]
        lyr = _np["lyrics"]
        key = _np["lyricsKey"]
        cover = _np["cover"]
    payload = {"at": now(), "lang": values["Language"],
               "look": values["Look"], "size": values["TextSize"], "progress": values["ShowProgress"],
               "karaoke": values["Karaoke"], "offset": values["OffsetMs"] / 1000.0,
               "track": track_public(track), "position": round(position_now(), 3),
               "playing": bool(track) and track.get("state") == "playing",
               "cover": f"api/cover/{cover}" if cover else "",
               "lyrics": {"kind": lyr.get("kind"), "key": key}}
    if key and key != have:
        payload["lyrics"]["lines"] = lyr.get("lines") or []
        payload["lyrics"]["plain"] = lyr.get("plain") or []
    return payload


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


def current_line(lines, pos):
    found = ""
    for row in lines or []:
        if row["t"] <= pos:
            found = row["text"]
        else:
            break
    return found


def state_payload():
    values = settings()
    state = load_state()
    with _takeover_lock:
        showing = _takeover["handle"] is not None
        note = _takeover["note"]
        dismissed = _takeover["dismissed"]
    with _np_lock:
        track = _np["track"]
        lyr = dict(_np["lyrics"])
        errors = {k: source_error_text(v) for k, v in _np["errors"].items()}
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    pos = position_now()
    ma = ma_config(values)
    jf = jellyfin_config(values)
    spotify_account.client_id = values["SpotifyClientId"]
    installed, enabled = playlist_music_spotify()
    return {
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "track": track_public(track),
        "position": round(pos, 1),
        "lyrics": {"kind": lyr.get("kind"), "how": lyr.get("how") or "", "matched": lyr.get("matched") or {},
                   "line": current_line(lyr.get("lines"), pos + values["OffsetMs"] / 1000.0) if track else "",
                   "count": len(lyr.get("lines") or lyr.get("plain") or [])},
        "showing": showing,
        "dismissed": dismissed,
        "quietNow": in_quiet_hours(values),
        "note": note or _playlists["note"] or _scene["note"],
        "permission": takeover_permission_note() if values["ShowMode"] == "auto" else "",
        "sources": {"active": list(build_sources(values).keys()), "errors": errors},
        "ma": {"from": ma.get("from") or "", "players": _ma_players["names"]},
        "jellyfin": {"from": jf.get("from") or ""},
        "spotify": {"signedIn": spotify_account.ok(), "redirect": sources.SPOTIFY_REDIRECT,
                    "here": {"installed": installed, "enabled": enabled}},
        "ownPlaylist": OWN.text(),
        "lastError": _loop["lastError"] or state.get("playbackStalled") or "",
        "theme": {"id": theme_id()},
        "services": services_payload(),
        "cache": lrclib.cache_count(),
    }


_ma_players = {"names": [], "at": 0.0}


def ma_players(force=False):
    if not force and now() - _ma_players["at"] < 60:
        return {"success": True, "players": _ma_players["names"]}
    cfg = ma_config()
    if not cfg.get("url"):
        return {"success": False, "error": tr("Not set up yet.")}
    try:
        names = sources.MusicAssistant(cfg["url"], cfg.get("token"), "", USER_AGENT).test()
    except sources.SourceError as exc:
        return {"success": False, "error": source_error_text(exc)}
    _ma_players.update(names=names, at=now())
    return {"success": True, "players": names,
            "message": tr("Connected, {n} players.", n=len(names))}


def test_jellyfin():
    cfg = jellyfin_config()
    if not cfg.get("url"):
        return {"success": False, "error": tr("Not set up yet.")}
    try:
        server, ver = sources.Jellyfin(cfg["url"], cfg.get("key"), cfg.get("user")).test()
    except sources.SourceError as exc:
        return {"success": False, "error": source_error_text(exc)}
    return {"success": True, "message": tr("Connected to {server} {version}.", server=server, version=ver)}


def spotify_login():
    spotify_account.client_id = settings()["SpotifyClientId"]
    try:
        url = spotify_account.start_login()
    except sources.SourceError:
        return {"success": False, "error": tr("Enter the Client ID of your Spotify app first.")}
    return {"success": True, "url": url}


def spotify_finish(body):
    spotify_account.client_id = settings()["SpotifyClientId"]
    try:
        spotify_account.finish_login(body.get("pasted"))
        who = spotify_account.test()
    except sources.SourceError as exc:
        if exc.code == "format":
            return {"success": False, "error": tr("That is not the address from the address bar. Copy the whole "
                                                  "address that starts with http://127.0.0.1:8888/callback?code=")}
        return {"success": False, "error": source_error_text(exc)}
    _services["at"] = 0.0
    return {"success": True, "message": tr("Signed in as {who}.", who=who)}


def lyrics_again():
    track = _np["track"]
    if not track:
        return {"success": False, "error": tr("Nothing is playing right now.")}
    lrclib.forget(track.get("title"), track.get("artist"), track.get("album"), track.get("duration"))
    with _np_lock:
        _np["lyricsFor"] = ""
    follow_track()
    return {"success": True, "message": tr("Looking for the lyrics again …")}


def settings_saved(changed):
    if "MakePlaylist" in changed:
        OWN.changed()
    if set(changed) & {"MaUrl", "MaToken", "SpotifyClientId", "JellyfinUrl", "JellyfinKey", "SpotifyHere",
                       "ShowMode", "Source"}:
        _services["at"] = 0.0
        _ma_players["at"] = 0.0
    if "ShowMode" in changed or "OnlyWithLyrics" in changed:
        _takeover["backoffUntil"] = 0.0
    _wake.set()
    _poll_wake.set()


class StudioHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"   # der Proxy der Weboberfläche hält Verbindungen offen

    def log_message(self, *_args):
        pass

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8",
                   status, cors=cors)

    def _body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        if length > 256 * 1024:
            self.rfile.read(length)
            return {}
        try:
            data = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
        except ValueError:
            return {}
        return data if isinstance(data, dict) else {}

    def do_HEAD(self):
        self.do_GET()

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload((query.get("have") or [""])[0]), cors=True)
                return
            if path.startswith("/api/cover/"):
                key = path.rsplit("/", 1)[-1]
                with _covers_lock:
                    found = _covers.get(key)
                if not found:
                    self._json({"success": False, "error": "Not found"}, 404, cors=True)
                    return
                self._send(found[0], found[1], cache="max-age=86400", cors=True)
                return
            if path == "/api/services":
                check_services(force=True)
                self._json({"success": True, "services": services_payload()})
                return
            if path == "/api/ma/players":
                self._json(ma_players(force=True))
                return
            self._json({"success": False, "error": "Not found"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Could not read a plugin file: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        body = self._body()
        try:
            if path == "/api/settings":
                for name in SECRETS:
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)   # ein leeres Feld heißt: das alte behalten
                changed = save_settings(body)
                if changed:
                    settings_saved(changed)
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/show":
                self._json(show_now())
                return
            if path == "/api/cancel":
                self._json(cancel())
                return
            if path == "/api/lyrics/again":
                self._json(lyrics_again())
                return
            if path == "/api/lyrics/clear":
                n = lrclib.clear()
                with _np_lock:
                    _np["lyricsFor"] = ""
                self._json({"success": True, "message": tr("{n} remembered songs forgotten.", n=n)})
                return
            if path == "/api/ma/test":
                self._json(ma_players(force=True))
                return
            if path == "/api/jellyfin/test":
                self._json(test_jellyfin())
                return
            if path == "/api/spotify/login":
                self._json(spotify_login())
                return
            if path == "/api/spotify/finish":
                self._json(spotify_finish(body))
                return
            if path == "/api/spotify/forget":
                spotify_account.forget()
                _services["at"] = 0.0
                self._json({"success": True, "message": tr("Signed out of Spotify.")})
                return
            self._json({"success": False, "error": "Not found"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin page at {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    plugin.log(f"Starting {PLUGIN_ID} {version()}")

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("show", lambda _context=None: show_now())
    plugin.on_action("cancel", lambda _context=None: cancel())
    plugin.on_action("playlist", lambda _context=None: OWN.create_now())

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    threading.Thread(target=poll_loop, name=f"{PLUGIN_ID}-poll", daemon=True).start()
    threading.Thread(target=main_loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _poll_wake.set()
    end_takeover("stopped")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    plugin.log(f"{PLUGIN_ID} stopped.")


if __name__ == "__main__":
    main()
