"""Ortsnamen zu Koordinaten über Nominatim (OpenStreetMap), aus On This Day.

Höchstens eine Anfrage pro Sekunde, Ergebnisse für immer im Cache
(data/places.json, 0,01°-Raster je Sprache). Nur für Haltestellen, deren
Fotos keinen Ortsnamen mitbringen (z. B. Dateien nur mit GPS).
"""

import json
import os
import threading
import time
from pathlib import Path

import requests

import photo_privacy

REVERSE = os.environ.get("LL_REVERSE_URL", "https://nominatim.openstreetmap.org/reverse")
USER_AGENT = "DynaFrame-LifeLines/0.1 (DynaFrame plugin)"
TIMEOUT = (10, 30)


class Places:
    def __init__(self, data_dir, log):
        self.file = Path(data_dir) / "places.json"
        self.log = log
        self.lock = threading.Lock()
        self.reverse_lock = threading.Lock()
        self.cache = None
        self.dirty = False
        self.last = 0.0
        self.failures = 0
        self.session = requests.Session()
        self.session.headers["User-Agent"] = USER_AGENT

    def _load(self):
        if self.cache is None:
            try:
                data = json.loads(self.file.read_text(encoding="utf-8"))
                self.cache = data if isinstance(data, dict) else {}
            except (OSError, ValueError):
                self.cache = {}

    def save(self):
        with self.lock:
            if not self.dirty or self.cache is None:
                return
            self.file.parent.mkdir(parents=True, exist_ok=True)
            temp = self.file.with_suffix(f".{threading.get_ident()}.tmp")
            temp.write_text(json.dumps(self.cache, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
            temp.replace(self.file)
            self.dirty = False

    def name(self, lat, lon, lang, allow_fetch=True):
        """"Stadt, Land" oder ""."""
        lat2, lon2 = round(float(lat), 2), round(float(lon), 2)
        key = f"{lat2},{lon2},{lang}"
        with self.lock:
            self._load()
            if key in self.cache:
                return self.cache[key]
        if not allow_fetch or self.failures >= 5 or photo_privacy.blocks(lat, lon):
            return ""
        with self.reverse_lock:
            wait = 1.1 - (time.time() - self.last)
            if wait > 0:
                time.sleep(wait)
            self.last = time.time()
            try:
                response = self.session.get(REVERSE, params={"lat": lat2, "lon": lon2, "format": "jsonv2", "zoom": 10,
                                                             "accept-language": lang}, timeout=TIMEOUT)
                response.raise_for_status()
                data = response.json()
            except (requests.RequestException, ValueError) as exc:
                self.failures += 1
                self.log(f"Ortsname {lat2},{lon2}: {str(exc)[:160]}", "warning")
                return ""
        self.failures = 0
        address = data.get("address") or {}
        city = next((address.get(k) for k in ("city", "town", "village", "municipality", "hamlet", "county",
                                               "state_district", "state") if address.get(k)), "")
        country = address.get("country") or ""
        name = (", ".join(x for x in (city, country) if x) or str(data.get("name") or ""))[:80]
        with self.lock:
            self.cache[key] = name
            self.dirty = True
        return name
