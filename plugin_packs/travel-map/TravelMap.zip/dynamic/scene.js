/* Travel Map - die Szene.
 *
 * Eine Weltkarte im Stil eines alten Globus (Pergament, Wasserlinien an den
 * Küsten, Gradnetz, Windrose) und darauf Stecknadeln an den Orten, an denen
 * die Fotos entstanden sind. Die Orte kommen vom Plugin Travel Map über den
 * Proxy der Weboberfläche, wie bei World Map Live.
 *
 * Querformat: ein ovaler Weltkarten-Globus (Mollweide) oder drei Globen;
 * Hochformat: drei Globen. "Um die Fotos" zeigt nur den Ausschnitt, in dem
 * Nadeln stecken. Beim Start stecken die Nadeln nach und nach, in der
 * Reihenfolge der Aufnahmen; danach zeigt die Szene ab und zu ein Foto an
 * seiner Nadel. Nadeln, die sich überdecken, werden zusammengefasst.
 *
 * Drei Canvas: "map" (Karte, nur bei Größen- oder Einstellungswechsel neu),
 * "pins" (Nadeln) und "fx" (Faden zur Fotokarte, Leuchten der Nadel).
 *
 * ?demo=1 zeigt erfundene Orte, ?lang=en, ?layout=globes, ?region=auto.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "TravelMap";
  const params = new URLSearchParams(location.search);
  const DEMO = params.has("demo");
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set([
    `${location.protocol}//${location.hostname}:8003${advanced}`,
    `${location.protocol}//${location.hostname}${advanced}`,
    `${location.origin}${advanced}`,
  ])];
  let baseIndex = 0;

  const TEXT = {
    de: { title: "Unsere Reisen", photos: "{n} Fotos", photo: "1 Foto", places: "{n} Orte", place: "1 Ort",
      busy: "Die Fotos werden eingelesen …", empty: "Noch keine Fotos mit Ort.",
      offline: "Travel Map antwortet nicht", ago: "heute vor {n} Jahren", ago1: "heute vor einem Jahr" },
    en: { title: "Our Travels", photos: "{n} photos", photo: "1 photo", places: "{n} places", place: "1 place",
      busy: "Reading the photos …", empty: "No photos with a location yet.",
      offline: "Travel Map is not responding", ago: "{n} years ago today", ago1: "one year ago today" },
    es: { title: "Nuestros viajes", photos: "{n} fotos", photo: "1 foto", places: "{n} lugares", place: "1 lugar",
      busy: "Leyendo las fotos …", empty: "Aún no hay fotos con ubicación.",
      offline: "Travel Map no responde", ago: "hoy hace {n} años", ago1: "hoy hace un año" },
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const OCEANS = [
    ["OCEANUS ATLANTICUS", -38, 30], ["OCEANUS ATLANTICUS", -18, -22], ["MARE PACIFICUM", -140, 8],
    ["MARE PACIFICUM", 170, -28], ["OCEANUS INDICUS", 78, -24], ["OCEANUS AUSTRALIS", 30, -55],
  ];
  // Ab Stufe 2: Nebenmeere, klein und in derselben alten Schreibweise
  const SEAS = [
    ["MARE MEDITERRANEUM", 18, 34.6], ["MARE BALTICUM", 19.6, 57.2], ["MARE GERMANICUM", 3.4, 56.2],
    ["MARE NIGRUM", 34, 43.3], ["MARE CASPIUM", 50.8, 42.2], ["MARE RUBRUM", 38.6, 20.2],
    ["SINUS PERSICUS", 51.6, 26.9], ["MARE ARABICUM", 63, 14], ["SINUS BENGALENSIS", 89, 14.5],
    ["MARE SINENSE", 114.5, 13.5], ["MARE IAPONICUM", 135, 40.5], ["MARE CORALLINUM", 155, -16],
    ["MARE TASMANICUM", 161, -38], ["MARE CARIBAEUM", -75, 14.5], ["SINUS MEXICANUS", -90.5, 25],
    ["SINUS HUDSONIUS", -85.5, 59.5], ["MARE GLACIALE", 40, 75], ["MARE NORVEGICUM", 2, 68],
  ];

  const RAD = Math.PI / 180;
  const SQRT2 = Math.SQRT2;
  const el = (id) => document.getElementById(id);
  const mapCanvas = el("map"), pinsCanvas = el("pins"), fxCanvas = el("fx");
  const mapCtx = mapCanvas.getContext("2d");
  const pinsCtx = pinsCanvas.getContext("2d");
  const fxCtx = fxCanvas.getContext("2d");
  const roseCanvas = el("rose"), roseCtx = roseCanvas.getContext("2d");

  const state = {
    lang: params.get("lang") || "de",
    layout: params.get("layout") || "oval",
    region: params.get("region") || "world",
    detail: 1,
    title: "",
    cluster: true, showPhotos: true, photoSeconds: 12, photoPause: 20, photoSize: "l", threadWidth: "thick", mapPan: true, showLegend: true,
    collections: [], cells: [], ver: -1, busy: false,
    reachable: true, failures: 0, loaded: false,
  };
  let W = 0, H = 0, dpr = 1, U = 1, pinR = 6;
  // Die Karte ist größer als der Bildschirm (quer OX links und rechts mehr,
  // hoch OY oben und unten), damit sie für ein Foto zur Seite rücken kann.
  // MW x MH ist ihre ganze Größe.
  let OX = 0, OY = 0, MW = 0, MH = 0, panX = 0, panY = 0;
  let views = [];
  let clusters = [];
  let settled = null;            // Offscreen-Canvas mit den Nadeln, die schon stecken
  let anim = null;               // {start, duration, next}
  let readySent = false;
  let paper = null;

  const tx = (key, values = {}) => ((TEXT[state.lang] || TEXT.de)[key] || key)
    .replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");
  const fmt = (n) => n.toLocaleString(LOCALES[state.lang] || "de-DE");

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  function rng(seed) {
    let a = seed >>> 0;
    return () => {
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // ------------------------------------------------------------ Projektionen
  //
  // Jede Ansicht hat fwd(lon, lat) -> [x, y, sichtbar], outline(ctx) für den
  // Rand und R (Pixel je Radiant ungefähr). Globen schieben verdeckte Punkte
  // auf den Rand, damit Landflächen sauber gefüllt werden.

  function mollweideUnit(lon, lat) {
    const phi = lat * RAD;
    let theta = phi;
    if (Math.abs(lat) < 89.999) {
      const target = Math.PI * Math.sin(phi);
      for (let i = 0; i < 12; i++) {
        const f = 2 * theta + Math.sin(2 * theta) - target;
        const d = 2 + 2 * Math.cos(2 * theta);
        if (d < 1e-9) break;
        theta -= f / d;
        if (Math.abs(f) < 1e-7) break;
      }
    } else {
      theta = Math.sign(lat) * Math.PI / 2;
    }
    return [(2 * SQRT2 / Math.PI) * lon * RAD * Math.cos(theta), SQRT2 * Math.sin(theta)];
  }

  function ovalView(box, ox = 0, oy = 0) {
    let R, cx, cy;
    if (!box) {
      R = Math.min(W * 0.955 / (4 * SQRT2), H * 0.85 / (2 * SQRT2));
      cx = W / 2 + ox;
      cy = H / 2 + oy;
    } else {
      const [x0, y0, x1, y1] = box;
      R = Math.min(W * 0.86 / (x1 - x0), H * 0.80 / (y1 - y0));
      cx = W / 2 - (x0 + x1) / 2 * R + ox;
      cy = H / 2 + (y0 + y1) / 2 * R + oy;
    }
    // S: Maßstab für Strichstärken und Schrift; beim Ausschnitt nach dem Bildschirm, nicht nach der Vergrößerung
    const v = { kind: "oval", R, cx, cy, crop: !!box, big: true, S: box ? Math.min(W, H) * 0.36 : R };
    v.fwd = (lon, lat) => {
      const [x, y] = mollweideUnit(lon, lat);
      return [cx + x * R, cy - y * R, true];
    };
    v.outline = (ctx) => {
      ctx.beginPath();
      ctx.ellipse(cx, cy, 2 * SQRT2 * R, SQRT2 * R, 0, 0, Math.PI * 2);
    };
    return v;
  }

  function globeView(lon0, lat0, cx, cy, R, big) {
    const l0 = lon0 * RAD, p0 = lat0 * RAD;
    const sp0 = Math.sin(p0), cp0 = Math.cos(p0);
    const v = { kind: "globe", R, cx, cy, big, lon0, lat0, S: R };
    v.fwd = (lon, lat) => {
      const p = lat * RAD, dl = lon * RAD - l0;
      const cp = Math.cos(p), sp = Math.sin(p), cdl = Math.cos(dl);
      let x = cp * Math.sin(dl);
      let y = cp0 * sp - sp0 * cp * cdl;
      const c = sp0 * sp + cp0 * cp * cdl;
      if (c < 0) {
        const len = Math.hypot(x, y) || 1;
        x /= len;
        y /= len;
      }
      return [cx + x * R, cy - y * R, c >= 0, c];
    };
    v.outline = (ctx) => {
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
    };
    return v;
  }

  // Drei Globen wie bei World Map Live: Europa/Afrika groß, Amerika und
  // Asien/Pazifik daneben (quer) oder darunter (hoch).
  function globeViews() {
    if (W >= H) {
      const big = H * 0.43;
      const small = Math.min(H * 0.235, (W - 2 * big) / 2 * 0.95 + big * 0.12);
      const off = big + small * 0.82;
      return [
        globeView(-80, 15, W / 2 - off, H * 0.66, small, false),
        globeView(125, 5, W / 2 + off, H * 0.66, small, false),
        globeView(15, 32, W / 2, H * 0.5, big, true),
      ];
    }
    const big = Math.min(W * 0.47, H * 0.25);
    const small = Math.min(W * 0.245, H * 0.135);
    const cyBig = H * 0.035 + big;
    const cySmall = cyBig + big + small * 0.92;
    return [
      globeView(-80, 15, W / 2 - small * 1.03, cySmall, small, false),
      globeView(125, 5, W / 2 + small * 1.03, cySmall, small, false),
      globeView(15, 32, W / 2, cyBig, big, true),
    ];
  }

  function cropBox() {
    if (!state.cells.length) return null;
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    for (const c of state.cells) {
      const [x, y] = mollweideUnit(c[1], c[0]);
      x0 = Math.min(x0, x); x1 = Math.max(x1, x);
      y0 = Math.min(y0, y); y1 = Math.max(y1, y);
    }
    const minW = 0.55, minH = 0.38;
    let w = x1 - x0, h = y1 - y0;
    const mx = (x0 + x1) / 2, my = (y0 + y1) / 2;
    w = Math.max(minW, w * 1.25); h = Math.max(minH, h * 1.3);
    // Seitenverhältnis des Bildschirms, damit nichts gestaucht wirkt
    const aspect = (W * 0.86) / (H * 0.80);
    if (w / h < aspect) w = h * aspect; else h = w / aspect;
    // Ein Ausschnitt größer als die halbe Welt: dann lieber die ganze Welt
    if (w > 4.2) return null;
    return [mx - w / 2, my - h / 2, mx + w / 2, my + h / 2];
  }

  function buildViews() {
    const portrait = H > W;
    const box = state.region === "auto" ? cropBox() : null;
    // Wie weit die Karte für ein Foto rücken darf: beim Ausschnitt weit
    // (dahinter geht die Karte weiter), bei der ganzen Welt nur ein Stück,
    // damit sie im Bild bleibt.
    OX = 0;
    OY = 0;
    if (state.mapPan && state.showPhotos) {
      if (portrait) OY = Math.round(H * (box ? 0.38 : 0.16));
      else OX = Math.round(W * (box ? 0.42 : 0.2));
    }
    MW = W + 2 * OX;
    MH = H + 2 * OY;
    if (box) { views = [ovalView(box, OX, OY)]; return; }
    if (portrait || state.layout === "globes") {
      views = globeViews();
      for (const v of views) Object.assign(v, globeView(v.lon0, v.lat0, v.cx + OX, v.cy + OY, v.R, v.big));
    } else {
      views = [ovalView(null, OX, OY)];
    }
  }

  // ------------------------------------------------------------ Karte

  function makePaper(W, H) {
    // Pergament: Körnung, ein paar Flecken, dunklere Ränder. Fester Zufall,
    // damit die Karte jedes Mal gleich alt aussieht.
    const c = document.createElement("canvas");
    c.width = Math.ceil(W * dpr);
    c.height = Math.ceil(H * dpr);
    const g = c.getContext("2d");
    g.scale(dpr, dpr);
    g.fillStyle = "#e6d5a8";
    g.fillRect(0, 0, W, H);
    const rand = rng(1823);
    for (let i = 0; i < 26; i++) {
      const x = rand() * W, y = rand() * H, r = (0.08 + rand() * 0.3) * Math.max(W, H);
      const grad = g.createRadialGradient(x, y, 0, x, y, r);
      const dark = rand() < 0.55;
      grad.addColorStop(0, dark ? `rgba(150,110,55,${0.05 + rand() * 0.08})` : `rgba(255,248,225,${0.08 + rand() * 0.1})`);
      grad.addColorStop(1, "rgba(150,110,55,0)");
      g.fillStyle = grad;
      g.fillRect(0, 0, W, H);
    }
    // Körnung
    const n = document.createElement("canvas");
    n.width = n.height = 192;
    const nc = n.getContext("2d");
    const img = nc.createImageData(192, 192);
    for (let i = 0; i < img.data.length; i += 4) {
      const v = 120 + rand() * 90;
      img.data[i] = v; img.data[i + 1] = v * 0.86; img.data[i + 2] = v * 0.62;
      img.data[i + 3] = rand() < 0.5 ? 26 : 10;
    }
    nc.putImageData(img, 0, 0);
    g.fillStyle = g.createPattern(n, "repeat");
    g.fillRect(0, 0, W, H);
    // Fasern
    g.strokeStyle = "rgba(120,85,40,.06)";
    g.lineWidth = 1;
    for (let i = 0; i < 260; i++) {
      const x = rand() * W, y = rand() * H, a = rand() * Math.PI, l = 8 + rand() * 40;
      g.beginPath();
      g.moveTo(x, y);
      g.quadraticCurveTo(x + Math.cos(a) * l * .5 + rand() * 6, y + Math.sin(a) * l * .5, x + Math.cos(a) * l, y + Math.sin(a) * l);
      g.stroke();
    }
    // dunkle Ränder
    const v = g.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.hypot(W, H) * 0.62);
    v.addColorStop(0, "rgba(90,60,25,0)");
    v.addColorStop(1, "rgba(90,60,25,.42)");
    g.fillStyle = v;
    g.fillRect(0, 0, W, H);
    return c;
  }

  function ringPath(v, ring, forFill) {
    // forFill: verdeckte Punkte auf dem Globusrand mitnehmen; sonst nur
    // sichtbare Stücke (für Küstenlinien), Naht bei ±180° auslassen.
    const path = new Path2D();
    const sc = SCALE;
    let lon = ring[0] / sc, lat = ring[1] / sc;
    let started = false, prevLon = lon, seen = false;
    for (let i = 0; i <= ring.length; i += 2) {
      if (i > 0 && i < ring.length) { lon += ring[i] / sc; lat += ring[i + 1] / sc; }
      if (i === ring.length) { lon = ring[0] / sc; lat = ring[1] / sc; }
      const [x, y, vis] = v.fwd(lon, lat);
      if (vis) seen = true;
      const seam = Math.abs(lon) > 179.9 && Math.abs(prevLon) > 179.9;
      if (forFill) {
        if (!started) { path.moveTo(x, y); started = true; } else path.lineTo(x, y);
      } else if (!vis || (v.kind === "oval" && seam)) {
        started = false;
      } else if (!started) {
        path.moveTo(x, y); started = true;
      } else {
        path.lineTo(x, y);
      }
      prevLon = lon;
    }
    if (forFill) path.closePath();
    path.seen = seen;
    return path;
  }

  function linePath(v, points, path = new Path2D()) {
    let started = false;
    for (const [lon, lat] of points) {
      const [x, y, vis] = v.fwd(lon, lat);
      if (!vis) { started = false; continue; }
      if (!started) { path.moveTo(x, y); started = true; } else path.lineTo(x, y);
    }
    return path;
  }

  function decode(rings) {
    return rings.map((ring) => {
      const pts = [];
      let lon = ring[0] / SCALE, lat = ring[1] / SCALE;
      pts.push([lon, lat]);
      for (let i = 2; i < ring.length; i += 2) { lon += ring[i] / SCALE; lat += ring[i + 1] / SCALE; pts.push([lon, lat]); }
      return pts;
    });
  }
  // Detailstufen: land.js ist Stufe 1, land-2.js … land-4.js werden erst bei Bedarf geladen
  let WORLD = window.WORLD_MAP || { land: [], lakes: [], borders: [] };
  let SCALE = 100, BORDERS = decode(WORLD.borders || []), RIVERS = [], PLACES = [], HILLS = [], BIG = [];
  let shownDetail = 1, loadingDetail = 0;

  function setWorld(data, level) {
    WORLD = data;
    SCALE = data.scale || 100;
    BORDERS = decode(data.borders || []);
    RIVERS = decode(data.rivers || []);
    PLACES = (data.places || []).slice().sort((a, b) => a[4] - b[4]);
    HILLS = data.hills || [];
    // Ringe ab etwa 0,6° Ausdehnung zählen als größere Küste
    BIG = decode(data.land).map((pts) => {
      let x0 = 999, x1 = -999, y0 = 999, y1 = -999;
      for (const [x, y] of pts) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
      return (x1 - x0) * (y1 - y0) > 0.35;
    });
    shownDetail = level;
  }

  // true: die gewünschte Stufe ist jetzt gesetzt (Karte neu malen);
  // false: schon gesetzt oder wird noch geladen (malt dann selbst neu)
  function ensureDetail() {
    const level = state.detail;
    if (level === shownDetail) return false;
    if (level === 1) { setWorld(window.WORLD_MAP, 1); return true; }
    const ready = (window.WORLD_MAP_DETAIL || {})[level];
    if (ready) { setWorld(ready, level); return true; }
    if (loadingDetail === level) return false;
    loadingDetail = level;
    const script = document.createElement("script");
    script.src = `land-${level}.js`;
    script.onload = () => {
      loadingDetail = 0;
      if (ensureDetail() && W) drawMap();
    };
    script.onerror = () => {
      loadingDetail = 0;
      report(`Karte Stufe ${level} nicht ladbar`);
    };
    document.head.appendChild(script);
    return false;
  }

  function graticule(v) {
    const lines = [];
    for (let lon = -180; lon <= 180; lon += 15) {
      const pts = [];
      for (let lat = -90; lat <= 90; lat += 2) pts.push([lon, lat]);
      lines.push({ pts, kind: "meridian" });
    }
    for (let lat = -75; lat <= 75; lat += 15) {
      const pts = [];
      for (let lon = -180; lon <= 180; lon += 2) pts.push([lon, lat]);
      lines.push({ pts, kind: lat === 0 ? "equator" : "parallel" });
    }
    for (const lat of [23.44, -23.44, 66.56, -66.56]) {
      const pts = [];
      for (let lon = -180; lon <= 180; lon += 2) pts.push([lon, lat]);
      lines.push({ pts, kind: "tropic" });
    }
    return lines.map((l) => ({ kind: l.kind, path: linePath(v, l.pts) }));
  }

  function spacedText(ctx, text, x, y, spacing) {
    const chars = [...text];
    const widths = chars.map((ch) => ctx.measureText(ch).width);
    const total = widths.reduce((a, b) => a + b, 0) + spacing * (chars.length - 1);
    let at = x - total / 2;
    chars.forEach((ch, i) => { ctx.fillText(ch, at + widths[i] / 2, y); at += widths[i] + spacing; });
  }

  function drawView(ctx, v) {
    const lw = Math.max(0.7, v.S * 0.0028);
    // ganz auf der Rückseite des Globus: gar nicht erst malen
    const land = WORLD.land.map((r) => ringPath(v, r, true)).filter((p) => p.seen);
    const coast = WORLD.land.map((r) => ringPath(v, r, false));
    const lakes = (WORLD.lakes || []).map((r) => ringPath(v, r, true)).filter((p) => p.seen);
    // Viele einzelne Linien als ein Pfad: ein Aufruf statt Tausender
    const merge = (paths) => { const all = new Path2D(); for (const p of paths) all.addPath(p); return all; };
    const coastAll = merge(coast), landAll = merge(land), lakesAll = merge(lakes);
    // Wasserlinien nur um größere Küsten, sonst werden viele Inselchen zu Flecken
    const coastBig = merge(shownDetail === 1 ? coast : coast.filter((_, i) => BIG[i]));

    ctx.save();
    // Schatten des Globus auf dem Papier
    ctx.save();
    ctx.shadowColor = "rgba(60,38,12,.45)";
    ctx.shadowBlur = v.R * 0.06;
    ctx.shadowOffsetY = v.R * 0.025;
    v.outline(ctx);
    ctx.fillStyle = "#b9c4a2";
    if (!v.crop) ctx.fill();
    ctx.restore();

    v.outline(ctx);
    if (!v.crop) ctx.clip();

    // Meer: hell oben links, dunkler zum Rand
    const lx = v.cx - v.R * (v.kind === "oval" ? 0.9 : 0.35), ly = v.cy - v.R * 0.35;
    const sea = ctx.createRadialGradient(lx, ly, v.R * 0.1, v.cx, v.cy, v.R * (v.kind === "oval" ? 3.0 : 1.05));
    sea.addColorStop(0, "#d6dcbf");
    sea.addColorStop(0.6, "#bfc9a6");
    sea.addColorStop(1, "#9eab88");
    ctx.fillStyle = sea;
    if (v.crop) ctx.fillRect(0, 0, MW, MH); else ctx.fill();

    // Wasserlinien an den Küsten (wie auf alten Karten)
    ctx.lineJoin = "round";
    for (let k = 5; k >= 1; k--) {
      ctx.strokeStyle = `rgba(62,82,70,${0.05 + (5 - k) * 0.025})`;
      ctx.lineWidth = lw * (k * 3.2);
      ctx.stroke(coastBig);
      ctx.strokeStyle = "rgba(214,220,191,.55)";
      ctx.lineWidth = lw * (k * 3.2 - 1.6);
      ctx.stroke(coastBig);
    }

    // Gradnetz unter dem Land
    for (const g of graticule(v)) {
      ctx.setLineDash(g.kind === "tropic" ? [lw * 6, lw * 4] : []);
      ctx.strokeStyle = g.kind === "equator" ? "rgba(130,52,30,.55)" : g.kind === "tropic"
        ? "rgba(130,52,30,.4)" : "rgba(88,70,45,.26)";
      ctx.lineWidth = g.kind === "equator" ? lw * 1.6 : lw * 0.9;
      ctx.stroke(g.path);
    }
    ctx.setLineDash([]);

    // Land
    const tint = ctx.createLinearGradient(v.cx - v.R, v.cy - v.R, v.cx + v.R, v.cy + v.R);
    tint.addColorStop(0, "#efdfb0");
    tint.addColorStop(1, "#e0c88e");
    ctx.fillStyle = tint;
    for (const p of land) ctx.fill(p);   // einzeln: auf dem Globus drehen Ringe am Rand sonst um
    // Handkolorierter Saum innen an der Küste
    ctx.save();
    ctx.clip(landAll);
    ctx.strokeStyle = "rgba(186,128,62,.30)";
    ctx.lineWidth = lw * 7;
    ctx.stroke(coastAll);
    // Gradnetz schwach auch über dem Land
    for (const g of graticule(v)) {
      if (g.kind !== "parallel" && g.kind !== "meridian") continue;
      ctx.strokeStyle = "rgba(88,70,45,.10)";
      ctx.lineWidth = lw * 0.8;
      ctx.stroke(g.path);
    }
    ctx.restore();

    // Seen
    ctx.fillStyle = "#c3cdab";
    for (const p of lakes) ctx.fill(p);

    // Flüsse (ab Stufe 2)
    if (RIVERS.length) {
      ctx.strokeStyle = "rgba(78,104,104,.55)";
      ctx.lineWidth = lw * 0.75;
      ctx.lineCap = "round";
      const rivers = new Path2D();
      for (const r of RIVERS) linePath(v, r, rivers);
      ctx.stroke(rivers);
      ctx.lineCap = "butt";
    }

    // Gebirge als kleine Bergzeichen (ab Stufe 3)
    if (HILLS.length) drawHills(ctx, v, lw);

    // Grenzen gepunktet
    ctx.strokeStyle = "rgba(112,72,38,.45)";
    ctx.lineWidth = lw * 0.9;
    ctx.setLineDash([lw * 1.2, lw * 2.4]);
    const borders = new Path2D();
    for (const b of BORDERS) linePath(v, b, borders);
    ctx.stroke(borders);
    ctx.setLineDash([]);

    // Küste
    ctx.strokeStyle = "#5a4022";
    ctx.lineWidth = lw * 1.25;
    ctx.stroke(coastAll);
    ctx.strokeStyle = "rgba(90,64,34,.5)";
    ctx.lineWidth = lw * 0.6;
    ctx.stroke(lakesAll);

    // Meeresnamen
    const size = Math.max(9, v.S * (v.kind === "oval" ? 0.055 : 0.042));
    const taken = [];
    ctx.font = `italic ${size}px Fell, Georgia, serif`;
    ctx.fillStyle = "rgba(52,64,54,.55)";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const done = new Set();
    for (const [name, lon, lat] of OCEANS) {
      if (v.kind === "globe" && !v.big) continue;
      const [x, y, vis, c] = v.fwd(lon, lat);
      if (!vis || (c !== undefined && c < 0.62)) continue;
      if (v.crop && (x < OX || x > OX + W || y < OY || y > OY + H)) continue;
      if (v.kind === "oval" && Math.abs(lon) > 150 && !v.crop) continue;   // zu nah am Rand des Ovals
      done.add(name);
      spacedText(ctx, name, x, y, size * 0.32);
      const w = ctx.measureText(name).width + size * 0.32 * name.length;
      taken.push([x - w / 2, y - size * 0.6, x + w / 2, y + size * 0.6]);
    }
    if (shownDetail >= 2) drawSeas(ctx, v, size, taken);
    if (PLACES.length) drawPlaces(ctx, v, size, taken);

    // Wölbung: Licht oben links, Schatten zum Rand
    if (!v.crop) {
      ctx.save();
      if (v.kind === "oval") {
        ctx.translate(v.cx, v.cy);
        ctx.scale(2, 1);
        const sh = ctx.createRadialGradient(-v.R * 0.35, -v.R * 0.45, v.R * 0.1, 0, 0, SQRT2 * v.R * 1.02);
        sh.addColorStop(0, "rgba(255,250,230,.18)");
        sh.addColorStop(0.65, "rgba(70,45,15,0)");
        sh.addColorStop(1, "rgba(60,38,12,.30)");
        ctx.fillStyle = sh;
        ctx.fillRect(-MW, -MH, 2 * MW, 2 * MH);
      } else {
        const sh = ctx.createRadialGradient(v.cx - v.R * 0.38, v.cy - v.R * 0.42, v.R * 0.05, v.cx, v.cy, v.R);
        sh.addColorStop(0, "rgba(255,250,230,.28)");
        sh.addColorStop(0.55, "rgba(70,45,15,0)");
        sh.addColorStop(1, "rgba(50,30,10,.42)");
        ctx.fillStyle = sh;
        ctx.fillRect(v.cx - v.R, v.cy - v.R, 2 * v.R, 2 * v.R);
      }
      ctx.restore();
    }
    ctx.restore();

    if (!v.crop) drawRim(ctx, v, lw);
  }

  function inFrame(v, x, y) {
    return !v.crop || (x >= OX && x <= OX + W && y >= OY && y <= OY + H);
  }

  // Pixel pro Grad an einer Stelle (für Größe und Abstand der Bergzeichen)
  function pxPerDeg(v, lon, lat) {
    const [x0, y0] = v.fwd(lon, lat), [x1, y1] = v.fwd(lon, lat + 0.5);
    return Math.hypot(x1 - x0, y1 - y0) * 2;
  }

  function drawHills(ctx, v, lw) {
    const step = shownDetail >= 4 ? 0.55 : 0.9;
    const grid = new Set();
    ctx.save();
    ctx.lineJoin = "round";
    ctx.lineWidth = Math.max(0.6, lw * 0.7);
    let cell = 0, s = 0;
    for (let i = 0; i < HILLS.length; i += 2) {
      const lon = HILLS[i], lat = HILLS[i + 1];
      const [x, y, vis, c] = v.fwd(lon, lat);
      if (!vis || (c !== undefined && c < 0.3) || !inFrame(v, x, y)) continue;
      if (!cell) {
        // Abstand und Größe einmal je Ansicht aus dem Maßstab ableiten
        cell = Math.max(9, pxPerDeg(v, lon, lat) * step);
        s = Math.min(16, Math.max(3, cell * 0.42));
      }
      const key = `${Math.round(x / cell)},${Math.round(y / cell)}`;
      if (grid.has(key)) continue;
      grid.add(key);
      // Schattenseite rechts, Linie oben
      ctx.beginPath();
      ctx.moveTo(x, y - s * 0.62);
      ctx.lineTo(x + s, y + s * 0.42);
      ctx.lineTo(x + s * 0.15, y + s * 0.42);
      ctx.closePath();
      ctx.fillStyle = "rgba(128,86,44,.30)";
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(x - s, y + s * 0.42);
      ctx.lineTo(x, y - s * 0.62);
      ctx.lineTo(x + s, y + s * 0.42);
      ctx.strokeStyle = "rgba(92,60,30,.70)";
      ctx.stroke();
    }
    ctx.restore();
  }

  function free(taken, box) {
    for (const b of taken) {
      if (box[0] < b[2] && box[2] > b[0] && box[1] < b[3] && box[3] > b[1]) return false;
    }
    taken.push(box);
    return true;
  }

  function drawSeas(ctx, v, size, taken) {
    if (v.kind === "globe" && !v.big && !v.crop) return;
    const sz = Math.max(8, size * 0.42);
    ctx.save();
    ctx.font = `italic ${sz}px Fell, Georgia, serif`;
    ctx.fillStyle = "rgba(52,64,54,.6)";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (const [name, lon, lat] of SEAS) {
      const [x, y, vis, c] = v.fwd(lon, lat);
      if (!vis || (c !== undefined && c < 0.5) || !inFrame(v, x, y)) continue;
      const w = ctx.measureText(name).width + sz * 0.18 * name.length;
      if (!free(taken, [x - w / 2, y - sz * 0.6, x + w / 2, y + sz * 0.6])) continue;
      spacedText(ctx, name, x, y, sz * 0.18);
    }
    ctx.restore();
  }

  function drawPlaces(ctx, v, size, taken) {
    const sz = Math.max(9, size * 0.42);
    ctx.save();
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (const [names, lon, lat, kind, rank] of PLACES) {
      // auf kleinen Globen nur die großen Namen
      if (v.kind === "globe" && !v.big && !v.crop && rank > 1) continue;
      const [x, y, vis, c] = v.fwd(lon, lat);
      if (!vis || (c !== undefined && c < 0.45) || !inFrame(v, x, y)) continue;
      const name = names[state.lang] || names.en || names.de || "";
      if (!name) continue;
      const big = rank <= 1 ? 1.15 : 1;
      const desert = kind === "d";
      const text = desert ? name.toUpperCase() : name;
      ctx.font = `italic ${sz * big}px Fell, Georgia, serif`;
      const gap = desert ? sz * 0.3 : 0;
      const w = ctx.measureText(text).width + gap * text.length;
      if (!free(taken, [x - w / 2 - 2, y - sz * 0.7, x + w / 2 + 2, y + sz * 0.7])) continue;
      ctx.fillStyle = "rgba(239,223,176,.75)";
      ctx.strokeStyle = "rgba(239,223,176,.75)";
      ctx.lineWidth = sz * 0.28;
      ctx.lineJoin = "round";
      if (desert) {
        ctx.fillStyle = "rgba(120,76,36,.72)";
        spacedText(ctx, text, x, y, gap);
      } else {
        ctx.strokeText(text, x, y);
        ctx.fillStyle = "rgba(84,52,24,.85)";
        ctx.fillText(text, x, y);
      }
    }
    ctx.restore();
  }

  function drawRim(ctx, v, lw) {
    ctx.save();
    if (v.kind === "globe" && v.big) {
      // Meridianring aus Messing, wie an einem Tischglobus
      const w = v.R * 0.045;
      const ring = ctx.createLinearGradient(v.cx - v.R, v.cy - v.R, v.cx + v.R, v.cy + v.R);
      ring.addColorStop(0, "#f2d78e");
      ring.addColorStop(0.35, "#b8893a");
      ring.addColorStop(0.7, "#e7c477");
      ring.addColorStop(1, "#6e4b1c");
      ctx.beginPath();
      ctx.arc(v.cx, v.cy, v.R + w / 2, 0, Math.PI * 2);
      ctx.lineWidth = w;
      ctx.strokeStyle = ring;
      ctx.stroke();
      ctx.lineWidth = 1;
      ctx.strokeStyle = "rgba(60,38,12,.7)";
      for (const r of [v.R, v.R + w]) { ctx.beginPath(); ctx.arc(v.cx, v.cy, r, 0, Math.PI * 2); ctx.stroke(); }
      // Gradstriche auf dem Ring
      ctx.strokeStyle = "rgba(60,38,12,.55)";
      for (let a = 0; a < 360; a += 5) {
        const long = a % 30 === 0;
        const r0 = v.R + w * (long ? 0.15 : 0.55), r1 = v.R + w * 0.95;
        const t = a * RAD;
        ctx.lineWidth = long ? 1.4 : 0.8;
        ctx.beginPath();
        ctx.moveTo(v.cx + Math.cos(t) * r0, v.cy + Math.sin(t) * r0);
        ctx.lineTo(v.cx + Math.cos(t) * r1, v.cy + Math.sin(t) * r1);
        ctx.stroke();
      }
    } else {
      const grow = (d) => {
        ctx.beginPath();
        if (v.kind === "oval") ctx.ellipse(v.cx, v.cy, 2 * SQRT2 * v.R + d, SQRT2 * v.R + d, 0, 0, Math.PI * 2);
        else ctx.arc(v.cx, v.cy, v.R + d, 0, Math.PI * 2);
      };
      const step = Math.max(3, v.R * 0.012);
      ctx.strokeStyle = "#4a3219";
      ctx.lineWidth = lw * 1.8;
      grow(0); ctx.stroke();
      // Gradleiste: abwechselnd hell und dunkel
      ctx.lineWidth = step * 0.9;
      ctx.strokeStyle = "#f1e6c8";
      grow(step * 0.75); ctx.stroke();
      ctx.setLineDash([step * 2.2, step * 2.2]);
      ctx.strokeStyle = "#4a3219";
      grow(step * 0.75); ctx.stroke();
      ctx.setLineDash([]);
      ctx.lineWidth = lw;
      grow(step * 1.25); ctx.stroke();
      grow(step * 2.1); ctx.lineWidth = lw * 0.8; ctx.stroke();
    }
    ctx.restore();
  }

  function drawCompass(ctx, x, y, r) {
    ctx.save();
    ctx.translate(x, y);
    ctx.lineJoin = "round";
    // Ringe
    ctx.strokeStyle = "rgba(59,42,23,.8)";
    ctx.fillStyle = "rgba(243,231,198,.55)";
    ctx.lineWidth = Math.max(1, r * 0.02);
    ctx.beginPath(); ctx.arc(0, 0, r * 0.82, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.arc(0, 0, r * 0.74, 0, Math.PI * 2); ctx.stroke();
    for (let a = 0; a < 360; a += 11.25) {
      const t = a * RAD, long = a % 45 === 0;
      ctx.lineWidth = Math.max(0.6, r * (long ? 0.014 : 0.008));
      ctx.beginPath();
      ctx.moveTo(Math.sin(t) * r * 0.74, -Math.cos(t) * r * 0.74);
      ctx.lineTo(Math.sin(t) * r * (long ? 0.86 : 0.8), -Math.cos(t) * r * (long ? 0.86 : 0.8));
      ctx.stroke();
    }
    const point = (angle, len, width, dark, light) => {
      const t = angle * RAD;
      const tip = [Math.sin(t) * len, -Math.cos(t) * len];
      const side = (s) => [Math.sin(t + s * Math.PI / 2) * width, -Math.cos(t + s * Math.PI / 2) * width];
      const [lx, ly] = side(-1), [rx, ry] = side(1);
      ctx.fillStyle = dark;
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(tip[0], tip[1]); ctx.lineTo(lx, ly); ctx.closePath(); ctx.fill();
      ctx.fillStyle = light;
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(tip[0], tip[1]); ctx.lineTo(rx, ry); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = "rgba(59,42,23,.85)";
      ctx.lineWidth = Math.max(0.6, r * 0.01);
      ctx.beginPath(); ctx.moveTo(lx, ly); ctx.lineTo(tip[0], tip[1]); ctx.lineTo(rx, ry); ctx.stroke();
    };
    for (let a = 22.5; a < 360; a += 45) point(a, r * 0.42, r * 0.05, "#7c6440", "#efe2bf");
    for (let a = 45; a < 360; a += 90) point(a, r * 0.58, r * 0.08, "#3b2a17", "#d9c49a");
    for (let a = 0; a < 360; a += 90) point(a, r * 0.78, r * 0.11, a === 0 ? "#8a1f14" : "#3b2a17", "#f3e7c6");
    ctx.fillStyle = "#3b2a17";
    ctx.beginPath(); ctx.arc(0, 0, r * 0.04, 0, Math.PI * 2); ctx.fill();
    ctx.font = `${r * 0.3}px "Fell SC", Fell, Georgia, serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "#3b2a17";
    ctx.fillText("N", 0, -r * 0.9);
    ctx.restore();
  }

  function compassPlace() {
    const r = Math.min(W, H) * 0.085;
    const v = views[views.length - 1];
    if (H > W) return [W - r * 1.15, H - r * 1.35, r];
    if (v.kind === "oval" && !v.crop) return [W - r * 1.2, r * 1.25, r];
    return [W - r * 1.2, r * 1.25, r];
  }

  function drawMap() {
    const t0 = performance.now();
    mapCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (!paper || paper.width !== Math.ceil(MW * dpr) || paper.height !== Math.ceil(MH * dpr)) paper = makePaper(MW, MH);
    mapCtx.drawImage(paper, 0, 0, MW, MH);
    for (const v of views) drawView(mapCtx, v);
    const [x, y, r] = compassPlace();
    // Rollt die Karte, bleibt die Windrose stehen: dann auf eigener Ebene
    roseCtx.setTransform(1, 0, 0, 1, 0, 0);
    roseCtx.clearRect(0, 0, roseCanvas.width, roseCanvas.height);
    if (OX || OY) {
      roseCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
      drawCompass(roseCtx, x, y, r);
      roseCtx.save();
      roseCtx.globalAlpha = 0.35;
      roseCtx.globalCompositeOperation = "source-atop";
      roseCtx.drawImage(paper, OX * dpr, OY * dpr, W * dpr, H * dpr, 0, 0, W, H);
      roseCtx.restore();
    } else {
      drawCompass(mapCtx, x, y, r);
    }
    // Etwas Papier auch über der Karte: sie soll nicht gedruckt wirken
    mapCtx.save();
    mapCtx.globalAlpha = 0.35;
    mapCtx.globalCompositeOperation = "multiply";
    mapCtx.drawImage(paper, 0, 0, MW, MH);
    mapCtx.restore();
    if (params.has("timing")) console.log(`Karte Stufe ${shownDetail}: ${Math.round(performance.now() - t0)} ms`);
  }

  // ------------------------------------------------------------ Nadeln

  function shade(hex, f) {
    const n = parseInt(hex.slice(1), 16);
    let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    if (f >= 0) { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; } else { r *= 1 + f; g *= 1 + f; b *= 1 + f; }
    return `rgb(${r | 0},${g | 0},${b | 0})`;
  }

  function ball(ctx, x, y, r, color) {
    const g = ctx.createRadialGradient(x - r * 0.38, y - r * 0.42, r * 0.08, x, y, r);
    g.addColorStop(0, shade(color, 0.65));
    g.addColorStop(0.35, color);
    g.addColorStop(1, shade(color, -0.55));
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,.75)";
    ctx.beginPath(); ctx.ellipse(x - r * 0.35, y - r * 0.4, r * 0.22, r * 0.15, -0.6, 0, Math.PI * 2); ctx.fill();
  }

  function needle(ctx, x0, y0, x1, y1, w) {
    const g = ctx.createLinearGradient(x0 - w, y0, x0 + w, y0);
    g.addColorStop(0, "#5d5d5d"); g.addColorStop(0.5, "#e6e6e6"); g.addColorStop(1, "#6b6b6b");
    ctx.strokeStyle = g;
    ctx.lineWidth = w;
    ctx.lineCap = "round";
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
  }

  function shadowLine(ctx, x, y, dx, dy, w, blur) {
    ctx.save();
    ctx.strokeStyle = "rgba(40,25,8,.28)";
    ctx.lineWidth = w;
    ctx.lineCap = "round";
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + dx, y + dy); ctx.stroke();
    ctx.fillStyle = "rgba(40,25,8,.22)";
    ctx.beginPath(); ctx.ellipse(x + dx, y + dy, blur, blur * 0.7, 0.4, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  // Die Spitze jeder Nadel sitzt genau auf (x, y).
  function drawPin(ctx, kind, x, y, r, color, alpha = 1) {
    ctx.save();
    ctx.globalAlpha = alpha;
    if (kind === "tack") {
      // Reißzwecke, schräg von oben
      ctx.fillStyle = "rgba(40,25,8,.3)";
      ctx.beginPath(); ctx.ellipse(x + r * 0.55, y + r * 0.2, r * 1.15, r * 0.75, 0, 0, Math.PI * 2); ctx.fill();
      const hx = x, hy = y - r * 0.55;
      ctx.fillStyle = shade(color, -0.45);
      ctx.beginPath(); ctx.ellipse(hx, hy + r * 0.18, r * 1.15, r * 0.82, 0, 0, Math.PI * 2); ctx.fill();
      const g = ctx.createRadialGradient(hx - r * 0.4, hy - r * 0.35, r * 0.1, hx, hy, r * 1.15);
      g.addColorStop(0, shade(color, 0.55)); g.addColorStop(0.5, color); g.addColorStop(1, shade(color, -0.3));
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.ellipse(hx, hy, r * 1.1, r * 0.78, 0, 0, Math.PI * 2); ctx.fill();
      ball(ctx, hx, hy - r * 0.08, r * 0.48, color);
    } else if (kind === "flag") {
      const top = y - r * 3.6;
      shadowLine(ctx, x, y, r * 1.8, -r * 1.1, r * 0.25, r * 0.5);
      ctx.strokeStyle = "#4a3219";
      ctx.lineWidth = Math.max(1, r * 0.22);
      ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x, top); ctx.stroke();
      const fw = r * 2.1, fh = r * 1.35;
      const g = ctx.createLinearGradient(x, top, x + fw, top + fh);
      g.addColorStop(0, shade(color, 0.2)); g.addColorStop(1, shade(color, -0.25));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(x, top + r * 0.1);
      ctx.bezierCurveTo(x + fw * 0.35, top - r * 0.35, x + fw * 0.65, top + r * 0.45, x + fw, top + r * 0.15);
      ctx.lineTo(x + fw * 0.82, top + fh * 0.6);
      ctx.lineTo(x + fw, top + fh + r * 0.05);
      ctx.bezierCurveTo(x + fw * 0.65, top + fh + r * 0.35, x + fw * 0.35, top + fh - r * 0.45, x, top + fh);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = "rgba(40,25,8,.45)";
      ctx.lineWidth = Math.max(0.6, r * 0.08);
      ctx.stroke();
      ball(ctx, x, top - r * 0.12, r * 0.3, "#c9a24a");
    } else if (kind === "needle") {
      // Lange Glaskopfnadel, steil
      const hx = x + r * 0.55, hy = y - r * 3.4;
      shadowLine(ctx, x, y, r * 2.4, -r * 1.3, r * 0.22, r * 0.5);
      needle(ctx, x, y, hx, hy, Math.max(1, r * 0.17));
      ball(ctx, hx, hy, r * 0.62, color);
    } else {
      // Stecknadel mit rundem Kopf, leicht schräg
      const hx = x + r * 0.95, hy = y - r * 2.3;
      shadowLine(ctx, x, y, r * 2.1, -r * 0.7, r * 0.28, r * 0.85);
      needle(ctx, x, y, hx, hy, Math.max(1, r * 0.22));
      ball(ctx, hx, hy, r, color);
    }
    // Einstichpunkt
    ctx.fillStyle = "rgba(40,25,8,.55)";
    ctx.beginPath(); ctx.arc(x, y, Math.max(0.8, r * 0.14), 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }

  function pinHead(kind, x, y, r) {
    if (kind === "tack") return [x, y - r * 0.6];
    if (kind === "flag") return [x + r * 1.0, y - r * 3.0];
    if (kind === "needle") return [x + r * 0.55, y - r * 3.4];
    return [x + r * 0.95, y - r * 2.3];
  }

  function label(ctx, x, y, text, r) {
    ctx.save();
    const size = Math.max(10, r * 1.5);
    ctx.font = `italic ${size}px Fell, Georgia, serif`;
    const w = ctx.measureText(text).width + size * 0.7, h = size * 1.15;
    const lx = x - r * 0.4, ly = y + r * 0.5;
    ctx.fillStyle = "rgba(246,238,214,.92)";
    ctx.strokeStyle = "rgba(59,42,23,.7)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.rect(lx, ly, w, h);
    ctx.fill(); ctx.stroke();
    ctx.fillStyle = "#3b2a17";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(text, lx + w / 2, ly + h / 2 + size * 0.05);
    ctx.restore();
  }

  function computeClusters() {
    const points = [];
    // Jeder Ort steckt nur einmal: auf dem Globus, auf dem er am weitesten
    // vorn liegt, und nicht dort, wo ein anderer Globus davor liegt.
    state.cells.forEach((cell, order) => {
      let best = null;
      views.forEach((v, i) => {
        const [x, y, vis, c = 1] = v.fwd(cell[1], cell[0]);
        if (!vis || x < -pinR || x > MW + pinR || y < -pinR || y > MH + pinR) return;
        const hidden = views.some((o, j) => j > i && o.kind === "globe" && Math.hypot(x - o.cx, y - o.cy) < o.R * 1.04);
        if (hidden) return;
        if (!best || c > best.c) best = { x, y, c };
      });
      if (best) points.push({ x: best.x, y: best.y, cell, order });
    });
    const radius = state.cluster ? pinR * 2.6 : 0;
    const out = [];
    if (!radius) {
      for (const p of points) out.push(newCluster(p));
    } else {
      points.sort((a, b) => b.cell[3] - a.cell[3]);
      const grid = new Map();
      const keyOf = (x, y) => `${Math.floor(x / radius)},${Math.floor(y / radius)}`;
      for (const p of points) {
        const gx = Math.floor(p.x / radius), gy = Math.floor(p.y / radius);
        let best = null, bestD = radius * radius;
        for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) {
          for (const c of grid.get(`${gx + dx},${gy + dy}`) || []) {
            const d = (c.x - p.x) ** 2 + (c.y - p.y) ** 2;
            if (d < bestD) { best = c; bestD = d; }
          }
        }
        if (best) addTo(best, p);
        else {
          const c = newCluster(p);
          out.push(c);
          const k = keyOf(p.x, p.y);
          if (!grid.has(k)) grid.set(k, []);
          grid.get(k).push(c);
        }
      }
    }
    for (const c of out) {
      const ranked = [...c.cols.entries()].sort((a, b) => b[1] - a[1]).map((e) => e[0]);
      c.ranked = ranked;
      c.scale = c.places > 1 ? Math.min(1.45, 1 + Math.log10(c.places) * 0.28) : 1;
    }
    out.sort((a, b) => a.order - b.order);
    clusters = out;
  }

  function newCluster(p) {
    const c = { x: p.x, y: p.y, n: 0, places: 0, cols: new Map(), order: p.order, cells: [] };
    addTo(c, p);
    return c;
  }

  function addTo(c, p) {
    c.n += p.cell[3];
    c.places += 1;
    c.order = Math.min(c.order, p.order);
    c.cols.set(p.cell[2], (c.cols.get(p.cell[2]) || 0) + p.cell[3]);
    c.cells.push(p.cell);
  }

  function collectionOf(index) {
    return state.collections[index] || { color: "#b3261e", pin: "pin" };
  }

  function drawCluster(ctx, c, dy = 0, alpha = 1) {
    const extra = c.ranked.slice(1, 3);
    extra.forEach((index, i) => {
      const col = collectionOf(index);
      drawPin(ctx, col.pin, c.x + (i === 0 ? -1 : 1) * pinR * 0.9, c.y + dy - pinR * 0.15, pinR * 0.85 * c.scale,
        col.color, alpha);
    });
    const main = collectionOf(c.ranked[0]);
    drawPin(ctx, main.pin, c.x, c.y + dy, pinR * c.scale, main.color, alpha);
    if (c.places > 1 && dy === 0) label(ctx, c.x, c.y, fmt(c.n), pinR);
  }

  function sizeCanvas(c, width = MW, height = MH) {
    c.width = Math.ceil(width * dpr);
    c.height = Math.ceil(height * dpr);
  }

  function renderSettled(list) {
    settled = settled || document.createElement("canvas");
    if (settled.width !== Math.ceil(MW * dpr) || settled.height !== Math.ceil(MH * dpr)) sizeCanvas(settled);
    const g = settled.getContext("2d");
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.clearRect(0, 0, settled.width, settled.height);
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    // Südliche Nadeln vorn: sie stecken "näher" am Betrachter
    for (const c of [...list].sort((a, b) => a.y - b.y)) drawCluster(g, c);
  }

  function blit() {
    pinsCtx.setTransform(1, 0, 0, 1, 0, 0);
    pinsCtx.clearRect(0, 0, pinsCanvas.width, pinsCanvas.height);
    if (settled) pinsCtx.drawImage(settled, 0, 0);
  }

  function renderPins(animate) {
    anim = null;
    if (!animate || !clusters.length) {
      renderSettled(clusters);
      blit();
      updateCounts(clusters.length);
      return;
    }
    renderSettled([]);
    blit();
    const duration = Math.min(9, 2.5 + clusters.length * 0.012) * 1000;
    anim = { start: performance.now(), duration, landed: 0 };
    requestAnimationFrame(step);
  }

  const FALL = 520;
  function step(time) {
    if (!anim) return;
    const t = time - anim.start;
    const n = clusters.length;
    const g = settled.getContext("2d");
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    while (anim.landed < n && (anim.landed / n) * anim.duration + FALL <= t) {
      drawCluster(g, clusters[anim.landed]);
      anim.landed++;
    }
    blit();
    pinsCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    for (let i = anim.landed; i < n; i++) {
      const at = (i / n) * anim.duration;
      if (at > t) break;
      const k = (t - at) / FALL;
      const ease = 1 - Math.pow(1 - k, 3);
      drawCluster(pinsCtx, clusters[i], -(1 - ease) * pinR * 7, Math.min(1, k * 2.5));
    }
    updateCounts(anim.landed);
    if (anim.landed < n) requestAnimationFrame(step);
    else { renderPins(false); scheduleCard(1500); }
  }

  // ------------------------------------------------------------ Texte

  function updateCounts(landedClusters) {
    let photos = 0, places = 0, first = "", last = "";
    const list = clusters.slice(0, landedClusters);
    for (const c of list) {
      photos += c.n;
      places += c.places;
    }
    for (const cell of state.cells) {
      if (cell[4]) {
        if (!first || cell[4] < first) first = cell[4];
        if (!last || cell[4] > last) last = cell[4];
      }
    }
    const parts = [];
    if (state.cells.length) {
      parts.push(photos === 1 ? tx("photo") : tx("photos", { n: fmt(photos) }));
      parts.push(places === 1 ? tx("place") : tx("places", { n: fmt(places) }));
      if (first && last) parts.push(first.slice(0, 4) === last.slice(0, 4) ? first.slice(0, 4)
        : `${first.slice(0, 4)} – ${last.slice(0, 4)}`);
    }
    el("subtitle").textContent = parts.join(" · ");
  }

  function miniPin(kind, color) {
    const c = document.createElement("canvas");
    const s = Math.ceil(U * 2.6 * dpr);
    c.width = c.height = s;
    const g = c.getContext("2d");
    const r = s * (kind === "tack" ? 0.3 : kind === "pin" ? 0.26 : 0.22);
    const x = kind === "tack" ? s * 0.5 : kind === "needle" ? s * 0.38 : s * 0.24;
    const y = kind === "tack" ? s * 0.78 : s * 0.94;
    drawPin(g, kind, x, y, r, color);
    return c;
  }

  function renderOverlays() {
    el("title").textContent = state.title || tx("title");
    const legend = el("legend");
    legend.textContent = "";
    if (state.showLegend && state.collections.length > 1) {
      for (const col of state.collections) {
        const li = document.createElement("li");
        li.appendChild(miniPin(col.pin, col.color));
        const name = document.createElement("span");
        name.className = "name";
        name.textContent = col.name;
        const count = document.createElement("span");
        count.className = "count";
        count.textContent = fmt(col.photos || 0);
        li.append(name, count);
        legend.appendChild(li);
      }
    }
    el("legendBox").style.display = legend.childElementCount ? "" : "none";
    let note = "";
    if (!state.reachable && !DEMO) note = tx("offline");
    else if (!state.cells.length) note = state.busy || !state.loaded ? tx("busy") : tx("empty");
    el("note").textContent = note;
    el("cartouche").classList.toggle("hidden", false);
    placeOverlays();
  }

  function placeOverlays() {
    const cart = el("cartouche").style, leg = el("legendBox").style;
    const m = `${U * 2.4}px`;
    for (const s of [cart, leg]) { s.left = s.right = s.top = s.bottom = "auto"; }
    const v = views[views.length - 1];
    if (H > W) {
      cart.left = m; cart.bottom = `calc(${m} + ${el("legendBox").offsetHeight + U * 2.2}px)`;
      leg.left = m; leg.bottom = m;
      if (!el("legendBox").offsetHeight) cart.bottom = m;
    } else if (v && v.kind === "globe") {
      cart.left = m; cart.top = m;
      leg.left = m; leg.top = `${U * 2.4 + el("cartouche").offsetHeight + U * 2.2}px`;
    } else {
      cart.left = m; cart.top = m;
      leg.left = m; leg.bottom = m;
    }
  }

  // ------------------------------------------------------------ Fotokarte

  let cardTimer = 0;
  let cardPending = false;
  let cardBusy = false;
  let cardBusySince = 0;
  let cardFailures = 0;
  const recent = [];

  function scheduleCard(ms) {
    clearTimeout(cardTimer);
    cardPending = false;
    if (!state.showPhotos) return;
    cardPending = true;
    cardTimer = setTimeout(() => { cardPending = false; showCard(); }, ms);
  }

  // Sicherheitsnetz: ist keine Fotokarte geplant (z. B. weil beim Start noch
  // keine Fotos da waren), plant dieser Wächter die nächste.
  // Hängt eine Karte (Bild lädt nicht, Animation angehalten), gibt er sie
  // nach einer Weile frei.
  setInterval(() => {
    if (cardBusy && performance.now() - cardBusySince > (state.photoSeconds + 90) * 1000) {
      report("Fotokarte hing und wurde freigegeben");
      cardBusy = false;
      el("card").classList.remove("show");
      clearFx();
    }
    if (anim && performance.now() - anim.start > anim.duration + 15000) renderPins(false);
    if (state.showPhotos && !cardPending && !cardBusy && !anim) scheduleCard(state.photoPause * 1000);
  }, 5000);

  // Meldet der Plugin-Seite, was in der Szene schiefging; steht dann in plugins.log.
  let reported = 0;
  function report(text) {
    if (DEMO || reported++ > 40) return;
    fetch(`${pluginBases[baseIndex]}api/report?m=${encodeURIComponent(String(text).slice(0, 200))}`,
      { cache: "no-store" }).catch(() => {});
  }

  function loadImage(img, src, ms) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { img.removeAttribute("src"); reject(new Error("Zeitüberschreitung")); }, ms);
      img.onload = () => { clearTimeout(timer); resolve(); };
      img.onerror = () => { clearTimeout(timer); reject(new Error("nicht ladbar")); };
      img.src = src;
    });
  }

  function pickCluster() {
    const withKeys = clusters.filter((c) => c.cells.some((cell) => (cell[5] || []).length));
    if (!withKeys.length) return null;
    for (let i = 0; i < 12; i++) {
      const c = withKeys[Math.floor(Math.random() * withKeys.length)];
      if (!recent.includes(c) || i === 11) return c;
    }
    return withKeys[0];
  }

  function formatDate(iso) {
    if (!iso || iso.length < 7) return "";
    const d = new Date(`${iso.slice(0, 10)}T12:00:00`);
    if (Number.isNaN(d.getTime())) return iso.slice(0, 10);
    return d.toLocaleDateString(LOCALES[state.lang] || "de-DE", { month: "long", year: "numeric" });
  }

  // Die Karte (und ihre Nadeln) verschieben, sanft per CSS.
  const PAN_MS = 1800;
  function setPan(x, y, animate) {
    panX = x;
    panY = y;
    for (const c of [mapCanvas, pinsCanvas]) {
      c.style.transition = animate ? `transform ${PAN_MS}ms cubic-bezier(.45,.05,.35,1)` : "none";
      c.style.transform = x || y ? `translate(${x}px, ${y}px)` : "";
    }
    return animate ? new Promise((r) => setTimeout(r, PAN_MS + 60)) : Promise.resolve();
  }
  const screenX = (x) => x - OX + panX;
  const screenY = (y) => y - OY + panY;

  // Rückt die Karte so, dass die Nadel nah am Rand sitzt (quer links oder
  // rechts, hoch oben oder unten): dann hat das Foto den Rest für sich.
  function panFor(cluster) {
    const x = cluster.x - OX, y = cluster.y - OY;
    const px = OX ? Math.max(-OX, Math.min(OX, (x < W / 2 ? W * 0.12 : W * 0.88) - x)) : 0;
    const py = OY ? Math.max(-OY, Math.min(OY, (y < H / 2 ? H * 0.14 : H * 0.86) - y)) : 0;
    return [px, py];
  }

  // Das Plugin wählt das nächste Foto nach der eingestellten Reihenfolge;
  // antwortet es nicht, wählt die Szene selbst zufällig.
  async function nextPhoto() {
    if (DEMO) return null;
    const got = await fetchJson(`api/next?v=${state.ver}`).catch(() => null);
    if (!got || !got.success) return null;
    const cell = state.cells.find((c) => (c[5] || []).includes(got.k));
    const cluster = cell && clusters.find((c) => c.cells.includes(cell));
    return cluster ? { cluster, cell, key: got.k, ago: got.ago || 0 } : null;
  }

  async function showCard() {
    if (cardBusy || anim || !clusters.length) { scheduleCard(3000); return; }
    cardBusy = true;
    cardBusySince = performance.now();
    let pick = await nextPhoto();
    if (!pick) {
      const cluster = pickCluster();
      if (!cluster) { cardBusy = false; scheduleCard(10000); return; }
      const cells = cluster.cells.filter((cell) => (cell[5] || []).length);
      const cell = cells[Math.floor(Math.random() * cells.length)];
      pick = { cluster, cell, key: cell[5][Math.floor(Math.random() * cell[5].length)], ago: 0 };
    }
    const { cluster, cell, key, ago } = pick;
    recent.push(cluster);
    if (recent.length > 15) recent.shift();
    let shown = false;
    try {
      const [src, info] = DEMO ? demoPhoto(cell) : await Promise.all([
        Promise.resolve(`${pluginBases[baseIndex]}api/photo?k=${key}&v=${state.ver}`),
        fetchJson(`api/info?k=${key}&v=${state.ver}`).catch(() => ({})),
      ]);
      const img = el("cardImg");
      await loadImage(img, src, 45000);
      const [px, py] = panFor(cluster);
      if (Math.abs(px) > W * 0.03 || Math.abs(py) > H * 0.03) await setPan(px, py, true);
      const since = ago === 1 ? tx("ago1") : ago > 1 ? tx("ago", { n: ago }) : "";
      await presentCard(cluster, img, info || {}, cell, since);
      if (panX || panY) await setPan(0, 0, true);
      shown = true;
      cardFailures = 0;
    } catch (exc) {
      // Foto nicht ladbar: gleich ein anderes versuchen, nach ein paar Fehlschlägen erst nach der Pause
      cardFailures++;
      report(`Foto ${key}: ${exc && exc.message ? exc.message : exc}`);
    } finally {
      cardBusy = false;
      const retry = !shown && cardFailures < 6;
      scheduleCard(retry ? 2000 : state.photoPause * 1000);
    }
  }

  function presentCard(cluster, img, info, cell, since = "") {
    return new Promise((resolve) => {
      const card = el("card");
      const ratio = Math.max(0.66, Math.min(1.5, (img.naturalWidth || 4) / (img.naturalHeight || 3)));
      const short = Math.min(W, H);
      const k = PHOTO_SIZES[state.photoSize] || PHOTO_SIZES.l;
      let pw = short * (H > W ? 0.44 : 0.36) * k, ph = pw / ratio;
      const maxH = Math.min(short * 0.42 * k, H * 0.72), maxW = W * 0.6;
      if (ph > maxH) { ph = maxH; pw = ph * ratio; }
      if (pw > maxW) { pw = maxW; ph = pw / ratio; }
      el("cardPlace").textContent = info.place || "";
      const when = formatDate(info.taken || cell[4]);
      el("cardDate").textContent = [when, since].filter(Boolean).join(" · ");
      const main = collectionOf(cluster.ranked[0]);
      const [hx, hy] = pinHead(main.pin, screenX(cluster.x), screenY(cluster.y), pinR * cluster.scale);
      // Ist die Karte gerückt, steht das Foto mitten auf der freien Seite.
      const moved = OX || OY;
      const tx = OX ? (hx < W / 2 ? (hx + W) / 2 : hx / 2) : moved ? W / 2 : hx;
      const ty = OY ? (hy < H / 2 ? (hy + H) / 2 : hy / 2) : moved ? H / 2 : hy;
      const size = (f) => {
        const w = pw * f, h = ph * f;
        card.querySelector(".photo").style.width = `${w}px`;
        card.querySelector(".photo").style.height = `${h}px`;
        const cw = w + U * 2.2;
        card.style.width = `${cw}px`;
        const ch = card.offsetHeight || h + U * 7;
        return [cw, ch, cardSpot(hx, hy, cw, ch, tx, ty)];
      };
      // Ist viel Platz frei (z. B. neben dem Oval), darf das Foto größer werden.
      let [cw, ch, spot] = size(1);
      let grown = false;
      const maxW2 = moved ? W * 0.74 : W * 0.62;
      for (const f of [2.8, 2.4, 2, 1.7, 1.45, 1.2]) {
        if (pw * f > maxW2 || ph * f + U * 9 > H * 0.88) continue;
        const bigger = size(f);
        // Ein größeres Foto darf etwas mehr Karte verdecken (Jan: lieber groß).
        if (bigger[2][3] <= spot[3] + 4 + (f - 1) * (moved ? 30 : 15)) { [cw, ch, spot] = bigger; grown = true; break; }
      }
      if (!grown) size(1);
      const [left, top, right] = spot;
      const tilt = (Math.random() * 2 - 1) * 3.2;
      card.style.left = `${left}px`;
      card.style.top = `${top}px`;
      card.style.transform = `rotate(${tilt}deg) translateY(${U * 1.5}px)`;
      const anchor = [right ? left + U * 1.2 : left + cw - U * 1.2, top + U * 1.2];
      requestAnimationFrame(() => {
        card.classList.add("show");
        card.style.transform = `rotate(${tilt}deg)`;
      });
      const shownFor = Math.max(4, state.photoSeconds) * 1000;
      const start = performance.now();
      let done = false;
      // Das Ende hängt an einem Timer, nicht an der Animation: hält der
      // Browser die Animation an, geht es trotzdem weiter.
      setTimeout(() => {
        done = true;
        clearFx();
        card.classList.remove("show");
        setTimeout(resolve, 900);
      }, shownFor);
      const fx = (time) => {
        if (done) return;
        const t = time - start;
        const fade = Math.min(1, t / 900, Math.max(0, (shownFor - t) / 900));
        try { drawThread(hx, hy, anchor, fade, t, pinR * cluster.scale); } catch (_) { /* nur Zierde */ }
        requestAnimationFrame(fx);
      };
      requestAnimationFrame(fx);
    });
  }

  // Wohin mit der Karte: neben die Nadel, wo sie die wenigsten anderen
  // Nadeln und keine Kartusche verdeckt.
  function inMap(x, y) {
    x += OX - panX;   // Bildschirm -> Karte
    y += OY - panY;
    for (const v of views) {
      if (v.crop) return true;
      const dx = x - v.cx, dy = y - v.cy;
      if (v.kind === "globe" ? Math.hypot(dx, dy) <= v.R
        : (dx / (2 * SQRT2 * v.R)) ** 2 + (dy / (SQRT2 * v.R)) ** 2 <= 1) return true;
    }
    return false;
  }

  // Wohin mit dem Foto: an die Stelle, die am wenigsten Karte, Nadeln,
  // Kartusche und Windrose verdeckt und nah am Ziel liegt. Ziel ist die
  // Nadel, bei gerollter Karte die Mitte der freien Seite.
  function cardSpot(hx, hy, cw, ch, tx, ty) {
    const short = Math.min(W, H);
    const blocks = ["cartouche", "legendBox"].map((id) => el(id).getBoundingClientRect())
      .filter((r) => r.width > 0);
    const [rx, ry, rr] = compassPlace();
    blocks.push({ left: rx - rr, right: rx + rr, top: ry - rr * 1.3, bottom: ry + rr });
    const M = U * 2;
    const spanX = Math.max(0, W - cw - 2 * M), spanY = Math.max(0, H - ch - M - U * 3);
    const area = cw * ch;
    let best = null;
    for (let i = 0; i < 20; i++) {
      const left = M + spanX * i / 19;
      for (let j = 0; j < 14; j++) {
        const top = M + spanY * j / 13;
        if (hx > left - pinR * 2 && hx < left + cw + pinR * 2 && hy > top - pinR * 4 && hy < top + ch + pinR * 2) continue;
        let inside = 0;
        for (let a = 0; a < 5; a++) for (let b = 0; b < 5; b++) {
          if (inMap(left + cw * (a + 0.5) / 5, top + ch * (b + 0.5) / 5)) inside++;
        }
        let score = (inside / 25) * 70;
        for (const c of clusters) {
          const cx = screenX(c.x), cy = screenY(c.y);
          if (cx > left - pinR && cx < left + cw + pinR && cy > top && cy < top + ch + pinR * 3) score += 3 + Math.sqrt(c.places) * 2;
        }
        for (const b of blocks) {
          const ox = Math.max(0, Math.min(left + cw, b.right) - Math.max(left, b.left));
          const oy = Math.max(0, Math.min(top + ch, b.bottom) - Math.max(top, b.top));
          score += (ox * oy) / area * 300;
        }
        score += Math.hypot(left + cw / 2 - tx, top + ch / 2 - ty) / short * 30;
        // Etwas Abstand, damit der Faden zu sehen ist
        const ex = Math.max(left - hx, hx - left - cw, 0), ey = Math.max(top - hy, hy - top - ch, 0);
        if (Math.hypot(ex, ey) < short * 0.04) score += 15;
        if (!best || score < best[3]) best = [left, top, left + cw / 2 > hx, score];
      }
    }
    return best || [M, M, true, 0];
  }


  function clearFx() {
    fxCtx.setTransform(1, 0, 0, 1, 0, 0);
    fxCtx.clearRect(0, 0, fxCanvas.width, fxCanvas.height);
  }

  const PHOTO_SIZES = { s: 0.85, m: 1, l: 1.25, xl: 1.55 };
  const THREAD_WIDTHS = { thin: 0.7, normal: 1, thick: 1.7, xthick: 2.6 };

  function drawThread(hx, hy, [ax, ay], fade, t, r) {
    const w = THREAD_WIDTHS[state.threadWidth] || 1;
    clearFx();
    if (fade <= 0) return;
    const g = fxCtx;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.globalAlpha = fade;
    // Leuchten um die Nadel, zwei Mal, dann ruhig
    const pulse = t < 2400 ? (t % 1200) / 1200 : 1;
    g.strokeStyle = `rgba(139,30,20,${0.6 * (1 - pulse) + 0.25})`;
    g.lineWidth = Math.max(1.5, r * 0.25) * Math.sqrt(w);
    g.beginPath(); g.arc(hx, hy, r * (1.6 + pulse * 1.8), 0, Math.PI * 2); g.stroke();
    // Roter Faden mit etwas Durchhang
    const mx = (hx + ax) / 2, my = Math.max(hy, ay) + Math.abs(ax - hx) * 0.12;
    g.strokeStyle = "rgba(139,30,20,.85)";
    g.lineWidth = Math.max(1.2, r * 0.2) * w;
    g.lineCap = "round";
    g.beginPath(); g.moveTo(hx, hy); g.quadraticCurveTo(mx, my, ax, ay); g.stroke();
    g.globalAlpha = 1;
  }

  // ------------------------------------------------------------ Daten

  async function fetchJson(path) {
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 15000);
    try {
      const response = await fetch(pluginBases[baseIndex] + path, { cache: "no-store", signal: abort.signal });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      return await response.json();
    } finally {
      clearTimeout(timer);
    }
  }

  function apply(data) {
    const s = data.settings || {};
    const layoutKey = () => `${state.layout}|${state.region}|${state.cluster}|${state.mapPan}|${state.showPhotos}`;
    const layoutBefore = layoutKey();
    state.lang = s.Language || state.lang;
    state.layout = params.get("layout") || s.Layout || state.layout;
    state.region = params.get("region") || s.Region || state.region;
    state.detail = Math.max(1, Math.min(4, Number(params.get("detail") || s.MapDetail) || 1));
    const detailNow = ensureDetail();
    state.title = s.Title || "";
    state.cluster = s.Cluster !== false;
    state.showPhotos = s.ShowPhotos !== false && params.get("photos") !== "0";
    state.photoSeconds = s.PhotoSeconds || 12;
    state.photoPause = Number.isFinite(s.PhotoPause) ? s.PhotoPause : 20;
    state.photoSize = params.get("size") || s.PhotoSize || state.photoSize;
    state.threadWidth = params.get("thread") || s.ThreadWidth || state.threadWidth;
    state.mapPan = params.has("pan") ? params.get("pan") !== "0" : s.MapPan !== false;
    state.showLegend = s.ShowLegend !== false;
    state.collections = data.collections || [];
    state.busy = !!data.busy;
    let fresh = false;
    if (Array.isArray(data.cells)) {
      state.cells = data.cells;
      state.ver = data.ver;
      fresh = true;
    }
    const first = !state.loaded;
    state.loaded = true;
    const changed = layoutBefore !== layoutKey();
    if (first || changed || (fresh && state.region === "auto")) {
      layout(first || fresh);
    } else if (detailNow) {
      drawMap();
      if (fresh) { computeClusters(); renderPins(false); }
    } else if (fresh) {
      computeClusters();
      renderPins(false);
    }
    renderOverlays();
    if (!state.showPhotos) { clearTimeout(cardTimer); cardPending = false; }
    else if (!cardPending && !cardBusy && !anim) scheduleCard(3000);
  }

  async function poll() {
    if (DEMO) return;
    try {
      const data = await fetchJson(`api/scene?v=${state.ver}`);
      state.reachable = true;
      state.failures = 0;
      apply(data);
    } catch (_) {
      state.failures++;
      if (pluginBases.length > 1) baseIndex = (baseIndex + 1) % pluginBases.length;
      if (state.failures >= pluginBases.length * 2) {
        state.reachable = false;
        if (!state.loaded) { state.loaded = true; layout(false); }
        renderOverlays();
      }
    }
    setTimeout(poll, state.loaded && state.reachable ? 30000 : 4000);
  }

  // ------------------------------------------------------------ Aufbau

  function layout(animate) {
    W = window.innerWidth;
    H = window.innerHeight;
    dpr = Math.min(2, window.devicePixelRatio || 1);
    U = Math.min(W, H) / 100;
    document.documentElement.style.setProperty("--u", `${U}px`);
    pinR = Math.max(5, Math.min(20, Math.min(W, H) * 0.0092));
    buildViews();
    for (const c of [mapCanvas, pinsCanvas]) {
      sizeCanvas(c);
      c.style.width = `${MW}px`;
      c.style.height = `${MH}px`;
      c.style.left = `${-OX}px`;
      c.style.top = `${-OY}px`;
    }
    sizeCanvas(fxCanvas, W, H);
    sizeCanvas(roseCanvas, W, H);
    setPan(0, 0, false);
    drawMap();
    computeClusters();
    renderPins(animate);
    renderOverlays();
    ready();
  }

  let resizeTimer = 0;
  window.addEventListener("resize", () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => layout(false), 250);
  });

  // ------------------------------------------------------------ Vorführung

  const DEMO_PLACES = [
    ["Lissabon, Portugal", 38.72, -9.14, 0, "2016-05"], ["Porto, Portugal", 41.15, -8.61, 0, "2016-05"],
    ["Sevilla, Spanien", 37.39, -5.98, 0, "2017-04"], ["Barcelona, Spanien", 41.39, 2.17, 0, "2018-09"],
    ["Paris, Frankreich", 48.86, 2.35, 0, "2014-03"], ["Rom, Italien", 41.9, 12.5, 0, "2015-10"],
    ["Florenz, Italien", 43.77, 11.25, 0, "2015-10"], ["Venedig, Italien", 45.44, 12.33, 0, "2019-02"],
    ["Wien, Österreich", 48.21, 16.37, 0, "2020-12"], ["Prag, Tschechien", 50.08, 14.44, 0, "2013-08"],
    ["Kopenhagen, Dänemark", 55.68, 12.57, 0, "2021-07"], ["Bergen, Norwegen", 60.39, 5.32, 1, "2022-07"],
    ["Tromsø, Norwegen", 69.65, 18.96, 1, "2022-07"], ["Reykjavík, Island", 64.15, -21.94, 1, "2019-06"],
    ["Edinburgh, Schottland", 55.95, -3.19, 0, "2012-08"], ["Dublin, Irland", 53.35, -6.26, 0, "2012-08"],
    ["Amsterdam, Niederlande", 52.37, 4.9, 0, "2011-04"], ["Berlin, Deutschland", 52.52, 13.4, 2, "2010-06"],
    ["Hamburg, Deutschland", 53.55, 9.99, 2, "2010-06"], ["München, Deutschland", 48.14, 11.58, 2, "2011-09"],
    ["Köln, Deutschland", 50.94, 6.96, 2, "2010-06"], ["Dresden, Deutschland", 51.05, 13.74, 2, "2023-03"],
    ["Rügen, Deutschland", 54.43, 13.43, 2, "2018-08"], ["Sylt, Deutschland", 54.9, 8.31, 2, "2019-08"],
    ["Garmisch-Partenkirchen", 47.49, 11.1, 2, "2020-02"], ["Zürich, Schweiz", 47.37, 8.54, 0, "2016-01"],
    ["Zermatt, Schweiz", 46.02, 7.75, 0, "2016-01"], ["Kreta, Griechenland", 35.24, 24.81, 0, "2017-09"],
    ["Athen, Griechenland", 37.98, 23.73, 0, "2017-09"], ["Istanbul, Türkei", 41.01, 28.98, 0, "2018-04"],
    ["Marrakesch, Marokko", 31.63, -8.0, 1, "2019-11"], ["Kairo, Ägypten", 30.04, 31.24, 1, "2020-01"],
    ["Kapstadt, Südafrika", -33.92, 18.42, 1, "2023-11"], ["Sansibar, Tansania", -6.16, 39.2, 1, "2023-12"],
    ["New York, USA", 40.71, -74.0, 1, "2015-12"], ["San Francisco, USA", 37.77, -122.42, 1, "2018-06"],
    ["Grand Canyon, USA", 36.1, -112.1, 1, "2018-06"], ["Vancouver, Kanada", 49.28, -123.12, 1, "2024-08"],
    ["Havanna, Kuba", 23.11, -82.37, 1, "2021-03"], ["Mexiko-Stadt", 19.43, -99.13, 1, "2021-03"],
    ["Cusco, Peru", -13.53, -71.97, 1, "2024-04"], ["Rio de Janeiro, Brasilien", -22.91, -43.17, 1, "2014-07"],
    ["Patagonien, Argentinien", -50.34, -72.26, 1, "2024-02"], ["Tokio, Japan", 35.68, 139.69, 1, "2025-04"],
    ["Kyoto, Japan", 35.01, 135.77, 1, "2025-04"], ["Bangkok, Thailand", 13.76, 100.5, 1, "2013-01"],
    ["Bali, Indonesien", -8.41, 115.19, 1, "2017-02"], ["Hanoi, Vietnam", 21.03, 105.85, 1, "2019-03"],
    ["Sydney, Australien", -33.87, 151.21, 1, "2022-12"], ["Queenstown, Neuseeland", -45.03, 168.66, 1, "2023-01"],
    ["Dubai, VAE", 25.2, 55.27, 1, "2020-11"], ["Kathmandu, Nepal", 27.72, 85.32, 1, "2016-10"],
    ["Mallorca, Spanien", 39.57, 2.65, 0, "2022-05"], ["Gardasee, Italien", 45.65, 10.65, 2, "2021-08"],
  ];

  function demoData() {
    const rand = rng(7);
    const cells = [];
    DEMO_PLACES.forEach(([, lat, lon, col, t], i) => {
      const n = 1 + Math.floor(rand() * rand() * 140);
      cells.push([lat, lon, col, n, `${t}-15`, [i]]);
      if (rand() < 0.35) cells.push([lat + (rand() - 0.5) * 0.6, lon + (rand() - 0.5) * 0.8, col, 3, `${t}-20`, [i]]);
    });
    if (params.get("demo") === "eu") {   // nur Europa: zum Prüfen des Ausschnitts
      for (let i = cells.length - 1; i >= 0; i--) {
        if (cells[i][0] < 34 || cells[i][1] < -12 || cells[i][1] > 32) cells.splice(i, 1);
      }
    }
    cells.sort((a, b) => a[4].localeCompare(b[4]));
    const counts = [0, 0, 0];
    cells.forEach((c) => { counts[c[2]] += c[3]; });
    return {
      ver: 1,
      settings: { Language: state.lang, Layout: state.layout, Region: state.region, Cluster: true,
        ShowPhotos: true, PhotoSeconds: 12, ShowLegend: true },
      collections: [
        { name: { de: "Europa-Album", en: "Europe album", es: "Álbum de Europa" }[state.lang] || "Europa-Album",
          color: "#b3261e", pin: "pin", photos: counts[0] },
        { name: { de: "Fernreisen (Immich)", en: "Far away (Immich)", es: "Lejos (Immich)" }[state.lang] || "Fernreisen",
          color: "#1f4e8c", pin: "flag", photos: counts[1] },
        { name: { de: "Playlist Deutschland", en: "Playlist Germany", es: "Lista Alemania" }[state.lang] || "Deutschland",
          color: "#2e6b34", pin: "tack", photos: counts[2] },
      ],
      cells,
    };
  }

  function demoPhoto(cell) {
    const i = cell[5][0];
    const [place] = DEMO_PLACES[i] || ["?"];
    const c = document.createElement("canvas");
    c.width = 800; c.height = 600;
    const g = c.getContext("2d");
    const rand = rng(i + 3);
    const hue = 180 + rand() * 40;
    const sky = g.createLinearGradient(0, 0, 0, 380);
    sky.addColorStop(0, `hsl(${hue},55%,62%)`); sky.addColorStop(1, `hsl(${hue - 150},70%,82%)`);
    g.fillStyle = sky; g.fillRect(0, 0, 800, 600);
    g.fillStyle = "rgba(255,240,200,.9)";
    g.beginPath(); g.arc(560 + rand() * 120, 150, 55, 0, Math.PI * 2); g.fill();
    for (let k = 0; k < 3; k++) {
      g.fillStyle = `hsl(${100 + k * 25 + rand() * 30},${30 + k * 10}%,${42 - k * 9}%)`;
      g.beginPath(); g.moveTo(0, 600);
      for (let x = 0; x <= 800; x += 40) g.lineTo(x, 330 + k * 70 + Math.sin(x / (90 + k * 40) + rand() * 6) * (50 - k * 10));
      g.lineTo(800, 600); g.closePath(); g.fill();
    }
    return [c.toDataURL("image/jpeg", 0.85), { place, taken: cell[4] }];
  }

  // ------------------------------------------------------------ Start

  async function start() {
    try {
      await Promise.race([
        Promise.all([document.fonts.load('italic 20px "Fell"'), document.fonts.load('20px "Fell"'),
          document.fonts.load('20px "Fell SC"')]),
        new Promise((r) => setTimeout(r, 2500)),
      ]);
    } catch (_) { /* Systemschrift */ }
    if (DEMO) {
      apply(demoData());
      return;
    }
    // Sofort eine Karte, dann die Nadeln
    layout(false);
    poll();
  }

  start();
})();
