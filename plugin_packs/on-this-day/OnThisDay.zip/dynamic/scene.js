/* On This Day - die Szene.
 *
 * Zeigt die Fotos vom heutigen Tag aus früheren Jahren, dazu das Wetter von
 * damals am Ort des Fotos und das Wetter heute. Die Fotos und das Wetter
 * kommen vom Plugin OnThisDay über den Proxy der Weboberfläche.
 *
 * Zwei Ansichten:
 * - journey: ein Foto nach dem anderen, Jahr für Jahr, mit Zeitleiste unten,
 * - wall:    alle Jahre nebeneinander als Karten, eine nach der anderen hervorgehoben.
 * Danach (wenn eingeschaltet) eine Übersicht: ein Foto je Jahr, die
 * Temperaturen der Jahre und ein paar Vergleiche.
 *
 * ?plugin=<url> nimmt ein anderes Plugin (Tests), ?lang=, ?layout=, ?view=summary.
 */
(function () {
  "use strict";

  const PLUGIN_ID = "OnThisDay";
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set([
    `${location.protocol}//${location.hostname}:8003${advanced}`,
    `${location.protocol}//${location.hostname}${advanced}`,
    `${location.origin}${advanced}`,
  ])];
  // Kommt die Szene über Port 80/443 (RemoteFrame, Web Login), zuerst denselben Ursprung fragen.
  if (!params.get("plugin") && (location.port === "" || location.port === "80" || location.port === "443")) {
    pluginBases.sort((a, b) => (b.startsWith(location.origin) ? 1 : 0) - (a.startsWith(location.origin) ? 1 : 0));
  }
  let baseIndex = 0;
  const base = () => pluginBases[baseIndex];

  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const TEXT = {
    de: {
      ago: "Heute vor {n} Jahren", ago1: "Heute vor einem Jahr",
      around: "Um diesen Tag vor {n} Jahren", around1: "Um diesen Tag vor einem Jahr",
      kicker: "Zeitreise", kickerWide: "Zeitreise · ± {n} Tage",
      then: "Damals", now: "Heute", nowHome: "Heute in {place}", nowThere: "Heute dort", home: "zu Hause",
      warmer: "{n}° wärmer als heute", colder: "{n}° kälter als heute", same: "so warm wie heute",
      near: "Wetter vom Ort eines anderen Fotos dieses Tages", atHome: "Wetter zu Hause (Foto ohne Ort)",
      rain: "{n} mm", sun: "{n} h Sonne",
      wallTitle: "Heute vor … Jahren", wallTitleWide: "Um diesen Tag in früheren Jahren",
      agoShort: "vor {n} J.", agoShort1: "vor 1 J.",
      sumTitle: "{date} in {n} Jahren", sumTitle1: "{date} vor einem Jahr",
      fWarm: "Am wärmsten war es {y}{at}: {t}.", fCold: "Am kältesten war es {y}{at}: {t}.",
      fWet: "Am nassesten war {y} mit {mm} mm Regen.", fDry: "{n} von {all} Jahren blieben trocken.",
      fAvg: "Im Schnitt waren es an diesem Tag {t}, heute sind es {now}.", fAvgSame: "Im Schnitt waren es an diesem Tag {t}, genau wie heute.",
      fPlace: "In {place} warst du an diesem Tag in {n} Jahren.", fPhotos: "{n} Fotos an diesem Tag seit {y}.",
      at: " in {p}",
      emptyTitle: "Heute keine Erinnerungen", emptyText: "An einem {date} hast du bisher keine Fotos gemacht.",
      emptyNext: "Die nächste Erinnerung kommt am {date}.", busy: "Die Fotos von heute werden gesucht …",
      offline: "On This Day antwortet nicht", noSource: "Wähle auf der Plugin-Seite, woher die Fotos kommen.",
      chartToday: "heute",
      codes: { clear: "Sonnig", clearNight: "Klar", mostly: "Heiter", partly: "Teils bewölkt", overcast: "Bedeckt",
        fog: "Nebel", drizzle: "Nieselregen", freezing: "Eisregen", rain: "Regen", heavyRain: "Starker Regen",
        snow: "Schnee", showers: "Regenschauer", snowShowers: "Schneeschauer", thunder: "Gewitter", hail: "Gewitter mit Hagel" },
    },
    en: {
      ago: "{n} years ago today", ago1: "One year ago today",
      around: "Around this day {n} years ago", around1: "Around this day a year ago",
      kicker: "Time travel", kickerWide: "Time travel · ± {n} days",
      then: "Back then", now: "Today", nowHome: "Today in {place}", nowThere: "Today there", home: "at home",
      warmer: "{n}° warmer than today", colder: "{n}° colder than today", same: "as warm as today",
      near: "Weather where another photo of that day was taken", atHome: "Weather at home (photo without location)",
      rain: "{n} mm", sun: "{n} h sun",
      wallTitle: "On this day", wallTitleWide: "Around this day in earlier years",
      agoShort: "{n} y ago", agoShort1: "1 y ago",
      sumTitle: "{date} over {n} years", sumTitle1: "{date} a year ago",
      fWarm: "The warmest was {y}{at}: {t}.", fCold: "The coldest was {y}{at}: {t}.",
      fWet: "The wettest was {y} with {mm} mm of rain.", fDry: "{n} of {all} years stayed dry.",
      fAvg: "On average it was {t} on this day; today it is {now}.", fAvgSame: "On average it was {t} on this day, just like today.",
      fPlace: "You were in {place} on this day in {n} different years.", fPhotos: "{n} photos on this day since {y}.",
      at: " in {p}",
      emptyTitle: "No memories today", emptyText: "You have not taken any photos on a {date} yet.",
      emptyNext: "The next memory comes on {date}.", busy: "Looking for today's photos …",
      offline: "On This Day is not responding", noSource: "Pick on the plugin page where the photos come from.",
      chartToday: "today",
      codes: { clear: "Sunny", clearNight: "Clear", mostly: "Mostly clear", partly: "Partly cloudy", overcast: "Overcast",
        fog: "Fog", drizzle: "Drizzle", freezing: "Freezing rain", rain: "Rain", heavyRain: "Heavy rain",
        snow: "Snow", showers: "Showers", snowShowers: "Snow showers", thunder: "Thunderstorm", hail: "Thunderstorm with hail" },
    },
    es: {
      ago: "Hoy hace {n} años", ago1: "Hoy hace un año",
      around: "Por estas fechas hace {n} años", around1: "Por estas fechas hace un año",
      kicker: "Viaje en el tiempo", kickerWide: "Viaje en el tiempo · ± {n} días",
      then: "Entonces", now: "Hoy", nowHome: "Hoy en {place}", nowThere: "Hoy allí", home: "en casa",
      warmer: "{n}° más cálido que hoy", colder: "{n}° más frío que hoy", same: "igual que hoy",
      near: "Tiempo donde se hizo otra foto de ese día", atHome: "Tiempo en casa (foto sin ubicación)",
      rain: "{n} mm", sun: "{n} h de sol",
      wallTitle: "Tal día como hoy", wallTitleWide: "Por estas fechas en años anteriores",
      agoShort: "hace {n} a", agoShort1: "hace 1 a",
      sumTitle: "{date} en {n} años", sumTitle1: "{date} hace un año",
      fWarm: "El más cálido fue {y}{at}: {t}.", fCold: "El más frío fue {y}{at}: {t}.",
      fWet: "El más lluvioso fue {y} con {mm} mm.", fDry: "{n} de {all} años fueron secos.",
      fAvg: "De media hacía {t} este día; hoy hace {now}.", fAvgSame: "De media hacía {t} este día, igual que hoy.",
      fPlace: "Estuviste en {place} este día en {n} años distintos.", fPhotos: "{n} fotos de este día desde {y}.",
      at: " en {p}",
      emptyTitle: "Hoy no hay recuerdos", emptyText: "Todavía no tienes fotos de un {date}.",
      emptyNext: "El próximo recuerdo llega el {date}.", busy: "Buscando las fotos de hoy …",
      offline: "On This Day no responde", noSource: "Elige en la página del plugin de dónde vienen las fotos.",
      chartToday: "hoy",
      codes: { clear: "Soleado", clearNight: "Despejado", mostly: "Poco nuboso", partly: "Parcialmente nuboso", overcast: "Cubierto",
        fog: "Niebla", drizzle: "Llovizna", freezing: "Lluvia helada", rain: "Lluvia", heavyRain: "Lluvia fuerte",
        snow: "Nieve", showers: "Chubascos", snowShowers: "Chubascos de nieve", thunder: "Tormenta", hail: "Tormenta con granizo" },
    },
  };

  const el = (id) => document.getElementById(id);
  const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const state = {
    lang: params.get("lang") || "en",
    s: { Layout: params.get("layout") || "journey", YearOrder: "oldest", PhotoSeconds: 8, FadeSeconds: 1.5, KenBurns: true,
      ShowSummary: true, SummarySeconds: 15, ShowWeather: true, TodayAt: "home", HomeName: "", Units: "c", ShowPlace: true },
    ver: -1, date: "", years: [], facts: {}, window: 0, next: "", today: { home: null }, busy: false, sources: 1,
    reachable: true, failures: 0, loaded: false,
  };
  let readySent = false;
  let slides = [];
  let pos = -1;
  let timer = 0;
  let pendingRebuild = false;
  let front = "A";
  let wallPos = -1;
  let viewShown = "";

  const tx = (key, values = {}) => String((TEXT[state.lang] || TEXT.en)[key] ?? TEXT.en[key] ?? key)
    .replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");
  const locale = () => LOCALES[state.lang] || "en-GB";

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }

  function report(text) {
    try {
      fetch(`${base()}api/report?m=${encodeURIComponent(String(text).slice(0, 200))}`, { cache: "no-store" }).catch(() => {});
    } catch (_) { /* egal */ }
  }

  // ------------------------------------------------------------ Größe

  function sizeUnits() {
    const W = window.innerWidth, H = window.innerHeight;
    const root = document.documentElement;
    root.style.setProperty("--u", `${Math.min(W, H) / 100}px`);
    root.classList.toggle("portrait", H > W * 1.05);
  }
  window.addEventListener("resize", () => { sizeUnits(); if (viewShown === "wall") renderWall(); if (viewShown === "journey") drawTimeline(); });
  sizeUnits();

  // ------------------------------------------------------------ Datum, Temperatur, Wetter

  const dateOf = (iso) => new Date(Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10), 12));
  const longDate = (iso) => dateOf(iso).toLocaleDateString(locale(), { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });
  const dayMonth = (iso) => dateOf(iso).toLocaleDateString(locale(), { day: "numeric", month: "long", timeZone: "UTC" });
  const clockOf = (taken) => {
    const h = +taken.slice(11, 13), m = +taken.slice(14, 16);
    if (Number.isNaN(h)) return "";
    return new Date(Date.UTC(2000, 0, 1, h, m)).toLocaleTimeString(locale(), { hour: "2-digit", minute: "2-digit", timeZone: "UTC" });
  };

  function temp(c, unit = true) {
    if (c === null || c === undefined || Number.isNaN(+c)) return "–";
    const v = state.s.Units === "f" ? c * 9 / 5 + 32 : +c;
    return `${Math.round(v).toLocaleString(locale()).replace("-", "−")}°${unit ? "" : ""}`;
  }
  const tempDiff = (a, b) => {
    const k = state.s.Units === "f" ? 9 / 5 : 1;
    return Math.round((a - b) * k);
  };

  function codeKey(code, isDay = 1) {
    code = +code || 0;
    if (code === 0) return isDay ? "clear" : "clearNight";
    if (code === 1) return "mostly";
    if (code === 2) return "partly";
    if (code === 3) return "overcast";
    if (code === 45 || code === 48) return "fog";
    if (code >= 51 && code <= 55) return "drizzle";
    if (code === 56 || code === 57 || code === 66 || code === 67) return "freezing";
    if (code === 61 || code === 63) return "rain";
    if (code === 65) return "heavyRain";
    if (code >= 71 && code <= 77) return "snow";
    if (code >= 80 && code <= 82) return "showers";
    if (code === 85 || code === 86) return "snowShowers";
    if (code === 95) return "thunder";
    if (code === 96 || code === 99) return "hail";
    return "overcast";
  }
  const codeText = (code, isDay) => (TEXT[state.lang] || TEXT.en).codes[codeKey(code, isDay)];

  // Eigene Wetter-Symbole (SVG, 64 x 64)
  const SUN = '<g class="sun"><circle cx="32" cy="32" r="11"/><g stroke-width="4" stroke-linecap="round">' +
    [0, 45, 90, 135, 180, 225, 270, 315].map((a) => {
      const r = a * Math.PI / 180;
      return `<line x1="${32 + Math.cos(r) * 17}" y1="${32 + Math.sin(r) * 17}" x2="${32 + Math.cos(r) * 23}" y2="${32 + Math.sin(r) * 23}"/>`;
    }).join("") + "</g></g>";
  const MOON = '<path class="moon" d="M40 14a19 19 0 1 0 12 30A16 16 0 0 1 40 14z"/>';
  const cloud = (x = 0, y = 0, s = 1, cls = "cloud") =>
    `<path class="${cls}" transform="translate(${x} ${y}) scale(${s})" d="M18 50h30a10 10 0 0 0 1-20 14 14 0 0 0-27-3 11 11 0 0 0-4 23z"/>`;
  const drops = (n, cls = "drop") => Array.from({ length: n }, (_, i) =>
    `<line class="${cls}" x1="${22 + i * 9}" y1="54" x2="${19 + i * 9}" y2="61"/>`).join("");
  const flakes = (n) => Array.from({ length: n }, (_, i) => `<circle class="flake" cx="${22 + i * 9}" cy="${57 + (i % 2) * 3}" r="2.4"/>`).join("");

  function icon(code, isDay = 1) {
    const key = codeKey(code, isDay);
    const sky = isDay ? SUN : MOON;
    let body;
    switch (key) {
      case "clear": body = SUN; break;
      case "clearNight": body = MOON; break;
      case "mostly": body = `<g transform="translate(-6 -6)">${sky}</g>${cloud(10, 10, 0.75)}`; break;
      case "partly": body = `<g transform="translate(-8 -8)">${sky}</g>${cloud(4, 4, 0.9)}`; break;
      case "overcast": body = cloud(-12, -8, 0.8, "cloud back") + cloud(2, 0, 0.95); break;
      case "fog": body = cloud(0, -6, 0.95) + '<g class="fog"><line x1="12" y1="54" x2="52" y2="54"/><line x1="18" y1="61" x2="46" y2="61"/></g>'; break;
      case "drizzle": body = cloud(0, -8, 1) + drops(3); break;
      case "rain": body = cloud(0, -8, 1) + drops(4); break;
      case "heavyRain": body = cloud(-10, -12, 0.8, "cloud back") + cloud(0, -8, 1) + drops(4, "drop heavy"); break;
      case "freezing": body = cloud(0, -8, 1) + drops(2) + flakes(2).replace(/cx="22/, 'cx="40'); break;
      case "snow": body = cloud(0, -8, 1) + flakes(4); break;
      case "showers": body = `<g transform="translate(-8 -10)">${sky}</g>${cloud(2, -4, 0.9)}${drops(3)}`; break;
      case "snowShowers": body = `<g transform="translate(-8 -10)">${sky}</g>${cloud(2, -4, 0.9)}${flakes(3)}`; break;
      case "thunder":
      case "hail": body = cloud(0, -8, 1) + '<path class="bolt" d="M34 44l-8 12h7l-4 10 11-14h-7l4-8z"/>' + (key === "hail" ? flakes(2) : ""); break;
      default: body = cloud();
    }
    return `<svg class="wicon" viewBox="0 0 64 64" aria-hidden="true">${body}</svg>`;
  }

  const PIN = '<svg class="pin" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z"/></svg>';

  // ------------------------------------------------------------ Daten

  function orderedYears() {
    const years = [...state.years];
    if (state.s.YearOrder === "newest") years.reverse();
    return years;
  }

  function agoText(n, wide) {
    if (wide) return n === 1 ? tx("around1") : tx("around", { n });
    return n === 1 ? tx("ago1") : tx("ago", { n });
  }

  function todayFor(photo) {
    const there = state.today.there || {};
    if (state.s.TodayAt === "there" || !state.today.home) {
      const w = there[String(photo.i)];
      if (w) return { w, label: tx("nowThere") };
    }
    if (state.today.home) {
      return { w: state.today.home, label: state.s.HomeName ? tx("nowHome", { place: state.s.HomeName.split(",")[0] }) : tx("now") };
    }
    return null;
  }

  function photoUrl(i) {
    return `${base()}api/photo?i=${i}&v=${state.ver}`;
  }

  function buildSlides() {
    slides = [];
    for (const year of orderedYears()) {
      year.photos.forEach((photo, k) => slides.push({ kind: "photo", year, photo, k }));
    }
    if (state.s.ShowSummary && state.years.length) slides.push({ kind: "summary" });
  }

  async function poll() {
    try {
      const response = await fetch(`${base()}api/scene?v=${state.ver}`, { cache: "no-store" });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      state.failures = 0;
      state.reachable = true;
      const langBefore = state.lang, layoutBefore = state.s.Layout;
      state.s = Object.assign(state.s, data.settings || {});
      state.lang = params.get("lang") || state.s.Language || "en";
      if (params.get("layout")) state.s.Layout = params.get("layout");
      state.today = data.today || { home: null };
      state.busy = !!data.busy;
      state.sources = data.sources ?? 1;
      const fresh = data.ver !== state.ver;
      if (data.years) {
        state.years = data.years;
        state.facts = data.facts || {};
        state.window = data.window || 0;
        state.next = data.next || "";
      }
      state.ver = data.ver;
      state.date = data.date;
      const first = !state.loaded;
      state.loaded = true;
      if (first || fresh || langBefore !== state.lang || layoutBefore !== state.s.Layout) {
        pendingRebuild = true;
        if (first || !slides.length || layoutBefore !== state.s.Layout || !state.years.length) start();
      }
    } catch (error) {
      state.failures++;
      if (state.failures >= 2 && pluginBases.length > 1) baseIndex = (baseIndex + 1) % pluginBases.length;
      if (state.failures >= 4) {
        state.reachable = false;
        if (!state.loaded) showMessage("offline");
      }
    }
  }

  // ------------------------------------------------------------ Ablauf

  function start() {
    clearTimeout(timer);
    pendingRebuild = false;
    buildSlides();
    pos = -1;
    wallPos = -1;
    if (!state.years.length) {
      showMessage(state.busy && !state.loaded ? "busy" : state.busy ? "busy" : "empty");
      ready();
      return;
    }
    next();
  }

  function next() {
    clearTimeout(timer);
    if (pendingRebuild) {
      pendingRebuild = false;
      buildSlides();
      pos = -1;
      wallPos = -1;
      if (!state.years.length) { start(); return; }
    }
    if (state.s.Layout === "wall") { nextWall(); return; }
    pos = (pos + 1) % slides.length;
    const slide = slides[pos];
    if (slide.kind === "summary") {
      showSummary();
      timer = setTimeout(next, state.s.SummarySeconds * 1000);
      return;
    }
    showPhoto(slide).then((ok) => {
      timer = setTimeout(next, ok ? state.s.PhotoSeconds * 1000 : 200);
    });
  }

  function showView(id) {
    for (const name of ["journey", "wall", "summary", "message"]) {
      const node = el(name);
      const on = name === id;
      if (on && node.hidden) {
        node.hidden = false;
        node.classList.remove("in");
        void node.offsetWidth;
        node.classList.add("in");
      } else if (!on) node.hidden = true;
    }
    document.documentElement.style.setProperty("--fade", `${state.s.FadeSeconds}s`);
    viewShown = id;
  }

  function loadImage(img, url) {
    return new Promise((resolve) => {
      if (img.dataset.src === url && img.complete && img.naturalWidth) { resolve(true); return; }
      const probe = new Image();
      probe.onload = () => { img.src = url; img.dataset.src = url; resolve(true); };
      probe.onerror = () => resolve(false);
      probe.src = url;
    });
  }

  function preload(i) {
    const slide = slides[i];
    if (slide && slide.kind === "photo") { const im = new Image(); im.src = photoUrl(slide.photo.i); }
  }

  async function showPhoto(slide) {
    const back = front === "A" ? "B" : "A";
    const node = el(`slide${back}`);
    const url = photoUrl(slide.photo.i);
    const pic = node.querySelector(".pic"), blur = node.querySelector(".blur");
    const ok = await loadImage(pic, url);
    if (!ok) { report(`Foto ${slide.photo.i} lädt nicht`); return false; }
    blur.src = url;
    const fromSummary = viewShown !== "journey";
    showView("journey");
    // Ken Burns: langsam heranfahren, Richtung je Foto anders
    const dur = state.s.PhotoSeconds + state.s.FadeSeconds * 2;
    node.style.setProperty("--kb-dur", `${dur}s`);
    const origins = ["30% 40%", "70% 35%", "50% 60%", "35% 65%", "65% 60%"];
    node.style.setProperty("--kb-origin", origins[(slide.photo.i * 7 + slide.k) % origins.length]);
    node.classList.toggle("kb", !!state.s.KenBurns);
    node.classList.remove("show", "moving");
    void node.offsetWidth;
    node.classList.add("show", "moving");
    el(`slide${front}`).classList.remove("show");
    front = back;
    renderCaption(slide, fromSummary);
    ready();
    preload(pos + 1);
    return true;
  }

  function renderCaption(slide) {
    const { year, photo } = slide;
    const wide = state.window > 0;
    el("kicker").textContent = wide ? tx("kickerWide", { n: state.window }) : tx("kicker");
    el("ago").textContent = agoText(year.ago, wide);
    const clock = clockOf(photo.t);
    el("when").textContent = `${longDate(photo.t)}${clock ? " · " + clock : ""}`;
    el("place").innerHTML = state.s.ShowPlace && photo.place ? `${PIN}<span>${esc(photo.place)}</span>` : "";
    el("count").textContent = year.photos.length > 1 ? `${slide.k + 1} / ${year.photos.length}` : "";
    const caption = el("caption");
    caption.classList.remove("swap");
    void caption.offsetWidth;
    caption.classList.add("swap");
    renderWeather(photo);
    drawTimeline(year);
  }

  function weatherBlock(label, w, extra = "") {
    if (!w) return "";
    const range = w.tmax !== null && w.tmax !== undefined ? `<span class="range">↑ ${temp(w.tmax)} &nbsp;↓ ${temp(w.tmin)}</span>` : "";
    const rain = w.rain !== null && w.rain !== undefined && w.rain >= 0.1 ? `<span>${tx("rain", { n: (Math.round(w.rain * 10) / 10).toLocaleString(locale()) })}</span>` : "";
    return `<div class="wx-col">
      <p class="wx-label">${esc(label)}</p>
      <div class="wx-main">${icon(w.code, w.isDay)}<span class="wx-t">${temp(w.t)}</span></div>
      <p class="wx-text">${esc(codeText(w.code, w.isDay))}</p>
      <p class="wx-more">${range}${rain}</p>${extra}</div>`;
  }

  function renderWeather(photo) {
    const box = el("wx");
    if (!state.s.ShowWeather || !photo.w) { box.innerHTML = ""; box.hidden = true; return; }
    box.hidden = false;
    const now = todayFor(photo);
    let diff = "";
    if (now && photo.w.t !== null && now.w.t !== null) {
      const d = tempDiff(photo.w.t, now.w.t);
      diff = `<p class="wx-diff ${d > 0 ? "warm" : d < 0 ? "cold" : ""}">${esc(d > 0 ? tx("warmer", { n: d }) : d < 0 ? tx("colder", { n: -d }) : tx("same"))}</p>`;
    }
    const where = photo.where === "near" ? tx("near") : photo.where === "home" ? tx("atHome") : "";
    box.innerHTML = `<div class="wx-row">${weatherBlock(tx("then"), photo.w)}${now ? '<div class="wx-sep"></div>' + weatherBlock(now.label, now.w) : ""}</div>${diff}${where ? `<p class="wx-where">${esc(where)}</p>` : ""}`;
  }

  // Zeitleiste: ein Punkt je Jahr, darüber die Temperatur damals, gestrichelt heute.
  function drawTimeline(current) {
    const box = el("timeline");
    const years = orderedYears();
    if (!years.length) { box.innerHTML = ""; return; }
    current = current || (slides[pos] && slides[pos].year) || years[0];
    const W = box.clientWidth || window.innerWidth * 0.9;
    const H = box.clientHeight || 120;
    const pad = Math.min(60, W / (years.length + 1) / 2 + 18);
    const x = (i) => years.length === 1 ? W / 2 : pad + (i * (W - 2 * pad)) / (years.length - 1);
    const temps = years.map((y) => { const w = (y.photos.find((p) => p.w) || {}).w; return w ? w.t : null; });
    const todayT = state.today.home ? state.today.home.t : null;
    const known = temps.filter((t) => t !== null).concat(todayT !== null ? [todayT] : []);
    const lineY = H * 0.70;
    let chart = "";
    if (state.s.ShowWeather && known.length) {
      const lo = Math.min(...known) - 2, hi = Math.max(...known) + 2;
      const top = H * 0.12, bottom = H * 0.50;
      const y = (t) => bottom - ((t - lo) / Math.max(1, hi - lo)) * (bottom - top);
      if (todayT !== null) {
        chart += `<line class="tl-today" x1="${pad * 0.4}" x2="${W - pad * 0.4}" y1="${y(todayT)}" y2="${y(todayT)}"/>`;
        chart += `<text class="tl-today-label" x="${W - pad * 0.4}" y="${y(todayT) + 18}" text-anchor="end">${esc(tx("chartToday"))} ${temp(todayT)}</text>`;
      }
      const pts = temps.map((t, i) => t === null ? null : [x(i), y(t)]).filter(Boolean);
      if (pts.length > 1) chart += `<polyline class="tl-curve" points="${pts.map((p) => p.join(",")).join(" ")}"/>`;
      temps.forEach((t, i) => {
        if (t === null) return;
        const on = years[i] === current;
        chart += `<circle class="tl-tdot${on ? " on" : ""}" cx="${x(i)}" cy="${y(t)}" r="${on ? 5 : 3.2}"/>`;
        if (on || years.length <= 12) chart += `<text class="tl-tlabel${on ? " on" : ""}" x="${x(i)}" y="${y(t) - 9}" text-anchor="middle">${temp(t)}</text>`;
      });
    }
    const every = years.length > 24 ? 4 : years.length > 14 ? 2 : 1;
    let dots = `<line class="tl-axis" x1="${pad * 0.4}" x2="${W - pad * 0.4}" y1="${lineY}" y2="${lineY}"/>`;
    years.forEach((year, i) => {
      const on = year === current;
      dots += `<circle class="tl-dot${on ? " on" : ""}" cx="${x(i)}" cy="${lineY}" r="${on ? 9 : 5}"/>`;
      if (on || i % every === 0 || i === years.length - 1) {
        dots += `<text class="tl-year${on ? " on" : ""}" x="${x(i)}" y="${lineY + 30}" text-anchor="middle">${year.y}</text>`;
      }
    });
    box.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${chart}${dots}</svg>`;
  }

  // ------------------------------------------------------------ Übersicht

  function showSummary() {
    showView("summary");
    const years = orderedYears();
    const f = state.facts || {};
    el("sumKicker").textContent = state.window > 0 ? tx("kickerWide", { n: state.window }) : tx("kicker");
    el("sumTitle").textContent = years.length === 1 ? tx("sumTitle1", { date: dayMonth(state.date) })
      : tx("sumTitle", { date: dayMonth(state.date), n: years.length });
    el("sumStrip").innerHTML = years.map((year, k) => {
      const photo = year.photos[0];
      const w = photo.w;
      return `<figure style="--i:${k}"><img src="${photoUrl(photo.i)}" alt=""><figcaption><b>${year.y}</b>${
        state.s.ShowWeather && w ? `<span>${icon(w.code, w.isDay)}${temp(w.t)}</span>` : ""}</figcaption></figure>`;
    }).join("");
    drawChart(years);
    const facts = [];
    const at = (p) => (p.place ? tx("at", { p: p.place.split(",")[0] }) : "");
    const todayT = state.today.home ? state.today.home.t : null;
    if (state.s.ShowWeather) {
      if (f.warmest && (f.perYear || []).length > 1) facts.push(["warm", tx("fWarm", { y: f.warmest.y, at: at(f.warmest), t: temp(f.warmest.tmax) })]);
      if (f.coldest && (f.perYear || []).length > 1 && f.coldest.y !== f.warmest?.y) facts.push(["cold", tx("fCold", { y: f.coldest.y, at: at(f.coldest), t: temp(f.coldest.tmin) })]);
      if (f.wettest) facts.push(["wet", tx("fWet", { y: f.wettest.y, mm: Math.round(f.wettest.rain).toLocaleString(locale()) })]);
      else if (f.dry > 1) facts.push(["dry", tx("fDry", { n: f.dry, all: (f.perYear || []).length })]);
      if (f.avgMax !== undefined && state.today.home && state.today.home.tmax !== null) {
        const d = tempDiff(f.avgMax, state.today.home.tmax);
        facts.push(["avg", d === 0 ? tx("fAvgSame", { t: temp(f.avgMax) }) : tx("fAvg", { t: temp(f.avgMax), now: temp(state.today.home.tmax) })]);
      }
    }
    if (f.place) facts.push(["place", tx("fPlace", { place: f.place.name.split(",")[0], n: f.place.years })]);
    if (f.photos && f.first) facts.push(["photos", tx("fPhotos", { n: f.photos.toLocaleString(locale()), y: f.first })]);
    void todayT;
    el("sumFacts").innerHTML = facts.slice(0, 4).map(([kind, text], k) => `<li class="${kind}" style="--i:${k}">${esc(text)}</li>`).join("");
    ready();
  }

  function drawChart(years) {
    const box = el("sumChart");
    const rows = years.map((y) => { const w = (y.photos.find((p) => p.w) || {}).w; return { y: y.y, w }; });
    if (!state.s.ShowWeather || !rows.some((r) => r.w && r.w.tmax !== null && r.w.tmax !== undefined)) { box.innerHTML = ""; box.hidden = true; return; }
    box.hidden = false;
    const W = box.clientWidth || window.innerWidth * 0.8, H = box.clientHeight || 160;
    const vals = [];
    for (const r of rows) if (r.w) vals.push(r.w.tmax ?? r.w.t, r.w.tmin ?? r.w.t);
    const home = state.today.home;
    if (home) vals.push(home.tmax ?? home.t, home.tmin ?? home.t);
    const lo = Math.min(...vals) - 1, hi = Math.max(...vals) + 1;
    const top = 26, bottom = H - 50;
    const y = (t) => bottom - ((t - lo) / Math.max(1, hi - lo)) * (bottom - top);
    const n = rows.length + (home ? 1 : 0);
    const slot = W / n;
    const bw = Math.min(42, slot * 0.42);
    let svg = "";
    const zero = lo < 0 && hi > 0 ? `<line class="ch-zero" x1="0" x2="${W}" y1="${y(0)}" y2="${y(0)}"/>` : "";
    rows.forEach((r, i) => {
      const cx = slot * (i + 0.5);
      if (r.w) {
        const a = r.w.tmax ?? r.w.t, b = r.w.tmin ?? r.w.t;
        svg += `<rect class="ch-bar" style="--i:${i}" x="${cx - bw / 2}" y="${y(a)}" width="${bw}" height="${Math.max(3, y(b) - y(a))}" rx="${bw / 2.4}" fill="url(#heat)"/>`;
        svg += `<text class="ch-t" x="${cx}" y="${y(a) - 7}" text-anchor="middle">${temp(a)}</text>`;
        svg += `<text class="ch-t low" x="${cx}" y="${y(b) + 17}" text-anchor="middle">${temp(b)}</text>`;
      }
      svg += `<text class="ch-y" x="${cx}" y="${H - 2}" text-anchor="middle">${r.y}</text>`;
    });
    if (home) {
      const cx = slot * (rows.length + 0.5);
      const a = home.tmax ?? home.t, b = home.tmin ?? home.t;
      svg += `<rect class="ch-bar now" x="${cx - bw / 2}" y="${y(a)}" width="${bw}" height="${Math.max(3, y(b) - y(a))}" rx="${bw / 2.4}"/>`;
      svg += `<text class="ch-t" x="${cx}" y="${y(a) - 7}" text-anchor="middle">${temp(a)}</text>`;
      svg += `<text class="ch-t low" x="${cx}" y="${y(b) + 17}" text-anchor="middle">${temp(b)}</text>`;
      svg += `<text class="ch-y now" x="${cx}" y="${H - 2}" text-anchor="middle">${esc(tx("chartToday"))}</text>`;
    }
    const grad = `<defs><linearGradient id="heat" x1="0" y1="${y(hi)}" x2="0" y2="${y(lo)}" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#ff7a45"/><stop offset=".45" stop-color="#ffc24b"/><stop offset=".7" stop-color="#8fd3ff"/><stop offset="1" stop-color="#5b8cff"/></linearGradient></defs>`;
    box.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">${grad}${zero}${svg}</svg>`;
  }

  // ------------------------------------------------------------ Wand

  let wallPhoto = {};   // Jahr -> Index des gezeigten Fotos

  function renderWall() {
    const years = orderedYears();
    const wide = state.window > 0;
    el("wallKicker").textContent = dayMonth(state.date) + (wide ? ` · ± ${state.window}` : "");
    el("wallTitle").textContent = wide ? tx("wallTitleWide") : tx("wallTitle");
    const home = state.today.home;
    el("wallToday").innerHTML = state.s.ShowWeather && home ? `<span class="wt-label">${esc(state.s.HomeName ? tx("nowHome", { place: state.s.HomeName.split(",")[0] }) : tx("now"))}</span>${icon(home.code, home.isDay)}<b>${temp(home.t)}</b>` : "";
    const portrait = document.documentElement.classList.contains("portrait");
    const n = years.length;
    const cols = portrait ? (n <= 1 ? 1 : n <= 4 ? 2 : 3) : (n <= 3 ? n : n <= 4 ? 4 : n <= 8 ? Math.ceil(n / 2) : Math.ceil(n / Math.ceil(n / 6)));
    const box = el("cards");
    box.style.setProperty("--cols", Math.max(1, cols));
    box.style.setProperty("--rows", Math.ceil(n / Math.max(1, cols)));
    box.innerHTML = years.map((year, i) => {
      const k = wallPhoto[year.y] || 0;
      const photo = year.photos[k] || year.photos[0];
      const w = photo.w;
      return `<figure class="card" data-i="${i}" style="--i:${i}">
        <div class="frame"><img class="a show" src="${photoUrl(photo.i)}" alt=""><img class="b" alt=""></div>
        <figcaption>
          <div class="c-year"><b>${year.y}</b><span>${esc(year.ago === 1 ? tx("agoShort1") : tx("agoShort", { n: year.ago }))}</span></div>
          ${state.s.ShowWeather && w ? `<div class="c-wx">${icon(w.code, w.isDay)}<span>${temp(w.t)}</span></div>` : ""}
          ${state.s.ShowPlace && photo.place ? `<p class="c-place">${esc(photo.place)}</p>` : ""}
        </figcaption></figure>`;
    }).join("");
    highlight();
  }

  function highlight() {
    for (const card of el("cards").querySelectorAll(".card")) card.classList.toggle("on", +card.dataset.i === wallPos);
  }

  function nextWall() {
    const years = orderedYears();
    if (viewShown !== "wall") { showView("wall"); wallPos = -1; renderWall(); ready(); }
    wallPos++;
    if (wallPos >= years.length) {
      if (state.s.ShowSummary && years.length) {
        wallPos = -1;
        showSummary();
        timer = setTimeout(() => { viewShown = ""; next(); }, state.s.SummarySeconds * 1000);
        return;
      }
      wallPos = 0;
    }
    const year = years[wallPos];
    // das hervorgehobene Jahr bekommt sein nächstes Foto
    if (year.photos.length > 1) {
      const k = ((wallPhoto[year.y] ?? 0) + 1) % year.photos.length;
      wallPhoto[year.y] = k;
      const card = el("cards").querySelector(`.card[data-i="${wallPos}"]`);
      if (card) swapCardPhoto(card, year, k);
    }
    highlight();
    timer = setTimeout(next, state.s.PhotoSeconds * 1000);
  }

  function swapCardPhoto(card, year, k) {
    const photo = year.photos[k];
    const frame = card.querySelector(".frame");
    const shown = frame.querySelector("img.show"), hidden = frame.querySelector("img:not(.show)");
    const url = photoUrl(photo.i);
    const probe = new Image();
    probe.onload = () => {
      hidden.src = url;
      hidden.classList.add("show");
      shown.classList.remove("show");
      const wx = card.querySelector(".c-wx");
      if (wx && photo.w) wx.innerHTML = `${icon(photo.w.code, photo.w.isDay)}<span>${temp(photo.w.t)}</span>`;
      const place = card.querySelector(".c-place");
      if (place) place.textContent = photo.place || "";
    };
    probe.src = url;
  }

  // ------------------------------------------------------------ Hinweise

  function showMessage(kind) {
    showView("message");
    const iso = state.date || new Date().toISOString().slice(0, 10);
    const d = dateOf(iso);
    el("leafMonth").textContent = d.toLocaleDateString(locale(), { month: "long", timeZone: "UTC" });
    el("leafDay").textContent = String(d.getUTCDate());
    let title = tx("emptyTitle"), text = "";
    if (kind === "offline") { title = tx("offline"); text = ""; }
    else if (kind === "busy") { title = tx("busy"); }
    else if (!state.sources) { text = tx("noSource"); }
    else {
      text = tx("emptyText", { date: dayMonth(iso) });
      if (state.next) text += " " + tx("emptyNext", { date: dayMonth(state.next) });
    }
    el("msgTitle").textContent = title;
    el("msgText").textContent = text;
    const home = state.today.home;
    el("msgToday").innerHTML = state.s.ShowWeather && home && kind !== "offline"
      ? weatherBlock(state.s.HomeName ? tx("nowHome", { place: state.s.HomeName.split(",")[0] }) : tx("now"), home) : "";
    ready();
  }

  // ------------------------------------------------------------ Start

  if (params.get("view") === "summary") {
    // Für Store-Bilder: gleich die Übersicht
    const once = setInterval(() => { if (state.loaded && state.years.length) { clearInterval(once); clearTimeout(timer); showSummary(); clearTimeout(timer); slides = []; } }, 300);
  }
  poll();
  setInterval(poll, 30000);
  setTimeout(() => { if (!readySent) { ready(); if (!state.loaded) showMessage("busy"); } }, 8000);
  setInterval(() => {   // Tageswechsel: das Plugin rechnet neu, die Szene fragt öfter
    if (!state.loaded) poll();
  }, 5000);
})();
