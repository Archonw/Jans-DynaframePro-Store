# Secret Santa

Secret Santa with your frame, as a DynaFrame scene with its plugin.

- **Everyone joins on their phone.** Scan the QR code on the TV (no app needed), enter your name, pick a four-digit PIN, write a wish list and, if you like, what you would rather not get. With name and PIN you can look again on any phone. People without a phone can be added on the plugin page.
- **The frame draws in secret.** By hand or at a set time: one big chain (A gives to B, B to C … back to A), never within the same household, and not the same person as last round.
- **Only your own phone knows.** After the draw each phone shows its own lot behind an envelope you tap open: whom you give to, their wish list, the budget and a countdown to gift-giving. You can ask your giftee anonymously ("What is your shoe size?") and tick "I have the present". Neither the TV nor the plugin page ever shows who drew whom.
- **On the TV:** who has joined, then the countdown with how many have looked at their lot and have their present, "Merry gift-giving!" when it is time.
- **The reveal:** pair by pair, "Who was Secret Santa for Ben?", a drum roll, then the name, until the whole chain is on screen. With bells, drum roll, fanfare and applause from the frame. It starts from the plugin page or by itself at gift-giving time (needs "Allow takeover", or the playlist running). Afterwards every phone also shows who their own Secret Santa was.

If you use Web Login, open port 8155 there. English, German or Spanish; the phone page follows the phone's language.
