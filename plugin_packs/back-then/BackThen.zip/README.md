# Back Then

An old photo of yours, and next to it what was going on in the world that year: the big events, the number-one hit of that week, who led the country, what bread, milk or petrol cost, and who was born that year. Your own life becomes part of history.

## Photos

One or more sources, merged:

- **All photos in DynaFrame**: the DynaFrame media database (also WebDAV) plus its media folders and extra folders you enter. The date comes from the database or, if missing, from the photo file (read once, then cached).
- **A DynaFrame playlist**.
- **All photos in Immich** or **an Immich album** (optional). You need the server address and an API key (`asset.read`, `asset.view`, `album.read`). If Immich Slideshow or Growing Up already has a server, it is taken over.
- **Which photos from DynaFrame**: stars, favourites, camera, tags and so on, straight from the DynaFrame media database. **Immich filters** work the same way for Immich.

Each visit is one year. The plugin prefers years it has not shown for a while, takes photos that are at least a number of years old (default 10), and picks a few photos (default 4) from different days of that year, favourites and photos with stars first, no bursts. Optionally only photos from around the same time of year as today.

## What the frame shows

- **The year**, the date of the photo and, if you enter your people with their birthday, how old everyone was ("Anna was 7").
- **In the news**: the most important events of that year (from Wikidata, ranked by how many Wikipedia languages write about them).
- **Number one**: the hit that was number one in the week of the photo (Germany, Austria, Switzerland, USA, UK).
- **Head of government**: chancellor, president or prime minister on the day of the photo, with portrait (Germany, Austria, USA, UK, Spain).
- **Prices back then and today**: bread, milk, butter, eggs, petrol, stamps (Germany from the Federal Statistical Office, USA from the Bureau of Labor Statistics). Today's values marked "≈" are estimates from the consumer price index. Where no price table exists, the plugin shows how much more expensive everything has become since then.
- **Born that year**: famous people born in that year.

Two looks: **Almanac** (photo next to a page of an old almanac) and **Newspaper** (the front page of a newspaper from back then, with the photo as the cover picture). The country follows the language (German → Germany, English → USA, Spanish → Spain) or can be set on the plugin page.

## Data

Everything for 1945 to 2025 is bundled with the plugin, so the frame works without the internet. For other years and missing languages the plugin asks Wikidata live and caches the answer. Portraits come from Wikimedia Commons and are cached too. If you use an ad blocker like Pi-hole, allow `query.wikidata.org`, `commons.wikimedia.org` and `upload.wikimedia.org`.

Sources: Wikidata (CC0), Wikipedia (CC BY-SA 4.0), Wikimedia Commons, Destatis, Eurostat, U.S. Bureau of Labor Statistics, World Bank. Details in `plugin/LICENSES.md`.

## Problems?

Report them here: https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=%5BBack%20Then%5D%20
