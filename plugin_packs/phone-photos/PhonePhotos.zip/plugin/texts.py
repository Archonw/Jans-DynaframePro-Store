"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Auf dem Rahmen.": ("On the frame.", "En el marco."),
    "Das Foto ist zu groß (höchstens {mb} MB).": (
        "The photo is too large (at most {mb} MB).",
        "La foto es demasiado grande (como máximo {mb} MB)."),
    "Das ist kein Foto, das der Rahmen lesen kann.": (
        "That is not a photo the frame can read.",
        "Eso no es una foto que el marco pueda leer."),
    "Der Bildschirm ist aus; das Foto wird nicht gezeigt.": (
        "The screen is off; the photo is not shown.",
        "La pantalla está apagada; la foto no se muestra."),
    "Der Rahmen hat das Foto nicht rechtzeitig angezeigt.": (
        "The frame did not show the photo in time.",
        "El marco no ha mostrado la foto a tiempo."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.",
        "El marco no ha creado la lista {name}."),
    "Der Rahmen ist nach den Fotos nicht zu deiner Playlist zurückgekehrt. Starte sie auf der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix passiert das nicht.": (
        "The frame did not return to your playlist after the photos. Start it again on the frame's home page. This does not happen with a saved playlist instead of a Quick Mix.",
        "El marco no ha vuelto a tu lista después de las fotos. Vuelve a iniciarla en la página de inicio del marco. Con una lista guardada en lugar de un Quick Mix no pasa."),
    "Die Szene Phone Photos ist auf der Plugins-Seite ausgeschaltet.": (
        "The Phone Photos scene is switched off on the Plugins page.",
        "La escena Phone Photos está desactivada en la página de plugins."),
    "Die Szene Phone Photos ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The Phone Photos scene is not installed on this frame. Install the package again.",
        "La escena Phone Photos no está instalada en este marco. Vuelve a instalar el paquete."),
    "Die Szene Phone Photos wurde nicht gefunden.": (
        "The Phone Photos scene was not found.",
        "No se ha encontrado la escena Phone Photos."),
    "Die Takeover-Playlist ist noch nicht angelegt.": (
        "The takeover playlist has not been created yet.",
        "La lista de takeover aún no se ha creado."),
    "Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.": (
        "This frame is too old to hand the screen to a plugin.",
        "Este marco es demasiado antiguo para ceder la pantalla a un plugin."),
    "Es kam kein Foto an.": ("No photo arrived.", "No ha llegado ninguna foto."),
    "Etwas anderes hat gerade den Bildschirm.": (
        "Something else has the screen right now.",
        "Ahora mismo otra cosa ocupa la pantalla."),
    "Falscher Code.": ("Wrong code.", "Código incorrecto."),
    "HEIC-Fotos vom iPhone kann der Rahmen nicht lesen. Füge im Kurzbefehl „Bild konvertieren“ in JPEG ein oder schick das Foto über die Handy-Seite.": (
        "The frame cannot read HEIC photos from the iPhone. Add “Convert Image” to JPEG in the shortcut, or send the photo from the phone page.",
        "El marco no puede leer fotos HEIC del iPhone. Añade «Convertir imagen» a JPEG en el atajo o envía la foto desde la página del móvil."),
    "Handy": ("Phone", "Móvil"),
    "Kein freier Port für die Handy-Seite (8095 bis 8098).": (
        "No free port for the phone page (8095 to 8098).",
        "No hay puerto libre para la página del móvil (8095 a 8098)."),
    "Konnte das Foto nicht anzeigen: {exc}": ("Could not show the photo: {exc}", "No se pudo mostrar la foto: {exc}"),
    "Konnte das Foto nicht lesen: {exc}": ("Could not read the photo: {exc}", "No se pudo leer la foto: {exc}"),
    "Konnte die Takeover-Playlist nicht anlegen: {exc}": (
        "Could not create the takeover playlist: {exc}",
        "No se pudo crear la lista de takeover: {exc}"),
    "Phone Photos ist auf der Plugins-Seite ausgeschaltet.": (
        "Phone Photos is switched off on the Plugins page.",
        "Phone Photos está desactivado en la página de plugins."),
    "„Allow takeover“ ist für Phone Photos auf der Plugins-Seite aus. Schalte es ein, sonst kann kein Foto gezeigt werden.": (
        "“Allow takeover” is off for Phone Photos on the Plugins page. Switch it on, otherwise no photo can be shown.",
        "«Allow takeover» está desactivado para Phone Photos en la página de plugins. Actívalo; si no, no se puede mostrar ninguna foto."),
    "{count} Fotos auf dem Rahmen.": ("{count} photos on the frame.", "{count} fotos en el marco."),
}


def t(lang, template, **values):
    text = template
    if lang in LANGUAGES and lang != "de":
        row = _TEXTS.get(template)
        if row:
            text = row[LANGUAGES.index(lang) - 1]
    try:
        return text.format(**values) if values else text
    except (KeyError, IndexError, ValueError):
        return text
