"""Musikquellen und Lautsprecher außerhalb des Rahmens.

- Radio: Sendersuche bei radio-browser.info (frei, ohne Konto).
- Jellyfin: Playlists, Alben, Interpreten, Genres; Stücke als Stream-Adresse.
- Ordner: Musikdateien auf dem Rahmen oder einer eingehängten Freigabe.
- Spotify: go-librespot (GPL-3.0, wird bei Bedarf von GitHub geladen) macht
  den Rahmen zum Spotify-Connect-Lautsprecher und kann auch andere
  Connect-Geräte des Kontos steuern. Kopplung per Code auf spotify.com/pair,
  kein Entwicklerschlüssel nötig. Braucht Spotify Premium.
- Music Assistant: JSON-API (POST /api) mit langlebigem Token.
"""

import json
import os
import platform
import re
import shutil
import signal
import subprocess
import tarfile
import threading
import time
from pathlib import Path
from urllib.parse import quote, urlencode, urlparse

import requests

USER_AGENT = "DynaFrame-PlaylistMusic/0.1.1 (+https://github.com/Archonw/Jans-DynaframePro-Store)"
TIMEOUT = (6, 20)
AUDIO_EXT = {".mp3", ".flac", ".ogg", ".oga", ".opus", ".m4a", ".aac", ".wav", ".wma", ".alac", ".aiff", ".aif"}


class SourceError(Exception):
    pass


def normalize_url(raw):
    value = str(raw or "").strip().rstrip("/")
    if value and not re.match(r"^https?://", value, re.I):
        value = "http://" + value
    return value[:300]


# --------------------------------------------------------------------------
# Radio
# --------------------------------------------------------------------------

RADIO_HOSTS = ("de1.api.radio-browser.info", "de2.api.radio-browser.info", "fi1.api.radio-browser.info",
               "nl1.api.radio-browser.info", "all.api.radio-browser.info")
_radio_host = {"value": None}


def _radio_get(path, params):
    hosts = ([_radio_host["value"]] if _radio_host["value"] else []) + [h for h in RADIO_HOSTS if h != _radio_host["value"]]
    last = None
    for host in hosts:
        try:
            answer = requests.get(f"https://{host}{path}", params=params, timeout=TIMEOUT,
                                  headers={"User-Agent": USER_AGENT})
            if answer.status_code == 200:
                _radio_host["value"] = host
                return answer.json()
            last = f"HTTP {answer.status_code}"
        except (requests.RequestException, ValueError) as exc:
            last = type(exc).__name__
    raise SourceError(f"radio-browser.info ist nicht erreichbar ({last}).")


def radio_search(query, country=""):
    params = {"limit": 30, "hidebroken": "true", "order": "votes", "reverse": "true"}
    if query:
        params["name"] = query
    if country:
        params["countrycode"] = country
    rows = _radio_get("/json/stations/search", params) or []
    found = []
    for row in rows:
        url = row.get("url_resolved") or row.get("url")
        if not url:
            continue
        sub = " · ".join(x for x in (row.get("country"), (row.get("codec") or "") + (f" {row.get('bitrate')} kbit/s" if row.get("bitrate") else ""), (row.get("tags") or "")[:60]) if x)
        found.append({"ref": url, "label": (row.get("name") or "?").strip()[:120], "sub": sub,
                      "kind": "radio", "id": row.get("stationuuid") or ""})
    return found


def radio_click(station_id):
    """radio-browser zählt Aufrufe; das hilft guten Sendern nach oben."""
    if station_id:
        try:
            _radio_get(f"/json/url/{quote(station_id)}", {})
        except SourceError:
            pass


# --------------------------------------------------------------------------
# Jellyfin
# --------------------------------------------------------------------------

class Jellyfin:
    def __init__(self, url, key, user):
        self.url = normalize_url(url)
        self.key = str(key or "").strip()
        self.user = str(user or "").strip()
        self._uid = None

    def ok(self):
        return bool(self.url and self.key)

    def _get(self, path, params=None):
        if not self.ok():
            raise SourceError("Jellyfin: Adresse oder Schlüssel fehlt")
        try:
            answer = requests.get(self.url + path, params=params or {}, timeout=TIMEOUT,
                                  headers={"X-Emby-Token": self.key, "User-Agent": USER_AGENT})
        except requests.RequestException as exc:
            raise SourceError(f"Jellyfin: {exc}") from exc
        if answer.status_code in (401, 403):
            raise SourceError("Jellyfin lehnt den Schlüssel ab")
        if answer.status_code >= 400:
            raise SourceError(f"Jellyfin: HTTP {answer.status_code}")
        return answer.json()

    def user_id(self):
        if self._uid:
            return self._uid
        users = self._get("/Users") or []
        pick = None
        for row in users:
            if self.user and str(row.get("Name", "")).lower() == self.user.lower():
                pick = row
        if pick is None:
            admins = [u for u in users if (u.get("Policy") or {}).get("IsAdministrator")]
            pick = (admins or users or [None])[0]
        if not pick:
            raise SourceError("Jellyfin: kein Benutzer gefunden")
        self._uid = pick["Id"]
        return self._uid

    def test(self):
        info = self._get("/System/Info")
        uid = self.user_id()
        name = next((u.get("Name") for u in self._get("/Users") if u.get("Id") == uid), "?")
        return f"{info.get('ServerName') or 'Jellyfin'} {info.get('Version') or ''}".strip(), name

    def search(self, query):
        uid = self.user_id()
        params = {"Recursive": "true", "Limit": 40, "Fields": "ChildCount,AlbumArtist",
                  "IncludeItemTypes": "Playlist,MusicAlbum,MusicArtist,MusicGenre" if query else "Playlist",
                  "SortBy": "SortName"}
        if query:
            params["searchTerm"] = query
        rows = (self._get(f"/Users/{uid}/Items", params) or {}).get("Items") or []
        if query:
            # Interpreten und Genres kennt /Items nicht immer; eigene Abfragen dazu
            for path, kind in (("/Artists", "MusicArtist"), ("/MusicGenres", "MusicGenre")):
                try:
                    more = (self._get(path, {"searchTerm": query, "UserId": uid, "Limit": 10}) or {}).get("Items") or []
                except SourceError:
                    more = []
                known = {r.get("Id") for r in rows}
                rows += [dict(r, Type=kind) for r in more if r.get("Id") not in known]
        found = []
        for row in rows:
            kind = row.get("Type") or ""
            if kind not in ("Playlist", "MusicAlbum", "MusicArtist", "MusicGenre", "Audio"):
                continue
            sub = row.get("AlbumArtist") or ""
            if row.get("ChildCount"):
                sub = (sub + " · " if sub else "") + f"{row['ChildCount']}"
            found.append({"ref": row["Id"], "label": row.get("Name") or "?", "sub": sub, "kind": kind})
        found.append({"ref": "__all__", "label": "*", "sub": "", "kind": "AllMusic"})
        return found

    def tracks(self, ref, kind, limit=300):
        uid = self.user_id()
        base = {"UserId": uid, "Recursive": "true", "IncludeItemTypes": "Audio", "Limit": limit,
                "Fields": "AlbumArtist", "SortBy": "Random"}
        if kind == "Playlist":
            data = self._get(f"/Playlists/{ref}/Items", {"UserId": uid, "Limit": limit})
        elif kind == "MusicAlbum":
            data = self._get(f"/Users/{uid}/Items", dict(base, ParentId=ref, SortBy="ParentIndexNumber,IndexNumber,SortName"))
        elif kind == "MusicArtist":
            data = self._get(f"/Users/{uid}/Items", dict(base, ArtistIds=ref))
        elif kind == "MusicGenre":
            data = self._get(f"/Users/{uid}/Items", dict(base, GenreIds=ref))
        elif kind == "AllMusic":
            data = self._get(f"/Users/{uid}/Items", base)
        else:
            data = {"Items": [{"Id": ref, "Type": "Audio"}]}
        rows = (data or {}).get("Items") or []
        out = []
        for row in rows:
            if row.get("Type") not in (None, "Audio"):
                continue
            artist = row.get("AlbumArtist") or ", ".join(row.get("Artists") or [])
            title = " – ".join(x for x in (artist, row.get("Name")) if x)
            url = f"{self.url}/Audio/{row['Id']}/stream?" + urlencode({"static": "true", "api_key": self.key})
            out.append((url, title))
        return out


def jellyfin_from_other_plugin(plugins_dir):
    """Adresse/Schlüssel/Benutzer aus dem Plugin Jellyfin Now Playing, falls da."""
    path = Path(plugins_dir) / "JellyfinNowPlaying" / "data" / "settings.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {"url": data.get("ServerUrl") or "", "key": data.get("ApiKey") or "", "user": data.get("UserName") or ""}


# --------------------------------------------------------------------------
# Ordner
# --------------------------------------------------------------------------

FOLDER_ROOTS = ("~/Music", "~/Musik", "/media", "/mnt", "~/.local/share/dfr/media", "/home/pi")


def folder_tracks(path, limit=5000):
    root = Path(os.path.expanduser(str(path or ""))).resolve()
    if not str(path or "").strip() or not root.is_dir():
        raise SourceError(f"Ordner nicht gefunden: {path}")
    found = []
    for folder, dirs, files in os.walk(root, followlinks=True):
        dirs[:] = sorted(d for d in dirs if not d.startswith("."))
        for name in sorted(files):
            if Path(name).suffix.lower() in AUDIO_EXT and not name.startswith("."):
                found.append((os.path.join(folder, name), Path(name).stem))
                if len(found) >= limit:
                    return found
    return found


def folder_browse(path):
    """Unterordner und Zahl der Musikdateien, für die Auswahl auf der Seite."""
    if not str(path or "").strip():
        rows = []
        for root in FOLDER_ROOTS:
            full = Path(os.path.expanduser(root))
            if full.is_dir():
                rows.append({"ref": str(full), "label": str(full), "sub": "", "kind": "folder"})
        return rows
    base = Path(os.path.expanduser(str(path))).resolve()
    if not base.is_dir():
        raise SourceError(f"Ordner nicht gefunden: {path}")
    rows = []
    if base.parent != base:
        rows.append({"ref": str(base.parent), "label": "..", "sub": "", "kind": "folder"})
    try:
        children = sorted((c for c in base.iterdir() if c.is_dir() and not c.name.startswith(".")), key=lambda c: c.name.lower())
    except OSError as exc:
        raise SourceError(str(exc)) from exc
    for child in children[:200]:
        rows.append({"ref": str(child), "label": child.name, "sub": "", "kind": "folder"})
    return rows


def folder_count(path):
    try:
        return len(folder_tracks(path, limit=5000))
    except SourceError:
        return -1


# --------------------------------------------------------------------------
# Music Assistant
# --------------------------------------------------------------------------

class MusicAssistant:
    def __init__(self, url, token):
        self.url = normalize_url(url)
        self.token = str(token or "").strip()

    def ok(self):
        return bool(self.url)

    def call(self, command, **args):
        if not self.url:
            raise SourceError("Music Assistant: Adresse fehlt")
        headers = {"Content-Type": "application/json", "User-Agent": USER_AGENT}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        body = {"message_id": str(int(time.time() * 1000)), "command": command, "args": args}
        try:
            answer = requests.post(self.url + "/api", data=json.dumps(body), headers=headers, timeout=TIMEOUT)
        except requests.RequestException as exc:
            raise SourceError(f"Music Assistant: {exc}") from exc
        if answer.status_code == 401:
            raise SourceError("Music Assistant lehnt das Token ab")
        if answer.status_code >= 400:
            raise SourceError(f"Music Assistant: HTTP {answer.status_code} {answer.text[:120]}")
        try:
            return answer.json() if answer.content else None
        except ValueError:
            return None

    def players(self):
        rows = self.call("players/all") or []
        out = []
        for row in rows:
            if not isinstance(row, dict) or not row.get("available", True) or not row.get("enabled", True):
                continue
            pid = row.get("player_id")
            name = row.get("display_name") or row.get("name") or pid
            if pid:
                out.append({"id": pid, "label": name, "state": row.get("playback_state") or row.get("state") or ""})
        return sorted(out, key=lambda r: str(r["label"]).lower())

    def player_state(self, player_id):
        row = self.call("players/get", player_id=player_id) or {}
        return str(row.get("playback_state") or row.get("state") or "")

    def search(self, query):
        if not query:
            data = self.call("music/playlists/library_items", limit=50) or []
            rows = data if isinstance(data, list) else (data.get("items") or [])
            return [{"ref": r.get("uri"), "label": r.get("name") or "?", "sub": _ma_sub(r), "kind": "playlist"}
                    for r in rows if isinstance(r, dict) and r.get("uri")]
        data = self.call("music/search", search_query=query,
                         media_types=["playlist", "album", "artist", "radio", "track"], limit=8) or {}
        found = []
        for key, kind in (("playlists", "playlist"), ("albums", "album"), ("artists", "artist"),
                          ("radio", "radio"), ("tracks", "track")):
            for row in data.get(key) or []:
                if isinstance(row, dict) and row.get("uri"):
                    found.append({"ref": row["uri"], "label": row.get("name") or "?", "sub": _ma_sub(row), "kind": kind})
        return found

    def play(self, player_id, media, shuffle=False):
        args = {"queue_id": player_id, "media": media, "option": "replace"}
        if shuffle:
            args["shuffle"] = True
        self.call("player_queues/play_media", **args)

    def volume(self, player_id, level):
        self.call("players/cmd/volume_set", player_id=player_id, volume_level=int(max(0, min(100, level))))

    def get_volume(self, player_id):
        row = self.call("players/get", player_id=player_id) or {}
        level = row.get("volume_level")
        return int(level) if isinstance(level, (int, float)) else None

    def pause(self, player_id):
        self.call("players/cmd/pause", player_id=player_id)

    def resume(self, player_id):
        self.call("players/cmd/play", player_id=player_id)

    def stop(self, player_id):
        self.call("players/cmd/stop", player_id=player_id)

    def test(self):
        info = None
        try:
            answer = requests.get(self.url + "/info", timeout=TIMEOUT, headers={"User-Agent": USER_AGENT})
            info = answer.json() if answer.status_code == 200 else None
        except (requests.RequestException, ValueError):
            info = None
        players = self.players()
        version = (info or {}).get("server_version") or ""
        return version, len(players)


def _ma_sub(row):
    parts = []
    artists = row.get("artists") or []
    if artists and isinstance(artists[0], dict):
        parts.append(", ".join(a.get("name", "") for a in artists[:3]))
    owner = row.get("owner")
    if owner and isinstance(owner, str):
        parts.append(owner)
    providers = row.get("provider_mappings") or []
    names = sorted({p.get("provider_domain") for p in providers if isinstance(p, dict) and p.get("provider_domain")})
    if names:
        parts.append(", ".join(names[:3]))
    return " · ".join(p for p in parts if p)


# --------------------------------------------------------------------------
# Spotify über go-librespot
# --------------------------------------------------------------------------

LIBRESPOT_URL = "https://github.com/devgianlu/go-librespot/releases/latest/download/go-librespot_linux_{arch}.tar.gz"
SPOTIFY_LINK = re.compile(r"open\.spotify\.com/(?:intl-[a-z]+/)?(playlist|album|artist|track|show|episode)/([A-Za-z0-9]+)")
SPOTIFY_URI = re.compile(r"^spotify:(playlist|album|artist|track|show|episode|collection):?([A-Za-z0-9:]*)$")


def spotify_uri(text):
    """Ein Spotify-Link oder eine URI als spotify:typ:id, sonst ''."""
    text = str(text or "").strip()
    match = SPOTIFY_LINK.search(text)
    if match:
        return f"spotify:{match.group(1)}:{match.group(2)}"
    if SPOTIFY_URI.match(text):
        return text
    if text == "liked":
        return "spotify:collection:tracks"
    return ""


def librespot_arch():
    machine = platform.machine().lower()
    if machine in ("aarch64", "arm64"):
        return "arm64"
    if machine in ("x86_64", "amd64"):
        return "x86_64"
    if machine.startswith("armv6"):
        return "armv6_rpi"
    if machine.startswith("arm"):
        return "armv6"
    return ""


class Spotify:
    """Startet und überwacht go-librespot und spricht mit seiner API."""

    def __init__(self, folder, log, port=36783):
        self.folder = Path(folder)
        self.binary = self.folder / "go-librespot"
        self.config_dir = self.folder / "config"
        self.port = port
        self.log = log
        self.process = None
        self.state = "off"         # off, installing, starting, pairing, ready, error
        self.note = ""
        self.enabled = False
        self.device_name = "DynaFrame"
        self.discoverable = True
        self._lock = threading.RLock()
        self._next_start = 0.0
        self._fails = 0

    # ---- Einrichtung -----------------------------------------------------

    def installed(self):
        return self.binary.is_file() and os.access(self.binary, os.X_OK)

    def install(self):
        arch = librespot_arch()
        if not arch:
            raise SourceError(f"Spotify: Prozessor {platform.machine()} wird nicht unterstützt")
        self.folder.mkdir(parents=True, exist_ok=True)
        archive = self.folder / "go-librespot.tar.gz"
        url = LIBRESPOT_URL.format(arch=arch)
        self.log(f"Lade go-librespot von {url}")
        try:
            with requests.get(url, stream=True, timeout=(10, 120), headers={"User-Agent": USER_AGENT}) as answer:
                if answer.status_code != 200:
                    raise SourceError(f"Spotify-Baustein: HTTP {answer.status_code}")
                with open(archive, "wb") as handle:
                    for part in answer.iter_content(1 << 16):
                        handle.write(part)
        except requests.RequestException as exc:
            raise SourceError(f"Spotify-Baustein: {exc}") from exc
        try:
            with tarfile.open(archive) as tar:
                member = next((m for m in tar.getmembers() if m.isfile() and Path(m.name).name == "go-librespot"), None)
                if member is None:
                    raise SourceError("Spotify-Baustein: Datei im Archiv fehlt")
                source = tar.extractfile(member)
                temp = self.binary.with_suffix(".new")
                with open(temp, "wb") as handle:
                    shutil.copyfileobj(source, handle)
                os.chmod(temp, 0o755)
                temp.replace(self.binary)
        except (tarfile.TarError, OSError) as exc:
            raise SourceError(f"Spotify-Baustein: {exc}") from exc
        finally:
            try:
                archive.unlink()
            except OSError:
                pass

    def write_config(self):
        self.config_dir.mkdir(parents=True, exist_ok=True)
        config = {
            "device_name": self.device_name or "DynaFrame",
            "device_type": "speaker",
            "audio_backend": os.environ.get("PLAYLISTMUSIC_SPOTIFY_BACKEND", "pulseaudio"),
            "zeroconf_enabled": bool(self.discoverable),
            "credentials": {"type": "device_auth"},
            "server": {"enabled": True, "address": "localhost", "port": self.port},
            "volume_steps": 100,
            "initial_volume": 100,
            "ignore_last_volume": True,
            "disable_autoplay": False,
            "bitrate": 320,
        }
        path = self.config_dir / "config.yml"
        text = json.dumps(config, indent=2)   # JSON ist gültiges YAML
        if not path.is_file() or path.read_text(encoding="utf-8") != text:
            path.write_text(text, encoding="utf-8")
            return True
        return False

    # ---- Prozess ---------------------------------------------------------

    def configure(self, enabled, device_name, discoverable):
        with self._lock:
            changed = (bool(enabled) != self.enabled or device_name != self.device_name
                       or bool(discoverable) != self.discoverable)
            self.enabled, self.device_name, self.discoverable = bool(enabled), device_name, bool(discoverable)
            if changed:
                self._fails = 0
                self._next_start = 0.0
                self.stop_process()

    def tick(self):
        """Regelmäßig aufrufen: startet/hält go-librespot und liest den Zustand."""
        with self._lock:
            if not self.enabled:
                self.stop_process()
                self.state, self.note = "off", ""
                return
            if not self.installed():
                if time.time() < self._next_start:
                    return
                self.state, self.note = "installing", ""
                try:
                    self.install()
                except SourceError as exc:
                    self.state, self.note = "error", str(exc)
                    self._next_start = time.time() + 600
                    return
            if self.process is None or self.process.poll() is not None:
                if self.process is not None:
                    err = self._tail()
                    self._fails += 1
                    self.log(f"go-librespot beendet (Code {self.process.returncode}): {err}", "warning")
                    self.state, self.note = "error", err
                    self._next_start = time.time() + min(300, 10 * self._fails)
                    self.process = None
                if time.time() < self._next_start:
                    return
                self.write_config()
                self.state, self.note = "starting", ""
                log_path = self.folder / "go-librespot.log"
                env = dict(os.environ)
                env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")
                try:
                    self._log_handle = open(log_path, "ab")
                    self.process = subprocess.Popen([str(self.binary), "--config_dir", str(self.config_dir)],
                                                    stdout=self._log_handle, stderr=subprocess.STDOUT,
                                                    stdin=subprocess.DEVNULL, env=env, start_new_session=True)
                    (self.folder / "pid").write_text(str(self.process.pid))
                except OSError as exc:
                    self.state, self.note = "error", str(exc)
                    self._next_start = time.time() + 300
                    return
                time.sleep(1.5)
        self.refresh_state()

    def refresh_state(self):
        if not self.enabled or self.process is None:
            return
        code = self.auth_code()
        if code:
            self.state, self.note = "pairing", code
            return
        status = self.status()
        if status is None:
            if self.state not in ("pairing",):
                self.state = "starting"
            return
        self._fails = 0
        self.state, self.note = "ready", status.get("username") or ""

    def _tail(self):
        try:
            data = (self.folder / "go-librespot.log").read_bytes()[-2000:].decode("utf-8", "replace")
        except OSError:
            return ""
        lines = [l for l in data.splitlines() if l.strip()]
        return (lines[-1] if lines else "")[:200]

    def stop_process(self):
        process, self.process = self.process, None
        if process is not None and process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=5)
            except Exception:
                try:
                    process.kill()
                except Exception:
                    pass

    def kill_leftover(self):
        """Ein go-librespot vom letzten Lauf (Plugin abgestürzt) beenden."""
        try:
            pid = int((self.folder / "pid").read_text().strip())
            cmdline = Path(f"/proc/{pid}/cmdline").read_bytes()
        except (OSError, ValueError):
            return
        if b"go-librespot" in cmdline:
            try:
                os.killpg(pid, signal.SIGTERM)
            except OSError:
                pass

    def forget(self):
        """Abmelden: Zugangsdaten löschen, neu koppeln."""
        with self._lock:
            self.stop_process()
            for name in ("state.json", "credentials.json"):
                try:
                    (self.config_dir / name).unlink()
                except OSError:
                    pass
            self._next_start = 0.0

    # ---- API -------------------------------------------------------------

    def _api(self, method, path, body=None, timeout=8):
        try:
            answer = requests.request(method, f"http://127.0.0.1:{self.port}{path}", json=body, timeout=(3, timeout))
        except requests.RequestException:
            return None, 0
        if answer.status_code == 204 or not answer.content:
            return {}, answer.status_code
        try:
            return answer.json(), answer.status_code
        except ValueError:
            return {}, answer.status_code

    def auth_code(self):
        data, code = self._api("GET", "/auth/code", timeout=4)
        if code == 200 and isinstance(data, dict) and data.get("url"):
            return json.dumps({"url": data.get("url"), "code": data.get("code") or ""})
        return ""

    def status(self):
        data, code = self._api("GET", "/status", timeout=4)
        if code == 200 and isinstance(data, dict):
            return data
        if code == 204:
            return {}
        return None

    def ready(self):
        return self.state == "ready"

    def devices(self):
        data, code = self._api("GET", "/connect/devices")
        if code != 200 or not isinstance(data, dict):
            return []
        out = []
        for row in data.get("devices") or []:
            if row.get("is_self") or row.get("is_offline"):
                continue
            out.append({"id": row.get("id"), "label": row.get("name") or "?", "type": row.get("type") or "",
                        "active": bool(row.get("is_active")), "volume": row.get("volume")})
        return out

    def cluster(self):
        data, code = self._api("GET", "/connect/devices")
        return data if code == 200 and isinstance(data, dict) else {}

    def library(self):
        data, code = self._api("GET", "/library/playlists?limit=200")
        rows = (data or {}).get("items") if code == 200 and isinstance(data, dict) else []
        found = [{"ref": "spotify:collection:tracks", "label": "♥", "sub": "", "kind": "liked"}]
        for row in rows or []:
            folder = " / ".join(row.get("folder") or [])
            sub = " · ".join(x for x in (folder, f"{row.get('length')}" if row.get("length") is not None else "") if x)
            found.append({"ref": row.get("uri"), "label": row.get("name") or "?", "sub": sub, "kind": "playlist"})
        return found

    # Abspielen hier auf dem Rahmen
    def play(self, uri, shuffle):
        self._api("POST", "/player/shuffle_context", {"shuffle_context": bool(shuffle)})
        data, code = self._api("POST", "/player/play", {"uri": uri})
        if code != 200:
            raise SourceError(f"Spotify spielt nicht ab (HTTP {code})")

    def set_volume(self, percent):
        self._api("POST", "/player/volume", {"volume": int(max(0, min(100, percent)))})

    def get_volume(self):
        data, code = self._api("GET", "/player/volume")
        if code == 200 and isinstance(data, dict) and data.get("max"):
            return round(100 * data.get("value", 0) / data["max"])
        return None

    def pause(self):
        self._api("POST", "/player/pause")

    def resume(self):
        self._api("POST", "/player/resume")

    def stop(self):
        data, code = self._api("POST", "/player/stop")
        if code >= 400 or code == 0:
            self._api("POST", "/player/pause")

    def busy_here(self):
        """Spielt hier gerade etwas, das jemand anders gestartet hat?"""
        status = self.status() or {}
        return bool(status) and not status.get("stopped") and not status.get("paused") \
            and status.get("play_origin") not in (None, "go-librespot")

    # Ein anderes Connect-Gerät steuern
    def remote(self, device_id, endpoint, **extra):
        body = {"device_id": device_id, "endpoint": endpoint}
        body.update(extra)
        data, code = self._api("POST", "/connect/command", body)
        if code != 200:
            raise SourceError(f"Spotify: Gerät antwortet nicht (HTTP {code})")

    def remote_busy(self, device_id):
        data = self.cluster()
        playing = (data.get("now_playing") or {})
        return data.get("active_device_id") == device_id and bool(playing) and not playing.get("paused", False)
