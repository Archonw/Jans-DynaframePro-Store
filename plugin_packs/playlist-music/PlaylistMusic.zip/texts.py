"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Aus": ("Off", "Apagado"),
    "Bereit, es läuft gerade keine Playlist mit Musik.": (
        "Ready, no playlist with music is running.", "Listo, no se está reproduciendo ninguna lista con música."),
    "Musik ist ausgeschaltet.": ("Music is switched off.", "La música está desactivada."),
    "Spielt {music} für {playlist}.": ("Playing {music} for {playlist}.", "Suena {music} para {playlist}."),
    "Pausiert ({why}).": ("Paused ({why}).", "En pausa ({why})."),
    "Leiser ({why}).": ("Quieter ({why}).", "Más bajo ({why})."),
    "ein Video läuft": ("a video is playing", "se reproduce un vídeo"),
    "ein anderes Plugin zeigt etwas": ("another plugin is showing something", "otro plugin muestra algo"),
    "Läuft weiter, obwohl die Playlist gewechselt hat.": (
        "Keeps playing although the playlist changed.", "Sigue sonando aunque la lista ha cambiado."),
    "Nicht gestartet: auf {target} läuft schon Musik.": (
        "Not started: music is already playing on {target}.", "No se ha iniciado: ya suena música en {target}."),
    "Nicht gestartet: außerhalb der Uhrzeit {start}–{end}.": (
        "Not started: outside the hours {start}–{end}.", "No se ha iniciado: fuera del horario {start}–{end}."),
    "Konnte nicht abspielen: {problem}": ("Could not play: {problem}", "No se ha podido reproducir: {problem}"),
    "Probehören: {music}": ("Preview: {music}", "Prueba: {music}"),
    "Gestoppt.": ("Stopped.", "Detenido."),
    "Der Rahmen": ("The frame", "El marco"),
    "Kein Tonausgang gefunden ({note}).": ("No sound output found ({note}).", "No se ha encontrado salida de sonido ({note})."),
    "ffmpeg fehlt auf dem Rahmen.": ("ffmpeg is missing on the frame.", "Falta ffmpeg en el marco."),
    "Verbunden mit {server}, Benutzer {user}.": ("Connected to {server}, user {user}.", "Conectado a {server}, usuario {user}."),
    "Verbunden mit Music Assistant {version}, {count} Lautsprecher.": (
        "Connected to Music Assistant {version}, {count} speakers.", "Conectado a Music Assistant {version}, {count} altavoces."),
    "DynaFrame antwortet nicht: {exc}": ("DynaFrame does not answer: {exc}", "DynaFrame no responde: {exc}"),
    "Spotify ist noch nicht bereit.": ("Spotify is not ready yet.", "Spotify aún no está listo."),
    "Spotify ist abgemeldet. Gleich erscheint ein neuer Code.": (
        "Signed out of Spotify. A new code appears shortly.", "Sesión de Spotify cerrada. En breve aparece un código nuevo."),
    "Dieser Ordner enthält {count} Musikdateien.": (
        "This folder contains {count} music files.", "Esta carpeta contiene {count} archivos de música."),
    "In diesem Ordner ist keine Musik.": ("There is no music in this folder.", "No hay música en esta carpeta."),
    "Alle anderen Playlists": ("All other playlists", "Todas las demás listas"),
    "Wähle zuerst, was gespielt werden soll.": ("First pick what should play.", "Elige primero qué debe sonar."),
}


def t(lang, template, **values):
    text = template
    if lang in LANGUAGES and lang != "de":
        row = _TEXTS.get(template)
        if row:
            text = row[LANGUAGES.index(lang) - 1]
    try:
        return text.format(**values) if values else text
    except (KeyError, IndexError, ValueError):
        return text
