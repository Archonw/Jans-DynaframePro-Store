"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/FussballLive/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["PageSeconds", "EveryMinutes", "ShowForSeconds", "ActiveFrom", "ActiveTo", "GoalSeconds", "GoalVolume"];
const CHECK_FIELDS = ["ShowTable", "GoalTakeover", "GoalSound", "TeamColors"];
let current = null;
let editing = false;

// Texte der Seite auf Deutsch, Englisch und Spanisch. Die Sprache ist eine
// Einstellung des Plugins und gilt auch für die Szene.
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Ergebnisse, Spieltage und Tabellen deiner Ligen. Fußball Live legt sie im eingestellten Takt für eine eingestellte Zeit über die laufende Playlist und gibt den Bildschirm danach zurück. Jede Änderung hier wird sofort gespeichert.",
    "Results, matchdays and tables of your leagues. Fußball Live shows them over the running playlist at the interval and for the time you set, then hands the screen back. Every change here is saved immediately.",
    "Resultados, jornadas y clasificaciones de tus ligas. Fußball Live los muestra sobre la lista en curso con la frecuencia y la duración que elijas y después devuelve la pantalla. Cada cambio aquí se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  refresh: ["Jetzt aktualisieren", "Refresh now", "Actualizar ahora"],
  show: ["Anzeigen", "Show", "Mostrar"],
  cancel: ["Beenden", "Stop", "Terminar"],
  factStatus: ["Gerade", "Now", "Ahora"],
  factScreen: ["Bildschirm", "Screen", "Pantalla"],
  factNext: ["Nächste Anzeige", "Next display", "Próxima visualización"],
  factScene: ["Szene", "Scene", "Escena"],
  factVersion: ["Version", "Version", "Versión"],
  leagues: ["Ligen", "Leagues", "Ligas"],
  leaguesHint: ["Jede gewählte Liga ist eine Seite in der Szene, in der Reihenfolge oben. Mit den Pfeilen änderst du sie.",
    "Each selected league is one page in the scene, in the order shown at the top. Use the arrows to change it.",
    "Cada liga elegida es una página de la escena, en el orden de arriba. Cámbialo con las flechas."],
  moveUp: ["Nach oben", "Move up", "Subir"],
  moveDown: ["Nach unten", "Move down", "Bajar"],
  pageSeconds: ["Sekunden je Liga", "Seconds per league", "Segundos por liga"],
  showTable: ["Tabelle neben den Spielen zeigen (wo es eine gibt)", "Show the table next to the matches (where there is one)",
    "Mostrar la clasificación junto a los partidos (si existe)"],
  autoTitle: ["Regelmäßig über die Playlist legen", "Show over the playlist regularly", "Mostrar sobre la lista periódicamente"],
  autoHint: ["Dafür muss auf der Plugins-Seite des Rahmens <b>Allow takeover</b> für Fußball Live eingeschaltet sein. Ein ausgeschalteter Bildschirm wird nie geweckt.",
    "For this, <b>Allow takeover</b> must be switched on for Fußball Live on the frame's Plugins page. A screen that is off is never woken.",
    "Para ello, <b>Allow takeover</b> debe estar activado para Fußball Live en la página de plugins del marco. Una pantalla apagada nunca se enciende."],
  when: ["Wann", "When", "Cuándo"],
  modeOff: ["Nie (nur mit Anzeigen oder in einer Playlist)", "Never (only with Show or in a playlist)", "Nunca (solo con Mostrar o en una lista)"],
  modeAlways: ["Immer, im Takt unten", "Always, at the interval below", "Siempre, con la frecuencia de abajo"],
  modeMatchday: ["Nur an Spieltagen", "Only on matchdays", "Solo en días de jornada"],
  modeLive: ["Nur, wenn ein Spiel läuft", "Only while a match is being played", "Solo mientras se juega un partido"],
  everyMinutes: ["Alle … Minuten", "Every … minutes", "Cada … minutos"],
  forSeconds: ["Für … Sekunden", "For … seconds", "Durante … segundos"],
  goalSound: ["Ton abspielen, sobald die Seite des Tores zu sehen ist", "Play a sound once the goal's page is on screen",
    "Reproducir un sonido cuando la página del gol esté en pantalla"],
  soundFile: ["Ton", "Sound", "Sonido"],
  soundVolume: ["Lautstärke in % (0 = wie am Rahmen eingestellt)", "Volume in % (0 = as set on the frame)",
    "Volumen en % (0 = como está en el marco)"],
  soundTest: ["Auf dem Rahmen anhören", "Listen on the frame", "Escuchar en el marco"],
  soundUpload: ["Eigenen Ton hochladen", "Upload your own sound", "Subir un sonido propio"],
  soundDelete: ["Diesen Ton löschen", "Delete this sound", "Borrar este sonido"],
  soundHint: ["Eigene Töne: WAV, MP3, OGG oder FLAC bis 5 MB. Der Ton kommt aus dem Lautsprecher des Rahmens, einmal je Tor-Anzeige.",
    "Your own sounds: WAV, MP3, OGG or FLAC up to 5 MB. The sound plays from the frame's speaker, once per goal display.",
    "Sonidos propios: WAV, MP3, OGG o FLAC de hasta 5 MB. El sonido sale del altavoz del marco, una vez por cada gol."],
  soundOwn: [" (eigener)", " (your own)", " (propio)"],
  soundBuiltin: { "torjubel.wav": ["Torjubel", "Goal cheer", "Celebración de gol"], "torhupe.wav": ["Torhupe", "Goal horn", "Bocina de gol"] },
  soundUploading: ["Lade {name} hoch …", "Uploading {name} …", "Subiendo {name} …"],
  soundSaved: ["{name} gespeichert und ausgewählt.", "{name} saved and selected.", "{name} guardado y elegido."],
  soundTooBig: ["Die Datei ist größer als 5 MB.", "The file is larger than 5 MB.", "El archivo supera los 5 MB."],
  soundDeleted: ["Ton gelöscht.", "Sound deleted.", "Sonido borrado."],
  from: ["Von … Uhr", "From … o'clock", "Desde las …"],
  to: ["Bis … Uhr", "Until … o'clock", "Hasta las …"],
  goalTitle: ["Bei einem Tor", "When a goal is scored", "Cuando hay un gol"],
  goalTakeover: ["Bei einem Tor sofort die Seite seiner Liga anzeigen", "Show that league's page right away when a goal is scored",
    "Mostrar al momento la página de esa liga cuando hay un gol"],
  goalHint: ["Tore werden jede Minute erkannt, also bis zu eine Minute nach dem Treffer. Zwei Tore kurz hintereinander lösen nur eine Anzeige aus.",
    "Goals are detected every minute, so up to one minute after they happen. Two goals in quick succession trigger only one display.",
    "Los goles se detectan cada minuto, así que hasta un minuto después. Dos goles seguidos solo provocan una visualización."],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „Fußball Live“ anlegen", "Create the playlist “Fußball Live”", "Crear la lista «Fußball Live»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistHint: ["Die Playlist enthält nur die Szene (1 Minute) und ist eingeschaltet. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist holds only the scene (1 minute) and is switched on. You can also add the scene to any playlist yourself.",
    "La lista contiene solo la escena (1 minuto) y está activada. También puedes añadir la escena a cualquier lista."],
  sources: ["Quellen", "Sources", "Fuentes"],
  sourcesHint: ["1., 2. und 3. Liga kommen von OpenLigaDB, alle anderen Wettbewerbe von ESPN. Laufende Spiele der deutschen Ligen bekommen Stand und Minute von ESPN, weil OpenLigaDB von Hand gepflegt wird und bei Toren oft hinterherhängt. Ist OpenLigaDB nicht erreichbar, liest Fußball Live die deutschen Ligen ganz bei ESPN.",
    "The 1st, 2nd and 3rd German divisions come from OpenLigaDB, all other competitions from ESPN. Running German matches take score and minute from ESPN, because OpenLigaDB is maintained by hand and often lags behind on goals. If OpenLigaDB is unreachable, Fußball Live reads the German leagues entirely from ESPN.",
    "La 1.ª, 2.ª y 3.ª división alemanas vienen de OpenLigaDB, el resto de competiciones de ESPN. Los partidos alemanes en curso toman marcador y minuto de ESPN, porque OpenLigaDB se mantiene a mano y a menudo va con retraso en los goles. Si OpenLigaDB no responde, Fußball Live lee las ligas alemanas solo de ESPN."],
  noAnswer: ["Das Plugin antwortet nicht – vermutlich wurde es neu gestartet. Lade die Seite neu.",
    "The plugin is not responding – it was probably restarted. Reload the page.",
    "El plugin no responde; probablemente se ha reiniciado. Recarga la página."],
  restarted: ["Das Plugin wurde neu gestartet (HTTP {status}). Lade die Seite neu.",
    "The plugin was restarted (HTTP {status}). Reload the page.",
    "El plugin se ha reiniciado (HTTP {status}). Recarga la página."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  oclock: ["{time} Uhr", "{time}", "{time} h"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
  teamTitle: ["Mein Verein", "My club", "Mi club"],
  teamHint: ["Wer möchte, wählt hier seinen Verein. Sein Wappen erscheint dann im Hintergrund der Szene und dieser Seite.",
    "If you like, pick your club here. Its crest then appears in the background of the scene and of this page.",
    "Si quieres, elige aquí tu club. Su escudo aparecerá en el fondo de la escena y de esta página."],
  teamLeague: ["Liga", "League", "Liga"],
  team: ["Verein", "Club", "Club"],
  noTeam: ["Kein Verein", "No club", "Ningún club"],
  teamColors: ["Vereinsfarben als Akzentfarbe verwenden", "Use the club colours as accent colour", "Usar los colores del club como color de acento"],
  teamsLoading: ["Lade die Vereine …", "Loading the clubs …", "Cargando los clubes …"],
  noColors: ["Für diesen Verein liefert die Quelle keine Farben.", "The source has no colours for this club.",
    "La fuente no tiene colores para este club."],
  noLeague: ["Keine Liga gewählt.", "No league selected.", "No hay ninguna liga elegida."],
  noRound: ["ohne Spieltag", "no matchday", "sin jornada"],
  nMatches: ["{n} Spiele", "{n} matches", "{n} partidos"],
  notRead: ["noch nicht gelesen", "not read yet", "aún sin leer"],
  showing: ["Fußball Live wird angezeigt", "Fußball Live is on screen", "Fußball Live está en pantalla"],
  until: [" bis {time}", " until {time}", " hasta {time}"],
  playlistRuns: ["Playlist läuft", "Playlist is playing", "La lista está en curso"],
  off: ["aus", "off", "desactivado"],
  installed: ["installiert", "installed", "instalada"],
  notFound: ["nicht gefunden", "not found", "no encontrada"],
  duration: ["{pages} Ligen × {sec} s = {total} s für einen Durchlauf aller Seiten.",
    "{pages} leagues × {sec} s = {total} s to go through all pages once.",
    "{pages} ligas × {sec} s = {total} s para recorrer todas las páginas."],
  tooShort: [" Mit {sec} s sind nicht alle Ligen zu sehen.", " With {sec} s not all leagues are shown.", " Con {sec} s no se ven todas las ligas."]
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "en";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "en";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([502, 503, 504].includes(response.status)) {
    throw new Error(t("restarted", { status: response.status }));
  }
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "") {
  const node = el("statusNote");
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(iso) {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(name, value) {
  try {
    await api("./api/settings", { method: "POST", body: JSON.stringify({ [name]: value }) });
    setStatus(t("saved"), "ok");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

function renderLeagues(state) {
  // Oben die gewählten Ligen in ihrer Reihenfolge, darunter die übrigen.
  const order = el("leagueOrder");
  const rest = el("leagueList");
  const chosen = state.settings.Leagues.slice();
  const names = new Map(state.leagues.map((l) => [l.id, l.name]));
  order.innerHTML = "";
  rest.innerHTML = "";

  const checkbox = (id, checked) => {
    const box = document.createElement("input");
    box.type = "checkbox";
    box.value = id;
    box.checked = checked;
    box.addEventListener("change", () => {
      save("Leagues", box.checked ? [...chosen, id] : chosen.filter((x) => x !== id));
    });
    return box;
  };
  const move = (index, step) => {
    const next = chosen.slice();
    [next[index], next[index + step]] = [next[index + step], next[index]];
    save("Leagues", next);
  };
  const arrow = (symbol, key, disabled, onClick) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "secondary arrow";
    button.textContent = symbol;
    button.title = t(key);
    button.setAttribute("aria-label", t(key));
    button.disabled = disabled;
    button.addEventListener("click", onClick);
    return button;
  };

  chosen.forEach((id, index) => {
    const li = document.createElement("li");
    const label = document.createElement("label");
    const text = document.createElement("span");
    text.textContent = names.get(id) || id;
    label.append(checkbox(id, true), text);
    li.append(label,
      arrow("▲", "moveUp", index === 0, () => move(index, -1)),
      arrow("▼", "moveDown", index === chosen.length - 1, () => move(index, 1)));
    order.append(li);
  });
  order.hidden = !chosen.length;

  for (const league of state.leagues) {
    if (chosen.includes(league.id)) continue;
    const label = document.createElement("label");
    const text = document.createElement("span");
    text.textContent = league.name;
    label.append(checkbox(league.id, false), text);
    rest.append(label);
  }
}

// ---- Mein Verein

const teamLists = new Map();  // Liga -> {teams, noColors} oder Promise

async function loadTeams(league) {
  if (!teamLists.has(league)) {
    teamLists.set(league, api(`./api/teams?league=${encodeURIComponent(league)}`).then((data) => {
      if (!data.success) throw new Error(data.error || "?");
      return data;
    }).catch((error) => {
      teamLists.delete(league);
      throw error;
    }));
  }
  return teamLists.get(league);
}

async function fillTeams(league, chosenId) {
  const select = el("teamSelect");
  select.innerHTML = `<option value="">${t("teamsLoading")}</option>`;
  select.disabled = true;
  try {
    const data = await loadTeams(league);
    if (el("teamLeague").value !== league) return;  // inzwischen andere Liga
    select.innerHTML = "";
    select.append(new Option(t("noTeam"), ""));
    for (const team of data.teams) select.append(new Option(team.name, team.id));
    select.value = data.teams.some((x) => x.id === chosenId) ? chosenId : "";
    select.dataset.league = league;
  } catch (error) {
    select.innerHTML = `<option value="">${t("noTeam")}</option>`;
    el("teamNote").textContent = error.message;
  } finally {
    select.disabled = false;
  }
}

function renderTeam(state) {
  const team = state.team;
  const chosen = state.settings.Team;
  const leagueSelect = el("teamLeague");
  if (document.activeElement !== leagueSelect) {
    const keep = leagueSelect.value;
    leagueSelect.innerHTML = "";
    for (const league of state.teamLeagues) leagueSelect.append(new Option(league.name, league.id));
    leagueSelect.value = chosen?.league || keep || state.teamLeagues[0]?.id || "";
  }
  const select = el("teamSelect");
  if (select.dataset.league !== leagueSelect.value || select.dataset.lang !== lang) {
    select.dataset.lang = lang;
    fillTeams(leagueSelect.value, chosen?.id || "");
  } else if (document.activeElement !== select) {
    select.value = chosen && chosen.league === leagueSelect.value ? chosen.id : "";
  }

  const root = document.documentElement;
  if (team?.logo) {
    document.body.style.setProperty("--crest", `url("${new URL(team.logo, location.href).href.replace(/["\\]/g, "")}")`);
    document.body.classList.add("crested");
  } else {
    document.body.style.removeProperty("--crest");
    document.body.classList.remove("crested");
  }
  if (team?.useColors) {
    root.style.setProperty("--accent", team.accent);
    root.style.setProperty("--accent-ink", team.accentInk);
  } else {
    root.style.removeProperty("--accent");
    root.style.removeProperty("--accent-ink");
  }
  const swatch = el("teamSwatch");
  swatch.hidden = !team?.accent;
  if (team?.accent) swatch.style.setProperty("--team-accent", team.accent);
  el("TeamColors").disabled = !team?.accent;
  el("teamNote").textContent = team && !team.accent ? t("noColors") : "";
}

el("teamLeague").addEventListener("change", (e) => {
  const chosen = current?.settings.Team;
  fillTeams(e.target.value, chosen?.league === e.target.value ? chosen.id : "");
});
el("teamSelect").addEventListener("change", async (e) => {
  const league = el("teamLeague").value;
  let team = null;
  if (e.target.value) {
    const data = await loadTeams(league);
    const found = data.teams.find((x) => x.id === e.target.value);
    if (found) team = { ...found, league };
  }
  save("Team", team);
});

function renderSources(state) {
  const list = el("sourceList");
  list.innerHTML = "";
  if (!state.sources.length) {
    list.innerHTML = `<li><span class="meta">${t("noLeague")}</span></li>`;
    return;
  }
  for (const row of state.sources) {
    const li = document.createElement("li");
    const dot = row.error ? "bad" : row.at ? "" : "idle";
    const live = row.live ? ` · ${row.live} live` : "";
    li.innerHTML = `<span class="name"><span class="dot ${dot}"></span></span><span class="meta"></span>`;
    li.querySelector(".name").append(row.name);
    li.querySelector(".meta").textContent = row.at
      ? `${row.round || t("noRound")} · ${t("nMatches", { n: row.matches })}${live} · ${row.source || "?"} · ${clock(row.at)}`
      : t("notRead");
    if (row.error) {
      const err = document.createElement("span");
      err.className = "err";
      err.textContent = row.error;
      li.append(err);
    }
    list.append(li);
  }
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  el("factStatus").textContent = state.status || "—";
  el("factScreen").textContent = state.takeover.active
    ? `${t("showing")}${state.takeover.until ? t("until", { time: clock(state.takeover.until) }) : ""}`
    : t("playlistRuns");
  el("factNext").textContent = s.AutoMode === "off" ? t("off") : state.next ? clock(state.next) : (state.autoNote || "—");
  el("factScene").textContent = state.scene.found ? t("installed") : t("notFound");
  el("factVersion").textContent = state.version;
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Fußball Live ${state.version}] `);

  const notes = [state.scene.note, state.takeover.note, state.lastError].filter(Boolean);
  if (!editing && notes.length) setStatus(notes.join(" "), state.lastError ? "bad" : "");
  const permission = el("permissionNote");
  permission.textContent = state.permission || "";
  permission.hidden = !state.permission;

  if (!editing) {
    for (const name of NUMBER_FIELDS) {
      if (document.activeElement !== el(name)) el(name).value = s[name];
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    el("AutoMode").value = s.AutoMode;
    el("MakePlaylist").value = String(Boolean(s.MakePlaylist));
    el("Language").value = lang;
  }
  renderLeagues(state);
  renderTeam(state);
  renderSounds(state);
  renderSources(state);
  el("playlistNote").textContent = state.ownerPlaylist || "";

  const pages = s.Leagues.length;
  const needed = pages * s.PageSeconds;
  el("durationHint").textContent = pages > 1
    ? t("duration", { pages, sec: s.PageSeconds, total: needed }) +
      (s.ShowForSeconds < needed ? t("tooShort", { sec: s.ShowForSeconds }) : "")
    : "";
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
  input.addEventListener("change", () => save(name, Number(input.value)));
}
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save(name, e.target.checked));
el("AutoMode").addEventListener("change", (e) => save("AutoMode", e.target.value));
el("MakePlaylist").addEventListener("change", (e) => save("MakePlaylist", e.target.value === "true"));
el("Language").addEventListener("change", (e) => {
  applyLanguage(e.target.value);
  save("Language", e.target.value);
});

for (const [id, path] of [["showButton", "show"], ["cancelButton", "cancel"], ["refreshButton", "refresh"]]) {
  el(id).addEventListener("click", async () => {
    try {
      const result = await api(`./api/${path}`, { method: "POST" });
      setStatus(result.message || "", "busy");
      setTimeout(refresh, 2500);
    } catch (error) {
      setStatus(error.message, "bad");
    }
  });
}

// ---- Ton bei einem Tor

function soundLabel(sound) {
  const builtin = I18N.soundBuiltin[sound.name];
  const name = builtin ? builtin[LANGS.indexOf(lang)] : sound.name.replace(/\.[^.]+$/, "");
  return sound.own ? name + t("soundOwn") : name;
}

let soundKey = "";

function renderSounds(state) {
  const select = el("GoalSoundFile");
  const chosen = state.settings.GoalSoundFile;
  // Nur neu aufbauen, wenn sich etwas geändert hat: die Seite fragt alle 5 s.
  const key = JSON.stringify([lang, chosen, state.sounds]);
  if (!editing && key !== soundKey) {
    soundKey = key;
    select.innerHTML = "";
    for (const sound of state.sounds || []) select.append(new Option(soundLabel(sound), sound.name));
    select.value = chosen;
  }
  const own = (state.sounds || []).find((s) => s.name === chosen)?.own;
  el("soundDelete").hidden = !own;
  const note = el("soundNote");
  note.textContent = state.soundNote || "";
  note.hidden = !state.soundNote;
}

el("GoalSoundFile").addEventListener("change", (e) => save("GoalSoundFile", e.target.value));
el("soundTest").addEventListener("click", async () => {
  try {
    const result = await api("./api/sounds/test", { method: "POST", body: JSON.stringify({ name: el("GoalSoundFile").value }) });
    setStatus(result.message || "", "busy");
  } catch (error) {
    setStatus(error.message, "bad");
  }
});
el("soundUpload").addEventListener("click", () => el("soundFileInput").click());
el("soundFileInput").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  if (file.size > 5 * 1024 * 1024) {
    setStatus(t("soundTooBig"), "bad");
    return;
  }
  setStatus(t("soundUploading", { name: file.name }), "busy");
  try {
    const result = await api(`./api/sounds?name=${encodeURIComponent(file.name)}`, {
      method: "POST", headers: { Accept: "application/json", "Content-Type": "application/octet-stream" }, body: file });
    setStatus(t("soundSaved", { name: result.name }), "ok");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
});
el("soundDelete").addEventListener("click", async () => {
  try {
    await api("./api/sounds/delete", { method: "POST", body: JSON.stringify({ name: el("GoalSoundFile").value }) });
    setStatus(t("soundDeleted"), "ok");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
});

refresh();
setInterval(refresh, 5000);
