"use strict";

// Always "./api/...": the WebUI serves this page under /Plugins/Advanced/GrowingUp/ without <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["MaxFrames", "MinFace", "RefreshHours", "HoldSeconds", "FadeSeconds", "ViewSeconds", "EveryMinutes", "ShowForSeconds", "ActiveFrom", "ActiveTo"];
const SELECT_FIELDS = ["Interval", "Zoom", "Captions", "AutoMode"];
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "en";
let current = null;
let editing = false;
let people = [];
let peopleError = "";

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Sieh zu, wie deine Kinder (oder wer auch immer) groß werden: Growing Up nimmt Personen aus deinem Immich, sucht aus allen ihren Fotos je Monat, Quartal oder Jahr das beste Gesicht heraus und schneidet Porträts aus, die auf das Gesicht ausgerichtet sind. Jede Änderung hier wird sofort gespeichert.",
    "Watch your children (or anyone) grow up: Growing Up takes people from your Immich, picks the best face per month, quarter or year from all their photos and cuts out portraits lined up on the face. Every change here is saved immediately.",
    "Mira cómo crecen tus hijos (o quien sea): Growing Up toma personas de tu Immich, elige la mejor cara por mes, trimestre o año de todas sus fotos y recorta retratos alineados con la cara. Cada cambio se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  refresh: ["Immich neu fragen", "Ask Immich again", "Consultar Immich"],
  show: ["Anzeigen", "Show", "Mostrar"],
  cancel: ["Beenden", "Stop", "Detener"],
  factStatus: ["Jetzt", "Now", "Ahora"],
  factScreen: ["Bildschirm", "Screen", "Pantalla"],
  factNext: ["Nächste Anzeige", "Next display", "Próxima visualización"],
  factVersion: ["Version", "Version", "Versión"],
  showing: ["Growing Up wird gezeigt", "Growing Up is showing", "Se muestra Growing Up"],
  until: [" bis {time}", " until {time}", " hasta las {time}"],
  playlistRuns: ["Deine Playlist läuft", "Your playlist is playing", "Tu lista se está reproduciendo"],
  off: ["Aus", "Off", "Desactivado"],
  oclock: ["{time} Uhr", "{time}", "{time}"],
  pillowMissing: ["Pillow fehlt, deshalb können keine Porträts ausgeschnitten werden. Installiere das Paket noch einmal (der Rahmen braucht dafür Zugriff auf files.pythonhosted.org).",
    "Pillow is missing, so no portraits can be cut out. Install the package again (the frame needs access to files.pythonhosted.org for that).",
    "Falta Pillow, así que no se pueden recortar retratos. Vuelve a instalar el paquete (el marco necesita acceso a files.pythonhosted.org)."],
  immichTitle: ["Dein Immich-Server", "Your Immich server", "Tu servidor Immich"],
  immich1: ["Die Adresse, unter der du Immich im Browser öffnest, z.&nbsp;B. <code>http://192.168.1.10:2283</code>.",
    "The address you open Immich with in the browser, e.g. <code>http://192.168.1.10:2283</code>.",
    "La dirección con la que abres Immich en el navegador, p.&nbsp;ej. <code>http://192.168.1.10:2283</code>."],
  immich2: ["Ein API-Schlüssel: in Immich <b>Kontoeinstellungen › API-Schlüssel › Neuer API-Schlüssel</b>. Er braucht mindestens <code>person.read</code>, <code>asset.read</code>, <code>asset.view</code> und <code>face.read</code> (oder einfach alle).",
    "An API key: in Immich <b>Account settings › API keys › New API key</b>. It needs at least <code>person.read</code>, <code>asset.read</code>, <code>asset.view</code> and <code>face.read</code> (or simply all).",
    "Una clave API: en Immich <b>Ajustes de la cuenta › Claves API › Nueva clave API</b>. Necesita al menos <code>person.read</code>, <code>asset.read</code>, <code>asset.view</code> y <code>face.read</code> (o simplemente todos)."],
  serverUrl: ["Server-Adresse", "Server address", "Dirección del servidor"],
  apiKey: ["API-Schlüssel", "API key", "Clave API"],
  save: ["Speichern", "Save", "Guardar"],
  test: ["Verbindung testen", "Test connection", "Probar conexión"],
  keySaved: ["gespeichert {hint}", "saved {hint}", "guardada {hint}"],
  adopted: ["Server und Schlüssel wurden von {name} übernommen.", "Server and key were taken from {name}.", "Servidor y clave tomados de {name}."],
  peopleTitle: ["Wessen Gesicht soll groß werden?", "Whose face should grow up?", "¿De quién es la cara que crecerá?"],
  peopleHint: ["Personen mit Namen aus der Gesichtserkennung von Immich. Mit Geburtstag zeigt die Szene das Alter auf jedem Bild und kann Geschwister im gleichen Alter vergleichen; trag ihn in Immich ein oder hier. Tippst oder klickst du ein Porträt an, nimmt Growing Up für diesen Zeitraum ein anderes Foto.",
    "People with a name from Immich's face recognition. With a birthday the scene shows the age on every picture and can compare siblings at the same age; enter it in Immich or here. Tap or click a portrait to make Growing Up use another photo for that period.",
    "Personas con nombre del reconocimiento facial de Immich. Con la fecha de nacimiento la escena muestra la edad en cada imagen y puede comparar hermanos a la misma edad; añádela en Immich o aquí. Toca o haz clic en un retrato para que Growing Up use otra foto para ese periodo."],
  addPerson: ["Person hinzufügen", "Add a person", "Añadir una persona"],
  filter: ["Name suchen …", "Search name …", "Buscar nombre …"],
  noPeople: ["Immich hat noch keine Personen mit Namen. Gib Gesichtern in Immich unter Erkunden › Personen einen Namen.",
    "Immich has no named people yet. Name faces in Immich under Explore › People.",
    "Immich aún no tiene personas con nombre. Pon nombre a las caras en Immich en Explorar › Personas."],
  connectFirst: ["Verbinde zuerst deinen Immich-Server.", "Connect your Immich server first.", "Conecta primero tu servidor Immich."],
  allChosen: ["Alle Personen sind ausgewählt.", "All people are picked.", "Todas las personas están elegidas."],
  maxPeople: ["Höchstens 12 Personen.", "At most 12 people.", "Como máximo 12 personas."],
  birthday: ["Geburtstag", "Birthday", "Nacimiento"],
  fromImmich: ["aus Immich", "from Immich", "de Immich"],
  stats: ["{photos} Fotos · {faces} mit Gesicht · {frames} Porträts", "{photos} photos · {faces} with a face · {frames} portraits", "{photos} fotos · {faces} con cara · {frames} retratos"],
  waiting: ["Wartet auf die erste Runde …", "Waiting for the first round …", "Esperando la primera ronda …"],
  remove: ["Entfernen", "Remove", "Quitar"],
  showPerson: ["Anzeigen", "Show", "Mostrar"],
  up: ["Nach oben", "Move up", "Subir"],
  restore: ["{n} verworfene zurückholen", "Bring back {n} skipped", "Recuperar {n} descartadas"],
  excludeAsk: ["Für diesen Zeitraum ein anderes Foto nehmen?", "Use another photo for this period?", "¿Usar otra foto para este periodo?"],
  smallFace: ["kleines Gesicht", "small face", "cara pequeña"],
  facesTitle: ["Welche Gesichter", "Which faces", "Qué caras"],
  facesHint: ["Growing Up nimmt je Zeitraum das beste Gesicht: groß, ganz im Bild, eher von vorn; Favoriten und Sterne zählen mit. Kleinere Gesichter als hier eingestellt nimmt es nur, wenn es in dem Zeitraum nichts Besseres gibt.",
    "Growing Up takes the best face per period: big, whole, rather from the front; favourites and stars count too. Faces smaller than set here are only used when a period has nothing better.",
    "Growing Up toma la mejor cara de cada periodo: grande, completa, más bien de frente; favoritos y estrellas también cuentan. Las caras más pequeñas que lo indicado solo se usan si en el periodo no hay nada mejor."],
  interval: ["Ein Porträt je", "One portrait per", "Un retrato por"],
  intAuto: ["Automatisch (nach Alter)", "Automatic (by age)", "Automático (según la edad)"],
  intMonth: ["Monat", "Month", "Mes"],
  intQuarter: ["Quartal", "Quarter", "Trimestre"],
  intHalf: ["Halbjahr", "Half year", "Semestre"],
  intYear: ["Jahr", "Year", "Año"],
  intervalHint: ["Automatisch: im ersten Lebensjahr jeden Monat, bis 3 jedes Quartal, bis 6 jedes Halbjahr, danach jedes Jahr. Ohne Geburtstag: Quartale bei bis zu vier Jahren Fotos, sonst Jahre.",
    "Automatic: every month in the first year, every quarter until 3, every half year until 6, then every year. Without a birthday: quarters for up to four years of photos, otherwise years.",
    "Automático: cada mes el primer año, cada trimestre hasta los 3, cada semestre hasta los 6 y luego cada año. Sin fecha de nacimiento: trimestres con hasta cuatro años de fotos, si no, años."],
  maxFrames: ["Höchstens … Porträts je Person", "At most … portraits per person", "Como máximo … retratos por persona"],
  minFace: ["Kleinstes Gesicht (Pixel)", "Smallest face (pixels)", "Cara más pequeña (píxeles)"],
  zoom: ["Ausschnitt", "Crop", "Encuadre"],
  zoomTight: ["Eng: nur das Gesicht", "Close: face only", "Cerrado: solo la cara"],
  zoomNormal: ["Normal: Kopf und Hals", "Normal: head and neck", "Normal: cabeza y cuello"],
  zoomWide: ["Weit: Kopf und Schultern", "Wide: head and shoulders", "Amplio: cabeza y hombros"],
  refreshHours: ["Alle … Stunden nach neuen Fotos sehen", "Look for new photos every … hours", "Buscar fotos nuevas cada … horas"],
  sceneTitle: ["Die Szene", "The scene", "La escena"],
  viewsHint: ["Die Szene zeigt nacheinander für jede Person die gewählten Seiten; jedes Mal beginnt sie mit der nächsten Person. „Im gleichen Alter“ braucht zwei Personen mit Geburtstag.",
    "The scene shows the chosen pages for each person in turn; each time it starts with the next person. “At the same age” needs two people with a birthday.",
    "La escena muestra las páginas elegidas para cada persona por turnos; cada vez empieza con la siguiente persona. «A la misma edad» necesita dos personas con fecha de nacimiento."],
  vFilm: ["Zeitraffer", "Time-lapse", "Time-lapse"],
  vGrid: ["Kontaktbogen", "Contact sheet", "Hoja de contactos"],
  vThenNow: ["Damals und heute", "Then and now", "Antes y ahora"],
  vSameAge: ["Im gleichen Alter", "At the same age", "A la misma edad"],
  holdSeconds: ["Zeitraffer: Sekunden, die jedes Porträt stehen bleibt", "Time-lapse: seconds each portrait stays", "Time-lapse: segundos que se queda cada retrato"],
  fadeSeconds: ["Zeitraffer: Sekunden für die Überblendung", "Time-lapse: seconds for the crossfade", "Time-lapse: segundos del fundido"],
  viewSeconds: ["Andere Seiten: Sekunden je Seite", "Other pages: seconds each", "Otras páginas: segundos cada una"],
  captions: ["Beschriftung", "Captions", "Textos"],
  capBoth: ["Alter und Datum", "Age and date", "Edad y fecha"],
  capAge: ["Nur Alter", "Age only", "Solo edad"],
  capDate: ["Nur Datum", "Date only", "Solo fecha"],
  capNone: ["Keine", "None", "Ninguno"],
  duration: ["Ein Durchgang dauert etwa {sec} Sekunden. Setz die Dauer der Szene in deiner Playlist auf mindestens so viel.",
    "One round takes about {sec} seconds. Set the scene's duration in your playlist to at least that.",
    "Una ronda dura unos {sec} segundos. Pon la duración de la escena en tu lista al menos en ese valor."],
  autoTitle: ["Über die Playlist", "Over the playlist", "Sobre la lista"],
  autoHint: ["Growing Up kann die Szene von selbst über deine Playlist legen, für die eingestellte Zeit, dann geht die Playlist weiter. Dafür auf der Plugins-Seite <b>Allow takeover</b> für Growing Up einschalten. Ein ausgeschalteter Bildschirm wird nie geweckt. <b>An Geburtstagen</b> zeigt sie nur das Geburtstagskind mit Glückwunsch.",
    "Growing Up can put the scene over your playlist by itself for the set time, then the playlist continues. Switch on <b>Allow takeover</b> for Growing Up on the Plugins page for that. A screen that is off is never woken. <b>On birthdays</b> it shows only the birthday child with congratulations.",
    "Growing Up puede poner la escena sobre tu lista por sí solo durante el tiempo indicado; luego la lista sigue. Para ello activa <b>Allow takeover</b> para Growing Up en la página de plugins. Nunca enciende una pantalla apagada. <b>En cumpleaños</b> solo muestra a quien cumple años, con felicitación."],
  when: ["Wann", "When", "Cuándo"],
  modeOff: ["Nie", "Never", "Nunca"],
  modeBirthday: ["An Geburtstagen", "On birthdays", "En cumpleaños"],
  modeAlways: ["Jeden Tag", "Every day", "Todos los días"],
  everyMinutes: ["Alle … Minuten", "Every … minutes", "Cada … minutos"],
  forSeconds: ["Für … Sekunden", "For … seconds", "Durante … segundos"],
  from: ["Von … Uhr", "From … o'clock", "Desde las …"],
  to: ["Bis … Uhr", "To … o'clock", "Hasta las …"],
  birthdayToday: ["Heute Geburtstag: {names}", "Birthday today: {names}", "Hoy cumple años: {names}"],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „Growing Up“ anlegen", "Create the playlist “Growing Up”", "Crear la lista «Growing Up»"],
  no: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistHint: ["Die Playlist enthält nur die Szene (2 Minuten) und ist eingeschaltet. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist holds only the scene (2 minutes) and is switched on. You can also add the scene to any playlist yourself.",
    "La lista contiene solo la escena (2 minutos) y está activada. También puedes añadir la escena a cualquier lista."],
  privacyTitle: ["Deine Fotos", "Your photos", "Tus fotos"],
  privacyHint: ["Die Fotos bleiben auf deinem Immich-Server. Auf dem Rahmen liegen nur die ausgeschnittenen Porträts (je etwa 60 KB) und die Liste der Fotos mit Gesichtern. Entfernst du eine Person, löscht Growing Up beides.",
    "The photos stay on your Immich server. The frame keeps only the cut-out portraits (about 60 KB each) and the list of photos with faces. Remove a person and Growing Up deletes both.",
    "Las fotos se quedan en tu servidor Immich. En el marco solo están los retratos recortados (unos 60 KB cada uno) y la lista de fotos con caras. Si quitas a una persona, Growing Up borra ambas cosas."],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin is not answering.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status}).", "Error (HTTP {status}).", "Error (HTTP {status})."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or wishes?", "¿Problemas, preguntas o deseos?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre un issue en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", ", with plugin name and version.", ", con el nombre y la versión del plugin."],
  months: ["{n} Mon.", "{n} mo", "{n} m"],
  years: ["{n} J.", "{n} y", "{n} a"]
};

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "en";
  if (chosen === lang && document.documentElement.dataset.applied === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  document.documentElement.dataset.applied = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  if (current) render(current);
}

const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", node = el("statusNote")) {
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(iso) {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  const sameDay = date.toDateString() === new Date().toDateString();
  const time = t("oclock", { time: date.toLocaleTimeString(LOCALES[lang], { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(LOCALES[lang], { day: "2-digit", month: "2-digit" })} ${time}`;
}

function shortAge(age, date) {
  if (!age) return date.slice(0, 4);
  return age.months < 24 ? t("months", { n: age.months }) : t("years", { n: Math.floor(age.months / 12) });
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes, quiet = false) {
  try {
    await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    if (!quiet) setStatus(t("saved"), "ok");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

// ---- people ------------------------------------------------------------------

async function loadPeople() {
  if (!current || !current.settings.ServerUrl || !current.key.set) {
    people = [];
    peopleError = t("connectFirst");
    renderPeopleList();
    return;
  }
  try {
    people = (await api("./api/people")).people || [];
    peopleError = people.length ? "" : t("noPeople");
  } catch (error) {
    people = [];
    peopleError = error.message;
  }
  renderPeopleList();
}

function renderPeopleList() {
  const box = el("peopleList");
  const chosen = new Set(current ? current.settings.People : []);
  const query = el("peopleFilter").value.trim().toLowerCase();
  const rows = people.filter((p) => !chosen.has(p.id) && (!query || p.name.toLowerCase().includes(query))).slice(0, 80);
  box.innerHTML = rows.map((p) => `<button type="button" class="person-chip" data-add="${p.id}">
      <img src="./api/face/${p.id}" alt="" loading="lazy"><span>${esc(p.name)}${p.birthDate ? ` <small>${esc(p.birthDate.slice(0, 4))}</small>` : ""}</span></button>`).join("");
  const note = peopleError || (people.length && !rows.length && !query ? t("allChosen") : "");
  setStatus(note, peopleError ? "bad" : "", el("peopleNote"));
}

function renderChosen(state) {
  const box = el("chosen");
  const ids = state.settings.People;
  const known = new Map(state.people.map((p) => [p.id, p]));
  const html = ids.map((id, index) => {
    const p = known.get(id) || { id, frames: [] };
    const name = p.name || (people.find((x) => x.id === id) || {}).name || "…";
    const stats = p.photos ? t("stats", { photos: p.photos, faces: p.withFace, frames: p.frames.length }) : t("waiting");
    const strip = p.frames.map((f) => `<figure data-person="${id}" data-asset="${f.id}" class="${f.small ? "small" : ""}" title="${esc(f.date)}${f.small ? " · " + esc(t("smallFace")) : ""}">
        <img src="./${f.src}" alt="" loading="lazy"><figcaption>${esc(shortAge(f.age, f.date))}</figcaption></figure>`).join("");
    const note = p.error ? `<p class="note bad">${esc(p.error)}</p>` : p.busy ? `<p class="note">${esc(p.busy)}</p>` : "";
    return `<div class="person" data-id="${id}">
      <div class="top">
        <img class="face" src="./api/face/${id}" alt="">
        <div class="who"><b>${esc(name)}</b><div class="meta">${esc(stats)}</div></div>
        <label class="bday"><span>${esc(t("birthday"))}${p.immichBirthDate && p.birthDate === p.immichBirthDate ? " (" + esc(t("fromImmich")) + ")" : ""}</span>
          <input type="date" data-bday="${id}" value="${esc(p.birthDate || "")}"></label>
        <div class="actions">
          <button type="button" data-show="${id}">${esc(t("showPerson"))}</button>
          ${index > 0 ? `<button type="button" class="secondary" data-up="${id}">${esc(t("up"))}</button>` : ""}
          ${p.excluded ? `<button type="button" class="secondary" data-restore="${id}">${esc(t("restore", { n: p.excluded }))}</button>` : ""}
          <button type="button" class="secondary" data-remove="${id}">${esc(t("remove"))}</button>
        </div>
      </div>
      ${note}
      ${strip ? `<div class="strip">${strip}</div>` : ""}
    </div>`;
  }).join("");
  if (box.dataset.html !== html) {
    const scroll = [...box.querySelectorAll(".strip")].map((s) => s.scrollLeft);
    box.innerHTML = html;
    box.dataset.html = html;
    box.querySelectorAll(".strip").forEach((s, i) => { s.scrollLeft = scroll[i] || 0; });
  }
}

// ---- state ---------------------------------------------------------------------

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  el("factStatus").textContent = state.status || "—";
  el("factScreen").textContent = state.takeover.active
    ? `${t("showing")}${state.takeover.until ? t("until", { time: clock(state.takeover.until) }) : ""}`
    : t("playlistRuns");
  el("factNext").textContent = s.AutoMode === "off" ? t("off") : state.next ? clock(state.next) : (state.autoNote || "—");
  el("factVersion").textContent = state.version;
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Growing Up ${state.version}] `);
  el("pillowNote").hidden = state.pillow;

  const notes = [state.scene.note, state.takeover.note, state.lastError].filter(Boolean);
  if (!editing && notes.length) setStatus(notes.join(" "), state.lastError ? "bad" : "");
  const permission = el("permissionNote");
  permission.textContent = state.permission || "";
  permission.hidden = !state.permission;

  if (!editing) {
    for (const name of NUMBER_FIELDS) if (document.activeElement !== el(name)) el(name).value = s[name];
    for (const name of SELECT_FIELDS) el(name).value = s[name];
    el("MakePlaylist").value = String(Boolean(s.MakePlaylist));
    el("Language").value = lang;
    for (const box of el("viewList").querySelectorAll("input")) box.checked = s.Views.includes(box.value);
    if (document.activeElement !== el("ServerUrl")) el("ServerUrl").value = s.ServerUrl || "";
  }
  el("ApiKey").placeholder = state.key.set ? t("keySaved", { hint: state.key.hint }) : "";
  if (state.adoptedFrom && !el("immichNote").textContent) setStatus(t("adopted", { name: state.adoptedFrom }), "", el("immichNote"));
  if (!editing) renderChosen(state);
  el("playlistNote").textContent = state.ownerPlaylist || "";
  const names = state.birthdays.map((id) => (state.people.find((p) => p.id === id) || {}).name).filter(Boolean);
  el("birthdayNote").textContent = names.length ? t("birthdayToday", { names: names.join(", ") }) : "";

  // How long one round of the scene takes.
  let total = 0;
  for (const p of state.people) {
    if (!p.frames.length) continue;
    if (s.Views.includes("film")) total += p.frames.length * (s.HoldSeconds + s.FadeSeconds) + 5;
    if (s.Views.includes("grid")) total += s.ViewSeconds + 1;
    if (s.Views.includes("thennow")) total += s.ViewSeconds + 1;
  }
  if (s.Views.includes("sameage") && state.people.filter((p) => p.birthDate && p.frames.length).length > 1) total += s.ViewSeconds + 1;
  el("durationHint").textContent = total ? t("duration", { sec: Math.round(total) }) : "";
}

async function refresh() {
  try {
    const hadKey = current && current.key.set && current.settings.ServerUrl;
    render(await api("./api/state"));
    if (!hadKey && current.key.set && current.settings.ServerUrl) loadPeople();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

// ---- events ----------------------------------------------------------------------

for (const name of NUMBER_FIELDS) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
  input.addEventListener("change", () => save({ [name]: Number(input.value) }));
}
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of ["ServerUrl", "ApiKey"]) {
  el(name).addEventListener("focus", () => { editing = true; });
  el(name).addEventListener("blur", () => { editing = false; });
}
el("saveImmich").addEventListener("click", async () => {
  await save({ ServerUrl: el("ServerUrl").value.trim(), ApiKey: el("ApiKey").value.trim() }, true);
  el("ApiKey").value = "";
  await testImmich();
});
async function testImmich() {
  setStatus("…", "busy", el("immichNote"));
  try {
    const result = await api("./api/test", { method: "POST" });
    setStatus(result.message, result.ok ? "ok" : "bad", el("immichNote"));
    if (result.ok) loadPeople();
  } catch (error) {
    setStatus(error.message, "bad", el("immichNote"));
  }
}
el("testImmich").addEventListener("click", testImmich);

el("peopleFilter").addEventListener("input", renderPeopleList);
el("peopleList").addEventListener("click", (e) => {
  const button = e.target.closest("[data-add]");
  if (!button || !current) return;
  const ids = current.settings.People;
  if (ids.length >= 12) { setStatus(t("maxPeople"), "bad", el("peopleNote")); return; }
  save({ People: [...ids, button.dataset.add] }).then(renderPeopleList);
});

el("chosen").addEventListener("click", async (e) => {
  if (!current) return;
  const ids = current.settings.People;
  const remove = e.target.closest("[data-remove]");
  if (remove) {
    await save({ People: ids.filter((id) => id !== remove.dataset.remove) });
    renderPeopleList();
    return;
  }
  const up = e.target.closest("[data-up]");
  if (up) {
    const i = ids.indexOf(up.dataset.up);
    const next = ids.slice();
    [next[i - 1], next[i]] = [next[i], next[i - 1]];
    await save({ People: next });
    return;
  }
  const show = e.target.closest("[data-show]");
  if (show) {
    try {
      const result = await api("./api/show", { method: "POST", body: JSON.stringify({ person: show.dataset.show }) });
      setStatus(result.message || "", "busy");
      setTimeout(refresh, 2500);
    } catch (error) { setStatus(error.message, "bad"); }
    return;
  }
  const restore = e.target.closest("[data-restore]");
  if (restore) {
    await api("./api/exclude", { method: "POST", body: JSON.stringify({ person: restore.dataset.restore, undo: true }) });
    await refresh();
    return;
  }
  const figure = e.target.closest("figure[data-asset]");
  if (figure && confirm(t("excludeAsk"))) {
    figure.style.opacity = ".3";
    await api("./api/exclude", { method: "POST", body: JSON.stringify({ person: figure.dataset.person, asset: figure.dataset.asset }) });
    setTimeout(refresh, 1500);
  }
});
el("chosen").addEventListener("focusin", (e) => { if (e.target.matches("[data-bday]")) editing = true; });
el("chosen").addEventListener("focusout", (e) => { if (e.target.matches("[data-bday]")) editing = false; });
el("chosen").addEventListener("change", (e) => {
  const input = e.target.closest("[data-bday]");
  if (!input || !current) return;
  const birthdays = { ...current.settings.Birthdays };
  const person = current.people.find((p) => p.id === input.dataset.bday) || {};
  if (input.value && input.value !== person.immichBirthDate) birthdays[input.dataset.bday] = input.value;
  else delete birthdays[input.dataset.bday];
  editing = false;
  save({ Birthdays: birthdays });
});

el("viewList").addEventListener("change", () => {
  const chosen = [...el("viewList").querySelectorAll("input:checked")].map((box) => box.value);
  save({ Views: chosen });
});
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));
el("Language").addEventListener("change", (e) => {
  // Read the choice first: applyLanguage() re-renders and resets the select.
  const chosen = e.target.value;
  if (current) current.settings.Language = chosen;
  applyLanguage(chosen);
  save({ Language: chosen });
});

for (const [id, path] of [["showButton", "show"], ["cancelButton", "cancel"], ["refreshButton", "refresh"]]) {
  el(id).addEventListener("click", async () => {
    try {
      const result = await api(`./api/${path}`, { method: "POST" });
      setStatus(result.message || "", "busy");
      setTimeout(refresh, 2500);
    } catch (error) {
      setStatus(error.message, "bad");
    }
  });
}

applyLanguage("en");
refresh().then(loadPeople);
setInterval(refresh, 5000);
