"""Bahnrechnung für Satellite Swarm, ohne fremde Pakete.

CelesTrak liefert für jeden Satelliten mittlere Bahnelemente (OMM, dieselben
Zahlen wie in einem TLE). Daraus rechnen wir mit Kepler + den säkularen
J2-Störungen (Knotenwanderung, Apsidendrehung) + dem Widerstandsterm aus
MEAN_MOTION_DOT. Das ist leichter als SGP4 und für die Anzeige und die
Überflugzeiten genau genug (gegen SGP4 geprüft, siehe test/check_orbit.py:
ISS etwa 10 km nach 12 h, also ein, zwei Sekunden bei einem Überflug).

Die Szene rechnet mit genau denselben Zahlen (prepare() liefert sie), nur auf
der Grafikkarte.

Einheiten: Erdradien, Minuten, Radiant. Zeiten als Unix-Sekunden.
"""

import csv
import io
import math
import re
from datetime import datetime, timezone

XKE = 0.0743669161331734132     # sqrt(GM) in Erdradien^1.5 / min (WGS72 wie SGP4)
J2 = 1.082616e-3
K2 = 0.5 * J2
RE_KM = 6378.135
TWO_PI = 2.0 * math.pi
DEG = math.pi / 180.0
MIN_PER_DAY = 1440.0
F_EARTH = 1 / 298.257223563     # für den Beobachter auf dem Ellipsoid


# --------------------------------------------------------------------------
# Gruppen
# --------------------------------------------------------------------------

GROUPS = ("starlink", "oneweb", "navigation", "earth", "stations", "science", "comms", "other")

_NAV = re.compile(r"^(GPS |NAVSTAR|GALILEO|GSAT0|GLONASS|BEIDOU|QZS|IRNSS|NVS-)|GLONASS")
_WEATHER = re.compile(r"^(NOAA |METOP|METEOSAT|MSG|MTG|GOES |HIMAWARI|FENGYUN|FY-|DMSP|SUOMI|NPP|JPSS|ELEKTRO|"
                      r"METEOR|INSAT-3D|GEO-KOMPSAT|GK-2|AQUA|TERRA|SENTINEL|LANDSAT|CALIPSO|GCOM|GPM|CLOUDSAT|"
                      r"JASON|SWOT|OCEANSAT|SMAP|ICESAT|GRACE|CRYOSAT|EARTHCARE|PACE|TROPICS|ARKTIKA|NISAR|WORLDVIEW|PLEIADES|"
                      r"SPOT |RESURS|KOMPSAT|CARTOSAT|GAOFEN|FLOCK|SKYSAT|ICEYE|CAPELLA|RADARSAT|TERRASAR|TANDEM|"
                      r"COSMO-SKYMED|SAOCOM|PROBA|SMOS|AEOLUS|KANOPUS|ZIYUAN|HAIYANG|CBERS|ALOS|GOSAT|SENTINEL)")
_STATION = re.compile(r"^(ISS \(|ISS$|CSS \(|TIANHE|WENTIAN|MENGTIAN|TIANGONG)")
_SCIENCE = re.compile(r"^(HST$|HUBBLE|SWIFT|FERMI|CHANDRA|XMM|NUSTAR|TESS|NEOWISE|INTEGRAL|AGILE|NICER|"
                      r"XRISM|IXPE|EINSTEIN PROBE|SVOM|GAIA|CHEOPS|SPEKTR|ASTROSAT|HXMT|DAMPE|CXO|MMS |THEMIS|LAGEOS|LARES|AJISAI)")
_COMMS = re.compile(r"^(IRIDIUM|ORBCOMM|GLOBALSTAR|INTELSAT|SES|ASTRA|EUTELSAT|HOTBIRD|TDRS|INMARSAT|VIASAT|"
                    r"ECHOSTAR|DIRECTV|TELSTAR|ARABSAT|NILESAT|TURKSAT|YAHSAT|AMAZONAS|HISPASAT|KUIPER|"
                    r"O3B|SIRIUS|XM-|GALAXY|CHINASAT|APSTAR|ASIASAT|JCSAT|SKYNET|WGS|MUOS|AEHF|LUCH|EXPRESS|"
                    r"YAMAL|GONETS|QIANFAN|SPACEBEE|LYNK|AST SPACEMOBILE|BLUEBIRD|SATELIOT|E-SPACE)")


def classify(name, mean_motion):
    name = (name or "").upper().strip()
    if name.startswith("STARLINK"):
        return "starlink"
    if name.startswith("ONEWEB"):
        return "oneweb"
    if _STATION.match(name):
        return "stations"
    if _NAV.search(name):
        return "navigation"
    if _WEATHER.match(name):
        return "earth"
    if _SCIENCE.match(name):
        return "science"
    if _COMMS.match(name) or 0.9 < mean_motion < 1.1:
        return "comms"          # dazu fast alles im geostationären Ring
    return "other"


# Bekannte Satelliten, die angesagt werden können (NORAD-Nummer -> Schlüssel)
NOTABLE = {25544: "iss", 48274: "css", 20580: "hst"}
NOTABLE_NAMES = {"iss": "ISS", "css": "Tiangong", "hst": "Hubble"}


# --------------------------------------------------------------------------
# Zeit, Sonne, Erddrehung
# --------------------------------------------------------------------------

def parse_epoch(text):
    text = str(text).strip().replace("Z", "")
    if "." in text:
        head, frac = text.split(".", 1)
        frac = (frac + "000000")[:6]
        text = f"{head}.{frac}"
        fmt = "%Y-%m-%dT%H:%M:%S.%f"
    else:
        fmt = "%Y-%m-%dT%H:%M:%S"
    return datetime.strptime(text, fmt).replace(tzinfo=timezone.utc).timestamp()


def julian(unix):
    return unix / 86400.0 + 2440587.5


def gmst(unix):
    """Sternzeit Greenwich in Radiant (IAU 1982, wie SGP4)."""
    tut1 = (julian(unix) - 2451545.0) / 36525.0
    temp = (-6.2e-6 * tut1 ** 3 + 0.093104 * tut1 ** 2 + (876600.0 * 3600 + 8640184.812866) * tut1
            + 67310.54841)
    return (temp * DEG / 240.0) % TWO_PI


def sun_direction(unix):
    """Einheitsvektor zur Sonne im ECI-System (genau auf etwa 0,01 Grad)."""
    n = julian(unix) - 2451545.0
    L = (280.460 + 0.9856474 * n) % 360.0
    g = ((357.528 + 0.9856003 * n) % 360.0) * DEG
    lam = (L + 1.915 * math.sin(g) + 0.020 * math.sin(2 * g)) * DEG
    eps = (23.439 - 0.0000004 * n) * DEG
    return (math.cos(lam), math.cos(eps) * math.sin(lam), math.sin(eps) * math.sin(lam))


def observer_eci(lat, lon, height_km, unix):
    """Ort des Beobachters im ECI-System (Erdradien)."""
    phi, lam = lat * DEG, lon * DEG
    e2 = F_EARTH * (2 - F_EARTH)
    c = 1 / math.sqrt(1 - e2 * math.sin(phi) ** 2)
    s = (1 - e2) * c
    h = height_km / RE_KM
    theta = gmst(unix) + lam
    rc = (c + h) * math.cos(phi)
    return (rc * math.cos(theta), rc * math.sin(theta), (s + h) * math.sin(phi)), theta


# --------------------------------------------------------------------------
# Bahnelemente
# --------------------------------------------------------------------------

class Elements:
    __slots__ = ("norad", "name", "cospar", "group", "epoch", "n", "a", "e", "i", "raan", "argp", "M",
                 "raan_dot", "argp_dot", "m_dot", "drag")

    def __init__(self, row):
        self.norad = int(float(row["NORAD_CAT_ID"]))
        self.name = (row.get("OBJECT_NAME") or "").strip()
        self.cospar = (row.get("OBJECT_ID") or "").strip()
        self.epoch = parse_epoch(row["EPOCH"])
        no_kozai = float(row["MEAN_MOTION"]) * TWO_PI / MIN_PER_DAY
        self.e = min(0.99, max(0.0, float(row["ECCENTRICITY"])))
        self.i = float(row["INCLINATION"]) * DEG
        self.raan = float(row["RA_OF_ASC_NODE"]) * DEG
        self.argp = float(row["ARG_OF_PERICENTER"]) * DEG
        self.M = float(row["MEAN_ANOMALY"]) * DEG
        ndot = float(row.get("MEAN_MOTION_DOT") or 0.0)          # n'/2 in Umläufen/Tag²
        self.group = classify(self.name, float(row["MEAN_MOTION"]))
        # Kozai -> Brouwer wie in SGP4 (sgp4init)
        cosi = math.cos(self.i)
        x3 = 3 * cosi * cosi - 1
        beta2 = 1 - self.e * self.e
        beta = math.sqrt(beta2)
        a1 = (XKE / no_kozai) ** (2.0 / 3.0)
        d1 = 0.75 * J2 * x3 / (beta * beta2 * a1 * a1)
        a0 = a1 * (1 - d1 / 3 - d1 * d1 - 134.0 / 81.0 * d1 ** 3)
        d0 = 0.75 * J2 * x3 / (beta * beta2 * a0 * a0)
        self.n = no_kozai / (1 + d0)
        self.a = (XKE / self.n) ** (2.0 / 3.0)
        p = self.a * beta2
        f = J2 / (p * p)
        self.raan_dot = -1.5 * f * self.n * cosi
        self.argp_dot = 0.75 * f * self.n * (5 * cosi * cosi - 1)
        self.m_dot = self.n * (1 + 0.75 * f * beta * x3)
        self.drag = min(max(ndot, -1e-3), 1e-2) * TWO_PI / (MIN_PER_DAY * MIN_PER_DAY)   # rad/min²

    def at(self, unix):
        """Elemente zur Zeit unix: (raan, argp, M) – alles andere bleibt."""
        dt = (unix - self.epoch) / 60.0
        return ((self.raan + self.raan_dot * dt) % TWO_PI,
                (self.argp + self.argp_dot * dt) % TWO_PI,
                (self.M + self.m_dot * dt + self.drag * dt * dt) % TWO_PI)

    def position(self, unix):
        """ECI-Ort in Erdradien."""
        raan, argp, M = self.at(unix)
        return kepler_position(self.a, self.e, self.i, raan, argp, M)


def kepler_position(a, e, i, raan, argp, M):
    E = M + e * math.sin(M) if e < 0.8 else math.pi
    for _ in range(12):
        f = E - e * math.sin(E) - M
        d = f / (1 - e * math.cos(E))
        E -= d
        if abs(d) < 1e-10:
            break
    cosE, sinE = math.cos(E), math.sin(E)
    x = a * (cosE - e)
    y = a * math.sqrt(1 - e * e) * sinE
    co, so = math.cos(raan), math.sin(raan)
    cw, sw = math.cos(argp), math.sin(argp)
    ci, si = math.cos(i), math.sin(i)
    px, py = x * cw - y * sw, x * sw + y * cw         # in der Bahnebene, ab Knoten
    return (px * co - py * ci * so, px * so + py * ci * co, py * si)


def parse_csv(text):
    """CelesTrak GP-Daten als CSV -> Liste von Elements (kaputte Zeilen fallen weg)."""
    out = []
    for row in csv.DictReader(io.StringIO(text)):
        try:
            el = Elements(row)
        except (KeyError, TypeError, ValueError, ZeroDivisionError):
            continue
        if el.n <= 0 or el.a < 1.0:
            continue
        out.append(el)
    return out


def prepare(sats, t0):
    """Zahlen für die Szene: alle Elemente auf die gemeinsame Zeit t0 gebracht.

    Spalten statt Objekte, damit das JSON klein bleibt. Die Szene rechnet
    raan/argp/M ab t0 selbst weiter (Raten pro Minute)."""
    cols = {k: [] for k in ("g", "a", "e", "i", "O", "w", "M", "n", "Od", "wd", "dr")}
    for s in sats:
        raan, argp, M = s.at(t0)
        cols["g"].append(GROUPS.index(s.group))
        cols["a"].append(round(s.a, 6))
        cols["e"].append(round(s.e, 6))
        cols["i"].append(round(s.i, 5))
        cols["O"].append(round(raan, 6))
        cols["w"].append(round(argp, 5))
        cols["M"].append(round(M, 6))
        cols["n"].append(round(s.m_dot, 9))
        cols["Od"].append(float(f"{s.raan_dot:.4g}"))
        cols["wd"].append(float(f"{s.argp_dot:.4g}"))
        # Widerstand nach t0 als quadratischer Term weiter; dazu die schon
        # aufgelaufene Änderung der Winkelgeschwindigkeit (2*drag*dt0)
        dt0 = (t0 - s.epoch) / 60.0
        cols["n"][-1] = round(s.m_dot + 2 * s.drag * dt0, 9)
        cols["dr"].append(float(f"{s.drag:.3g}"))
    return cols


# --------------------------------------------------------------------------
# Überflüge
# --------------------------------------------------------------------------

def look_angles(sat_eci, obs_eci, theta, lat):
    """Azimut, Höhe (Grad) und Entfernung (km) vom Beobachter aus."""
    rx, ry, rz = (sat_eci[0] - obs_eci[0], sat_eci[1] - obs_eci[1], sat_eci[2] - obs_eci[2])
    sl, cl = math.sin(lat * DEG), math.cos(lat * DEG)
    st, ct = math.sin(theta), math.cos(theta)
    south = sl * ct * rx + sl * st * ry - cl * rz
    east = -st * rx + ct * ry
    up = cl * ct * rx + cl * st * ry + sl * rz
    rng = math.sqrt(rx * rx + ry * ry + rz * rz)
    el = math.asin(max(-1.0, min(1.0, up / rng))) / DEG
    az = (math.atan2(east, -south) / DEG) % 360.0
    return az, el, rng * RE_KM


def sunlit(sat_eci, sun):
    """Liegt der Satellit im Sonnenlicht? (Zylinderschatten der Erde)"""
    d = sat_eci[0] * sun[0] + sat_eci[1] * sun[1] + sat_eci[2] * sun[2]
    if d > 0:
        return True
    r2 = sat_eci[0] ** 2 + sat_eci[1] ** 2 + sat_eci[2] ** 2
    return r2 - d * d > 1.0


def sun_elevation(lat, lon, unix):
    obs, theta = observer_eci(lat, lon, 0, unix)
    sun = sun_direction(unix)
    far = (sun[0] * 23500, sun[1] * 23500, sun[2] * 23500)      # 1 AE in Erdradien
    return look_angles(far, obs, theta, lat)[1]


def find_passes(sat, lat, lon, height_km, start, hours, min_el=10.0, step=20.0):
    """Alle Überflüge mit größter Höhe >= min_el in [start, start+hours]."""
    def el_at(t):
        obs, theta = observer_eci(lat, lon, height_km, t)
        return look_angles(sat.position(t), obs, theta, lat)

    def edge(t_lo, t_hi, rising):
        for _ in range(14):     # bis auf ~1 s genau
            mid = (t_lo + t_hi) / 2
            above = el_at(mid)[1] > 0
            if above == rising:
                t_hi = mid
            else:
                t_lo = mid
        return t_hi if rising else t_lo

    # LEO braucht feine Schritte, MEO/GEO nicht
    if sat.n < 0.03:
        step = max(step, 120.0)
    passes = []
    end = start + hours * 3600
    t = start
    prev = el_at(t)[1]
    rise = start if prev > 0 else None
    while t < end:
        t2 = t + step
        cur = el_at(t2)[1]
        if prev <= 0 < cur:
            rise = edge(t, t2, True)
        elif prev > 0 >= cur and rise is not None:
            setting = edge(t, t2, False)
            p = describe_pass(sat, lat, lon, height_km, rise, setting, el_at)
            if p and p["maxEl"] >= min_el:
                passes.append(p)
            rise = None
        prev, t = cur, t2
    if rise is not None:
        p = describe_pass(sat, lat, lon, height_km, rise, end, el_at)
        if p and p["maxEl"] >= min_el:
            passes.append(p)
    return passes


def describe_pass(sat, lat, lon, height_km, rise, setting, el_at):
    if setting - rise < 20:
        return None
    # höchster Punkt: grob abtasten, dann golden section
    n = max(8, int((setting - rise) / 15))
    samples = [(rise + (setting - rise) * k / n) for k in range(n + 1)]
    best = max(samples, key=lambda t: el_at(t)[1])
    lo, hi = max(rise, best - (setting - rise) / n), min(setting, best + (setting - rise) / n)
    for _ in range(20):
        m1, m2 = lo + (hi - lo) * 0.382, lo + (hi - lo) * 0.618
        if el_at(m1)[1] < el_at(m2)[1]:
            lo = m1
        else:
            hi = m2
    tmax = (lo + hi) / 2
    az0, _, _ = el_at(rise)
    azm, elm, rngm = el_at(tmax)
    az1, _, _ = el_at(setting)
    # sichtbar: Satellit im Sonnenlicht, während es beim Beobachter dunkel ist
    visible_from = visible_to = None
    t = rise
    while t <= setting:
        pos = sat.position(t)
        if sun_elevation(lat, lon, t) < -6 and sunlit(pos, sun_direction(t)) and el_at(t)[1] >= 10:
            visible_from = visible_from or t
            visible_to = t
        t += 10
    return {"start": round(rise), "end": round(setting), "max": round(tmax), "maxEl": round(elm, 1),
            "azStart": round(az0), "azMax": round(azm), "azEnd": round(az1), "rangeKm": round(rngm),
            "visible": visible_from is not None,
            "visibleFrom": round(visible_from) if visible_from else None,
            "visibleTo": round(visible_to) if visible_to else None}


def compass(az, lang="de"):
    names = {
        "de": ("Norden", "Nordosten", "Osten", "Südosten", "Süden", "Südwesten", "Westen", "Nordwesten"),
        "en": ("north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"),
        "es": ("norte", "noreste", "este", "sureste", "sur", "suroeste", "oeste", "noroeste"),
    }[lang if lang in ("de", "en", "es") else "en"]
    return names[int(((az % 360) + 22.5) // 45) % 8]


# --------------------------------------------------------------------------
# Starlink-Züge
# --------------------------------------------------------------------------

_COSPAR = re.compile(r"^(\d{4})-(\d{3})")


def _arc_span(angles):
    """Kleinster Bogen (Radiant), der alle Winkel enthält."""
    a = sorted(x % TWO_PI for x in angles)
    if len(a) < 2:
        return 0.0
    gaps = [a[k + 1] - a[k] for k in range(len(a) - 1)] + [a[0] + TWO_PI - a[-1]]
    return TWO_PI - max(gaps)


def starlink_trains(sats, now, max_alt_km=600, max_raan_deg=3.0, max_arc_deg=60.0):
    """Frisch gestartete Starlink-Gruppen, die noch als Kette fliegen.

    Kette = mindestens 8 Satelliten aus einem Start (COSPAR-Startnummer) in
    derselben Bahnebene, dicht hintereinander. Je Kette ein Vertreter aus der
    Mitte, für die Überflüge."""
    launches = {}
    for s in sats:
        if s.group != "starlink":
            continue
        m = _COSPAR.match(s.cospar)
        if not m or (s.a - 1) * RE_KM > max_alt_km or now - s.epoch > 5 * 86400:
            continue
        launches.setdefault(m.group(0), []).append(s)
    trains = []
    for key, members in launches.items():
        if len(members) < 8:
            continue
        states = [(s, s.at(now)) for s in members]
        if _arc_span([st[1][0] for st in states]) > max_raan_deg * DEG:
            continue
        u = [(st[1][1] + st[1][2]) % TWO_PI for st in states]
        if _arc_span(u) > max_arc_deg * DEG:
            continue
        # Vertreter: der Satellit am nächsten an der Mitte der Kette
        cx, cy = sum(math.cos(x) for x in u), sum(math.sin(x) for x in u)
        mid = math.atan2(cy, cx)
        rep = min(zip(u, members), key=lambda p: abs(math.remainder(p[0] - mid, TWO_PI)))[1]
        trains.append({"key": key, "count": len(members), "rep": rep,
                       "alt": round(sum((s.a - 1) * RE_KM for s in members) / len(members))})
    trains.sort(key=lambda t: t["key"], reverse=True)
    return trains[:4]
