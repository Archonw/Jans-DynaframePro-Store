"""Der Datenstrom der Wikimedia EventStreams (recentchange) für Wikipedia Breathes.

https://stream.wikimedia.org/v2/stream/recentchange liefert jede Änderung in
allen Wikimedia-Wikis als Server-Sent Events, je nach Tageszeit 30 bis 100 pro
Sekunde (das meiste davon Wikidata und Commons). Behalten werden nur
Änderungen an Wikipedias. Vor dem JSON-Parsen fliegt alles raus, was nicht
"wikipedia.org" enthält: So bleibt der Pi entspannt.

Der Strom läuft nur, solange jemand zusieht (Szene oder Plugin-Seite fragen
regelmäßig nach). Sonst liefe er rund um die Uhr mit mehreren GB pro Tag.

Ein Ereignis für die Szene ist ein Tupel
    (seq, zeit, sprache, bytes, flags, titel)
flags: 1 Bot, 2 neue Seite, 4 Seite gelöscht, 8 Artikel (Namensraum 0), 16 kleine Änderung.
"""

import json
import os
import threading
import time
from collections import Counter, deque

import requests

URL = os.environ.get("WB_STREAM_URL") or "https://stream.wikimedia.org/v2/stream/recentchange"
F_BOT, F_NEW, F_DELETED, F_ARTICLE, F_MINOR = 1, 2, 4, 8, 16
KEEP_EVENTS = 4000           # Puffer für die Szene (bei 40/s gut eineinhalb Minuten)
RATE_SECONDS = 300           # Atemkurve: Bearbeitungen je Sekunde der letzten 5 Minuten
LANG_BUCKET = 10             # Sprachen-Zählung in 10-Sekunden-Fächern
LANG_BUCKETS = 30            # = 5 Minuten
RESUME_WITHIN = 60           # Last-Event-ID nur nach kurzer Pause nutzen, sonst kommt ein Rückstau


def lang_of(server_name):
    """"de.wikipedia.org" -> "de"; alles andere (Wikidata, Commons, Wiktionary …) -> None."""
    if not server_name or not server_name.endswith(".wikipedia.org"):
        return None
    code = server_name[:-14]
    if not code or "." in code or code in ("test", "test2"):
        return None
    return code


def parse(raw):
    """Ein recentchange-Ereignis (JSON-Bytes) -> (sprache, bytes, flags, titel) oder None."""
    try:
        ev = json.loads(raw)
    except ValueError:
        return None
    if not isinstance(ev, dict):
        return None
    lang = lang_of(ev.get("server_name") or "")
    if not lang:
        return None
    kind = ev.get("type")
    flags = 0
    if ev.get("bot"):
        flags |= F_BOT
    if ev.get("namespace") == 0:
        flags |= F_ARTICLE
    if ev.get("minor"):
        flags |= F_MINOR
    length = ev.get("length") or {}
    old = length.get("old") or 0
    new = length.get("new") or 0
    if kind == "edit":
        delta = int(new) - int(old)
    elif kind == "new":
        delta = int(new)
        flags |= F_NEW
    elif kind == "log" and ev.get("log_type") == "delete" and ev.get("log_action") in ("delete", "delete_redir"):
        delta = 0
        flags |= F_DELETED
    else:
        return None                     # categorize, Logins, Sperren … ohne Text
    title = ev.get("title") or ""
    if not isinstance(title, str):
        title = ""
    return lang, delta, flags, title[:120]


class Stream:
    def __init__(self, user_agent, log):
        self.user_agent = user_agent
        self.log = log
        self.lock = threading.Lock()
        self.events = deque(maxlen=KEEP_EVENTS)
        self.seq = 0
        self.state = "paused"           # paused | connecting | live | error
        self.error = ""
        self.connected_at = 0.0
        self.counting_since = 0.0        # seit wann die Zahlen zählen (über kurze Neuverbindungen hinweg)
        self.last_event_at = 0.0
        self.new_pages = 0
        self.deleted_pages = 0
        self.total = 0
        self._last_id = None
        self._closed_at = 0.0
        self._rate = [0] * RATE_SECONDS     # Bearbeitungen je Sekunde
        self._bots = [0] * RATE_SECONDS
        self._added = [0] * RATE_SECONDS
        self._removed = [0] * RATE_SECONDS
        self._rate_sec = int(time.time())
        self._langs = [Counter() for _ in range(LANG_BUCKETS)]
        self._lang_slot = int(time.time()) // LANG_BUCKET
        self._wanted_until = 0.0
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._response = None
        self._thread = threading.Thread(target=self._run, name="WikipediaBreathes-stream", daemon=True)

    # ------------------------------------------------------------ Steuerung

    def start(self):
        self._thread.start()

    def stop(self):
        self._stop.set()
        self._wake.set()
        self._close()

    def want(self, seconds):
        """Jemand sieht zu: Strom für die nächsten <seconds> Sekunden offen halten."""
        until = time.time() + seconds
        if until > self._wanted_until:
            self._wanted_until = until
        if self.state == "paused":
            self._wake.set()

    def wanted(self):
        return time.time() < self._wanted_until

    def _close(self):
        response = self._response
        if response is not None:
            try:
                response.close()
            except Exception:
                pass

    # ------------------------------------------------------------ Zählen

    def _roll(self, now_sec):
        """Sekunden- und Sprachfächer bis now_sec vorrücken (unter self.lock)."""
        gap = now_sec - self._rate_sec
        if gap > 0:
            for k in range(1, min(gap, RATE_SECONDS) + 1):
                i = (self._rate_sec + k) % RATE_SECONDS
                self._rate[i] = self._bots[i] = self._added[i] = self._removed[i] = 0
            self._rate_sec = now_sec
        slot = now_sec // LANG_BUCKET
        gap = slot - self._lang_slot
        if gap > 0:
            for k in range(1, min(gap, LANG_BUCKETS) + 1):
                self._langs[(self._lang_slot + k) % LANG_BUCKETS] = Counter()
            self._lang_slot = slot

    def _add(self, lang, delta, flags, title):
        now = time.time()
        sec = int(now)
        with self.lock:
            self._roll(sec)
            i = sec % RATE_SECONDS
            self._rate[i] += 1
            if flags & F_BOT:
                self._bots[i] += 1
            if delta > 0:
                self._added[i] += delta
            elif delta < 0:
                self._removed[i] -= delta
            self._langs[self._lang_slot % LANG_BUCKETS][lang] += 1
            if flags & F_NEW:
                self.new_pages += 1
            if flags & F_DELETED:
                self.deleted_pages += 1
            self.total += 1
            self.seq += 1
            self.events.append((self.seq, now, lang, delta, flags, title))
            self.last_event_at = now

    def _reset_counts(self):
        with self.lock:
            self._rate = [0] * RATE_SECONDS
            self._bots = [0] * RATE_SECONDS
            self._added = [0] * RATE_SECONDS
            self._removed = [0] * RATE_SECONDS
            self._langs = [Counter() for _ in range(LANG_BUCKETS)]
            self.new_pages = self.deleted_pages = self.total = 0
            self.counting_since = 0.0

    # ------------------------------------------------------------ Lesen

    def _run(self):
        backoff = 0
        while not self._stop.is_set():
            if not self.wanted():
                if self.state != "paused":
                    self.state = "paused"
                    self.log("Datenstrom pausiert: niemand sieht zu")
                self._wake.clear()
                self._wake.wait(30)
                continue
            if self.state == "paused" or time.time() - self._closed_at > 600:
                self._reset_counts()        # nach einer Pause frisch zählen
            self.state = "connecting"
            try:
                self._read()
                backoff = 0
            except requests.HTTPError as exc:
                status = exc.response.status_code if exc.response is not None else 0
                self.error = f"HTTP {status}"
                self.state = "error"
                backoff = 60 if status in (429, 503) else min(60, max(5, backoff * 2))
                self.log(f"Datenstrom: HTTP {status}", "warning")
            except (requests.RequestException, OSError, ValueError) as exc:
                if self._stop.is_set():
                    break
                if self.wanted():
                    self.error = short(exc)
                    self.state = "error"
                    backoff = min(60, max(3, backoff * 2))
                    self.log(f"Datenstrom unterbrochen: {self.error}", "warning")
            finally:
                self._response = None
                self._closed_at = time.time()
            if backoff and not self._stop.is_set():
                self._stop.wait(backoff)

    def _read(self):
        headers = {"Accept": "text/event-stream", "User-Agent": self.user_agent}
        if self._last_id and time.time() - self._closed_at < RESUME_WITHIN:
            headers["Last-Event-ID"] = self._last_id
        response = requests.get(URL, headers=headers, stream=True, timeout=(10, 60))
        self._response = response
        response.raise_for_status()
        self.connected_at = time.time()
        if not self.counting_since:
            self.counting_since = self.connected_at
        if self.state != "connecting" or not self._last_id:
            self.log("Datenstrom verbunden")
        self.state = "live"
        self.error = ""
        data = []
        event_id = None
        checked = time.time()
        for line in response.iter_lines(chunk_size=16384):
            if self._stop.is_set():
                return
            if line:
                if line.startswith(b"data:"):
                    data.append(line[5:].lstrip())
                elif line.startswith(b"id:"):
                    event_id = line[3:].strip()
                continue                       # Kommentare (":ok") und "event:" ignorieren
            # Leerzeile: Ereignis fertig
            if data:
                raw = data[0] if len(data) == 1 else b"\n".join(data)
                data = []
                if b"wikipedia.org" in raw:
                    item = parse(raw)
                    if item:
                        self._add(*item)
            if event_id:
                try:
                    self._last_id = event_id.decode("utf-8")
                except UnicodeDecodeError:
                    pass
                event_id = None
            now = time.time()
            if now - checked > 5:
                checked = now
                if not self.wanted():
                    response.close()
                    return

    # ------------------------------------------------------------ Für Szene und Seite

    def since(self, seq, limit, keep=None, max_age=6.0):
        """Ereignisse nach seq, höchstens limit Stück. Sind es mehr, gewinnen die
        großen, neuen Seiten und Löschungen; der Rest wird gleichmäßig ausgedünnt."""
        cutoff = time.time() - max_age
        with self.lock:
            last = self.seq
            rows = [e for e in self.events if e[0] > seq and e[1] >= cutoff] if seq < last else []
        if keep is not None:
            rows = [e for e in rows if keep(e[4])]
        dropped = 0
        if len(rows) > limit:
            def weight(e):
                d = abs(e[3])
                return (2 if e[4] & (F_NEW | F_DELETED) else 0) + (1 if d >= 500 else 0) + min(d, 100000) / 100000
            keep = sorted(range(len(rows)), key=lambda i: weight(rows[i]), reverse=True)[:limit]
            dropped = len(rows) - limit
            rows = [rows[i] for i in sorted(keep)]
        return last, rows, dropped

    def numbers(self):
        now_sec = int(time.time())
        with self.lock:
            self._roll(now_sec)
            order = [(now_sec - k) % RATE_SECONDS for k in range(RATE_SECONDS - 1, -1, -1)]
            rate = [self._rate[i] for i in order]
            bots = [self._bots[i] for i in order]
            added = [self._added[i] for i in order]
            removed = [self._removed[i] for i in order]
            langs = Counter()
            for bucket in self._langs:
                langs.update(bucket)
            new_pages, deleted, total = self.new_pages, self.deleted_pages, self.total
        live_for = time.time() - self.counting_since if self.counting_since and self.state in ("live", "connecting") else 0
        # die laufende Sekunde ist noch unvollständig
        minute = sum(rate[-61:-1])
        span = max(1, min(60, int(live_for)))
        return {
            "rate": rate,
            "perMin": round(minute * 60 / span) if live_for >= 1 else 0,
            "botsMin": round(sum(bots[-61:-1]) * 60 / span) if live_for >= 1 else 0,
            "addedMin": round(sum(added[-61:-1]) * 60 / span) if live_for >= 1 else 0,
            "removedMin": round(sum(removed[-61:-1]) * 60 / span) if live_for >= 1 else 0,
            "langs": langs.most_common(12),
            "langCount": len(langs),
            "newPages": new_pages,
            "deletedPages": deleted,
            "total": total,
            "liveFor": round(live_for),
        }


def short(exc):
    text = str(exc) or exc.__class__.__name__
    if "NameResolution" in text or "getaddrinfo" in text or "Name or service not known" in text:
        return "DNS"
    if "timed out" in text.lower() or "timeout" in text.lower():
        return "Timeout"
    if "Connection refused" in text:
        return "Connection refused"
    return text[:120]
