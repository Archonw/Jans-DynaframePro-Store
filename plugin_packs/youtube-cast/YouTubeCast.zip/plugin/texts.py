"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Aus.": ("Off.", "Apagado."),
    "Bereit: der Rahmen steht im Streamen-Menü der YouTube-App.": (
        "Ready: the frame is listed in the YouTube app's cast menu.",
        "Listo: el marco aparece en el menú de enviar de la app de YouTube."),
    "Das ist kein YouTube-Link zu einem Video.": (
        "That is not a YouTube link to a video.",
        "Eso no es un enlace de YouTube a un vídeo."),
    "Der Bildschirm ist aus; das Video wird nicht gezeigt.": (
        "The screen is off; the video is not shown.",
        "La pantalla está apagada; el vídeo no se muestra."),
    "Der Rahmen hat das Video nicht rechtzeitig angezeigt.": (
        "The frame did not show the video in time.",
        "El marco no ha mostrado el vídeo a tiempo."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.",
        "El marco no ha creado la lista {name}."),
    "Der Rahmen ist nach dem Video nicht zu deiner Playlist zurückgekehrt. Starte sie auf der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix passiert das nicht.": (
        "The frame did not return to your playlist after the video. Start it again on the frame's home page. This does not happen with a saved playlist instead of a Quick Mix.",
        "El marco no ha vuelto a tu lista después del vídeo. Vuelve a iniciarla en la página de inicio del marco. Con una lista guardada en lugar de un Quick Mix no pasa."),
    "Die Szene YouTube Cast ist auf der Plugins-Seite ausgeschaltet.": (
        "The YouTube Cast scene is switched off on the Plugins page.",
        "La escena YouTube Cast está desactivada en la página de plugins."),
    "Die Szene YouTube Cast ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The YouTube Cast scene is not installed on this frame. Install the package again.",
        "La escena YouTube Cast no está instalada en este marco. Vuelve a instalar el paquete."),
    "Die Szene YouTube Cast wurde nicht gefunden.": (
        "The YouTube Cast scene was not found.",
        "No se ha encontrado la escena YouTube Cast."),
    "Die Takeover-Playlist ist noch nicht angelegt.": (
        "The takeover playlist has not been created yet.",
        "La lista de takeover aún no se ha creado."),
    "Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.": (
        "This frame is too old to hand the screen to a plugin.",
        "Este marco es demasiado antiguo para ceder la pantalla a un plugin."),
    "Etwas anderes hat gerade den Bildschirm.": (
        "Something else has the screen right now.",
        "Otra cosa está usando la pantalla ahora mismo."),
    "Handy": ("Phone", "Móvil"),
    "Kein TV-Code: {exc}": ("No TV code: {exc}", "Sin código de TV: {exc}"),
    "Keine Verbindung zu YouTube: {exc}": ("No connection to YouTube: {exc}", "Sin conexión con YouTube: {exc}"),
    "Konnte das Video nicht anzeigen: {exc}": ("Could not show the video: {exc}", "No se pudo mostrar el vídeo: {exc}"),
    "Konnte die Takeover-Playlist nicht anlegen: {exc}": (
        "Could not create the takeover playlist: {exc}",
        "No se pudo crear la lista de takeover: {exc}"),
    "Läuft gleich auf dem Rahmen.": ("Coming up on the frame.", "Enseguida en el marco."),
    "Melde den Rahmen bei YouTube an …": ("Signing the frame in with YouTube …", "Registrando el marco en YouTube …"),
    "Noch nicht bei YouTube angemeldet.": ("Not signed in with YouTube yet.", "Aún no registrado en YouTube."),
    "Probe": ("Test", "Prueba"),
    "YouTube Cast ist auf der Plugins-Seite ausgeschaltet.": (
        "YouTube Cast is switched off on the Plugins page.",
        "YouTube Cast está desactivado en la página de plugins."),
    "„Allow takeover“ ist für YouTube Cast auf der Plugins-Seite aus. Schalte es ein, sonst kann kein Video gezeigt werden.": (
        "“Allow takeover” is off for YouTube Cast on the Plugins page. Switch it on, otherwise no video can be shown.",
        "«Allow takeover» está desactivado para YouTube Cast en la página de plugins. Actívalo; si no, no se puede mostrar ningún vídeo."),
}


def t(lang, template, **values):
    text = template
    if lang in LANGUAGES and lang != "de":
        row = _TEXTS.get(template)
        if row:
            text = row[LANGUAGES.index(lang) - 1]
    try:
        return text.format(**values) if values else text
    except (KeyError, IndexError, ValueError):
        return text
