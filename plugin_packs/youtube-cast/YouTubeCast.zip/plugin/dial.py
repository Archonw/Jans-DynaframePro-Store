"""Damit die YouTube-App den Rahmen im WLAN findet (DIAL über SSDP).

Tippt man in der YouTube-App auf "Streamen", fragt die App per Multicast
im WLAN, wer YouTube abspielen kann (SSDP, UDP-Port 1900). Der Rahmen
antwortet mit der Adresse seiner Gerätebeschreibung. Wählt man ihn aus,
schickt die App einen Kopplungscode an /apps/YouTube; den meldet das Plugin
bei YouTube an, und ab da läuft alles über den Lounge-Dienst (lounge.py).

Derselbe kleine Webserver liefert auch die Senden-Seite für das Handy und
nimmt Links an (siehe plugin.py, extra_routes).
"""

import email.utils
import re
import socket
import struct
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse
from xml.sax.saxutils import escape

SSDP_ADDR = "239.255.255.250"
SSDP_PORT = 1900
DIAL_SERVICE = "urn:dial-multiscreen-org:service:dial:1"
DIAL_DEVICE = "urn:dial-multiscreen-org:device:dial:1"
ANNOUNCE_SECONDS = 120


def local_ip_for(address=None):
    """Die eigene Adresse, über die `address` (oder das Internet) erreicht wird."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect((address or "8.8.8.8", 9))
        return probe.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        probe.close()


class DialServer:
    """Webserver (DIAL + Senden-Seite) und SSDP-Antworten.

    on_launch(body_text) wird aufgerufen, wenn die App sich koppeln will,
    und gibt True zurück, wenn das geklappt hat. extra_routes(handler,
    method, path, query, body) beantwortet alle anderen Adressen und gibt
    (status, content_type, bytes) zurück oder None für 404.
    """

    def __init__(self, friendly_name, uuid, ports, on_launch, extra_routes, log, app_pid):
        self.friendly_name = friendly_name
        self.uuid = uuid
        self.ports = ports
        self.on_launch = on_launch
        self.extra_routes = extra_routes
        self.log = log
        self.app_pid = app_pid
        self.port = None
        self.httpd = None
        self.ssdp_ok = False
        self.ssdp_error = ""
        self.http_error = ""
        self._ssdp_sock = None
        self._stop = threading.Event()

    # ------------------------------------------------------------------
    # HTTP
    # ------------------------------------------------------------------

    def _handler(self):
        server = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            server_version = "DynaFrame-DIAL/1.0"

            def log_message(self, *_args):
                pass

            def _reply(self, status, content_type="text/plain; charset=utf-8", body=b"", headers=None):
                self.send_response(status)
                if content_type:
                    self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("Access-Control-Allow-Origin", "*")
                for key, value in (headers or {}).items():
                    self.send_header(key, value)
                self.end_headers()
                if body and self.command != "HEAD":
                    self.wfile.write(body)

            def _body(self):
                length = int(self.headers.get("Content-Length") or 0)
                if length > 65536:
                    raise ValueError("zu groß")
                return self.rfile.read(length).decode("utf-8", "replace") if length else ""

            def _host_base(self):
                host = self.headers.get("Host") or f"{local_ip_for()}:{server.port}"
                if ":" not in host:
                    host = f"{host}:{server.port}"
                return f"http://{host}"

            def do_OPTIONS(self):
                self._reply(204, None, b"", {"Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
                                             "Access-Control-Allow-Headers": "Content-Type"})

            def do_HEAD(self):
                self.do_GET()

            def do_GET(self):
                self._route("GET")

            def do_POST(self):
                self._route("POST")

            def do_DELETE(self):
                path = urlparse(self.path).path
                self._reply(405 if path.startswith("/apps/YouTube") else 404)

            def _route(self, method):
                parsed = urlparse(self.path)
                path = re.sub(r"/{2,}", "/", parsed.path)
                try:
                    body = self._body() if method == "POST" else ""
                except ValueError:
                    self._reply(413)
                    return
                try:
                    if path in ("/ssdp/device-desc.xml", "/dd.xml") and method == "GET":
                        base = self._host_base()
                        self._reply(200, "application/xml; charset=utf-8", server.device_xml(base).encode("utf-8"),
                                    {"Application-URL": f"{base}/apps"})
                        return
                    if path.rstrip("/") == "/apps" and method == "GET":
                        self._reply(204, None)
                        return
                    if path.rstrip("/") == "/apps/YouTube":
                        if method == "GET":
                            self._reply(200, "application/xml; charset=utf-8", server.app_xml().encode("utf-8"))
                            return
                        ok = server.on_launch(body)
                        if ok:
                            self._reply(201, "text/plain; charset=utf-8", b"",
                                        {"Location": f"{self._host_base()}/apps/YouTube/{server.app_pid}"})
                        else:
                            self._reply(503)
                        return
                    if path.startswith("/apps/"):
                        self._reply(404)
                        return
                    if path == "/ssdp/notfound":
                        self._reply(404)
                        return
                    answer = server.extra_routes(self, method, path, parse_qs(parsed.query), body)
                    if answer is None:
                        self._reply(404, "text/plain; charset=utf-8", b"Not found")
                    else:
                        status, content_type, payload = answer[:3]
                        self._reply(status, content_type, payload, answer[3] if len(answer) > 3 else None)
                except (BrokenPipeError, ConnectionResetError):
                    pass
                except Exception as exc:
                    server.log(f"Webserver: {path}: {exc!r}", "warning")
                    try:
                        self._reply(500, "text/plain; charset=utf-8", b"Error")
                    except Exception:
                        pass

        return Handler

    def device_xml(self, base):
        name = escape(self.friendly_name)
        return f"""<?xml version="1.0"?>
<root xmlns="urn:schemas-upnp-org:device-1-0">
  <specVersion><major>1</major><minor>0</minor></specVersion>
  <URLBase>{escape(base)}</URLBase>
  <device>
    <deviceType>{DIAL_DEVICE}</deviceType>
    <friendlyName>{name}</friendlyName>
    <manufacturer>DynaFrame</manufacturer>
    <modelName>DynaFrame</modelName>
    <UDN>uuid:{self.uuid}</UDN>
    <iconList><icon><mimetype>image/png</mimetype><width>144</width><height>144</height><depth>32</depth><url>/icon.png</url></icon></iconList>
    <serviceList>
      <service>
        <serviceType>{DIAL_SERVICE}</serviceType>
        <serviceId>urn:dial-multiscreen-org:serviceId:dial</serviceId>
        <controlURL>/ssdp/notfound</controlURL>
        <eventSubURL>/ssdp/notfound</eventSubURL>
        <SCPDURL>/ssdp/notfound</SCPDURL>
      </service>
    </serviceList>
  </device>
</root>
"""

    def app_xml(self):
        return f"""<?xml version="1.0" encoding="UTF-8"?>
<service xmlns="urn:dial-multiscreen-org:schemas:dial" dialVer="1.7">
  <name>YouTube</name>
  <options allowStop="false"/>
  <state>running</state>
  <link rel="run" href="{escape(self.app_pid)}"/>
</service>
"""

    def start_http(self):
        for port in self.ports:
            try:
                httpd = ThreadingHTTPServer(("0.0.0.0", port), self._handler())
            except OSError as exc:
                self.http_error = f"Port {port}: {exc}"
                continue
            httpd.daemon_threads = True
            self.httpd, self.port, self.http_error = httpd, port, ""
            threading.Thread(target=httpd.serve_forever, name="dial-http", daemon=True).start()
            return port
        return None

    # ------------------------------------------------------------------
    # SSDP
    # ------------------------------------------------------------------

    def _types(self):
        return [DIAL_SERVICE, DIAL_DEVICE, "upnp:rootdevice", f"uuid:{self.uuid}"]

    def _location(self, ip):
        return f"http://{ip}:{self.port}/ssdp/device-desc.xml"

    def _headers(self, ip, st):
        usn = f"uuid:{self.uuid}" if st.startswith("uuid:") else f"uuid:{self.uuid}::{st}"
        return {
            "CACHE-CONTROL": "max-age=1800",
            "DATE": email.utils.formatdate(usegmt=True),
            "EXT": "",
            "LOCATION": self._location(ip),
            "SERVER": "Linux UPnP/1.1 DynaFrame/1.0",
            "ST": st,
            "USN": usn,
            "BOOTID.UPNP.ORG": "1",
            "CONFIGID.UPNP.ORG": "1",
        }

    def _answer_search(self, data, address):
        text = data.decode("utf-8", "replace")
        if not text.upper().startswith("M-SEARCH"):
            return
        headers = {}
        for line in text.split("\r\n")[1:]:
            if ":" in line:
                key, value = line.split(":", 1)
                headers[key.strip().upper()] = value.strip()
        st = headers.get("ST", "")
        if st == "ssdp:all":
            targets = self._types()
        elif st in self._types():
            targets = [st]
        else:
            return
        ip = local_ip_for(address[0])
        for target in targets:
            lines = ["HTTP/1.1 200 OK"] + [f"{k}: {v}" for k, v in self._headers(ip, target).items()]
            try:
                self._ssdp_sock.sendto(("\r\n".join(lines) + "\r\n\r\n").encode("utf-8"), address)
            except OSError:
                pass

    def _notify(self, nts):
        if not self._ssdp_sock:
            return
        ip = local_ip_for()
        for nt in self._types():
            headers = self._headers(ip, nt)
            headers.pop("ST")
            headers.pop("EXT")
            headers.pop("DATE")
            lines = [f"NOTIFY * HTTP/1.1", f"HOST: {SSDP_ADDR}:{SSDP_PORT}", f"NT: {nt}", f"NTS: {nts}"] + \
                [f"{k}: {v}" for k, v in headers.items()]
            try:
                self._ssdp_sock.sendto(("\r\n".join(lines) + "\r\n\r\n").encode("utf-8"), (SSDP_ADDR, SSDP_PORT))
            except OSError:
                pass

    def _ssdp_loop(self):
        last = 0.0
        while not self._stop.is_set():
            if time.time() - last > ANNOUNCE_SECONDS:
                self._notify("ssdp:alive")
                last = time.time()
            try:
                data, address = self._ssdp_sock.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                if self._stop.is_set():
                    break
                time.sleep(1)
                continue
            self._answer_search(data, address)

    def start_ssdp(self):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            if hasattr(socket, "SO_REUSEPORT"):
                try:
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
                except OSError:
                    pass
            sock.bind(("", SSDP_PORT))
            membership = struct.pack("4s4s", socket.inet_aton(SSDP_ADDR), socket.inet_aton("0.0.0.0"))
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, membership)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
            sock.settimeout(2)
        except OSError as exc:
            self.ssdp_ok, self.ssdp_error = False, str(exc)
            self.log(f"Der Rahmen kann im WLAN nicht gefunden werden (SSDP: {exc}). "
                     "Verknüpfen mit TV-Code geht trotzdem.", "warning")
            return False
        self._ssdp_sock = sock
        self.ssdp_ok, self.ssdp_error = True, ""
        threading.Thread(target=self._ssdp_loop, name="dial-ssdp", daemon=True).start()
        return True

    def start(self):
        self._stop.clear()
        port = self.start_http()
        if port is None:
            self.log(f"Kein freier Port für die Senden-Seite und DIAL ({self.http_error}).", "warning")
            return False
        self.start_ssdp()
        return True

    def rename(self, friendly_name):
        self.friendly_name = friendly_name

    def stop(self):
        self._stop.set()
        if self._ssdp_sock:
            self._notify("ssdp:byebye")
            try:
                self._ssdp_sock.close()
            except OSError:
                pass
            self._ssdp_sock = None
        if self.httpd:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:
                pass
            self.httpd = None

    def url(self):
        return f"http://{local_ip_for()}:{self.port}/" if self.port else ""


def parse_launch(body):
    """pairingCode=…&theme=cl&… aus dem POST der App."""
    values = parse_qs(body or "")
    return {k: v[0] for k, v in values.items() if v}
