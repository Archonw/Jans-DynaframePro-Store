#!/usr/bin/env python3
"""Photo Quiz - der Plugin-Teil des Pakets "photo-quiz".

Die Szene "photo-quiz" ist ein Ratespiel mit den eigenen Fotos: „Wann und wo
war das?“. Ein Foto erscheint erst grob verpixelt oder als enger Ausschnitt,
wird nach und nach deutlicher, dazwischen kommen Hinweise (Jahreszeit,
Wetter damals, Kamera, Entfernung von zu Hause, Land). Am Ende die
Auflösung mit Datum, Ort und Karte.

Mitspielen geht mit dem Handy: Die Szene zeigt einen QR-Code, das Handy
öffnet die Seite dieses Plugins im WLAN (Port 8099), dort tippt man Jahr und
Ort auf einer Karte. Das Plugin zählt die Punkte und zeigt nach ein paar
Runden den Endstand. Wer schon mitgespielt hat, kann das Quiz vom Handy aus
auf den Rahmen holen (Takeover).

Dieses Plugin
- liest die Fotos ein (DynaFrame-Playlists, Mediendatenbank, Ordner; Immich
  als Zufallsauswahl), mit Datum, GPS, Ort und Kamera,
- wählt je Runde ein Foto, bereitet es vor (verkleinert) und rechnet die
  Hinweise aus (Wetter damals über Open-Meteo, Ortsnamen über OpenStreetMap),
- führt das Spiel (Zeit, Tipps, Punkte) für Szene und Handys.
"""

import collections
import datetime
import hashlib
import io
import json
import os
import random
import re
import secrets
import socket
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import exif_gps  # noqa: E402
import dynaframe_filters  # noqa: E402
import immich_filters  # noqa: E402
import sources  # noqa: E402
import own_playlist  # noqa: E402
import quiz  # noqa: E402
import texts  # noqa: E402
import weather  # noqa: E402

try:
    import playback_guard  # noqa: E402
except Exception:  # noqa: BLE001 - nur ein Behelf, darf fehlen
    playback_guard = None

try:
    from PIL import Image, ImageOps
except ImportError:  # pragma: no cover - kommt mit requirements.txt
    Image = ImageOps = None

HEIF = False
if Image is not None:
    try:
        from pillow_heif import register_heif_opener  # type: ignore

        register_heif_opener()
        HEIF = True
    except Exception:  # noqa: BLE001 - optional
        HEIF = False

plugin = create_plugin()

PLUGIN_ID = "PhotoQuiz"
SCENE_ID = "photo-quiz"             # id in scene.dynamic - nie ändern
DISPLAY_NAME = "Photo Quiz"
PLAYLIST_NAMES = {"de": "Photo Quiz", "en": "Photo Quiz", "es": "Photo Quiz"}
TAKEOVER_PLAYLIST_NAME = "Photo Quiz (takeover)"
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen, Caches; bleibt bei Updates
PHOTO_DIR = DATA_DIR / "photos"

CONNECT_TIMEOUT = 10
MAX_SOURCES = 6
PHOTO_EDGE = 1920                   # lange Seite der Fotos für die Szene
PHONE_PORTS = (8099, 8100, 8101, 8102)
SCENE_GONE = 8                      # so lange ohne Frage der Szene: sie ist nicht mehr zu sehen

KINDS = ("library", "playlist", "immich_all", "immich_album")
HINT_KINDS = ("season", "weather", "camera", "distance", "country")


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def as_float(value, default=None):
    try:
        number = float(str(value).strip().replace(",", "."))
    except (TypeError, ValueError):
        return default
    return default if number != number else number


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält den API-Schlüssel
        except OSError:
            pass


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

def default_sources():
    return [{"id": "s1", "kind": "library", "ref": "", "name": ""}]


SCHEMA = {
    "Language":        {"kind": "choice", "default": "en", "choices": texts.LANGUAGES},
    "ServerUrl":       {"kind": "url", "default": ""},
    "ApiKey":          {"kind": "secret", "default": ""},
    "Sources":         {"kind": "sources", "default": None},
    "Folders":         {"kind": "folders", "default": ""},
    # Welche Immich-Fotos überhaupt (wie Growing Up)
    "Albums":          {"kind": "albums", "default": []},
    # Immich-Filter wie Foto Mosaik
    **immich_filters.schema(),
    # DynaFrame-Filter wie Foto Mosaik (Sterne, Kamera … aus der Mediendatenbank)
    **dynaframe_filters.schema(),
    # Das Spiel
    "GuessMode":       {"kind": "choice", "default": "both", "choices": ("both", "when", "where")},
    "Rounds":          {"kind": "int", "default": 5, "min": 2, "max": 20},
    "GuessSeconds":    {"kind": "int", "default": 45, "min": 15, "max": 180},
    "IdleSeconds":     {"kind": "int", "default": 20, "min": 8, "max": 120},
    "RevealSeconds":   {"kind": "int", "default": 15, "min": 6, "max": 60},
    "FinalSeconds":    {"kind": "int", "default": 20, "min": 8, "max": 120},
    "RevealStyle":     {"kind": "choice", "default": "mixed", "choices": ("mixed", "pixel", "zoom", "blur")},
    "HintSeason":      {"kind": "bool", "default": True},
    "HintWeather":     {"kind": "bool", "default": True},
    "HintCamera":      {"kind": "bool", "default": True},
    "HintDistance":    {"kind": "bool", "default": True},
    "HintCountry":     {"kind": "bool", "default": True},
    "HomeName":        {"kind": "text", "default": ""},
    "HomeLat":         {"kind": "coord", "default": None},
    "HomeLon":         {"kind": "coord", "default": None},
    "Units":           {"kind": "choice", "default": "c", "choices": ("c", "f")},
    # Mitspielen mit dem Handy
    "PhonePlay":       {"kind": "bool", "default": True},
    "PhoneStart":      {"kind": "bool", "default": True},
    "QuizMinutes":     {"kind": "int", "default": 20, "min": 5, "max": 180},
    "WakeScreen":      {"kind": "bool", "default": True},
    "RefreshHours":    {"kind": "int", "default": 24, "min": 1, "max": 168},
    "PlaylistSeconds": {"kind": "int", "default": 900, "min": 60, "max": 86400},
    "MakePlaylist":    {"kind": "bool", "default": False},
}
SECRETS = [name for name, spec in SCHEMA.items() if spec["kind"] == "secret"]
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()




def coerce_sources(raw):
    if raw is None:
        return default_sources()
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return default_sources()
    out, ids = [], set()
    for row in raw if isinstance(raw, list) else []:
        if not isinstance(row, dict) or len(out) >= MAX_SOURCES:
            continue
        ident = re.sub(r"[^A-Za-z0-9]", "", str(row.get("id") or ""))[:16] or uuid.uuid4().hex[:8]
        while ident in ids:
            ident = uuid.uuid4().hex[:8]
        ids.add(ident)
        out.append({
            "id": ident,
            "kind": row.get("kind") if row.get("kind") in KINDS else "library",
            "ref": re.sub(r"[^A-Za-z0-9_-]", "", str(row.get("ref") or ""))[:64],
            "name": re.sub(r"\s+", " ", str(row.get("name") or "")).strip()[:60],
        })
    return out


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind in ("ref", "date", "name"):
        return immich_filters.coerce(spec, raw)
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "float":
        return round(max(spec["min"], min(spec["max"], as_float(raw, spec["default"]))), 1)
    if kind == "coord":
        value = as_float(raw, None)
        return None if value is None or abs(value) > 180 else round(value, 4)
    if kind == "choice":
        value = str(raw or "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "sources":
        return coerce_sources(raw)
    if kind == "albums":
        if isinstance(raw, str):
            raw = [part for part in raw.split(",") if part]
        ids = []
        for item in raw if isinstance(raw, list) else []:
            ident = re.sub(r"[^A-Za-z0-9_-]", "", str(item or ""))[:64]
            if ident and ident not in ids:
                ids.append(ident)
        return ids[:50]
    if kind == "url":
        return sources.normalize_url(raw)[:300]
    if kind == "text":
        return re.sub(r"\s+", " ", str(raw or "")).strip()[:80]
    if kind == "folders":
        lines = [line.strip() for line in str(raw or "").replace(";", "\n").splitlines()]
        return "\n".join(line for line in lines if line.startswith("/"))[:2000]
    return re.sub(r"\s+", "", str(raw or ""))[:400]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


def adopt_immich():
    """Server und Schlüssel aus einem anderen Immich-Plugin übernehmen, wenn hier keiner steht."""
    values = settings()
    if values["ServerUrl"] and values["ApiKey"]:
        return ""
    for name, title in (("ImmichSlideshow", "Immich Slideshow"), ("GrowingUp", "Growing Up"),
                        ("ColorCalendar", "Colour Calendar"), ("PhotoMosaic", "Photo Mosaic"), ("OnThisDay", "On This Day")):
        other = read_json(PLUGIN_DIR.parent / name / "data" / "settings.json", {}) or {}
        if not isinstance(other, dict):
            continue
        url, key = sources.normalize_url(other.get("ServerUrl")), str(other.get("ApiKey") or "").strip()
        if url and key:
            save_settings({"ServerUrl": url, "ApiKey": key})
            log(f"Immich-Server und API-Schlüssel aus {title} übernommen.")
            return title
    return ""


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 120))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def engine_image(media_id, path=""):
    """Das Vorschaubild, das die Engine für die Weboberfläche erzeugt (auf Jans Rahmen 512 Pixel)."""
    candidates = []
    if path:
        candidates += [("/media/thumbnail", {"path": path, "purpose": "preview"}),
                       ("/media/thumbnail", {"path": path})]
    if media_id:
        candidates += [(f"/media/thumbnail/{media_id}", {"purpose": "preview"}),
                       (f"/media/thumbnail/{media_id}", None)]
    failures = []
    for route, params in candidates:
        try:
            response = requests.get(f"{engine_base()}{route}", params=params, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 60))
        except requests.RequestException as exc:
            failures.append(f"{route}: {exc}")
            continue
        kind = response.headers.get("Content-Type", "").split(";")[0]
        if response.status_code == 200 and kind.startswith("image/"):
            return response.content
        failures.append(f"{route}{'?path' if params and 'path' in params else ''}: HTTP {response.status_code} {kind}")
    raise sources.SourceError(f"Vorschaubild {media_id}: " + "; ".join(failures))


# --------------------------------------------------------------------------
# Index der DynaFrame-Fotos (Datum + GPS), mit Cache für Dateien
# --------------------------------------------------------------------------

immich = sources.Immich(tr)
dynaframe = sources.DynaFrame(engine_call, EngineError, log)
sky = weather.Weather(DATA_DIR, log)

EXIF_FILE = DATA_DIR / "exif.json"
_exif = {"data": None, "dirty": 0}
_exif_lock = threading.Lock()


def exif_lookup(path, stamp):
    """(taken, lat, lon) aus der Datei, mit Cache (key = Pfad, Stempel muss passen)."""
    with _exif_lock:
        if _exif["data"] is None:
            stored = read_json(EXIF_FILE, {})
            _exif["data"] = stored if isinstance(stored, dict) else {}
        row = _exif["data"].get(path)
    if isinstance(row, list) and len(row) == 4 and row[0] == stamp:
        return row[1], row[2], row[3]
    lat, lon, taken = exif_gps.read(path)
    taken = sources.clean_taken(taken)
    with _exif_lock:
        _exif["data"][path] = [stamp, taken, lat, lon]
        _exif["dirty"] += 1
    return taken, lat, lon


def exif_save(keep=None):
    with _exif_lock:
        if _exif["data"] is None:
            return
        if keep is not None:
            for key in [k for k in _exif["data"] if k not in keep]:
                del _exif["data"][key]
                _exif["dirty"] += 1
        if _exif["dirty"]:
            write_json(EXIF_FILE, _exif["data"])
            _exif["dirty"] = 0


def key_path(key):
    if key.startswith("d:"):
        return key.partition("|")[2]
    if key.startswith("f:"):
        return key[2:]
    return ""


_stop_requested = threading.Event()
_work_stop = threading.Event()
_wake = threading.Event()
_index_lock = threading.Lock()
_index = {"rows": [], "status": {}, "at": 0.0, "signature": "", "busy": False,
          "progress": {"done": 0, "todo": 0, "phase": ""}, "undated": 0, "total": 0}


def index_signature(values):
    wanted = [(s["id"], s["kind"], s["ref"]) for s in values["Sources"] if not s["kind"].startswith("immich")]
    return json.dumps([wanted, values["Folders"], dynaframe_filters.signature(values), version()], sort_keys=True)


def build_index(reason=""):
    """Alle DynaFrame-Quellen einlesen: Datum und GPS jedes Fotos."""
    values = settings()
    wanted = [s for s in values["Sources"] if not s["kind"].startswith("immich")]
    with _index_lock:
        if _index["busy"]:
            return
        _index["busy"] = True
    started = now()
    status, rows = {}, {}
    match = None
    if wanted and dynaframe_filters.active(values):
        match = dynaframe_filters.Matcher(values, lambda: dynaframe.library_rows(_work_stop),
                                          cache_file=str(DATA_DIR / "file_meta.json"), log=log)
    try:
        if wanted:
            log(f"Lese die DynaFrame-Fotos ein{' - ' + reason if reason else ''}.")
        _index["progress"] = {"done": 0, "todo": 0, "phase": "list"}
        for source in wanted:
            sid = source["id"]
            _index["status"][sid] = dict(_index["status"].get(sid) or {}, state="busy")
            try:
                if source["kind"] == "playlist":
                    if not source["ref"]:
                        raise sources.SourceError(tr("Wähle eine Playlist."))
                    try:
                        found, total = dynaframe.playlist(source["ref"], _work_stop)
                    except EngineError as exc:
                        if exc.status == 404:
                            raise sources.SourceError(tr("Die Playlist gibt es nicht mehr.")) from exc
                        raise
                else:
                    folders = [f for f in values["Folders"].splitlines() if f]
                    found, total = dynaframe.library(folders, _work_stop)
                if match is not None:
                    found = [row for row in found if match.keep(row["k"])]
                for row in found:
                    row["src"] = sid
                    rows.setdefault(row["k"], row)
                status[sid] = {"state": "ok", "total": total, "dated": 0, "located": 0, "error": "", "at": now()}
            except EngineError as exc:
                status[sid] = {"state": "error", "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except sources.SourceError as exc:
                status[sid] = {"state": "error", "error": str(exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except Exception as exc:  # pragma: no cover - darf den Durchlauf nicht beenden
                status[sid] = {"state": "error", "error": str(exc)[:200], "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc!r}", "warning")
            _index["status"][sid] = status[sid]
            if _work_stop.is_set() or _stop_requested.is_set():
                return

        if match is not None:
            match.save()
        _index["dfCount"] = match.counts() if match is not None else None
        # Datum/GPS aus den Dateien, wo die Engine keins mitliefert
        todo = [r for r in rows.values() if (not r["t"] or r["lat"] is None) and os.path.isfile(key_path(r["k"]))]
        _index["progress"] = {"done": 0, "todo": len(todo), "phase": "exif"}
        for count, row in enumerate(todo, 1):
            if _work_stop.is_set() or _stop_requested.is_set():
                exif_save()
                return
            taken, lat, lon = exif_lookup(key_path(row["k"]), row["stamp"])
            row["t"] = row["t"] or taken
            if row["lat"] is None and lat is not None and lon is not None:
                row["lat"], row["lon"] = lat, lon
            _index["progress"]["done"] = count
            if count % 200 == 0:
                time.sleep(0.05)
        exif_save(keep={key_path(r["k"]) for r in rows.values() if key_path(r["k"])})
        dated = [r for r in rows.values() if len(r["t"]) >= 10]
        for sid, row in status.items():
            if row.get("state") == "ok":
                mine = [r for r in rows.values() if r.get("src") == sid]
                row["dated"] = sum(1 for r in mine if len(r["t"]) >= 10)
                row["located"] = sum(1 for r in mine if r["lat"] is not None)
        with _index_lock:
            _index.update(rows=dated, status=dict(_index["status"], **status), at=now(),
                          signature=index_signature(values), undated=len(rows) - len(dated), total=len(rows))
        if wanted:
            log(f"{len(dated)} DynaFrame-Fotos mit Datum ({len(rows) - len(dated)} ohne), {now() - started:.0f} s.")
    finally:
        _index["progress"] = {"done": 0, "todo": 0, "phase": ""}
        with _index_lock:
            _index["busy"] = False


# --------------------------------------------------------------------------
# Fotos für die Szene
# --------------------------------------------------------------------------

PHOTO_MAX = 40 * 1024 * 1024
SHOWABLE = (".jpg", ".jpeg", ".jpe", ".png", ".webp", ".gif", ".bmp", ".tif", ".tiff")


def webdav_dirs():
    seen = []
    for home in (Path.home(), Path("/home/pi")):
        folder = home / ".local/share/dfr/webdav-cache"
        if folder not in seen and folder.is_dir():
            seen.append(folder)
    return seen


def webdav_cached(path, size):
    """Fotos aus WebDAV (/webdav-media/<Quelle>/...) liefert die Engine nur als
    512-Pixel-Vorschau. Das Original legt DynaFrame aber in webdav-cache ab,
    als <Quelle>-<Hash>.<Endung>. Den Hash kennen wir nicht, also: gleiche
    Quelle, gleiche Endung, gleiche Dateigröße (wie bei Halloween Scare)."""
    if not path.startswith("/webdav-media/"):
        return None
    size = as_int(size, 0)
    if size <= 0 or size > PHOTO_MAX:
        return None
    parts = path.split("/")
    source = parts[2] if len(parts) > 2 else ""
    suffix = Path(path).suffix.lower()
    best = None
    for folder in webdav_dirs():
        try:
            entries = list(os.scandir(folder))
        except OSError:
            continue
        for entry in entries:
            name = entry.name
            if source and not name.startswith(source + "-"):
                continue
            if suffix and not name.lower().endswith(suffix):
                continue
            try:
                info = entry.stat()
            except OSError:
                continue
            if info.st_size == size and (best is None or info.st_mtime > best[0]):
                best = (info.st_mtime, Path(entry.path))
    return best[1] if best else None


def shrink(source):
    """Bild (Pfad oder Bytes) gedreht nach Exif und verkleinert als JPEG-Bytes, dazu (w, h)."""
    if Image is None:
        raise sources.SourceError("Pillow fehlt")
    handle = io.BytesIO(source) if isinstance(source, (bytes, bytearray)) else source
    with Image.open(handle) as image:
        try:
            image.draft("RGB", (PHOTO_EDGE, PHOTO_EDGE))
        except Exception:  # noqa: BLE001 - nur JPEG kennt draft
            pass
        image = ImageOps.exif_transpose(image)
        image = image.convert("RGB")
        image.thumbnail((PHOTO_EDGE, PHOTO_EDGE), Image.LANCZOS)
        out = io.BytesIO()
        image.save(out, "JPEG", quality=86, optimize=True, progressive=True)
        return out.getvalue(), image.size


def photo_file(item):
    name = hashlib.sha1(f"{item['k']}|{item.get('stamp') or ''}".encode("utf-8")).hexdigest()[:20]
    return PHOTO_DIR / f"{name}.jpg"


def prepare(item):
    """Das Foto als JPEG im Cache ablegen; liefert den Pfad."""
    target = photo_file(item)
    if target.is_file():
        return target
    key = item["k"]
    data = None
    if key.startswith("i:"):
        values = settings()
        immich.configure(values["ServerUrl"], values["ApiKey"])
        raw, _kind = immich.photo(key[2:], size="preview")
        try:
            data, _size = shrink(raw)
        except Exception:  # noqa: BLE001 - dann so, wie Immich es schickt
            data = raw
    else:
        path = key_path(key)
        local = path and os.path.isfile(path)
        if local and (path.lower().endswith(SHOWABLE) or HEIF):
            try:
                data, _size = shrink(path)
            except Exception as exc:  # noqa: BLE001 - kaputte Datei: über die Engine
                log(f"Foto {path}: {exc}", "warning")
        if data is None and path.startswith("/webdav-media/"):
            cached = webdav_cached(path, str(item.get("stamp") or "").split(":")[0])
            if cached:
                try:
                    data, _size = shrink(str(cached))
                except Exception:  # noqa: BLE001
                    data = None
        if data is None and key.startswith("d:"):
            raw = engine_image(key[2:].partition("|")[0], path)
            try:
                data, _size = shrink(raw)
            except Exception:  # noqa: BLE001
                data = raw
        if data is None:
            raise sources.SourceError("Foto nicht gefunden")
    PHOTO_DIR.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(f".{threading.get_ident()}.tmp")
    temp.write_bytes(data)
    temp.replace(target)
    return target


_prepare_lock = threading.Lock()




# --------------------------------------------------------------------------
# Immich: eine Zufallsauswahl statt der ganzen Bibliothek
# --------------------------------------------------------------------------

IMMICH_SAMPLE = 400
_immich = {"rows": [], "at": 0.0, "signature": "", "status": {}, "busy": False}


def immich_signature(values):
    keep = ("Sources", "ServerUrl", "ApiKey", "Albums", *immich_filters.SCHEMA.keys())
    text = json.dumps([{k: values[k] for k in keep}, version()], sort_keys=True, default=str)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def refill_immich(reason=""):
    values = settings()
    wanted = [s for s in values["Sources"] if s["kind"].startswith("immich")]
    signature = immich_signature(values)
    if not wanted:
        _immich.update(rows=[], status={}, at=now(), signature=signature)
        return
    if _immich["busy"]:
        return
    _immich["busy"] = True
    try:
        immich.configure(values["ServerUrl"], values["ApiKey"])
        f = immich_filters.from_settings(values)
        rows, status = {}, {}
        for source in wanted:
            sid = source["id"]
            albums = [source["ref"]] if source["kind"] == "immich_album" else list(values["Albums"])
            if source["kind"] == "immich_album" and not source["ref"]:
                status[sid] = {"state": "error", "error": tr("Wähle ein Album."), "at": now()}
                continue
            try:
                found = immich.sample(albums, f, _work_stop, IMMICH_SAMPLE // len(wanted))
                for row in found:
                    row["src"] = sid
                    rows.setdefault(row["k"], row)
                status[sid] = {"state": "ok", "total": len(found),
                               "dated": sum(1 for r in found if r["t"]),
                               "located": sum(1 for r in found if r["lat"] is not None), "error": "", "at": now()}
            except sources.SourceError as exc:
                status[sid] = {"state": "error", "error": str(exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
        _immich.update(rows=list(rows.values()), status=status, at=now(), signature=signature)
        log(f"Immich: {len(rows)} Fotos zufällig ausgewählt{' - ' + reason if reason else ''}.")
    finally:
        _immich["busy"] = False


def pool():
    rows = list(_index["rows"]) + [r for r in _immich["rows"] if r["t"]]
    return rows


def pool_years(rows):
    years = sorted({int(r["t"][:4]) for r in rows if r["t"][:4].isdigit()})
    if not years:
        this = datetime.date.today().year
        return [this - 15, this]
    return [years[0], years[-1]]


_geo = {"home": None, "scale": 300.0, "auto": True, "at": 0.0}


def update_geo():
    values = settings()
    rows = pool()
    if values["HomeLat"] is not None and values["HomeLon"] is not None:
        home, auto = (values["HomeLat"], values["HomeLon"]), False
    else:
        home, auto = quiz.home_of(rows), True
    _geo.update(home=home, auto=auto, scale=quiz.place_scale(rows, home), at=now())


# --------------------------------------------------------------------------
# Fotos für die Runden
# --------------------------------------------------------------------------

_round_lock = threading.Lock()
_recent_keys = collections.deque(maxlen=300)
_recent_days = collections.deque(maxlen=12)
_prep = {"busy": False, "photo": None, "error": "", "failed": 0}


def wanted_hints(values):
    return [k for k in HINT_KINDS if values["Hint" + k.capitalize()]]


def make_round_photo():
    """Ein Foto auswählen, vorbereiten und die Hinweise rechnen. None, wenn es nicht klappt."""
    values = settings()
    rows = pool()
    need_place = values["GuessMode"] in ("both", "where")
    lang = values["Language"]
    for _attempt in range(6):
        row = quiz.pick(rows, set(_recent_keys), set(_recent_days), need_place)
        if row is None:
            _prep["error"] = "empty"
            return None
        _recent_keys.append(row["k"])
        try:
            target = prepare(row)
        except Exception as exc:  # noqa: BLE001 - nächstes Foto versuchen
            _prep["failed"] += 1
            if _prep["failed"] <= 5:
                log(f"Foto fürs Quiz ({row['k'][:100]}): {exc}", "warning")
            continue
        place = row.get("place") or ""
        if row.get("lat") is not None and (not place or "," not in place):
            looked = sky.place(row["lat"], row["lon"], lang)
            place = looked or place
        then = None
        if values["HintWeather"] and row.get("lat") is not None and len(row["t"]) >= 13:
            try:
                then = sky.then(row["lat"], row["lon"], row["t"][:10], as_int(row["t"][11:13], 12))
            except weather.WeatherError as exc:
                log(f"Wetter damals: {exc}", "warning")
        sky.save()
        hints = quiz.hints(dict(row, place=place), _geo["home"], wanted_hints(values), then)
        _recent_days.append(row["t"][:10])
        size = (row.get("w"), row.get("h"))
        try:
            with Image.open(target) as image:
                size = image.size
        except Exception:  # noqa: BLE001
            pass
        return {"id": target.stem, "k": row["k"], "t": row["t"], "lat": row.get("lat"), "lon": row.get("lon"),
                "place": place, "hints": hints, "w": size[0], "h": size[1],
                "fav": bool(row.get("fav")), "focus": [round(random.uniform(0.3, 0.7), 3),
                                                       round(random.uniform(0.3, 0.6), 3)],
                "style": values["RevealStyle"] if values["RevealStyle"] != "mixed"
                else random.choice(("pixel", "zoom", "blur"))}
    return None


def ensure_prep():
    """Das nächste Foto im Hintergrund vorbereiten (wenn nicht schon eins wartet)."""
    with _round_lock:
        if _prep["busy"] or _prep["photo"] is not None:
            return
        _prep["busy"] = True

    def work():
        try:
            photo = make_round_photo()
            with _round_lock:
                _prep["photo"] = photo
                if photo:
                    _prep["error"] = ""
        except Exception as exc:  # noqa: BLE001
            log(f"Nächste Runde: {exc!r}", "warning")
        finally:
            with _round_lock:
                _prep["busy"] = False

    threading.Thread(target=work, name=f"{PLUGIN_ID}-prep", daemon=True).start()


def take_prepared():
    with _round_lock:
        photo, _prep["photo"] = _prep["photo"], None
    return photo


def prune_photos(keep):
    try:
        for entry in os.scandir(PHOTO_DIR):
            if entry.name.split(".")[0] not in keep and now() - entry.stat().st_mtime > 3600:
                os.unlink(entry.path)
    except OSError:
        pass


def photo_bytes(query):
    ident = (query.get("id") or [""])[0]
    if not re.match(r"^[0-9a-f]{20}$", ident):
        return None
    path = PHOTO_DIR / f"{ident}.jpg"
    return path.read_bytes() if path.is_file() else None


# --------------------------------------------------------------------------
# Das Spiel
# --------------------------------------------------------------------------

PLAYERS_FILE = DATA_DIR / "players.json"
_game_lock = threading.RLock()
game = None
_scene = {"seen": 0.0, "first": 0.0}
_join = {"code": "", "day": ""}


def load_game():
    global game
    stored = read_json(PLAYERS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    stored.setdefault("players", {})
    game = quiz.Game(stored)


def save_players():
    with _game_lock:
        write_json(PLAYERS_FILE, game.store)


def join_code():
    today = datetime.date.today().isoformat()
    if _join["day"] != today or not _join["code"]:
        _join.update(code=f"{secrets.randbelow(9000) + 1000}", day=today)
    return _join["code"]


def scene_visible(t=None):
    return (t or now()) - _scene["seen"] < SCENE_GONE


def guess_seconds(values, t):
    return values["GuessSeconds"] if game.active(t) else values["IdleSeconds"]


def begin_round(values, t):
    photo = take_prepared()
    if photo is None:
        game.phase = "wait"
        ensure_prep()
        return
    if game.round >= values["Rounds"]:
        game.reset_game()
    game.start_round(photo, t, guess_seconds(values, t))
    prune_photos({photo["id"]})
    ensure_prep()


def step():
    """Einmal je Viertelsekunde: das Spiel weiterschalten."""
    t = now()
    values = settings()
    with _game_lock:
        if not scene_visible(t):
            if game.phase != "off":
                game.stop()
            return
        phase = game.phase
        if phase in ("off", "wait"):
            if not pool():
                game.phase = "wait"
                return
            begin_round(values, t)
        elif phase == "guess":
            if t >= game.until or (t - game.started >= quiz.MIN_GUESS_SECONDS and game.all_guessed(t)):
                game.reveal(t, values["RevealSeconds"], _geo["scale"], values["GuessMode"])
                if game.results:
                    save_players()
                ensure_prep()
        elif phase == "reveal":
            if t >= game.until:
                if game.round >= values["Rounds"] and game.played:
                    game.finish(t, values["FinalSeconds"])
                    save_players()
                else:
                    if game.round >= values["Rounds"]:
                        game.reset_game()
                    begin_round(values, t)
        elif phase == "final":
            if t >= game.until:
                game.reset_game()
                begin_round(values, t)


def game_loop():
    while not _stop_requested.is_set():
        try:
            step()
            decide_takeover()
        except Exception as exc:  # noqa: BLE001 - der Faden darf nicht sterben
            log(f"Spiel: {exc!r}", "warning")
        _stop_requested.wait(0.25)


def shown_hints(t):
    photo = game.photo or {}
    hints = photo.get("hints") or []
    if game.phase != "guess":
        return hints
    dur = max(1.0, game.until - game.started)
    elapsed = t - game.started
    return [h for i, h in enumerate(hints) if elapsed >= dur * (i + 1) / (len(hints) + 1)]


def answer():
    photo = game.photo or {}
    return {"t": photo.get("t") or "", "place": photo.get("place") or "",
            "lat": photo.get("lat"), "lon": photo.get("lon")}


def player_rows(t):
    active = set(game.active(t))
    rows = []
    for ident in active:
        person = game.players().get(ident)
        if person:
            rows.append({"name": person["name"], "color": person["color"], "score": game.scores.get(ident, 0),
                         "done": ident in game.guesses})
    rows.sort(key=lambda r: (-r["score"], r["name"].lower()))
    return rows


def public_rows(rows, me):
    """Ohne die IDs der Mitspieler: mit einer ID kann man für jemanden tippen."""
    return [dict({k: v for k, v in r.items() if k != "id"}, mine=bool(me) and r.get("id") == me) for r in rows]


def game_state(t, for_scene=False, me=None):
    values = settings()
    rows = pool()
    with _game_lock:
        phase = game.phase
        out = {
            "success": True,
            "phase": phase,
            "round": game.round,
            "rounds": values["Rounds"],
            "ident": game.ident,
            "left": round(max(0.0, game.until - t), 2) if phase in ("guess", "reveal", "final") else 0,
            "dur": round(max(0.0, game.until - game.started), 2) if phase in ("guess", "reveal", "final") else 0,
            "mode": values["GuessMode"],
            "years": pool_years(rows),
            "units": values["Units"],
            "lang": values["Language"],
            "players": player_rows(t),
            "count": len(rows),
            "busy": _index["busy"] or _immich["busy"],
        }
        if phase in ("guess", "reveal"):
            out["hints"] = shown_hints(t)
            out["hintCount"] = len((game.photo or {}).get("hints") or [])
        if phase == "reveal":
            out["answer"] = answer()
            out["results"] = public_rows(game.results, me)
        if phase == "final":
            out["final"] = public_rows(game.final, me)
        home = _geo["home"]
        out["home"] = list(home) if home else None
        out["scale"] = round(_geo["scale"], 1)
        if for_scene:
            out["phone"] = values["PhonePlay"]
            if values["PhonePlay"]:
                out["url"] = phone_url()
                out["code"] = join_code()
            if game.photo and phase in ("guess", "reveal"):
                photo = game.photo
                out["photo"] = {"id": photo["id"], "w": photo["w"], "h": photo["h"],
                                "style": photo["style"], "focus": photo["focus"]}
            with _round_lock:
                upcoming = _prep["photo"]
            if upcoming:
                out["next"] = upcoming["id"]
            out["takeover"] = _takeover["handle"] is not None
        else:
            person = game.players().get(me) if me else None
            if person:
                out["me"] = {"name": person["name"], "color": person["color"], "score": game.scores.get(me, 0),
                             "games": person.get("games", 0), "wins": person.get("wins", 0)}
                mine = game.guesses.get(me)
                if mine:
                    out["myGuess"] = {k: mine[k] for k in ("year", "lat", "lon") if k in mine}
            out["canStart"] = bool(person) and values["PhoneStart"] and not scene_visible(t)
            out["takeover"] = _takeover["handle"] is not None
            out["center"] = list(home) if home else None
            out["visible"] = scene_visible(t)
            with _takeover_lock:
                out["note"] = _takeover["note"]
    return out


# --------------------------------------------------------------------------
# Handy: beitreten, tippen, Quiz starten
# --------------------------------------------------------------------------

def phone_join(body):
    values = settings()
    if not values["PhonePlay"]:
        return {"success": False, "error": "off"}
    ident = str(body.get("id") or "")
    t = now()
    with _game_lock:
        known = ident in game.players()
        if not known and str(body.get("code") or "").strip() != join_code():
            return {"success": False, "error": "code"}
        new_id, error = game.join(body.get("name"), t, ident if known else None)
    if not new_id:
        return {"success": False, "error": error}
    save_players()
    log(f"Mitspieler: {game.players()[new_id]['name']}")
    return {"success": True, "id": new_id}


def phone_guess(body):
    t = now()
    ident = str(body.get("id") or "")
    year = body.get("year")
    lat, lon = body.get("lat"), body.get("lon")
    try:
        year = int(year) if year not in (None, "") else None
        lat = float(lat) if lat not in (None, "") else None
        lon = float(lon) if lon not in (None, "") else None
    except (TypeError, ValueError):
        return {"success": False, "error": "value"}
    with _game_lock:
        if ident not in game.players():
            return {"success": False, "error": "unknown"}
        if str(body.get("ident") or "") not in ("", str(game.ident)):
            return {"success": False, "error": "late"}
        ok = game.guess(ident, year, lat, lon, t)
    return {"success": ok, "error": "" if ok else "late"}


def phone_start(body):
    values = settings()
    ident = str(body.get("id") or "")
    with _game_lock:
        known = ident in game.players()
    if not known:
        return {"success": False, "error": "unknown"}
    if not values["PhoneStart"]:
        return {"success": False, "error": "off"}
    with _takeover_lock:
        _takeover.update(wanted=True, until=now() + values["QuizMinutes"] * 60, by=ident, retryAt=0.0, note="")
    log(f"{game.players()[ident]['name']} holt das Quiz auf den Rahmen ({values['QuizMinutes']} min).")
    _takeover_wake.set()
    return {"success": True}


def phone_end(body):
    ident = str(body.get("id") or "")
    with _game_lock:
        known = ident in game.players()
    if not known:
        return {"success": False, "error": "unknown"}
    with _takeover_lock:
        _takeover["wanted"] = False
    end_takeover("vom Handy beendet")
    return {"success": True}


def lan_address():
    probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        probe.connect(("10.255.255.255", 1))     # schickt nichts, sucht nur die Route
        return probe.getsockname()[0]
    except OSError:
        return ""
    finally:
        probe.close()


_lan = {"at": 0.0, "ip": ""}


def phone_url():
    if now() - _lan["at"] > 60:
        _lan.update(at=now(), ip=lan_address())
    if phone_server is None:
        return ""
    port = phone_server.server_address[1]
    host = _lan["ip"] or socket.gethostname()
    return f"http://{host}:{port}/"


# --------------------------------------------------------------------------
# Takeover: das Quiz vom Handy aus auf den Rahmen holen
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}
TAKEOVER_DESCRIPTION = ("Wird vom Plugin Photo Quiz abgespielt, wenn jemand das Quiz vom Handy aus startet. "
                        "Bleibt ausgeschaltet, damit es nicht im Quick Mix landet. "
                        "Das Plugin legt sie neu an, wenn sie gelöscht wird.")
TAKEOVER_ITEM_SECONDS = 12 * 3600
STATE_FILE = DATA_DIR / "state.json"

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "since": 0.0, "limit": 0, "wanted": False, "until": 0.0, "by": "",
             "note": "", "retryAt": 0.0, "busy": False, "playlistId": None, "playlistAt": 0.0}
_takeover_wake = threading.Event()


def load_state():
    stored = read_json(STATE_FILE, {})
    return stored if isinstance(stored, dict) else {}


def save_state(**fields):
    stored = load_state()
    stored.update(fields)
    write_json(STATE_FILE, stored)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def ensure_takeover_playlist(scene_db_id):
    """Ein Takeover spielt eine Playlist: die Szene allein, zwölf Stunden, ausgeschaltet."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = None
    if playlist_id:
        try:
            playlist = engine_call("GET", f"/playlists/{playlist_id}")
        except EngineError as exc:
            if exc.status != 404:
                raise
    if not playlist:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist and playlist_id:
        items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
        items = items.get("items") if isinstance(items, dict) else items
        items = [i for i in items or [] if isinstance(i, dict)]
        if len(items) == 1 and str(items[0].get("dynamicSceneId")) == str(scene_db_id):
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if playlist.get("name") != TAKEOVER_PLAYLIST_NAME:  # 0.1.0 hieß sie "Foto Quiz (takeover)"
                engine_call("PUT", f"/playlists/{playlist_id}", {"name": TAKEOVER_PLAYLIST_NAME})
            save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    created = engine_call("POST", "/playlists", {"name": TAKEOVER_PLAYLIST_NAME,
                                                 "description": TAKEOVER_DESCRIPTION}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=TAKEOVER_PLAYLIST_NAME))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": scene_db_id, "customDurationSeconds": TAKEOVER_ITEM_SECONDS})
    engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    save_state(takeoverPlaylistId=playlist_id)
    log(f"Playlist {TAKEOVER_PLAYLIST_NAME} angelegt ({playlist_id}).")
    return playlist_id


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    enabled = config.get("enabledPluginNames")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Photo Quiz auf der Plugins-Seite aus. Schalte es ein, "
                  "sonst kann das Handy das Quiz nicht starten.")
    return ""


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        log(text)
    return False


def _on_session_state(handle_or_state):
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _takeover.update(handle=None, since=0.0)
        if new_state != "expired":
            _takeover["wanted"] = False      # jemand anderes hat den Bildschirm genommen
    log(f"Der Rahmen hat das Quiz beendet: {new_state}.")
    if new_state != "expired":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason):
    with _takeover_lock:
        handle = _takeover["handle"]
        _takeover.update(handle=None, since=0.0)
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:  # noqa: BLE001
        log(f"Konnte den Bildschirm nicht zurückgeben: {exc}", "warning")
    log(f"Bildschirm zurückgegeben ({reason}).")
    if reason != "neu":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def show_quiz():
    scene = find_scene()
    if not scene:
        return _note(tr("Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal."))
    try:
        if not _takeover["playlistId"] or now() - _takeover["playlistAt"] > 600:
            _takeover.update(playlistId=ensure_takeover_playlist(scene["id"]), playlistAt=now())
    except EngineError as exc:
        return _note(tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc))
    playlist_id = _takeover["playlistId"]
    left = max(60, int(_takeover["until"] - now()))
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             "overlay": {"enabled": False}}
    handle, limit, last_error = None, 0, None
    for seconds in sorted({min(left + 60, 4 * 3600), min(left + 60, 3600), min(left + 60, 300)}, reverse=True):
        try:
            _leftover["askedAt"] = time.time()
            handle = plugin.acquire_display_session(
                session_key="quiz", state=state, display_name=DISPLAY_NAME,
                max_duration_seconds=seconds, wake_if_off=settings()["WakeScreen"])
            limit = seconds
            break
        except Exception as exc:  # noqa: BLE001
            last_error = exc
    if handle is None:
        if last_error is not None:
            return _note(tr("Konnte das Quiz nicht zeigen: {exc}", exc=last_error))
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    with _takeover_lock:
        _takeover.update(handle=handle, since=now(), limit=limit, note="")
    try:
        handle.on_state_change(_on_session_state)
    except Exception:  # noqa: BLE001
        pass
    try:
        if not handle.wait_until_active(timeout=15):
            end_takeover("fehlgeschlagen")
            return _note(tr("Der Rahmen hat das Quiz nicht rechtzeitig gezeigt."))
    except Exception as exc:  # noqa: BLE001
        end_takeover("fehlgeschlagen")
        return _note(tr("Konnte das Quiz nicht zeigen: {exc}", exc=exc))
    _scene["seen"] = max(_scene["seen"], now())   # Zeit, bis die Szene geladen ist
    log("Photo Quiz hat den Bildschirm.")
    return True


IDLE_END = 300   # so lange niemand mitspielt: das Quiz gibt den Bildschirm zurück


def decide_takeover():
    t = now()
    with _takeover_lock:
        wanted, until, handle = _takeover["wanted"], _takeover["until"], _takeover["handle"]
        since, limit, retry_at, busy = _takeover["since"], _takeover["limit"], _takeover["retryAt"], _takeover["busy"]
    if wanted and t >= until:
        wanted = False
        _takeover["wanted"] = False
        log("Quiz-Zeit abgelaufen.")
    if wanted and handle is not None and since and t - since > IDLE_END:
        with _game_lock:
            last = max(game.seen.values()) if game.seen else 0
        if t - last > IDLE_END:
            wanted = False
            _takeover["wanted"] = False
            log("Niemand spielt mehr mit, das Quiz gibt den Bildschirm zurück.")
    if handle is not None:
        if str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
            return
        if not wanted:
            end_takeover("fertig")
        elif limit and t - since >= limit - 20:
            end_takeover("neu")
        return
    if not wanted:
        stop_leftover_takeover()
        return
    if t < retry_at or busy:
        return
    _takeover["busy"] = True
    try:
        if not show_quiz():
            with _takeover_lock:
                _takeover["retryAt"] = t + 20
    finally:
        _takeover["busy"] = False


# ---- Takeover-Playlist, die nach dem Zurückgeben weiterläuft ---------------
# Lief vor einem Takeover keine Playlist, stellt die Engine dieses "nichts"
# nicht wieder her, und die Takeover-Playlist läuft einfach weiter (Jans
# Rahmen, 2026-10-24). Dann hält das Plugin sie mit POST /slideshow/stop an:
# nur wenn sie läuft, niemand den Bildschirm hält und das Plugin nicht
# gerade selbst darum gebeten hat.
_leftover = {"askedAt": 0.0, "failed": False, "checkedAt": 0.0}


def stop_leftover_takeover():
    if time.time() - _leftover["checkedAt"] < 15:
        return False
    _leftover["checkedAt"] = time.time()
    try:
        playlist_id = _takeover["playlistId"] or load_state().get("takeoverPlaylistId")
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status") or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status") or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop")
    except Exception as exc:  # noqa: BLE001 - darf die Schleife nie aufhalten
        if not _leftover["failed"]:
            log(f"The takeover playlist kept running and could not be stopped: {exc}", "warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def check_playback_resumed():
    if playback_guard is not None:
        try:
            playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log, stop_event=_stop_requested)
        except Exception as exc:  # noqa: BLE001
            log(f"playback_guard: {exc}", "warning")


# --------------------------------------------------------------------------
# Der Arbeitsfaden: Fotos einlesen
# --------------------------------------------------------------------------

def work_loop():
    while not _stop_requested.is_set():
        values = settings()
        try:
            due = now() - _index["at"] >= values["RefreshHours"] * 3600
            if due or _index["signature"] != index_signature(values):
                build_index("geplant" if due and _index["at"] else "Einstellungen")
                update_geo()
            if (_immich["signature"] != immich_signature(values) or now() - _immich["at"] > 3600
                    or (_immich["rows"] and sum(1 for r in _immich["rows"] if r["k"] in _recent_keys)
                        > len(_immich["rows"]) * 0.6)):
                refill_immich("Einstellungen" if _immich["signature"] != immich_signature(values) else "neue Auswahl")
                update_geo()
            if now() - _geo["at"] > 600:
                update_geo()
        except Exception as exc:  # noqa: BLE001 - der Faden darf nicht sterben
            log(f"Fehler: {exc!r}", "warning")
        _wake.wait(20)
        _wake.clear()


def reload_now():
    _work_stop.set()
    _index["at"] = 0.0
    _immich["signature"] = ""

    def later():
        time.sleep(1)
        _work_stop.clear()
        _wake.set()

    threading.Thread(target=later, daemon=True).start()
    return {"success": True, "message": tr("Die Fotos werden neu eingelesen.")}


# --------------------------------------------------------------------------
# Playlist für die Szene
# --------------------------------------------------------------------------

def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=PLAYLIST_NAMES.values(),
    name=lambda: PLAYLIST_NAMES.get(settings()["Language"], PLAYLIST_NAMES["en"]),
    description=lambda: tr("Ein Ratespiel mit deinen Fotos: Wann und wo war das?"),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
    held=lambda: _takeover["handle"] is not None,
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    status = {}
    for source in values["Sources"]:
        row = dict(_index["status"].get(source["id"]) or _immich["status"].get(source["id"]) or {})
        if (_index["busy"] or _immich["busy"]) and not row:
            row = {"state": "wait"}
        row["kind"] = source["kind"]
        status[source["id"]] = row
    rows = pool()
    t = now()
    with _game_lock:
        people = []
        for ident, person in game.players().items():
            people.append({"id": ident, "name": person["name"], "color": person["color"],
                           "games": person.get("games", 0), "wins": person.get("wins", 0),
                           "best": person.get("best", 0), "active": t - game.seen.get(ident, 0) <= quiz.ACTIVE_SECONDS,
                           "last": person.get("last", 0)})
        people.sort(key=lambda p: -p["last"])
        phase = game.phase
        played_round = game.round
    with _takeover_lock:
        note = _takeover["note"]
    home = _geo["home"]
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "status": status,
        "busy": _index["busy"] or _immich["busy"],
        "progress": _index["progress"],
        "indexAt": _index["at"],
        "photos": len(rows),
        "located": sum(1 for r in rows if r.get("lat") is not None),
        "years": pool_years(rows) if rows else None,
        "dfCount": _index.get("dfCount"),
        "undated": _index["undated"],
        "phase": phase,
        "round": played_round,
        "sceneVisible": scene_visible(t),
        "phoneUrl": phone_url(),
        "code": join_code(),
        "players": people,
        "home": list(home) if home else None,
        "homeAuto": _geo["auto"],
        "homePlace": sky.place(home[0], home[1], values["Language"], allow_fetch=False) if home else "",
        "scale": round(_geo["scale"], 1),
        "takeover": _takeover["handle"] is not None,
        "takeoverNote": note or (takeover_permission_note() if values["PhoneStart"] else ""),
        "heif": HEIF,
        "theme": {"id": theme_id()},
    }


def test_immich():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        info = immich.test()
    except sources.SourceError as exc:
        return {"success": True, "ok": False, "message": str(exc)}
    return {"success": True, "ok": True,
            "message": tr("Verbunden als {user} (Immich {version}).", user=info["user"] or "?",
                          version=info["version"] or "?")}


def list_albums():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, "albums": immich.albums()}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_immich(what):
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, what: getattr(immich_filters, what)(immich)}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_playlists():
    try:
        skip = set(PLAYLIST_NAMES.values()) | {TAKEOVER_PLAYLIST_NAME}
        rows = [p for p in dynaframe.playlists() if p["name"] not in skip]
        return {"success": True, "playlists": sorted(rows, key=lambda p: str(p["name"]).lower())}
    except EngineError as exc:
        return {"success": False, "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc)}


def search_place(query):
    name = re.sub(r"\s+", " ", (query.get("q") or [""])[0]).strip()[:80]
    if len(name) < 2:
        return {"success": True, "places": []}
    try:
        return {"success": True, "places": sky.search(name, settings()["Language"])}
    except weather.WeatherError as exc:
        return {"success": False, "error": tr("Die Ortssuche (Open-Meteo) antwortet nicht: {exc}", exc=exc)}


def remove_player(body):
    ident = str(body.get("id") or "")
    with _game_lock:
        if ident in game.players():
            del game.players()[ident]
            game.seen.pop(ident, None)
            game.scores.pop(ident, None)
            game.guesses.pop(ident, None)
    save_players()
    return {"success": True}


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
    "/qrcode.js": ("phone/qrcode.js", "application/javascript; charset=utf-8"),
}
PHONE_FILES = {
    "/phone.css": ("phone/phone.css", "text/css; charset=utf-8"),
    "/phone.js": ("phone/phone.js", "application/javascript; charset=utf-8"),
    "/quiztext.js": ("phone/quiztext.js", "application/javascript; charset=utf-8"),
    "/land.js": ("phone/land.js", "application/javascript; charset=utf-8"),
    "/leaflet/leaflet.js": ("phone/leaflet/leaflet.js", "application/javascript; charset=utf-8"),
    "/leaflet/leaflet.css": ("phone/leaflet/leaflet.css", "text/css; charset=utf-8"),
    "/icon.png": ("icon.png", "image/png"),
}


class BaseHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(min(length, 1024 * 1024)) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _photo(self, query):
        found = photo_bytes(query)
        if found is None:
            self._json({"success": False}, 404, cors=True)
        else:
            self._send(found, "image/jpeg", cache="private, max-age=3600", cors=True)


class StudioHandler(BaseHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/game":
                # Die Szene fragt jede Sekunde; daran merkt das Plugin, dass sie zu sehen ist.
                t = now()
                if not scene_visible(t):
                    _scene["first"] = t
                _scene["seen"] = t
                self._json(game_state(t, for_scene=True), cors=True)
                return
            if path == "/api/photo":
                self._photo(query)
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            if path == "/api/albums":
                self._json(list_albums())
                return
            if path in ("/api/people", "/api/tags"):
                self._json(list_immich(path.rsplit("/", 1)[1]))
                return
            if path == "/api/playlists":
                self._json(list_playlists())
                return
            if path == "/api/places":
                self._json(search_place(query))
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                for name in SECRETS:
                    # Ein leeres Feld heißt: das alte behalten. Löschen geht mit "-".
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)
                    elif name in body and str(body[name]).strip() == "-":
                        body[name] = ""
                changed = save_settings(body)
                if "MakePlaylist" in changed:
                    OWN.changed()
                if changed:
                    if any(n in changed for n in ("HomeLat", "HomeLon")):
                        update_geo()
                    if any(n in changed for n in ("Albums", "Sources", *immich_filters.SCHEMA,
                                                  *dynaframe_filters.SCHEMA, "GuessMode",
                                                  *("Hint" + k.capitalize() for k in HINT_KINDS))):
                        # Nichts Ausgefiltertes mehr zeigen: das vorbereitete Foto verwerfen
                        take_prepared()
                    _wake.set()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                take_prepared()
                self._json(reload_now())
                return
            if path == "/api/test":
                self._json(test_immich())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            if path == "/api/player/remove":
                self._json(remove_player(self._body()))
                return
            if path == "/api/start":
                # Von der Plugin-Seite: ohne Mitspieler-ID
                values = settings()
                with _takeover_lock:
                    _takeover.update(wanted=True, until=now() + values["QuizMinutes"] * 60, by="page",
                                     retryAt=0.0, note="")
                _takeover_wake.set()
                self._json({"success": True})
                return
            if path == "/api/end":
                with _takeover_lock:
                    _takeover["wanted"] = False
                end_takeover("von der Plugin-Seite beendet")
                self._json({"success": True})
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


def phone_html():
    html = (PLUGIN_DIR / "phone" / "index.html").read_text(encoding="utf-8")
    lang = settings()["Language"]
    return html.replace('<html lang="en">', f'<html lang="{lang}">', 1)


class PhoneHandler(BaseHandler):
    """Die Seite für die Handys, im ganzen WLAN erreichbar. Nur Spielen, keine Einstellungen."""

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if not settings()["PhonePlay"]:
                self._send(b"Photo Quiz: phone play is switched off.", "text/plain; charset=utf-8", 403)
                return
            if path in ("/", "/index.html"):
                self._send(phone_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = PHONE_FILES.get(path)
            if asset:
                cache = "public, max-age=86400" if path.startswith("/leaflet/") or path == "/land.js" else "no-store"
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1], cache=cache)
                return
            if path.startswith("/leaflet/images/") and re.match(r"^/leaflet/images/[a-z0-9-]+\.png$", path):
                self._send((PLUGIN_DIR / "phone" / path.lstrip("/")).read_bytes(), "image/png",
                           cache="public, max-age=86400")
                return
            if path == "/api/game":
                t = now()
                me = (query.get("id") or [""])[0]
                with _game_lock:
                    game.touch(me, t)
                self._json(game_state(t, me=me))
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError:
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if not settings()["PhonePlay"]:
                self._json({"success": False, "error": "off"}, 403)
                return
            body = self._body()
            handlers = {"/api/join": phone_join, "/api/guess": phone_guess,
                        "/api/start": phone_start, "/api/end": phone_end}
            handler = handlers.get(path)
            if handler is None:
                self._json({"success": False, "error": "Nicht gefunden"}, 404)
                return
            self._json(handler(body))
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None
phone_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    studio_server.daemon_threads = True
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


def start_phone():
    global phone_server
    wanted = os.environ.get("PHOTOQUIZ_PORT")
    for port in ([int(wanted)] if wanted else PHONE_PORTS):
        try:
            phone_server = ThreadingHTTPServer(("0.0.0.0", port), PhoneHandler)
            break
        except OSError as exc:
            log(f"Port {port} ist belegt ({exc}).", "warning")
    if phone_server is None:
        log("Kein freier Port für die Handy-Seite (8099 bis 8102).", "warning")
        return
    phone_server.daemon_threads = True
    threading.Thread(target=phone_server.serve_forever, name=f"{PLUGIN_ID}-phone", daemon=True).start()
    log(f"Handy-Seite: {phone_url()}")


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}" + ("" if HEIF else " (ohne HEIC-Unterstützung, HEIC über die Engine)"))
    load_game()

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: reload_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    start_phone()
    adopt_immich()
    try:
        os.nice(5)   # das Einlesen soll die Wiedergabe nicht stören
    except OSError:
        pass
    threading.Thread(target=work_loop, name=f"{PLUGIN_ID}-work", daemon=True).start()
    threading.Thread(target=game_loop, name=f"{PLUGIN_ID}-game", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _work_stop.set()
    _wake.set()
    end_takeover("gestoppt")
    try:
        exif_save()
        sky.save()
        save_players()
    except Exception:  # noqa: BLE001
        pass
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:  # noqa: BLE001
        pass
    for server in (studio_server, phone_server):
        if server is not None:
            try:
                server.shutdown()
                server.server_close()
            except Exception:  # noqa: BLE001
                pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
