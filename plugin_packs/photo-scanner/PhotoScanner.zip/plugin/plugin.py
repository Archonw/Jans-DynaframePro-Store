#!/usr/bin/env python3
"""Photo Scanner - der Plugin-Teil des Pakets.

Die Szene "photo-scanner" zeigt ein Foto nach dem anderen und "scannt" es wie
in einem Science-Fiction-Film: Auflösung, Kamera, Objektiv, Blende,
Belichtung, ISO, Aufnahmezeit, GPS-Position mit Ort, Farbspektrum,
Histogramm, Helligkeit, Kontrast, Schärfe, Farbtemperatur, Sterne, Tags und
(bei Immich) Personen. An den Rändern laufen Live-Werte des Rahmens mit:
CPU, Speicher, Netzwerk, Temperatur und die Größe der Mediathek.

Dieses Plugin
- sammelt die Fotos aus DynaFrame (Playlist, ganze Mediendatenbank, Ordner)
  oder von einem Immich-Server, mit den Filtern wie bei Photo Mosaic,
- liest zu jedem Foto EXIF und die Zeile der Mediendatenbank, verkleinert es
  passend zum Bildschirm und analysiert es dabei (scan.py). Die Szene holt
  immer schon das nächste Foto, während das aktuelle zu sehen ist,
- misst die Live-Werte (telemetry.py, nur /proc und /sys).
"""

import hashlib
import io
import json
import math
import os
import random
import re
import sys
import threading
import time
import uuid
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, unquote, urlparse


def _await_dependencies():
    """Nach einem Update baut DynaFrame das venv (requests, Pillow) neu auf und
    startet das Plugin manchmal schon, bevor pip fertig ist. Dann nicht mit
    Exit 1 aufgeben (die Engine startet nicht neu), sondern warten und den
    Prozess frisch starten, bis die Pakete da sind (höchstens etwa 10 Minuten)."""
    try:
        import requests  # noqa: F401
        import PIL  # noqa: F401
        return
    except ImportError as error:
        tries = int(os.environ.get("PS_DEP_TRIES", "0"))
        if tries >= 40:
            raise
        sys.stderr.write(f"PhotoScanner: {error}; warte auf die Installation der Pakete ({tries + 1}/40)\n")
        sys.stderr.flush()
        time.sleep(15)
        os.environ["PS_DEP_TRIES"] = str(tries + 1)
        os.execv(sys.executable, [sys.executable] + sys.argv)


_await_dependencies()
import requests  # noqa: E402


def _crash_hook(kind, value, tb):
    """Jeden Absturz (auch beim Laden) nach data/last_crash.txt schreiben: die Engine speichert stderr nirgends."""
    import traceback
    try:
        path = Path(__file__).resolve().parent / "data" / "last_crash.txt"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(time.strftime("%Y-%m-%d %H:%M:%S\n") + "".join(traceback.format_exception(kind, value, tb)),
                        encoding="utf-8")
    except Exception:
        pass
    sys.__excepthook__(kind, value, tb)


sys.excepthook = _crash_hook

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import dynaframe_filters  # noqa: E402
import immich_filters  # noqa: E402
import own_playlist  # noqa: E402
import palette  # noqa: E402
import scan as scanner  # noqa: E402
import sources  # noqa: E402
import telemetry  # noqa: E402
import texts  # noqa: E402

plugin = create_plugin()

PLUGIN_ID = "PhotoScanner"
SCENE_ID = "photo-scanner"          # id in scene.dynamic - nie ändern
PLAYLIST_NAME = "Photo Scanner"     # in allen Sprachen englisch (Jans Regel, 12.11.2026)
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen, Stand; bleibt bei Updates

CONNECT_TIMEOUT = 10
MAX_SOURCES = 6
MAX_EDGE = 3840                     # größer wird kein Foto ausgeliefert (4K)
PREPARED_KEEP = 6                   # so viele vorbereitete Fotos hält das Plugin im Speicher

KINDS = ("library", "playlist", "immich_all", "immich_album")
ACCENTS = ("cyan", "amber", "green", "magenta", "white", "photo")
COORDINATES = ("exact", "rounded", "hidden")
PHOTO_ORDERS = ("random", "newest", "oldest")
USER_AGENT = "DynaFrame-PhotoScanner (+https://github.com/Archonw/Jans-DynaframePro-Store)"


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält den API-Schlüssel
        except OSError:
            pass


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

def default_sources():
    return [{"id": "s1", "kind": "library", "ref": "", "name": ""}]


SCHEMA = {
    "Language":        {"kind": "choice", "default": "en", "choices": texts.LANGUAGES},
    "ServerUrl":       {"kind": "url", "default": ""},
    "ApiKey":          {"kind": "secret", "default": ""},
    "Sources":         {"kind": "sources", "default": None},
    # Immich- und DynaFrame-Filter wie Photo Mosaic (alle Gruppen)
    **immich_filters.schema(),
    **dynaframe_filters.schema(),
    "Accent":          {"kind": "choice", "default": "cyan", "choices": ACCENTS},
    "Telemetry":       {"kind": "bool", "default": True},
    "Coordinates":     {"kind": "choice", "default": "exact", "choices": COORDINATES},
    "PlaceLookup":     {"kind": "bool", "default": True},
    "ShowFileName":    {"kind": "bool", "default": False},
    "ScanEffect":      {"kind": "bool", "default": True},
    "PhotoSeconds":    {"kind": "int", "default": 25, "min": 8, "max": 3600},
    "PhotoOrder":      {"kind": "choice", "default": "random", "choices": PHOTO_ORDERS},
    "Folders":         {"kind": "folders", "default": ""},
    # Optional: Originale direkt vom WebDAV-Speicher (wie Photo Mosaic)
    "WebDavUrl":       {"kind": "url", "default": ""},
    "WebDavUser":      {"kind": "name", "default": ""},
    "WebDavPassword":  {"kind": "secret", "default": ""},
    "RefreshHours":    {"kind": "int", "default": 6, "min": 1, "max": 168},
    "PlaylistSeconds": {"kind": "int", "default": 300, "min": 10, "max": 86400},
    "MakePlaylist":    {"kind": "bool", "default": False},
}
SECRETS = [name for name, spec in SCHEMA.items() if spec["kind"] == "secret"]
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()


def coerce_sources(raw):
    if raw is None:
        return default_sources()
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return default_sources()
    out, ids = [], set()
    for row in raw if isinstance(raw, list) else []:
        if not isinstance(row, dict) or len(out) >= MAX_SOURCES:
            continue
        ident = re.sub(r"[^A-Za-z0-9]", "", str(row.get("id") or ""))[:16] or uuid.uuid4().hex[:8]
        while ident in ids:
            ident = uuid.uuid4().hex[:8]
        ids.add(ident)
        out.append({
            "id": ident,
            "kind": row.get("kind") if row.get("kind") in KINDS else "library",
            # Immich-Alben: mehrere IDs mit Komma (wie bei Growing Up)
            "ref": ",".join(dict.fromkeys(p for p in (re.sub(r"[^A-Za-z0-9_-]", "", part)[:64]
                                                      for part in str(row.get("ref") or "").split(",")) if p))[:2000],
            "name": re.sub(r"\s+", " ", str(row.get("name") or "")).strip()[:60],
        })
    return out


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind in ("ref", "date", "name"):
        return immich_filters.coerce(spec, raw)
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "choice":
        value = str(raw if raw is not None else "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "sources":
        return coerce_sources(raw)
    if kind == "url":
        return sources.normalize_url(raw)[:300]
    if kind == "text":
        return re.sub(r"\s+", " ", str(raw or "")).strip()[:60]
    if kind == "folders":
        lines = [line.strip() for line in str(raw or "").replace(";", "\n").splitlines()]
        return "\n".join(line for line in lines if line.startswith("/"))[:2000]
    if name == "WebDavPassword":   # Passwörter dürfen Leerzeichen enthalten
        return str(raw or "").strip()[:400]
    return re.sub(r"\s+", "", str(raw or ""))[:400]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 120))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def engine_image(media_id, path=""):
    """Das Vorschaubild, das die Engine für die Weboberfläche erzeugt (auf Jans Rahmen 512 Pixel)."""
    candidates = []
    if path:
        candidates += [("/media/thumbnail", {"path": path, "purpose": "preview"}),
                       ("/media/thumbnail", {"path": path})]
    if media_id:
        candidates += [(f"/media/thumbnail/{media_id}", {"purpose": "preview"}),
                       (f"/media/thumbnail/{media_id}", None)]
    failures = []
    for route, params in candidates:
        try:
            response = requests.get(f"{engine_base()}{route}", params=params, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 60))
        except requests.RequestException as exc:
            failures.append(f"{route}: {exc}")
            continue
        kind = response.headers.get("Content-Type", "").split(";")[0]
        if response.status_code == 200 and kind.startswith("image/"):
            return response.content
        failures.append(f"{route}{'?path' if params and 'path' in params else ''}: HTTP {response.status_code} {kind}")
    raise sources.SourceError(f"Vorschaubild {media_id}: " + "; ".join(failures))


# --------------------------------------------------------------------------
# Die Fotos (Liste aus den Quellen)
# --------------------------------------------------------------------------

immich = sources.Immich(tr)
dynaframe = sources.DynaFrame(engine_call, EngineError, log)

# Die Mediendatenbank wird je Einlesen nur einmal geholt, auch wenn Quelle, Filter
# und der Index für die Foto-Daten sie alle brauchen.
_db_rows = {"at": 0.0, "rows": []}
_db_rows_lock = threading.Lock()
_engine_library_rows = dynaframe.library_rows


def _library_rows_once(stop):
    with _db_rows_lock:
        if now() - _db_rows["at"] < 300:
            return _db_rows["rows"]
        rows = _engine_library_rows(stop)
        _db_rows.update(at=now(), rows=rows)
        return rows


dynaframe.library_rows = _library_rows_once

# Index der Mediendatenbank: Kamera, Ort, Sterne … je Foto (Schlüssel: id und Pfad)
DB_FILE = DATA_DIR / "library.json"
_db = {"byId": {}, "byPath": {}, "stats": {}}


def build_db_index(rows):
    by_id, by_path = {}, {}
    photos = videos = located = 0
    total_bytes = 0
    cameras, years = set(), []
    for row in rows:
        path = sources._find(row, sources.PATH_KEYS)
        kind = str(sources._find(row, sources.TYPE_KEYS) or "").lower()
        meta = scanner.from_db(row)
        size = meta.get("bytes") or 0
        total_bytes += size if isinstance(size, int) else 0
        if "video" in kind or Path(str(path or "")).suffix.lower() in VIDEO_EXT:
            videos += 1
            continue
        if not sources._is_photo(row, path):
            continue
        photos += 1
        if meta.get("lat") is not None:
            located += 1
        if meta.get("camera"):
            cameras.add(meta["camera"].lower())
        if meta.get("taken"):
            years.append(meta["taken"][:4])
        if row.get("id") is not None:
            by_id[str(row["id"])] = meta
        if path:
            by_path[str(path)] = meta
    stats = {"photos": photos, "videos": videos, "bytes": total_bytes, "located": located,
             "cameras": len(cameras), "first": min(years) if years else "", "last": max(years) if years else "",
             "at": now()}
    return by_id, by_path, stats


def refresh_db_index(stop):
    try:
        rows = dynaframe.library_rows(stop)
    except EngineError as exc:
        log(f"Mediendatenbank nicht lesbar: {exc}", "warning")
        return
    if not rows:
        return
    by_id, by_path, stats = build_db_index(rows)
    _db.update(byId=by_id, byPath=by_path, stats=stats)
    try:
        write_json(DB_FILE, {"byId": by_id, "byPath": by_path, "stats": stats})
    except OSError as exc:
        log(f"Konnte {DB_FILE.name} nicht schreiben: {exc}", "warning")


def load_db_index():
    stored = read_json(DB_FILE, {})
    if isinstance(stored, dict) and isinstance(stored.get("byId"), dict):
        _db.update(byId=stored["byId"], byPath=stored.get("byPath") or {}, stats=stored.get("stats") or {})


def db_meta(key):
    if key.startswith("d:"):
        media_id, _, path = key[2:].partition("|")
        return _db["byId"].get(media_id) or _db["byPath"].get(path) or {}
    if key.startswith("f:"):
        return _db["byPath"].get(key[2:]) or {}
    return {}

LIST_FILE = DATA_DIR / "photos.json"
_scan_lock = threading.Lock()
_scan_wake = threading.Event()
_stop_requested = threading.Event()
_scan_stop = threading.Event()
_data = {
    "ver": 0,
    "photos": [],         # [key, taken, size]
    "status": {},         # source id -> {state, total, error, at}
    "busy": False, "at": 0.0, "signature": "",
    "progress": {"done": 0, "phase": ""},
    "dfCount": None,
}


def scan_signature(values):
    wanted = [(s["id"], s["kind"], s["ref"]) for s in values["Sources"]]
    # Nur ein Hash wird gespeichert: im Klartext stünde der Immich-Schlüssel in der Datei.
    text = json.dumps([wanted, values["ServerUrl"], values["ApiKey"], values["Folders"],
                       immich_filters.signature(values), dynaframe_filters.signature(values), version()],
                      sort_keys=True)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def collect(source, values, stop, match=None):
    kind = source["kind"]
    if kind in ("immich_all", "immich_album"):
        immich.configure(values["ServerUrl"], values["ApiKey"])
        albums = [a for a in source["ref"].split(",") if a] if kind == "immich_album" else None
        if kind == "immich_album" and not albums:
            raise sources.SourceError(tr("Wähle ein Album."))
        return immich.photos(albums, stop, lambda n: _data["progress"].update(phase="list", done=n),
                             immich_filters.from_settings(values))
    if kind == "playlist":
        if not source["ref"]:
            raise sources.SourceError(tr("Wähle eine Playlist."))
        try:
            rows, total = dynaframe.playlist(source["ref"], stop)
        except EngineError as exc:
            if exc.status == 404:
                raise sources.SourceError(tr("Die Playlist gibt es nicht mehr.")) from exc
            raise sources.SourceError(tr("DynaFrame antwortet nicht: {exc}", exc=exc)) from exc
    else:
        folders = [f for f in values["Folders"].splitlines() if f]
        try:
            rows, total = dynaframe.library(folders, stop, lambda n: _data["progress"].update(phase="list", done=n))
        except EngineError as exc:
            raise sources.SourceError(tr("DynaFrame antwortet nicht: {exc}", exc=exc)) from exc
    if match is not None:
        rows = [r for r in rows if match.keep(r[1])]
    return rows, total


def scan(reason=""):
    """Alle Quellen einlesen (nur die Liste, keine Bilder). Läuft im Hintergrund."""
    values = settings()
    with _scan_lock:
        if _data["busy"]:
            return
        _data["busy"] = True
        _scan_stop.clear()
    _data["progress"] = {"done": 0, "phase": "list"}
    log(f"Lese die Fotos ein{' - ' + reason if reason else ''}.")
    started = now()
    rows, status = {}, {}
    match = None
    if dynaframe_filters.active(values) and any(s["kind"] in ("library", "playlist") for s in values["Sources"]):
        match = dynaframe_filters.Matcher(values, lambda: dynaframe.library_rows(_scan_stop),
                                          cache_file=str(DATA_DIR / "file_meta.json"), log=log)
    try:
        for source in values["Sources"]:
            sid = source["id"]
            _data["status"][sid] = dict(_data["status"].get(sid) or {}, state="busy")
            try:
                found, total = collect(source, values, _scan_stop, match)
                for row in found:
                    rows.setdefault(row[1], row)
                status[sid] = {"state": "ok", "total": total, "used": len(found), "error": "", "at": now()}
            except (sources.SourceError, EngineError) as exc:
                status[sid] = {"state": "error", "total": 0, "used": 0, "error": str(exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except Exception as exc:  # pragma: no cover - darf den Durchlauf nicht beenden
                status[sid] = {"state": "error", "total": 0, "used": 0, "error": str(exc)[:200], "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc!r}", "warning")
            _data["status"][sid] = status[sid]
            if _scan_stop.is_set() or _stop_requested.is_set():
                break
        if not (_scan_stop.is_set() or _stop_requested.is_set()):
            refresh_db_index(_scan_stop)    # auch für die Mediathek-Zahlen der Szene
        if match is not None:
            match.save()
        _data["dfCount"] = match.counts() if match is not None else None
        if _scan_stop.is_set() or _stop_requested.is_set():
            log("Einlesen abgebrochen.")
            return
        photos = []
        for taken, key, _job, stamp in rows.values():
            size = str(stamp).split(":")[0] if key.startswith("d:") else ""
            photos.append([key, taken or "", size])
        with _scan_lock:
            _data.update(photos=photos, status=status, ver=_data["ver"] + 1, at=now(),
                         signature=scan_signature(values))
            _order["bag"] = []
        write_json(LIST_FILE, {"photos": photos, "status": status, "at": _data["at"],
                               "signature": _data["signature"]})
        log(f"{len(photos)} Fotos gefunden ({now() - started:.0f} s).")
    finally:
        _data["progress"] = {"done": 0, "phase": ""}
        with _scan_lock:
            _data["busy"] = False


def load_list():
    stored = read_json(LIST_FILE, {})
    if isinstance(stored, dict) and isinstance(stored.get("photos"), list):
        _data.update(photos=[p for p in stored["photos"] if isinstance(p, list) and len(p) == 3],
                     status=stored.get("status") or {}, at=stored.get("at") or 0.0,
                     signature=stored.get("signature") or "", ver=1)


def scan_loop():
    while not _stop_requested.is_set():
        values = settings()
        due = now() - _data["at"] >= values["RefreshHours"] * 3600
        if due or _data["signature"] != scan_signature(values):
            scan("geplant" if due else "Einstellungen")
        _scan_wake.wait(60)
        _scan_wake.clear()


def rescan_now():
    if _data["busy"]:
        _scan_stop.set()
    _data["at"] = 0.0
    _scan_wake.set()
    return {"success": True, "message": tr("Die Fotos werden neu eingelesen.")}


# --------------------------------------------------------------------------
# Das nächste Foto: auswählen, verkleinern, Palette rechnen
# --------------------------------------------------------------------------

PHOTO_MAX = 40 * 1024 * 1024
VIDEO_EXT = {".mp4", ".mov", ".m4v", ".mkv", ".avi", ".webm", ".mts", ".m2ts", ".3gp", ".wmv"}
SHOWABLE = (".jpg", ".jpeg", ".jpe", ".png", ".webp", ".gif", ".bmp", ".tif", ".tiff")


def heif_ready():
    try:
        import pillow_heif
        pillow_heif.register_heif_opener()
        return True
    except Exception:
        return False


HEIF = heif_ready()
if HEIF:
    SHOWABLE += (".heic", ".heif")

_order = {"bag": [], "pos": 0, "recent": []}
_prepared = OrderedDict()      # token -> {jpeg, ...}
_prepared_lock = threading.Lock()
_prepare_lock = threading.Lock()   # immer nur ein Foto auf einmal (Pi schonen)
_last = {"scan": "", "at": 0.0}


def summary(found):
    """Eine Zeile für die Plugin-Seite: Kamera · Blende · Ort."""
    meta = found.get("meta") or {}
    parts = [meta.get("camera") or "",
             f"f/{meta['fnumber']:g}" if meta.get("fnumber") else "",
             f"ISO {meta['iso']}" if meta.get("iso") else "",
             meta.get("place") or "",
             f"{meta['mp']:g} MP" if meta.get("mp") else ""]
    return " · ".join(p for p in parts if p)[:160]


def webdav_dirs():
    seen = []
    for home in (Path.home(), Path("/home/pi")):
        folder = home / ".local/share/dfr/webdav-cache"
        if folder not in seen and folder.is_dir():
            seen.append(folder)
    return seen


_webdav = {"at": 0.0, "index": {}}
_webdav_lock = threading.Lock()


def webdav_cached(path, size):
    """Fotos aus WebDAV (/webdav-media/<Quelle>/...) liefert die Engine nur als
    512-Pixel-Vorschau. Das Original legt DynaFrame aber teils in webdav-cache
    ab, als <Quelle>-<Hash>.<Endung>. Den Hash kennen wir nicht, also: gleiche
    Quelle, gleiche Endung, gleiche Dateigröße (wie Photo Mosaic). Das
    Verzeichnis wird nur alle 10 Minuten einmal gelesen."""
    if not path.startswith("/webdav-media/"):
        return None
    size = as_int(size, 0)
    if size <= 0 or size > PHOTO_MAX:
        return None
    with _webdav_lock:
        if now() - _webdav["at"] > 600:
            index = {}
            for folder in webdav_dirs():
                try:
                    entries = list(os.scandir(folder))
                except OSError:
                    continue
                for entry in entries:
                    try:
                        info = entry.stat()
                    except OSError:
                        continue
                    source = entry.name.split("-", 1)[0]
                    key = (source, Path(entry.name).suffix.lower(), info.st_size)
                    old = index.get(key)
                    if old is None or info.st_mtime > old[0]:
                        index[key] = (info.st_mtime, entry.path)
            _webdav.update(at=now(), index=index)
        parts = path.split("/")
        source = parts[2] if len(parts) > 2 else ""
        found = _webdav["index"].get((source, Path(path).suffix.lower(), size))
    return Path(found[1]) if found else None


_original_note = {"at": 0.0}


def webdav_original(path):
    """Das Original direkt aus dem WebDAV-Speicher (z. B. Nextcloud), mit
    eigenen Zugangsdaten aus den Einstellungen; DynaFrame gibt Plugins nur
    Vorschaubilder. /webdav-media/<Quelle>/<Pfad> -> <WebDavUrl>/<Pfad>."""
    values = settings()
    base, user, password = values["WebDavUrl"], values["WebDavUser"], values["WebDavPassword"]
    if not (base and user and password) or not path.startswith("/webdav-media/"):
        return None
    parts = path.split("/", 3)
    if len(parts) < 4 or not parts[3]:
        return None
    relative = parts[3]
    url = base.rstrip("/") + "/" + quote(relative, safe="/")
    try:
        with requests.get(url, auth=(user, password), stream=True, timeout=(CONNECT_TIMEOUT, 120)) as response:
            if response.status_code != 200:
                raise sources.SourceError(f"HTTP {response.status_code}")
            data = bytearray()
            for chunk in response.iter_content(256 * 1024):
                data.extend(chunk)
                if len(data) > PHOTO_MAX:
                    raise sources.SourceError("zu groß")
            return bytes(data)
    except Exception as exc:
        if now() - _original_note["at"] > 300:   # nicht bei jedem Foto ins Log
            _original_note["at"] = now()
            log(f"WebDAV-Original nicht geladen ({Path(relative).name}): {str(exc)[:160]}", "warning")
        return None


def test_webdav():
    values = settings()
    base, user, password = values["WebDavUrl"], values["WebDavUser"], values["WebDavPassword"]
    if not (base and user and password):
        return {"success": True, "ok": False, "message": tr("Adresse, Benutzer und Passwort fehlen noch.")}
    try:
        response = requests.request("PROPFIND", base.rstrip("/") + "/", auth=(user, password),
                                    headers={"Depth": "0"}, timeout=(CONNECT_TIMEOUT, 30))
    except requests.RequestException as exc:
        return {"success": True, "ok": False, "message": str(exc)[:200]}
    if response.status_code in (200, 207):
        return {"success": True, "ok": True, "message": tr("Verbunden. Fotos kommen jetzt in voller Auflösung.")}
    if response.status_code in (401, 403):
        return {"success": True, "ok": False, "message": tr("Benutzer oder Passwort stimmt nicht (HTTP {status}).",
                                                             status=response.status_code)}
    return {"success": True, "ok": False, "message": tr("Der Server antwortet mit HTTP {status}.",
                                                         status=response.status_code)}


_webdav_guess = {"at": 0.0, "value": None}


def webdav_guess():
    """Adresse und Benutzer der WebDAV-Quelle von DynaFrame, zum Vorausfüllen."""
    if now() - _webdav_guess["at"] < 600:
        return _webdav_guess["value"]
    _webdav_guess["at"] = now()
    found = None
    try:
        rows = engine_call("GET", "/media/webdav/sources")
    except Exception:
        rows = None
    stack = [rows]
    while stack and not found:
        item = stack.pop()
        if isinstance(item, list):
            stack.extend(item)
        elif isinstance(item, dict):
            lower = {str(k).lower(): v for k, v in item.items()}
            url = next((v for k, v in lower.items() if "url" in k and isinstance(v, str) and v.startswith("http")), "")
            user = next((v for k, v in lower.items() if "user" in k and isinstance(v, str)), "")
            if url:
                found = {"url": url, "user": user}
            else:
                stack.extend(item.values())
    _webdav_guess["value"] = found
    return found


def original_bytes(key, size):
    """Die Bytes des Fotos in möglichst guter Auflösung und woher sie kommen."""
    if key.startswith("i:"):
        values = settings()
        immich.configure(values["ServerUrl"], values["ApiKey"])
        return immich.photo(key[2:], size="preview")[0], "immich"
    path = key.partition("|")[2] if key.startswith("d:") else key[2:]
    if path and path.lower().endswith(SHOWABLE) and os.path.isfile(path):
        with open(path, "rb") as handle:
            return handle.read(PHOTO_MAX), "file"
    if path:
        cached = webdav_cached(path, size)
        if cached:
            with open(cached, "rb") as handle:
                return handle.read(PHOTO_MAX), "file"
        original = webdav_original(path)
        if original:
            return original, "file"
    if key.startswith("d:"):
        return engine_image(key[2:].partition("|")[0], path), "preview"
    raise sources.SourceError("Datei nicht gefunden")


# --------------------------------------------------------------------------
# Ortsnamen zu GPS-Positionen (OpenStreetMap Nominatim, freiwillig, mit Cache)
# --------------------------------------------------------------------------

PLACES_FILE = DATA_DIR / "places.json"
_places = {"cache": None, "last": 0.0, "state": "", "error": "", "at": 0.0}
_places_lock = threading.Lock()


def place_lookup_allowed(values):
    """Ortsnamen nur online nachschlagen, wenn es eingeschaltet ist und die GPS-Koordinaten nicht
    ausgeblendet sind: Wer „Ausgeblendet“ wählt, erwartet, dass keine Position den Rahmen verlässt."""
    return bool(values["PlaceLookup"]) and values["Coordinates"] != "hidden"


def place_name(lat, lon, lang):
    """„Stadt, Land“ zu einer Position. Höchstens eine Anfrage je Sekunde, jede Position nur einmal."""
    if not place_lookup_allowed(settings()):
        return ""
    key = f"{lat:.3f},{lon:.3f},{lang}"
    with _places_lock:
        if _places["cache"] is None:
            stored = read_json(PLACES_FILE, {})
            _places["cache"] = stored if isinstance(stored, dict) else {}
        if key in _places["cache"]:
            return _places["cache"][key]
        if _places["state"] == "bad" and now() - _places["at"] < 600:
            return ""    # nach einem Fehler 10 Minuten Ruhe, sonst wartet jedes Foto auf den Timeout
        wait = 1.1 - (now() - _places["last"])
        if wait > 0:
            time.sleep(wait)
        _places["last"] = now()
        try:
            response = requests.get("https://nominatim.openstreetmap.org/reverse",
                                    params={"format": "jsonv2", "lat": f"{lat:.5f}", "lon": f"{lon:.5f}",
                                            "zoom": 12, "accept-language": lang},
                                    headers={"User-Agent": f"{USER_AGENT} {version()}"},
                                    timeout=(CONNECT_TIMEOUT, 8))
            response.raise_for_status()
            data = response.json() or {}
        except (requests.RequestException, ValueError) as exc:
            _places.update(state="bad", error=str(exc)[:160], at=now())
            return ""
        address = data.get("address") if isinstance(data.get("address"), dict) else {}
        town = next((address.get(k) for k in ("city", "town", "village", "municipality", "hamlet", "suburb",
                                               "county", "state") if address.get(k)), "")
        name = ", ".join(p for p in (town, address.get("country")) if p) or str(data.get("name") or "")
        name = re.sub(r"\s+", " ", name).strip()[:80]
        _places["cache"][key] = name
        if len(_places["cache"]) > 5000:
            for old in list(_places["cache"])[:1000]:
                _places["cache"].pop(old, None)
        _places.update(state="ok", error="", at=now())
        try:
            write_json(PLACES_FILE, _places["cache"])
        except OSError:
            pass
        return name


# --------------------------------------------------------------------------
# Ein Foto scannen
# --------------------------------------------------------------------------

_immich_meta = OrderedDict()


def immich_meta(asset_id):
    if asset_id in _immich_meta:
        return _immich_meta[asset_id]
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        meta = scanner.from_immich(immich.call("GET", f"/assets/{asset_id}") or {})
    except sources.SourceError as exc:
        log(f"Immich-Daten zu {asset_id}: {exc}", "warning")
        meta = {}
    _immich_meta[asset_id] = meta
    while len(_immich_meta) > 200:
        _immich_meta.popitem(last=False)
    return meta


def prepare(key, taken, size, box_w, box_h, values):
    """Foto holen, Daten lesen, drehen, auf den Bildschirm verkleinern, analysieren."""
    from PIL import Image, ImageOps

    started = now()
    data, origin = original_bytes(key, size)
    with Image.open(io.BytesIO(data)) as image:
        file_w, file_h = image.size
        file_format = str(image.format or "").upper()
        info = scanner.exif(image)
        if info.get("orientation") in (5, 6, 7, 8):
            file_w, file_h = file_h, file_w
        try:
            image.draft("RGB", (box_w, box_h))       # JPEG gleich verkleinert dekodieren
        except (AttributeError, ValueError, OSError):
            pass
        image = ImageOps.exif_transpose(image)
        image = image.convert("RGB")
        image.thumbnail((box_w, box_h), Image.LANCZOS if max(image.size) < 4000 else Image.BILINEAR)
        colours = palette.from_image(image, 6, "share")
        measured = scanner.metrics(image)
        out = io.BytesIO()
        image.save(out, "JPEG", quality=88, optimize=False, progressive=False)
        jpeg = out.getvalue()
        shown_w, shown_h = image.width, image.height

    extra = immich_meta(key[2:]) if key.startswith("i:") else db_meta(key)
    meta = scanner.merge(info, extra)
    if origin == "file":
        meta["w"], meta["h"], meta["bytes"] = file_w, file_h, len(data)
        meta["format"] = file_format
    else:
        # Nur ein Vorschaubild: Größe aus der Datenbank, sonst unbekannt
        meta.pop("orientation", None)
    if not meta.get("taken") and taken:
        meta["taken"] = taken
    path = key.partition("|")[2] if key.startswith("d:") else key[2:] if key.startswith("f:") else ""
    if path:
        meta.setdefault("file", Path(path).name[:80])
        suffix = Path(path).suffix.lower().lstrip(".")
        if suffix and not meta.get("format"):
            meta["format"] = {"jpg": "JPEG", "jpeg": "JPEG", "tif": "TIFF"}.get(suffix, suffix.upper())
    meta["source"] = "immich" if key.startswith("i:") else ("webdav" if path.startswith("/webdav-media/") else "dynaframe")

    lat, lon = meta.get("lat"), meta.get("lon")
    if values["Coordinates"] == "rounded" and lat is not None and lon is not None:
        lat, lon = round(lat, 2), round(lon, 2)   # auch OpenStreetMap bekommt nur die gerundete Position
    if values["Coordinates"] == "hidden":
        for name in ("lat", "lon", "alt", "heading", "speed"):
            meta.pop(name, None)
    elif values["Coordinates"] == "rounded" and lat is not None:
        meta["lat"], meta["lon"] = round(lat, 2), round(lon, 2)
        meta.pop("alt", None)
    if not meta.get("place") and lat is not None and lon is not None and place_lookup_allowed(values):
        meta["place"] = place_name(lat, lon, values["Language"])
    if not values["ShowFileName"]:
        meta.pop("file", None)

    mp = (meta.get("w") or 0) * (meta.get("h") or 0) / 1e6
    meta["mp"] = round(mp, 1) if mp else None
    meta["aspect"] = scanner.aspect(meta.get("w"), meta.get("h"))
    if meta.get("exposure") and meta.get("fnumber") and meta.get("iso"):
        # Belichtungswert, auf ISO 100 bezogen
        ev = math.log2(meta["fnumber"] ** 2 / meta["exposure"]) - math.log2(meta["iso"] / 100.0)
        meta["ev"] = round(ev, 1)
    scan_id = measured.pop("hash")
    return {"jpeg": jpeg, "w": shown_w, "h": shown_h,
            "scan": {"id": scan_id, "meta": meta, "palette": colours, "image": measured,
                     "ms": int((now() - started) * 1000)}}


def next_key():
    photos = _data["photos"]
    if not photos:
        return None
    mode = settings()["PhotoOrder"]
    if mode in ("newest", "oldest"):
        ordered = sorted(range(len(photos)), key=lambda i: photos[i][1] or "0000", reverse=(mode == "newest"))
        pick = ordered[_order["pos"] % len(ordered)]
        _order["pos"] += 1
        return photos[pick]
    if not _order["bag"]:
        bag = list(range(len(photos)))
        random.shuffle(bag)
        # Das gerade gezeigte nicht gleich wieder vorne
        recent = set(_order["recent"])
        bag.sort(key=lambda i: photos[i][0] in recent)
        _order["bag"] = bag
    idx = _order["bag"].pop()
    return photos[idx] if idx < len(photos) else None


def next_photo(query):
    """Das nächste Foto für die Szene vorbereiten. Bis zu 6 Versuche, falls Fotos fehlen."""
    box_w = max(320, min(MAX_EDGE, as_int((query.get("w") or ["1920"])[0], 1920)))
    box_h = max(240, min(MAX_EDGE, as_int((query.get("h") or ["1080"])[0], 1080)))
    values = settings()
    with _prepare_lock:
        errors = []
        for _attempt in range(6):
            with _scan_lock:
                row = next_key()
            if row is None:
                return {"success": False, "empty": True, "busy": _data["busy"]}
            key, taken, size = row
            try:
                done = prepare(key, taken, size, box_w, box_h, values)
            except Exception as exc:  # noqa: BLE001 - ein kaputtes Foto darf die Szene nicht aufhalten
                errors.append(str(exc)[:160])
                continue
            token = uuid.uuid4().hex[:16]
            with _prepared_lock:
                _prepared[token] = done
                while len(_prepared) > PREPARED_KEEP:
                    _prepared.popitem(last=False)
            _order["recent"] = (_order["recent"] + [key])[-20:]
            _last.update(scan=summary(done["scan"]), at=now())
            return {"success": True, "id": token, "w": done["w"], "h": done["h"], "scan": done["scan"],
                    "ver": _data["ver"]}
        for text in errors[:3]:
            log(f"Foto für die Szene: {text}", "warning")
        return {"success": False, "error": errors[-1] if errors else ""}


def photo_bytes(query):
    token = (query.get("id") or [""])[0]
    with _prepared_lock:
        done = _prepared.get(token)
    return done["jpeg"] if done else None


# --------------------------------------------------------------------------
# Playlist für die Szene
# --------------------------------------------------------------------------

def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=(PLAYLIST_NAME,),
    name=lambda: PLAYLIST_NAME,
    description=lambda: tr("Deine Fotos, gescannt wie im Science-Fiction-Film."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()


# --------------------------------------------------------------------------
# Was die Szene bekommt
# --------------------------------------------------------------------------

SCENE_SETTINGS = ("Language", "Accent", "Telemetry", "Coordinates", "ScanEffect", "PhotoSeconds")


def scene_payload():
    values = settings()
    return {
        "success": True,
        "ver": _data["ver"],
        "settings": {k: values[k] for k in SCENE_SETTINGS},
        "photos": len(_data["photos"]),
        "busy": _data["busy"],
    }


# --------------------------------------------------------------------------
# Live-Werte für die Seitenleisten
# --------------------------------------------------------------------------

TELEMETRY = telemetry.Telemetry(str(Path.home()))


def library_stats():
    stats = dict(_db.get("stats") or {})
    if not stats.get("photos"):
        stats["photos"] = len(_data["photos"])
    stats["inScanner"] = len(_data["photos"])
    return stats


def telemetry_payload():
    return {"success": True, "system": TELEMETRY.snapshot(), "library": library_stats()}


# --------------------------------------------------------------------------
# Verbindungen (Karte auf der Plugin-Seite, wie Moody Frame)
# --------------------------------------------------------------------------

SERVICES_EVERY = 600
_services = {"rows": [], "at": 0.0, "busy": False}
_services_lock = threading.Lock()


def _service(key, name, state, text, hint=""):
    return {"key": key, "name": name, "state": state, "text": text, "hint": hint}


def _check_engine(values):
    name = tr("DynaFrame-Mediendatenbank")
    try:
        data = engine_call("GET", "/media/database?page=1&pageSize=1")
    except EngineError as exc:
        return _service("engine", name, "bad", tr("DynaFrame antwortet nicht: {exc}", exc=exc))
    total = data.get("totalCount") if isinstance(data, dict) else None
    stats = _db.get("stats") or {}
    if not total and not stats.get("photos"):
        uses_df = any(s["kind"] in ("library", "playlist") for s in values["Sources"])
        return _service("engine", name, "warn" if uses_df else "ok",
                        tr("Erreichbar, aber noch keine Fotos in der Datenbank."))
    return _service("engine", name, "ok", tr("Erreichbar, {photos} Fotos und {videos} Videos.",
                                             photos=f"{stats.get('photos') or total or 0:,}".replace(",", "."),
                                             videos=f"{stats.get('videos') or 0:,}".replace(",", ".")))


def _check_immich(values):
    if not any(s["kind"].startswith("immich") for s in values["Sources"]):
        return None
    result = test_immich()
    return _service("immich", "Immich", "ok" if result["ok"] else "bad", result["message"])


def _check_webdav(values):
    if not (values["WebDavUrl"] and values["WebDavUser"] and values["WebDavPassword"]):
        return None
    result = test_webdav()
    return _service("webdav", "WebDAV", "ok" if result["ok"] else "bad", result["message"])


def _check_places(values):
    if not values["PlaceLookup"]:
        return None
    name = tr("Ortsnamen (OpenStreetMap)")
    if values["Coordinates"] == "hidden":
        # Auch die Prüfung fragt dann nicht bei OpenStreetMap an.
        return _service("places", name, "ok", tr("Aus, weil die GPS-Koordinaten ausgeblendet sind: Nichts wird an OpenStreetMap geschickt."))
    hint = tr("Erlaube nominatim.openstreetmap.org in Pi-hole oder Firewall. Ohne geht alles andere weiter.")
    try:
        response = requests.get("https://nominatim.openstreetmap.org/status", params={"format": "json"},
                                headers={"User-Agent": f"{USER_AGENT} {version()}"}, timeout=(CONNECT_TIMEOUT, 8))
        ok = response.status_code == 200
    except requests.RequestException as exc:
        return _service("places", name, "bad", sources.short_error(exc), hint)
    if not ok:
        return _service("places", name, "warn", tr("Der Server antwortet mit HTTP {status}.",
                                                   status=response.status_code), hint)
    cached = len(_places["cache"] or {}) if _places["cache"] is not None else len(read_json(PLACES_FILE, {}) or {})
    return _service("places", name, "ok", tr("Erreichbar, {n} Orte gemerkt.", n=cached))


def _check_system(_values):
    name = tr("Live-Werte des Rahmens")
    if not TELEMETRY.ok:
        return _service("system", name, "warn", tr("CPU und Speicher lassen sich hier nicht lesen."))
    snap = TELEMETRY.snapshot()
    TELEMETRY.wanted_at = 0.0   # die Prüfung zählt nicht als Szene
    temp = f", {snap['temp']:.0f} °C" if snap.get("temp") else ""
    cpu = f"{snap['cpu'][-1]:.0f} %" if snap.get("cpu") else "–"
    return _service("system", name, "ok", tr("CPU {cpu}, Speicher {mem} %{temp}.", cpu=cpu, temp=temp,
                                             mem=round(100 * snap["mem"]["used"] / (snap["mem"]["total"] or 1))))


def check_services(force=False):
    with _services_lock:
        if _services["busy"] or (not force and now() - _services["at"] < SERVICES_EVERY and _services["rows"]):
            return _services["rows"]
        _services["busy"] = True
    try:
        values = settings()
        rows = []
        for fn in (_check_engine, _check_immich, _check_webdav, _check_places, _check_system):
            try:
                row = fn(values)
            except Exception as exc:  # noqa: BLE001 - eine kaputte Prüfung soll die anderen nicht aufhalten
                row = _service("error", tr("Prüfung"), "bad", str(exc)[:200])
            if row:
                rows.append(row)
        before = {r["key"]: r["state"] for r in _services["rows"]}
        for r in rows:
            if r["state"] == "bad" and before.get(r["key"]) != "bad":
                log(f"{r['name']}: {r['text']}", "warning")
        _services.update(rows=rows, at=now())
        return rows
    finally:
        _services["busy"] = False


def services_payload():
    rows = _services["rows"]
    return {"at": _services["at"] or None, "busy": _services["busy"], "rows": rows,
            "bad": sum(1 for r in rows if r["state"] == "bad"),
            "warn": sum(1 for r in rows if r["state"] == "warn")}


def services_loop():
    _stop_requested.wait(20)
    while not _stop_requested.is_set():
        if now() - _services["at"] >= SERVICES_EVERY:
            check_services(True)
        _stop_requested.wait(30)


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    status = {}
    for source in values["Sources"]:
        row = dict(_data["status"].get(source["id"]) or {})
        if _data["busy"] and not row:
            row = {"state": "wait"}
        status[source["id"]] = row
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "status": status,
        "busy": _data["busy"],
        "progress": _data["progress"],
        "at": _data["at"],
        "photos": len(_data["photos"]),
        "last": {"scan": _last["scan"], "at": _last["at"]},
        "library": library_stats(),
        "services": services_payload(),
        "heif": HEIF,
        "webdav": webdav_guess(),
        "libraryWay": dynaframe.library_way,
        "dfCount": _data.get("dfCount"),
        "theme": {"id": theme_id()},
    }


def test_immich():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        info = immich.test()
    except sources.SourceError as exc:
        return {"success": True, "ok": False, "message": str(exc)}
    return {"success": True, "ok": True,
            "message": tr("Verbunden als {user} (Immich {version}).", user=info["user"] or "?",
                          version=info["version"] or "?")}


def list_albums():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, "albums": immich.albums()}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_immich(what):
    """Personen bzw. Tags für die Immich-Filter."""
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, what: getattr(immich_filters, what)(immich)}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_playlists():
    try:
        rows = [p for p in dynaframe.playlists() if p["name"] != PLAYLIST_NAME]
        return {"success": True, "playlists": sorted(rows, key=lambda p: str(p["name"]).lower())}
    except EngineError as exc:
        return {"success": False, "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc)}


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(), cors=True)
                return
            if path == "/api/next":
                self._json(next_photo(query), cors=True)
                return
            if path == "/api/telemetry":
                self._json(telemetry_payload(), cors=True)
                return
            if path == "/api/services":
                check_services(True)
                self._json({"success": True, "services": services_payload()})
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            if path == "/api/photo":
                found = photo_bytes(query)
                if found is None:
                    self._json({"success": False}, 404, cors=True)
                else:
                    self._send(found, "image/jpeg", cache="private, max-age=3600", cors=True)
                return
            if path == "/api/albums":
                self._json(list_albums())
                return
            if path in ("/api/people", "/api/tags"):
                self._json(list_immich(path.rsplit("/", 1)[1]))
                return
            if path == "/api/playlists":
                self._json(list_playlists())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                for name in SECRETS:
                    # Ein leeres Feld heißt: das alte behalten. Löschen geht mit "-".
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)
                    elif name in body and str(body[name]).strip() == "-":
                        body[name] = ""
                changed = save_settings(body)
                if "MakePlaylist" in changed:
                    OWN.changed()
                if set(changed) & {"PlaceLookup", "Coordinates", "WebDavUrl", "WebDavUser", "WebDavPassword"}:
                    _services["at"] = 0.0
                if set(changed) & {"PhotoOrder"}:
                    _order.update(bag=[], pos=0)
                if set(changed) & ({"Sources"} | set(immich_filters.SCHEMA) | set(dynaframe_filters.SCHEMA)):
                    # Strengere Filter sollen sofort greifen: alte Liste nicht weiter zeigen
                    with _scan_lock:
                        _data.update(photos=[], ver=_data["ver"] + 1)
                        _order["bag"] = []
                if changed and scan_signature(settings()) != _data["signature"]:
                    rescan_now()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(rescan_now())
                return
            if path == "/api/test":
                self._json(test_immich())
                return
            if path == "/api/webdavtest":
                self._json(test_webdav())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}" + ("" if HEIF else " (ohne HEIC-Unterstützung)"))

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: rescan_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())

    load_list()
    load_db_index()
    start_studio()
    plugin.connect_sse()
    plugin.ready()

    try:
        os.nice(5)   # Einlesen und Verkleinern sollen die Wiedergabe nicht stören
    except OSError:
        pass
    threading.Thread(target=scan_loop, name=f"{PLUGIN_ID}-scan", daemon=True).start()
    TELEMETRY.start()
    threading.Thread(target=services_loop, name=f"{PLUGIN_ID}-services", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _scan_stop.set()
    _scan_wake.set()
    TELEMETRY.stop.set()
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
