# Third-party notes

- Place names from OpenStreetMap via Nominatim, © OpenStreetMap contributors, ODbL.
- The scene bundles the font Inter under the SIL Open Font License 1.1 (see `dynamic/fonts/OFL-Inter.txt`).
- `exif_gps.py` is shared with the Travel Map plugin, `trips.py` with the travel scrapbook (own code).
