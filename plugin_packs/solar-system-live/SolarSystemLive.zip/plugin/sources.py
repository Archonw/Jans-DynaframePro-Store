"""Online-Quellen von Solar System Live (beide frei, ohne Schlüssel).

- JPL Horizons: Orte der Raumsonden (heliozentrisch, ekliptisch J2000, AE), 10 Tage zurück
  bis 90 Tage voraus, alle 2 Tage. Einmal am Tag.
- JPL Small-Body Database: Kometen, die in den nächsten Monaten der Sonne am nächsten
  kommen und hell genug werden. Einmal am Tag.

Beide sind freiwillig. Ohne sie zeigt die Szene die Sonden aus einem einfachen Ersatzmodell
(Voyager, New Horizons, Webb, BepiColombo) und die bekannten Kometen aus sky_objects.json.
"""

import json
import math
import os
import re
import time
from datetime import datetime, timezone

import requests

HORIZONS_URL = os.environ.get("SSL_HORIZONS_URL", "https://ssd.jpl.nasa.gov/api/horizons.api")
SBDB_URL = os.environ.get("SSL_SBDB_URL", "https://ssd-api.jpl.nasa.gov/sbdb_query.api")
DAY = 86400.0
TIMEOUT = (10, 60)


def iso(seconds):
    return datetime.fromtimestamp(seconds, timezone.utc).strftime("%Y-%m-%d %H:%M")


def jd_to_unix(jd):
    return (jd - 2440587.5) * DAY


def parse_horizons(text):
    """Die Zeilen zwischen $$SOE und $$EOE: JD, Datum, X, Y, Z (CSV)."""
    if "$$SOE" not in text:
        raise ValueError(re.sub(r"\s+", " ", text)[:160] or "leer")
    body = text.split("$$SOE", 1)[1].split("$$EOE", 1)[0]
    times, points = [], []
    for line in body.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 5:
            continue
        try:
            jd = float(parts[0])
            x, y, z = float(parts[2]), float(parts[3]), float(parts[4])
        except ValueError:
            continue
        times.append(round(jd_to_unix(jd)))
        points.append([round(x, 6), round(y, 6), round(z, 6)])
    if len(times) < 2:
        raise ValueError("keine Orte")
    return times, points


def fetch_probe(command, user_agent, now=None):
    now = now or time.time()
    start = datetime.fromtimestamp(now - 10 * DAY, timezone.utc).strftime("%Y-%m-%d")
    stop = datetime.fromtimestamp(now + 90 * DAY, timezone.utc).strftime("%Y-%m-%d")
    params = {
        "format": "json", "COMMAND": f"'{command}'", "OBJ_DATA": "'NO'", "MAKE_EPHEM": "'YES'",
        "EPHEM_TYPE": "'VECTORS'", "CENTER": "'500@10'", "REF_PLANE": "'ECLIPTIC'", "REF_SYSTEM": "'ICRF'",
        "START_TIME": f"'{start}'", "STOP_TIME": f"'{stop}'", "STEP_SIZE": "'2 d'", "VEC_TABLE": "'1'",
        "OUT_UNITS": "'AU-D'", "CSV_FORMAT": "'YES'", "VEC_LABELS": "'NO'",
    }
    response = requests.get(HORIZONS_URL, params=params, timeout=TIMEOUT, headers={"User-Agent": user_agent})
    if response.status_code != 200:
        raise ValueError(f"HTTP {response.status_code}")
    try:
        text = response.json().get("result", "")
    except ValueError:
        text = response.text
    return parse_horizons(text)


def fetch_probes(probes, user_agent, log=None, pause=1.0):
    """Holt alle Sonden nacheinander. Gibt (Ergebnis, Fehlertext) zurück."""
    out, errors = {}, []
    for probe in probes:
        command = probe.get("horizons")
        if not command:
            continue
        try:
            times, points = fetch_probe(command, user_agent)
            out[probe["id"]] = {"t": times, "p": points}
        except requests.RequestException as exc:
            errors.append(f"{probe['name']}: {exc.__class__.__name__}")
            if len(errors) >= 2 and not out:
                break                     # Horizons nicht erreichbar: nicht 11-mal warten
        except ValueError as exc:
            errors.append(f"{probe['name']}: {exc}")
        time.sleep(pause)
    if log and errors:
        log("Horizons: " + "; ".join(errors)[:400], "warning")
    return out, ("; ".join(errors)[:300] if not out and errors else "")


# ---------------------------------------------------------------------------- Kometen

def _num(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def fetch_comets(user_agent, now=None, limit=8):
    """Kometen mit Perihel in -60 bis +240 Tagen, die heller als 11 mag werden."""
    now = now or time.time()
    jd_now = now / DAY + 2440587.5
    cdata = {"AND": [f"tp|GT|{jd_now - 60:.1f}", f"tp|LT|{jd_now + 240:.1f}", "q|LT|3.5"]}
    params = {"fields": "full_name,pdes,e,q,i,om,w,tp,M1,K1", "sb-kind": "c",
              "sb-cdata": json.dumps(cdata, separators=(",", ":")), "full-prec": "0"}
    response = requests.get(SBDB_URL, params=params, timeout=TIMEOUT, headers={"User-Agent": user_agent})
    if response.status_code != 200:
        raise ValueError(f"HTTP {response.status_code}: {response.text[:120]}")
    data = response.json()
    fields = data.get("fields") or []
    rows = data.get("data") or []
    out = []
    for row in rows:
        item = dict(zip(fields, row))
        e, q, inc, node, peri, tp = (_num(item.get(k)) for k in ("e", "q", "i", "om", "w", "tp"))
        if None in (e, q, inc, node, peri, tp):
            continue
        m1, k1 = _num(item.get("M1")), _num(item.get("K1"))
        if m1 is None:
            continue
        k1 = 10.0 if k1 is None else k1
        # Helligkeit am Perihel, Abstand zur Erde grob 1 AE angenommen
        mag = m1 + k1 * math.log10(max(q, 0.05))
        if mag > 11:
            continue
        name = re.sub(r"\s+", " ", str(item.get("full_name") or item.get("pdes") or "?")).strip()
        cid = re.sub(r"[^a-z0-9]", "", str(item.get("pdes") or name).lower())[:24] or "comet"
        out.append({"id": cid, "name": name, "q": round(q, 4), "e": round(e, 5), "i": round(inc, 3),
                    "node": round(node, 3), "peri": round(peri, 3), "tp": round(jd_to_unix(tp)),
                    "mag": round(mag, 1), "live": True})
    out.sort(key=lambda c: c["mag"])
    return out[:limit]


# ---------------------------------------------------------------------------- Kometen: Perihel

def parse_tp(value):
    if isinstance(value, (int, float)):
        return float(value)
    return datetime.strptime(str(value), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc).timestamp()


def next_perihelion(comet, now):
    """Für periodische Kometen der nächste Perihel-Durchgang (oder der letzte, wenn er < 60 Tage her ist)."""
    tp = parse_tp(comet["tp"])
    e, q = comet["e"], comet["q"]
    if e >= 1:
        return tp
    a = q / (1 - e)
    period = 365.25636 * DAY * a ** 1.5
    while tp < now - 60 * DAY:
        tp += period
    return tp
