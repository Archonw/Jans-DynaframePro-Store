# Party Wall

The photo wall for your party, as a DynaFrame scene with its plugin.

- **Guests join with the QR code on the TV.** It opens a page of the plugin on port 8110 in your Wi-Fi with the party code filled in; guests only type their name. No app needed.
- **Upload photos** from the gallery or the camera, with an optional line of text. Photos are shrunk on the phone, turned the right way up and stored on the frame at 1920 pixels without location or camera data.
- **React with emojis** (❤️ 😂 😍 🔥 👏 🎉 😮). They fly across the TV with the guest's name. Each guest counts at most three reactions per photo for the ranking.
- **The wall** shows new photos within seconds (with a NEW badge), then popular photos more often. Next to the photo: the QR code, the numbers of the evening and the three most popular photos.
- **Top photos in between** (every 20 minutes by default) and **a recap** at the end: the numbers of the night, a countdown of the most popular photos and a collage. Start it on the plugin page or at a set time.
- **Plugin page**: party name, guest code, approve photos before they appear (optional), hide or delete photos, download all photos as ZIP, earlier parties, three looks (party, elegant, bright), instant photo or large photo.
- Show it with the playlist "Party Wall" or send it to the TV from the plugin page for a few hours (needs "Allow takeover").

If you use Web Login, open port 8110 there. English, German or Spanish; the guest page follows the phone's language.

Emoji graphics: Twemoji, © Twitter, Inc. and other contributors, CC BY 4.0.
