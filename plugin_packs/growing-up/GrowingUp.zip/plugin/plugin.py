#!/usr/bin/env python3
"""Growing Up - the plugin part of the Growing Up package.

Takes people from the owner's Immich server (face recognition), picks one
good face per month, quarter or year from all their photos, cuts out square
portraits lined up on the face and hands them to the scene "growing-up":
a time-lapse in which the face grows up, a contact sheet of all years, then
and now, and several people at the same age.

What a scene can't do, this plugin does:
- talk to Immich with the owner's API key, which never leaves the frame;
- go through thousands of photos and pick the best faces (faces.py);
- keep the portraits on the frame, so the scene loads fast;
- show the scene over the playlist on a birthday or on a schedule
  (display takeover), and Show/Stop/Toggle by hand or automation;
- keep all settings on its own page (Plugins > Open Growing Up).

The scene reaches this plugin via the WebUI proxy on :8003 or port 80.
"""

import json
import os
import re
import sys
import threading
import time
from datetime import date, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

import requests

# DynaFrame puts the shared SDK one folder above every plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import faces  # noqa: E402
import texts  # noqa: E402

try:
    # Works around a DynaFrame bug that can leave a Quick Mix stopped after a
    # takeover (see there). Without the file everything else keeps working.
    import playback_guard  # noqa: E402
except ImportError:  # pragma: no cover
    playback_guard = None

plugin = create_plugin()

PLUGIN_ID = "GrowingUp"
DISPLAY_NAME = "Growing Up"
SCENE_ID = "growing-up"          # id in scene.dynamic - never change
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"   # settings and state; survives updates
CACHE_DIR = PLUGIN_DIR / "cache"  # photo lists and portraits; may be deleted
CROP_DIR = CACHE_DIR / "portraits"

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 45
PHOTO_TIMEOUT = 60
UUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
SEARCH_PAGE = 1000
SEARCH_MAX = 30000          # photos per person read at most
FACE_LOOKUPS = 800          # extra face reads if the search has no face boxes


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        pass
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def ensure_dirs():
    for folder in (DATA_DIR, CACHE_DIR, CROP_DIR):
        folder.mkdir(parents=True, exist_ok=True)


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Could not read {path.name}: {exc}", level="warning")
        return default


def write_json(path, payload, indent=None):
    """Atomic, so a power cut never leaves half a file."""
    ensure_dirs()
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=indent, ensure_ascii=False, separators=None if indent else (",", ":"))
    temp.replace(path)


def local_text(epoch):
    if not epoch:
        return ""
    return datetime.fromtimestamp(epoch).astimezone().isoformat(timespec="seconds")


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


# --------------------------------------------------------------------------
# Settings (all on the plugin page; the manifest declares none)
# --------------------------------------------------------------------------

VIEWS = ["film", "grid", "thennow", "sameage"]

SETTINGS = {
    "ServerUrl":      {"kind": "text", "default": ""},
    "ApiKey":         {"kind": "secret", "default": ""},
    "People":         {"kind": "ids", "default": []},
    "Birthdays":      {"kind": "dates", "default": {}},
    "Excluded":       {"kind": "excluded", "default": {}},
    # Which faces
    "Interval":       {"kind": "choice", "default": "auto", "options": ["auto", "month", "quarter", "half", "year"]},
    "MaxFrames":      {"kind": "number", "default": 48, "min": 6, "max": 150},
    "MinFace":        {"kind": "number", "default": 90, "min": 30, "max": 400},
    "Zoom":           {"kind": "choice", "default": "normal", "options": list(faces.ZOOMS)},
    "RefreshHours":   {"kind": "number", "default": 12, "min": 1, "max": 168},
    # The scene
    "Views":          {"kind": "views", "default": list(VIEWS)},
    "HoldSeconds":    {"kind": "decimal", "default": 2.0, "min": 0.2, "max": 30},
    "FadeSeconds":    {"kind": "decimal", "default": 1.5, "min": 0, "max": 10},
    "ViewSeconds":    {"kind": "number", "default": 18, "min": 5, "max": 300},
    "Captions":       {"kind": "choice", "default": "both", "options": ["both", "age", "date", "none"]},
    # When the scene comes over the playlist by itself.
    "AutoMode":       {"kind": "choice", "default": "birthday", "options": ["off", "birthday", "always"]},
    "EveryMinutes":   {"kind": "number", "default": 120, "min": 5, "max": 1440},
    "ShowForSeconds": {"kind": "number", "default": 90, "min": 15, "max": 3600},
    "ActiveFrom":     {"kind": "number", "default": 8, "min": 0, "max": 23},
    "ActiveTo":       {"kind": "number", "default": 21, "min": 1, "max": 24},
    "MakePlaylist":   {"kind": "bool", "default": False},
    "Language":       {"kind": "choice", "default": "en", "options": list(texts.LANGUAGES)},
}

SETTINGS_FILE = DATA_DIR / "settings.json"
STATE_FILE = DATA_DIR / "state.json"
_settings_lock = threading.Lock()


def coerce(name, raw):
    spec = SETTINGS[name]
    kind, default = spec["kind"], spec["default"]
    if raw is None:
        return json.loads(json.dumps(default))
    if kind == "bool":
        return as_bool(raw, default)
    if kind == "number":
        return max(spec["min"], min(spec["max"], as_int(raw, default)))
    if kind == "decimal":
        try:
            value = float(str(raw).replace(",", "."))
        except ValueError:
            value = default
        return round(max(spec["min"], min(spec["max"], value)), 1)
    if kind == "choice":
        value = str(raw).strip().lower()
        return value if value in spec["options"] else default
    if kind == "ids":
        items = raw if isinstance(raw, list) else str(raw).split(",")
        chosen = []
        for item in items:
            value = str(item).strip().lower()
            if UUID.match(value) and value not in chosen:
                chosen.append(value)
        return chosen[:12]
    if kind == "views":
        items = raw if isinstance(raw, list) else str(raw).split(",")
        wanted = {str(i).strip().lower() for i in items}
        return [v for v in VIEWS if v in wanted]
    if kind == "dates":
        result = {}
        for key, value in (raw.items() if isinstance(raw, dict) else []):
            key = str(key).strip().lower()
            day = faces.parse_date(value)
            if UUID.match(key) and day:
                result[key] = day.isoformat()
        return result
    if kind == "excluded":
        result = {}
        for key, value in (raw.items() if isinstance(raw, dict) else []):
            key = str(key).strip().lower()
            ids = [str(v).strip().lower() for v in (value if isinstance(value, list) else [])]
            ids = [v for v in dict.fromkeys(ids) if UUID.match(v)]
            if UUID.match(key) and ids:
                result[key] = ids[-500:]
        return result
    if kind == "secret":
        return re.sub(r"\s+", "", str(raw))[:400]
    return str(raw).strip()[:500]


def normalize_url(url):
    url = str(url or "").strip().rstrip("/")
    if url and not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    if url.lower().endswith("/api"):
        url = url[:-4]
    return url


def settings():
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
    return {name: coerce(name, stored.get(name)) for name in SETTINGS}


def tr(template, **values):
    """A text in the chosen language (see texts.py)."""
    return texts.t(settings()["Language"], template, **values)


def save_settings(changes):
    changed = []
    with _settings_lock:
        stored = read_json(SETTINGS_FILE, {}) or {}
        for name, raw in (changes or {}).items():
            if name not in SETTINGS:
                continue
            value = coerce(name, raw)
            if name == "ServerUrl":
                value = normalize_url(value)
            if stored.get(name, SETTINGS[name]["default"]) != value:
                stored[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, stored, indent=1)
    return changed


_state_lock = threading.Lock()


def load_state():
    return read_json(STATE_FILE, {}) or {}


def save_state(**fields):
    with _state_lock:
        state = read_json(STATE_FILE, {}) or {}
        if all(k in state and state[k] == v for k, v in fields.items()):
            return state  # nothing new, so no write to the SD card
        state.update(fields)
        write_json(STATE_FILE, state, indent=1)
    return state


def adopt_immich_login():
    """Take server and key from Immich Slideshow if this plugin has none yet."""
    values = settings()
    if values["ServerUrl"] and values["ApiKey"]:
        return ""
    for name in ("ImmichSlideshow",):
        other = read_json(PLUGIN_DIR.parent / name / "data" / "settings.json", {}) or {}
        url, key = normalize_url(other.get("ServerUrl")), str(other.get("ApiKey") or "").strip()
        if url and key:
            save_settings({"ServerUrl": url, "ApiKey": key})
            save_state(adoptedFrom="Immich Slideshow")
            plugin.log("Took the Immich server and API key from Immich Slideshow.")
            return name
    return ""


# --------------------------------------------------------------------------
# Immich
# --------------------------------------------------------------------------

class ImmichError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


_session = requests.Session()


def short_error(exc):
    text = str(exc)
    for marker in ("Failed to establish a new connection: ", "Read timed out", "Name or service not known"):
        if marker in text:
            tail = text.split(marker, 1)[1] if marker.endswith(": ") else marker
            return tail.split("'))")[0].strip(" )") or marker
    return text[:200]


def immich(method, path, payload=None, params=None, raw=False, timeout=None, values=None):
    values = values or settings()
    base, key = values["ServerUrl"], values["ApiKey"]
    if not base:
        raise ImmichError(tr("Trag die Adresse deines Immich-Servers ein."))
    if not key:
        raise ImmichError(tr("Trag einen API-Schlüssel von Immich ein."))
    headers = {"x-api-key": key, "Accept": "image/*" if raw else "application/json"}
    try:
        response = _session.request(method, f"{base}/api{path}", json=payload, params=params, headers=headers,
                                    timeout=(CONNECT_TIMEOUT, timeout or READ_TIMEOUT))
    except requests.RequestException as exc:
        raise ImmichError(tr("Immich ist nicht erreichbar: {exc}", exc=short_error(exc))) from exc
    if response.status_code == 401:
        raise ImmichError(tr("Immich lehnt den API-Schlüssel ab."), 401)
    if response.status_code == 403:
        raise ImmichError(tr("Dem API-Schlüssel fehlt eine Berechtigung ({path}).", path=path.split("?")[0]), 403)
    if response.status_code >= 400:
        detail = ""
        try:
            body = response.json()
            detail = body.get("message") if isinstance(body, dict) else ""
            if isinstance(detail, list):
                detail = "; ".join(str(d) for d in detail)
        except ValueError:
            pass
        raise ImmichError(f"{method} {path}: HTTP {response.status_code} {detail or ''}".strip(),
                          response.status_code)
    if raw:
        return response
    if not response.content.strip():
        return None
    try:
        return response.json()
    except ValueError as exc:
        raise ImmichError(tr("Unter dieser Adresse antwortet kein Immich-Server.")) from exc


def server_info(values=None):
    about = {}
    try:
        about = immich("GET", "/server/about", values=values) or {}
    except ImmichError as exc:
        if exc.status in (401, 403):
            raise
    found = about.get("version") or ""
    if not found:
        try:
            v = immich("GET", "/server/version", values=values) or {}
            found = f"v{v.get('major')}.{v.get('minor')}.{v.get('patch')}"
        except ImmichError:
            found = "?"
    me = immich("GET", "/users/me", values=values) or {}
    return {"version": found, "user": me.get("name") or me.get("email") or ""}


_people_list = {"at": 0.0, "rows": [], "error": ""}


def list_people(force=False):
    """The named people in Immich (cached for five minutes)."""
    if not force and now() - _people_list["at"] < 300 and _people_list["rows"]:
        return _people_list["rows"]
    people, page = [], 1
    while page <= 30:
        data = immich("GET", "/people", params={"page": page, "size": 500, "withHidden": "false"}) or {}
        for row in data.get("people") or []:
            if row.get("name") and not row.get("isHidden"):
                people.append({"id": row["id"], "name": row["name"],
                               "birthDate": (row.get("birthDate") or "")[:10],
                               "favorite": bool(row.get("isFavorite"))})
        if not data.get("hasNextPage"):
            break
        page += 1
    people.sort(key=lambda p: (not p["favorite"], p["name"].lower()))
    _people_list.update(at=now(), rows=people, error="")
    return people


def person_info(person_id):
    row = immich("GET", f"/people/{person_id}") or {}
    return {"id": person_id, "name": row.get("name") or "", "birthDate": (row.get("birthDate") or "")[:10]}


def face_thumb(person_id):
    response = immich("GET", f"/people/{person_id}/thumbnail", raw=True)
    return response.content, response.headers.get("Content-Type", "image/jpeg").split(";")[0]


def photo(asset_id, size):
    response = immich("GET", f"/assets/{asset_id}/thumbnail", params={"size": size}, raw=True,
                      timeout=PHOTO_TIMEOUT)
    kind = response.headers.get("Content-Type", "image/jpeg").split(";")[0]
    if not kind.startswith("image/"):
        raise ImmichError(f"Immich sent {kind} instead of an image")
    return response.content


def search_person(person_id):
    """All photos of a person, oldest first, with the face boxes."""
    assets, page = [], 1
    while len(assets) < SEARCH_MAX and not _stop_requested.is_set():
        body = {"personIds": [person_id], "type": "IMAGE", "withPeople": True, "withExif": True,
                "order": "asc", "size": SEARCH_PAGE, "page": page}
        data = immich("POST", "/search/metadata", body) or {}
        block = data.get("assets") or {}
        items = block.get("items") or []
        assets.extend(i for i in items if isinstance(i, dict))
        next_page = block.get("nextPage")
        if not items or not next_page:
            break
        page = as_int(next_page, page + 1)
    return assets


def faces_for(asset_id):
    rows = immich("GET", "/faces", params={"id": asset_id}) or []
    return [r for r in rows if isinstance(r, dict)]


# --------------------------------------------------------------------------
# The portraits: photo list per person, selection, cut-outs
# --------------------------------------------------------------------------

_data_lock = threading.Lock()
_people = {}       # person id -> {"name", "birthDate", "rows", "at", "error", "frames", "busy"}
_version = {"n": 0}
_force = set()


def bump():
    with _data_lock:
        _version["n"] += 1


def rows_file(person_id):
    return CACHE_DIR / f"photos-{person_id}.json"


def load_cache():
    for person_id in settings()["People"]:
        stored = read_json(rows_file(person_id), None)
        if isinstance(stored, dict) and isinstance(stored.get("rows"), list):
            _people[person_id] = {"name": stored.get("name") or "", "birthDate": stored.get("birthDate") or "",
                                  "rows": stored["rows"], "at": stored.get("at") or 0, "error": "",
                                  "frames": [], "total": stored.get("total") or len(stored["rows"]),
                                  "busy": ""}


def birth_of(person_id, values=None):
    values = values or settings()
    entry = _people.get(person_id) or {}
    text = values["Birthdays"].get(person_id) or entry.get("birthDate") or ""
    return faces.parse_date(text)


def read_person(person_id, values):
    """Ask Immich for every photo of the person and note the faces."""
    with _data_lock:
        entry = _people.setdefault(person_id, {"name": "", "birthDate": "", "rows": [], "at": 0, "error": "",
                                               "frames": [], "total": 0, "busy": ""})
        entry["busy"] = tr("Liest die Fotos aus Immich …")
        old = {r["id"]: r for r in entry.get("rows") or []}
    try:
        info = person_info(person_id)
        assets = search_person(person_id)
        rows, missing = [], []
        for asset in assets:
            row = faces.candidate(asset, person_id)
            if row is None:
                continue
            if row["box"] is None:
                known = old.get(row["id"])
                if known and (known.get("box") or known.get("looked")):
                    row = known  # face already read (or known to have none)
                else:
                    missing.append(row)
            rows.append(row)
        # Older Immich versions send no face boxes with the search: read the
        # faces of a sample spread over the years instead.
        if missing:
            sample = faces.thin_out(missing, FACE_LOOKUPS)
            plugin.log(f"{info['name'] or person_id}: reading faces of {len(sample)} of {len(missing)} photos.")
            for row in sample:
                if _stop_requested.is_set():
                    break
                try:
                    found = faces_for(row["id"])
                except ImmichError as exc:
                    if exc.status in (401, 403):
                        raise
                    continue
                mine = [f for f in found if (f.get("person") or {}).get("id") == person_id]
                better = faces.candidate({"id": row["id"], "localDateTime": row["d"], "isFavorite": row["fav"],
                                          "exifInfo": {"rating": row["r"]}}, person_id, faces=mine)
                if better:
                    row.update(better)
                row["looked"] = True
    except ImmichError as exc:
        with _data_lock:
            entry["error"], entry["busy"] = str(exc), ""
        plugin.log(f"Immich, person {person_id}: {exc}", level="warning")
        return False
    with _data_lock:
        entry.update(name=info["name"], birthDate=info["birthDate"], rows=rows, at=now(), error="",
                     total=len(assets), busy="")
    write_json(rows_file(person_id), {"name": info["name"], "birthDate": info["birthDate"], "at": now(),
                                      "total": len(assets), "rows": rows})
    usable = sum(1 for r in rows if r.get("box"))
    plugin.log(f"{info['name'] or person_id}: {len(assets)} photos, {usable} with a usable face.")
    return True


def crop_path(person_id, asset_id, zoom):
    return CROP_DIR / person_id / f"{asset_id}-{zoom}.jpg"


def meta_path(person_id):
    return CROP_DIR / person_id / "faces.json"


def make_portrait(person_id, row, zoom):
    """Cut the portrait out of Immich's preview (or the original for small faces)."""
    preview = photo(row["id"], "preview")
    data = preview
    if faces.needs_bigger_image(row["box"], faces.size_of(preview)):
        try:
            bigger = photo(row["id"], "fullsize")
            if faces.size_of(bigger)[0] > faces.size_of(preview)[0]:
                data = bigger
        except (ImmichError, faces.CropError):
            pass
    try:
        jpeg, face = faces.crop(data, row["box"], zoom)
    except faces.CropError:
        if data is preview:
            raise
        jpeg, face = faces.crop(preview, row["box"], zoom)
    target = crop_path(person_id, row["id"], zoom)
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(".tmp")
    temp.write_bytes(jpeg)
    temp.replace(target)
    return face


def build_frames(person_id, values):
    """Pick the series and cut out what is missing. Returns True if done."""
    with _data_lock:
        entry = _people.get(person_id)
        rows = list(entry.get("rows") or []) if entry else []
    if not entry:
        return False
    born = birth_of(person_id, values)
    bad = set(read_json(meta_path(person_id), {}).get("bad") or [])
    excluded = set(values["Excluded"].get(person_id) or []) | bad
    chosen = faces.select(rows, born, values["Interval"], values["MaxFrames"], values["MinFace"], excluded)
    zoom = values["Zoom"]
    meta = read_json(meta_path(person_id), {}) or {}
    known = meta.get("faces") or {}
    frames, todo = [], []
    for row in chosen:
        key = f"{row['id']}-{zoom}"
        if key in known and crop_path(person_id, row["id"], zoom).exists():
            frames.append((row, known[key]))
        else:
            todo.append(row)
    total = len(chosen)
    changed = broken = False
    for count, row in enumerate(todo, 1):
        if _stop_requested.is_set() or set(values["People"]) != set(settings()["People"]):
            break
        with _data_lock:
            entry["busy"] = tr("Schneidet Porträts aus: {done} von {total}", done=total - len(todo) + count, total=total)
        try:
            known[f"{row['id']}-{zoom}"] = make_portrait(person_id, row, zoom)
            frames.append((row, known[f"{row['id']}-{zoom}"]))
            changed = True
        except (ImmichError, faces.CropError) as exc:
            if isinstance(exc, ImmichError) and exc.status in (401, 403):
                with _data_lock:
                    entry["error"], entry["busy"] = str(exc), ""
                return False
            plugin.log(f"Portrait {row['id']}: {exc}", level="warning")
            bad.add(row["id"])
            changed = broken = True
        if count % 4 == 0:
            publish_frames(person_id, frames, born, values)
        _stop_requested.wait(0.2)  # keep the Pi responsive
    if changed:
        meta.update(faces=known, bad=sorted(bad))
        write_json(meta_path(person_id), meta)
    publish_frames(person_id, frames, born, values)
    if broken:
        return False  # a few were broken: pick again with the next best ones next round
    remove_old_portraits(person_id, {f"{r['id']}-{zoom}.jpg" for r, _ in frames})
    with _data_lock:
        entry["busy"] = ""
    return len(frames) == total


def publish_frames(person_id, frames, born, values):
    rows = []
    for row, face in sorted(frames, key=lambda f: (f[0]["d"], f[0]["id"])):
        day = faces.parse_date(row["d"])
        rows.append({"id": row["id"], "date": row["d"], "age": faces.age_of(born, day), "face": face,
                     "fav": row.get("fav", False), "small": faces.face_size(row) < values["MinFace"],
                     "src": f"api/portrait/{person_id}/{row['id']}-{values['Zoom']}.jpg"})
    with _data_lock:
        entry = _people.get(person_id)
        if entry is not None and entry.get("frames") != rows:
            entry["frames"] = rows
            _version["n"] += 1


def remove_old_portraits(person_id, keep):
    folder = CROP_DIR / person_id
    if not folder.is_dir():
        return
    for path in folder.glob("*.jpg"):
        if path.name not in keep:
            try:
                path.unlink()
            except OSError:
                pass


def forget_person(person_id):
    with _data_lock:
        _people.pop(person_id, None)
    for path in (rows_file(person_id),):
        try:
            path.unlink()
        except OSError:
            pass
    folder = CROP_DIR / person_id
    if folder.is_dir():
        for path in folder.iterdir():
            try:
                path.unlink()
            except OSError:
                pass
        try:
            folder.rmdir()
        except OSError:
            pass
    bump()


_data_running = threading.Lock()
_rebuild = set()
_loop_info = {"lastError": "", "dataAt": 0.0}


def refresh_data(force=False):
    values = settings()
    if not values["ServerUrl"] or not values["ApiKey"]:
        return
    wanted = values["People"]
    for person_id in [p for p in list(_people) if p not in wanted]:
        forget_person(person_id)
    for person_id in wanted:
        if _stop_requested.is_set():
            return
        entry = _people.get(person_id)
        stale = not entry or now() - (entry.get("at") or 0) > values["RefreshHours"] * 3600
        if force or person_id in _force or stale:
            _force.discard(person_id)
            if not read_person(person_id, values):
                continue
            _rebuild.add(person_id)
        if person_id in _rebuild or not (_people.get(person_id) or {}).get("frames"):
            if build_frames(person_id, settings()):
                _rebuild.discard(person_id)
    _loop_info["dataAt"] = now()


def data_round(force):
    """Reading Immich and cutting portraits takes a while: own thread."""
    if not _data_running.acquire(blocking=False):
        return
    try:
        refresh_data(force)
        _loop_info["lastError"] = ""
    except Exception as exc:  # pragma: no cover
        _loop_info["lastError"] = str(exc)
        plugin.log(f"Reading Immich failed: {exc!r}", level="error")
    finally:
        _data_running.release()


def person_name(person_id):
    entry = _people.get(person_id) or {}
    if entry.get("name"):
        return entry["name"]
    return next((p["name"] for p in _people_list["rows"] if p["id"] == person_id), "")


def birthday_people(values, today=None):
    today = today or date.today()
    found = []
    for person_id in values["People"]:
        born = birth_of(person_id, values)
        if born and (born.month, born.day) == (today.month, today.day) and \
                (_people.get(person_id) or {}).get("frames"):
            found.append(person_id)
    return found


def snapshot():
    """What the scene draws."""
    values = settings()
    with _takeover_lock:
        focus = _takeover["focus"] if _takeover["handle"] is not None or _takeover["asking"] else None
    people = []
    with _data_lock:
        for person_id in values["People"]:
            entry = _people.get(person_id) or {}
            born = birth_of(person_id, values)
            people.append({"id": person_id, "name": entry.get("name") or person_name(person_id),
                           "birthDate": born.isoformat() if born else "",
                           "frames": entry.get("frames") or [], "busy": entry.get("busy") or "",
                           "error": entry.get("error") or ""})
        version_n = _version["n"]
    today = date.today()
    return {
        "success": True,
        "version": version(),
        "rev": version_n,
        "language": values["Language"],
        "views": values["Views"],
        "holdMs": int(values["HoldSeconds"] * 1000),
        "fadeMs": int(values["FadeSeconds"] * 1000),
        "viewSeconds": values["ViewSeconds"],
        "captions": values["Captions"],
        "today": today.isoformat(),
        "configured": bool(values["ServerUrl"] and values["ApiKey"]),
        "people": people,
        "sameAges": faces.common_ages([p for p in people if p["birthDate"]]),
        "birthdays": birthday_people(values, today),
        "focus": focus,
    }


# --------------------------------------------------------------------------
# The engine on this frame
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None, read_timeout=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, read_timeout or 30))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} returned HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


_scene = {"dbId": None, "note": ""}


def find_scene():
    """The installed scene. A playlist item needs its numeric id."""
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        _scene.update(dbId=row["id"], note="" if row.get("isEnabled", True) else
                      tr("Die Szene Growing Up ist auf der Plugins-Seite ausgeschaltet."))
        return row
    _scene.update(dbId=None, note=tr("Die Szene Growing Up ist auf diesem Rahmen nicht installiert. "
                                     "Installiere das Growing-Up-Paket noch einmal."))
    return None


# --------------------------------------------------------------------------
# Playlists: the takeover playlist and, if wanted, one for the owner
# --------------------------------------------------------------------------

TAKEOVER_PLAYLIST_NAME = "Growing Up (takeover)"
TAKEOVER_PLAYLIST_DESCRIPTION = ("Played by the Growing Up plugin when it takes over the screen. Stays "
                                 "switched off so it doesn't end up in the Quick Mix. The plugin creates it "
                                 "again if it is deleted.")
OWNER_PLAYLIST_NAME = "Growing Up"
OWNER_PLAYLIST_DESCRIPTION = "Created by the Growing Up plugin. Switch off, schedule or delete like any playlist."
TAKEOVER_ITEM_SECONDS = 6 * 3600  # the plugin ends the display long before
SCENE_SECONDS = 120               # recommendedDurationSec in scene.dynamic

_playlists = {"at": 0.0, "takeoverId": None, "note": "", "ownerNote": ""}
_playlist_lock = threading.Lock()


def same_id(a, b):
    return a is not None and b is not None and str(a) == str(b)


def all_playlists():
    playlists = engine_call("GET", "/playlists") or []
    if isinstance(playlists, dict):
        playlists = playlists.get("playlists") or []
    return [p for p in playlists if isinstance(p, dict)]


def playlist_items(playlist_id):
    items = engine_call("GET", f"/playlists/{playlist_id}/items") or []
    if isinstance(items, dict):
        items = items.get("items") or []
    return [i for i in items if isinstance(i, dict)]


def get_playlist(playlist_id):
    try:
        return engine_call("GET", f"/playlists/{playlist_id}") or {}
    except EngineError as exc:
        if exc.status == 404:
            return None
        raise


def screen_held():
    """Does anything hold the screen? Playlists are only created while nothing
    does: the frame rebuilds the Quick Mix after a takeover, and a playlist
    created meanwhile changes what it restores."""
    if _takeover["handle"] is not None:
        return True
    try:
        status = engine_call("GET", "/display-sessions/status", read_timeout=10) or {}
    except EngineError as exc:
        return exc.status != 404
    return bool(status.get("active"))


def create_playlist(name, description, seconds, enabled):
    created = engine_call("POST", "/playlists", {"name": name, "description": description}) or {}
    playlist_id = created.get("id") or (created.get("playlist") or {}).get("id")
    if not playlist_id:
        raise EngineError(tr("Der Rahmen hat die Playlist {name} nicht angelegt.", name=name))
    engine_call("POST", f"/playlists/{playlist_id}/items",
                {"dynamicSceneId": _scene["dbId"], "customDurationSeconds": seconds})
    if not enabled:
        engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
    return playlist_id


def ensure_takeover_playlist():
    """A takeover plays a playlist, not a single scene. So: the scene alone,
    six hours, switched off."""
    playlist_id = load_state().get("takeoverPlaylistId")
    playlist = get_playlist(playlist_id) if playlist_id else None
    if playlist is None:
        playlist = next((p for p in all_playlists() if p.get("name") == TAKEOVER_PLAYLIST_NAME), None)
        playlist_id = playlist.get("id") if playlist else None
    if playlist is not None and playlist_id:
        items = playlist_items(playlist_id)
        ours = [i for i in items if i.get("dynamicSceneId") == _scene["dbId"]]
        if len(ours) == 1 and len(items) == 1:
            if playlist.get("isEnabled") is not False:
                engine_call("PUT", f"/playlists/{playlist_id}", {"isEnabled": False})
            if not same_id(playlist_id, load_state().get("takeoverPlaylistId")):
                save_state(takeoverPlaylistId=playlist_id)
            return playlist_id
        engine_call("DELETE", f"/playlists/{playlist_id}")
    playlist_id = create_playlist(TAKEOVER_PLAYLIST_NAME, TAKEOVER_PLAYLIST_DESCRIPTION,
                                  TAKEOVER_ITEM_SECONDS, enabled=False)
    save_state(takeoverPlaylistId=playlist_id)
    plugin.log(f"Created playlist {TAKEOVER_PLAYLIST_NAME} ({playlist_id}).")
    return playlist_id


def maintain_owner_playlist(values):
    state = load_state()
    playlist_id = state.get("ownerPlaylistId")
    if playlist_id:
        if get_playlist(playlist_id) is None:
            save_state(ownerPlaylistId=None, ownerPlaylistDeleted=bool(values["MakePlaylist"]))
            if values["MakePlaylist"]:
                save_settings({"MakePlaylist": False})
                plugin.log("The Growing Up playlist was deleted; it is not created again.")
        return ""
    if not values["MakePlaylist"]:
        return ""
    if screen_held():
        return tr("Wartet, bis der Bildschirm wieder frei ist.")
    playlist_id = create_playlist(OWNER_PLAYLIST_NAME, OWNER_PLAYLIST_DESCRIPTION, SCENE_SECONDS, enabled=True)
    save_state(ownerPlaylistId=playlist_id, ownerPlaylistDeleted=False)
    plugin.log(f"Created playlist {OWNER_PLAYLIST_NAME} ({playlist_id}), switched on.")
    return ""


def maintain_playlists(force=False):
    with _playlist_lock:
        if not force and now() - _playlists["at"] < 60:
            return
        _playlists["at"] = now()
        find_scene()
        if _scene["dbId"] is None:
            _playlists.update(note=_scene["note"], ownerNote=_scene["note"])
            return
        try:
            if not screen_held():
                _playlists.update(takeoverId=ensure_takeover_playlist(), note="")
            elif not _playlists["takeoverId"]:
                _playlists["takeoverId"] = load_state().get("takeoverPlaylistId")
        except EngineError as exc:
            _playlists["note"] = tr("Konnte die Takeover-Playlist nicht anlegen: {exc}", exc=exc)
            plugin.log(_playlists["note"], level="warning")
        try:
            _playlists["ownerNote"] = maintain_owner_playlist(settings())
        except EngineError as exc:
            _playlists["ownerNote"] = tr("Konnte die Playlist Growing Up nicht pflegen: {exc}", exc=exc)


def owner_playlist_text(values, state):
    if values["MakePlaylist"]:
        if state.get("ownerPlaylistId"):
            return tr("Angelegt: die Playlist Growing Up steht unter Playlists.")
        return _playlists["ownerNote"] or tr("Noch nicht angelegt; das passiert innerhalb einer Minute.")
    if state.get("ownerPlaylistDeleted"):
        return tr("Die Playlist wurde gelöscht, deshalb steht das wieder auf Nein.")
    if state.get("ownerPlaylistId"):
        return tr("Die früher angelegte Playlist steht noch unter Playlists; das Plugin pflegt sie nicht mehr.")
    return ""


# --------------------------------------------------------------------------
# Taking over the screen and handing it back
# --------------------------------------------------------------------------

TERMINAL_STATES = {"released", "expired", "failed", "preempted"}

_takeover_lock = threading.Lock()
_takeover = {"handle": None, "reason": None, "since": None, "until": None, "started": False,
             "token": 0, "note": "", "focus": None, "asking": False}
_schedule = {"nextAt": 0.0, "lastAt": 0.0}
_stop_requested = threading.Event()
_wake = threading.Event()


def takeover_supported():
    try:
        info = engine_call("GET", "/plugins/platform") or {}
    except EngineError:
        return True  # can't tell: the attempt itself will say
    features = info.get("features")
    return "display-sessions-v1" in features if isinstance(features, list) else True


def takeover_permission_note():
    try:
        config = engine_call("GET", "/plugins/display-takeover") or {}
    except EngineError:
        return ""
    row = next((r for r in config.get("plugins") or [] if r.get("pluginName") == PLUGIN_ID), None)
    enabled = config.get("enabledPluginNames")
    if row is not None and not row.get("pluginEnabled", True):
        return tr("Growing Up ist auf der Plugins-Seite ausgeschaltet.")
    if isinstance(enabled, list) and PLUGIN_ID not in enabled:
        return tr("„Allow takeover“ ist für Growing Up auf der Plugins-Seite aus, deshalb kann es "
                  "den Bildschirm nicht übernehmen.")
    return ""


def display_is_off():
    """Only true when the frame says the screen is off. Growing Up never wakes a screen."""
    try:
        power = engine_call("GET", "/display/power", read_timeout=5) or {}
    except EngineError:
        return False
    if power.get("isWaking"):
        return False
    return bool(power.get("isSleeping")) or str(power.get("state", "")).lower() == "off"


def scene_on_screen():
    """Is the scene playing as a normal playlist item right now? A takeover
    on top leaves the frame stopped afterwards (known bug), and the faces are
    on screen anyway."""
    if _scene["dbId"] is None:
        return False
    try:
        status = engine_call("GET", "/slideshow/status?includeCurrentItem=true", read_timeout=5) or {}
    except EngineError:
        return False
    item = status.get("currentItem") or {}
    return bool(status.get("isRunning") and item.get("dynamicSceneId") == _scene["dbId"]
                and not same_id(status.get("activePlaylistId"), _playlists["takeoverId"]))


def _note(text):
    with _takeover_lock:
        _takeover["note"] = text
    if text:
        plugin.log(text)
    return False


def _on_session_state(handle_or_state):
    """The SDK calls this with the handle, not with the new state."""
    new_state = str(getattr(handle_or_state, "state", handle_or_state)).strip().lower()
    if new_state not in TERMINAL_STATES:
        return
    with _takeover_lock:
        handle = _takeover["handle"]
        if handle is None or (not isinstance(handle_or_state, str) and handle is not handle_or_state):
            return
        _takeover.update(handle=None, reason=None, since=None, until=None, started=False, focus=None,
                         note=tr("Der Rahmen hat die Anzeige beendet ({state}).", state=new_state))
    plugin.log(f"The frame ended Growing Up: {new_state}.")
    threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()


def end_takeover(reason, token=None):
    """Hand the screen back. Safe to call more than once."""
    with _takeover_lock:
        if token is not None and token != _takeover["token"]:
            return False
        handle = _takeover["handle"]
        _takeover.update(handle=None, reason=None, since=None, until=None, started=False, focus=None, note="")
    if handle is None:
        return False
    try:
        handle.release()
    except Exception as exc:
        plugin.log(f"Could not hand the screen back: {exc}", level="warning")
    plugin.log(f"Screen handed back ({reason}).")
    if reason != "stopped":
        threading.Thread(target=check_playback_resumed, name=f"{PLUGIN_ID}-resumed", daemon=True).start()
    return True


def _release_after(seconds, token):
    if _stop_requested.wait(max(1, int(seconds))):
        return
    end_takeover("done", token)


def show_scene(reason="show", seconds=None, focus=None):
    """Put the scene over everything for `seconds`. True if the frame gave up the screen."""
    if _takeover["handle"] is not None:
        return _note(tr("Growing Up ist schon auf dem Bildschirm."))
    if not any((_people.get(p) or {}).get("frames") for p in settings()["People"]):
        return _note(tr("Noch keine Porträts: wähle Personen aus und warte, bis sie ausgeschnitten sind."))
    if not takeover_supported():
        return _note(tr("Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen."))
    if _scene["dbId"] is None:
        find_scene()
    if _scene["dbId"] is None or _scene["note"]:
        return _note(_scene["note"] or tr("Die Szene Growing Up wurde nicht gefunden."))
    if not _playlists["takeoverId"]:
        maintain_playlists(force=True)
    playlist_id = _playlists["takeoverId"]
    if not playlist_id:
        return _note(_playlists["note"] or tr("Die Takeover-Playlist ist noch nicht angelegt."))
    if scene_on_screen():
        return _note(tr("Growing Up läuft gerade in deiner Playlist; die Anzeige bleibt so."))
    if display_is_off():
        return _note(tr("Der Bildschirm ist aus. Growing Up weckt ihn nicht."))
    seconds = int(seconds or settings()["ShowForSeconds"])
    state = {"playback": {"kind": "playlist", "playlistId": playlist_id, "isRunning": True},
             "settings": {"durationSeconds": TAKEOVER_ITEM_SECONDS, "randomizeOrder": False},
             "overlay": {"enabled": False}}
    # The scene loads and polls before acquire returns: set the focus first.
    with _takeover_lock:
        _takeover.update(focus=focus, asking=True)
    try:
        _leftover["askedAt"] = time.time()
        handle = plugin.acquire_display_session(
            session_key=reason, state=state, display_name=DISPLAY_NAME,
            # A bit longer than wanted: the timer below is the proper end, the
            # engine limit only matters if the plugin dies.
            max_duration_seconds=seconds + 10, wake_if_off=False)
    except Exception as exc:
        handle = None
        error = exc
    else:
        error = None
    finally:
        with _takeover_lock:
            _takeover["asking"] = False
    if error is not None:
        return _note(tr("Konnte Growing Up nicht anzeigen: {exc}", exc=error))
    if handle is None:
        return _note(takeover_permission_note() or tr("Etwas anderes hat gerade den Bildschirm."))
    t = now()
    with _takeover_lock:
        _takeover["token"] += 1
        token = _takeover["token"]
        _takeover.update(handle=handle, reason=reason, since=t, until=t + seconds, started=False,
                         note="", focus=focus)
    try:
        handle.on_state_change(_on_session_state)
    except Exception:
        pass
    try:
        if not handle.wait_until_active(timeout=10):
            end_takeover("failed", token)
            return _note(tr("Der Rahmen hat Growing Up nicht rechtzeitig angezeigt."))
    except Exception as exc:
        end_takeover("failed", token)
        return _note(tr("Konnte Growing Up nicht anzeigen: {exc}", exc=exc))
    with _takeover_lock:
        if _takeover["token"] != token or _takeover["handle"] is None:
            return False
        _takeover["started"] = True
    plugin.log(f"Growing Up on screen for {seconds} seconds ({reason}).")
    threading.Thread(target=_release_after, args=(seconds, token),
                     name=f"{PLUGIN_ID}-timer", daemon=True).start()
    return True


def cancel_scene():
    if not end_takeover("cancelled"):
        _note(tr("Growing Up hatte den Bildschirm nicht."))


def toggle_scene():
    if _takeover["handle"] is not None:
        cancel_scene()
    else:
        show_scene("show")


_action_lock = threading.Lock()


def run_action(name, focus=None):
    """Show, Cancel and Toggle answer right away and work in a thread."""
    work = {"show": lambda: show_scene("show", focus=focus), "cancel": cancel_scene, "toggle": toggle_scene}[name]
    showing = _takeover["handle"] is not None
    asking, returning = tr("Bitte den Rahmen um den Bildschirm."), tr("Gebe den Bildschirm zurück.")
    message = {"show": asking, "cancel": returning, "toggle": returning if showing else asking}[name]

    def run():
        with _action_lock:
            try:
                work()
            except Exception as exc:  # pragma: no cover
                _note(tr("{name} hat nicht geklappt: {exc}", name=name, exc=exc))
    threading.Thread(target=run, name=f"{PLUGIN_ID}-{name}", daemon=True).start()
    return {"success": True, "message": message}


# ---- Takeover playlist that keeps running after the release ---------------
# If nothing played before a takeover, the engine doesn't restore that
# "nothing" and the takeover playlist keeps running (Jan's frame, 2026-10-24).
# Every round stops it with POST /slideshow/stop: only when it runs, nobody
# holds the screen and the plugin didn't just ask for it itself.
_leftover = {"askedAt": 0.0, "failed": False}


def stop_leftover_takeover():
    try:
        playlist_id = _playlists["takeoverId"]
        if _takeover["handle"] is not None or not playlist_id or time.time() - _leftover["askedAt"] < 30:
            return False
        status = engine_call("GET", "/slideshow/status", read_timeout=5) or {}
        if not (status.get("isRunning") and str(status.get("activePlaylistId")) == str(playlist_id)):
            return False
        if (engine_call("GET", "/display-sessions/status", read_timeout=5) or {}).get("active"):
            return False
        engine_call("POST", "/slideshow/stop", read_timeout=10)
    except Exception as exc:  # noqa: BLE001 - must never stop the loop
        if not _leftover["failed"]:
            plugin.log(f"The takeover playlist kept running and could not be stopped: {exc}", level="warning")
        _leftover["failed"] = True
        return False
    _leftover["failed"] = False
    plugin.log("Nothing was playing before the takeover, so the takeover playlist that kept running was stopped.")
    return True


def check_playback_resumed():
    if playback_guard is not None:
        outcome = playback_guard.restore_if_stalled(engine_base(), engine_headers, plugin.log,
                                                    stop_event=_stop_requested)
        if outcome == "not-requested":
            save_state(playbackStalled="")
            return
    elif _stop_requested.wait(12):
        return
    if _stop_requested.is_set():
        return
    try:
        status = engine_call("GET", "/slideshow/status") or {}
    except EngineError:
        return
    if status.get("isRunning") or _takeover["handle"] is not None:
        save_state(playbackStalled="")
        return
    message = tr("Der Rahmen ist nach Growing Up nicht zu deiner Playlist zurückgekehrt. Starte sie auf "
                 "der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix "
                 "passiert das nicht.")
    save_state(playbackStalled=message)
    plugin.log(message, level="warning")


# ---- The schedule -----------------------------------------------------------

def in_active_hours(values, moment=None):
    hour = (moment or datetime.now()).hour
    start, end = values["ActiveFrom"], values["ActiveTo"]
    if start == end:
        return True
    if start < end:
        return start <= hour < end
    return hour >= start or hour < end  # past midnight, e.g. 18 to 2


_auto = {"note": ""}


def decide_takeover():
    values = settings()
    if _takeover["handle"] is not None:
        with _takeover_lock:
            handle = _takeover["handle"]
        if handle is not None and str(getattr(handle, "state", "")) in TERMINAL_STATES:
            _on_session_state(handle)
        return
    focus = None
    if values["AutoMode"] == "off":
        _auto["note"], _schedule["nextAt"] = tr("Regelmäßige Anzeige ist aus."), 0.0
        return
    if values["AutoMode"] == "birthday":
        today = birthday_people(values)
        if not today:
            _auto["note"], _schedule["nextAt"] = tr("Heute hat niemand Geburtstag."), 0.0
            return
        focus = {"birthday": today}
    if not in_active_hours(values):
        _auto["note"] = tr("Außerhalb von {start}–{end} Uhr.", start=values["ActiveFrom"], end=values["ActiveTo"])
        _schedule["nextAt"] = 0.0
        return
    _auto["note"] = ""
    t = now()
    if not _schedule["nextAt"]:
        _schedule["nextAt"] = max(t + 60, _schedule["lastAt"] + values["EveryMinutes"] * 60)
    if t < _schedule["nextAt"]:
        return
    if show_scene("birthday" if focus else "schedule", focus=focus):
        _schedule["lastAt"] = t
        _schedule["nextAt"] = t + values["EveryMinutes"] * 60
    else:
        _schedule["nextAt"] = t + 120


# --------------------------------------------------------------------------
# The loop
# --------------------------------------------------------------------------

TICK_SECONDS = 15
_loop = {"lastCheckAt": None, "lastError": "", "force": False}


def tick(force=False):
    try:
        stop_leftover_takeover()
        maintain_playlists(force)
        threading.Thread(target=data_round, args=(force,), name=f"{PLUGIN_ID}-data", daemon=True).start()
        decide_takeover()
        _loop.update(lastCheckAt=local_text(now()), lastError="")
    except Exception as exc:  # pragma: no cover - the loop must keep running
        _loop["lastError"] = str(exc)
        plugin.log(f"Round failed: {exc}", level="error")


def main_loop():
    _stop_requested.wait(3)
    while not _stop_requested.is_set():
        _wake.clear()
        force, _loop["force"] = _loop["force"], False
        tick(force)
        _wake.wait(TICK_SECONDS)


def check_now():
    _loop["force"] = True
    _wake.set()
    return {"success": True, "message": tr("Fragt Immich jetzt neu.")}


def test_connection(values=None):
    values = values or settings()
    try:
        info = server_info(values)
        list_people(force=True)
    except ImmichError as exc:
        return {"success": True, "ok": False, "message": str(exc)}
    return {"success": True, "ok": True,
            "message": tr("Verbunden mit Immich {version} als {user}.", version=info["version"], user=info["user"])}


def status_line():
    values = settings()
    if not values["ServerUrl"] or not values["ApiKey"]:
        return tr("Noch nicht mit Immich verbunden.")
    if not values["People"]:
        return tr("Noch keine Person ausgewählt.")
    with _data_lock:
        busy = next((e["busy"] for e in _people.values() if e.get("busy")), "")
        error = next((e["error"] for e in _people.values() if e.get("error")), "")
        count = sum(len(e.get("frames") or []) for e in _people.values())
    if error:
        return error
    if busy:
        return busy
    if len(values["People"]) == 1:
        return tr("{n} Porträts von {name} bereit.", n=count, name=person_name(values["People"][0]) or "?")
    return tr("{n} Porträts von {people} Personen bereit.", n=count, people=len(values["People"]))


# --------------------------------------------------------------------------
# The plugin page
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


def state_payload():
    values = settings()
    state = load_state()
    with _takeover_lock:
        takeover = {"active": _takeover["handle"] is not None, "reason": _takeover["reason"],
                    "until": local_text(_takeover["until"]), "note": _takeover["note"]}
    shown = dict(values)
    shown["ApiKey"] = ""
    key = values["ApiKey"]
    people = []
    with _data_lock:
        for person_id in values["People"]:
            entry = _people.get(person_id) or {}
            rows = entry.get("rows") or []
            people.append({"id": person_id, "name": entry.get("name") or person_name(person_id),
                           "immichBirthDate": entry.get("birthDate") or "",
                           "birthDate": values["Birthdays"].get(person_id) or entry.get("birthDate") or "",
                           "photos": entry.get("total") or 0,
                           "withFace": sum(1 for r in rows if r.get("box")),
                           "frames": entry.get("frames") or [],
                           "excluded": len(values["Excluded"].get(person_id) or []),
                           "busy": entry.get("busy") or "", "error": entry.get("error") or "",
                           "at": local_text(entry.get("at"))})
    return {
        "success": True,
        "version": version(),
        "settings": shown,
        "key": {"set": bool(key), "hint": ("…" + key[-4:]) if len(key) >= 8 else ("✓" if key else "")},
        "adoptedFrom": state.get("adoptedFrom") or "",
        "pillow": faces.Image is not None,
        "people": people,
        "status": status_line(),
        "scene": {"found": _scene["dbId"] is not None, "note": _scene["note"]},
        "takeover": takeover,
        "permission": takeover_permission_note(),
        "next": local_text(_schedule["nextAt"]) if _schedule["nextAt"] else "",
        "autoNote": _auto["note"],
        "birthdays": birthday_people(values),
        "ownerPlaylist": owner_playlist_text(values, state),
        "lastCheckAt": _loop["lastCheckAt"],
        "lastError": _loop["lastError"] or _loop_info["lastError"] or state.get("playbackStalled") or "",
        "theme": {"id": theme_id()},
    }


def settings_saved(changed):
    values = settings()
    if "MakePlaylist" in changed:
        if values["MakePlaylist"]:
            save_state(ownerPlaylistDeleted=False)
        threading.Thread(target=maintain_playlists, kwargs={"force": True}, daemon=True).start()
    touched = set(changed)
    if touched & {"ServerUrl", "ApiKey"}:
        _people_list.update(at=0.0, rows=[])
        with _data_lock:
            for entry in _people.values():
                entry["error"] = ""
        _force.update(values["People"])
    if "People" in touched:
        for person_id in values["People"]:
            if person_id not in _people:
                _force.add(person_id)
    if touched & {"Interval", "MaxFrames", "MinFace", "Zoom", "Birthdays", "Excluded"}:
        _rebuild.update(values["People"])
    if touched & {"AutoMode", "EveryMinutes", "ActiveFrom", "ActiveTo"}:
        _schedule["nextAt"] = 0.0
    bump()
    _wake.set()


def exclude(person_id, asset_id, undo=False):
    values = settings()
    current = dict(values["Excluded"])
    ids = list(current.get(person_id) or [])
    if undo:
        ids = []
    elif asset_id not in ids:
        ids.append(asset_id)
    if ids:
        current[person_id] = ids
    else:
        current.pop(person_id, None)
    changed = save_settings({"Excluded": current})
    if changed:
        settings_saved(changed)
    return {"success": True}


PORTRAIT = re.compile(r"^/api/portrait/([0-9a-f-]{36})/([0-9a-f-]{36})-([a-z]+)\.jpg$")


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, because the WebUI proxy keeps connections open.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """The plugin log is the log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # The scene comes from the engine's port, this page via :8003.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        """Read the whole body: unread bytes on an open connection would
        become the start of the next request."""
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = unquote(urlparse(self.path).path)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(snapshot(), cors=True)
                return
            match = PORTRAIT.match(path)
            if match and UUID.match(match.group(1)) and UUID.match(match.group(2)) and match.group(3) in faces.ZOOMS:
                file = crop_path(match.group(1), match.group(2), match.group(3))
                if file.exists():
                    self._send(file.read_bytes(), "image/jpeg", cache="public, max-age=604800, immutable", cors=True)
                else:
                    self._json({"success": False, "error": "Not found"}, 404, cors=True)
                return
            if path == "/api/people":
                try:
                    self._json({"success": True, "people": list_people()})
                except ImmichError as exc:
                    self._json({"success": False, "error": str(exc)}, 502)
                return
            parts = path.strip("/").split("/")
            if len(parts) == 3 and parts[:2] == ["api", "face"] and UUID.match(parts[2]):
                try:
                    body, kind = face_thumb(parts[2])
                except ImmichError as exc:
                    self._json({"success": False, "error": str(exc)}, 404 if exc.status == 404 else 502)
                    return
                self._send(body, kind, cache="private, max-age=3600")
                return
            self._json({"success": False, "error": "Not found"}, 404)
        except (BrokenPipeError, ConnectionResetError):
            pass  # the page stopped loading
        except OSError as exc:
            self._json({"success": False, "error": f"Could not read a plugin file: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                # An empty key field means "keep", not "delete".
                if "ApiKey" in body and not str(body.get("ApiKey") or "").strip():
                    body.pop("ApiKey")
                changed = save_settings(body)
                if changed:
                    settings_saved(changed)
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/test":
                self._json(test_connection())
                return
            if path == "/api/refresh":
                self._json(check_now())
                return
            if path == "/api/exclude":
                body = self._body()
                person_id, asset_id = str(body.get("person") or ""), str(body.get("asset") or "")
                if not UUID.match(person_id) or not (UUID.match(asset_id) or body.get("undo")):
                    self._json({"success": False, "error": "Bad request"}, 400)
                    return
                self._json(exclude(person_id, asset_id, bool(body.get("undo"))))
                return
            if path == "/api/show":
                body = self._body()
                person_id = str(body.get("person") or "")
                focus = {"person": person_id} if UUID.match(person_id) else None
                self._json(run_action("show", focus))
                return
            if path in ("/api/cancel", "/api/toggle"):
                self._json(run_action(path.rsplit("/", 1)[-1]))
                return
            self._json({"success": False, "error": "Not found"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """The page on loopback; tell the host the port actually bound."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    studio_server.daemon_threads = True
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    plugin.log(f"Plugin page at {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    ensure_dirs()
    plugin.log(f"Starting {PLUGIN_ID} {version()}")
    if faces.Image is None:
        plugin.log("Pillow is missing, so no portraits can be cut out. Install the package again.", level="error")
    adopt_immich_login()
    load_cache()

    # Everything the host can call must exist before ready().
    plugin.on_action("refresh", lambda _context=None: check_now())
    plugin.on_action("show", lambda _context=None: run_action("show"))
    plugin.on_action("cancel", lambda _context=None: run_action("cancel"))
    plugin.on_action("toggle", lambda _context=None: run_action("toggle"))

    start_studio()
    plugin.connect_sse()
    plugin.ready()

    threading.Thread(target=main_loop, name=f"{PLUGIN_ID}-loop", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    end_takeover("stopped")
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    plugin.log(f"{PLUGIN_ID} stopped.")


if __name__ == "__main__":
    main()
