#!/usr/bin/env python3
"""Color Reveal - der Plugin-Teil des Pakets.

Die Szene "color-reveal" zeigt ein Foto nach dem anderen. Jedes beginnt in
Schwarz-Weiß und wird innerhalb weniger Sekunden langsam farbig: gleichmäßig,
zuerst im Licht, von der farbigsten Stelle aus oder wie ein Pinselstrich.
Die Szene rechnet das mit der Grafikkarte (WebGL), auf dem Pi 4 flüssig.

Dieses Plugin
- sammelt die Fotos aus DynaFrame (Playlist, ganze Mediendatenbank, Ordner)
  oder von einem Immich-Server, mit den Filtern wie bei Photo Mosaic,
- wählt das nächste Foto, verkleinert es passend zum Bildschirm und sucht
  dabei die farbigste Stelle (dort beginnt die Farbe beim Stil „Von der
  Farbe aus“). Fotos, die schon schwarz-weiß sind, lässt es auf Wunsch aus.
  Die Szene holt immer schon das nächste Foto, während das aktuelle zu sehen ist.
"""

import datetime
import hashlib
import io
import json
import os
import random
import re
import sys
import threading
import time
import uuid
from collections import OrderedDict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse


def _await_dependencies():
    """Nach einem Update baut DynaFrame das venv (requests, Pillow) neu auf und
    startet das Plugin manchmal schon, bevor pip fertig ist. Dann nicht mit
    Exit 1 aufgeben (die Engine startet nicht neu), sondern warten und den
    Prozess frisch starten, bis die Pakete da sind (höchstens etwa 10 Minuten)."""
    try:
        import requests  # noqa: F401
        import PIL  # noqa: F401
        return
    except ImportError as error:
        tries = int(os.environ.get("CR_DEP_TRIES", "0"))
        if tries >= 40:
            raise
        sys.stderr.write(f"ColorReveal: {error}; warte auf die Installation der Pakete ({tries + 1}/40)\n")
        sys.stderr.flush()
        time.sleep(15)
        os.environ["CR_DEP_TRIES"] = str(tries + 1)
        os.execv(sys.executable, [sys.executable] + sys.argv)


_await_dependencies()
import requests  # noqa: E402


def _crash_hook(kind, value, tb):
    """Jeden Absturz (auch beim Laden) nach data/last_crash.txt schreiben: die Engine speichert stderr nirgends."""
    import traceback
    try:
        path = Path(__file__).resolve().parent / "data" / "last_crash.txt"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(time.strftime("%Y-%m-%d %H:%M:%S\n") + "".join(traceback.format_exception(kind, value, tb)),
                        encoding="utf-8")
    except Exception:
        pass
    sys.__excepthook__(kind, value, tb)


sys.excepthook = _crash_hook

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import dynaframe_filters  # noqa: E402
import immich_filters  # noqa: E402
import own_playlist  # noqa: E402
import sources  # noqa: E402
import texts  # noqa: E402

plugin = create_plugin()

PLUGIN_ID = "ColorReveal"
SCENE_ID = "color-reveal"          # id in scene.dynamic - nie ändern
PLAYLIST_NAME = "Color Reveal"     # in allen Sprachen englisch (Jans Regel, 12.11.2026)
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen, Stand; bleibt bei Updates

CONNECT_TIMEOUT = 10
MAX_SOURCES = 6
MAX_EDGE = 3840                     # größer wird kein Foto ausgeliefert (4K)
PREPARED_KEEP = 6                   # so viele vorbereitete Fotos hält das Plugin im Speicher

KINDS = ("library", "playlist", "immich_all", "immich_album")
STYLES = ("fade", "light", "focus", "brush", "mix")
LAYOUTS = ("auto", "fill", "fit", "gallery")
BACKGROUNDS = ("light", "dark")
BW_LOOKS = ("neutral", "contrast", "warm")
PHOTO_ORDERS = ("random", "newest", "oldest")


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält den API-Schlüssel
        except OSError:
            pass


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

def default_sources():
    return [{"id": "s1", "kind": "library", "ref": "", "name": ""}]


SCHEMA = {
    "Language":        {"kind": "choice", "default": "en", "choices": texts.LANGUAGES},
    "ServerUrl":       {"kind": "url", "default": ""},
    "ApiKey":          {"kind": "secret", "default": ""},
    "Sources":         {"kind": "sources", "default": None},
    # Immich- und DynaFrame-Filter wie Photo Mosaic (alle Gruppen)
    **immich_filters.schema(),
    **dynaframe_filters.schema(),
    "Style":           {"kind": "choice", "default": "fade", "choices": STYLES},
    "RevealSeconds":   {"kind": "int", "default": 6, "min": 2, "max": 30},
    "RevealDelay":     {"kind": "int", "default": 2, "min": 0, "max": 20},
    "ColourStrength":  {"kind": "int", "default": 100, "min": 40, "max": 100},
    "BwLook":          {"kind": "choice", "default": "neutral", "choices": BW_LOOKS},
    "BackToBw":        {"kind": "bool", "default": False},
    "SkipBw":          {"kind": "bool", "default": True},
    "Layout":          {"kind": "choice", "default": "auto", "choices": LAYOUTS},
    "Background":      {"kind": "choice", "default": "dark", "choices": BACKGROUNDS},
    "SlowZoom":        {"kind": "bool", "default": False},
    "ShowDate":        {"kind": "bool", "default": False},
    "PhotoSeconds":    {"kind": "int", "default": 20, "min": 6, "max": 3600},
    "PhotoOrder":      {"kind": "choice", "default": "random", "choices": PHOTO_ORDERS},
    "Folders":         {"kind": "folders", "default": ""},
    "RefreshHours":    {"kind": "int", "default": 6, "min": 1, "max": 168},
    "PlaylistSeconds": {"kind": "int", "default": 300, "min": 10, "max": 86400},
    "MakePlaylist":    {"kind": "bool", "default": False},
}
SECRETS = [name for name, spec in SCHEMA.items() if spec["kind"] == "secret"]
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()


def coerce_sources(raw):
    if raw is None:
        return default_sources()
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return default_sources()
    out, ids = [], set()
    for row in raw if isinstance(raw, list) else []:
        if not isinstance(row, dict) or len(out) >= MAX_SOURCES:
            continue
        ident = re.sub(r"[^A-Za-z0-9]", "", str(row.get("id") or ""))[:16] or uuid.uuid4().hex[:8]
        while ident in ids:
            ident = uuid.uuid4().hex[:8]
        ids.add(ident)
        out.append({
            "id": ident,
            "kind": row.get("kind") if row.get("kind") in KINDS else "library",
            # Immich-Alben: mehrere IDs mit Komma (wie bei Growing Up)
            "ref": ",".join(dict.fromkeys(p for p in (re.sub(r"[^A-Za-z0-9_-]", "", part)[:64]
                                                      for part in str(row.get("ref") or "").split(",")) if p))[:2000],
            "name": re.sub(r"\s+", " ", str(row.get("name") or "")).strip()[:60],
        })
    return out


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind in ("ref", "date", "name"):
        return immich_filters.coerce(spec, raw)
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "choice":
        value = str(raw if raw is not None else "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "sources":
        return coerce_sources(raw)
    if kind == "url":
        return sources.normalize_url(raw)[:300]
    if kind == "text":
        return re.sub(r"\s+", " ", str(raw or "")).strip()[:60]
    if kind == "folders":
        lines = [line.strip() for line in str(raw or "").replace(";", "\n").splitlines()]
        return "\n".join(line for line in lines if line.startswith("/"))[:2000]
    return re.sub(r"\s+", "", str(raw or ""))[:400]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 120))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def engine_image(media_id, path=""):
    """Das Vorschaubild, das die Engine für die Weboberfläche erzeugt (auf Jans Rahmen 512 Pixel)."""
    candidates = []
    if path:
        candidates += [("/media/thumbnail", {"path": path, "purpose": "preview"}),
                       ("/media/thumbnail", {"path": path})]
    if media_id:
        candidates += [(f"/media/thumbnail/{media_id}", {"purpose": "preview"}),
                       (f"/media/thumbnail/{media_id}", None)]
    failures = []
    for route, params in candidates:
        try:
            response = requests.get(f"{engine_base()}{route}", params=params, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 60))
        except requests.RequestException as exc:
            failures.append(f"{route}: {exc}")
            continue
        kind = response.headers.get("Content-Type", "").split(";")[0]
        if response.status_code == 200 and kind.startswith("image/"):
            return response.content
        failures.append(f"{route}{'?path' if params and 'path' in params else ''}: HTTP {response.status_code} {kind}")
    raise sources.SourceError(f"Vorschaubild {media_id}: " + "; ".join(failures))


# --------------------------------------------------------------------------
# Die Fotos (Liste aus den Quellen)
# --------------------------------------------------------------------------

immich = sources.Immich(tr)
dynaframe = sources.DynaFrame(engine_call, EngineError, log)

LIST_FILE = DATA_DIR / "photos.json"
_scan_lock = threading.Lock()
_scan_wake = threading.Event()
_stop_requested = threading.Event()
_scan_stop = threading.Event()
_data = {
    "ver": 0,
    "photos": [],         # [key, taken, size]
    "status": {},         # source id -> {state, total, error, at}
    "busy": False, "at": 0.0, "signature": "",
    "progress": {"done": 0, "phase": ""},
    "dfCount": None,
}


def scan_signature(values):
    wanted = [(s["id"], s["kind"], s["ref"]) for s in values["Sources"]]
    # Nur ein Hash wird gespeichert: im Klartext stünde der Immich-Schlüssel in der Datei.
    text = json.dumps([wanted, values["ServerUrl"], values["ApiKey"], values["Folders"],
                       immich_filters.signature(values), dynaframe_filters.signature(values), version()],
                      sort_keys=True)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def collect(source, values, stop, match=None):
    kind = source["kind"]
    if kind in ("immich_all", "immich_album"):
        immich.configure(values["ServerUrl"], values["ApiKey"])
        albums = [a for a in source["ref"].split(",") if a] if kind == "immich_album" else None
        if kind == "immich_album" and not albums:
            raise sources.SourceError(tr("Wähle ein Album."))
        return immich.photos(albums, stop, lambda n: _data["progress"].update(phase="list", done=n),
                             immich_filters.from_settings(values))
    if kind == "playlist":
        if not source["ref"]:
            raise sources.SourceError(tr("Wähle eine Playlist."))
        try:
            rows, total = dynaframe.playlist(source["ref"], stop)
        except EngineError as exc:
            if exc.status == 404:
                raise sources.SourceError(tr("Die Playlist gibt es nicht mehr.")) from exc
            raise sources.SourceError(tr("DynaFrame antwortet nicht: {exc}", exc=exc)) from exc
    else:
        folders = [f for f in values["Folders"].splitlines() if f]
        try:
            rows, total = dynaframe.library(folders, stop, lambda n: _data["progress"].update(phase="list", done=n))
        except EngineError as exc:
            raise sources.SourceError(tr("DynaFrame antwortet nicht: {exc}", exc=exc)) from exc
    if match is not None:
        rows = [r for r in rows if match.keep(r[1])]
    return rows, total


def scan(reason=""):
    """Alle Quellen einlesen (nur die Liste, keine Bilder). Läuft im Hintergrund."""
    values = settings()
    with _scan_lock:
        if _data["busy"]:
            return
        _data["busy"] = True
        _scan_stop.clear()
    _data["progress"] = {"done": 0, "phase": "list"}
    log(f"Lese die Fotos ein{' - ' + reason if reason else ''}.")
    started = now()
    rows, status = {}, {}
    match = None
    if dynaframe_filters.active(values) and any(s["kind"] in ("library", "playlist") for s in values["Sources"]):
        match = dynaframe_filters.Matcher(values, lambda: dynaframe.library_rows(_scan_stop),
                                          cache_file=str(DATA_DIR / "file_meta.json"), log=log)
    try:
        for source in values["Sources"]:
            sid = source["id"]
            _data["status"][sid] = dict(_data["status"].get(sid) or {}, state="busy")
            try:
                found, total = collect(source, values, _scan_stop, match)
                for row in found:
                    rows.setdefault(row[1], row)
                status[sid] = {"state": "ok", "total": total, "used": len(found), "error": "", "at": now()}
            except (sources.SourceError, EngineError) as exc:
                status[sid] = {"state": "error", "total": 0, "used": 0, "error": str(exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except Exception as exc:  # pragma: no cover - darf den Durchlauf nicht beenden
                status[sid] = {"state": "error", "total": 0, "used": 0, "error": str(exc)[:200], "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc!r}", "warning")
            _data["status"][sid] = status[sid]
            if _scan_stop.is_set() or _stop_requested.is_set():
                break
        if match is not None:
            match.save()
        _data["dfCount"] = match.counts() if match is not None else None
        if _scan_stop.is_set() or _stop_requested.is_set():
            log("Einlesen abgebrochen.")
            return
        photos = []
        for taken, key, _job, stamp in rows.values():
            size = str(stamp).split(":")[0] if key.startswith("d:") else ""
            photos.append([key, taken or "", size])
        with _scan_lock:
            _data.update(photos=photos, status=status, ver=_data["ver"] + 1, at=now(),
                         signature=scan_signature(values))
            _order["bag"] = []
        write_json(LIST_FILE, {"photos": photos, "status": status, "at": _data["at"],
                               "signature": _data["signature"]})
        log(f"{len(photos)} Fotos gefunden ({now() - started:.0f} s).")
    finally:
        _data["progress"] = {"done": 0, "phase": ""}
        with _scan_lock:
            _data["busy"] = False


def load_list():
    stored = read_json(LIST_FILE, {})
    if isinstance(stored, dict) and isinstance(stored.get("photos"), list):
        _data.update(photos=[p for p in stored["photos"] if isinstance(p, list) and len(p) == 3],
                     status=stored.get("status") or {}, at=stored.get("at") or 0.0,
                     signature=stored.get("signature") or "", ver=1)


def scan_loop():
    while not _stop_requested.is_set():
        values = settings()
        due = now() - _data["at"] >= values["RefreshHours"] * 3600
        if due or _data["signature"] != scan_signature(values):
            scan("geplant" if due else "Einstellungen")
        _scan_wake.wait(60)
        _scan_wake.clear()


def rescan_now():
    if _data["busy"]:
        _scan_stop.set()
    _data["at"] = 0.0
    _scan_wake.set()
    return {"success": True, "message": tr("Die Fotos werden neu eingelesen.")}


# --------------------------------------------------------------------------
# Das nächste Foto: auswählen, verkleinern, farbigste Stelle suchen
# --------------------------------------------------------------------------

PHOTO_MAX = 40 * 1024 * 1024
SHOWABLE = (".jpg", ".jpeg", ".jpe", ".png", ".webp", ".gif", ".bmp", ".tif", ".tiff")


def heif_ready():
    try:
        import pillow_heif
        pillow_heif.register_heif_opener()
        return True
    except Exception:
        return False


HEIF = heif_ready()
if HEIF:
    SHOWABLE += (".heic", ".heif")

_order = {"bag": [], "pos": 0, "recent": []}
_prepared = OrderedDict()      # token -> {jpeg, ...}
_prepared_lock = threading.Lock()
_prepare_lock = threading.Lock()   # immer nur ein Foto auf einmal (Pi schonen)
_last = {"taken": "", "at": 0.0, "name": "", "skipped": 0}


def webdav_dirs():
    seen = []
    for home in (Path.home(), Path("/home/pi")):
        folder = home / ".local/share/dfr/webdav-cache"
        if folder not in seen and folder.is_dir():
            seen.append(folder)
    return seen


def webdav_cached(path, size):
    """Fotos aus WebDAV (/webdav-media/<Quelle>/...) liefert die Engine nur als
    512-Pixel-Vorschau. Das Original legt DynaFrame aber in webdav-cache ab,
    als <Quelle>-<Hash>.<Endung>. Den Hash kennen wir nicht, also: gleiche
    Quelle, gleiche Endung, gleiche Dateigröße (wie bei Halloween Scare)."""
    if not path.startswith("/webdav-media/"):
        return None
    size = as_int(size, 0)
    if size <= 0 or size > PHOTO_MAX:
        return None
    parts = path.split("/")
    source = parts[2] if len(parts) > 2 else ""
    suffix = Path(path).suffix.lower()
    best = None
    for folder in webdav_dirs():
        try:
            entries = list(os.scandir(folder))
        except OSError:
            continue
        for entry in entries:
            name = entry.name
            if source and not name.startswith(source + "-"):
                continue
            if suffix and not name.lower().endswith(suffix):
                continue
            try:
                info = entry.stat()
            except OSError:
                continue
            if info.st_size == size and (best is None or info.st_mtime > best[0]):
                best = (info.st_mtime, Path(entry.path))
    return best[1] if best else None


def original_bytes(key, size):
    """Die Bytes des Fotos in möglichst guter Auflösung."""
    if key.startswith("i:"):
        values = settings()
        immich.configure(values["ServerUrl"], values["ApiKey"])
        return immich.photo(key[2:], size="preview")[0]
    path = key.partition("|")[2] if key.startswith("d:") else key[2:]
    if path and path.lower().endswith(SHOWABLE) and os.path.isfile(path):
        with open(path, "rb") as handle:
            return handle.read(PHOTO_MAX)
    if path:
        cached = webdav_cached(path, size)
        if cached:
            with open(cached, "rb") as handle:
                return handle.read(PHOTO_MAX)
    if key.startswith("d:"):
        return engine_image(key[2:].partition("|")[0], path)
    raise sources.SourceError("Datei nicht gefunden")


def exif_taken(image):
    try:
        exif = image.getexif()
        raw = exif.get_ifd(0x8769).get(36867) or exif.get(306)
    except Exception:
        return ""
    return sources.clean_taken(str(raw or "").replace(":", "-", 2))


class AlreadyBw(Exception):
    """Das Foto ist schon schwarz-weiß: da gibt es nichts farbig werden zu lassen."""


def colour_spot(image):
    """Wie farbig das Foto ist (0..1) und wo seine farbigste Stelle liegt (x, y in 0..1).

    Auf 64 Pixel verkleinert: Buntheit (Sättigung mal Helligkeit) je Pixel. Der
    Schwerpunkt der buntesten 3 % (hoch 3 gewichtet, damit ein kleines rotes Kleid
    gegen einen großen blassblauen Himmel gewinnt) ist die Stelle, an der die Farbe beim Stil „Von der
    Farbe aus“ zuerst erscheint; er bleibt etwas vom Rand weg."""
    small = image.copy()
    small.thumbnail((64, 64))
    hsv = small.convert("HSV")
    w, h = hsv.size
    raw = hsv.tobytes()
    weights = []
    for i in range(w * h):
        sat, val = raw[3 * i + 1], raw[3 * i + 2]
        weights.append((sat * val / 65025.0, i % w, i // w))
    if not weights:
        return 0.0, 0.5, 0.5
    weights.sort(reverse=True)
    top = [(wt ** 3, x, y) for wt, x, y in weights[:max(8, len(weights) * 3 // 100)]]
    total = sum(wt for wt, _x, _y in top)
    colourful = sum(wt for wt, _x, _y in weights[:max(1, len(weights) // 4)]) / max(1, len(weights) // 4)
    if total <= 0:
        return colourful, 0.5, 0.5
    fx = sum(wt * (x + 0.5) for wt, x, _y in top) / total / w
    fy = sum(wt * (y + 0.5) for wt, _x, y in top) / total / h
    clamp = lambda v: max(0.2, min(0.8, v))  # noqa: E731
    return colourful, round(clamp(fx), 3), round(clamp(fy), 3)


BW_LIMIT = 0.06   # darunter gilt ein Foto als schwarz-weiß (auch leicht getönte Abzüge)


def prepare(key, taken, size, box_w, box_h, values, skip_bw=True):
    """Foto holen, drehen, auf den Bildschirm verkleinern, farbigste Stelle suchen."""
    from PIL import Image, ImageOps

    data = original_bytes(key, size)
    with Image.open(io.BytesIO(data)) as image:
        if not taken:
            taken = exif_taken(image)
        try:
            image.draft("RGB", (box_w, box_h))       # JPEG gleich verkleinert dekodieren
        except (AttributeError, ValueError, OSError):
            pass
        image = ImageOps.exif_transpose(image)
        image = image.convert("RGB")
        image.thumbnail((box_w, box_h), Image.LANCZOS if max(image.size) < 4000 else Image.BILINEAR)
        colourful, fx, fy = colour_spot(image)
        if skip_bw and colourful < BW_LIMIT:
            raise AlreadyBw()
        out = io.BytesIO()
        image.save(out, "JPEG", quality=88, optimize=False, progressive=False)
        return {"jpeg": out.getvalue(), "w": image.width, "h": image.height, "focus": [fx, fy],
                "colourful": round(colourful, 3), "taken": taken[:10] if len(taken) >= 10 else ""}


def next_key():
    photos = _data["photos"]
    if not photos:
        return None
    mode = settings()["PhotoOrder"]
    if mode in ("newest", "oldest"):
        ordered = sorted(range(len(photos)), key=lambda i: photos[i][1] or "0000", reverse=(mode == "newest"))
        pick = ordered[_order["pos"] % len(ordered)]
        _order["pos"] += 1
        return photos[pick]
    if not _order["bag"]:
        bag = list(range(len(photos)))
        random.shuffle(bag)
        # Das gerade gezeigte nicht gleich wieder vorne
        recent = set(_order["recent"])
        bag.sort(key=lambda i: photos[i][0] in recent)
        _order["bag"] = bag
    idx = _order["bag"].pop()
    return photos[idx] if idx < len(photos) else None


def next_photo(query):
    """Das nächste Foto für die Szene vorbereiten. Bis zu 8 Versuche, falls Fotos fehlen
    oder schon schwarz-weiß sind. Sind alle Versuche schwarz-weiß, kommt das letzte trotzdem."""
    box_w = max(320, min(MAX_EDGE, as_int((query.get("w") or ["1920"])[0], 1920)))
    box_h = max(240, min(MAX_EDGE, as_int((query.get("h") or ["1080"])[0], 1080)))
    values = settings()
    with _prepare_lock:
        errors = []
        skipped = 0
        attempts = 8
        for attempt in range(attempts):
            with _scan_lock:
                row = next_key()
            if row is None:
                return {"success": False, "empty": True, "busy": _data["busy"]}
            key, taken, size = row
            last_try = attempt == attempts - 1 or len(_data["photos"]) <= skipped + 1
            try:
                done = prepare(key, taken, size, box_w, box_h, values,
                               skip_bw=values["SkipBw"] and not last_try)
            except AlreadyBw:
                skipped += 1
                continue
            except Exception as exc:  # noqa: BLE001 - ein kaputtes Foto darf die Szene nicht aufhalten
                errors.append(str(exc)[:160])
                continue
            token = uuid.uuid4().hex[:16]
            with _prepared_lock:
                _prepared[token] = done
                while len(_prepared) > PREPARED_KEEP:
                    _prepared.popitem(last=False)
            _order["recent"] = (_order["recent"] + [key])[-20:]
            name = Path(key.partition("|")[2] if key.startswith("d:") else key[2:]).name if not key.startswith("i:") else ""
            _last.update(taken=done["taken"], at=now(), name=name, skipped=_last.get("skipped", 0) + skipped)
            return {"success": True, "id": token, "w": done["w"], "h": done["h"], "focus": done["focus"],
                    "taken": done["taken"], "ver": _data["ver"]}
        for text in errors[:3]:
            log(f"Foto für die Szene: {text}", "warning")
        return {"success": False, "error": errors[-1] if errors else ""}


def photo_bytes(query):
    token = (query.get("id") or [""])[0]
    with _prepared_lock:
        done = _prepared.get(token)
    return done["jpeg"] if done else None


# --------------------------------------------------------------------------
# Playlist für die Szene
# --------------------------------------------------------------------------

def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=(PLAYLIST_NAME,),
    name=lambda: PLAYLIST_NAME,
    description=lambda: tr("Deine Fotos werden langsam farbig."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()


# --------------------------------------------------------------------------
# Was die Szene bekommt
# --------------------------------------------------------------------------

SCENE_SETTINGS = ("Language", "Style", "RevealSeconds", "RevealDelay", "ColourStrength", "BwLook", "BackToBw",
                  "Layout", "Background", "SlowZoom", "ShowDate", "PhotoSeconds")


def scene_payload():
    values = settings()
    return {
        "success": True,
        "ver": _data["ver"],
        "settings": {k: values[k] for k in SCENE_SETTINGS},
        "photos": len(_data["photos"]),
        "busy": _data["busy"],
    }


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    status = {}
    for source in values["Sources"]:
        row = dict(_data["status"].get(source["id"]) or {})
        if _data["busy"] and not row:
            row = {"state": "wait"}
        status[source["id"]] = row
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "status": status,
        "busy": _data["busy"],
        "progress": _data["progress"],
        "at": _data["at"],
        "photos": len(_data["photos"]),
        "last": {"name": _last["name"], "taken": _last["taken"], "at": _last["at"], "skipped": _last["skipped"]},
        "heif": HEIF,
        "libraryWay": dynaframe.library_way,
        "dfCount": _data.get("dfCount"),
        "theme": {"id": theme_id()},
    }


def test_immich():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        info = immich.test()
    except sources.SourceError as exc:
        return {"success": True, "ok": False, "message": str(exc)}
    return {"success": True, "ok": True,
            "message": tr("Verbunden als {user} (Immich {version}).", user=info["user"] or "?",
                          version=info["version"] or "?")}


def list_albums():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, "albums": immich.albums()}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_immich(what):
    """Personen bzw. Tags für die Immich-Filter."""
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, what: getattr(immich_filters, what)(immich)}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_playlists():
    try:
        rows = [p for p in dynaframe.playlists() if p["name"] != PLAYLIST_NAME]
        return {"success": True, "playlists": sorted(rows, key=lambda p: str(p["name"]).lower())}
    except EngineError as exc:
        return {"success": False, "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc)}


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(), cors=True)
                return
            if path == "/api/next":
                self._json(next_photo(query), cors=True)
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            if path == "/api/photo":
                found = photo_bytes(query)
                if found is None:
                    self._json({"success": False}, 404, cors=True)
                else:
                    self._send(found, "image/jpeg", cache="private, max-age=3600", cors=True)
                return
            if path == "/api/albums":
                self._json(list_albums())
                return
            if path in ("/api/people", "/api/tags"):
                self._json(list_immich(path.rsplit("/", 1)[1]))
                return
            if path == "/api/playlists":
                self._json(list_playlists())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                for name in SECRETS:
                    # Ein leeres Feld heißt: das alte behalten. Löschen geht mit "-".
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)
                    elif name in body and str(body[name]).strip() == "-":
                        body[name] = ""
                changed = save_settings(body)
                if "MakePlaylist" in changed:
                    OWN.changed()
                if set(changed) & {"PhotoOrder"}:
                    _order.update(bag=[], pos=0)
                if set(changed) & ({"Sources"} | set(immich_filters.SCHEMA) | set(dynaframe_filters.SCHEMA)):
                    # Strengere Filter sollen sofort greifen: alte Liste nicht weiter zeigen
                    with _scan_lock:
                        _data.update(photos=[], ver=_data["ver"] + 1)
                        _order["bag"] = []
                if changed and scan_signature(settings()) != _data["signature"]:
                    rescan_now()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(rescan_now())
                return
            if path == "/api/test":
                self._json(test_immich())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}" + ("" if HEIF else " (ohne HEIC-Unterstützung)"))

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: rescan_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())

    load_list()
    start_studio()
    plugin.connect_sse()
    plugin.ready()

    try:
        os.nice(5)   # Einlesen und Verkleinern sollen die Wiedergabe nicht stören
    except OSError:
        pass
    threading.Thread(target=scan_loop, name=f"{PLUGIN_ID}-scan", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _scan_stop.set()
    _scan_wake.set()
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
