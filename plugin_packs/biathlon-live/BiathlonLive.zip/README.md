# Biathlon Live

Biathlon Live zeigt Biathlon-Ergebnisse auf dem Rahmen: das Ergebnis jedes Rennens mit Platz, Nation, Schießen und Rückstand, während eines Rennens den Zwischenstand, dazu das Programm, die nächste Station und die Gesamtwertung. Voreingestellt sind der BMW IBU Weltcup und die Weltmeisterschaften; IBU-Cup, Europameisterschaften, Junioren- und Jugendserien, Sommerbiathlon-WM, Universiade und EYOF lassen sich dazuschalten.

Biathlon Live ist ein Nachbau des MagicMirror-Moduls [MMM-Biathlon](https://github.com/2hdlockness/MMM-Biathlon) von 2hdlockness (MIT-Lizenz) für DynaFrame: dieselbe Datenquelle, dieselben Serien und Einstellungen (Anzahl der Plätze, Zeit und Schießen ein/aus, nächste Station, Wechselintervall), dazu Live-Zwischenstand, Gesamtwertung und die Übernahme des Bildschirms.

Biathlon Live besteht aus zwei Teilen, die zusammen installiert werden:

- **Die Szene Biathlon Live** zeichnet Ergebnisse, Programm und Gesamtwertung. Jede Seite (ein Rennen, das Programm, die Gesamtwertung) wechselt im eingestellten Takt.
- **Das Plugin** liest die Daten, hält alle Einstellungen und legt die Szene nach Zeitplan über die laufende Playlist.

## Einrichten

1. Paket installieren (Plugins > Hochladen, oder über den Store).
2. Auf der Plugins-Seite bei Biathlon Live **Allow takeover** einschalten. Ohne das kann Biathlon Live die Playlist nicht kurz beiseiteschieben.
3. **Open Biathlon Live** öffnen und Serien, Rennen (Frauen, Männer, Mixed), Plätze, deine Nation, Takt und Anzeigedauer wählen. Alles wird sofort gespeichert.
4. Zum Ausprobieren **Anzeigen** drücken.

## Wie die Szene über die Playlist kommt

- **Regelmäßig (Takeover):** immer, nur an Renntagen (voreingestellt) oder nur während eines Rennens, alle X Minuten für Y Sekunden, zwischen *Von* und *Bis* Uhr. Ein ausgeschalteter Bildschirm wird nie geweckt.
- **Beim Rennen:** auf Wunsch sofort beim Start eines Rennens, beim Ergebnis oder bei beidem, mit diesem Rennen zuerst.
- **In einer Playlist:** Die Szene kann wie jedes Bild in eine Playlist (empfohlene Dauer 60 Sekunden). Mit *Eine Playlist dafür* legt das Plugin eine Playlist „Biathlon Live“ für dich an.

Die Playlist **Biathlon Live (takeover)** benutzt das Plugin selbst. Lass sie ausgeschaltet; wird sie gelöscht, legt das Plugin sie neu an.

## Was die Szene zeigt

- Kopf: Serie, Ort mit Flagge, Rennen, Tag und Startzeit; LIVE während eines Rennens.
- Je Rennen die ersten Plätze (Medaillen für 1 bis 3), Flagge, Name, das Schießen (fünf Scheiben je Schießen, Fehler rot, daneben die Fehler gesamt) und Zeit bzw. Rückstand. Staffeln zeigen die Nationen.
- Ist eine Nation gewählt, sind ihre Leute hervorgehoben; ist niemand vorne dabei, steht die oder der Beste darunter.
- Daneben (im Hochformat darunter) die nächsten Rennen und die nächste Station jeder Serie.
- Programm: die nächsten Rennen und Stationen.
- Gesamtwertung Frauen und Männer (Weltcup, IBU-Cup, IBU Junior Cup).

Gezeigt werden die Rennen der laufenden oder letzten Station. In der Sommerpause ist das die letzte Station der Vorsaison.

## Automationen

Aktionen: **Anzeigen**, **Beenden**, **Umschalten**, **Jetzt aktualisieren**.

Ereignisse:

- **biathlon_rennen_gestartet** mit rennen, serie, ort.
- **biathlon_ergebnis** mit rennen, ort, sieger, nation, zweiter, dritter und bester_der_nation.
- **biathlon_anzeige_gestartet** mit grund (show, zeitplan, rennstart, ergebnis).
- **biathlon_anzeige_beendet** mit grund (fertig, abgebrochen, verdraengt, abgelaufen, fehlgeschlagen, gestoppt).

Der Overlay-Dienst **Biathlon live line** liefert eine Zeile mit dem laufenden Rennen und der Führung, sonst das nächste Rennen.

## Woher die Daten kommen

Alle Daten kommen von **biathlonresults.com**, dem öffentlichen Datacenter der IBU (dieselbe Schnittstelle wie MMM-Biathlon), ohne Konto. Während eines Rennens liest das Plugin alle 30 Sekunden, an Renntagen alle 5 Minuten das Programm, sonst selten.

## Wenn etwas nicht stimmt

- **Die Szene kommt nicht von selbst.** Ist *Allow takeover* an? Die Plugin-Seite sagt unter Status, warum nicht.
- **Unten rechts steht „Plugin nicht erreichbar – Notbetrieb“.** Die Szene liest dann nur die letzten zwei Weltcup-Rennen selbst. Prüfe, ob das Plugin läuft.
- **„Stand“ oben rechts ist gelb.** Die Daten sind veraltet (im Rennen älter als 5 Minuten).

## Danke

- [MMM-Biathlon](https://github.com/2hdlockness/MMM-Biathlon) von 2hdlockness, MIT-Lizenz: Idee, Datenquelle und Einstellungen.
- [flag-icons](https://github.com/lipis/flag-icons) von Panayiotis Lipiridis, MIT-Lizenz: die Flaggen.
- Daten: International Biathlon Union (IBU), biathlonresults.com.
