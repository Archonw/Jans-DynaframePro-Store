# Halloween Scare

This pack is a demo: it shows how a plugin can react to triggers from Home
Assistant (motion sensors, doorbells, switches, events) and take over the
screen for a moment. Halloween is just the example.

A Halloween jump scare for DynaFrame. The frame shows your photos as usual. When
someone walks past a motion sensor or rings the doorbell (both from your own
Home Assistant), it comes over the playlist for a few seconds and gives them a
fright, then the playlist carries on.

## The four scares

- **Haunted portrait**: an old oil painting in a gold frame. Its eyes find you,
  then the face turns into a ghoul and screams.
- **Ghost in the photo**: a pale figure stands in the darkest corner of the
  photo that is on screen right now, disappears, comes back much closer, then
  jumps at you.
- **TV static**: the picture breaks up like an old TV. With every glitch a dark
  figure stands closer, until its face fills the screen with a bang.
- **Monster**: claws grab the bottom edge of the frame, glowing eyes rise, then
  a horned monster roars "Trick or treat!" (your own words if you like).

Each has a **gentle version for children** (the portrait winks and giggles, a
friendly sheet ghost says "Booo!", a cute one-eyed monster waves).

## Your own pictures and videos

On the plugin page you can add your own scares: photorealistic pictures (JPG,
PNG, WebP, GIF) or jump-scare clips (MP4, WebM, MOV, up to 90 seconds are
played). Choose "Your own pictures and videos" for motion or the doorbell, or
"Different each time" to mix them with the painted scares. A picture appears
after the creeping with a flash and a scream of your choice; a video plays full
screen with its own sound. The files stay on the frame (plugin data folder) and
survive updates.

One file can be marked as the **idle picture**, e.g. a video of a portrait that
only moves its eyes. It loops quietly whenever the scene is on screen (also in
a normal playlist) and during the creeping of a takeover; when a trigger comes,
the frame cuts straight to one of the other files as the scare.

## Triggers

- Motion sensors in Home Assistant (from "clear" to "detected"), with their own scare.
- The doorbell, with its own scare (the monster by default, ideal for trick-or-treaters).
- Any Home Assistant automation: fire the event `halloween_scare`
  (optional `mode`, `intensity`, `variant`, `text`, `lurk`, `force`).
- DynaFrame actions "Scare now", "Stop", "Arm" and "Disarm", and the test buttons on the plugin page.

Pause between scares, a chance per trigger (so it is not every time), quiet
hours, "only around Halloween" and an arm switch keep it fun.

## Sound

The plugin plays screams, whispers, static, growls and giggles on the frame
itself, exactly when the picture needs them, and sets the volume back
afterwards. All pictures and sounds are drawn and synthesised by the plugin; no
recordings or images by others. Font: Creepster (SIL Open Font License).

## Setup

1. Install from the store, open the plugin page ("Open Halloween Scare").
2. Enter your Home Assistant address and a long-lived access token, Connect.
   Motion sensors and the doorbell are filled in automatically.
3. Switch on **Allow takeover** for Halloween Scare on the Plugins page.
4. Try each scare with the buttons on the plugin page.

Tip: put the Halloween Scare scene into a normal playlist too. The portrait
then hangs there quietly and comes alive when someone walks by.

Plugin page in English, German and Spanish.
