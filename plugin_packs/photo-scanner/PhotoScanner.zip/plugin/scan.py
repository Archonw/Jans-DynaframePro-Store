"""Was Photo Scanner über ein Foto herausfindet.

exif(image)          -> Kamera, Objektiv, Blende, Belichtung, ISO, Datum, GPS … aus den EXIF-Daten
metrics(image)       -> Helligkeit, Kontrast, Sättigung, Schärfe, Farbtemperatur, Histogramme,
                        Fokuspunkt (Stelle mit den meisten Details), Bild-Fingerabdruck
from_db(row)         -> dasselbe aus einer Zeile der DynaFrame-Mediendatenbank (für Lücken)
from_immich(asset)   -> dasselbe aus einem Immich-Asset (exifInfo, Personen, Tags)
merge(*dicts)        -> erster vorhandener Wert gewinnt

Alles ohne Zusatzpakete außer Pillow. metrics() bekommt das schon auf
Bildschirmgröße verkleinerte Foto und rechnet auf einer kleinen Kopie, damit es
auf dem Pi schnell bleibt.
"""

import math
import re

from PIL import Image, ImageFilter, ImageStat

EXIF_IFD = 0x8769
GPS_IFD = 0x8825

METERING = {1: "average", 2: "center", 3: "spot", 4: "multi-spot", 5: "pattern", 6: "partial"}
PROGRAMS = {1: "manual", 2: "program", 3: "aperture", 4: "shutter", 5: "creative", 6: "action",
            7: "portrait", 8: "landscape"}


def _num(value):
    try:
        if isinstance(value, tuple) and len(value) == 2:
            return float(value[0]) / float(value[1]) if value[1] else None
        number = float(value)
        return number if math.isfinite(number) else None
    except (TypeError, ValueError, ZeroDivisionError):
        return None


def _text(value, limit=80):
    if isinstance(value, bytes):
        value = value.decode("utf-8", "ignore")
    text = re.sub(r"[\x00-\x1f]+", " ", str(value or "")).strip()
    return text[:limit]


def _degrees(values, ref):
    try:
        d, m, s = (_num(v) for v in values)
    except (TypeError, ValueError):
        return None
    if d is None:
        return None
    value = d + (m or 0) / 60.0 + (s or 0) / 3600.0
    if str(ref or "").upper().startswith(("S", "W")):
        value = -value
    return round(value, 6)


def _taken(text):
    text = _text(text, 40)
    match = re.match(r"(\d{4})[:-](\d{2})[:-](\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?", text)
    if not match or match.group(1) in ("0000", "1970"):
        return ""
    y, mo, d, h, mi, s = match.groups()
    return f"{y}-{mo}-{d}T{h}:{mi}:{s or '00'}"


def clean_make_model(make, model):
    """„Canon“ + „Canon EOS R6“ -> „Canon EOS R6“; „NIKON CORPORATION“ -> „Nikon“."""
    make = _text(make, 40)
    model = _text(model, 60)
    short = re.sub(r"\b(corporation|corp\.?|company|co\.,? ?ltd\.?|ltd\.?|inc\.?|imaging|optical|camera)\b",
                   "", make, flags=re.I).strip(" ,.")
    if short.isupper() and len(short) > 3:
        short = short.title()
    if model and short and model.lower().startswith(short.lower()):
        return model
    if model and short and short.split()[0].lower() in model.lower():
        return model
    return " ".join(p for p in (short, model) if p)


def exif(image):
    """Die EXIF-Daten eines geöffneten (noch nicht verkleinerten) Pillow-Bilds."""
    out = {}
    try:
        data = image.getexif()
    except Exception:   # noqa: BLE001 - kaputte EXIF-Blöcke kommen vor
        return out
    if not data:
        return out
    try:
        ifd = data.get_ifd(EXIF_IFD) or {}
    except Exception:   # noqa: BLE001
        ifd = {}
    try:
        gps = data.get_ifd(GPS_IFD) or {}
    except Exception:   # noqa: BLE001
        gps = {}
    camera = clean_make_model(data.get(271), data.get(272))
    if camera:
        out["camera"] = camera
    if data.get(305):
        out["software"] = _text(data.get(305), 40)
    if data.get(274):
        out["orientation"] = int(_num(data.get(274)) or 1)
    lens = _text(ifd.get(42036), 60)
    lens_make = _text(ifd.get(42035), 30)
    if lens:
        out["lens"] = lens if not lens_make or lens_make.lower() in lens.lower() else f"{lens_make} {lens}"
    fnum = _num(ifd.get(33437))
    if fnum:
        out["fnumber"] = round(fnum, 1)
    exposure = _num(ifd.get(33434))
    if exposure:
        out["exposure"] = exposure
    iso = ifd.get(34855)
    if isinstance(iso, (tuple, list)):
        iso = iso[0] if iso else None
    if _num(iso):
        out["iso"] = int(_num(iso))
    focal = _num(ifd.get(37386))
    if focal:
        out["focal"] = round(focal, 1)
    focal35 = _num(ifd.get(41989))
    if focal35:
        out["focal35"] = int(focal35)
    bias = _num(ifd.get(37380))
    if bias is not None and abs(bias) < 20:
        out["bias"] = round(bias, 2)
    flash = ifd.get(37385)
    if isinstance(flash, int):
        out["flash"] = bool(flash & 1)
    if ifd.get(37383) in METERING:
        out["metering"] = METERING[ifd.get(37383)]
    if ifd.get(34850) in PROGRAMS:
        out["program"] = PROGRAMS[ifd.get(34850)]
    taken = _taken(ifd.get(36867) or ifd.get(36868) or data.get(306))
    if taken:
        out["taken"] = taken
        offset = _text(ifd.get(36881), 8)
        if re.match(r"^[+-]\d{2}:\d{2}$", offset):
            out["offset"] = offset
    if gps:
        lat = _degrees(gps.get(2), gps.get(1)) if gps.get(2) else None
        lon = _degrees(gps.get(4), gps.get(3)) if gps.get(4) else None
        if lat is not None and lon is not None and (abs(lat) > 1e-6 or abs(lon) > 1e-6) \
                and abs(lat) <= 90 and abs(lon) <= 180:
            out["lat"], out["lon"] = lat, lon
            alt = _num(gps.get(6))
            if alt is not None and abs(alt) < 12000:
                below = gps.get(5) in (1, b"\x01")
                out["alt"] = round(-alt if below else alt, 1)
            heading = _num(gps.get(17))
            if heading is not None and 0 <= heading <= 360:
                out["heading"] = round(heading)
            speed = _num(gps.get(13))
            if speed:
                out["speed"] = round(speed, 1)
    return out


# --------------------------------------------------------------------------
# Bildanalyse
# --------------------------------------------------------------------------

def _cct(r, g, b):
    """Ungefähre Farbtemperatur (Kelvin) der mittleren Farbe, nach McCamy."""
    def lin(c):
        c /= 255.0
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    rl, gl, bl = lin(r), lin(g), lin(b)
    x = 0.4124 * rl + 0.3576 * gl + 0.1805 * bl
    y = 0.2126 * rl + 0.7152 * gl + 0.0722 * bl
    z = 0.0193 * rl + 0.1192 * gl + 0.9505 * bl
    total = x + y + z
    if total <= 0:
        return None
    cx, cy = x / total, y / total
    if abs(0.1858 - cy) < 1e-6:
        return None
    n = (cx - 0.3320) / (0.1858 - cy)
    kelvin = 449 * n ** 3 + 3525 * n ** 2 + 6823.3 * n + 5520.33
    return int(round(max(1500, min(15000, kelvin)) / 50.0) * 50)


def _bins(hist, count):
    step = len(hist) // count
    return [sum(hist[i * step:(i + 1) * step]) for i in range(count)]


def _scale(values):
    top = max(values) or 1
    return [round(v / top, 3) for v in values]


def metrics(image):
    """image: RGB-Bild in Bildschirmgröße. Werte 0-100, Histogramme 0-1."""
    small = image.copy()
    small.thumbnail((160, 160), Image.BILINEAR)
    luma = small.convert("L")
    stat = ImageStat.Stat(luma)
    out = {
        "brightness": round(stat.mean[0] / 2.55, 1),
        "contrast": round(min(100.0, stat.stddev[0] / 0.8), 1),
    }
    hist_l = luma.histogram()
    pixels = float(sum(hist_l)) or 1.0
    out["highlights"] = round(100.0 * sum(hist_l[250:]) / pixels, 1)
    out["shadows"] = round(100.0 * sum(hist_l[:6]) / pixels, 1)
    try:
        out["entropy"] = round(luma.entropy(), 2)
    except AttributeError:
        out["entropy"] = None
    rgb_hist = small.histogram()
    out["histogram"] = {
        "r": _scale(_bins(rgb_hist[0:256], 64)),
        "g": _scale(_bins(rgb_hist[256:512], 64)),
        "b": _scale(_bins(rgb_hist[512:768], 64)),
        "l": _scale(_bins(hist_l, 64)),
    }

    # Sättigung, Farbigkeit (Hasler & Süsstrunk) und mittlere Farbe in einem Durchlauf
    sat_sum = 0.0
    rg_sum = yb_sum = rg_sq = yb_sq = 0.0
    r_sum = g_sum = b_sum = 0.0
    count = 0
    for r, g, b in small.getdata():
        high, low = max(r, g, b), min(r, g, b)
        sat_sum += (high - low) / high if high else 0.0
        rg = r - g
        yb = 0.5 * (r + g) - b
        rg_sum += rg
        yb_sum += yb
        rg_sq += rg * rg
        yb_sq += yb * yb
        r_sum += r
        g_sum += g
        b_sum += b
        count += 1
    count = count or 1
    mean_rg, mean_yb = rg_sum / count, yb_sum / count
    std_rg = math.sqrt(max(0.0, rg_sq / count - mean_rg ** 2))
    std_yb = math.sqrt(max(0.0, yb_sq / count - mean_yb ** 2))
    colourful = math.sqrt(std_rg ** 2 + std_yb ** 2) + 0.3 * math.sqrt(mean_rg ** 2 + mean_yb ** 2)
    out["saturation"] = round(100.0 * sat_sum / count, 1)
    out["colourfulness"] = round(min(100.0, colourful / 1.1), 1)
    mean = (r_sum / count, g_sum / count, b_sum / count)
    out["mean"] = "%02x%02x%02x" % tuple(int(round(v)) for v in mean)
    out["kelvin"] = _cct(*mean)
    out["warmth"] = round(max(-100.0, min(100.0, (mean[0] - mean[2]) / 1.2)), 1)

    # Details/Schärfe: Kanten auf einer mittleren Kopie; Fokuspunkt = Feld mit den meisten Kanten
    mid = image.copy()
    mid.thumbnail((480, 480), Image.BILINEAR)
    edges = mid.convert("L").filter(ImageFilter.FIND_EDGES)
    # Der Rand von FIND_EDGES ist immer hell: einen Pixel abschneiden
    edges = edges.crop((2, 2, max(3, edges.width - 2), max(3, edges.height - 2)))
    edge_stat = ImageStat.Stat(edges)
    out["detail"] = round(min(100.0, edge_stat.mean[0] * 3.2), 1)
    out["sharpness"] = round(min(100.0, edge_stat.stddev[0] * 1.6), 1)
    cols, rows = 12, 8
    grid = edges.resize((cols, rows), Image.BOX)
    values = list(grid.getdata())
    best = max(range(len(values)), key=lambda i: values[i] * (1.0 - 0.35 * _edge_penalty(i, cols, rows)))
    out["focus"] = [round((best % cols + 0.5) / cols, 3), round((best // cols + 0.5) / rows, 3)]

    # Fingerabdruck (dHash, 64 Bit)
    tiny = image.convert("L").resize((9, 8), Image.BILINEAR)
    px = list(tiny.getdata())
    bits = 0
    for y in range(8):
        for x in range(8):
            bits = (bits << 1) | (1 if px[y * 9 + x] > px[y * 9 + x + 1] else 0)
    out["hash"] = "%016x" % bits
    return out


def _edge_penalty(index, cols, rows):
    """0 in der Mitte, 1 am Rand: der Fokuspunkt soll nicht an einer Kante kleben."""
    x = (index % cols + 0.5) / cols - 0.5
    y = (index // cols + 0.5) / rows - 0.5
    return min(1.0, 2.0 * max(abs(x), abs(y)))


# --------------------------------------------------------------------------
# Andere Quellen
# --------------------------------------------------------------------------

def _find(row, *keys):
    lower = {str(k).lower(): v for k, v in row.items()}
    for key in keys:
        value = lower.get(key.lower())
        if value not in (None, "", [], {}):
            return value
    return None


def _tags(value):
    if isinstance(value, str):
        parts = re.split(r"[;,|]", value)
    elif isinstance(value, list):
        parts = [p.get("name") if isinstance(p, dict) else p for p in value]
    else:
        return []
    out = []
    for part in parts:
        text = _text(part, 30)
        if text and text.lower() not in (t.lower() for t in out):
            out.append(text)
    return out[:8]


def from_db(row):
    """Eine Zeile aus GET /media/database (Feldnamen wie auf Jans Rahmen, mit Ausweichnamen)."""
    if not isinstance(row, dict):
        return {}
    out = {}
    camera = clean_make_model(_find(row, "make", "cameraMake"), _find(row, "model", "cameraModel"))
    if camera:
        out["camera"] = camera
    for key, names, kind in (
            ("lens", ("lensModel", "lens"), "text"),
            ("fnumber", ("fNumber", "aperture", "fStop"), "num"),
            ("exposure", ("exposureTime", "shutterSpeed"), "exposure"),
            ("iso", ("iso", "isoSpeed", "isoSpeedRatings"), "int"),
            ("focal", ("focalLength",), "num"),
            ("lat", ("latitude", "gpsLatitude", "lat"), "num"),
            ("lon", ("longitude", "gpsLongitude", "lon", "lng"), "num"),
            ("alt", ("altitude", "gpsAltitude"), "num"),
            ("place", ("locationName", "location", "placeName"), "text"),
            ("title", ("title",), "text"),
            ("w", ("width", "imageWidth"), "int"),
            ("h", ("height", "imageHeight"), "int"),
            ("bytes", ("fileSize", "size", "sizeBytes"), "int")):
        value = _find(row, *names)
        if value is None:
            continue
        if kind == "text":
            value = _text(value, 80)
        elif kind == "int":
            value = int(_num(value) or 0) or None
        elif kind == "exposure":
            value = parse_exposure(value)
        else:
            value = _num(value)
        if value not in (None, ""):
            out[key] = value
    if out.get("lat") is not None and out.get("lon") is not None and abs(out["lat"]) < 1e-6 and abs(out["lon"]) < 1e-6:
        out.pop("lat")
        out.pop("lon")
    taken = _taken(_find(row, "dateTaken", "takenAt", "dateTimeOriginal") or "")
    if taken:
        out["taken"] = taken
    rating = _find(row, "rating")
    if rating is not None and _num(rating) is not None:
        out["rating"] = max(0, min(5, int(_num(rating))))
    tags = _tags(_find(row, "tags", "keywords"))
    if tags:
        out["tags"] = tags
    return out


def parse_exposure(value):
    """„1/250“, „0.004“, 0.004 -> Sekunden."""
    if isinstance(value, (int, float)):
        return float(value) if value > 0 else None
    text = _text(value, 20).rstrip("s ").strip()
    if "/" in text:
        top, _, bottom = text.partition("/")
        try:
            return float(top) / float(bottom)
        except (ValueError, ZeroDivisionError):
            return None
    try:
        number = float(text)
    except ValueError:
        return None
    return number if number > 0 else None


def from_immich(asset):
    if not isinstance(asset, dict):
        return {}
    info = asset.get("exifInfo") if isinstance(asset.get("exifInfo"), dict) else {}
    out = from_db({
        "make": info.get("make"), "model": info.get("model"), "lensModel": info.get("lensModel"),
        "fNumber": info.get("fNumber"), "exposureTime": info.get("exposureTime"), "iso": info.get("iso"),
        "focalLength": info.get("focalLength"), "latitude": info.get("latitude"),
        "longitude": info.get("longitude"), "width": info.get("exifImageWidth"),
        "height": info.get("exifImageHeight"), "fileSize": info.get("fileSizeInByte"),
        "dateTaken": info.get("dateTimeOriginal") or asset.get("localDateTime"),
        "rating": info.get("rating"), "title": info.get("description"),
    })
    place = ", ".join(p for p in (info.get("city"), info.get("country")) if p)
    if place:
        out["place"] = _text(place, 80)
    people = [p.get("name") for p in asset.get("people") or [] if isinstance(p, dict) and p.get("name")]
    faces = len(asset.get("people") or [])
    unassigned = asset.get("unassignedFaces") or []
    if people:
        out["people"] = [_text(p, 30) for p in people[:8]]
    if faces or unassigned:
        out["faces"] = faces + len(unassigned)
    tags = _tags(asset.get("tags") or [])
    if tags:
        out["tags"] = tags
    if asset.get("isFavorite"):
        out["favorite"] = True
    if asset.get("originalFileName"):
        out["file"] = _text(asset.get("originalFileName"), 80)
    return out


def merge(*parts):
    out = {}
    for part in parts:
        for key, value in (part or {}).items():
            if key not in out and value not in (None, "", [], {}):
                out[key] = value
    return out


def aspect(w, h):
    """3:2, 4:3, 16:9 … oder 1.85:1."""
    if not w or not h:
        return ""
    ratio = max(w, h) / float(min(w, h))
    for a, b in ((1, 1), (5, 4), (4, 3), (3, 2), (16, 10), (5, 3), (16, 9), (2, 1), (21, 9), (3, 1)):
        if abs(ratio - a / float(b)) < 0.02:
            return f"{a}:{b}" if w >= h else f"{b}:{a}"
    return f"{ratio:.2f}:1" if w >= h else f"1:{ratio:.2f}"
