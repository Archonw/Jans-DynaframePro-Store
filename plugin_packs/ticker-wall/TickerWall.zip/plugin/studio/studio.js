"use strict";

// Always "./api/...": the WebUI serves this page under /Plugins/Advanced/TickerWall/ without <base>.

const el = (id) => document.getElementById(id);
let current = null;
let editing = false;

const A = (href, text) => `<a href="${href}" target="_blank" rel="noopener">${text}</a>`;
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  lede: ["Eine Nachrichtensender- und Börsenparkett-Wand: Newsfeeds, Kurse, Krypto, Weltuhren und Laufbänder überall. Die Ticker Wall wertet die Schlagzeilen aus (Themen-Radar, Eilmeldungen, Nachrichtenlage) und kann sich bei Alarmen über die Playlist legen. Jede Änderung hier wird sofort gespeichert.",
    "A news-channel and trading-floor wall: news feeds, prices, crypto, world clocks and tickers everywhere. Ticker Wall analyses the headlines (topic radar, breaking news, news pace) and can come over the playlist when an alert fires. Every change here is saved immediately.",
    "Un muro de canal de noticias y parqué bursátil: noticias, cotizaciones, cripto, relojes mundiales y teletipos por todas partes. Ticker Wall analiza los titulares (radar de temas, última hora, ritmo informativo) y puede ponerse sobre la lista cuando salta una alerta. Cada cambio se guarda al instante."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  refresh: ["Jetzt aktualisieren", "Refresh now", "Actualizar ahora"],
  test: ["Testalarm", "Test alert", "Alerta de prueba"],
  show: ["Anzeigen", "Show", "Mostrar"],
  cancel: ["Beenden", "Stop", "Terminar"],
  factStatus: ["Top-Meldung", "Top headline", "Titular principal"],
  factScreen: ["Bildschirm", "Screen", "Pantalla"],
  factNext: ["Nächste regelmäßige Anzeige", "Next regular display", "Próxima visualización periódica"],
  factData: ["Daten", "Data", "Datos"],
  factVersion: ["Version", "Version", "Versión"],
  dataLine: ["{h} Schlagzeilen · {f} von {ft} Feeds · {q} Kurse", "{h} headlines · {f} of {ft} feeds · {q} prices", "{h} titulares · {f} de {ft} fuentes · {q} cotizaciones"],
  radarLine: ["Themen gerade: {terms}", "Topics right now: {terms}", "Temas ahora: {terms}"],
  lastAlerts: ["Letzte Alarme", "Latest alerts", "Últimas alertas"],
  noAlerts: ["Noch keine.", "None yet.", "Ninguna todavía."],
  lookTitle: ["Look und Region", "Look and region", "Aspecto y región"],
  regionHint: ["Die Region füllt Feeds, Watchlist, Krypto-Währung, Städte, Börsenglocken und Leitindex mit passenden Vorgaben. Danach kannst du alles frei ändern; ein erneutes Füllen überschreibt deine Listen.",
    "The region fills feeds, watchlist, crypto currency, cities, market bells and main index with sensible defaults. You can change everything afterwards; filling again overwrites your lists.",
    "La región rellena fuentes, lista de valores, moneda cripto, ciudades, campanas de apertura e índice principal con valores adecuados. Después puedes cambiarlo todo; volver a rellenar sobrescribe tus listas."],
  region: ["Region", "Region", "Región"],
  rIntl: ["International", "International", "Internacional"],
  rUs: ["USA", "United States", "Estados Unidos"],
  rUk: ["Großbritannien", "United Kingdom", "Reino Unido"],
  rDe: ["Deutschland", "Germany", "Alemania"],
  rEs: ["Spanien", "Spain", "España"],
  applyRegion: ["Listen für diese Region füllen", "Fill lists for this region", "Rellenar listas para esta región"],
  regionAsk: ["Feeds, Watchlist, Krypto, Städte und Börsenglocken mit den Vorgaben für „{name}“ überschreiben?", "Overwrite feeds, watchlist, crypto, cities and market bells with the defaults for “{name}”?", "¿Sobrescribir fuentes, lista de valores, cripto, ciudades y campanas con los valores de «{name}»?"],
  look: ["Look", "Look", "Aspecto"],
  lookNews: ["Nachrichtensender (Rot und Blau)", "News channel (red and blue)", "Canal de noticias (rojo y azul)"],
  lookTerminal: ["Börsenterminal (Schwarz und Bernstein)", "Trading terminal (black and amber)", "Terminal bursátil (negro y ámbar)"],
  lookAuto: ["Alle 10 Minuten wechseln", "Change every 10 minutes", "Cambiar cada 10 minutos"],
  speed: ["Tempo der Laufbänder in %", "Ticker speed in %", "Velocidad de los teletipos en %"],
  showImages: ["Bilder hinter dem Top-Thema", "Pictures behind the top story", "Imágenes detrás de la noticia principal"],
  showWeather: ["Wetter der Städte", "Weather of the cities", "Tiempo de las ciudades"],
  showQuakes: ["Erdbeben im Laufband", "Earthquakes in the ticker", "Terremotos en el teletipo"],
  newsTitle: ["Newsfeeds", "News feeds", "Fuentes de noticias"],
  feedsHint: ["Eine Zeile pro Feed: <code>Name | Adresse</code>. Jeder RSS- oder Atom-Feed geht. Zeilen mit <code>#</code> am Anfang sind ausgeschaltet. Je mehr Quellen, desto besser erkennt das Themen-Radar, was gerade überall läuft.",
    "One line per feed: <code>Name | address</code>. Any RSS or Atom feed works. Lines starting with <code>#</code> are switched off. The more sources, the better the topic radar sees what is everywhere right now.",
    "Una línea por fuente: <code>Nombre | dirección</code>. Vale cualquier feed RSS o Atom. Las líneas que empiezan con <code>#</code> están desactivadas. Cuantas más fuentes, mejor ve el radar de temas lo que está en todas partes."],
  newsMinutes: ["Feeds alle … Minuten lesen", "Read the feeds every … minutes", "Leer las fuentes cada … minutos"],
  feedOk: ["{n} Meldungen", "{n} items", "{n} noticias"],
  marketsTitle: ["Märkte", "Markets", "Mercados"],
  watchHint: ["Eine Zeile pro Wert: <code>Symbol | Anzeigename | Art</code>. Finnhub liefert kostenlos US-Aktien und ETFs: <code>AAPL</code>, <code>SAP</code> (US-Notierung), <code>SIEGY</code> (Siemens-ADR). Indizes, Länder und Rohstoffe über ETFs, z.&nbsp;B. <code>EWG | Deutschland (EWG) | index</code>, <code>GLD | Gold (GLD) | commodity</code>; deren Kurs ist der des ETF in US-Dollar. Devisen als <code>EURUSD=X</code> (Tageskurs der EZB, ohne Schlüssel). Art ist optional: index, stock, commodity, bond, fx.",
    "One line per symbol: <code>Symbol | display name | kind</code>. Finnhub's free plan has US stocks and ETFs: <code>AAPL</code>, <code>SAP</code> (US listing), <code>SIEGY</code> (Siemens ADR). Indices, countries and commodities through ETFs, e.g. <code>SPY | S&amp;P 500 (SPY) | index</code>, <code>GLD | Gold (GLD) | commodity</code>; their move is the ETF's in US dollars. Currencies as <code>EURUSD=X</code> (ECB daily rate, no key needed). Kind is optional: index, stock, commodity, bond, fx.",
    "Una línea por valor: <code>Símbolo | nombre | tipo</code>. El plan gratuito de Finnhub tiene acciones y ETF de EE.&nbsp;UU.: <code>AAPL</code>, <code>SAN</code> (cotización en EE.&nbsp;UU.), <code>IBDRY</code> (ADR de Iberdrola). Índices, países y materias primas con ETF, p.&nbsp;ej. <code>EWP | España (EWP) | index</code>, <code>GLD | Oro (GLD) | commodity</code>; su variación es la del ETF en dólares. Divisas como <code>EURUSD=X</code> (cambio diario del BCE, sin clave). El tipo es opcional: index, stock, commodity, bond, fx."],
  keyHint: [`Aktienkurse kommen von ${A("https://finnhub.io/register", "Finnhub")}: dort kostenlos registrieren, im Dashboard den API-Schlüssel kopieren und hier eintragen. Kostenlos sind 60 Abfragen pro Minute; die Ticker Wall fragt höchstens eine pro Sekunde. Der Schlüssel bleibt auf dem Rahmen. Die Tageskurven zeichnet die Wand aus ihren eigenen Abfragen, sie füllen sich also im Lauf des Tages.`,
    `Stock prices come from ${A("https://finnhub.io/register", "Finnhub")}: sign up for free, copy the API key from the dashboard and enter it here. The free plan allows 60 calls a minute; Ticker Wall makes at most one a second. The key stays on the frame. The wall draws the day curves from its own reads, so they fill up during the day.`,
    `Las cotizaciones vienen de ${A("https://finnhub.io/register", "Finnhub")}: regístrate gratis, copia la clave API del panel y escríbela aquí. El plan gratuito permite 60 consultas por minuto; Ticker Wall hace como mucho una por segundo. La clave se queda en el marco. Las curvas del día se dibujan con sus propias consultas, así que se llenan a lo largo del día.`],
  finnhubKey: ["Finnhub-API-Schlüssel", "Finnhub API key", "Clave API de Finnhub"],
  save: ["Speichern", "Save", "Guardar"],
  remove: ["Entfernen", "Remove", "Quitar"],
  keySaved: ["Gespeichert ({hint})", "Saved ({hint})", "Guardada ({hint})"],
  keyMissing: ["Noch kein Schlüssel: die Kacheln zeigen bis dahin Krypto und Devisen.", "No key yet: until then the tiles show crypto and currencies.", "Aún no hay clave: hasta entonces los recuadros muestran cripto y divisas."],
  quoteErrors: ["Nicht gefunden oder ohne Antwort: {list}", "Not found or no answer: {list}", "No encontrado o sin respuesta: {list}"],
  coins: ["Krypto (CoinGecko-IDs, mit Komma getrennt)", "Crypto (CoinGecko ids, separated by commas)", "Cripto (ids de CoinGecko, separados por comas)"],
  coinCurrency: ["Krypto in", "Crypto in", "Cripto en"],
  marketMinutes: ["Kurse alle … Minuten lesen", "Read the prices every … minutes", "Leer las cotizaciones cada … minutos"],
  citiesTitle: ["Weltuhren und Wetter", "World clocks and weather", "Relojes mundiales y tiempo"],
  citiesHint: [`Eine Zeile pro Stadt: <code>Name | Breite | Länge | Zeitzone</code>, z.&nbsp;B. <code>Hamburg | 53.55 | 9.99 | Europe/Berlin</code>. Bis zu acht Städte; die Zeitzonen-Namen stehen ${A("https://en.wikipedia.org/wiki/List_of_tz_database_time_zones", "hier")}.`,
    `One line per city: <code>Name | latitude | longitude | time zone</code>, e.g. <code>Boston | 42.36 | -71.06 | America/New_York</code>. Up to eight cities; time zone names are listed ${A("https://en.wikipedia.org/wiki/List_of_tz_database_time_zones", "here")}.`,
    `Una línea por ciudad: <code>Nombre | latitud | longitud | zona horaria</code>, p.&nbsp;ej. <code>Sevilla | 37.39 | -5.98 | Europe/Madrid</code>. Hasta ocho ciudades; los nombres de zona están ${A("https://en.wikipedia.org/wiki/List_of_tz_database_time_zones", "aquí")}.`],
  alertsTitle: ["Alarme: über die Playlist, wenn etwas passiert", "Alerts: over the playlist when something happens", "Alertas: sobre la lista cuando pasa algo"],
  alertsHint: ["Bei einem Alarm legt sich die Ticker Wall über die laufende Playlist, zeigt den Alarm groß und danach ein rotes Band mit dem Auslöser. Dafür muss auf der Plugins-Seite <b>Allow takeover</b> für Ticker Wall an sein. Jeder Alarm kommt nur einmal (Kursalarme einmal pro Tag).",
    "On an alert Ticker Wall comes over the running playlist, shows the alert big and then a red band with what triggered it. For this, <b>Allow takeover</b> must be on for Ticker Wall on the Plugins page. Each alert fires once (price alerts once a day).",
    "Con una alerta, Ticker Wall se pone sobre la lista en curso, muestra la alerta en grande y luego una banda roja con el motivo. Para ello, <b>Allow takeover</b> debe estar activado para Ticker Wall en la página de plugins. Cada alerta salta una vez (las de precio, una vez al día)."],
  keywords: ["Schlagworte (eins pro Zeile oder mit Komma getrennt)", "Keywords (one per line or separated by commas)", "Palabras clave (una por línea o separadas por comas)"],
  breaking: ["Eilmeldungen", "Breaking news", "Última hora"],
  no: ["Nein", "No", "No"],
  brMarker: ["Wenn ein Feed sie als Eilmeldung markiert", "When a feed marks it as breaking", "Cuando una fuente la marca como última hora"],
  brCluster: ["Wenn mehrere Quellen dasselbe neue Thema melden", "When several sources report the same new topic", "Cuando varias fuentes informan del mismo tema nuevo"],
  brBoth: ["Beides", "Both", "Ambas"],
  breakingSources: ["„Mehrere Quellen“ heißt mindestens", "“Several sources” means at least", "«Varias fuentes» significa al menos"],
  rules: ["Kursregeln (eine pro Zeile)", "Price rules (one per line)", "Reglas de precio (una por línea)"],
  rulesHint: ["Beispiele: <code>NVDA &gt; 150</code> (steigt über 150), <code>SAP.DE &lt; 200</code> (fällt unter 200), <code>TSLA ± 5%</code> (bewegt sich heute um 5 % oder mehr), <code>BTC ± 3%</code> (Krypto mit Kürzel). Das Symbol muss in der Watchlist oder der Krypto-Liste stehen.",
    "Examples: <code>NVDA &gt; 150</code> (rises above 150), <code>AAPL &lt; 180</code> (falls below 180), <code>TSLA ± 5%</code> (moves 5 % or more today), <code>BTC ± 3%</code> (crypto by ticker). The symbol must be in the watchlist or the crypto list.",
    "Ejemplos: <code>NVDA &gt; 150</code> (sube por encima de 150), <code>SAN.MC &lt; 4</code> (baja de 4), <code>TSLA ± 5%</code> (se mueve un 5 % o más hoy), <code>BTC ± 3%</code> (cripto por símbolo). El símbolo debe estar en la lista de valores o de cripto."],
  rulesActive: ["Erkannte Regeln: {list}", "Rules understood: {list}", "Reglas reconocidas: {list}"],
  movePct: ["Irgendeine Aktie der Liste bewegt sich um … % (0 = aus)", "Any stock of the list moves by … % (0 = off)", "Cualquier acción de la lista se mueve un … % (0 = no)"],
  mainIndex: ["Leitindex (Symbol)", "Main index (symbol)", "Índice principal (símbolo)"],
  indexPct: ["Crash oder Rallye: Index bewegt sich um … % (0 = aus)", "Crash or rally: index moves by … % (0 = off)", "Caída o rally: el índice se mueve un … % (0 = no)"],
  quakeMag: ["Erdbeben ab Magnitude (0 = aus)", "Earthquake from magnitude (0 = off)", "Terremoto desde magnitud (0 = no)"],
  bellsHint: ["Börsenglocke: zur Handelseröffnung dieser Börsen (Montag bis Freitag) kurz einblenden.", "Market bell: show briefly when these exchanges open (Monday to Friday).", "Campana: mostrar brevemente cuando abren estas bolsas (de lunes a viernes)."],
  alertSeconds: ["Alarm … Sekunden zeigen", "Show an alert for … seconds", "Mostrar una alerta … segundos"],
  cooldown: ["Höchstens ein Alarm alle … Minuten", "At most one alert every … minutes", "Como mucho una alerta cada … minutos"],
  from: ["Von … Uhr", "From … o'clock", "Desde las …"],
  to: ["Bis … Uhr", "To … o'clock", "Hasta las …"],
  hoursHint: ["Alarme und regelmäßige Anzeige nur zwischen „Von“ und „Bis“. Der Bildschirm wird nie geweckt.", "Alerts and the regular display only between “From” and “To”. The screen is never woken up.", "Alertas y visualización periódica solo entre «Desde» y «Hasta». La pantalla nunca se despierta."],
  autoTitle: ["Regelmäßig über die Playlist", "Show over the playlist regularly", "Sobre la lista periódicamente"],
  when: ["Wann", "When", "Cuándo"],
  modeOff: ["Nie", "Never", "Nunca"],
  modeAlways: ["Im Abstand unten", "At the interval below", "Con el intervalo de abajo"],
  everyMinutes: ["Alle … Minuten", "Every … minutes", "Cada … minutos"],
  forSeconds: ["Für … Sekunden", "For … seconds", "Durante … segundos"],
  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „Ticker Wall“ anlegen", "Create the playlist “Ticker Wall”", "Crear la lista «Ticker Wall»"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistHint: ["Die Playlist enthält nur die Szene (2 Minuten) und ist eingeschaltet. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist holds only the scene (2 minutes) and is switched on. You can also add the scene to any playlist yourself.",
    "La lista contiene solo la escena (2 minutos) y está activada. También puedes añadir la escena a cualquier lista."],
  sourcesTitle: ["Woher die Daten kommen", "Where the data comes from", "De dónde vienen los datos"],
  sourcesHint: ["Kostenlos: die RSS-Feeds der Medien, Krypto von CoinGecko, Devisen von der EZB (Frankfurter), Wetter von Open-Meteo, Erdbeben vom USGS, alles ohne Schlüssel. Aktienkurse von Finnhub mit deinem kostenlosen Schlüssel. Die Ticker Wall merkt sich die Schlagzeilen der letzten 48 Stunden auf dem Rahmen, um Trends zu erkennen. Keine Anlageberatung.",
    "Free: the news outlets' RSS feeds, crypto from CoinGecko, currencies from the ECB (Frankfurter), weather from Open-Meteo, earthquakes from the USGS, all without keys. Stock prices from Finnhub with your free key. Ticker Wall keeps the headlines of the last 48 hours on the frame to spot trends. Not investment advice.",
    "Gratis: los feeds RSS de los medios, cripto de CoinGecko, divisas del BCE (Frankfurter), tiempo de Open-Meteo, terremotos del USGS, todo sin claves. Cotizaciones de Finnhub con tu clave gratuita. Ticker Wall guarda en el marco los titulares de las últimas 48 horas para detectar tendencias. No es asesoramiento financiero."],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or wishes?", "¿Problemas, preguntas o deseos?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre un issue en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", ", with plugin name and version.", ", con el nombre y la versión del plugin."],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin is not answering.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status}).", "Error (HTTP {status}).", "Error (HTTP {status})."],
  showing: ["Ticker Wall wird gezeigt", "Ticker Wall is showing", "Se muestra Ticker Wall"],
  until: [" bis {time}", " until {time}", " hasta las {time}"],
  playlistRuns: ["Deine Playlist läuft", "Your playlist is playing", "Tu lista se está reproduciendo"],
  off: ["Aus", "Off", "Desactivado"],
  oclock: ["{time} Uhr", "{time}", "{time}"]
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = "en";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "en";
  if (chosen === lang && document.documentElement.dataset.applied === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  document.documentElement.dataset.applied = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([502, 503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "") {
  const node = el("statusNote");
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function clock(iso) {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  const sameDay = date.toDateString() === new Date().toDateString();
  const time = t("oclock", { time: date.toLocaleTimeString(LOCALES[lang], { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(LOCALES[lang], { day: "2-digit", month: "2-digit" })} ${time}`;
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function save(changes) {
  try {
    await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    setStatus(t("saved"), "ok");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

// Every field with data-kind is one setting with the same name as its id.
const FIELDS = [...document.querySelectorAll("[data-kind]")];

function readField(node) {
  const kind = node.dataset.kind;
  if (kind === "bool") return node.checked;
  if (kind === "boolsel") return node.value === "true";
  if (kind === "number") return Number(node.value);
  return node.value;
}

function writeField(node, value) {
  const kind = node.dataset.kind;
  if (kind === "bool") node.checked = Boolean(value);
  else if (kind === "boolsel") node.value = String(Boolean(value));
  else node.value = value ?? "";
}

for (const node of FIELDS) {
  node.addEventListener("focus", () => { editing = true; });
  node.addEventListener("blur", () => { editing = false; });
  node.addEventListener("change", () => {
    if (node.id === "Language") applyLanguage(node.value);
    save({ [node.id]: readField(node) });
  });
}

function renderBells(state) {
  const box = el("bellList");
  if (!box.dataset.built) {
    box.dataset.built = "1";
    box.innerHTML = Object.entries(state.exchanges).map(([id, name]) =>
      `<label><input type="checkbox" value="${esc(id)}"><span>${esc(name)}</span></label>`).join("");
    box.addEventListener("change", () => save({ Bells: [...box.querySelectorAll("input:checked")].map((i) => i.value) }));
  }
  for (const input of box.querySelectorAll("input")) input.checked = state.settings.Bells.includes(input.value);
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  el("factStatus").textContent = state.status || "—";
  el("factScreen").textContent = state.takeover.active
    ? `${t("showing")}${state.takeover.until ? t("until", { time: clock(state.takeover.until) }) : ""}`
    : t("playlistRuns");
  el("factNext").textContent = s.AutoMode === "off" ? t("off") : state.next ? clock(state.next) : (state.autoNote || "—");
  const okFeeds = state.feeds.filter((f) => f.ok).length;
  el("factData").textContent = t("dataLine", { h: state.headlines, f: okFeeds, ft: state.feeds.length, q: state.quotesOk });
  el("factVersion").textContent = state.version;
  el("radarLine").textContent = state.radar.length ? t("radarLine", { terms: state.radar.join(" · ") }) : "";
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Ticker Wall ${state.version}] `);

  const notes = [state.scene.note, state.takeover.note, state.lastError, ...Object.values(state.sourceErrors || {})].filter(Boolean);
  if (!editing && notes.length) setStatus(notes.join(" "), state.lastError ? "bad" : "");
  const permission = el("permissionNote");
  permission.textContent = state.permission || "";
  permission.hidden = !state.permission;

  el("alertList").innerHTML = state.alerts.length
    ? state.alerts.map((a) => `<li><b>${esc(a.label)}</b>${esc(a.title)}<small>${esc(clock(a.at))}</small></li>`).join("")
    : `<li style="border-left-color:var(--line)">${esc(t("noAlerts"))}</li>`;

  if (!editing) {
    for (const node of FIELDS) if (document.activeElement !== node) writeField(node, s[node.id]);
    if (document.activeElement !== el("regionPick")) el("regionPick").value = s.Region;
  }
  renderBells(state);
  el("feedList").innerHTML = state.feeds.map((f) => `<li><span class="dot${f.ok ? "" : " bad"}"></span><b>${esc(f.name)}</b>
    ${f.ok ? esc(t("feedOk", { n: f.count })) : `<span class="err">${esc(f.error)}</span>`}</li>`).join("");
  const key = state.finnhubKey || {};
  el("finnhubKeyInput").placeholder = key.set ? t("keySaved", { hint: key.hint }) : "";
  el("keyRemove").hidden = !key.set;
  const keyNote = (state.sourceErrors || {}).markets || (key.set ? "" : t("keyMissing"));
  el("keyNote").textContent = keyNote;
  el("keyNote").className = `status${(state.sourceErrors || {}).markets && key.set ? " bad" : ""}`;
  const failed = Object.keys(state.quoteErrors || {});
  el("quoteErrors").textContent = failed.length ? t("quoteErrors", { list: failed.join(", ") }) : "";
  const rules = state.rules || [];
  el("AlertRules").title = rules.length ? t("rulesActive", { list: rules.join(", ") }) : "";
  el("playlistNote").textContent = state.ownerPlaylist || "";
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

el("finnhubKeyInput").addEventListener("focus", () => { editing = true; });
el("finnhubKeyInput").addEventListener("blur", () => { editing = false; });
el("keySave").addEventListener("click", async () => {
  const value = el("finnhubKeyInput").value.trim();
  if (!value) return;
  await save({ FinnhubKey: value });
  el("finnhubKeyInput").value = "";
  setTimeout(refresh, 6000);
});
el("keyRemove").addEventListener("click", async () => {
  try {
    await api("./api/remove-key", { method: "POST" });
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
});

el("regionButton").addEventListener("click", async () => {
  const pick = el("regionPick");
  const name = pick.options[pick.selectedIndex].textContent;
  if (!confirm(t("regionAsk", { name }))) return;
  try {
    await api("./api/region", { method: "POST", body: JSON.stringify({ region: pick.value }) });
    setStatus(t("saved"), "ok");
    await refresh();
  } catch (error) {
    setStatus(error.message, "bad");
  }
});

for (const [id, path] of [["showButton", "show"], ["cancelButton", "cancel"], ["refreshButton", "refresh"], ["testButton", "test-alert"]]) {
  el(id).addEventListener("click", async () => {
    try {
      const result = await api(`./api/${path}`, { method: "POST" });
      setStatus(result.message || "", "busy");
      setTimeout(refresh, 2500);
    } catch (error) {
      setStatus(error.message, "bad");
    }
  });
}

applyLanguage("en");
refresh();
setInterval(refresh, 5000);
