# Network Overview

Network Overview (früher Netzwerk-Lagebild) zeigt dein Heimnetz als lebendigen Netzplan: oben das Internet, in der Mitte die Fritzbox, daneben deine Pi-hole(s) und dein Server, rundherum alle Geräte, gruppiert nach LAN, WLAN und Gästen. Über die Leitungen wandern Punkte, so viele, wie gerade los ist: Download und Upload am Internet, DNS-Anfragen der Geräte, und rote Funken an der Pi-hole für jede geblockte Anfrage. Die aktivsten Geräte sind größer und mit Namen beschriftet, neue Geräte leuchten gelb mit „NEU“.

Daneben (im Hochformat darunter) stehen vier Karten:

- **Internet:** aktuelle Geschwindigkeit runter und hoch, Auslastung der Leitung, Datenvolumen heute, wie lange die Verbindung steht.
- **Pi-hole:** heute geblockt, Anteil an allen Anfragen, Verlauf der letzten 24 Stunden und geblockte Anfragen der letzten 7 Tage.
- **Server:** Belegung des Arrays, jede Platte mit Temperatur (oder „schläft“), CPU, RAM und laufende Docker-Container.
- **Lagebild:** was heute auffällt, zum Beispiel ein neues Gerät, eine zu warme Platte, ein fast voller Server, eine Pi-hole, die nicht antwortet oder nicht blockt, mehr geblockt oder mehr geladen als an einem normalen Tag, das aktivste Gerät.

Das Paket besteht aus der **Szene** (kommt wie ein Bild in eine Playlist, empfohlene Dauer 2 Minuten) und dem **Plugin**, das die Daten sammelt, auswertet und einen kurzen Verlauf (60 Tage) auf dem Rahmen aufbewahrt. Alles bleibt im Heimnetz.

## Einrichten

1. Paket installieren (über den Store).
2. **Open Network Overview** öffnen und eintragen, was du hast. Jede Quelle ist freiwillig.
   - **Pi-hole** (6 oder 5): Adresse und App-Passwort, bis zu drei Pi-holes. Mit keepalived kannst du zusätzlich die gemeinsame Adresse eintragen; das Plugin erkennt sie, zählt sie nicht doppelt und zeigt die aktive Pi-hole.
   - **FRITZ!Box:** eigener Benutzer mit dem Recht „FRITZ!Box Einstellungen“, und unter Heimnetz > Netzwerk > Netzwerkeinstellungen „Zugriff für Anwendungen zulassen“.
   - **Server:** Unraid ab 7.2 mit einem API-Key (Settings > Management Access > API Keys, Rolle Viewer), sonst Glances.
3. **Playlist anlegen** drücken, oder die Szene selbst in eine Playlist aufnehmen.

## Gut zu wissen

- Wie viele Daten jedes einzelne Gerät lädt, gibt die Fritzbox über TR-064 nicht heraus. „Am aktivsten“ beruht deshalb auf den DNS-Anfragen, die die Pi-hole zählt.
- Beim allerersten Start gilt kein Gerät als neu. Danach ist ein Gerät 24 Stunden lang „neu“, nachdem es zum ersten Mal auftaucht.
- Vergleiche mit den letzten Tagen holt das Plugin bei Pi-hole 6 gleich aus deren Langzeit-Datenbank; Datenvolumen und Gerätezahl vergleicht es, sobald es selbst ein paar Tage mitgezählt hat.

Probleme oder Wünsche: [Issue auf GitHub](https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=%5BNetwork%20Overview%5D%20).
