/* Color Reveal - die Szene.
 *
 * Zeigt ein Foto nach dem anderen. Jedes beginnt in Schwarz-Weiß und wird
 * innerhalb weniger Sekunden langsam farbig. Das Foto kommt vom Plugin ColorReveal
 * (api/next verkleinert es passend zum Bildschirm und sucht die farbigste
 * Stelle, api/photo liefert es). Das nächste Foto wird schon geholt, während
 * das aktuelle zu sehen ist.
 *
 * Stile:
 * - fade:  das ganze Foto gleichmäßig
 * - light: zuerst die hellen Stellen, die Schatten zuletzt
 * - focus: von der farbigsten Stelle aus, sehr weich nach außen
 * - brush: wie ein weicher, unregelmäßiger Pinselstrich über das Foto
 * - mix:   wechselt mit jedem Foto
 *
 * Die Farbe rechnet die Grafikkarte (WebGL 1, ein Shader mit zwei Texturen:
 * Foto und eine kleine Reihenfolge-Karte, die einmal pro Foto in JS entsteht).
 * Gezeichnet wird nur, solange sich etwas ändert. Ohne WebGL: Schwarz-Weiß-Bild
 * unter dem Farbbild, das per Deckkraft einblendet (nur gleichmäßig).
 *
 * Test im Browser: ?plugin=<url-der-plugin-seite>/ und ?style=, ?layout=, ?bg=,
 * ?lang=, ?reveal=, ?delay=, ?seconds=, ?look=, ?zoom=1, ?date=1, ?back=1, ?nogl=1, ?freeze=0.5 (Standbild)
 */
(function () {
  "use strict";

  const PLUGIN_ID = "ColorReveal";
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  // Über die Weboberfläche (Port 80/443, RemoteFrame, HTTPS) nur derselbe Ursprung: :8003 ist dort
  // per Firewall gesperrt (DROP), jede Anfrage hinge bis zum Timeout.
  const viaWebUi = location.port === "" || location.port === "80" || location.port === "443";
  const pluginBases = params.get("plugin") ? [params.get("plugin")]
    : viaWebUi ? [`${location.origin}${advanced}`]
    : [...new Set([`${location.protocol}//${location.hostname}:8003${advanced}`,
      `${location.origin}${advanced}`,
      `${location.protocol}//${location.hostname}${advanced}`])];
  let baseIndex = 0, baseFound = false;

  const TEXT = {
    de: { empty: "Noch keine Fotos. Wähle auf der Plugin-Seite, woher sie kommen.", busy: "Sucht Fotos …",
      offline: "Color Reveal wartet auf das Plugin …" },
    en: { empty: "No photos yet. Choose on the plugin page where they come from.", busy: "Looking for photos …",
      offline: "Color Reveal is waiting for the plugin …" },
    es: { empty: "Aún no hay fotos. Elige en la página del plugin de dónde vienen.", busy: "Buscando fotos …",
      offline: "Color Reveal está esperando al plugin …" },
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const MIX = ["fade", "light", "focus", "brush"];
  const STYLE_NUM = { fade: 0, light: 1, focus: 2, brush: 3 };
  const LOOK_NUM = { neutral: 0, contrast: 1, warm: 2 };
  const STORE = "colorReveal.v1";
  const CROSSFADE = 1600;

  const el = (id) => document.getElementById(id);
  const stage = el("stage");
  const note = el("note");

  const state = {
    lang: "en", style: "fade", reveal: 6, delay: 2, strength: 100, look: "neutral", backToBw: false,
    layout: "auto", bg: "dark", zoom: false, showDate: false, seconds: 20,
    loaded: false, busy: false, mixIndex: 0,
  };
  let W = 0, H = 0, U = 1;
  let readySent = false;
  let current = null;      // Folie, die gerade zu sehen ist
  const noGl = params.get("nogl") === "1";

  const tx = (key) => (TEXT[state.lang] || TEXT.en)[key] || TEXT.en[key];
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 8000);   // Rückfall: DynaFrame bricht sonst die Szene ab

  function report(text) {
    try {
      fetch(`${pluginBases[baseIndex]}api/report?m=${encodeURIComponent(String(text).slice(0, 200))}`,
        { cache: "no-store" }).catch(() => {});
    } catch (_) { /* egal */ }
  }

  // ------------------------------------------------------------ Daten

  async function fetchJson(path) {
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 15000);
    const used = baseIndex;
    try {
      const response = await fetch(pluginBases[used] + path, { cache: "no-store", signal: abort.signal });
      if (!response.ok && response.status !== 404) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      baseFound = true;
      return data;
    } catch (error) {
      // Nur weiterschalten, solange noch keine Adresse ging, und nur, wenn dieser Aufruf die aktuelle benutzt hat
      if (!baseFound && pluginBases.length > 1 && used === baseIndex) baseIndex = (baseIndex + 1) % pluginBases.length;
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  function remember(data) {
    try { localStorage.setItem(STORE, JSON.stringify(data)); } catch (_) { /* kein Speicher */ }
  }

  function recall() {
    try { return JSON.parse(localStorage.getItem(STORE) || "null"); } catch (_) { return null; }
  }

  const num = (value, fallback) =>
    (value !== null && value !== undefined && value !== "" && Number.isFinite(Number(value)) ? Number(value) : fallback);

  function applySettings(s) {
    s = s || {};
    state.lang = params.get("lang") || s.Language || state.lang;
    state.style = params.get("style") || s.Style || state.style;
    state.reveal = Math.max(1, num(params.get("reveal"), num(s.RevealSeconds, state.reveal)));
    state.delay = Math.max(0, num(params.get("delay"), num(s.RevealDelay, state.delay)));
    state.strength = Math.max(10, Math.min(100, num(params.get("strength"), num(s.ColourStrength, state.strength))));
    state.look = params.get("look") || s.BwLook || state.look;
    state.backToBw = params.has("back") ? params.get("back") === "1" : Boolean(s.BackToBw);
    state.layout = params.get("layout") || s.Layout || state.layout;
    state.bg = params.get("bg") || s.Background || state.bg;
    state.zoom = params.has("zoom") ? params.get("zoom") === "1" : Boolean(s.SlowZoom);
    state.showDate = params.has("date") ? params.get("date") === "1" : Boolean(s.ShowDate);
    state.seconds = Math.max(4, num(params.get("seconds"), num(s.PhotoSeconds, state.seconds)));
    document.documentElement.lang = state.lang;
    document.documentElement.classList.toggle("light", state.bg === "light");
    document.documentElement.classList.toggle("dark", state.bg !== "light");
  }

  async function poll() {
    try {
      const data = await fetchJson("api/scene");
      if (data && data.success) {
        applySettings(data.settings);
        state.busy = !!data.busy;
        state.loaded = true;
        remember({ settings: data.settings });
      }
    } catch (_) { /* nächster Versuch */ }
    setTimeout(poll, state.loaded ? 30000 : 5000);
  }

  // Über fetch -> Blob holen: so ist das Bild für WebGL "same origin" (kein Taint).
  async function loadImage(url) {
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 30000);
    let blobUrl = "";
    try {
      const response = await fetch(url, { cache: "no-store", signal: abort.signal });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      blobUrl = URL.createObjectURL(await response.blob());
      const img = new Image();
      img.decoding = "async";
      img.alt = "";
      img.src = blobUrl;
      await img.decode();
      return { img, blobUrl };
    } catch (error) {
      if (blobUrl) URL.revokeObjectURL(blobUrl);
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }

  async function nextItem() {
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = Math.round(window.innerWidth * dpr), h = Math.round(window.innerHeight * dpr);
    const data = await fetchJson(`api/next?w=${w}&h=${h}`);
    if (!data || !data.success) return { empty: !!(data && data.empty), busy: data && data.busy };
    const { img, blobUrl } = await loadImage(`${pluginBases[baseIndex]}api/photo?id=${encodeURIComponent(data.id)}`);
    return { ...data, img, blobUrl, aspect: (img.naturalWidth || data.w) / (img.naturalHeight || data.h || 1) };
  }

  // ------------------------------------------------------------ Reihenfolge-Karte

  // Kleine Karte (höchstens 160 Pixel), welche Stelle wann farbig wird: 0 = zuerst, 1 = zuletzt.
  // Einmal pro Foto in JS; die Grafikkarte liest sie weich interpoliert.
  function hash(x, y, seed) {
    let h = (Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(seed, 1442695041)) | 0;
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
  }

  function valueNoise(x, y, seed) {
    const xi = Math.floor(x), yi = Math.floor(y);
    const xf = x - xi, yf = y - yi;
    const sx = xf * xf * (3 - 2 * xf), sy = yf * yf * (3 - 2 * yf);
    const a = hash(xi, yi, seed), b = hash(xi + 1, yi, seed);
    const c = hash(xi, yi + 1, seed), d = hash(xi + 1, yi + 1, seed);
    return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy;
  }

  function fbm(x, y, seed) {
    let sum = 0, amp = 0.5, freq = 1, norm = 0;
    for (let o = 0; o < 4; o++) {
      sum += amp * valueNoise(x * freq, y * freq, seed + o * 17);
      norm += amp;
      amp *= 0.5;
      freq *= 2.03;
    }
    return sum / norm;
  }

  function orderMap(style, aspect, focus) {
    const gw = aspect >= 1 ? 160 : Math.max(16, Math.round(160 * aspect));
    const gh = aspect >= 1 ? Math.max(16, Math.round(160 / aspect)) : 160;
    const field = new Float32Array(gw * gh);
    const seed = Math.floor(Math.random() * 100000);
    const fx = focus ? focus[0] : 0.5, fy = focus ? focus[1] : 0.5;
    const angle = Math.random() * Math.PI * 2;
    const dx = Math.cos(angle), dy = Math.sin(angle);
    for (let j = 0; j < gh; j++) {
      for (let i = 0; i < gw; i++) {
        const u = (i + 0.5) / gw, v = (j + 0.5) / gh;
        const px = u * aspect, py = v;   // gleiche Einheiten in beiden Richtungen
        let f;
        if (style === "focus") {
          f = Math.hypot((u - fx) * aspect, v - fy) + (fbm(px * 2.2, py * 2.2, seed) - 0.5) * 0.22;
        } else {
          // brush: Richtung (zufällig je Foto) plus unruhige Kante wie Aquarell
          f = (px * dx + py * dy) + (fbm(px * 1.8, py * 1.8, seed) - 0.5) * 0.9;
        }
        field[j * gw + i] = f;
      }
    }
    let lo = Infinity, hi = -Infinity;
    for (const v of field) { if (v < lo) lo = v; if (v > hi) hi = v; }
    const span = hi - lo || 1;
    const bytes = new Uint8Array(gw * gh);
    for (let k = 0; k < field.length; k++) bytes[k] = Math.round(((field[k] - lo) / span) * 255);
    return { w: gw, h: gh, bytes };
  }

  // ------------------------------------------------------------ WebGL

  const VERT = `
attribute vec2 a_pos;
varying vec2 v_uv;
void main() {
  v_uv = vec2(a_pos.x * 0.5 + 0.5, 0.5 - a_pos.y * 0.5);
  gl_Position = vec4(a_pos, 0.0, 1.0);
}`;

  const FRAG = `
precision mediump float;
varying vec2 v_uv;
uniform sampler2D u_img;
uniform sampler2D u_order;
uniform vec4 u_crop;      // xy = Versatz, zw = Maßstab (Ausschnitt des Fotos)
uniform float u_p;        // Fortschritt 0..1
uniform float u_strength; // so viel Farbe am Ende
uniform int u_style;      // 0 fade, 1 light, 2 focus, 3 brush
uniform int u_look;       // 0 neutral, 1 kontrastreich, 2 warm
void main() {
  vec2 uv = u_crop.xy + v_uv * u_crop.zw;
  vec3 c = texture2D(u_img, uv).rgb;
  float y = dot(c, vec3(0.2126, 0.7152, 0.0722));
  vec3 g = vec3(y);
  if (u_look == 1) {
    float s = y * y * (3.0 - 2.0 * y);
    g = vec3(mix(y, s, 0.55));
  } else if (u_look == 2) {
    g = vec3(y) * vec3(1.0, 0.965, 0.9) + vec3(0.025, 0.018, 0.008);
  }
  float m;
  if (u_style == 0) {
    m = u_p;
  } else {
    float f;
    float w;
    if (u_style == 1) {
      f = 1.0 - y;          // helle Stellen zuerst
      w = 0.55;
    } else {
      f = texture2D(u_order, uv).r;
      w = u_style == 2 ? 0.5 : 0.38;
    }
    m = clamp((u_p * (1.0 + w) - f) / w, 0.0, 1.0);
    m = mix(m, u_p, 0.12);  // ein Hauch überall, damit keine harte Grenze bleibt
  }
  m = m * m * (3.0 - 2.0 * m);
  gl_FragColor = vec4(mix(g, c, m * u_strength), 1.0);
}`;

  function makeRenderer(canvas, img) {
    const gl = canvas.getContext("webgl", { alpha: false, antialias: false, depth: false, stencil: false,
      premultipliedAlpha: false, preserveDrawingBuffer: false });
    if (!gl) return null;
    const shader = (type, source) => {
      const s = gl.createShader(type);
      gl.shaderSource(s, source);
      gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) || "shader");
      return s;
    };
    const program = gl.createProgram();
    gl.attachShader(program, shader(gl.VERTEX_SHADER, VERT));
    gl.attachShader(program, shader(gl.FRAGMENT_SHADER, FRAG));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program) || "link");
    gl.useProgram(program);
    const buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(program, "a_pos");
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    const texture = (unit) => {
      const t = gl.createTexture();
      gl.activeTexture(gl.TEXTURE0 + unit);
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      return t;
    };
    texture(0);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, img);
    texture(1);
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, 1, 1, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, new Uint8Array([0]));
    const u = (name) => gl.getUniformLocation(program, name);
    const loc2 = { img: u("u_img"), order: u("u_order"), crop: u("u_crop"), p: u("u_p"), strength: u("u_strength"),
      style: u("u_style"), look: u("u_look") };
    gl.uniform1i(loc2.img, 0);
    gl.uniform1i(loc2.order, 1);
    gl.uniform4f(loc2.crop, 0, 0, 1, 1);
    let lost = false;
    canvas.addEventListener("webglcontextlost", (e) => { e.preventDefault(); lost = true; });
    const r = {
      p: 0,
      setup(style, look, strength, order) {
        gl.uniform1i(loc2.style, STYLE_NUM[style] || 0);
        gl.uniform1i(loc2.look, LOOK_NUM[look] || 0);
        gl.uniform1f(loc2.strength, strength);
        if (order) {
          gl.activeTexture(gl.TEXTURE1);
          gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, order.w, order.h, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, order.bytes);
        }
      },
      crop(x, y, w, h) { gl.uniform4f(loc2.crop, x, y, w, h); },
      size(w, h) {
        if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
        gl.viewport(0, 0, w, h);
      },
      draw(p) {
        r.p = p;
        if (lost) return;
        gl.uniform1f(loc2.p, p);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      },
      dispose() {
        try { gl.getExtension("WEBGL_lose_context")?.loseContext(); } catch (_) { /* egal */ }
      },
    };
    return r;
  }

  // ------------------------------------------------------------ Aufbau einer Folie

  function measure() {
    W = window.innerWidth;
    H = window.innerHeight;
    U = Math.min(W, H) / 100;
    document.documentElement.style.setProperty("--u", `${U}px`);
  }

  const fit = (bw, bh, a) => {
    const w = Math.max(1, Math.min(bw, bh * a));
    return { w, h: w / a };
  };

  function chooseStyle() {
    if (state.style !== "mix") return STYLE_NUM[state.style] !== undefined ? state.style : "fade";
    const name = MIX[state.mixIndex % MIX.length];
    state.mixIndex++;
    return name;
  }

  function chooseLayout(aspect) {
    if (state.layout !== "auto") return ["fill", "fit", "gallery"].includes(state.layout) ? state.layout : "fit";
    const ratio = aspect / (W / H);
    return ratio > 0.8 && ratio < 1.25 ? "fill" : "fit";
  }

  function dateText(item) {
    if (!state.showDate || !item.taken) return "";
    const d = new Date(`${item.taken}T12:00:00`);
    if (Number.isNaN(d.getTime())) return "";
    return d.toLocaleDateString(LOCALES[state.lang] || "en-GB", { day: "numeric", month: "long", year: "numeric" });
  }

  // Lage von Ausschnitt (view), Rahmen und Datum für die aktuelle Bildschirmgröße
  function geometry(slide) {
    measure();
    const a = slide.item.aspect;
    const g = { view: null, frame: null, crop: [0, 0, 1, 1], date: null };
    if (slide.layout === "fill") {
      const R = W / H;
      g.view = { x: 0, y: 0, w: W, h: H };
      g.crop = a > R ? [(1 - R / a) / 2, 0, R / a, 1] : [0, (1 - a / R) / 2, 1, a / R];
      g.date = { right: U * 3, bottom: U * 2.6, over: true };
    } else if (slide.layout === "fit") {
      const p = fit(W, H, a);
      g.view = { x: (W - p.w) / 2, y: (H - p.h) / 2, w: p.w, h: p.h };
      const sideRoom = (W - p.w) / 2;
      g.date = sideRoom > U * 22 ? { right: U * 3, bottom: U * 2.6 }
        : { right: sideRoom + U * 3, bottom: (H - p.h) / 2 + U * 2.6, over: true };
    } else {
      const border = Math.max(2, U * 1.1);
      const mat = U * 6.5;
      const label = state.showDate && slide.item.taken ? U * 5 : 0;
      const room = fit(W - U * 16 - 2 * (border + mat), H - U * 14 - label - 2 * (border + mat), a);
      const fw = room.w + 2 * (border + mat), fh = room.h + 2 * (border + mat);
      const fx = (W - fw) / 2, fy = (H - fh - label) / 2;
      g.frame = { x: fx, y: fy, w: fw, h: fh, border };
      g.view = { x: mat, y: mat, w: room.w, h: room.h };   // innerhalb des Rahmens (nach dem Rand)
      g.date = { left: fx, top: fy + fh + U * 2 };
    }
    return g;
  }

  function placeBox(node, b) {
    Object.assign(node.style, { left: `${b.x}px`, top: `${b.y}px`, width: `${b.w}px`, height: `${b.h}px` });
  }

  function lay(slide) {
    const g = geometry(slide);
    if (g.frame) {
      placeBox(slide.frameNode, g.frame);
      slide.frameNode.style.borderWidth = `${g.frame.border}px`;
    }
    placeBox(slide.view, g.view);
    if (slide.dateNode && g.date) {
      const s = slide.dateNode.style;
      s.left = s.right = s.top = s.bottom = "";
      for (const k of ["left", "right", "top", "bottom"]) if (g.date[k] !== undefined) s[k] = `${g.date[k]}px`;
      slide.dateNode.classList.toggle("over", Boolean(g.date.over));
    }
    if (slide.gl) {
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const iw = slide.item.img.naturalWidth, ih = slide.item.img.naturalHeight;
      // Nicht feiner rechnen, als das Foto Pixel hat (der Ausschnitt zählt)
      const scale = Math.max(0.5, Math.min(dpr, (iw * g.crop[2]) / g.view.w, (ih * g.crop[3]) / g.view.h));
      slide.gl.size(Math.max(16, Math.round(g.view.w * scale)), Math.max(16, Math.round(g.view.h * scale)));
      slide.gl.crop(...g.crop);
      slide.gl.draw(slide.gl.p);
    }
  }

  function build(item) {
    const slide = { item, style: chooseStyle(), layout: chooseLayout(item.aspect), gl: null, raf: 0 };
    const root = document.createElement("div");
    root.className = `slide ${slide.layout}`;
    const view = document.createElement("div");
    view.className = "view";
    slide.root = root;
    slide.view = view;
    if (slide.layout === "gallery") {
      slide.frameNode = document.createElement("div");
      slide.frameNode.className = "frame";
      slide.frameNode.append(view);
      root.append(slide.frameNode);
    } else {
      root.append(view);
    }
    if (!noGl) {
      const canvas = document.createElement("canvas");
      let renderer = null;
      try {
        renderer = makeRenderer(canvas, item.img);
      } catch (error) {
        report(`WebGL: ${error.message}`);
      }
      if (renderer) {
        const order = slide.style === "focus" || slide.style === "brush"
          ? orderMap(slide.style, item.aspect, item.focus) : null;
        renderer.setup(slide.style, state.look, state.strength / 100, order);
        view.append(canvas);
        slide.gl = renderer;
        slide.zoomNode = canvas;
      }
    }
    if (!slide.gl) {
      // Ohne WebGL: S/W darunter, Farbe darüber blendet ein
      const bw = item.img.cloneNode();
      bw.className = "bw";
      item.img.className = "col";
      view.append(bw, item.img);
      slide.colNode = item.img;
      slide.zoomNode = view;
    }
    const date = dateText(item);
    if (date) {
      slide.dateNode = document.createElement("span");
      slide.dateNode.className = "date";
      slide.dateNode.textContent = date;
      root.append(slide.dateNode);
    }
    return slide;
  }

  function dispose(slide) {
    if (!slide) return;
    cancelAnimationFrame(slide.raf);
    slide.root.remove();
    if (slide.gl) slide.gl.dispose();
    if (slide.item.blobUrl) URL.revokeObjectURL(slide.item.blobUrl);
  }

  // ------------------------------------------------------------ Farbe kommen lassen

  const ease = (t) => t * t * t * (t * (t * 6 - 15) + 10);   // smootherstep: sanft hinein und hinaus

  function animate(slide, from, to, seconds) {
    return new Promise((resolve) => {
      if (slide.gl) {
        const start = performance.now();
        const step = (now) => {
          const t = Math.min(1, Math.max(0, (now - start) / (seconds * 1000)));
          slide.gl.draw(from + (to - from) * ease(t));
          if (t < 1 && !slide.gone) slide.raf = requestAnimationFrame(step);
          else resolve();
        };
        slide.raf = requestAnimationFrame(step);
        return;
      }
      const col = slide.colNode;
      col.style.transitionDuration = `${seconds}s`;
      col.style.opacity = String((to * state.strength) / 100);
      setTimeout(resolve, seconds * 1000);
    });
  }

  function startZoom(slide, seconds) {
    if (!state.zoom || !slide.zoomNode) return;
    const node = slide.zoomNode;
    node.style.transition = "none";
    node.style.transform = "scale(1)";
    void node.offsetWidth;
    node.style.transition = `transform ${seconds}s linear`;
    node.style.transform = "scale(1.045)";
  }

  async function present(item) {
    hideNote();
    const slide = build(item);
    stage.append(slide.root);
    lay(slide);
    if (slide.gl) slide.gl.draw(0);
    void slide.root.offsetWidth;   // Startzustand festhalten, dann Übergang
    slide.root.classList.add("on");
    const old = current;
    current = slide;
    if (old) {
      old.gone = true;
      setTimeout(() => dispose(old), CROSSFADE + 200);
    }
    ready();
    const hold = Math.max(state.seconds, state.delay + state.reveal + 3);
    startZoom(slide, hold + (2 * CROSSFADE) / 1000);
    const shownAt = Date.now();
    if (params.has("freeze") && slide.gl) {   // nur für Vorschaubilder: auf einem Stand stehen bleiben
      await sleep(CROSSFADE);
      slide.gl.draw(Number(params.get("freeze")));
      await sleep(3600 * 1000);
    }
    await sleep(state.delay * 1000);
    if (!slide.gone) await animate(slide, 0, 1, state.reveal);
    return { slide, shownAt, hold };
  }

  async function farewell(slide) {
    // Auf Wunsch vor dem nächsten Foto wieder zurück zu Schwarz-Weiß
    if (!state.backToBw || slide.gone) return;
    await animate(slide, 1, 0, Math.min(state.reveal, 4));
  }

  // Bei Größenwechsel (Drehen des Rahmens) neu legen, ohne Animation
  let resizeTimer = 0;
  window.addEventListener("resize", () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => { if (current) lay(current); }, 250);
  });

  function showNote(key) {
    if (current) return;   // ein Foto bleibt lieber stehen als eine leere Seite
    note.textContent = tx(key);
    note.classList.add("on");
    ready();
  }

  function hideNote() {
    note.classList.remove("on");
  }

  async function fetchNext() {
    try {
      return await nextItem();
    } catch (error) {
      return { failed: true, error };
    }
  }

  async function run() {
    let failures = 0;
    let next = await fetchNext();
    for (;;) {
      if (next.img) {
        failures = 0;
        const shown = await present(next);
        const fetching = fetchNext();
        const backMs = state.backToBw ? Math.min(state.reveal, 4) * 1000 : 0;
        await sleep(Math.max(0, shown.hold * 1000 - (Date.now() - shown.shownAt) - backMs));
        next = await fetching;
        if (!next.img) {
          // Kam nichts, bleibt das Foto stehen und es geht gleich wieder los
          await sleep(4000);
          next = await fetchNext();
        }
        if (next.img) await farewell(shown.slide);
        continue;
      }
      failures++;
      if (next.empty) showNote(next.busy || state.busy ? "busy" : "empty");
      else if (failures >= 2) {
        showNote("offline");
        if (failures === 3) report(`Szene: kein Foto (${next.error && next.error.message})`);
      }
      await sleep(next.empty ? 8000 : Math.min(15000, 3000 * failures));
      next = await fetchNext();
    }
  }

  // ------------------------------------------------------------ Start

  measure();
  const remembered = recall();
  applySettings(remembered && remembered.settings ? remembered.settings : {});
  poll();
  run();
})();
