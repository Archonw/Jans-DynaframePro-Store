/* Party Wall - die Szene.
 *
 * Das Plugin wählt das Foto und sammelt die Reaktionen; die Szene fragt etwa
 * jede Sekunde api/wall?since=<letzte Reaktion> und zeigt:
 *   welcome - noch keine Fotos: großer QR-Code,
 *   wall    - ein Foto groß (Polaroid oder ganz), daneben QR-Code und
 *             „gerade beliebt“; Emojis der Gäste fliegen hoch,
 *   top     - zwischendurch die fünf beliebtesten Fotos,
 *   recap   - die Rückschau: Zahlen des Abends, Countdown der beliebtesten
 *             Fotos, zum Schluss eine Collage. Läuft in der Szene im Kreis.
 * Dass die Szene fragt, heißt fürs Plugin: die Wand ist zu sehen.
 *
 * Zum Ausprobieren: ?plugin=<URL der Plugin-Seite> &lang=de|en|es
 */
(function () {
  "use strict";

  const PLUGIN_ID = "PartyWall";
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const sameOrigin = (location.protocol === "http:" && (location.port === "" || location.port === "80"))
    || (location.protocol === "https:" && (location.port === "" || location.port === "443"));
  const pluginBases = params.get("plugin") ? [params.get("plugin").replace(/\/?$/, "/")] : [...new Set(sameOrigin ? [
    `${location.origin}${advanced}`,
    `${location.protocol}//${location.hostname}:8003${advanced}`
  ] : [
    `${location.protocol}//${location.hostname || "localhost"}:8003${advanced}`,
    `http://${location.hostname || "localhost"}${advanced}`
  ])];
  let baseIndex = 0;

  const EMOJI = { heart: "2764", laugh: "1f602", love: "1f60d", fire: "1f525", clap: "1f44f", party: "1f389", wow: "1f62e" };
  const TEXT = {
    de: {
      join: "Teil deine Fotos!", joinBig: "Scannt den Code und teilt eure Fotos vom Abend. Reagiert mit Emojis auf die Fotos der anderen.",
      code: "Code", stats: "<b>{p}</b> Fotos · <b>{g}</b> Gäste · <b>{r}</b> Reaktionen", hot: "Gerade beliebt",
      fresh: "NEU", topKicker: "Zwischenstand", topTitle: "Die beliebtesten Fotos bis jetzt",
      recap: "Rückschau", photos: "Fotos", guests: "Gäste", reactions: "Reaktionen", mostPhotos: "die meisten Fotos",
      thanks: "Danke fürs Mitfeiern!", endSub: "{p} Fotos von {g} Gästen", party: "Party Wall",
      unreachable: "Party Wall antwortet nicht.", login: "Bitte zuerst im Browser beim Rahmen anmelden.",
      noUploads: "Fotos hochladen ist gerade aus"
    },
    en: {
      join: "Share your photos!", joinBig: "Scan the code and share your photos of the evening. React to everyone else's photos with emojis.",
      code: "Code", stats: "<b>{p}</b> photos · <b>{g}</b> guests · <b>{r}</b> reactions", hot: "Popular right now",
      fresh: "NEW", topKicker: "So far", topTitle: "The most popular photos so far",
      recap: "Recap", photos: "photos", guests: "guests", reactions: "reactions", mostPhotos: "most photos",
      thanks: "Thanks for celebrating!", endSub: "{p} photos from {g} guests", party: "Party Wall",
      unreachable: "Party Wall is not responding.", login: "Please sign in to the frame in the browser first.",
      noUploads: "Uploading is off right now"
    },
    es: {
      join: "¡Comparte tus fotos!", joinBig: "Escanead el código y compartid vuestras fotos de la noche. Reaccionad con emojis a las fotos de los demás.",
      code: "Código", stats: "<b>{p}</b> fotos · <b>{g}</b> invitados · <b>{r}</b> reacciones", hot: "Lo más popular ahora",
      fresh: "NUEVA", topKicker: "Hasta ahora", topTitle: "Las fotos más populares hasta ahora",
      recap: "Resumen", photos: "fotos", guests: "invitados", reactions: "reacciones", mostPhotos: "más fotos",
      thanks: "¡Gracias por celebrar con nosotros!", endSub: "{p} fotos de {g} invitados", party: "Party Wall",
      unreachable: "Party Wall no responde.", login: "Inicia sesión primero en el marco desde el navegador.",
      noUploads: "La subida de fotos está desactivada"
    }
  };
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  let lang = params.get("lang") || "en";
  const tx = (key, values) => {
    let text = (TEXT[lang] || TEXT.en)[key] || key;
    for (const [k, v] of Object.entries(values || {})) text = text.split(`{${k}}`).join(v);
    return text;
  };
  const $ = (id) => document.getElementById(id);
  const esc = (text) => String(text ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const fmt = (n) => Number(n || 0).toLocaleString(LOCALES[lang] || "en-GB");

  // ------------------------------------------------------------ Plugin

  async function api(path) {
    let lastError = null;
    for (let i = 0; i < pluginBases.length; i += 1) {
      const base = pluginBases[(baseIndex + i) % pluginBases.length];
      try {
        const response = await fetch(base + path, { cache: "no-store", credentials: "same-origin" });
        if (response.redirected && /login/i.test(response.url)) throw new Error("login");
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        const body = await response.json();
        baseIndex = (baseIndex + i) % pluginBases.length;
        return body;
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error("unreachable");
  }
  const url = (path) => pluginBases[baseIndex] + path;
  const photoUrl = (id, size = "f") => url(`api/photo?id=${encodeURIComponent(id)}&s=${size}`);

  function report(message) {
    api("api/report?m=" + encodeURIComponent(String(message).slice(0, 180))).catch(() => {});
  }
  addEventListener("error", (e) => report(`${e.message} ${e.filename || ""}:${e.lineno || ""}`));

  // DynaFrame wartet, bis die Szene meldet, dass sie steht; sonst bricht der
  // Fernseher nach einer Frist ab ("scene readiness deadline expired").
  let readySent = false;
  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 8000);

  function showNote(text) {
    $("note").textContent = text || "";
    $("note").hidden = !text;
    if (text) ready();
  }

  // ------------------------------------------------------------ Größe

  function layout() {
    const w = innerWidth, h = innerHeight;
    document.documentElement.style.setProperty("--u", `${Math.min(w, h) / 100}px`);
    document.body.classList.toggle("portrait", h > w);
    document.body.classList.toggle("landscape", h <= w);
    fitCard(document.querySelector("#stage .card:not(.leave)"));
  }
  addEventListener("resize", layout);
  const unit = () => Math.min(innerWidth, innerHeight) / 100;

  function loadImage(src) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.decoding = "async";
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("image " + src));
      img.src = src;
    });
  }

  // ------------------------------------------------------------ QR-Code

  const qrDone = {};
  function drawQr(id, link) {
    if (!link || qrDone[id] === link || typeof qrcode !== "function") return;
    qrDone[id] = link;
    const code = qrcode(0, "M");
    code.addData(link);
    code.make();
    $(id).innerHTML = code.createSvgTag({ cellSize: 4, margin: 0, scalable: true });
  }

  function renderJoin(state) {
    const link = state.url ? `${state.url}?c=${state.code}` : "";
    const host = (state.url || "").replace(/^https?:\/\//, "").replace(/\/$/, "");
    drawQr("qr", link);
    drawQr("qrBig", link);
    $("joinTitle").textContent = state.uploads ? tx("join") : tx("noUploads");
    $("codeLabel").textContent = tx("code");
    $("codeLabelBig").textContent = tx("code");
    $("code").textContent = state.code;
    $("codeBig").textContent = state.code;
    $("joinUrl").textContent = host;
    $("joinUrlBig").textContent = host;
    document.querySelector(".join").hidden = !link;
  }

  // ------------------------------------------------------------ Karten (Fotos)

  function chipsHtml(reactions) {
    return Object.entries(reactions || {}).filter(([, n]) => n > 0).sort((a, b) => b[1] - a[1]).slice(0, 5)
      .map(([key, n]) => `<span data-e="${key}"><img src="emoji/${EMOJI[key]}.svg" alt=""><b>${fmt(n)}</b></span>`).join("");
  }

  function makeCard(photo, opts = {}) {
    const card = document.createElement("div");
    card.className = "card";
    card.dataset.w = photo.w;
    card.dataset.h = photo.h;
    card.style.setProperty("--rot", `${opts.rot ?? ((Math.random() * 5 - 2.5).toFixed(2))}deg`);
    const label = (opts.names !== false || (opts.caption !== false && photo.cap))
      ? `<div class="label">${opts.names !== false ? `<i class="dot" style="background:${esc(photo.color)}"></i><span class="who">${esc(photo.name)}</span>` : ""}
         ${opts.caption !== false && photo.cap ? `<span class="cap">${esc(photo.cap)}</span>` : ""}</div>` : `<div class="label"></div>`;
    card.innerHTML = `<div class="pic"><img alt=""></div>${label}${opts.fresh ? `<span class="badge">${esc(tx("fresh"))}</span>` : ""}`;
    card.querySelector("img").src = opts.src || photoUrl(photo.id);
    return card;
  }

  function fitCard(card, boxW, boxH) {
    if (!card) return;
    const box = card.parentElement;
    if (!box) return;
    const W = boxW || box.clientWidth, H = boxH || box.clientHeight;
    const polaroid = document.body.classList.contains("polaroid");
    const u = unit();
    const pad = polaroid ? u * 1.6 : 0;
    const label = polaroid ? u * 9 : 0;
    const chipRoom = card.closest("#stage") ? u * 6 : 0;
    const w = Number(card.dataset.w) || 4, h = Number(card.dataset.h) || 3;
    const maxW = W * 0.94 - 2 * pad, maxH = (H - chipRoom) * 0.94 - pad - label;
    const scale = Math.min(maxW / w, maxH / h);
    const pic = card.querySelector(".pic");
    pic.style.width = `${Math.round(w * scale)}px`;
    pic.style.height = `${Math.round(h * scale)}px`;
    if (chipRoom) card.style.top = `${(H - chipRoom) / 2}px`;
  }

  // ------------------------------------------------------------ Die Wand

  const wall = { id: "", key: "", backdrop: "" };

  async function showPhoto(state) {
    const photo = state.photo;
    const stage = $("stage");
    if (!photo) return;
    const chips = chipsHtml(photo.r);
    if (photo.id === wall.id) {
      updateChips(chips);
      return;
    }
    wall.id = photo.id;
    let img;
    try {
      img = await loadImage(photoUrl(photo.id));
    } catch (error) {
      report(String(error));
      wall.id = "";
      return;
    }
    if (wall.id !== photo.id) return;
    for (const old of stage.querySelectorAll(".card")) {
      old.classList.add("leave");
      setTimeout(() => old.remove(), 1200);
    }
    const card = makeCard(photo, { names: state.showNames, caption: state.showCaptions, fresh: photo.new, src: img.src });
    card.classList.add("enter");
    stage.appendChild(card);
    fitCard(card);
    requestAnimationFrame(() => requestAnimationFrame(() => card.classList.remove("enter")));
    let bar = stage.querySelector(".chips");
    if (!bar) {
      bar = document.createElement("div");
      bar.className = "chips";
      stage.appendChild(bar);
    }
    bar.innerHTML = chips;
    bar.dataset.html = chips;
    setBackdrop(photoUrl(photo.id, "t"));
    if (state.next) new Image().src = photoUrl(state.next);
    ready();
  }

  function updateChips(html) {
    const bar = $("stage").querySelector(".chips");
    if (!bar || bar.dataset.html === html) return;
    const before = Object.fromEntries([...bar.querySelectorAll("span")].map((s) => [s.dataset.e, s.textContent]));
    bar.innerHTML = html;
    bar.dataset.html = html;
    for (const span of bar.querySelectorAll("span")) {
      if (before[span.dataset.e] !== span.textContent) {
        span.classList.add("bump");
        setTimeout(() => span.classList.remove("bump"), 260);
      }
    }
  }

  function setBackdrop(src) {
    const back = $("backdrop");
    if (wall.backdrop === src) return;
    wall.backdrop = src;
    if (!src) { back.classList.remove("on"); return; }
    back.classList.remove("on");
    setTimeout(() => {
      back.onload = () => back.classList.add("on");
      back.src = src;
    }, 500);
  }

  function renderSide(state) {
    const s = state.stats || {};
    $("stats").innerHTML = tx("stats", { p: fmt(s.photos), g: fmt(s.guests), r: fmt(s.reactions) });
    const hot = state.hot || [];
    $("hotBox").hidden = !hot.length;
    $("hotTitle").textContent = tx("hot");
    const html = hot.map((p, i) => `<li><b>${i + 1}</b><img src="${photoUrl(p.id, "t")}" alt="">
      <span><span class="name">${esc(p.name)}</span><small>${chipsHtml(p.r).replace(/<[^>]+>/g, " ").trim() ? topLine(p.r) : ""}</small></span></li>`).join("");
    if ($("hot").dataset.html !== html) { $("hot").innerHTML = html; $("hot").dataset.html = html; }
  }

  function topLine(reactions) {
    return Object.entries(reactions || {}).filter(([, n]) => n > 0).sort((a, b) => b[1] - a[1]).slice(0, 3)
      .map(([key, n]) => `<img src="emoji/${EMOJI[key]}.svg" alt="" style="width:1.1em;height:1.1em;vertical-align:-.2em"> ${fmt(n)}`).join("&nbsp;&nbsp;");
  }

  // ------------------------------------------------------------ Fliegende Emojis

  let flying = 0;
  function fly(event, state) {
    if (flying > 40) return;    // nicht mehr als 40 gleichzeitig: der Pi soll flüssig bleiben
    flying += 1;
    const node = document.createElement("div");
    node.className = "fly";
    const u = unit();
    const stage = $("stage").getBoundingClientRect();
    const onWall = state.phase === "wall" && stage.width > 0;
    const left = onWall ? stage.left + stage.width * (0.1 + Math.random() * 0.8) : innerWidth * (0.08 + Math.random() * 0.84);
    node.style.left = `${left - u * 4}px`;
    node.style.setProperty("--dur", `${(4.2 + Math.random() * 1.8).toFixed(2)}s`);
    node.style.setProperty("--wob", `${(1.2 + Math.random() * 0.8).toFixed(2)}s`);
    node.style.setProperty("--size", `${(u * (7 + Math.random() * 3)).toFixed(0)}px`);
    node.style.setProperty("--c", event.c || "#fff");
    node.innerHTML = `<div class="wob"><img class="e" src="emoji/${EMOJI[event.e] || EMOJI.heart}.svg" alt="">
      ${!event.here && event.p ? `<img class="t" src="${photoUrl(event.p, "t")}" alt="">` : ""}
      ${event.n ? `<small>${esc(event.n)}</small>` : ""}</div>`;
    $("flyer").appendChild(node);
    node.addEventListener("animationend", (e) => {
      if (e.target !== node) return;
      node.remove();
      flying -= 1;
    });
  }

  function launch(events, state) {
    // Viele auf einmal etwas auseinanderziehen, damit sie nicht als Klumpen fliegen.
    events.slice(-30).forEach((event, i) => setTimeout(() => fly(event, state), i * 140 + Math.random() * 120));
  }

  // ------------------------------------------------------------ Hitliste zwischendurch

  let topKey = "";
  function renderTop(state) {
    $("topKicker").textContent = tx("topKicker");
    $("topTitle").textContent = tx("topTitle");
    const key = (state.top || []).map((p) => p.id).join(",");
    if (key === topKey) return;
    topKey = key;
    $("podium").innerHTML = (state.top || []).map((p, i) => `<li>
      <div class="pic"><span class="rank">${i + 1}</span><img src="${photoUrl(p.id)}" alt=""></div>
      <span class="who">${esc(p.name)}</span><div class="chips">${chipsHtml(p.r)}</div></li>`).join("");
    setBackdrop(state.top && state.top[0] ? photoUrl(state.top[0].id, "t") : "");
  }

  // ------------------------------------------------------------ Rückschau

  const recap = { id: -1, steps: [], index: 0, timer: 0, data: null };

  function recapSteps(data) {
    const steps = [{ kind: "intro", seconds: 9 }];
    const top = data.top || [];
    for (let i = top.length - 1; i >= 0; i -= 1) steps.push({ kind: "rank", photo: top[i], rank: i + 1, seconds: i === 0 ? 11 : 7 });
    steps.push({ kind: "end", seconds: 16 });
    return steps;
  }

  function startRecap(state) {
    recap.id = state.recap.id;
    recap.data = state.recap;
    recap.steps = recapSteps(state.recap);
    recap.index = 0;
    // Die Fotos vorladen, damit der Countdown nicht hängt.
    for (const p of state.recap.top || []) new Image().src = photoUrl(p.id);
    runRecap(state);
  }

  function runRecap(state) {
    clearTimeout(recap.timer);
    const step = recap.steps[recap.index % recap.steps.length];
    const data = recap.data;
    const stats = state.stats || {};
    $("recapIntro").hidden = step.kind !== "intro";
    $("recapRank").hidden = step.kind !== "rank";
    $("recapEnd").hidden = step.kind !== "end";
    const title = state.title || tx("party");
    if (step.kind === "intro") {
      $("introKicker").textContent = tx("recap");
      $("introTitle").textContent = title;
      const started = data.started ? new Date(data.started * 1000) : null;
      $("introDate").textContent = started ? started.toLocaleDateString(LOCALES[lang], { weekday: "long", day: "numeric", month: "long", year: "numeric" }) : "";
      const tiles = [[fmt(stats.photos), tx("photos")], [fmt(stats.guests), tx("guests")], [fmt(stats.reactions), tx("reactions")]];
      if (stats.topGuest) tiles.push([esc(stats.topGuest.name), `${tx("mostPhotos")} (${fmt(stats.topGuest.n)})`]);
      $("introTiles").innerHTML = tiles.map(([a, b]) => `<div><b>${a}</b><span>${esc(b)}</span></div>`).join("");
      // Animationen neu starten
      const node = $("recapIntro"); node.style.animation = "none"; void node.offsetWidth; node.style.animation = "";
      setBackdrop("");
    } else if (step.kind === "rank") {
      const p = step.photo;
      const box = $("rankPhoto");
      box.innerHTML = "";
      const card = makeCard(p, { names: false, caption: false, rot: (step.rank % 2 ? -2 : 2) });
      box.appendChild(card);
      fitCard(card);
      $("rankNo").textContent = `#${step.rank}`;
      $("rankName").textContent = p.name;
      const quotes = { de: ["„", "“"], es: ["«", "»"] }[lang] || ["“", "”"];
      $("rankCap").textContent = p.cap ? `${quotes[0]}${p.cap}${quotes[1]}` : "";
      $("rankChips").innerHTML = chipsHtml(p.r);
      const text = document.querySelector(".rank-text"); text.style.animation = "none"; void text.offsetWidth; text.style.animation = "";
      setBackdrop(photoUrl(p.id, "t"));
      if (step.rank === 1) confetti();
    } else {
      // Das Raster ganz füllen: so viele Spalten, dass die Kacheln etwa quadratisch werden, Fotos notfalls wiederholen.
      const pics = (data.collage || []).slice(0, 24);
      const aspect = innerWidth / innerHeight;
      const cols = Math.max(3, Math.round(Math.sqrt(Math.max(pics.length, 12) * aspect)));
      const rows = Math.max(2, Math.round(cols / aspect));
      const grid = $("collage");
      grid.style.gridTemplateColumns = `repeat(${cols}, 1fr)`;
      grid.style.gridTemplateRows = `repeat(${rows}, 1fr)`;
      const cells = pics.length ? Array.from({ length: cols * rows }, (_, i) => pics[i % pics.length]) : [];
      grid.innerHTML = cells.map((p, i) => `<img src="${photoUrl(p.id, "t")}" alt="" style="animation-delay:${(i * 0.05).toFixed(2)}s">`).join("");
      $("endTitle").textContent = tx("thanks");
      $("endSub").textContent = `${title} · ${tx("endSub", { p: fmt(stats.photos), g: fmt(stats.uploaders || stats.guests) })}`;
      setBackdrop("");
    }
    ready();
    recap.timer = setTimeout(() => {
      recap.index = (recap.index + 1) % recap.steps.length;
      runRecap(lastState || state);
    }, step.seconds * 1000);
  }

  function confetti() {
    const keys = ["party", "heart", "love", "fire", "clap"];
    for (let i = 0; i < 18; i += 1) {
      setTimeout(() => fly({ e: keys[i % keys.length], n: "", here: true }, { phase: "recap" }), i * 110);
    }
  }

  // ------------------------------------------------------------ Takt

  let since = -1;
  let lastState = null;
  let failures = 0;

  function render(state) {
    if (state.lang && state.lang !== lang && !params.get("lang")) lang = state.lang;
    document.body.className = document.body.className.replace(/\btheme-\w+\b/g, "").replace(/\b(polaroid|full)\b/g, "").trim();
    document.body.classList.add(`theme-${state.theme || "party"}`, state.style === "full" ? "full" : "polaroid");
    layoutClasses();
    renderJoin(state);
    const phase = state.phase;
    $("welcome").hidden = phase !== "welcome";
    $("wall").hidden = phase !== "wall";
    $("top").hidden = phase !== "top";
    $("recap").hidden = phase !== "recap";
    if (phase !== "recap" && recap.id !== -1) { clearTimeout(recap.timer); recap.id = -1; }
    if (phase !== "top") topKey = "";
    if (phase !== "wall" && wall.id) { wall.id = ""; $("stage").innerHTML = ""; }
    if (phase === "welcome") {
      $("welcomeKicker").textContent = tx("party");
      $("welcomeTitle").textContent = state.title || tx("join");
      $("welcomeLead").textContent = tx("joinBig");
      setBackdrop("");
      ready();
    } else if (phase === "wall") {
      renderSide(state);
      showPhoto(state);
    } else if (phase === "top") {
      renderTop(state);
      ready();
    } else if (phase === "recap" && state.recap && state.recap.id !== recap.id) {
      startRecap(state);
    }
  }

  function layoutClasses() {
    const portrait = innerHeight > innerWidth;
    document.body.classList.toggle("portrait", portrait);
    document.body.classList.toggle("landscape", !portrait);
  }

  async function tick() {
    try {
      const state = await api(`api/wall?since=${since}`);
      failures = 0;
      showNote("");
      const firstLoad = since < 0;
      since = state.seq;
      lastState = state;
      render(state);
      if (!firstLoad && state.events && state.events.length) launch(state.events, state);
    } catch (error) {
      failures += 1;
      if (failures >= 3) showNote(String(error && error.message) === "login" ? tx("login") : tx("unreachable"));
    }
    setTimeout(tick, document.hidden ? 4000 : 800);
  }

  layout();
  tick();
})();
