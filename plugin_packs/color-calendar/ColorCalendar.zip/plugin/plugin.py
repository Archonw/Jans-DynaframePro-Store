#!/usr/bin/env python3
"""Farbkalender - der Plugin-Teil des Pakets.

Die Szene "color-calendar" zeigt ein Jahr (oder mehrere) als Kalender, in dem
jeder Tag die Farbe seiner Fotos hat. So sieht man Sommer, Urlaube, Winter
und Weihnachten als Farbband. Ab und zu hebt die Szene einen Tag hervor und
zeigt ein paar Fotos dieses Tages.

Dieses Plugin sammelt dafür Datum und Farben der Fotos:
- aus einer Playlist von DynaFrame,
- aus der ganzen Mediendatenbank von DynaFrame (und eingehängten Ordnern),
- von einem Immich-Server (alle Fotos oder ein Album). Immich liefert zu jedem
  Foto einen ThumbHash; daraus kommt die Farbe, ohne ein Bild zu laden.

Die Farben jedes Fotos merkt sich das Plugin (data/colors.json), damit ein
zweiter Durchlauf nur neue Fotos ansehen muss.
"""

import datetime
import json
import os
import random
import re
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests

# Dynaframe legt das gemeinsame SDK einen Ordner über jedes Plugin.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from dynaframe_plugin_base import create_plugin  # noqa: E402

import colors  # noqa: E402
import exif_gps  # noqa: E402
import sources  # noqa: E402
import own_playlist  # noqa: E402
import texts  # noqa: E402

plugin = create_plugin()

PLUGIN_ID = "ColorCalendar"
SCENE_ID = "color-calendar"         # id in scene.dynamic - nie ändern
PLAYLIST_NAMES = {"de": "Farbkalender", "en": "Colour Calendar", "es": "Calendario de colores"}
PLUGIN_DIR = Path(plugin.plugin_dir)
DATA_DIR = PLUGIN_DIR / "data"      # Einstellungen, Farben; bleibt bei Updates

CONNECT_TIMEOUT = 10
KEYS_PER_DAY = 12                   # so viele Fotos je Tag kann die Szene zeigen, über den Tag verteilt
MERGE_PER_DAY = 80                  # aus so vielen Fotos je Tag wird die Tagesfarbe gemischt
MAX_SOURCES = 6
PUBLISH_EVERY = 300                 # beim Ansehen der Fotos alle so viele einen neuen Stand zeigen
PUBLISH_SECONDS = 45

KINDS = ("library", "playlist", "immich_all", "immich_album")
LAYOUTS = ("months", "weeks", "ring", "stripes")
PERIODS = ("last12", "year", "pick", "all")
ORDERS = ("random", "walk", "onthisday")


def now():
    return time.time()


def as_bool(value, default=False):
    if isinstance(value, bool):
        return value
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on", "ja"}


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as exc:
        plugin.log(f"Konnte {path.name} nicht lesen: {exc}", level="warning")
        return default


def write_json(path, payload):
    """Atomar, damit ein Stromausfall keine halbe Datei hinterlässt."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
    with open(temp, "w", encoding="utf-8") as stream:
        json.dump(payload, stream, ensure_ascii=False, separators=(",", ":"))
    temp.replace(path)
    if path.name == "settings.json":
        try:
            os.chmod(path, 0o600)  # enthält den API-Schlüssel
        except OSError:
            pass


def version():
    try:
        return json.loads((PLUGIN_DIR / "manifest.json").read_text(encoding="utf-8"))["Version"]
    except (OSError, ValueError, KeyError):
        return "0"


def log(text, level="info"):
    plugin.log(text, level=level)


# --------------------------------------------------------------------------
# Einstellungen
# --------------------------------------------------------------------------

def default_sources():
    return [{"id": "s1", "kind": "library", "ref": "", "name": ""}]


SCHEMA = {
    "Language":        {"kind": "choice", "default": "en", "choices": texts.LANGUAGES},
    "ServerUrl":       {"kind": "url", "default": ""},
    "ApiKey":          {"kind": "secret", "default": ""},
    "Sources":         {"kind": "sources", "default": None},
    "MinRating":       {"kind": "int", "default": 0, "min": 0, "max": 5},
    "FavoritesOnly":   {"kind": "bool", "default": False},
    "IncludeArchived": {"kind": "bool", "default": False},
    "Layout":          {"kind": "choice", "default": "months", "choices": LAYOUTS},
    "Period":          {"kind": "choice", "default": "last12", "choices": PERIODS},
    "Year":            {"kind": "int", "default": datetime.date.today().year, "min": 1970, "max": 2100},
    "YearsMax":        {"kind": "int", "default": 6, "min": 2, "max": 12},
    "Background":      {"kind": "choice", "default": "dark", "choices": ("dark", "light")},
    "CellShape":       {"kind": "choice", "default": "rounded", "choices": ("rounded", "dots", "square")},
    "FillGaps":        {"kind": "bool", "default": True},
    "Vivid":           {"kind": "bool", "default": True},
    "MonthColours":    {"kind": "bool", "default": True},
    "ShowStats":       {"kind": "bool", "default": True},
    "Title":           {"kind": "text", "default": ""},
    "ShowPhotos":      {"kind": "bool", "default": True},
    "PhotoSeconds":    {"kind": "int", "default": 12, "min": 4, "max": 120},
    "PhotoPause":      {"kind": "int", "default": 8, "min": 2, "max": 3600},
    "DayOrder":        {"kind": "choice", "default": "random", "choices": ORDERS},
    "Folders":         {"kind": "folders", "default": ""},
    "RefreshHours":    {"kind": "int", "default": 6, "min": 1, "max": 168},
    "PlaylistSeconds": {"kind": "int", "default": 300, "min": 10, "max": 86400},
    "MakePlaylist":        {"kind": "bool", "default": False},
}
SECRETS = [name for name, spec in SCHEMA.items() if spec["kind"] == "secret"]
SETTINGS_FILE = DATA_DIR / "settings.json"
_settings_lock = threading.Lock()


def coerce_sources(raw):
    if raw is None:
        return default_sources()
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return default_sources()
    out, ids = [], set()
    for row in raw if isinstance(raw, list) else []:
        if not isinstance(row, dict) or len(out) >= MAX_SOURCES:
            continue
        ident = re.sub(r"[^A-Za-z0-9]", "", str(row.get("id") or ""))[:16] or uuid.uuid4().hex[:8]
        while ident in ids:
            ident = uuid.uuid4().hex[:8]
        ids.add(ident)
        out.append({
            "id": ident,
            "kind": row.get("kind") if row.get("kind") in KINDS else "library",
            # Immich-Alben: mehrere IDs mit Komma (wie bei Growing Up)
            "ref": ",".join(dict.fromkeys(p for p in (re.sub(r"[^A-Za-z0-9_-]", "", part)[:64]
                                                      for part in str(row.get("ref") or "").split(",")) if p))[:2000],
            "name": re.sub(r"\s+", " ", str(row.get("name") or "")).strip()[:60],
        })
    return out


def coerce(name, raw):
    spec = SCHEMA[name]
    kind = spec["kind"]
    if kind == "bool":
        return as_bool(raw, spec["default"])
    if kind == "int":
        return max(spec["min"], min(spec["max"], as_int(raw, spec["default"])))
    if kind == "choice":
        value = str(raw or "").strip()
        return value if value in spec["choices"] else spec["default"]
    if kind == "sources":
        return coerce_sources(raw)
    if kind == "url":
        return sources.normalize_url(raw)[:300]
    if kind == "text":
        return re.sub(r"\s+", " ", str(raw or "")).strip()[:60]
    if kind == "folders":
        lines = [line.strip() for line in str(raw or "").replace(";", "\n").splitlines()]
        return "\n".join(line for line in lines if line.startswith("/"))[:2000]
    return re.sub(r"\s+", "", str(raw or ""))[:400]


def settings():
    stored = read_json(SETTINGS_FILE, {})
    stored = stored if isinstance(stored, dict) else {}
    return {name: coerce(name, stored.get(name, spec["default"])) for name, spec in SCHEMA.items()}


def save_settings(changes):
    with _settings_lock:
        values = settings()
        changed = []
        for name, raw in (changes or {}).items():
            if name not in SCHEMA:
                continue
            value = coerce(name, raw)
            if value != values[name]:
                values[name] = value
                changed.append(name)
        if changed:
            write_json(SETTINGS_FILE, values)
        return changed


def tr(template, **values):
    return texts.t(settings()["Language"], template, **values)


# --------------------------------------------------------------------------
# Die Engine
# --------------------------------------------------------------------------

class EngineError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def engine_base():
    return str(getattr(plugin, "engine_url", "") or "http://localhost:8001").rstrip("/")


def engine_headers():
    headers = {"Content-Type": "application/json", "X-DynaFrame-Plugin": PLUGIN_ID}
    credential = str(getattr(plugin, "plugin_credential", "") or "")
    generation = str(getattr(plugin, "process_generation", "") or "")
    if credential:
        headers["X-Dfr-Plugin-Credential"] = credential
    if generation:
        headers["X-Dfr-Plugin-Generation"] = generation
    return headers


def engine_call(method, path, payload=None):
    try:
        response = requests.request(method, engine_base() + path, json=payload, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 120))
    except requests.RequestException as exc:
        raise EngineError(f"{method} {path}: {exc}") from exc
    if response.status_code >= 400:
        raise EngineError(f"{method} {path} lieferte HTTP {response.status_code}", response.status_code)
    body = response.content or b""
    if response.status_code == 204 or not body.strip():
        return None
    try:
        return response.json()
    except ValueError:
        return None


def engine_image(media_id, path=""):
    """Das Vorschaubild, das die Engine für die Weboberfläche erzeugt (auf Jans Rahmen 512 Pixel)."""
    candidates = []
    if path:
        candidates += [("/media/thumbnail", {"path": path, "purpose": "preview"}),
                       ("/media/thumbnail", {"path": path})]
    if media_id:
        candidates += [(f"/media/thumbnail/{media_id}", {"purpose": "preview"}),
                       (f"/media/thumbnail/{media_id}", None)]
    failures = []
    for route, params in candidates:
        try:
            response = requests.get(f"{engine_base()}{route}", params=params, headers=engine_headers(),
                                    timeout=(CONNECT_TIMEOUT, 60))
        except requests.RequestException as exc:
            failures.append(f"{route}: {exc}")
            continue
        kind = response.headers.get("Content-Type", "").split(";")[0]
        if response.status_code == 200 and kind.startswith("image/"):
            return response.content, kind
        failures.append(f"{route}{'?path' if params and 'path' in params else ''}: HTTP {response.status_code} {kind}")
    raise sources.SourceError(f"Vorschaubild {media_id}: " + "; ".join(failures))


# --------------------------------------------------------------------------
# Farben der Fotos (mit Cache)
# --------------------------------------------------------------------------

COLORS_FILE = DATA_DIR / "colors.json"
SHOWABLE = (".jpg", ".jpeg", ".jpe", ".png", ".webp", ".avif", ".gif")
HEIF = colors.heif_ready()


class ColourCache:
    """key -> [stamp, taken, palette]; palette als "rrggbb:57,rrggbb:30"."""

    def __init__(self):
        self.lock = threading.Lock()
        self.data = None
        self.dirty = 0

    def load(self):
        with self.lock:
            if self.data is None:
                stored = read_json(COLORS_FILE, {})
                self.data = stored if isinstance(stored, dict) else {}

    def get(self, key, stamp):
        self.load()
        row = self.data.get(key)
        if isinstance(row, list) and len(row) == 3 and row[0] == stamp:
            return row
        return None

    def put(self, key, stamp, taken, packed):
        self.load()
        with self.lock:
            self.data[key] = [stamp, taken, packed]
            self.dirty += 1

    def save(self, keep=None):
        self.load()
        with self.lock:
            if keep is not None:
                for key in [k for k in self.data if k not in keep]:
                    del self.data[key]
                    self.dirty += 1
            if self.dirty:
                write_json(COLORS_FILE, self.data)
                self.dirty = 0


colour_cache = ColourCache()


def analyse(job, taken):
    """(taken, palette) für ein Foto. palette [] heißt: keine Farbe zu bekommen."""
    kind = job[0]
    if kind == "hash":
        return taken, colors.palette(colors.thumbhash_pixels(job[1]))
    if kind == "immich":
        data, _kind = immich.photo(job[1], size="thumbnail")
        return taken, colors.palette(colors.image_pixels(data))
    path = job[2] if kind == "engine" else job[1]
    local = bool(path) and os.path.isfile(path)
    if local and not taken:
        taken = sources.clean_taken(exif_gps.read(path)[2])
    if local and (path.lower().endswith(SHOWABLE + (".tif", ".tiff")) or HEIF):
        try:
            return taken, colors.palette(colors.image_pixels(path))
        except Exception:  # noqa: BLE001 - kaputte Datei: dann über die Engine
            pass
    if kind == "engine":
        data, _kind = engine_image(job[1], path)
        return taken, colors.palette(colors.image_pixels(data))
    if local and not path.lower().endswith(SHOWABLE):
        raise sources.SourceError("Format ohne Pillow-Unterstützung")
    raise sources.SourceError("Datei nicht gefunden")


# --------------------------------------------------------------------------
# Die Quellen und das Einlesen
# --------------------------------------------------------------------------

immich = sources.Immich(tr)
dynaframe = sources.DynaFrame(engine_call, EngineError, log)

DAYS_FILE = DATA_DIR / "days.json"
_scan_lock = threading.Lock()
_scan_wake = threading.Event()
_stop_requested = threading.Event()
_scan_stop = threading.Event()
_data = {
    "ver": 0,
    "days": [],           # [date, n, "hex,hex", "w,w", [key_idx...]]
    "keys": [],           # [key, taken, hex, stamp]
    "status": {},         # source id -> {state, total, dated, error, at}
    "busy": False, "at": 0.0, "signature": "",
    "progress": {"done": 0, "todo": 0, "phase": ""},
    "skipped": 0, "photos": 0,
}


def scan_signature(values):
    wanted = [(s["id"], s["kind"], s["ref"]) for s in values["Sources"]]
    return json.dumps([wanted, values["ServerUrl"], values["ApiKey"], values["Folders"], values["MinRating"],
                       values["FavoritesOnly"], values["IncludeArchived"], version()], sort_keys=True)


def collect(source, values, stop):
    kind = source["kind"]
    if kind in ("immich_all", "immich_album"):
        immich.configure(values["ServerUrl"], values["ApiKey"])
        albums = [a for a in source["ref"].split(",") if a] if kind == "immich_album" else None
        if kind == "immich_album" and not albums:
            raise sources.SourceError(tr("Wähle ein Album."))
        return immich.photos(albums, stop, lambda n: _data["progress"].update(phase="list", done=n),
                             values["MinRating"], values["FavoritesOnly"], values["IncludeArchived"])
    if kind == "playlist":
        if not source["ref"]:
            raise sources.SourceError(tr("Wähle eine Playlist."))
        try:
            return dynaframe.playlist(source["ref"], stop)
        except EngineError as exc:
            if exc.status == 404:
                raise sources.SourceError(tr("Die Playlist gibt es nicht mehr.")) from exc
            raise sources.SourceError(tr("DynaFrame antwortet nicht: {exc}", exc=exc)) from exc
    folders = [f for f in values["Folders"].splitlines() if f]
    try:
        return dynaframe.library(folders, stop)
    except EngineError as exc:
        raise sources.SourceError(tr("DynaFrame antwortet nicht: {exc}", exc=exc)) from exc


def aggregate(photos):
    """photos: {key: (taken, palette, stamp)} -> (days, keys)."""
    by_day = {}
    for key, (taken, palette, stamp) in photos.items():
        if len(taken) >= 10 and palette:
            by_day.setdefault(taken[:10], []).append((taken, key, palette, stamp))
    days, keys = [], []
    for day in sorted(by_day):
        rows = sorted(by_day[day])
        mix = rows
        if len(rows) > MERGE_PER_DAY:
            step = (len(rows) - 1) / (MERGE_PER_DAY - 1)
            mix = [rows[round(i * step)] for i in range(MERGE_PER_DAY)]
        merged = colors.merge([r[2] for r in mix])
        if not merged:
            continue
        shown = rows
        if len(rows) > KEYS_PER_DAY:
            step = (len(rows) - 1) / (KEYS_PER_DAY - 1)
            shown = [rows[round(i * step)] for i in range(KEYS_PER_DAY)]
        idx = []
        for taken, key, palette, stamp in shown:
            idx.append(len(keys))
            keys.append([key, taken, palette[0][0], stamp])
        days.append([day, len(rows), ",".join(h for h, _w in merged),
                     ",".join(str(round(w * 100)) for _h, w in merged), idx])
    return days, keys


def publish(photos, values, status, final=False):
    days, keys = aggregate(photos)
    with _scan_lock:
        _data.update(days=days, keys=keys, status=status, ver=_data["ver"] + 1,
                     photos=sum(d[1] for d in days))
        if final:
            _data.update(at=now(), signature=scan_signature(values))
    if final:
        write_json(DAYS_FILE, {"days": days, "keys": keys, "status": status, "at": _data["at"],
                               "signature": _data["signature"], "skipped": _data["skipped"]})


def scan(reason=""):
    """Alle Quellen einlesen, Farben bestimmen. Läuft im Hintergrund."""
    values = settings()
    with _scan_lock:
        if _data["busy"]:
            return
        _data["busy"] = True
        _scan_stop.clear()
    _data["progress"] = {"done": 0, "todo": 0, "phase": "list"}
    log(f"Lese die Fotos ein{' - ' + reason if reason else ''}.")
    started = now()
    rows, status, source_keys = {}, {}, {}
    try:
        for source in values["Sources"]:
            sid = source["id"]
            _data["status"][sid] = dict(_data["status"].get(sid) or {}, state="busy")
            try:
                found, total = collect(source, values, _scan_stop)
                for row in found:
                    rows.setdefault(row[1], row)
                source_keys[sid] = [row[1] for row in found]
                status[sid] = {"state": "ok", "total": total, "dated": sum(1 for r in found if r[0]),
                               "error": "", "at": now()}
            except (sources.SourceError, EngineError) as exc:
                status[sid] = {"state": "error", "total": 0, "dated": 0, "error": str(exc), "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc}", "warning")
            except Exception as exc:  # pragma: no cover - darf den Durchlauf nicht beenden
                status[sid] = {"state": "error", "total": 0, "dated": 0, "error": str(exc)[:200], "at": now()}
                log(f"Quelle {source['name'] or source['kind']}: {exc!r}", "warning")
            _data["status"][sid] = status[sid]
            if _scan_stop.is_set() or _stop_requested.is_set():
                break
        if _scan_stop.is_set() or _stop_requested.is_set():
            log("Einlesen abgebrochen.")
            return

        # Was der Cache schon kennt und was schnell geht (ThumbHash), gleich;
        # Bilder ansehen danach, neueste zuerst, mit Zwischenständen.
        photos, pending, failed = {}, [], 0
        for key, (taken, _key, job, stamp) in rows.items():
            cached = colour_cache.get(key, stamp)
            if cached:
                photos[key] = (cached[1] or taken, colors.unpack(cached[2]), stamp)
                continue
            if job[0] == "hash":
                try:
                    taken2, palette = analyse(job, taken)
                except (ValueError, IndexError):
                    failed += 1
                    continue
                photos[key] = (taken2, palette, stamp)
                colour_cache.put(key, stamp, taken2, colors.pack(palette))
            else:
                pending.append((taken or "0000", key, job, stamp))
        pending.sort(reverse=True)
        publish(photos, values, status)
        if pending:
            log(f"{len(photos)} Fotos fertig, {len(pending)} Fotos werden angesehen.")
        _data["progress"] = {"done": 0, "todo": len(pending), "phase": "colours"}
        last = now()
        errors_logged = 0
        for count, (taken, key, job, stamp) in enumerate(pending, 1):
            if _scan_stop.is_set() or _stop_requested.is_set():
                break
            taken = "" if taken == "0000" else taken
            try:
                taken, palette = analyse(job, taken)
            except Exception as exc:  # noqa: BLE001 - ein Foto darf das Einlesen nicht beenden
                failed += 1
                if errors_logged < 5:
                    errors_logged += 1
                    log(f"Farbe von {key[:120]}: {exc}", "warning")
                palette = []
            colour_cache.put(key, stamp, taken, colors.pack(palette))
            if palette:
                photos[key] = (taken, palette, stamp)
            _data["progress"]["done"] = count
            if count % PUBLISH_EVERY == 0 or now() - last > PUBLISH_SECONDS:
                colour_cache.save()
                publish(photos, values, status)
                last = now()
            if count % 50 == 0:
                time.sleep(0.2)   # die Wiedergabe nicht ausbremsen
        if _scan_stop.is_set() or _stop_requested.is_set():
            colour_cache.save()
            log("Einlesen abgebrochen.")
            return
        _data["skipped"] = sum(1 for p in photos.values() if len(p[0]) < 10) + failed
        # Das Datum vieler Dateien kennt das Plugin erst nach dem Ansehen (Exif)
        for sid, keys in source_keys.items():
            if sid in status:
                status[sid]["dated"] = sum(1 for k in keys if k in photos and len(photos[k][0]) >= 10)
        colour_cache.save(keep=set(rows))
        publish(photos, values, status, final=True)
        log(f"{_data['photos']} Fotos an {len(_data['days'])} Tagen ({now() - started:.0f} s)"
            + (f", {failed} ohne Farbe" if failed else "") + ".")
    finally:
        _data["progress"] = {"done": 0, "todo": 0, "phase": ""}
        with _scan_lock:
            _data["busy"] = False


def load_days():
    stored = read_json(DAYS_FILE, {})
    if isinstance(stored, dict) and isinstance(stored.get("days"), list):
        _data.update(days=stored["days"], keys=stored.get("keys") or [], status=stored.get("status") or {},
                     at=stored.get("at") or 0.0, signature=stored.get("signature") or "", ver=1,
                     skipped=stored.get("skipped") or 0, photos=sum(d[1] for d in stored["days"]))


def scan_loop():
    while not _stop_requested.is_set():
        values = settings()
        due = now() - _data["at"] >= values["RefreshHours"] * 3600
        if due or _data["signature"] != scan_signature(values):
            scan("geplant" if due else "Einstellungen")
        _scan_wake.wait(60)
        _scan_wake.clear()


def rescan_now():
    if _data["busy"]:
        _scan_stop.set()
    _data["at"] = 0.0
    _scan_wake.set()
    return {"success": True, "message": tr("Die Fotos werden neu eingelesen.")}


# --------------------------------------------------------------------------
# Playlist für die Szene
# --------------------------------------------------------------------------

def find_scene():
    try:
        row = engine_call("GET", f"/dynamic-scenes/{SCENE_ID}")
    except EngineError:
        row = None
    if isinstance(row, dict) and row.get("id") is not None:
        return row
    return None


OWN = own_playlist.OwnPlaylist(
    state_file=DATA_DIR / "own_playlist.json",
    names=PLAYLIST_NAMES.values(),
    name=lambda: PLAYLIST_NAMES.get(settings()["Language"], PLAYLIST_NAMES["en"]),
    description=lambda: tr("Das Jahr in den Farben deiner Fotos."),
    scene_id=lambda: (find_scene() or {}).get("id"),
    seconds=lambda: settings()["PlaylistSeconds"],
    wanted=lambda: settings()["MakePlaylist"],
    set_wanted=lambda on: save_settings({"MakePlaylist": on}),
    engine_call=engine_call,
    language=lambda: settings()["Language"],
    log=lambda text, level="info": log(text, level),
)


def make_playlist():
    """Aktion „Playlist anlegen“ auf der Plugins-Seite: stellt „Eine Playlist dafür“ auf Ja."""
    return OWN.create_now()


# --------------------------------------------------------------------------
# Was die Szene bekommt
# --------------------------------------------------------------------------

SCENE_SETTINGS = ("Language", "Layout", "Period", "Year", "YearsMax", "Background", "CellShape", "FillGaps",
                  "Vivid", "MonthColours", "ShowStats", "Title", "ShowPhotos", "PhotoSeconds", "PhotoPause")


def scene_payload(query):
    values = settings()
    have = as_int((query.get("v") or ["-1"])[0], -1)
    progress = _data["progress"]
    payload = {
        "success": True,
        "ver": _data["ver"],
        "settings": {k: values[k] for k in SCENE_SETTINGS},
        "today": datetime.date.today().isoformat(),
        "busy": _data["busy"],
        "progress": {"done": progress.get("done", 0), "todo": progress.get("todo", 0)},
    }
    if have != _data["ver"]:
        # Ohne die Fotos je Tag: die holt die Szene erst, wenn sie den Tag zeigt.
        payload["days"] = [d[:4] for d in _data["days"]]
    return payload


_order = {"bag": [], "bagRange": "", "walk": "", "day": "", "today": [], "pos": 0}
ORDER_FILE = DATA_DIR / "order.json"


def _days_in(lo, hi):
    return [d[0] for d in _data["days"] if lo <= d[0] <= hi]


def next_day(query):
    """Welchen Tag die Szene als Nächstes hervorhebt (nur Tage im gezeigten Zeitraum)."""
    lo = (query.get("from") or ["0000-00-00"])[0][:10]
    hi = (query.get("to") or ["9999-99-99"])[0][:10]
    days = _days_in(lo, hi)
    if not days:
        return {"success": False}
    mode = settings()["DayOrder"]
    pick, ago = None, 0
    if mode == "walk":
        if not _order["walk"]:
            stored = read_json(ORDER_FILE, {})
            _order["walk"] = str(stored.get("walk") or "") if isinstance(stored, dict) else ""
        pick = next((d for d in days if d > _order["walk"]), days[0])
        _order["walk"] = pick
        write_json(ORDER_FILE, {"walk": pick})
    elif mode == "onthisday":
        today = datetime.date.today()
        key = f"{today.isoformat()}|{lo}|{hi}"
        if _order["day"] != key:
            near = []
            for d in days:
                try:
                    when = datetime.date(today.year, int(d[5:7]), int(d[8:10]))
                except ValueError:
                    continue
                diff = abs((when - today).days)
                if min(diff, 365 - diff) <= 3 and d < today.isoformat():
                    near.append(d)
            _order.update(day=key, today=sorted(near), pos=0)
        if _order["today"]:
            pick = _order["today"][_order["pos"] % len(_order["today"])]
            _order["pos"] += 1
            ago = today.year - int(pick[:4])
    if pick is None:
        span = f"{lo}|{hi}|{_data['ver']}"
        if _order["bagRange"] != span or not _order["bag"]:
            bag = list(days)
            random.shuffle(bag)
            _order.update(bag=bag, bagRange=span)
        pick = _order["bag"].pop()
    return {"success": True, "d": pick, "ago": ago}


def day_detail(query):
    day = (query.get("d") or [""])[0][:10]
    ver = as_int((query.get("v") or ["-1"])[0], -1)
    if ver != _data["ver"]:
        return {"success": False, "stale": True}
    row = next((d for d in _data["days"] if d[0] == day), None)
    if row is None:
        return {"success": False}
    keys = _data["keys"]
    photos = [{"k": k, "t": keys[k][1], "c": keys[k][2]} for k in row[4] if 0 <= k < len(keys)]
    return {"success": True, "d": day, "n": row[1], "colours": row[2].split(","),
            "weights": [as_int(w) for w in row[3].split(",")], "photos": photos}


def key_row(query):
    idx = as_int((query.get("k") or ["-1"])[0], -1)
    ver = as_int((query.get("v") or ["-1"])[0], -1)
    keys = _data["keys"]
    if ver != _data["ver"] or not 0 <= idx < len(keys):
        return None
    return keys[idx]


# ------------------------------------------------------------ Fotos für die Szene

PHOTO_MAX = 25 * 1024 * 1024


def webdav_dirs():
    seen = []
    for home in (Path.home(), Path("/home/pi")):
        folder = home / ".local/share/dfr/webdav-cache"
        if folder not in seen and folder.is_dir():
            seen.append(folder)
    return seen


def webdav_cached(path, size):
    """Fotos aus WebDAV (/webdav-media/<Quelle>/...) liefert die Engine nur als
    512-Pixel-Vorschau. Das Original legt DynaFrame aber in webdav-cache ab,
    als <Quelle>-<Hash>.<Endung>. Den Hash kennen wir nicht, also: gleiche
    Quelle, gleiche Endung, gleiche Dateigröße (wie bei Halloween Scare)."""
    if not path.startswith("/webdav-media/"):
        return None
    size = as_int(size, 0)
    if size <= 0 or size > PHOTO_MAX:
        return None
    parts = path.split("/")
    source = parts[2] if len(parts) > 2 else ""
    suffix = Path(path).suffix.lower()
    best = None
    for folder in webdav_dirs():
        try:
            entries = list(os.scandir(folder))
        except OSError:
            continue
        for entry in entries:
            name = entry.name
            if source and not name.startswith(source + "-"):
                continue
            if suffix and not name.lower().endswith(suffix):
                continue
            try:
                info = entry.stat()
            except OSError:
                continue
            if info.st_size == size and (best is None or info.st_mtime > best[0]):
                best = (info.st_mtime, Path(entry.path))
    return best[1] if best else None


def file_bytes(path):
    suffix = Path(path).suffix.lower()
    kind = {".png": "image/png", ".webp": "image/webp", ".avif": "image/avif", ".gif": "image/gif"}.get(
        suffix, "image/jpeg")
    with open(path, "rb") as handle:
        return handle.read(PHOTO_MAX), kind


def photo_bytes(query):
    row = key_row(query)
    if row is None:
        return None
    key, stamp = row[0], row[3] if len(row) > 3 else ""
    try:
        if key.startswith("i:"):
            values = settings()
            immich.configure(values["ServerUrl"], values["ApiKey"])
            return immich.photo(key[2:])
        path = key.partition("|")[2] if key.startswith("d:") else key[2:]
        if path and path.lower().endswith(SHOWABLE) and os.path.isfile(path):
            return file_bytes(path)
        if path:
            cached = webdav_cached(path, str(stamp).split(":")[0])
            if cached:
                return file_bytes(str(cached))
        if key.startswith("d:"):
            return engine_image(key[2:].partition("|")[0], path)
    except (sources.SourceError, OSError) as exc:
        log(f"Foto für die Szene: {exc}", "warning")
    return None


# --------------------------------------------------------------------------
# Die Plugin-Seite
# --------------------------------------------------------------------------

DFR_DATA_DIR = Path(os.environ.get("DFR_DATA_DIR", Path.home() / ".local" / "share" / "dfr"))
THEME_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


def theme_id():
    stored = read_json(DFR_DATA_DIR / "webui_theme.json", {})
    if not isinstance(stored, dict):
        return ""
    value = next((str(v) for k, v in stored.items() if k.lower() == "themeid" and v), "")
    return value if THEME_ID.match(value) else ""


def state_payload():
    values = settings()
    public = dict(values)
    for name in SECRETS:
        public[name] = ""
    status = {}
    for source in values["Sources"]:
        row = dict(_data["status"].get(source["id"]) or {})
        if _data["busy"] and not row:
            row = {"state": "wait"}
        status[source["id"]] = row
    days = _data["days"]
    return {
        "ownPlaylist": OWN.text(),
        "success": True,
        "version": version(),
        "settings": public,
        "secretsSet": {name: bool(values[name]) for name in SECRETS},
        "status": status,
        "busy": _data["busy"],
        "progress": _data["progress"],
        "at": _data["at"],
        "days": len(days),
        "photos": _data["photos"],
        "first": days[0][0] if days else "",
        "last": days[-1][0] if days else "",
        "years": sorted({d[0][:4] for d in days}, reverse=True),
        "skipped": _data["skipped"],
        "heif": HEIF,
        "libraryWay": dynaframe.library_way,
        "theme": {"id": theme_id()},
    }


def test_immich():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        info = immich.test()
    except sources.SourceError as exc:
        return {"success": True, "ok": False, "message": str(exc)}
    return {"success": True, "ok": True,
            "message": tr("Verbunden als {user} (Immich {version}).", user=info["user"] or "?",
                          version=info["version"] or "?")}


def list_albums():
    values = settings()
    immich.configure(values["ServerUrl"], values["ApiKey"])
    try:
        return {"success": True, "albums": immich.albums()}
    except sources.SourceError as exc:
        return {"success": False, "error": str(exc)}


def list_playlists():
    try:
        rows = [p for p in dynaframe.playlists() if p["name"] not in PLAYLIST_NAMES.values()]
        return {"success": True, "playlists": sorted(rows, key=lambda p: str(p["name"]).lower())}
    except EngineError as exc:
        return {"success": False, "error": tr("DynaFrame antwortet nicht: {exc}", exc=exc)}


def page_html():
    html = (PLUGIN_DIR / "studio" / "index.html").read_text(encoding="utf-8")
    identifier = theme_id()
    css = f'@import url("/themes/{identifier}/theme.css") layer(frame-theme);' if identifier else ""
    if identifier:
        html = html.replace("<html", f'<html data-theme="{identifier}"', 1)
    return html.replace('<link rel="stylesheet"', f'<style id="frameTheme">{css}</style>\n  <link rel="stylesheet"', 1)


STUDIO_FILES = {
    "/studio.css": ("studio/studio.css", "text/css; charset=utf-8"),
    "/studio.js": ("studio/studio.js", "application/javascript; charset=utf-8"),
}


class StudioHandler(BaseHTTPRequestHandler):
    # HTTP/1.1, weil der Proxy der Weboberfläche Verbindungen offen hält.
    protocol_version = "HTTP/1.1"

    def log_message(self, *_args):
        """Das Plugin-Log ist das Log."""

    def _send(self, body, content_type, status=200, cache="no-store", cors=False):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        if cors:
            # Die Szene kommt vom Port der Engine, diese Seite über den Proxy.
            self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, payload, status=200, cors=False):
        self._send(json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8"),
                   "application/json; charset=utf-8", status, cors=cors)

    def _drain_body(self):
        length = as_int(self.headers.get("Content-Length"), 0)
        self._raw_body = self.rfile.read(length) if length > 0 else b""

    def _body(self):
        raw = getattr(self, "_raw_body", b"")
        if not raw:
            return {}
        try:
            body = json.loads(raw.decode("utf-8")) or {}
        except (ValueError, UnicodeDecodeError):
            return {}
        return body if isinstance(body, dict) else {}

    def do_OPTIONS(self):
        self._drain_body()
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path in ("/", "/index.html"):
                self._send(page_html().encode("utf-8"), "text/html; charset=utf-8")
                return
            asset = STUDIO_FILES.get(path)
            if asset:
                self._send((PLUGIN_DIR / asset[0]).read_bytes(), asset[1])
                return
            if path == "/api/state":
                self._json(state_payload())
                return
            if path == "/api/scene":
                self._json(scene_payload(query), cors=True)
                return
            if path == "/api/next":
                self._json(next_day(query), cors=True)
                return
            if path == "/api/day":
                self._json(day_detail(query), cors=True)
                return
            if path == "/api/report":
                text = re.sub(r"[\x00-\x1f]", " ", (query.get("m") or [""])[0])[:200]
                if text:
                    log(f"Szene: {text}", "warning")
                self._json({"success": True}, cors=True)
                return
            if path == "/api/photo":
                found = photo_bytes(query)
                if found is None:
                    self._json({"success": False}, 404, cors=True)
                else:
                    self._send(found[0], found[1], cache="private, max-age=3600", cors=True)
                return
            if path == "/api/albums":
                self._json(list_albums())
                return
            if path == "/api/playlists":
                self._json(list_playlists())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except OSError as exc:
            self._json({"success": False, "error": f"Konnte eine Plugin-Datei nicht lesen: {exc}"}, 500)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)

    def do_POST(self):
        path = unquote(urlparse(self.path).path)
        self._drain_body()
        try:
            if path == "/api/settings":
                body = self._body()
                for name in SECRETS:
                    # Ein leeres Feld heißt: das alte behalten. Löschen geht mit "-".
                    if name in body and not str(body[name] or "").strip():
                        body.pop(name)
                    elif name in body and str(body[name]).strip() == "-":
                        body[name] = ""
                changed = save_settings(body)
                if "MakePlaylist" in changed:
                    OWN.changed()
                if set(changed) & {"Sources", "MinRating", "FavoritesOnly", "IncludeArchived"}:
                    # Strengere Filter sollen sofort greifen: alte Tage nicht weiter zeigen
                    with _scan_lock:
                        _data.update(days=[], keys=[], photos=0, ver=_data["ver"] + 1)
                if changed and scan_signature(settings()) != _data["signature"]:
                    rescan_now()
                self._json({"success": True, "changed": changed})
                return
            if path == "/api/refresh":
                self._json(rescan_now())
                return
            if path == "/api/test":
                self._json(test_immich())
                return
            if path == "/api/playlist":
                self._json(make_playlist())
                return
            self._json({"success": False, "error": "Nicht gefunden"}, 404)
        except Exception as exc:  # pragma: no cover
            self._json({"success": False, "error": str(exc)}, 500)


studio_server = None


def start_studio():
    """Die Seite auf Loopback; dem Host den tatsächlich gebundenen Port sagen."""
    global studio_server
    studio_server = ThreadingHTTPServer(("127.0.0.1", 0), StudioHandler)
    port = studio_server.server_address[1]
    threading.Thread(target=studio_server.serve_forever, name=f"{PLUGIN_ID}-studio", daemon=True).start()
    url = f"http://127.0.0.1:{port}/"
    plugin.register_advanced_settings_page(url)
    log(f"Plugin-Seite unter {url}")
    return url


# --------------------------------------------------------------------------
# Start
# --------------------------------------------------------------------------

def main():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    log(f"Starte {PLUGIN_ID} {version()}" + ("" if HEIF else " (ohne HEIC-Unterstützung, HEIC über die Engine)"))

    # Alles, was der Host aufrufen kann, muss vor ready() da sein.
    plugin.on_action("refresh", lambda _context=None: rescan_now())
    plugin.on_action("playlist", lambda _context=None: make_playlist())

    load_days()
    start_studio()
    plugin.connect_sse()
    plugin.ready()

    try:
        os.nice(5)   # das Einlesen soll die Wiedergabe nicht stören
    except OSError:
        pass
    threading.Thread(target=scan_loop, name=f"{PLUGIN_ID}-scan", daemon=True).start()
    try:
        while not _stop_requested.is_set():
            _stop_requested.wait(3600)
    except KeyboardInterrupt:
        pass
    finally:
        shutdown()


def shutdown():
    _stop_requested.set()
    _scan_stop.set()
    _scan_wake.set()
    try:
        colour_cache.save()
    except Exception:
        pass
    try:
        plugin.unregister_advanced_settings_page()
    except Exception:
        pass
    if studio_server is not None:
        try:
            studio_server.shutdown()
            studio_server.server_close()
        except Exception:
            pass
    log(f"{PLUGIN_ID} gestoppt.")


if __name__ == "__main__":
    main()
