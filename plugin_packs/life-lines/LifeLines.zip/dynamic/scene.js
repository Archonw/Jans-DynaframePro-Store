/* Life Lines - die Szene: dein Leben als U-Bahn-Plan.
 *
 * Das Plugin LifeLines liefert Haltestellen (Reisen, Feste, Umzüge) und
 * Linien (Personen oder Orte). Die Szene zeichnet daraus einen Linienplan:
 * die Zeit läuft von links nach rechts (hochkant von oben nach unten), jede
 * Linie hat ihre Spur, und an einer Haltestelle schwenken die Linien, die
 * dort halten, zur Stammlinie ("Mein Leben") ein. Wo mehrere Linien halten,
 * steht ein Umsteigebahnhof.
 *
 * Ein Zug fährt die Stammlinie entlang, die Kamera folgt ihm. An jeder
 * Haltestelle fliegen ein paar Fotos heraus, darunter Name, Datum und wer
 * dabei war. Nach einigen Haltestellen zoomt die Kamera auf den ganzen Plan.
 *
 * Test: ?plugin=<url>, ?lang=, ?theme=dark, ?demo=1 (Beispieldaten ohne Plugin).
 */
(function () {
  "use strict";

  const PLUGIN_ID = "LifeLines";
  const params = new URLSearchParams(location.search);
  const advanced = `/Plugins/Advanced/${PLUGIN_ID}/`;
  const pluginBases = params.get("plugin") ? [params.get("plugin")] : [...new Set([
    `${location.protocol}//${location.hostname}:8003${advanced}`,
    `${location.protocol}//${location.hostname}${advanced}`,
    `${location.origin}${advanced}`,
  ])];
  // Kommt die Szene über Port 80/443 (RemoteFrame, Web Login), zuerst denselben Ursprung fragen.
  if (!params.get("plugin") && (location.port === "" || location.port === "80" || location.port === "443")) {
    pluginBases.sort((a, b) => (b.startsWith(location.origin) ? 1 : 0) - (a.startsWith(location.origin) ? 1 : 0));
  }
  let baseIndex = 0;
  const base = () => pluginBases[baseIndex];
  let useFiles = false;             // Remote Frame ohne Anmeldung: Daten aus data/ im Szenenordner

  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const TEXT = {
    de: {
      trunk: "Mein Leben", home: "Zuhause", title: "Dein Leben als Linienplan",
      kicker: "Linienplan {from}–{to}", facts: "{stations} Haltestellen · {photos} Fotos · {years} Jahre",
      trip: "Reise", event: "Großer Tag", move: "Umzug", moveTo: "Umzug nach {city}", xmas: "Weihnachten",
      nye: "Silvester", easter: "Ostern", birthday: "Geburtstag", birthdayOf: "{name}s Geburtstag",
      photos: "{n} Fotos", photos1: "1 Foto", days: "{n} Tage", day1: "1 Tag", km: "{n} km weit weg",
      lineStops: "{n} Halte", busy: "Der Plan wird gezeichnet …", busyText: "Die Fotos werden eingelesen. Das dauert beim ersten Mal ein paar Minuten.",
      emptyTitle: "Noch keine Haltestellen", emptyText: "Es wurden keine Reisen und keine Tage mit vielen Fotos gefunden. Auf der Plugin-Seite lässt sich einstellen, ab wann eine Reise oder ein Fest zählt.",
      offline: "Life Lines antwortet nicht", offlineText: "Das Plugin ist gerade nicht erreichbar. Die Szene versucht es weiter.",
      noSource: "Wähle auf der Plugin-Seite, woher die Fotos kommen.",
    },
    en: {
      trunk: "My life", home: "Home", title: "Your life as a metro map",
      kicker: "Network map {from}–{to}", facts: "{stations} stations · {photos} photos · {years} years",
      trip: "Trip", event: "Big day", move: "Move", moveTo: "Moved to {city}", xmas: "Christmas",
      nye: "New Year's Eve", easter: "Easter", birthday: "Birthday", birthdayOf: "{name}'s birthday",
      photos: "{n} photos", photos1: "1 photo", days: "{n} days", day1: "1 day", km: "{n} km from home",
      lineStops: "{n} stops", busy: "Drawing the map …", busyText: "Reading the photos. The first time this takes a few minutes.",
      emptyTitle: "No stations yet", emptyText: "No trips and no days with many photos were found. On the plugin page you can set when a trip or a celebration counts.",
      offline: "Life Lines is not responding", offlineText: "The plugin cannot be reached right now. The scene keeps trying.",
      noSource: "Pick on the plugin page where the photos come from.",
    },
    es: {
      trunk: "Mi vida", home: "Casa", title: "Tu vida como plano de metro",
      kicker: "Plano de la red {from}–{to}", facts: "{stations} estaciones · {photos} fotos · {years} años",
      trip: "Viaje", event: "Gran día", move: "Mudanza", moveTo: "Mudanza a {city}", xmas: "Navidad",
      nye: "Nochevieja", easter: "Pascua", birthday: "Cumpleaños", birthdayOf: "Cumpleaños de {name}",
      photos: "{n} fotos", photos1: "1 foto", days: "{n} días", day1: "1 día", km: "a {n} km de casa",
      lineStops: "{n} paradas", busy: "Dibujando el plano …", busyText: "Leyendo las fotos. La primera vez tarda unos minutos.",
      emptyTitle: "Todavía no hay estaciones", emptyText: "No se han encontrado viajes ni días con muchas fotos. En la página del plugin puedes ajustar cuándo cuenta un viaje o una fiesta.",
      offline: "Life Lines no responde", offlineText: "El plugin no está disponible ahora mismo. La escena lo sigue intentando.",
      noSource: "Elige en la página del plugin de dónde vienen las fotos.",
    },
  };

  const el = (id) => document.getElementById(id);
  const canvas = el("map");
  const ctx = canvas.getContext("2d");

  const S = {
    lang: params.get("lang") || "en",
    s: { TourOrder: "chrono", StopSeconds: 9, PhotosPerStop: 3, StopsPerRound: 10, Overview: true, Speed: "normal",
      Theme: params.get("theme") || "light", ShowPeople: true, TrunkName: "" },
    ver: -1, plan: null, busy: false, sources: 1, pos: "", today: "", failures: 0, loaded: false, files: {},
  };
  const tx = (key, values = {}) => String((TEXT[S.lang] || TEXT.en)[key] ?? TEXT.en[key] ?? key)
    .replace(/\{(\w+)\}/g, (_, k) => values[k] ?? "");
  const locale = () => LOCALES[S.lang] || "en-GB";

  let readySent = false;
  function ready() {
    if (readySent) return;
    readySent = true;
    try { window.DynaFrameScene?.ready?.(); } catch (_) { /* Vorschau im Browser */ }
  }
  setTimeout(ready, 8000);

  function report(text) {
    try { fetch(`${base()}api/report?m=${encodeURIComponent(String(text).slice(0, 200))}`, { cache: "no-store" }).catch(() => {}); } catch (_) { /* egal */ }
  }

  // ------------------------------------------------------------------ Bildschirm

  let W = 0, H = 0, DPR = 1, portrait = false;
  function resize() {
    DPR = Math.min(2, window.devicePixelRatio || 1);
    W = window.innerWidth; H = window.innerHeight;
    canvas.width = Math.round(W * DPR); canvas.height = Math.round(H * DPR);
    const was = portrait;
    portrait = H > W * 1.05;
    if (S.plan && was !== portrait) { layout(); }
  }
  window.addEventListener("resize", resize);

  function theme() {
    const dark = S.s.Theme === "dark";
    document.body.classList.toggle("dark", dark);
    return dark
      ? { bg: "#12151b", band: "rgba(255,255,255,0.035)", ink: "#eef0f4", soft: "rgba(238,240,244,0.55)", year: "rgba(255,255,255,0.10)",
          halo: "#12151b", stationFill: "#ffffff", stationEdge: "#0c0e12", trunk: "#cfd4dc", veil: "rgba(10,12,16,0.62)" }
      : { bg: "#f3f0e8", band: "rgba(40,30,10,0.035)", ink: "#1d2129", soft: "rgba(29,33,41,0.55)", year: "rgba(29,33,41,0.10)",
          halo: "#f3f0e8", stationFill: "#ffffff", stationEdge: "#1d2129", trunk: "#3c4350", veil: "rgba(243,240,232,0.70)" };
  }
  let T = theme();

  // ------------------------------------------------------------------ Datum und Texte

  const dateOf = (iso) => new Date(`${iso}T12:00:00`);
  function fmtDay(iso, withYear = true) {
    return dateOf(iso).toLocaleDateString(locale(), withYear ? { day: "numeric", month: "long", year: "numeric" } : { day: "numeric", month: "long" });
  }
  function fmtRange(a, b) {
    if (!b || a === b) return fmtDay(a);
    try {
      const f = new Intl.DateTimeFormat(locale(), { day: "numeric", month: "long", year: "numeric" });
      if (f.formatRange) return f.formatRange(dateOf(a), dateOf(b));
    } catch (_) { /* alte Browser */ }
    return `${fmtDay(a)} – ${fmtDay(b)}`;
  }
  function fmtShort(a, b) {
    const opts = { month: "short", year: "numeric" };
    const one = dateOf(a).toLocaleDateString(locale(), opts);
    if (!b || a.slice(0, 7) === b.slice(0, 7)) return one;
    try {
      const f = new Intl.DateTimeFormat(locale(), opts);
      if (f.formatRange) return f.formatRange(dateOf(a), dateOf(b));
    } catch (_) { /* egal */ }
    return one;
  }
  const listOf = (names) => {
    try { return new Intl.ListFormat(locale(), { style: "long", type: "conjunction" }).format(names); } catch (_) { return names.join(", "); }
  };
  const days = (a, b) => Math.round((dateOf(b) - dateOf(a)) / 86400000) + 1;

  function lineName(line) {
    if (line.kind === "trunk") return S.s.TrunkName || line.name || tx("trunk");
    if (line.kind === "home") return tx("home");
    return line.name || "?";
  }
  function lineColor(line) { return line.kind === "trunk" ? T.trunk : line.color; }

  function stationTitle(st) {
    if (st.kind === "move") return tx("moveTo", { city: st.name || st.city || "?" });
    if (st.kind === "event") {
      if (st.birthday) return tx("birthdayOf", { name: st.birthday });
      if (st.holiday) return tx(st.holiday);
      return st.name || fmtDay(st.a);
    }
    return st.name || st.city || fmtShort(st.a, st.b);
  }
  function stationLabel(st) {
    if (st.kind === "move") return st.name || st.city || tx("move");
    if (st.kind === "event") {
      if (st.birthday) return tx("birthdayOf", { name: st.birthday });
      if (st.holiday) return tx(st.holiday);
      return st.name || fmtDay(st.a);
    }
    return st.name || st.city || "?";
  }
  function stationKicker(st) {
    if (st.kind === "trip") return tx("trip") + (st.country && st.country !== S.plan.homeCountry ? ` · ${st.country}` : "");
    if (st.kind === "move") return tx("move");
    return (st.city ? `${tx("event")} · ${st.city}` : tx("event"));
  }

  // ------------------------------------------------------------------ Der Plan als Bild

  const LANE = 74, GAP = 14, LW = 9, TRUNK_LW = 11, RUN = 26, CLEAR = 24, CORNER = 16;
  let G = null;            // Geometrie: Haltestellen, Pfade, Ausdehnung

  function laneOrder(lines) {
    // Stammlinie in der Mitte, die anderen abwechselnd darunter/darüber (häufigste innen)
    const order = lines.map((l, i) => i).filter((i) => i > 0).sort((a, b) => lines[b].n - lines[a].n);
    const lane = { 0: 0 };
    order.forEach((idx, k) => { lane[idx] = (k % 2 === 0 ? 1 : -1) * (Math.floor(k / 2) + 1); });
    return lane;
  }

  function layout() {
    const plan = S.plan;
    const stations = plan.stations;
    const lines = plan.lines;
    const lane = laneOrder(lines);
    const n = stations.length;
    // Wo halten die Linien? (Stammlinie überall)
    const first = lines.map(() => Infinity), last = lines.map(() => -Infinity);
    stations.forEach((st, i) => {
      for (const l of [0, ...st.l]) { first[l] = Math.min(first[l], i); last[l] = Math.max(last[l], i); }
    });
    // Quer zur Zeit: Bündel an jeder Haltestelle
    const pos = [];        // pos[i][line] = v
    const bundle = [];
    stations.forEach((st, i) => {
      const members = [0, ...st.l].sort((a, b) => lane[a] - lane[b]);
      const centre = members.reduce((sum, l) => sum + lane[l], 0) / members.length * LANE;
      const at = {};
      members.forEach((l, k) => { at[l] = centre + (k - (members.length - 1) / 2) * GAP; });
      const lo = centre - (members.length - 1) / 2 * GAP, hi = centre + (members.length - 1) / 2 * GAP;
      // Linien, die hier nicht halten, aber in diesem Abschnitt fahren: um den Bahnhof herum
      const passing = lines.map((_, l) => l).filter((l) => !(l in at) && first[l] <= i && last[l] >= i);
      const above = passing.filter((l) => lane[l] * LANE < centre || (lane[l] * LANE === centre && lane[l] < 0))
        .sort((a, b) => lane[b] - lane[a]);
      const below = passing.filter((l) => !above.includes(l)).sort((a, b) => lane[a] - lane[b]);
      let edge = hi + CLEAR - GAP * 1.3;
      for (const l of below) { const v = Math.max(lane[l] * LANE, edge + GAP * 1.3); at[l] = v; edge = v; }
      edge = lo - CLEAR + GAP * 1.3;
      for (const l of above) { const v = Math.min(lane[l] * LANE, edge - GAP * 1.3); at[l] = v; edge = v; }
      pos.push(at);
      bundle.push({ lo, hi, centre, members });
    });
    // Entlang der Zeit: Abstand wächst mit der Pause dazwischen, Platz für die Schrägen
    const minStep = portrait ? 132 : 230;
    const u = [0];
    for (let i = 1; i < n; i++) {
      const gap = Math.max(0, days(stations[i - 1].b, stations[i].a) - 1);
      let step = minStep + 70 * Math.log2(1 + gap / 45);
      for (const l in pos[i]) {
        if (l in pos[i - 1]) step = Math.max(step, Math.abs(pos[i][l] - pos[i - 1][l]) + 2 * RUN + 30);
      }
      u.push(u[i - 1] + step);
    }
    // Pfade
    const paths = lines.map((line, l) => {
      if (first[l] === Infinity) return null;
      const pts = [];
      for (let i = first[l]; i <= last[l]; i++) {
        const v = pos[i][l];
        pts.push([u[i] - RUN, v], [u[i] + RUN, v]);
      }
      const full = [pts[0]];
      for (let k = 1; k < pts.length; k++) {
        const [u1, v1] = full[full.length - 1], [u2, v2] = pts[k];
        const dv = v2 - v1, du = u2 - u1;
        if (Math.abs(dv) > 0.5 && du > Math.abs(dv)) {
          const mid = (u1 + u2) / 2;
          full.push([mid - Math.abs(dv) / 2, v1], [mid + Math.abs(dv) / 2, v2]);
        }
        full.push([u2, v2]);
      }
      // Gerade Stücke zusammenlegen
      const clean = [full[0]];
      for (let k = 1; k < full.length; k++) {
        const p = full[k];
        if (clean.length >= 2) {
          const a = clean[clean.length - 2], b = clean[clean.length - 1];
          const cross = (b[0] - a[0]) * (p[1] - b[1]) - (b[1] - a[1]) * (p[0] - b[0]);
          if (Math.abs(cross) < 0.01) { clean[clean.length - 1] = p; continue; }
        }
        if (Math.abs(p[0] - clean[clean.length - 1][0]) > 0.01 || Math.abs(p[1] - clean[clean.length - 1][1]) > 0.01) clean.push(p);
      }
      return { l, pts: clean, path: null };
    });
    // Strecke der Stammlinie (für den Zug)
    const trunk = paths[0].pts;
    const cum = [0];
    for (let k = 1; k < trunk.length; k++) cum.push(cum[k - 1] + Math.hypot(trunk[k][0] - trunk[k - 1][0], trunk[k][1] - trunk[k - 1][1]));
    const stationS = stations.map((_, i) => {
      // Punkt (u[i], pos[i][0]) liegt auf einem waagrechten Stück
      for (let k = 1; k < trunk.length; k++) {
        const a = trunk[k - 1], b = trunk[k];
        if (Math.abs(a[1] - pos[i][0]) < 0.01 && Math.abs(b[1] - pos[i][0]) < 0.01 && a[0] <= u[i] + 0.01 && b[0] >= u[i] - 0.01) {
          return cum[k - 1] + (u[i] - a[0]);
        }
      }
      return cum[cum.length - 1] * i / Math.max(1, n - 1);
    });
    // Jahre: 1. Januar als Position auf der Zeitachse (zwischen den Haltestellen gleichmäßig)
    const times = stations.map((st) => (dateOf(st.a).getTime() + dateOf(st.b).getTime()) / 2);
    const uAt = (t) => {
      if (n === 1) return u[0] + (t - times[0]) / 86400000 * 0.6;
      if (t <= times[0]) return u[0] - Math.min(400, (times[0] - t) / 86400000 * 0.6);
      if (t >= times[n - 1]) return u[n - 1] + Math.min(400, (t - times[n - 1]) / 86400000 * 0.6);
      let k = 1;
      while (times[k] < t) k++;
      return u[k - 1] + (u[k] - u[k - 1]) * (t - times[k - 1]) / Math.max(1, times[k] - times[k - 1]);
    };
    const y0 = Number(stations[0].a.slice(0, 4)), y1 = Number(stations[n - 1].b.slice(0, 4));
    const years = [];
    for (let y = y0; y <= y1 + 1; y++) years.push({ y, u: uAt(new Date(`${y}-01-01T00:00:00`).getTime()) });
    years[0].u = Math.min(years[0].u, u[0] - 220);
    years[years.length - 1].u = Math.max(years[years.length - 1].u, u[n - 1] + 220);
    let vmin = Infinity, vmax = -Infinity;
    for (const p of paths) if (p) for (const [, v] of p.pts) { vmin = Math.min(vmin, v); vmax = Math.max(vmax, v); }
    vmin -= 120; vmax += 120;
    G = { u, pos, bundle, paths, trunk, cum, stationS, years, vmin, vmax, lane, first, last,
      umin: years[0].u, umax: years[years.length - 1].u };
    for (const p of paths) if (p) p.path = roundedPath(p.pts);
  }

  // Welt (u = Zeit, v = quer) -> Zeichenfläche (x, y)
  const wx = (u, v) => (portrait ? v : u);
  const wy = (u, v) => (portrait ? u : v);

  function roundedPath(pts) {
    const path = new Path2D();
    const P = pts.map(([u, v]) => [wx(u, v), wy(u, v)]);
    path.moveTo(P[0][0], P[0][1]);
    for (let k = 1; k < P.length - 1; k++) path.arcTo(P[k][0], P[k][1], P[k + 1][0], P[k + 1][1], CORNER);
    path.lineTo(P[P.length - 1][0], P[P.length - 1][1]);
    return path;
  }

  function trainAt(s) {
    const { trunk, cum } = G;
    s = Math.max(0, Math.min(cum[cum.length - 1], s));
    let k = 1;
    while (k < cum.length - 1 && cum[k] < s) k++;
    const a = trunk[k - 1], b = trunk[k];
    const f = (s - cum[k - 1]) / Math.max(0.001, cum[k] - cum[k - 1]);
    return [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f];
  }

  // ------------------------------------------------------------------ Kamera

  const cam = { u: 0, v: 0, z: 1 };
  const stopZoom = () => Math.max(0.55, Math.min(W, H) / 1080 * (portrait ? 1.25 : 1.35));
  function overviewView(centreU) {
    // Der ganze Plan (oder ein Stück um den Zug), neben bzw. unter dem Kasten mit Titel und Legende
    const span = G.umax - G.umin, vspan = G.vmax - G.vmin;
    const along = portrait ? H * 0.70 : W * 0.94, across = portrait ? W * 0.9 : H * 0.55;
    let z = Math.min(along / span, across / vspan);
    z = Math.max(z, stopZoom() * 0.12);
    const half = along / 2 / z;
    let u = (G.umin + G.umax) / 2;
    if (span * z > along) u = Math.max(G.umin + half, Math.min(G.umax - half, centreU));
    const vc = (G.vmin + G.vmax) / 2;
    if (portrait) return { u: u - H * 0.12 / z, v: vc, z };     // Kasten oben: Plan nach unten
    return { u, v: vc + H * 0.17 / z, z };                       // Kasten unten: Plan nach oben
  }
  function travelAnchor(i) {
    const z = stopZoom();
    if (portrait) return { u: G.u[i], v: 0, z };
    return { u: G.u[i], v: G.pos[i][0] * 0.5, z };
  }
  function stopAnchor(i) {
    // Wo soll die Haltestelle auf dem Bildschirm stehen? Fotos kommen auf die andere Seite.
    const v = G.pos[i][0];
    const z = stopZoom();
    if (portrait) return { u: G.u[i] - H * 0.30 / z, v: 0, z, cardsTop: true };
    const down = v >= -LANE * 0.25;
    return { u: G.u[i], v: v - (down ? H * 0.31 : -H * 0.31) / z, z, cardsTop: down };
  }

  function toScreen(u, v) {
    const cu = portrait ? cam.v : cam.u, cv = portrait ? cam.u : cam.v;
    const x = wx(u, v), y = wy(u, v);
    return [(x - cu) * cam.z + W / 2, (y - cv) * cam.z + H / 2];
  }

  // ------------------------------------------------------------------ Zeichnen

  let train = null;        // [u, v] oder null
  let veil = 0;            // 0..1 Schleier während eines Halts
  let spot = -1;           // Haltestelle im Licht

  function draw() {
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    ctx.fillStyle = T.bg;
    ctx.fillRect(0, 0, W, H);
    if (!G) return;
    const z = cam.z;
    const cu = portrait ? cam.v : cam.u, cv = portrait ? cam.u : cam.v;
    ctx.setTransform(DPR * z, 0, 0, DPR * z, DPR * (W / 2 - cu * z), DPR * (H / 2 - cv * z));
    const px = 1 / z;   // ein Bildschirmpixel in Weltmaß
    // sichtbarer Ausschnitt entlang der Zeit
    const halfAlong = (portrait ? H : W) / 2 / z, midAlong = portrait ? cam.u : cam.u;
    const lo = midAlong - halfAlong - 300, hi = midAlong + halfAlong + 300;

    // Jahresbänder
    const span0 = G.vmin - 1e5, span1 = G.vmax + 1e5;
    G.years.forEach((yr, k) => {
      if (k === G.years.length - 1) return;
      const a = yr.u, b = G.years[k + 1].u;
      if (b < lo || a > hi) return;
      if (k % 2 === 0) {
        ctx.fillStyle = T.band;
        if (portrait) ctx.fillRect(span0, a, span1 - span0, b - a);
        else ctx.fillRect(a, span0, b - a, span1 - span0);
      }
      const size = Math.max(64, 30 * px);
      if ((b - a) < size * 2.9) return;     // Band zu schmal für die Jahreszahl
      ctx.font = `800 ${size}px Inter, Arial, sans-serif`;
      ctx.fillStyle = T.year;
      ctx.textBaseline = "alphabetic";
      if (portrait) {
        ctx.textAlign = "left";
        const x = cam.v - W / 2 / z + 18 * px;
        ctx.fillText(String(yr.y), x, a + size * 1.0);
      } else {
        ctx.textAlign = "left";
        const top = cam.v - H / 2 / z + 10 * px;
        ctx.fillText(String(yr.y), a + 14 * px, top + size);
      }
    });

    // Linien
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    const lines = S.plan.lines;
    for (let l = lines.length - 1; l >= 0; l--) {
      const p = G.paths[l];
      if (!p) continue;
      const width = Math.max(l === 0 ? TRUNK_LW : LW, (l === 0 ? 3 : 2.4) * px);
      ctx.strokeStyle = T.halo;
      ctx.lineWidth = width + Math.max(5, 2 * px);
      ctx.stroke(p.path);
      ctx.strokeStyle = lineColor(lines[l]);
      ctx.lineWidth = width;
      ctx.stroke(p.path);
      // Endhaltestellen: Querstrich
      for (const end of [p.pts[0], p.pts[p.pts.length - 1]]) {
        const [u, v] = end;
        if (u < lo || u > hi) continue;
        ctx.beginPath();
        if (portrait) { ctx.moveTo(v - 16, u); ctx.lineTo(v + 16, u); } else { ctx.moveTo(u, v - 16); ctx.lineTo(u, v + 16); }
        ctx.lineWidth = Math.max(LW, 2 * px);
        ctx.stroke();
      }
    }
    // Linienschilder am Anfang (Linien, die an derselben Haltestelle beginnen, untereinander)
    const badgeSize = Math.max(19, 9 * px);
    ctx.font = `750 ${badgeSize}px Inter, Arial, sans-serif`;
    ctx.textBaseline = "middle";
    const starts = {};
    for (let l = 0; l < lines.length; l++) if (G.paths[l]) (starts[G.first[l]] = starts[G.first[l]] || []).push(l);
    for (const [at, all] of Object.entries(starts)) {
      const i = Number(at);
      let group = all;
      if (i > 0) {
        // Später beginnende Linien: Schild auf der Linie, wo sie ihre eigene Spur erreicht
        group = [];
        for (const l of all) {
          const pts = G.paths[l].pts, laneV = G.lane[l] * LANE;
          let k = pts.findIndex((p, idx) => idx > 0 && Math.abs(p[1] - laneV) < 0.5 && Math.abs(pts[idx - 1][1] - laneV) > 0.5);
          if (k < 0 || k + 1 >= pts.length || Math.abs(pts[k + 1][1] - laneV) > 0.5) { group.push(l); continue; }
          const label = lineName(lines[l]);
          const w = ctx.measureText(label).width + badgeSize * 1.1, h = badgeSize * 1.6;
          const room = pts[k + 1][0] - pts[k][0];
          if (room < w + 60) { group.push(l); continue; }
          const um = pts[k][0] + 30 + w / 2;
          if (um < lo - 400 || um > hi + 400) continue;
          const x = wx(um, laneV), y = wy(um, laneV);
          ctx.fillStyle = lineColor(lines[l]);
          roundRect(x - w / 2, y - h / 2, w, h, h / 2);
          ctx.fill();
          ctx.lineWidth = 3; ctx.strokeStyle = T.halo; ctx.stroke();
          ctx.fillStyle = "#ffffff";
          ctx.textAlign = "center";
          ctx.fillText(label, x, y + badgeSize * 0.04);
        }
        if (!group.length) continue;
      }
      const u0 = G.u[i] - RUN;
      if (u0 < lo - 900 || u0 > hi) continue;
      group.sort((a, b) => G.pos[i][a] - G.pos[i][b]);
      const h = badgeSize * 1.6, gapB = badgeSize * 0.35;
      const widths = group.map((l) => ctx.measureText(lineName(lines[l])).width + badgeSize * 1.1);
      const total = portrait ? widths.reduce((a, b) => a + b, 0) + gapB * (group.length - 1) : group.length * h + (group.length - 1) * gapB;
      const centre = G.bundle[i].centre;
      let cursor = centre - total / 2;
      group.forEach((l, k) => {
        const label = lineName(lines[l]);
        const w = widths[k];
        let x, y;
        if (portrait) { x = cursor; y = u0 - 30 - h; cursor += w + gapB; } else { x = u0 - 26 - w; y = cursor; cursor += h + gapB; }
        ctx.fillStyle = lineColor(lines[l]);
        roundRect(x, y, w, h, h / 2);
        ctx.fill();
        ctx.fillStyle = l === 0 && S.s.Theme === "dark" ? "#12151b" : "#ffffff";
        ctx.textAlign = "center";
        ctx.fillText(label, x + w / 2, y + h / 2 + badgeSize * 0.04);
      });
    }

    // Haltestellen
    const stations = S.plan.stations;
    const labelSize = 19, dateSize = 13.5;
    const showLabels = z * labelSize >= 7;
    stations.forEach((st, i) => {
      const u = G.u[i];
      if (u < lo || u > hi) return;
      const b = G.bundle[i];
      const lit = i === spot ? 1 : 0;
      ctx.lineWidth = 3.6;
      ctx.strokeStyle = T.stationEdge;
      ctx.fillStyle = T.stationFill;
      if (b.members.length === 1) {
        const [x, y] = [wx(u, b.centre), wy(u, b.centre)];
        ctx.beginPath(); ctx.arc(x, y, 9.5 + lit * 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = lineColor(S.plan.lines[0]);
        ctx.lineWidth = 4.2;
        ctx.stroke();
      } else {
        const r = 11 + lit * 3;
        const len = b.hi - b.lo;
        if (portrait) roundRect(b.lo - r, u - r, len + 2 * r, 2 * r, r);
        else roundRect(u - r, b.lo - r, 2 * r, len + 2 * r, r);
        ctx.fill(); ctx.stroke();
      }
      if (!showLabels) return;
      // Beschriftung: nach außen (weg von der Stammlinie), sonst abwechselnd
      const out = b.centre > 1 ? 1 : b.centre < -1 ? -1 : (i % 2 ? 1 : -1);
      const name = stationLabel(st);
      const when = st.kind === "event" && !st.birthday && !st.holiday && !st.name ? (st.city || "") : fmtShort(st.a, st.b);
      ctx.textAlign = portrait ? "left" : "center";
      ctx.lineJoin = "round";
      let x, y;
      if (portrait) {
        const passing = Object.values(G.pos[i]).filter((v) => v > b.hi).sort((p, q) => p - q);
        let edge = b.hi;
        for (const v of passing) { if (v - edge < 40) edge = v; else break; }
        x = edge + 26; y = u;
        ctx.textBaseline = "middle";
        halo(`700 ${labelSize}px Inter, Arial, sans-serif`, name, x, y - 9, T.ink);
        halo(`500 ${dateSize}px Inter, Arial, sans-serif`, when, x, y + 12, T.soft);
      } else {
        const passing = Object.values(G.pos[i]).filter((v) => (out > 0 ? v > b.hi : v < b.lo))
          .sort((p, q) => (out > 0 ? p - q : q - p));
        let edge = out > 0 ? b.hi : b.lo;
        for (const v of passing) { if (Math.abs(v - edge) < 64) edge = v; else break; }
        x = u;
        ctx.textBaseline = "alphabetic";
        if (out > 0) {
          y = edge + 22 + labelSize;
          halo(`700 ${labelSize}px Inter, Arial, sans-serif`, name, x, y, T.ink);
          halo(`500 ${dateSize}px Inter, Arial, sans-serif`, when, x, y + dateSize + 6, T.soft);
        } else {
          y = edge - 22 - dateSize - 6;
          halo(`700 ${labelSize}px Inter, Arial, sans-serif`, name, x, y, T.ink);
          halo(`500 ${dateSize}px Inter, Arial, sans-serif`, when, x, y + dateSize + 6, T.soft);
        }
      }
    });

    // Zug
    if (train) {
      const [u, v] = train;
      const x = wx(u, v), y = wy(u, v);
      const r = Math.max(13, 5 * px);
      ctx.beginPath(); ctx.arc(x, y, r * 1.9, 0, Math.PI * 2);
      ctx.fillStyle = S.s.Theme === "dark" ? "rgba(255,255,255,0.12)" : "rgba(29,33,41,0.10)";
      ctx.fill();
      ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fillStyle = "#ffffff"; ctx.fill();
      ctx.lineWidth = r * 0.45; ctx.strokeStyle = lineColor(S.plan.lines[0]); ctx.stroke();
    }

    // Schleier bei einem Halt, mit Licht auf der Haltestelle
    if (veil > 0.001) {
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      ctx.save();
      ctx.globalAlpha = veil;
      if (spot >= 0) {
        const [sx, sy] = toScreen(G.u[spot], G.bundle[spot].centre);
        const r = Math.min(W, H) * 0.16;
        const g = ctx.createRadialGradient(sx, sy, r * 0.35, sx, sy, r * 1.6);
        g.addColorStop(0, T.veil.replace(/[\d.]+\)$/, "0)"));
        g.addColorStop(1, T.veil);
        ctx.fillStyle = g;
      } else {
        ctx.fillStyle = T.veil;
      }
      ctx.fillRect(0, 0, W, H);
      ctx.restore();
    }
  }

  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function halo(font, text, x, y, color) {
    ctx.font = font;
    ctx.lineWidth = 5;
    ctx.strokeStyle = T.halo;
    ctx.strokeText(text, x, y);
    ctx.fillStyle = color;
    ctx.fillText(text, x, y);
  }

  // ------------------------------------------------------------------ Fotos und Beschriftung (HTML)

  const cardsBox = el("cards");
  const cache = new Map();          // Fotoindex -> Promise<HTMLImageElement|null>
  const visits = new Map();         // Haltestelle -> wie oft schon gezeigt

  function photoUrl(i) {
    if (useFiles) return `data/photos/${encodeURIComponent(S.files[i] || "")}`;
    return `${base()}api/photo?i=${i}&v=${S.ver}`;
  }
  function loadPhoto(i) {
    const key = `${S.ver}:${i}`;
    if (!cache.has(key)) {
      cache.set(key, new Promise((resolve) => {
        const img = new Image();
        img.decoding = "async";
        img.onload = () => resolve(img);
        let second = false;
        img.onerror = () => {
          // Plugin gibt das Foto nicht her: die Kopie im Szenenordner versuchen (und umgekehrt)
          const name = S.files[i];
          if (!second && !S.plan.demo && name) {
            second = true;
            img.src = useFiles ? `${base()}api/photo?i=${i}&v=${S.ver}` : `data/photos/${encodeURIComponent(name)}`;
            return;
          }
          report(`Foto ${i} lädt nicht`);
          setTimeout(() => cache.delete(key), 60000);   // später noch einmal versuchen
          resolve(null);
        };
        img.src = S.plan.demo ? demoPhoto(i) : photoUrl(i);
      }));
      if (cache.size > 80) cache.delete(cache.keys().next().value);
    }
    return cache.get(key);
  }
  function stopPhotos(i) {
    const st = S.plan.stations[i];
    // Remote Frame ohne Anmeldung: nur Fotos, die das Plugin schon in den Szenenordner gelegt hat
    const list = useFiles ? st.p.filter((x) => S.files[x]) : st.p;
    const count = Math.min(S.s.PhotosPerStop, list.length);
    if (!count) return [];
    const offset = ((visits.get(i) || 0) * count) % list.length;
    const out = [];
    for (let k = 0; k < count; k++) out.push(list[(offset + k) % list.length]);
    return out;
  }

  function fitCards(imgs, box) {
    // Eine oder zwei Reihen; die Variante mit den größten Fotos gewinnt
    const gap = Math.min(W, H) * 0.022;
    const ratios = imgs.map((img) => Math.max(0.5, Math.min(2.2, img.naturalWidth / Math.max(1, img.naturalHeight))));
    let best = null;
    for (let rows = 1; rows <= Math.min(3, ratios.length); rows++) {
      const per = Math.ceil(ratios.length / rows);
      const groups = [];
      for (let k = 0; k < ratios.length; k += per) groups.push(ratios.slice(k, k + per));
      const rowH = Math.min(...groups.map((g) => (box.w - gap * (g.length - 1)) / g.reduce((a, b) => a + b, 0)),
        (box.h - gap * (groups.length - 1)) / groups.length);
      const area = rowH * rowH * ratios.reduce((a, b) => a + b, 0);
      if (!best || area > best.area) best = { area, rowH, groups };
    }
    const out = [];
    const totalH = best.rowH * best.groups.length + gap * (best.groups.length - 1);
    let y = box.y + (box.h - totalH) / 2, idx = 0;
    for (const group of best.groups) {
      const rowW = group.reduce((a, b) => a + b * best.rowH, 0) + gap * (group.length - 1);
      let x = box.x + (box.w - rowW) / 2;
      for (const r of group) {
        out.push({ x, y, w: r * best.rowH, h: best.rowH, img: imgs[idx++] });
        x += r * best.rowH + gap;
      }
      y += best.rowH + gap;
    }
    return out;
  }

  async function showStop(i, anchor) {
    const st = S.plan.stations[i];
    const wanted = stopPhotos(i);
    visits.set(i, (visits.get(i) || 0) + 1);
    const loaded = (await Promise.race([
      Promise.all(wanted.map(loadPhoto)),
      new Promise((resolve) => setTimeout(() => resolve(null), 4000)),
    ])) || (await Promise.all(wanted.map((p) => Promise.race([loadPhoto(p), new Promise((r) => setTimeout(() => r(null), 10))]))));
    const imgs = loaded.filter(Boolean);
    // Beschriftung
    const cap = el("caption");
    const accent = st.l.length ? S.plan.lines[st.l[0]].color : lineColor(S.plan.lines[0]);
    cap.style.setProperty("--accent", accent);
    el("capKicker").textContent = stationKicker(st);
    el("capTitle").textContent = stationTitle(st);
    const bits = [fmtRange(st.a, st.b)];
    if (st.kind === "trip" && days(st.a, st.b) > 1) bits.push(tx("days", { n: days(st.a, st.b) }));
    bits.push(st.n === 1 ? tx("photos1") : tx("photos", { n: st.n.toLocaleString(locale()) }));
    el("capWhen").textContent = bits.join(" · ");
    const who = el("capWho");
    who.innerHTML = "";
    if (S.s.ShowPeople) {
      for (const l of st.l) {
        const line = S.plan.lines[l];
        const chip = document.createElement("span");
        chip.className = "chip";
        chip.style.setProperty("--c", line.color);
        chip.innerHTML = "<i></i>";
        chip.append(lineName(line));
        who.append(chip);
      }
      const onLines = new Set(st.l.map((l) => S.plan.lines[l].name));
      for (const name of (st.who || []).filter((n) => !onLines.has(n)).slice(0, 4)) {
        const chip = document.createElement("span");
        chip.className = "chip plain";
        chip.innerHTML = "<i></i>";
        chip.append(name);
        who.append(chip);
      }
    }
    // Platz: Beschriftung zur Haltestelle hin, Fotos darüber bzw. darunter
    const margin = Math.min(W, H) * 0.045;
    cap.hidden = false;
    cap.style.left = cap.style.top = cap.style.bottom = "auto";
    const capH = cap.offsetHeight, capW = cap.offsetWidth;
    let region;
    if (anchor.cardsTop) {
      const top = margin, bottom = portrait ? H * 0.70 : H * 0.70;
      region = { x: margin, y: top, w: W - 2 * margin, h: bottom - top - capH - margin * 0.6 };
      cap.style.top = `${bottom - capH}px`;
    } else {
      const top = H * 0.30, bottom = H - margin;
      cap.style.top = `${top}px`;
      region = { x: margin, y: top + capH + margin * 0.6, w: W - 2 * margin, h: bottom - top - capH - margin * 0.6 };
    }
    cap.style.left = `${Math.max(margin, Math.min(W - margin - capW, W / 2 - capW / 2))}px`;
    requestAnimationFrame(() => cap.classList.add("in"));
    // Fotos aus der Haltestelle herausfliegen lassen
    const [sx, sy] = toScreen(G.u[i], G.bundle[i].centre);
    cardsBox.innerHTML = "";
    if (imgs.length && region.h > 60) {
      fitCards(imgs, region).forEach((c, k) => {
        const card = document.createElement("div");
        card.className = "card";
        const tilt = ((k * 37 + i * 13) % 7 - 3) * 0.6;
        Object.assign(card.style, { left: `${c.x}px`, top: `${c.y}px`, width: `${c.w}px`, height: `${c.h}px` });
        const dx = sx - (c.x + c.w / 2), dy = sy - (c.y + c.h / 2);
        card.style.transform = `translate(${dx}px, ${dy}px) scale(0.06) rotate(${tilt * 3}deg)`;
        card.append(c.img.cloneNode());
        cardsBox.append(card);
        setTimeout(() => { card.classList.add("in"); card.style.transform = `rotate(${tilt}deg)`; }, 120 + k * 230);
      });
    }
  }

  function hideStop(i) {
    const cap = el("caption");
    cap.classList.remove("in");
    const [sx, sy] = i >= 0 && G ? toScreen(G.u[i], G.bundle[i].centre) : [W / 2, H / 2];
    for (const card of cardsBox.children) {
      const r = card.getBoundingClientRect();
      card.style.transform = `translate(${sx - (r.left + r.width / 2)}px, ${sy - (r.top + r.height / 2)}px) scale(0.05)`;
      card.classList.remove("in");
    }
  }

  // ------------------------------------------------------------------ Überblick

  function showIntro(on) {
    const box = el("intro");
    if (!on) { box.classList.remove("in"); return; }
    const plan = S.plan;
    el("introKicker").textContent = tx("kicker", { from: plan.from, to: plan.to });
    el("introTitle").textContent = tx("title");
    el("introFacts").textContent = tx("facts", { stations: plan.stations.length.toLocaleString(locale()),
      photos: (plan.count || 0).toLocaleString(locale()), years: plan.to - plan.from + 1 });
    const legend = el("legend");
    legend.innerHTML = "";
    plan.lines.forEach((line) => {
      const li = document.createElement("li");
      li.style.setProperty("--c", lineColor(line));
      li.innerHTML = "<i></i>";
      li.append(lineName(line));
      if (line.kind !== "trunk") {
        const small = document.createElement("small");
        small.textContent = tx("lineStops", { n: line.n });
        li.append(" ", small);
      }
      legend.append(li);
    });
    box.hidden = false;
    requestAnimationFrame(() => box.classList.add("in"));
  }

  // ------------------------------------------------------------------ Fahrt

  const ease = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
  let anim = null;          // {from, to, start, dur, onDone, trainFrom, trainTo}
  let tour = { at: -1, stops: 0, timer: 0, phase: "idle", token: 0 };
  let pendingPlan = null;

  function animateTo(view, dur, opts = {}) {
    return new Promise((resolve) => {
      anim = { from: { ...cam }, to: view, start: performance.now(), dur: Math.max(1, dur * 1000), resolve,
        trainFrom: opts.trainFrom, trainTo: opts.trainTo, veilTo: opts.veil };
      anim.veilFrom = veil;
    });
  }

  function step(now) {
    if (anim) {
      const t = Math.min(1, (now - anim.start) / anim.dur);
      const e = ease(t);
      // Zoom logarithmisch, sonst wirkt es ruckig
      const lz = Math.log(anim.from.z) + (Math.log(anim.to.z) - Math.log(anim.from.z)) * e;
      cam.z = Math.exp(lz);
      if (anim.trainFrom !== undefined) {
        const s = anim.trainFrom + (anim.trainTo - anim.trainFrom) * e;
        train = trainAt(s);
        cam.u = anim.from.u + (anim.to.u - anim.from.u) * e;
        cam.v = anim.from.v + (anim.to.v - anim.from.v) * e;
      } else {
        cam.u = anim.from.u + (anim.to.u - anim.from.u) * e;
        cam.v = anim.from.v + (anim.to.v - anim.from.v) * e;
      }
      if (anim.veilTo !== undefined) veil = anim.veilFrom + (anim.veilTo - anim.veilFrom) * e;
      if (t >= 1) { const done = anim.resolve; anim = null; done(); }
    }
    draw();
    requestAnimationFrame(step);
  }

  const wait = (seconds, token) => new Promise((resolve) => setTimeout(() => resolve(token === tour.token), seconds * 1000));
  const speed = () => ({ slow: 240, normal: 360, fast: 540 }[S.s.Speed] || 360);

  function startIndex() {
    const st = S.plan.stations;
    const order = S.s.TourOrder;
    if (order === "random") return Math.floor(Math.random() * st.length);
    if (order === "onthisday") {
      const today = (S.today || new Date().toISOString()).slice(5, 10);
      const dist = (iso) => {
        const a = new Date(`2001-${iso.slice(5, 10)}T12:00:00`), b = new Date(`2001-${today}T12:00:00`);
        const d = Math.abs(a - b) / 86400000;
        return Math.min(d, 365 - d);
      };
      let best = 0;
      st.forEach((s, i) => { if (dist(s.a) < dist(st[best].a)) best = i; });
      return best;
    }
    let last = S.pos;
    try { last = localStorage.getItem("lifelines.pos") || last; } catch (_) { /* egal */ }
    if (!last) return 0;
    const next = st.findIndex((s) => s.a > last);
    return next < 0 ? 0 : next;
  }

  function remember(i) {
    const a = S.plan.stations[i].a;
    S.pos = a;
    try { localStorage.setItem("lifelines.pos", a); } catch (_) { /* egal */ }
    if (!S.plan.demo) fetch(`${base()}api/pos?a=${a}`, { cache: "no-store" }).catch(() => {});
  }

  async function overview(token, centreU, seconds) {
    showIntro(true);
    el("year").hidden = true;
    const view = overviewView(centreU);
    await animateTo({ u: view.u, v: view.v, z: view.z }, 3.2, { veil: 0 });
    ready();
    return wait(seconds, token);
  }

  async function run() {
    const token = ++tour.token;
    hideStop(-1);
    el("caption").hidden = true;
    const n = S.plan.stations.length;
    let i = startIndex();
    train = trainAt(G.stationS[i]);
    if (tour.at < 0) {
      // Erster Start: vom Überblick her
      const view = overviewView(G.u[i]);
      Object.assign(cam, { u: view.u, v: view.v, z: view.z });
      if (S.s.Overview) { if (!(await overview(token, G.u[i], 8))) return; } else ready();
    }
    for (;;) {
      showIntro(false);
      const a = travelAnchor(i);
      await animateTo({ u: a.u, v: a.v, z: a.z }, tour.stops === 0 ? 3.2 : 2.6);
      if (token !== tour.token) return;
      for (let k = 0; k < S.s.StopsPerRound; k++) {
        tour.at = i;
        updateYear(i);
        // Halt
        spot = i;
        const anchor = stopAnchor(i);
        el("year").classList.add("away");
        const shown = showStop(i, anchor);
        await animateTo({ u: anchor.u, v: anchor.v, z: anchor.z }, 0.8, { veil: 1 });
        await shown;
        ready();
        remember(i);
        if (!(await wait(S.s.StopSeconds, token))) return;
        hideStop(i);
        const back = travelAnchor(i);
        await animateTo({ u: back.u, v: back.v, z: back.z }, 0.9, { veil: 0 });
        spot = -1;
        el("caption").hidden = true;
        cardsBox.innerHTML = "";
        el("year").classList.remove("away");
        if (token !== tour.token) return;
        if (pendingPlan) { applyPlan(pendingPlan); return; }
        // Weiterfahren
        const j = (i + 1) % n;
        if (j === 0) break;       // Ende des Plans: Überblick, dann von vorn
        const b = travelAnchor(j);
        const dist = Math.abs(G.stationS[j] - G.stationS[i]);
        const dur = Math.max(2.2, Math.min(8, dist / speed()));
        fetchPhotosAhead(j);
        animateYear(i, j, dur);
        await animateTo({ u: b.u, v: b.v, z: b.z }, dur, { trainFrom: G.stationS[i], trainTo: G.stationS[j] });
        if (token !== tour.token) return;
        i = j;
        tour.stops++;
      }
      // Überblick zwischen den Runden
      if (S.s.Overview) {
        if (!(await overview(token, G.u[i], 7))) return;
      }
      if (pendingPlan) { applyPlan(pendingPlan); return; }
      const next = S.s.TourOrder === "random" ? Math.floor(Math.random() * n) : (i + 1) % n;
      const dist = Math.abs(G.stationS[next] - G.stationS[i]);
      train = trainAt(G.stationS[i]);
      if (!S.s.Overview) {
        const b = travelAnchor(next);
        await animateTo({ u: b.u, v: b.v, z: b.z }, Math.max(2.2, Math.min(8, dist / speed())),
          { trainFrom: G.stationS[i], trainTo: G.stationS[next] });
      } else {
        train = trainAt(G.stationS[next]);
      }
      i = next;
    }
  }

  function fetchPhotosAhead(j) { for (const p of stopPhotos(j)) loadPhoto(p); }

  let yearShown = "";
  function updateYear(i) {
    const y = S.plan.stations[i].a.slice(0, 4);
    const box = el("year");
    box.hidden = false;
    if (y !== yearShown) { box.textContent = y; yearShown = y; }
  }
  function animateYear(i, j, dur) {
    const a = Number(S.plan.stations[i].a.slice(0, 4)), b = Number(S.plan.stations[j].a.slice(0, 4));
    if (a === b) return;
    const steps = b - a;
    for (let k = 1; k <= steps; k++) setTimeout(() => { el("year").textContent = String(a + k); yearShown = String(a + k); }, dur * 1000 * k / (steps + 1));
  }

  // ------------------------------------------------------------------ Meldungen

  function loaded() { const box = el("loading"); if (box) box.remove(); }

  function message(kind) {
    loaded();
    const box = el("message");
    const texts = { busy: ["busy", "busyText"], empty: ["emptyTitle", "emptyText"], offline: ["offline", "offlineText"],
      nosource: ["emptyTitle", "noSource"] }[kind];
    if (!texts) { box.hidden = true; return; }
    el("msgTitle").textContent = tx(texts[0]);
    el("msgText").textContent = tx(texts[1]);
    box.hidden = false;
    for (const id of ["intro", "caption", "year"]) el(id).hidden = true;
    cardsBox.innerHTML = "";
    G = null;
    tour.token++;
    tour.at = -1;
    ready();
  }

  // ------------------------------------------------------------------ Daten vom Plugin

  function applyPlan(plan) {
    pendingPlan = null;
    S.plan = plan;
    T = theme();
    if (!plan || !plan.stations || !plan.stations.length) {
      message(plan ? "empty" : (S.busy ? "busy" : "empty"));
      return;
    }
    el("message").hidden = true;
    loaded();
    layout();
    tour.at = tour.at >= 0 ? 0 : -1;
    run();
  }

  // Remote Frame ohne Anmeldung: /Plugins/Advanced/ gibt dann 401. Das Plugin legt
  // Plan und Fotos zusätzlich in den Ordner der Szene (data/scene.json, data/photos/),
  // den DynaFrame über /engine-proxy/dynamic-scenes/content/ ohne Anmeldung ausliefert.
  async function fromFiles() {
    const response = await fetch(`data/scene.json?t=${Date.now()}`, { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const body = await response.json();
    if (!body || !body.settings) throw new Error("leer");
    return body;
  }

  async function fromPlugin() {
    for (let tries = 0; tries < pluginBases.length; tries++) {
      const stop = new AbortController();
      const timer = setTimeout(() => stop.abort(), 5000);   // ein gesperrter Port darf nicht ewig hängen
      try {
        const response = await fetch(`${base()}api/scene?v=${S.ver}`,
          { cache: "no-store", credentials: "same-origin", signal: stop.signal });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return await response.json();
      } catch (_) {
        baseIndex = (baseIndex + 1) % pluginBases.length;
      } finally {
        clearTimeout(timer);
      }
    }
    return null;
  }

  let pluginTried = 0;
  async function poll() {
    if (params.get("demo")) return;
    let data = null, files = false;
    const own = !params.get("plugin");
    if (!S.loaded && own) {
      // Beim Start: Plugin und Kopie gleichzeitig fragen, wer zuerst antwortet, zeichnet.
      // Die Kopie liegt neben der Szene und ist sofort da; das Plugin übernimmt beim nächsten Abruf.
      try {
        const won = await Promise.any([
          fromPlugin().then((d) => d || Promise.reject(new Error("plugin"))).then((d) => ({ d, f: false })),
          fromFiles().then((d) => ({ d, f: true })),
        ]);
        data = won.d; files = won.f;
      } catch (_) { /* noch nichts da */ }
    } else {
      // Ohne Anmeldung (Remote Frame) antwortet das Plugin nie; dann nur alle 5 Minuten nachfragen
      if (!useFiles || Date.now() - pluginTried > 300000) {
        pluginTried = Date.now();
        data = await fromPlugin();
      }
      if (!data && own) {
        try { data = await fromFiles(); files = true; } catch (_) { /* weder Plugin noch Kopie */ }
      }
    }
    if (data) {
      if (files !== useFiles) cache.clear();
      useFiles = files;
      S.files = data.files || {};
    }
    if (!data) {
      S.failures++;
      if (!S.loaded && S.failures >= 6) message("offline");
      return;
    }
    S.failures = 0;
    const themeBefore = S.s.Theme, langBefore = S.lang;
    S.s = { ...S.s, ...data.settings };
    if (params.get("theme")) S.s.Theme = params.get("theme");
    S.lang = params.get("lang") || data.settings.Language || S.lang;
    document.documentElement.lang = S.lang;
    S.busy = data.busy; S.sources = data.sources; S.pos = data.pos || S.pos; S.today = data.today || S.today;
    const fresh = data.ver !== S.ver;
    if (fresh) {
      S.ver = data.ver;
      const plan = data.plan;
      if (!S.loaded || !G) { S.loaded = true; applyPlan(plan); }
      else if (!plan || !plan.stations?.length) applyPlan(plan);
      else pendingPlan = plan;
    } else if (!S.plan && !G) {
      message(S.sources ? (S.busy ? "busy" : "empty") : "nosource");
    } else if (S.s.Theme !== themeBefore || S.lang !== langBefore) {
      T = theme();
    }
  }

  // ------------------------------------------------------------------ Beispieldaten (?demo=1)

  function demoPhoto(i) {
    const c = document.createElement("canvas");
    c.width = i % 3 ? 640 : 420; c.height = i % 3 ? 440 : 560;
    const g = c.getContext("2d");
    const hue = (i * 47) % 360;
    const grad = g.createLinearGradient(0, 0, 0, c.height);
    grad.addColorStop(0, `hsl(${hue},55%,62%)`); grad.addColorStop(1, `hsl(${(hue + 40) % 360},45%,35%)`);
    g.fillStyle = grad; g.fillRect(0, 0, c.width, c.height);
    g.fillStyle = "rgba(255,255,255,.85)"; g.beginPath(); g.arc(c.width * .7, c.height * .3, 40, 0, 7); g.fill();
    return c.toDataURL("image/jpeg", 0.8);
  }
  function demoPlan() {
    const lines = [{ id: "trunk", kind: "trunk", name: "", color: "#3c4350", n: 0 },
      { kind: "person", name: "Anna", color: "#e3242b", n: 0 }, { kind: "person", name: "Ben", color: "#0a6cbc", n: 0 },
      { kind: "person", name: "Mia", color: "#00a05a", n: 0 }, { kind: "person", name: "Oma Gerda", color: "#f4b000", n: 0 },
      { kind: "person", name: "Tom", color: "#8e3fa8", n: 0 }];
    const raw = [["2013-07-12", "2013-07-20", "trip", "Palma", "Spanien", [1]], ["2014-05-02", "2014-05-05", "trip", "Paris", "Frankreich", [1, 5]],
      ["2014-12-23", "2014-12-26", "trip", "Kassel", "Deutschland", [1, 4]], ["2015-08-01", "2015-08-10", "trip", "Rom · Florenz", "Italien", [1]],
      ["2016-06-18", "2016-06-18", "event", "", "Deutschland", [1, 4, 5]], ["2017-03-10", "2017-03-10", "event", "", "Deutschland", [1, 2, 4]],
      ["2017-07-15", "2017-07-24", "trip", "Heringsdorf", "Deutschland", [1, 2]], ["2018-07-02", "2018-07-02", "move", "Lübeck", "Deutschland", [1, 2]],
      ["2018-08-04", "2018-08-14", "trip", "Palma · Alcúdia", "Spanien", [1, 2]], ["2019-12-22", "2019-12-26", "trip", "Kassel", "Deutschland", [1, 2, 3, 4]],
      ["2021-02-27", "2021-03-05", "trip", "Innsbruck", "Österreich", [1, 2, 3, 5]], ["2022-06-03", "2022-06-07", "trip", "Kopenhagen", "Dänemark", [1, 3]],
      ["2023-12-24", "2023-12-24", "event", "", "Deutschland", [1, 2, 3, 4]], ["2024-04-11", "2024-04-14", "trip", "London", "Vereinigtes Königreich", [5]],
      ["2025-07-05", "2025-07-16", "trip", "Oslo · Bergen", "Norwegen", [1, 2, 3]]];
    let p = 0;
    const stations = raw.map(([a, b, kind, name, country, l]) => {
      l.forEach((x) => lines[x].n++);
      return { kind, a, b, name, city: kind === "event" ? "Lübeck" : name, country, n: 20 + (p % 17), km: 0, l, p: [p++, p++, p++, p++],
        who: l.map((x) => lines[x].name), holiday: a.endsWith("12-24") ? "xmas" : "", birthday: a === "2017-03-10" ? "Ben" : "" };
    });
    return { demo: true, stations, lines, homeCountry: "Deutschland", count: 2685, from: 2013, to: 2025, photos: [] };
  }

  // ------------------------------------------------------------------ Start

  resize();
  requestAnimationFrame(step);
  if (params.get("demo")) {
    S.ver = 1; S.loaded = true;
    if (params.get("stop")) S.s.StopSeconds = Number(params.get("stop"));
    if (params.get("overview") === "0") S.s.Overview = false;
    if (params.get("order")) S.s.TourOrder = params.get("order");
    document.fonts?.load?.("700 20px Inter").finally(() => applyPlan(demoPlan()));
  } else {
    const loop = () => poll().catch(() => {}).finally(() => setTimeout(loop, S.loaded ? 20000 : 3000));
    loop();
  }
})();
