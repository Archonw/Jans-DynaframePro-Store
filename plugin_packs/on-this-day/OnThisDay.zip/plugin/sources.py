"""Woher die Fotos kommen: Immich oder DynaFrame selbst (wie bei der Reisekarte).

Jede Quelle liefert Zeilen als dict:
- k: womit die Szene das Foto später zeigen kann ("i:<asset-id>" bei Immich,
  "d:<id>|<pfad>" aus der Mediendatenbank, "f:<pfad>" bei Dateien auf dem Rahmen),
- t: Aufnahmezeit "YYYY-MM-DDTHH:MM:SS" (Ortszeit) oder "" (dann liest das
  Plugin Datum und GPS aus der Datei),
- lat, lon: GPS oder None, place: Ortsname oder "",
- stamp: ändert sich, wenn das Foto sich ändert, fav: Favorit (Immich).

Immich wird nicht ganz eingelesen: on_day() fragt je Jahr nur die Tage um das
heutige Datum ab. DynaFrame hat keine Suche nach Datum, darum liest das Plugin
dort die ganze Liste (mit Cache für Datum und GPS aus den Dateien).
"""

import datetime
import json
import os
import re
import time
from pathlib import Path
from urllib.parse import urlencode

import requests

CONNECT_TIMEOUT = 10
READ_TIMEOUT = 60
PAGE_SIZE = 1000
MAX_PHOTOS = 300000

EXTENSIONS = {".jpg", ".jpeg", ".jpe", ".png", ".webp", ".heic", ".heif", ".hif", ".avif", ".tif", ".tiff"}


class SourceError(Exception):
    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


def as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def short_error(exc):
    text = str(exc)
    for marker in ("Failed to establish a new connection: ", "Read timed out", "Name or service not known"):
        if marker in text:
            tail = text.split(marker, 1)[1] if marker.endswith(": ") else marker
            return tail.split("'))")[0].strip(" )") or marker
    return text[:200]


def clean_taken(value):
    """Ein Aufnahmedatum in "YYYY-MM-DDTHH:MM:SS"; auch Epoch-Zahlen und "2024:06:01 10:00:00"."""
    if value in (None, ""):
        return ""
    if isinstance(value, (int, float)) or re.fullmatch(r"\d{9,13}", str(value).strip()):
        number = float(value)
        if number > 1e11:
            number /= 1000
        try:
            return datetime.datetime.fromtimestamp(number).strftime("%Y-%m-%dT%H:%M:%S")
        except (OverflowError, OSError, ValueError):
            return ""
    text = str(value).strip()
    match = re.match(r"^(\d{4})[-:/](\d{2})[-:/](\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?)?", text)
    if not match:
        return ""
    year, month, day = int(match.group(1)), int(match.group(2)), int(match.group(3))
    if not (1900 < year < 2200 and 1 <= month <= 12 and 1 <= day <= 31):
        return ""
    clock = f"{match.group(4) or '12'}:{match.group(5) or '00'}:{match.group(6) or '00'}"
    return f"{year:04d}-{month:02d}-{day:02d}T{clock}"


# --------------------------------------------------------------------------
# Immich
# --------------------------------------------------------------------------

def normalize_url(url):
    url = str(url or "").strip().rstrip("/")
    if url and not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    if url.lower().endswith("/api"):
        url = url[:-4]
    return url


class Immich:
    """Der Zugang zu einem Immich-Server mit API-Schlüssel (wie Immich Slideshow)."""

    def __init__(self, tr):
        self.tr = tr
        self.base = ""
        self.key = ""
        self.session = requests.Session()
        self.visibility_ok = True

    def configure(self, base, key):
        self.base, self.key = normalize_url(base), key

    def call(self, method, path, payload=None, params=None, raw=False, timeout=None):
        if not self.base:
            raise SourceError(self.tr("Trag die Adresse deines Immich-Servers ein."))
        if not self.key:
            raise SourceError(self.tr("Trag einen API-Schlüssel von Immich ein."))
        headers = {"x-api-key": self.key, "Accept": "image/*" if raw else "application/json"}
        try:
            response = self.session.request(method, f"{self.base}/api{path}", json=payload, params=params,
                                            headers=headers, timeout=(CONNECT_TIMEOUT, timeout or READ_TIMEOUT))
        except requests.RequestException as exc:
            raise SourceError(self.tr("Immich ist nicht erreichbar: {exc}", exc=short_error(exc))) from exc
        if response.status_code == 401:
            raise SourceError(self.tr("Immich lehnt den API-Schlüssel ab."), 401)
        if response.status_code == 403:
            raise SourceError(self.tr("Dem API-Schlüssel fehlt eine Berechtigung ({path}).",
                                      path=path.split("?")[0]), 403)
        if response.status_code >= 400:
            detail = ""
            try:
                body = response.json()
                detail = body.get("message") if isinstance(body, dict) else ""
                if isinstance(detail, list):
                    detail = "; ".join(str(d) for d in detail)
            except ValueError:
                pass
            raise SourceError(f"{method} {path}: HTTP {response.status_code} {detail or ''}".strip(),
                              response.status_code)
        if raw:
            return response
        if not response.content.strip():
            return None
        try:
            return response.json()
        except ValueError as exc:
            raise SourceError(self.tr("Unter dieser Adresse antwortet kein Immich-Server.")) from exc

    def test(self):
        me = self.call("GET", "/users/me") or {}
        about = {}
        try:
            about = self.call("GET", "/server/about") or {}
        except SourceError as exc:
            if exc.status in (401, 403):
                raise
        return {"user": me.get("name") or me.get("email") or "", "version": about.get("version") or ""}

    def albums(self):
        found = {}
        for query in ({}, {"shared": "true"}):
            rows = self.call("GET", "/albums", params=query) or []
            for row in rows if isinstance(rows, list) else []:
                if isinstance(row, dict) and row.get("id"):
                    found[row["id"]] = {"id": row["id"], "name": row.get("albumName") or "?",
                                        "count": row.get("assetCount") or 0}
        return sorted(found.values(), key=lambda a: a["name"].lower())

    def _search(self, body, stop, limit=4000):
        out, page = [], 1
        while len(out) < limit and not stop.is_set():
            query = dict(body, page=page, size=min(PAGE_SIZE, limit))
            data = self.call("POST", "/search/metadata", query, timeout=120) or {}
            assets = data.get("assets") or {}
            items = [i for i in assets.get("items") or [] if isinstance(i, dict)]
            out += items
            next_page = assets.get("nextPage")
            if not next_page or not items:
                break
            page = as_int(next_page, page + 1)
        return out

    def _filtered(self, body, stop, filters, limit=4000):
        """Suche mit den Filtern (wie Growing Up): nur Favoriten, Archiv weglassen.
        Ältere Immich-Versionen kennen "visibility" nicht; dann wird nachher aussortiert."""
        body = dict(body)
        if filters.get("fav"):
            body["isFavorite"] = True
        if not filters.get("archived") and self.visibility_ok:
            body["visibility"] = "timeline"
        try:
            return self._search(body, stop, limit)
        except SourceError as exc:
            if exc.status == 400 and "visibility" in body:
                self.visibility_ok = False
                body.pop("visibility")
                return self._search(body, stop, limit)
            raise

    def first_year(self, albums, stop, filters=None):
        first = None
        for album in albums or [None]:
            body = {"type": "IMAGE", "order": "asc", "withExif": False}
            if album:
                body["albumIds"] = [album]
            try:
                items = self._filtered(body, stop, filters or {}, limit=1)
            except SourceError as exc:
                if exc.status in (401, 403) or exc.status is None:
                    raise
                items = []
            for item in items[:1]:
                taken = clean_taken(item.get("localDateTime") or item.get("fileCreatedAt"))
                if taken and (first is None or int(taken[:4]) < first):
                    first = int(taken[:4])
        return first or 1990

    def on_day(self, albums, month, day, window, stop, filters=None, first_year=None):
        """Alle Fotos um month/day (± window Tage) in allen früheren Jahren.

        albums: leer = alle Fotos, sonst nur diese Alben (je Album eine Suche,
        weil Immich mehrere Album-IDs mit UND verknüpft).
        filters: {"rating": Mindest-Sterne, "fav": nur Favoriten, "archived": Archiv auch}."""
        filters = filters or {}
        today = datetime.date.today()
        first = first_year or self.first_year(albums, stop, filters)
        found = {}
        for year in range(today.year - 1, max(1900, first) - 1, -1):
            if stop.is_set():
                break
            try:
                centre = datetime.date(year, month, day)
            except ValueError:            # 29. Februar in einem Nicht-Schaltjahr
                centre = datetime.date(year, month, 28)
            # Immich filtert nach UTC; einen Tag Rand, genau gefiltert wird nach Ortszeit.
            lo = centre - datetime.timedelta(days=window + 1)
            hi = centre + datetime.timedelta(days=window + 2)
            for album in albums or [None]:
                body = {"type": "IMAGE", "withExif": True, "takenAfter": f"{lo.isoformat()}T00:00:00.000Z",
                        "takenBefore": f"{hi.isoformat()}T00:00:00.000Z"}
                if album:
                    body["albumIds"] = [album]
                try:
                    items = self._filtered(body, stop, filters)
                except SourceError as exc:
                    if exc.status == 400 and album:
                        continue          # Album gibt es nicht mehr
                    raise
                for item in items:
                    row = self._row(item, filters)
                    if row:
                        found[row["k"]] = row
        return list(found.values()), first

    @staticmethod
    def _row(item, filters):
        if not item.get("id") or item.get("isTrashed") or item.get("type") not in (None, "IMAGE"):
            return None
        if not filters.get("archived") and (item.get("isArchived") or
                                            item.get("visibility") in ("archive", "hidden", "locked")):
            return None
        if filters.get("fav") and item.get("isFavorite") is False:
            return None
        exif = item.get("exifInfo") or {}
        if filters.get("rating") and (as_int(exif.get("rating"), 0) < filters["rating"]):
            return None
        taken = clean_taken(item.get("localDateTime") or item.get("fileCreatedAt"))
        if not taken:
            return None
        lat, lon = exif.get("latitude"), exif.get("longitude")
        place = ", ".join(str(x) for x in (exif.get("city"), exif.get("country")) if x)
        width, height = exif.get("exifImageWidth"), exif.get("exifImageHeight")
        if str(exif.get("orientation") or "") in ("5", "6", "7", "8") and width and height:
            width, height = height, width
        return {"k": "i:" + item["id"], "t": taken, "lat": lat, "lon": lon, "place": place,
                "stamp": str(item.get("checksum") or item.get("thumbhash") or ""),
                "fav": bool(item.get("isFavorite")), "w": width, "h": height,
                "stars": as_int(exif.get("rating"), 0)}

    def photo(self, asset_id, size="preview"):
        response = self.call("GET", f"/assets/{asset_id}/thumbnail", params={"size": size}, raw=True, timeout=60)
        kind = response.headers.get("Content-Type", "image/jpeg").split(";")[0]
        if not kind.startswith("image/"):
            raise SourceError(f"Immich lieferte {kind} statt eines Bildes")
        return response.content, kind


# --------------------------------------------------------------------------
# DynaFrame: Playlists und die ganze Mediendatenbank (wie die Reisekarte)
# --------------------------------------------------------------------------

PATH_KEYS = ("filePath", "path", "fullPath", "localPath", "mediaPath", "sourcePath")
TAKEN_KEYS = ("dateTaken", "takenAt", "dateTimeOriginal", "captureDate", "exifDate", "takenDate")
TYPE_KEYS = ("mediaType", "type", "kind")
SKIP_DIRS = {"@eaDir", "#recycle", ".thumbnails", "__pycache__", "node_modules", "lost+found", ".Trash-1000"}


def _rows(data):
    if isinstance(data, list):
        return [r for r in data if isinstance(r, dict)]
    if isinstance(data, dict):
        for key in ("items", "results", "media", "files", "data", "rows"):
            if isinstance(data.get(key), list):
                return [r for r in data[key] if isinstance(r, dict)]
    return []


def _find(row, keys, depth=0):
    """Den ersten Wert unter einem der Schlüssel, auch eine Ebene tiefer."""
    for key in keys:
        for name, value in row.items():
            if name.lower() == key.lower() and value not in (None, ""):
                return value
    if depth == 0:
        for value in row.values():
            if isinstance(value, dict):
                found = _find(value, keys, 1)
                if found not in (None, ""):
                    return found
    return None


def _coord(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if number != number or abs(number) > 180 or number == 0.0:
        return None
    return number


def _media_folder_ok(path):
    """Nur echte Bilderordner durchsuchen, nie das ganze System."""
    clean = os.path.normpath(path)
    if clean in ("/", "/home", "/media", "/mnt", str(Path.home())) or not os.path.isdir(clean):
        return False
    if clean.startswith(("/opt", "/usr", "/etc", "/proc", "/sys", "/var", "/tmp", "/run", "/boot", "/dev")):
        return False
    return not any(part in clean for part in ("/.local", "/.config", "/.cache"))


def _quick_mix(row):
    """Eine Quick-Mix-Liste von DynaFrame: Typ steht als JSON in description."""
    text = row.get("description")
    if isinstance(text, str) and "quick_mix" in text.replace(" ", "").lower():
        try:
            data = json.loads(text)
        except ValueError:
            return True
        return str((data or {}).get("Type") or (data or {}).get("type") or "").lower() == "quick_mix" \
            if isinstance(data, dict) else True
    return False


def _is_photo(row, path):
    kind = str(_find(row, TYPE_KEYS) or "").lower()
    if kind and any(word in kind for word in ("video", "scene", "dynamic", "web", "audio")):
        return False
    return not path or Path(str(path)).suffix.lower() in EXTENSIONS or kind.startswith("image") or kind == "photo"


class DynaFrame:
    def __init__(self, engine_call, engine_error, log):
        self.engine_call = engine_call
        self.EngineError = engine_error
        self.log = log
        self.library_way = ""
        self.logged_keys = set()

    def _log_keys(self, what, row):
        if what not in self.logged_keys and isinstance(row, dict):
            self.logged_keys.add(what)
            self.log(f"Engine {what}: Felder " + ", ".join(sorted(row.keys())))

    def playlists(self):
        data = self.engine_call("GET", "/playlists") or []
        rows = _rows(data) if not isinstance(data, list) else [r for r in data if isinstance(r, dict)]
        if isinstance(data, dict) and not rows:
            rows = _rows({"items": data.get("playlists") or []})
        return [{"id": r.get("id"), "name": r.get("name") or "?", "count": r.get("itemCount") or r.get("count")}
                for r in rows if r.get("id") is not None and not _quick_mix(r)]

    def _row(self, row, media_id=None):
        """Zeile (dict) aus einer Engine-Zeile, oder None (kein Foto)."""
        path = _find(row, PATH_KEYS)
        if not _is_photo(row, path):
            return None
        if media_id is None:
            media_id = row.get("id")
        taken = clean_taken(_find(row, TAKEN_KEYS))
        lat = _find(row, ("latitude", "lat", "gpsLatitude"))
        lon = _find(row, ("longitude", "lon", "lng", "gpsLongitude"))
        place = _find(row, ("locationName", "location", "place", "city"))
        stamp = f"{row.get('fileSize') or ''}:{str(row.get('dateModified') or row.get('modifiedAt') or '')[:19]}"
        base = {"t": taken, "lat": _coord(lat), "lon": _coord(lon), "place": place if isinstance(place, str) else "",
                "stamp": stamp, "fav": bool(row.get("isFavorite") or row.get("favorite")),
                "w": row.get("width"), "h": row.get("height")}
        if media_id is not None:
            return dict(base, k=f"d:{media_id}|{path or ''}")
        if path:
            return dict(base, k=f"f:{path}")
        return None

    def _library_index(self, stop):
        by_id, by_path = {}, {}
        for row in self.library_rows(stop):
            if row.get("id") is not None:
                by_id[str(row["id"])] = row
            path = _find(row, PATH_KEYS)
            if path:
                by_path[str(path)] = row
        return by_id, by_path

    def playlist(self, playlist_id, stop):
        items = self.engine_call("GET", f"/playlists/{playlist_id}/items") or []
        rows = _rows(items)
        if rows:
            self._log_keys("Playlist-Eintrag", rows[0])
        index = None
        out, total = [], 0
        for item in rows:
            if stop.is_set():
                break
            folder = _find(item, ("directoryPath", "folderPath", "directory", "folder"))
            if isinstance(folder, str) and folder.startswith("/"):
                pts, n = self.folder_rows([folder], stop)
                out += pts
                total += n
                continue
            media = item.get("media") if isinstance(item.get("media"), dict) else {}
            media_id = item.get("mediaFileId") or item.get("mediaId") or media.get("id")
            if item.get("dynamicSceneId") or (media_id is None and not _find(item, PATH_KEYS)):
                continue
            if index is None:
                index = self._library_index(stop)
            path = _find(item, PATH_KEYS) or _find(media, PATH_KEYS)
            row = (index[0].get(str(media_id)) if media_id is not None else None) or \
                (index[1].get(str(path)) if path else None) or (media if _find(media, PATH_KEYS) else None) or item
            found = self._row(row, media_id if media_id is not None else row.get("id"))
            if found:
                total += 1
                out.append(found)
        self.log(f"Playlist {playlist_id}: {len(rows)} Einträge, {total} Fotos.")
        return out, total

    def _page_through(self, path_for_page, stop):
        rows, seen, page = [], set(), 1
        while page <= 2000 and not stop.is_set():
            data = self.engine_call("GET", path_for_page(page))
            batch = _rows(data)
            fresh = 0
            for row in batch:
                path = _find(row, PATH_KEYS)
                if path and path not in seen:
                    seen.add(path)
                    rows.append(row)
                    fresh += 1
            if not batch or not fresh:
                break
            page += 1
        return rows

    def library_rows(self, stop):
        ways = [
            ("database", lambda p: f"/media/database?page={p}&pageSize=500&limit=500&offset={(p - 1) * 500}"),
            ("search", lambda p: f"/media/database/search?query=&page={p}&pageSize=500&limit=500"
                                 f"&offset={(p - 1) * 500}"),
        ]
        for name, way in ways:
            try:
                rows = self._page_through(way, stop)
            except self.EngineError:
                continue
            rows = [r for r in rows if _find(r, PATH_KEYS)]
            if rows:
                if self.library_way != name:
                    self.library_way = name
                    self._log_keys("Datenbank", rows[0])
                    self.log(f"Mediendatenbank über /media/database ({name}): {len(rows)} Einträge.")
                return rows
        self.library_way = ""
        return []

    def media_folders(self):
        found = []

        def walk(value, depth=0):
            if depth > 4:
                return
            if isinstance(value, dict):
                for name, inner in value.items():
                    if re.search(r"folder|director|librar|media|root|share", name, re.I):
                        walk(inner, depth + 1)
            elif isinstance(value, list):
                for inner in value:
                    walk(inner, depth + 1)
            elif isinstance(value, str) and value.startswith("/") and len(value) < 300:
                if _media_folder_ok(value):
                    found.append(value.rstrip("/"))

        for path in ("/settings/slideshow", "/settings/media", "/media/folders", "/media/directories"):
            try:
                walk(self.engine_call("GET", path))
            except self.EngineError:
                continue
        return list(dict.fromkeys(found))

    def folder_rows(self, folders, stop, seen=None):
        out, total = [], 0
        seen = seen if seen is not None else set()
        for folder in folders:
            for root, dirs, files in os.walk(folder, followlinks=False):
                if stop.is_set():
                    return out, total
                dirs[:] = [d for d in dirs if not d.startswith(".") and d not in SKIP_DIRS]
                for name in files:
                    if Path(name).suffix.lower() not in EXTENSIONS or name.startswith("."):
                        continue
                    path = os.path.join(root, name)
                    if path in seen:
                        continue
                    seen.add(path)
                    try:
                        info = os.stat(path)
                    except OSError:
                        continue
                    total += 1
                    out.append({"k": f"f:{path}", "t": "", "lat": None, "lon": None, "place": "",
                                "stamp": f"{int(info.st_mtime)}:{info.st_size}", "fav": False})
                    if total % 500 == 0:
                        time.sleep(0.02)
                    if total >= MAX_PHOTOS:
                        return out, total
        return out, total

    def library(self, extra_folders, stop):
        out, total, seen = [], 0, set()
        for row in self.library_rows(stop):
            if stop.is_set():
                break
            path = str(_find(row, PATH_KEYS))
            found = self._row(row)
            if found:
                seen.add(path)
                total += 1
                out.append(found)
        folders = list(dict.fromkeys(list(extra_folders) + self.media_folders()))
        if not folders and not seen:
            home = Path.home() / "Pictures"
            folders = [str(home)] if home.is_dir() else []
        pts, n = self.folder_rows([f for f in folders if os.path.isdir(f)], stop, seen)
        return out + pts, total + n
