"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

import re

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    "Bitte eine WAV-, MP3-, OGG- oder FLAC-Datei.": (
        "Please choose a WAV, MP3, OGG or FLAC file.",
        "Elige un archivo WAV, MP3, OGG o FLAC."),
    "Das ist keine Tondatei bis 5 MB.": (
        "That is not a sound file of up to 5 MB.",
        "No es un archivo de sonido de hasta 5 MB."),
    "Nur eigene Töne lassen sich löschen.": (
        "Only your own sounds can be deleted.",
        "Solo se pueden borrar los sonidos propios."),
    "Kein Abspielprogramm auf dem Rahmen gefunden.": (
        "No sound player found on the frame.",
        "No se encontró ningún reproductor en el marco."),
    "Der Ton {name} ist nicht mehr da.": (
        "The sound {name} is gone.",
        "El sonido {name} ya no está."),
    "Konnte den Ton nicht abspielen ({problem}).": (
        "Could not play the sound ({problem}).",
        "No se pudo reproducir el sonido ({problem})."),
    "Spiele {name} auf dem Rahmen.": (
        "Playing {name} on the frame.",
        "Reproduciendo {name} en el marco."),
    "Vor {name} lief auf dem Rahmen keine Playlist, und der Rahmen hat die Anzeige danach nicht beendet. Wähle auf der Startseite des Rahmens eine Playlist. Solange keine Playlist läuft, kommt {name} nicht mehr von selbst.": (
        "No playlist was playing on the frame before {name}, and the frame did not end the display afterwards. Choose a playlist on the frame's home page. While no playlist is playing, {name} will not come up by itself.",
        "Antes de {name} no se reproducía ninguna lista en el marco, y el marco no terminó la visualización después. Elige una lista en la página de inicio del marco. Mientras no se reproduzca ninguna lista, {name} no aparecerá por sí solo."),
    "Auf dem Rahmen läuft keine Playlist. {name} wartet, weil der Rahmen die Anzeige danach nicht von selbst beendet.": (
        "No playlist is playing on the frame. {name} waits, because the frame would not end the display by itself afterwards.",
        "No se reproduce ninguna lista en el marco. {name} espera, porque el marco no terminaría la visualización por sí solo."),
    "Die Szene Fußball Live ist auf der Plugins-Seite ausgeschaltet.": (
        "The Fußball Live scene is switched off on the Plugins page.",
        "La escena Fußball Live está desactivada en la página de plugins."),
    "Die Szene Fußball Live ist auf diesem Rahmen nicht installiert. Installiere das Fußball-Live-Paket noch einmal.": (
        "The Fußball Live scene is not installed on this frame. Install the Fußball Live package again.",
        "La escena Fußball Live no está instalada en este marco. Vuelve a instalar el paquete Fußball Live."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.",
        "El marco no ha creado la lista {name}."),
    "Wartet, bis der Bildschirm wieder frei ist.": (
        "Waiting until the screen is free again.",
        "Esperando a que la pantalla vuelva a estar libre."),
    "Konnte die Takeover-Playlist nicht anlegen: {exc}": (
        "Could not create the takeover playlist: {exc}",
        "No se pudo crear la lista de takeover: {exc}"),
    "Konnte die Playlist Fußball Live nicht pflegen: {exc}": (
        "Could not maintain the Fußball Live playlist: {exc}",
        "No se pudo mantener la lista Fußball Live: {exc}"),
    "Angelegt: die Playlist Fußball Live steht unter Playlists.": (
        "Created: the Fußball Live playlist is listed under Playlists.",
        "Creada: la lista Fußball Live aparece en Playlists."),
    "Noch nicht angelegt; das passiert innerhalb einer Minute.": (
        "Not created yet; this happens within a minute.",
        "Todavía no creada; se creará en menos de un minuto."),
    "Die Playlist wurde gelöscht, deshalb steht das wieder auf Nein.": (
        "The playlist was deleted, so this is set back to No.",
        "La lista se ha borrado, por eso vuelve a estar en No."),
    "Die früher angelegte Playlist steht noch unter Playlists; das Plugin pflegt sie nicht mehr.": (
        "The playlist created earlier is still under Playlists; the plugin no longer maintains it.",
        "La lista creada antes sigue en Playlists; el plugin ya no la mantiene."),
    "Fußball Live ist auf der Plugins-Seite ausgeschaltet.": (
        "Fußball Live is switched off on the Plugins page.",
        "Fußball Live está desactivado en la página de plugins."),
    "„Allow takeover“ ist für Fußball Live auf der Plugins-Seite aus, deshalb kann es den Bildschirm nicht übernehmen.": (
        "“Allow takeover” is off for Fußball Live on the Plugins page, so it cannot take over the screen.",
        "«Allow takeover» está desactivado para Fußball Live en la página de plugins, así que no puede ocupar la pantalla."),
    "Der Rahmen hat die Anzeige beendet ({state}).": (
        "The frame ended the display ({state}).",
        "El marco ha terminado la visualización ({state})."),
    "Fußball Live ist schon auf dem Bildschirm.": (
        "Fußball Live is already on screen.",
        "Fußball Live ya está en pantalla."),
    "Dieser Rahmen ist zu alt, um einem Plugin den Bildschirm zu überlassen.": (
        "This frame is too old to hand the screen to a plugin.",
        "Este marco es demasiado antiguo para ceder la pantalla a un plugin."),
    "Die Szene Fußball Live wurde nicht gefunden.": (
        "The Fußball Live scene was not found.",
        "No se ha encontrado la escena Fußball Live."),
    "Die Takeover-Playlist ist noch nicht angelegt.": (
        "The takeover playlist has not been created yet.",
        "La lista de takeover aún no se ha creado."),
    "Fußball Live läuft gerade in deiner Playlist; die Anzeige bleibt so.": (
        "Fußball Live is currently playing in your playlist; the display stays as it is.",
        "Fußball Live se está mostrando en tu lista; la pantalla se queda así."),
    "Der Bildschirm ist aus. Fußball Live weckt ihn nicht.": (
        "The screen is off. Fußball Live does not wake it.",
        "La pantalla está apagada. Fußball Live no la enciende."),
    "Konnte Fußball Live nicht anzeigen: {exc}": (
        "Could not show Fußball Live: {exc}",
        "No se pudo mostrar Fußball Live: {exc}"),
    "Etwas anderes hat gerade den Bildschirm.": (
        "Something else has the screen right now.",
        "Otra cosa está usando la pantalla ahora mismo."),
    "Der Rahmen hat Fußball Live nicht rechtzeitig angezeigt.": (
        "The frame did not show Fußball Live in time.",
        "El marco no mostró Fußball Live a tiempo."),
    "Fußball Live hatte den Bildschirm nicht.": (
        "Fußball Live did not have the screen.",
        "Fußball Live no tenía la pantalla."),
    "Bitte den Rahmen um den Bildschirm.": (
        "Asking the frame for the screen.",
        "Pidiendo la pantalla al marco."),
    "Gebe den Bildschirm zurück.": (
        "Handing the screen back.",
        "Devolviendo la pantalla."),
    "{name} hat nicht geklappt: {exc}": (
        "{name} did not work: {exc}",
        "{name} no ha funcionado: {exc}"),
    "Der Rahmen ist nach Fußball Live nicht zu deiner Playlist zurückgekehrt. Starte sie auf der Startseite des Rahmens neu. Mit einer gespeicherten Playlist statt eines Quick Mix passiert das nicht.": (
        "The frame did not return to your playlist after Fußball Live. Restart it on the frame's home page. "
        "This does not happen with a saved playlist instead of a Quick Mix.",
        "El marco no volvió a tu lista después de Fußball Live. Vuelve a iniciarla en la página principal del marco. "
        "Con una lista guardada en lugar de un Quick Mix esto no pasa."),
    "Regelmäßige Anzeige ist aus.": (
        "Regular display is off.",
        "La visualización periódica está desactivada."),
    "Keine Liga gewählt.": (
        "No league selected.",
        "No hay ninguna liga elegida."),
    "Außerhalb von {start}–{end} Uhr.": (
        "Outside {start}:00–{end}:00.",
        "Fuera del horario {start}:00–{end}:00."),
    "Gerade läuft kein Spiel.": (
        "No match is being played right now.",
        "Ahora mismo no se juega ningún partido."),
    "Heute ist in den gewählten Ligen kein Spieltag.": (
        "No matchday today in the selected leagues.",
        "Hoy no hay jornada en las ligas elegidas."),
    "Nächstes Spiel: {when} {home} – {away}": (
        "Next match: {when} {home} – {away}",
        "Próximo partido: {when} {home} – {away}"),
    "Live: {scores}": (
        "Live: {scores}",
        "En vivo: {scores}"),
    "Keine Spiele": (
        "No matches",
        "Sin partidos"),
    "Lese die Ergebnisse jetzt neu.": (
        "Reading the results again now.",
        "Leyendo los resultados de nuevo."),
    "Konnte die Vereine nicht laden: {exc}": (
        "Could not load the clubs: {exc}",
        "No se pudieron cargar los clubes: {exc}"),
}

_ROUND = re.compile(r"^\s*(\d+)\.\s*Spieltag\s*$")


def language(value):
    value = str(value or "").strip().lower()
    return value if value in LANGUAGES else "de"


def t(lang, template, **values):
    lang = language(lang)
    text = template
    if lang != "de":
        pair = _TEXTS.get(template)
        if pair:
            text = pair[LANGUAGES.index(lang) - 1]
    return text.format(**values) if values else text


def round_name(lang, text):
    """OpenLigaDB liefert den Spieltag auf Deutsch ("8. Spieltag")."""
    match = _ROUND.match(str(text or ""))
    if not match or language(lang) == "de":
        return text
    number = match.group(1)
    return f"Matchday {number}" if language(lang) == "en" else f"Jornada {number}"
