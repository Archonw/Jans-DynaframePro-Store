/* Secret Santa: die Handy-Seite.
 * Code steht im QR-Code (?c=1234). Mitmachen mit Name, PIN, Wunschliste.
 * Das Handy merkt sich einen zufälligen Schlüssel; nur damit (oder mit Name +
 * PIN) zeigt der Rahmen das eigene Los. Das Los wird nie von selbst gezeigt,
 * sondern erst nach einem Tippen auf den Umschlag. */
(function () {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const T = {
    loading: ["Secret Santa wird geöffnet …", "Opening Secret Santa …", "Abriendo Secret Santa …"],
    codeTitle: ["Fast geschafft", "Almost there", "Casi listo"],
    codeLead: ["Gib die vier Ziffern ein, die neben dem QR-Code auf dem Fernseher stehen.",
      "Enter the four digits shown next to the QR code on the TV.",
      "Escribe las cuatro cifras que aparecen junto al código QR en la tele."],
    code: ["Code", "Code", "Código"],
    next: ["Weiter", "Next", "Seguir"],
    badCode: ["Der Code stimmt nicht.", "That code is not right.", "El código no es correcto."],
    noAnswer: ["Der Rahmen antwortet nicht. Bist du im selben WLAN?", "The frame does not answer. Are you on the same Wi-Fi?", "El marco no responde. ¿Estás en la misma wifi?"],
    kicker: ["Wichteln", "Secret Santa", "Amigo invisible"],
    joinLead: ["Mach mit: dein Name, eine PIN und was du dir wünschst. Wenn alle dabei sind, lost der Rahmen geheim aus, und nur dein eigenes Handy zeigt dir, wen du beschenkst.",
      "Join in: your name, a PIN and what you would like. Once everyone is in, the frame draws in secret, and only your own phone shows you whom you give a present to.",
      "Apúntate: tu nombre, un PIN y lo que te gustaría. Cuando estéis todos, el marco hace el sorteo en secreto y solo tu móvil te dice a quién le haces el regalo."],
    name: ["Dein Name", "Your name", "Tu nombre"],
    namePh: ["z. B. Anna", "e.g. Anna", "p. ej. Ana"],
    pin: ["Wähle eine PIN (4 Ziffern)", "Choose a PIN (4 digits)", "Elige un PIN (4 cifras)"],
    pinShort: ["PIN", "PIN", "PIN"],
    pinHint: ["Mit Name und PIN kannst du auf jedem Handy wieder nachsehen. Behalte sie für dich.",
      "With your name and this PIN you can look again on any phone. Keep it to yourself.",
      "Con tu nombre y este PIN puedes volver a mirarlo en cualquier móvil. No se lo digas a nadie."],
    house: ["Haushalt (freiwillig)", "Household (optional)", "Hogar (opcional)"],
    housePh: ["z. B. Familie Müller", "e.g. Miller family", "p. ej. familia García"],
    houseHint: ["Wer im selben Haushalt ist, zieht sich nie gegenseitig.", "People with the same household never draw each other.", "Quienes son del mismo hogar nunca se tocan entre sí."],
    wish: ["Meine Wunschliste", "My wish list", "Mi lista de deseos"],
    wishPh: ["Bücher, warme Socken (Größe 39), alles mit Katzen …", "Books, warm socks (size 39), anything with cats …", "Libros, calcetines gordos (talla 39), cualquier cosa con gatos …"],
    nope: ["Bitte nicht", "Please not", "Mejor no"],
    nopePh: ["Schokolade mit Nüssen, Duftkerzen …", "Chocolate with nuts, scented candles …", "Chocolate con frutos secos, velas aromáticas …"],
    join: ["Beim Wichteln mitmachen", "Join Secret Santa", "Apuntarme al amigo invisible"],
    needName: ["Bitte schreib deinen Namen dazu.", "Please add your name.", "Escribe tu nombre, por favor."],
    needPin: ["Die PIN hat genau vier Ziffern.", "The PIN has exactly four digits.", "El PIN tiene exactamente cuatro cifras."],
    haveAccount: ["Schon dabei? Mit PIN anmelden", "Already in? Sign in with your PIN", "¿Ya estás? Entra con tu PIN"],
    loginTitle: ["Anmelden", "Sign in", "Entrar"],
    loginLead: ["Dein Name und deine PIN, genau wie beim Mitmachen.", "Your name and your PIN, exactly as when you joined.", "Tu nombre y tu PIN, igual que cuando te apuntaste."],
    signIn: ["Anmelden", "Sign in", "Entrar"],
    signInPin: ["Mit Name und PIN anmelden", "Sign in with name and PIN", "Entrar con nombre y PIN"],
    toJoin: ["Ich bin neu und will mitmachen", "I am new and want to join", "Soy nuevo y quiero apuntarme"],
    hello: ["Hallo, {name}!", "Hello, {name}!", "¡Hola, {name}!"],
    waitTitle: ["Du bist dabei!", "You are in!", "¡Ya estás dentro!"],
    waitLead: ["Noch ist nicht ausgelost. Sobald es so weit ist, siehst du hier, wen du beschenkst. Bisher dabei:",
      "Nothing is drawn yet. As soon as it is, you will see here whom you give a present to. In so far:",
      "Todavía no se ha sorteado. En cuanto se haga, verás aquí a quién le haces el regalo. De momento estáis:"],
    waitLeadDraw: ["Ausgelost wird am {when}. Dann siehst du hier, wen du beschenkst. Bisher dabei:",
      "The draw is on {when}. Then you will see here whom you give a present to. In so far:",
      "El sorteo es el {when}. Entonces verás aquí a quién le haces el regalo. De momento estáis:"],
    tapOpen: ["Tippe, um dein Los zu öffnen", "Tap to open your lot", "Toca para abrir tu papelito"],
    tapOpenSub: ["Schau, dass dir niemand über die Schulter guckt.", "Make sure nobody is looking over your shoulder.", "Que nadie mire por encima de tu hombro."],
    youGive: ["Du beschenkst", "You are Secret Santa for", "Tu amigo invisible es"],
    theirWish: ["Wunschliste", "Wish list", "Lista de deseos"],
    theirNope: ["Bitte nicht", "Please not", "Mejor no"],
    noWish: ["Noch keine Wünsche eingetragen. Frag doch anonym nach!", "No wishes yet. Why not ask anonymously?", "Aún no ha puesto deseos. ¡Pregúntale de forma anónima!"],
    ready: ["Ich habe das Geschenk", "I have the present", "Ya tengo el regalo"],
    askTitle: ["Anonym nachfragen", "Ask anonymously", "Preguntar de forma anónima"],
    askHint: ["{name} sieht deine Frage, aber nicht, von wem sie ist.", "{name} sees your question, but not who sent it.", "{name} ve tu pregunta, pero no quién la manda."],
    askPh: ["z. B. Welche Schuhgröße hast du?", "e.g. What is your shoe size?", "p. ej. ¿Qué número de zapato usas?"],
    send: ["Senden", "Send", "Enviar"],
    closeLot: ["Wieder verstecken", "Hide it again", "Volver a esconder"],
    yourSanta: ["Dein Wichtel war", "Your Secret Santa was", "Tu amigo invisible era"],
    fromTitle: ["Dein Wichtel fragt", "Your Secret Santa asks", "Tu amigo invisible pregunta"],
    fromHint: ["Das sieht sonst niemand, und du weißt nicht, wer fragt. Deine Antwort geht nur an deinen Wichtel.",
      "Nobody else sees this, and you do not know who is asking. Your answer goes back to your Secret Santa only.",
      "Nadie más lo ve y no sabes quién pregunta. Tu respuesta solo le llega a tu amigo invisible."],
    answerPh: ["Deine Antwort …", "Your answer …", "Tu respuesta …"],
    meSanta: ["Dein Wichtel", "Your Secret Santa", "Tu amigo invisible"],
    meYou: ["Du", "You", "Tú"],
    meKid: ["{name}", "{name}", "{name}"],
    myWish: ["Meine Wunschliste", "My wish list", "Mi lista de deseos"],
    save: ["Speichern", "Save", "Guardar"],
    saved: ["Gespeichert.", "Saved.", "Guardado."],
    logout: ["Auf diesem Handy abmelden", "Sign out on this phone", "Cerrar sesión en este móvil"],
    leave: ["Nicht mehr mitmachen", "Leave the round", "Dejar de participar"],
    leaveSure: ["Wirklich aussteigen?", "Really leave?", "¿Seguro que lo dejas?"],
    closedTitle: ["Die Lose sind gezogen", "The lots are drawn", "Ya se ha hecho el sorteo"],
    closedLead: ["Wenn du dabei bist, melde dich mit deinem Namen und deiner PIN an, dann siehst du, wen du beschenkst.",
      "If you are in, sign in with your name and PIN to see whom you give a present to.",
      "Si participas, entra con tu nombre y tu PIN para ver a quién le haces el regalo."],
    closedSignup: ["Die Anmeldung ist geschlossen", "Sign-up is closed", "La inscripción está cerrada"],
    closedSignupLead: ["Gerade kann niemand dazukommen. Wenn du schon dabei bist, melde dich mit Name und PIN an.",
      "Nobody can join right now. If you are in already, sign in with your name and PIN.",
      "Ahora no se puede apuntar nadie. Si ya participas, entra con tu nombre y tu PIN."],
    budget: ["Budget <b>{b}</b>", "Budget <b>{b}</b>", "Presupuesto <b>{b}</b>"],
    giftDay: ["Bescherung <b>{when}</b>", "Gift-giving <b>{when}</b>", "Entrega <b>{when}</b>"],
    countPeople: ["<b>{n}</b> dabei", "<b>{n}</b> in", "<b>{n}</b> apuntados"],
    cdGift: ["Noch bis zur Bescherung", "Until gift-giving", "Hasta la entrega"],
    cdDraw: ["Noch bis zur Auslosung", "Until the draw", "Hasta el sorteo"],
    cdNow: ["Frohe Bescherung!", "Merry gift-giving!", "¡A abrir los regalos!"],
    cdNowSub: ["Gleich verrät der Fernseher, wer wessen Wichtel war.", "Soon the TV reveals who was whose Secret Santa.", "Enseguida la tele desvela quién era el amigo invisible de quién."],
    cdDone: ["Alles aufgedeckt", "All revealed", "Todo desvelado"],
    days: ["Tage", "days", "días"], day1: ["Tag", "day", "día"], hours: ["Std.", "hrs", "h"], mins: ["Min.", "min", "min"], secs: ["Sek.", "sec", "s"],
    kickerDrawn: ["Wichteln · ausgelost", "Secret Santa · drawn", "Amigo invisible · sorteado"],
    kickerWait: ["Wichteln · Anmeldung", "Secret Santa · sign-up", "Amigo invisible · inscripción"],
    kickerDone: ["Wichteln · aufgelöst", "Secret Santa · revealed", "Amigo invisible · desvelado"]
  };
  const LANGS = ["de", "en", "es"];
  const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
  const browser = (navigator.languages || [navigator.language || ""]).map((l) => String(l).slice(0, 2).toLowerCase());
  let lang = browser.find((l) => LANGS.includes(l)) || (document.documentElement.lang || "en").slice(0, 2);
  if (!LANGS.includes(lang)) lang = "en";
  const tx = (key, values) => {
    const row = T[key] || [key, key, key];
    let text = row[LANGS.indexOf(lang)] ?? row[1];
    for (const [k, v] of Object.entries(values || {})) text = text.split(`{${k}}`).join(v);
    return text;
  };
  const esc = (text) => String(text ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const linkify = (text) => esc(text).replace(/https?:\/\/[^\s<]+/g, (url) => `<a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`);
  const when = (epoch) => new Date(epoch * 1000).toLocaleString(LOCALES[lang], { weekday: "short", day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" });

  function applyLanguage() {
    document.documentElement.lang = lang;
    document.querySelectorAll("[data-t]").forEach((node) => { node.textContent = tx(node.dataset.t); });
    document.querySelectorAll("[data-tp]").forEach((node) => { node.placeholder = tx(node.dataset.tp); });
  }

  // ------------------------------------------------------------ Speicher

  const store = {
    get(key) { try { return localStorage.getItem("secretsanta." + key) || ""; } catch (_) { return ""; } },
    set(key, value) { try { localStorage.setItem("secretsanta." + key, value); } catch (_) { /* privat */ } },
    del(key) { try { localStorage.removeItem("secretsanta." + key); } catch (_) { /* privat */ } }
  };
  function newToken() {
    const bytes = new Uint8Array(18);
    (window.crypto || {}).getRandomValues ? crypto.getRandomValues(bytes) : bytes.forEach((_, i) => { bytes[i] = Math.random() * 256; });
    return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
  }
  let token = store.get("tok");
  if (!/^[A-Za-z0-9_-]{16,80}$/.test(token)) { token = newToken(); store.set("tok", token); }
  const params = new URLSearchParams(location.search);
  let code = (params.get("c") || store.get("code") || "").replace(/\D/g, "").slice(0, 4);
  if (params.get("c")) history.replaceState(null, "", location.pathname);   // Code nicht im Verlauf teilen
  let info = null;
  let match = null;          // nur nach dem Öffnen, nur im Speicher dieser Seite
  let screen = "";
  let offset = 0;            // Uhr des Rahmens minus Uhr des Handys

  const q = () => `c=${encodeURIComponent(code)}&tok=${encodeURIComponent(token)}`;
  async function getJson(path) {
    const response = await fetch(path, { cache: "no-store" });
    return response.json();
  }
  async function post(path, body = {}) {
    const response = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ c: code, tok: token, ...body }) });
    return response.json();
  }

  function show(id) {
    for (const s of ["codeScreen", "joinScreen", "loginScreen", "homeScreen", "closedScreen"]) $(s).hidden = s !== id;
    $("loadNote").hidden = true;
    if (screen !== id) scrollTo(0, 0);
    screen = id;
  }

  // ------------------------------------------------------------ Start

  async function load(quiet) {
    applyLanguage();
    try {
      info = await getJson(`api/info?${q()}`);
    } catch (_) {
      if (!quiet) $("loadNote").textContent = tx("noAnswer");
      setTimeout(() => load(quiet), 5000);
      return;
    }
    if (info.now) offset = info.now - Date.now() / 1000;
    $("roundTitle").textContent = info.title || "";
    if (!info.codeOk) {
      store.del("code");
      $("code").value = "";
      show("codeScreen");
      return;
    }
    store.set("code", code);
    route();
  }

  function route() {
    if (info.me) { renderHome(); show("homeScreen"); return; }
    if (["loginScreen"].includes(screen)) return;
    if (info.signupOpen) { renderJoin(); if (screen !== "joinScreen") show("joinScreen"); return; }
    $("closedTitle").textContent = tx(info.drawn ? "closedTitle" : "closedSignup");
    $("closedLead").textContent = tx(info.drawn ? "closedLead" : "closedSignupLead");
    show("closedScreen");
  }

  $("codeButton").addEventListener("click", async () => {
    code = $("code").value.replace(/\D/g, "").slice(0, 4);
    $("codeNote").textContent = "";
    try {
      info = await getJson(`api/info?${q()}`);
    } catch (_) {
      $("codeNote").textContent = tx("noAnswer");
      return;
    }
    if (!info.codeOk) { $("codeNote").textContent = tx("badCode"); return; }
    store.set("code", code);
    $("roundTitle").textContent = info.title || "";
    route();
  });
  $("code").addEventListener("keydown", (e) => { if (e.key === "Enter") $("codeButton").click(); });

  function facts(target) {
    const parts = [];
    if (info.budget) parts.push(tx("budget", { b: esc(info.budget) }));
    if (info.gift) parts.push(tx("giftDay", { when: esc(when(info.gift)) }));
    parts.push(tx("countPeople", { n: info.names.length }));
    $(target).innerHTML = parts.map((p) => `<span class="chip">${p}</span>`).join("");
  }

  // ------------------------------------------------------------ Mitmachen / Anmelden

  function renderJoin() {
    $("joinTitle").textContent = info.title;
    $("joinHouseField").hidden = !info.houses;
    facts("joinFacts");
  }

  $("joinButton").addEventListener("click", async () => {
    const name = $("joinName").value.trim();
    const pin = $("joinPin").value.replace(/\D/g, "");
    $("joinNote").textContent = "";
    if (!name) { $("joinNote").textContent = tx("needName"); return; }
    if (pin.length !== 4) { $("joinNote").textContent = tx("needPin"); return; }
    $("joinButton").disabled = true;
    try {
      const result = await post("api/join", { name, pin, house: $("joinHouse").value, wish: $("joinWish").value, nope: $("joinNope").value });
      if (!result.success) { $("joinNote").textContent = result.error; return; }
      $("joinPin").value = "";
      await load(true);
    } catch (_) {
      $("joinNote").textContent = tx("noAnswer");
    } finally {
      $("joinButton").disabled = false;
    }
  });

  function toLogin() {
    $("toJoin").hidden = !(info && info.signupOpen);
    $("loginNote").textContent = "";
    show("loginScreen");
  }
  $("toLogin").addEventListener("click", toLogin);
  $("closedLogin").addEventListener("click", toLogin);
  $("toJoin").addEventListener("click", () => { screen = ""; route(); });

  $("loginButton").addEventListener("click", async () => {
    $("loginNote").textContent = "";
    $("loginButton").disabled = true;
    try {
      const result = await post("api/login", { name: $("loginName").value, pin: $("loginPin").value.replace(/\D/g, "") });
      if (!result.success) { $("loginNote").textContent = result.error; return; }
      $("loginPin").value = "";
      screen = "";
      await load(true);
    } catch (_) {
      $("loginNote").textContent = tx("noAnswer");
    } finally {
      $("loginButton").disabled = false;
    }
  });
  $("loginPin").addEventListener("keydown", (e) => { if (e.key === "Enter") $("loginButton").click(); });

  // ------------------------------------------------------------ Angemeldet

  function thread(rows, mine) {
    return rows.map((m) => {
      const out = m.by === mine;
      const time = new Date(m.at * 1000).toLocaleString(LOCALES[lang], { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
      return `<div class="msg${out ? " out" : ""}">${esc(m.text)}<small>${esc(time)}</small></div>`;
    }).join("");
  }

  function setValue(id, value) {
    if (document.activeElement !== $(id) && !$(id).dataset.dirty) $(id).value = value;
  }

  function renderHome() {
    const me = info.me;
    const done = info.mode === "done";
    $("homeKicker").textContent = tx(done ? "kickerDone" : info.drawn ? "kickerDrawn" : "kickerWait");
    $("homeTitle").textContent = tx("hello", { name: me.name });
    facts("homeFacts");
    $("waitCard").hidden = info.drawn;
    if (!info.drawn) {
      $("waitLead").textContent = info.drawAt ? tx("waitLeadDraw", { when: when(info.drawAt) }) : tx("waitLead");
      $("people").innerHTML = info.names.map((n) => `<span class="${n === me.name ? "me" : ""}">${esc(n)}</span>`).join("");
    }
    $("lotCard").hidden = !info.drawn;
    if (!info.drawn) closeLot();
    $("santaCard").hidden = !(done && me.santa);
    $("santaName").textContent = me.santa || "";
    const from = me.fromSanta || [];
    $("fromCard").hidden = !(info.drawn && info.messages && from.length && !done);
    $("fromThread").innerHTML = thread(from, "kid");
    $("askBox").hidden = !info.messages || done;
    if (match) renderLot();
    $("meNameField").hidden = info.drawn;
    $("meHouseField").hidden = info.drawn || !info.houses;
    setValue("meName", me.name);
    setValue("meHouse", me.house);
    setValue("meWish", me.wish);
    setValue("meNope", me.nope);
    $("leave").hidden = info.drawn;
    tickCountdown();
  }

  function renderLot() {
    $("lotName").textContent = match.name;
    $("lotHouse").textContent = match.house || "";
    $("lotWish").innerHTML = match.wish ? linkify(match.wish) : esc(tx("noWish"));
    $("lotNope").innerHTML = linkify(match.nope || "");
    $("lotNope").hidden = !match.nope;
    $("lotNopeTitle").hidden = !match.nope;
    $("ready").checked = Boolean(info.me.ready);
    $("askHint").textContent = tx("askHint", { name: match.name });
    $("askThread").innerHTML = thread(info.me.toKid || [], "santa");
  }

  function closeLot() {
    match = null;
    $("lot").hidden = true;
    $("envelope").hidden = false;
    $("envelope").classList.remove("opening");
    $("lotName").textContent = "";
    $("lotWish").textContent = "";
  }

  $("envelope").addEventListener("click", async () => {
    const env = $("envelope");
    env.disabled = true;
    try {
      const result = await post("api/open");
      if (!result.success) { alertNote(result.error); return; }
      match = result.match;
      info.me = result.me;
      env.classList.add("opening");
      await new Promise((r) => setTimeout(r, 650));
      env.hidden = true;
      $("lot").hidden = false;
      renderLot();
    } catch (_) {
      alertNote(tx("noAnswer"));
    } finally {
      env.disabled = false;
    }
  });
  function alertNote(text) { $("askNote").textContent = text; $("meNote").textContent = text; $("meNote").className = "note bad"; }
  $("closeLot").addEventListener("click", () => { closeLot(); scrollTo(0, 0); });
  // Wer das Handy weglegt: Los wieder zu.
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) closeLot();
    else load(true);
  });

  $("ready").addEventListener("change", async (e) => {
    const result = await post("api/ready", { ready: e.target.checked }).catch(() => null);
    if (result && result.success) info.me = result.me;
  });

  async function sendMessage(path, input, note) {
    const text = $(input).value.trim();
    $(note).textContent = "";
    if (!text) return;
    try {
      const result = await post(path, { text });
      if (!result.success) { $(note).textContent = result.error; return; }
      $(input).value = "";
      info.me = result.me;
      renderHome();
    } catch (_) {
      $(note).textContent = tx("noAnswer");
    }
  }
  $("askButton").addEventListener("click", () => sendMessage("api/ask", "askText", "askNote"));
  $("answerButton").addEventListener("click", () => sendMessage("api/answer", "answerText", "answerNote"));
  $("askText").addEventListener("keydown", (e) => { if (e.key === "Enter") $("askButton").click(); });
  $("answerText").addEventListener("keydown", (e) => { if (e.key === "Enter") $("answerButton").click(); });

  for (const id of ["meName", "meHouse", "meWish", "meNope"]) $(id).addEventListener("input", () => { $(id).dataset.dirty = "1"; });
  $("saveMe").addEventListener("click", async () => {
    const body = { wish: $("meWish").value, nope: $("meNope").value };
    if (!info.drawn) { body.name = $("meName").value; if (info.houses) body.house = $("meHouse").value; }
    $("meNote").className = "note";
    try {
      const result = await post("api/me", body);
      if (!result.success) { $("meNote").textContent = result.error; $("meNote").className = "note bad"; return; }
      for (const id of ["meName", "meHouse", "meWish", "meNope"]) delete $(id).dataset.dirty;
      info.me = result.me;
      $("meNote").textContent = tx("saved");
      $("meNote").className = "note ok";
      load(true);
    } catch (_) {
      $("meNote").textContent = tx("noAnswer");
      $("meNote").className = "note bad";
    }
  });

  $("logout").addEventListener("click", async () => {
    await post("api/logout").catch(() => null);
    token = newToken();
    store.set("tok", token);
    closeLot();
    screen = "";
    load(true);
  });
  $("leave").addEventListener("click", async () => {
    const button = $("leave");
    if (!button.classList.contains("confirm")) {
      button.classList.add("confirm");
      button.textContent = tx("leaveSure");
      setTimeout(() => { button.classList.remove("confirm"); button.textContent = tx("leave"); }, 4000);
      return;
    }
    const result = await post("api/leave").catch(() => null);
    if (result && !result.success) { $("meNote").textContent = result.error; $("meNote").className = "note bad"; return; }
    screen = "";
    load(true);
  });

  // ------------------------------------------------------------ Countdown

  function tickCountdown() {
    if (!info || !info.me) return;
    const box = $("countdown");
    const nowS = Date.now() / 1000 + offset;
    let target = 0, label = "";
    if (!info.drawn && info.drawAt && info.drawAt > nowS) { target = info.drawAt; label = tx("cdDraw"); }
    else if (info.gift && info.gift > nowS) { target = info.gift; label = tx("cdGift"); }
    box.hidden = !(target || (info.gift && info.drawn));
    if (box.hidden) return;
    if (!target) {
      $("cdLabel").textContent = "";
      $("cdRow").innerHTML = `<div><b>${esc(tx(info.mode === "done" ? "cdDone" : "cdNow"))}</b></div>`;
      $("cdSub").textContent = info.mode === "done" ? "" : tx("cdNowSub");
      return;
    }
    let left = Math.max(0, Math.floor(target - nowS));
    const d = Math.floor(left / 86400); left -= d * 86400;
    const h = Math.floor(left / 3600); left -= h * 3600;
    const m = Math.floor(left / 60); const s = left - m * 60;
    const cell = (n, k) => `<div><b>${String(n).padStart(2, "0")}</b><small>${esc(tx(k))}</small></div>`;
    $("cdLabel").textContent = label;
    $("cdRow").innerHTML = (d ? cell(d, d === 1 ? "day1" : "days") : "") + cell(h, "hours") + cell(m, "mins") + (d ? "" : cell(s, "secs"));
    $("cdSub").textContent = when(target);
  }
  setInterval(tickCountdown, 1000);
  setInterval(() => { if (!document.hidden && screen === "homeScreen") load(true); }, 20000);

  load(false);
})();
