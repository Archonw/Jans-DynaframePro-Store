"""Texte des Plugins auf Deutsch, Englisch und Spanisch.

Der deutsche Text ist zugleich der Schlüssel. t() sucht die Übersetzung in
der gewählten Sprache und füllt die Platzhalter; fehlt eine Übersetzung,
bleibt es beim deutschen Text.
"""

LANGUAGES = ("de", "en", "es")

_TEXTS = {
    # Immich (sources.py, immich_filters.py)
    "Dieses Immich kann nicht nach Text im Bild suchen.": (
        "This Immich cannot search for text in images.", "Este Immich no puede buscar texto en las imágenes."),
    "Dem API-Schlüssel fehlt eine Berechtigung ({path}).": (
        "The API key lacks a permission ({path}).", "A la clave API le falta un permiso ({path})."),
    "Immich ist nicht erreichbar: {exc}": ("Immich cannot be reached: {exc}", "No se puede acceder a Immich: {exc}"),
    "Immich lehnt den API-Schlüssel ab.": ("Immich refuses the API key.", "Immich rechaza la clave API."),
    "Trag die Adresse deines Immich-Servers ein.": (
        "Enter the address of your Immich server.", "Introduce la dirección de tu servidor Immich."),
    "Trag einen API-Schlüssel von Immich ein.": (
        "Enter an API key from Immich.", "Introduce una clave API de Immich."),
    "Unter dieser Adresse antwortet kein Immich-Server.": (
        "No Immich server answers at this address.", "Ningún servidor Immich responde en esta dirección."),
    "Verbunden als {user} (Immich {version}).": (
        "Connected as {user} (Immich {version}).", "Conectado como {user} (Immich {version})."),
    "Wähle ein Album.": ("Pick an album.", "Elige un álbum."),
    "Wähle eine Playlist.": ("Pick a playlist.", "Elige una lista."),
    "Die Playlist gibt es nicht mehr.": ("That playlist no longer exists.", "Esa lista ya no existe."),
    "DynaFrame antwortet nicht: {exc}": ("DynaFrame does not answer: {exc}", "DynaFrame no responde: {exc}"),
    "Fotos und Termine werden neu eingelesen.": (
        "Reading photos and appointments again.", "Volviendo a leer las fotos y las citas."),

    # Termine
    "Trag die Adresse von Home Assistant ein.": (
        "Enter the address of Home Assistant.", "Introduce la dirección de Home Assistant."),
    "Trag einen Token von Home Assistant ein.": (
        "Enter a token from Home Assistant.", "Introduce un token de Home Assistant."),
    "Home Assistant lehnt den Token ab.": ("Home Assistant refuses the token.", "Home Assistant rechaza el token."),
    "Der Server verweigert den Kalender ({exc}). Ist es die geheime Adresse im iCal-Format?": (
        "The server refuses the calendar ({exc}). Is it the secret address in iCal format?",
        "El servidor rechaza el calendario ({exc}). ¿Es la dirección secreta en formato iCal?"),
    "Diesen Kalender gibt es nicht (mehr).": (
        "This calendar does not exist (any more).", "Este calendario no existe (ya)."),
    "Unter dieser Adresse liegt kein Kalender im iCal-Format.": (
        "There is no calendar in iCal format at this address.", "En esta dirección no hay un calendario en formato iCal."),
    "Der Kalender ist größer als 15 MB.": ("The calendar is larger than 15 MB.", "El calendario ocupa más de 15 MB."),
    "Dem Plugin fehlt ein Baustein (icalendar). Installiere das Paket noch einmal.": (
        "The plugin is missing a component (icalendar). Install the pack again.",
        "Al plugin le falta un componente (icalendar). Vuelve a instalar el paquete."),
    "Der Server spricht kein HTTPS. Versuch die Adresse mit http:// statt https:// bzw. webcal://.": (
        "The server does not speak HTTPS. Try the address with http:// instead of https:// or webcal://.",
        "El servidor no usa HTTPS. Prueba la dirección con http:// en lugar de https:// o webcal://."),
    "Das Zertifikat des Servers passt nicht: {exc}": (
        "The server's certificate does not match: {exc}", "El certificado del servidor no coincide: {exc}"),
    "Trag die Adresse des Kalenders ein.": ("Enter the calendar's address.", "Introduce la dirección del calendario."),
    "Wähle einen Kalender aus Home Assistant.": (
        "Pick a calendar from Home Assistant.", "Elige un calendario de Home Assistant."),
    "Verbunden mit {name} (Home Assistant {version}), {n} Kalender.": (
        "Connected to {name} (Home Assistant {version}), {n} calendar(s).",
        "Conectado a {name} (Home Assistant {version}), {n} calendario(s)."),

    # Playlists, Szene, Takeover
    "Das Kalenderblatt des Monats mit einem Foto von früher.": (
        "The month's calendar page with a photo from back then.",
        "La hoja del calendario del mes con una foto de otros años."),
    "Der Rahmen hat die Playlist {name} nicht angelegt.": (
        "The frame did not create the playlist {name}.", "El marco no ha creado la lista {name}."),
    "Die Szene ist auf diesem Rahmen nicht installiert. Installiere das Paket noch einmal.": (
        "The scene is not installed on this frame. Install the pack again.",
        "La escena no está instalada en este marco. Vuelve a instalar el paquete."),
    "Die Szene Calendar Page ist auf der Plugins-Seite ausgeschaltet.": (
        "The Calendar Page scene is switched off on the Plugins page.",
        "La escena Calendar Page está desactivada en la página de plugins."),
    "Die Szene wurde nicht gefunden.": ("The scene was not found.", "No se ha encontrado la escena."),
    "Konnte die Takeover-Playlist nicht anlegen: {exc}": (
        "Could not create the takeover playlist: {exc}", "No se ha podido crear la lista de toma de pantalla: {exc}"),
    "Die Takeover-Playlist ist noch nicht angelegt.": (
        "The takeover playlist has not been created yet.", "La lista de toma de pantalla aún no se ha creado."),
    "Dieser Rahmen ist zu alt, um ein Plugin den Bildschirm übernehmen zu lassen.": (
        "This frame is too old to let a plugin take over the screen.",
        "Este marco es demasiado antiguo para que un plugin tome la pantalla."),
    "Calendar Page ist auf der Plugins-Seite ausgeschaltet.": (
        "Calendar Page is switched off on the Plugins page.",
        "Calendar Page está desactivado en la página de plugins."),
    "„Allow takeover“ ist für Calendar Page auf der Plugins-Seite aus. Schalte es ein, sonst kann das Blatt nicht über die Playlist gelegt werden.": (
        "“Allow takeover” is off for Calendar Page on the Plugins page. Switch it on, otherwise the page cannot be "
        "put over the playlist.",
        "«Allow takeover» está desactivado para Calendar Page en la página de plugins. Actívalo; si no, la hoja "
        "no se puede poner sobre la lista."),
    "Der Bildschirm ist aus; das Blatt wartet, bis er wieder an ist.": (
        "The screen is off; the page waits until it is on again.",
        "La pantalla está apagada; la hoja espera a que vuelva a encenderse."),
    "Konnte das Blatt nicht zeigen: {exc}": ("Could not show the page: {exc}", "No se ha podido mostrar la hoja: {exc}"),
    "Gerade hat etwas anderes den Bildschirm.": (
        "Something else has the screen right now.", "Ahora mismo otra cosa ocupa la pantalla."),
    "Der Rahmen hat das Blatt nicht rechtzeitig gezeigt.": (
        "The frame did not show the page in time.", "El marco no ha mostrado la hoja a tiempo."),
    "Das Blatt kommt gleich auf den Bildschirm.": (
        "The page is coming to the screen in a moment.", "La hoja aparecerá enseguida en la pantalla."),

    # Verbindungen
    "DynaFrame auf diesem Rahmen": ("DynaFrame on this frame", "DynaFrame en este marco"),
    "Nicht erreichbar: {exc}": ("Not reachable: {exc}", "No accesible: {exc}"),
    "Starte den Rahmen neu, wenn das rot bleibt.": (
        "Restart the frame if this stays red.", "Reinicia el marco si sigue en rojo."),
    "Erreichbar ({ms} ms).": ("Reachable ({ms} ms).", "Accesible ({ms} ms)."),
    "Erreichbar ({ms} ms), Immich {version}.": ("Reachable ({ms} ms), Immich {version}.", "Accesible ({ms} ms), Immich {version}."),
    "Erreichbar ({ms} ms), Home Assistant {version}.": (
        "Reachable ({ms} ms), Home Assistant {version}.", "Accesible ({ms} ms), Home Assistant {version}."),
    "Deine Fotos": ("Your photos", "Tus fotos"),
    "Werden zum ersten Mal eingelesen: {done} von {todo} Dateien, {n} Fotos mit Datum bisher.": (
        "Being read for the first time: {done} of {todo} files, {n} photos with a date so far.",
        "Leyéndose por primera vez: {done} de {todo} archivos, {n} fotos con fecha hasta ahora."),
    "Das erste Einlesen liest das Aufnahmedatum aus jeder Datei, die DynaFrame ohne Datum liefert. Danach geht es schnell.": (
        "The first reading takes the date taken from every file DynaFrame delivers without a date. After that it is quick.",
        "La primera lectura saca la fecha de toma de cada archivo que DynaFrame entrega sin fecha. Después va rápido."),
    "Werden gerade zum ersten Mal eingelesen …": ("Being read for the first time …", "Leyéndose por primera vez …"),
    "{n} Quelle(n) mit Fehler: {exc}": ("{n} source(s) with an error: {exc}", "{n} fuente(s) con error: {exc}"),
    "Sieh in der Karte „Fotos“ nach.": ("Look at the “Photos” card.", "Mira la tarjeta «Fotos»."),
    "Noch nicht eingelesen.": ("Not read yet.", "Aún no leídas."),
    "Keine Fotos mit Datum gefunden.": ("No photos with a date found.", "No se han encontrado fotos con fecha."),
    "Prüfe die Quellen und Filter.": ("Check the sources and filters.", "Revisa las fuentes y los filtros."),
    "{n} Fotos mit Datum; für diesen Monat {m} aus {y} Jahren.": (
        "{n} photos with a date; for this month {m} from {y} years.",
        "{n} fotos con fecha; para este mes {m} de {y} años."),
    "Ohne Fotos aus diesem Monat zeigt das Blatt nur den Kalender.": (
        "Without photos from this month the page only shows the calendar.",
        "Sin fotos de este mes la hoja solo muestra el calendario."),
    "Adresse oder API-Schlüssel fehlt.": ("Address or API key missing.", "Falta la dirección o la clave API."),
    "Trag sie in der Karte „Immich-Server“ ein.": ("Enter them in the “Immich server” card.", "Introdúcelas en la tarjeta «Servidor Immich»."),
    "{n} Personen mit Geburtsdatum.": ("{n} people with a birthday.", "{n} personas con fecha de nacimiento."),
    "Kalender „{name}“": ("Calendar “{name}”", "Calendario «{name}»"),
    "Noch nicht geladen.": ("Not loaded yet.", "Aún no cargado."),
    "{n} Termine geladen ({ms} ms).": ("{n} appointments loaded ({ms} ms).", "{n} citas cargadas ({ms} ms)."),
    "Schulferien (OpenHolidays)": ("School holidays (OpenHolidays)", "Vacaciones escolares (OpenHolidays)"),
    "Für dieses Land gibt es keine Schulferien bei OpenHolidays.": (
        "OpenHolidays has no school holidays for this country.",
        "OpenHolidays no tiene vacaciones escolares para este país."),
    "{host} ist nicht erreichbar: {exc}": ("{host} cannot be reached: {exc}", "No se puede acceder a {host}: {exc}"),
    "Steht ein Werbeblocker wie Pi-hole dazwischen? Dann {host} erlauben.": (
        "Is an ad blocker like Pi-hole in the way? Then allow {host}.",
        "¿Hay un bloqueador como Pi-hole por medio? Entonces permite {host}."),
    "Wähle dein Bundesland oder deine Region, sonst fehlen die regionalen Ferien.": (
        "Pick your state or region, otherwise the regional holidays are missing.",
        "Elige tu comunidad o región; si no, faltan las vacaciones regionales."),
    "{n} Ferienzeiten in den nächsten Wochen.": (
        "{n} holiday periods in the coming weeks.", "{n} periodos de vacaciones en las próximas semanas."),
    "Blatt über die Playlist legen": ("Put the page over the playlist", "Poner la hoja sobre la lista"),
    "Erlaubt, die Szene ist installiert.": ("Allowed, the scene is installed.", "Permitido, la escena está instalada."),
    "Prüfung": ("Check", "Comprobación"),
}


def t(lang, template, **values):
    text = template
    if lang in LANGUAGES and lang != "de":
        row = _TEXTS.get(template)
        if row:
            text = row[LANGUAGES.index(lang) - 1]
    try:
        return text.format(**values) if values else text
    except (KeyError, IndexError, ValueError):
        return text
