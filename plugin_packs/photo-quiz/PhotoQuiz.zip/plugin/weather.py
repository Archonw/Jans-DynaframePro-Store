"""Wetter und Ortsnamen: Open-Meteo (ohne Schlüssel) und Nominatim.

- then(lat, lon, day, hour): das Wetter an einem Tag in der Vergangenheit
  (Open-Meteo Historical Weather API, ERA5, ab 1940). Ändert sich nie, darum
  bleibt es für immer im Cache (data/weather.json).
- today(lat, lon): das Wetter jetzt (Open-Meteo Forecast API), 30 Minuten im Cache.
- search(name, lang): Orte für die Plugin-Seite (Open-Meteo Geocoding API).
- place(lat, lon, lang): ein Ortsname zu Koordinaten (Nominatim, höchstens
  eine Anfrage pro Sekunde, für immer im Cache).

Die Adressen lassen sich für Tests über Umgebungsvariablen umbiegen.
"""

import json
import os
import threading
import time
from pathlib import Path

import requests

ARCHIVE = os.environ.get("OTD_ARCHIVE_URL", "https://archive-api.open-meteo.com/v1/archive")
FORECAST = os.environ.get("OTD_FORECAST_URL", "https://api.open-meteo.com/v1/forecast")
GEOCODE = os.environ.get("OTD_GEOCODE_URL", "https://geocoding-api.open-meteo.com/v1/search")
REVERSE = os.environ.get("OTD_REVERSE_URL", "https://nominatim.openstreetmap.org/reverse")
USER_AGENT = "DynaFrame-PhotoQuiz/0.1 (+https://github.com/Archonw/Jans-DynaframePro-Store)"
TIMEOUT = (10, 30)
TODAY_SECONDS = 1800
MAX_CACHE = 20000


class WeatherError(Exception):
    pass


def _round(value, step=0.1):
    return round(round(float(value) / step) * step, 4)


def _num(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return None if number != number else number


class Weather:
    def __init__(self, data_dir, log):
        self.file = Path(data_dir) / "weather.json"
        self.places_file = Path(data_dir) / "places.json"
        self.log = log
        self.lock = threading.Lock()
        self.cache = None
        self.places = None
        self.dirty = False
        self.places_dirty = False
        self.live = {}           # "lat,lon" -> (time, payload)
        self.last_reverse = 0.0
        self.reverse_lock = threading.Lock()
        self.session = requests.Session()
        self.session.headers["User-Agent"] = USER_AGENT
        self.failures = 0
        self.last_error = ""

    # ------------------------------------------------------------ Cache

    def _load(self):
        if self.cache is None:
            self.cache = self._read(self.file)
        if self.places is None:
            self.places = self._read(self.places_file)

    @staticmethod
    def _read(path):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    @staticmethod
    def _write(path, payload):
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix(path.suffix + f".{threading.get_ident()}.tmp")
        temp.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        temp.replace(path)

    def save(self):
        with self.lock:
            self._load()
            if self.dirty:
                if len(self.cache) > MAX_CACHE:
                    for key in list(self.cache)[: len(self.cache) - MAX_CACHE]:
                        del self.cache[key]
                self._write(self.file, self.cache)
                self.dirty = False
            if self.places_dirty:
                self._write(self.places_file, self.places)
                self.places_dirty = False

    def _get(self, url, params):
        try:
            response = self.session.get(url, params=params, timeout=TIMEOUT)
        except requests.RequestException as exc:
            self.failures += 1
            self.last_error = str(exc)[:200]
            raise WeatherError(str(exc)[:200]) from exc
        if response.status_code >= 400:
            self.failures += 1
            detail = ""
            try:
                detail = (response.json() or {}).get("reason") or ""
            except ValueError:
                pass
            self.last_error = f"HTTP {response.status_code} {detail}".strip()
            raise WeatherError(self.last_error)
        try:
            data = response.json()
        except ValueError as exc:
            raise WeatherError("keine JSON-Antwort") from exc
        self.failures = 0
        self.last_error = ""
        return data

    # ------------------------------------------------------------ damals

    def then(self, lat, lon, day, hour=12):
        """{"t", "code", "day", "tmax", "tmin", "rain", "sun", "wind"} oder None (Archiv kennt den Tag noch nicht)."""
        lat, lon = _round(lat), _round(lon)
        key = f"{lat},{lon},{day}"
        with self.lock:
            self._load()
            row = self.cache.get(key)
        if row is None:
            data = self._get(ARCHIVE, {
                "latitude": lat, "longitude": lon, "start_date": day, "end_date": day, "timezone": "auto",
                "hourly": "temperature_2m,weather_code,is_day,precipitation,cloud_cover,wind_speed_10m",
                "daily": "temperature_2m_max,temperature_2m_min,weather_code,precipitation_sum,sunshine_duration",
            })
            row = self._pack_then(data)
            with self.lock:
                self.cache[key] = row
                self.dirty = True
        if not row:
            return None
        hours = row.get("h") or []
        hour = max(0, min(23, int(hour)))
        at = hours[hour] if hour < len(hours) else None
        out = dict(row["d"])
        if at:
            out.update(t=at[0], code=at[1], isDay=at[2], wind=at[3])
        else:
            out.update(t=out.get("tmax"), code=out.get("dcode"), isDay=1, wind=None)
        return out if out.get("t") is not None else None

    @staticmethod
    def _pack_then(data):
        hourly = data.get("hourly") or {}
        daily = data.get("daily") or {}
        temps = hourly.get("temperature_2m") or []
        if not any(_num(t) is not None for t in temps):
            return {}          # noch nicht im Archiv (die letzten Tage)
        codes = hourly.get("weather_code") or []
        days = hourly.get("is_day") or []
        winds = hourly.get("wind_speed_10m") or []
        hours = []
        for i in range(min(24, len(temps))):
            hours.append([_num(temps[i]), int(_num(codes[i]) or 0) if i < len(codes) else 0,
                          int(_num(days[i]) or 0) if i < len(days) else 1,
                          _num(winds[i]) if i < len(winds) else None])

        def first(name):
            values = daily.get(name) or []
            return _num(values[0]) if values else None

        sun = first("sunshine_duration")
        return {"h": hours, "d": {"tmax": first("temperature_2m_max"), "tmin": first("temperature_2m_min"),
                                  "dcode": int(first("weather_code") or 0), "rain": first("precipitation_sum"),
                                  "sun": round(sun / 3600, 1) if sun is not None else None}}

    # ------------------------------------------------------------ heute

    def today(self, lat, lon):
        lat, lon = _round(lat, 0.05), _round(lon, 0.05)
        key = f"{lat},{lon}"
        hit = self.live.get(key)
        if hit and time.time() - hit[0] < TODAY_SECONDS:
            return hit[1]
        try:
            data = self._get(FORECAST, {
                "latitude": lat, "longitude": lon, "timezone": "auto", "forecast_days": 1,
                "current": "temperature_2m,weather_code,is_day,wind_speed_10m,precipitation",
                "daily": "temperature_2m_max,temperature_2m_min,weather_code,precipitation_sum,sunshine_duration",
            })
        except WeatherError:
            if hit:
                return hit[1]
            raise
        current = data.get("current") or {}
        daily = data.get("daily") or {}

        def first(name):
            values = daily.get(name) or []
            return _num(values[0]) if values else None

        sun = first("sunshine_duration")
        payload = {"t": _num(current.get("temperature_2m")), "code": int(_num(current.get("weather_code")) or 0),
                   "isDay": int(_num(current.get("is_day")) if current.get("is_day") is not None else 1),
                   "wind": _num(current.get("wind_speed_10m")),
                   "tmax": first("temperature_2m_max"), "tmin": first("temperature_2m_min"),
                   "dcode": int(first("weather_code") or 0), "rain": first("precipitation_sum"),
                   "sun": round(sun / 3600, 1) if sun is not None else None}
        if payload["t"] is None:
            raise WeatherError("keine aktuellen Werte")
        self.live[key] = (time.time(), payload)
        return payload

    # ------------------------------------------------------------ Orte

    def search(self, name, lang):
        data = self._get(GEOCODE, {"name": name, "count": 8, "language": lang, "format": "json"})
        out = []
        for row in data.get("results") or []:
            lat, lon = _num(row.get("latitude")), _num(row.get("longitude"))
            if lat is None or lon is None:
                continue
            region = ", ".join(str(x) for x in (row.get("admin1"), row.get("country")) if x)
            out.append({"name": row.get("name") or "?", "region": region, "lat": round(lat, 4), "lon": round(lon, 4)})
        return out

    def place(self, lat, lon, lang, allow_fetch=True):
        """Ortsname (Stadt, Land) oder ""."""
        lat2, lon2 = _round(lat, 0.01), _round(lon, 0.01)
        key = f"{lat2},{lon2},{lang}"
        with self.lock:
            self._load()
            if key in self.places:
                return self.places[key]
        if not allow_fetch:
            return ""
        with self.reverse_lock:
            wait = 1.1 - (time.time() - self.last_reverse)
            if wait > 0:
                time.sleep(wait)
            self.last_reverse = time.time()
            try:
                data = self._get(REVERSE, {"lat": lat2, "lon": lon2, "format": "jsonv2", "zoom": 10,
                                           "accept-language": lang})
            except WeatherError as exc:
                self.log(f"Ortsname {lat2},{lon2}: {exc}", "warning")
                return ""
        address = data.get("address") or {}
        city = next((address.get(k) for k in ("city", "town", "village", "municipality", "hamlet", "county",
                                               "state_district", "state") if address.get(k)), "")
        country = address.get("country") or ""
        name = ", ".join(x for x in (city, country) if x) or str(data.get("name") or "")
        with self.lock:
            self.places[key] = name[:80]
            self.places_dirty = True
        return name[:80]
