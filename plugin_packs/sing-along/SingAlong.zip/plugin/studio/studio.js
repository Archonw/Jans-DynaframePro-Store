"use strict";

// Immer "./api/...": die Weboberfläche liefert diese Seite unter
// /Plugins/Advanced/SingAlong/ aus, ohne <base>.

const el = (id) => document.getElementById(id);
const NUMBER_FIELDS = ["PauseSeconds", "QuietFrom", "QuietTo", "OffsetMs", "PlaylistSeconds"];
const CHECK_FIELDS = ["OnlyWithLyrics", "WakeScreen", "QuietEnabled", "ShowProgress", "Karaoke", "SpotifyHere"];
const SELECT_FIELDS = ["ShowMode", "Source", "Look", "TextSize"];
const TEXT_FIELDS = ["MaUrl", "JellyfinUrl", "JellyfinUser", "SpotifyClientId"];
const SECRET_FIELDS = ["MaToken", "JellyfinKey"];
let current = null;
let editing = false;

const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  name: ["Sing-along", "Sing-along", "Sing-along"],
  lede: ["Karaoke ganz nebenbei: Läuft Musik über Music Assistant, Spotify oder Jellyfin, zeigt der Rahmen den Liedtext zeilengenau im Takt, mit Cover und Fortschritt. Die Texte kommen von LRCLIB, kostenlos und ohne Schlüssel. Jede Änderung hier wird sofort gespeichert.",
    "Karaoke on the side: while music plays via Music Assistant, Spotify or Jellyfin, the frame shows the lyrics line by line in time with the song, with the cover and the progress. The lyrics come from LRCLIB, free and without a key. Every change here is saved right away.",
    "Karaoke de paso: cuando suena música por Music Assistant, Spotify o Jellyfin, el marco muestra la letra línea a línea al ritmo de la canción, con la portada y el progreso. Las letras vienen de LRCLIB, gratis y sin clave. Cada cambio aquí se guarda al momento."],
  language: ["Sprache", "Language", "Idioma"],
  status: ["Status", "Status", "Estado"],
  showNow: ["Jetzt zeigen", "Show now", "Mostrar ahora"],
  hide: ["Ausblenden", "Hide", "Ocultar"],
  factTrack: ["Läuft gerade", "Playing now", "Suena ahora"],
  factSource: ["Quelle", "Source", "Fuente"],
  factLyrics: ["Liedtext", "Lyrics", "Letra"],
  factScreen: ["Auf dem Bildschirm", "On screen", "En pantalla"],
  factVersion: ["Version", "Version", "Versión"],
  nothing: ["Gerade läuft nichts.", "Nothing is playing right now.", "Ahora no suena nada."],
  paused: ["pausiert", "paused", "en pausa"],
  lyr_synced: ["zeilengenau ({n} Zeilen)", "synced ({n} lines)", "sincronizada ({n} líneas)"],
  lyr_plain: ["nur Text, ohne Zeiten", "text only, no timing", "solo texto, sin tiempos"],
  lyr_instrumental: ["Instrumental", "Instrumental", "Instrumental"],
  lyr_none: ["nicht gefunden", "not found", "no encontrada"],
  lyr_loading: ["wird gesucht …", "searching …", "buscando …"],
  lyr_error: ["LRCLIB nicht erreichbar", "LRCLIB not reachable", "LRCLIB no accesible"],
  lyr_idle: ["—", "—", "—"],
  yes: ["ja", "yes", "sí"],
  no: ["nein", "no", "no"],
  hidden: ["ausgeblendet bis zu einer Musikpause", "hidden until the music pauses", "oculta hasta que pare la música"],
  quietNow: ["Ruhezeit", "quiet hours", "horas de silencio"],
  again: ["Liedtext neu suchen", "Look up the lyrics again", "Buscar la letra otra vez"],
  nowLine: ["Gerade gesungen", "Being sung now", "Se canta ahora"],
  matched: ["Gefunden als: {title} von {artist}", "Found as: {title} by {artist}", "Encontrada como: {title} de {artist}"],

  servicesTitle: ["Verbindungen", "Connections", "Conexiones"],
  servicesCheck: ["Jetzt prüfen", "Check now", "Comprobar ahora"],
  servicesHint: ["Alles, was Sing-along braucht. Das Plugin prüft es alle fünf Minuten selbst; rot heißt, dass etwas fehlt, gelb, dass es nur teilweise geht. Eine Musikquelle reicht.",
    "Everything Sing-along needs. The plugin checks it by itself every five minutes; red means something is missing, yellow that it only partly works. One music source is enough.",
    "Todo lo que necesita Sing-along. El plugin lo comprueba solo cada cinco minutos; rojo significa que falta algo, amarillo que solo funciona en parte. Basta con una fuente de música."],
  servicesWait: ["Wird geprüft …", "Checking …", "Comprobando …"],
  servicesAllOk: ["Alles erreichbar, zuletzt geprüft {time}.", "Everything reachable, last checked {time}.", "Todo accesible, última comprobación {time}."],
  servicesSome: ["Nicht alles in Ordnung, zuletzt geprüft {time}.", "Not everything is fine, last checked {time}.", "No todo está bien, última comprobación {time}."],
  svc_ok: ["OK", "OK", "OK"],
  svc_warn: ["Teilweise", "Partly", "En parte"],
  svc_bad: ["Problem", "Problem", "Problema"],
  svc_off: ["Nicht eingerichtet", "Not set up", "Sin configurar"],

  whenTitle: ["Wann der Liedtext erscheint", "When the lyrics appear", "Cuándo aparece la letra"],
  whenHint: ["Von selbst heißt: Sobald ein Lied mit Liedtext läuft, schiebt sich die Szene über die laufende Playlist und gibt den Bildschirm zurück, wenn die Musik aufhört. Dafür muss auf der Seite Plugins bei Sing-along „Takeover erlauben“ an sein.",
    "By itself means: as soon as a song with lyrics plays, the scene slides over the running playlist and hands the screen back when the music stops. For this, “Allow takeover” must be on for Sing-along on the Plugins page.",
    "Sola significa: en cuanto suena una canción con letra, la escena se pone sobre la lista en curso y devuelve la pantalla cuando para la música. Para ello, “Permitir takeover” debe estar activado para Sing-along en la página Plugins."],
  showMode: ["Liedtext zeigen", "Show the lyrics", "Mostrar la letra"],
  mode_auto: ["Von selbst, wenn Musik läuft", "By itself while music plays", "Sola cuando suena música"],
  mode_playlist: ["Nur in einer Playlist mit der Szene", "Only in a playlist with the scene", "Solo en una lista con la escena"],
  source: ["Welche Musik", "Which music", "Qué música"],
  src_auto: ["Alles, was gerade läuft", "Whatever is playing", "Lo que esté sonando"],
  src_ma: ["Nur Music Assistant", "Music Assistant only", "Solo Music Assistant"],
  src_spotifyhere: ["Nur Spotify auf diesem Rahmen", "Spotify on this frame only", "Solo Spotify en este marco"],
  src_spotify: ["Nur Spotify-Konto", "Spotify account only", "Solo la cuenta de Spotify"],
  src_jellyfin: ["Nur Jellyfin", "Jellyfin only", "Solo Jellyfin"],
  pauseSeconds: ["Bildschirm zurückgeben nach … Sekunden Pause", "Hand the screen back after … seconds of silence", "Devolver la pantalla tras … segundos de pausa"],
  onlyLyrics: ["Nur bei Liedern mit Liedtext", "Only for songs with lyrics", "Solo canciones con letra"],
  wake: ["Bildschirm dafür aufwecken", "Wake the screen for it", "Despertar la pantalla"],
  quiet: ["Ruhezeit (dann nicht von selbst)", "Quiet hours (not by itself then)", "Horas de silencio (entonces no sola)"],
  quietFrom: ["Ruhe ab (Uhr)", "Quiet from (hour)", "Silencio desde (hora)"],
  quietTo: ["Ruhe bis (Uhr)", "Quiet until (hour)", "Silencio hasta (hora)"],

  lookTitle: ["Aussehen", "Look", "Aspecto"],
  look: ["Ansicht", "Layout", "Vista"],
  look_cover: ["Cover links, Text rechts", "Cover on the left, lyrics on the right", "Portada a la izquierda, letra a la derecha"],
  look_backdrop: ["Cover als Hintergrund, Text in der Mitte", "Cover as background, lyrics in the middle", "Portada de fondo, letra en el centro"],
  look_lyrics: ["Nur der Liedtext, ganz groß", "Lyrics only, extra large", "Solo la letra, muy grande"],
  textSize: ["Schriftgröße", "Text size", "Tamaño del texto"],
  size_small: ["Klein", "Small", "Pequeño"],
  size_normal: ["Normal", "Normal", "Normal"],
  size_large: ["Groß", "Large", "Grande"],
  showProgress: ["Fortschritt mit Zeit zeigen", "Show progress and time", "Mostrar progreso y tiempo"],
  karaoke: ["Aktuelle Zeile wie beim Karaoke einfärben", "Colour the current line like karaoke", "Colorear la línea actual como en el karaoke"],
  offset: ["Liedtext verschieben (Millisekunden, plus = früher)", "Shift the lyrics (milliseconds, plus = earlier)", "Desplazar la letra (milisegundos, más = antes)"],
  offsetHint: ["Läuft der Text dem Gesang hinterher, z. B. weil die Lautsprecher verzögern, stell hier 300 bis 1000 ein.",
    "If the lyrics lag behind the singing, for example because the speakers add a delay, set 300 to 1000 here.",
    "Si la letra va detrás del canto, p. ej. porque los altavoces retrasan, pon aquí de 300 a 1000."],
  cacheTitle: ["Gemerkte Liedtexte", "Remembered lyrics", "Letras guardadas"],
  cacheText: ["{n} Lieder sind auf dem Rahmen gemerkt, damit LRCLIB nur einmal gefragt wird.", "{n} songs are remembered on the frame so LRCLIB is asked only once.", "{n} canciones guardadas en el marco para preguntar a LRCLIB solo una vez."],
  clearCache: ["Alle vergessen", "Forget all", "Olvidar todas"],

  maTitle: ["Music Assistant", "Music Assistant", "Music Assistant"],
  maHint: ["Adresse deines Music Assistant (Port 8095) und ein Token. Steht beides schon in Playlist Music, nimmt Sing-along es von dort, solange die Felder leer sind.",
    "Address of your Music Assistant (port 8095) and a token. If Playlist Music already has both, Sing-along uses them as long as these fields are empty.",
    "Dirección de tu Music Assistant (puerto 8095) y un token. Si Playlist Music ya los tiene, Sing-along los usa mientras estos campos estén vacíos."],
  address: ["Adresse", "Address", "Dirección"],
  token: ["Token", "Token", "Token"],
  player: ["Player", "Player", "Reproductor"],
  anyPlayer: ["Jeder Player, der gerade spielt", "Any player that is playing", "Cualquier reproductor que suene"],
  test: ["Verbindung testen", "Test connection", "Probar la conexión"],
  secretSaved: ["gespeichert (leer lassen zum Behalten)", "saved (leave empty to keep)", "guardado (deja vacío para mantenerlo)"],
  secretMissing: ["noch keiner", "none yet", "ninguno todavía"],
  borrowed: ["Wird gerade aus {plugin} genommen.", "Currently taken from {plugin}.", "Ahora se toma de {plugin}."],

  spotifyTitle: ["Spotify", "Spotify", "Spotify"],
  spotifyHere: ["Spotify auf diesem Rahmen erkennen (über Playlist Music)", "Recognise Spotify on this frame (via Playlist Music)", "Reconocer Spotify en este marco (con Playlist Music)"],
  spotifyHereHint: ["Spielt der Rahmen selbst Spotify ab (Spotify Connect aus Playlist Music), braucht es nichts weiter.",
    "If the frame plays Spotify itself (Spotify Connect from Playlist Music), nothing else is needed.",
    "Si el marco reproduce Spotify él mismo (Spotify Connect de Playlist Music), no hace falta nada más."],
  spotifyAccount: ["Spotify-Konto (Handy, Echo, Rechner)", "Spotify account (phone, Echo, computer)", "Cuenta de Spotify (móvil, Echo, ordenador)"],
  spotifyAccountHint: ["Damit sieht Sing-along auch, was auf deinen anderen Geräten läuft. Dafür brauchst du eine eigene kleine Spotify-App (kostenlos, siehe unten).",
    "With this Sing-along also sees what plays on your other devices. You need your own small Spotify app for it (free, see below).",
    "Así Sing-along también ve lo que suena en tus otros dispositivos. Necesitas tu propia pequeña app de Spotify (gratis, ver abajo)."],
  clientId: ["Client ID deiner Spotify-App", "Client ID of your Spotify app", "Client ID de tu app de Spotify"],
  spotifyLogin: ["Bei Spotify anmelden", "Sign in with Spotify", "Iniciar sesión en Spotify"],
  spotifyPaste: ["Adresse aus der Adresszeile nach der Anmeldung", "Address from the address bar after signing in", "Dirección de la barra tras iniciar sesión"],
  spotifyFinish: ["Anmeldung abschließen", "Finish signing in", "Terminar el inicio de sesión"],
  spotifyForget: ["Abmelden", "Sign out", "Cerrar sesión"],
  spotifySignedIn: ["Angemeldet.", "Signed in.", "Sesión iniciada."],
  spotifyNotSignedIn: ["Noch nicht angemeldet.", "Not signed in yet.", "Sin iniciar sesión."],
  spotifyOpened: ["Spotify ist in einem neuen Tab offen. Nach der Anmeldung zeigt der Browser eine Fehlerseite: Das ist richtig. Kopiere die ganze Adresse aus der Adresszeile hier hinein.",
    "Spotify is open in a new tab. After signing in the browser shows an error page: that is expected. Copy the whole address from the address bar into this field.",
    "Spotify está abierto en otra pestaña. Tras iniciar sesión el navegador muestra una página de error: es lo esperado. Copia aquí la dirección completa de la barra."],
  spotifyHowTo: ["So bekommst du eine Client ID", "How to get a Client ID", "Cómo obtener un Client ID"],
  spotifyHowToText: ["1. Auf <b>developer.spotify.com/dashboard</b> mit deinem Spotify-Konto anmelden und <b>Create app</b> wählen.<br>2. Name und Beschreibung frei, bei <b>Redirect URIs</b> genau <code>http://127.0.0.1:8888/callback</code> eintragen, <b>Web API</b> ankreuzen, speichern.<br>3. Die <b>Client ID</b> aus den Einstellungen der App kopieren und oben eintragen (kein Client Secret nötig).<br>4. <b>Bei Spotify anmelden</b> drücken, zustimmen, danach die Adresse aus der Adresszeile oben einfügen.<br>Eine eigene App im Entwicklungsmodus gilt nur für Konten, die du dort unter <b>User Management</b> einträgst; dein eigenes ist schon dabei.",
    "1. Sign in to <b>developer.spotify.com/dashboard</b> with your Spotify account and choose <b>Create app</b>.<br>2. Any name and description; under <b>Redirect URIs</b> enter exactly <code>http://127.0.0.1:8888/callback</code>, tick <b>Web API</b>, save.<br>3. Copy the <b>Client ID</b> from the app's settings into the field above (no client secret needed).<br>4. Press <b>Sign in with Spotify</b>, agree, then paste the address from the address bar above.<br>An app in development mode only works for accounts you add under <b>User Management</b>; your own is already included.",
    "1. Inicia sesión en <b>developer.spotify.com/dashboard</b> con tu cuenta de Spotify y elige <b>Create app</b>.<br>2. Nombre y descripción libres; en <b>Redirect URIs</b> escribe exactamente <code>http://127.0.0.1:8888/callback</code>, marca <b>Web API</b> y guarda.<br>3. Copia el <b>Client ID</b> de los ajustes de la app en el campo de arriba (no hace falta client secret).<br>4. Pulsa <b>Iniciar sesión en Spotify</b>, acepta y pega arriba la dirección de la barra.<br>Una app en modo de desarrollo solo sirve para las cuentas que añadas en <b>User Management</b>; la tuya ya está."],

  jfTitle: ["Jellyfin", "Jellyfin", "Jellyfin"],
  jfHint: ["Adresse deines Jellyfin-Servers (Port 8096) und ein API-Schlüssel (Dashboard > API-Schlüssel). Steht beides schon in Jellyfin Now Playing oder Playlist Music, nimmt Sing-along es von dort, solange die Felder leer sind.",
    "Address of your Jellyfin server (port 8096) and an API key (Dashboard > API Keys). If Jellyfin Now Playing or Playlist Music already has both, Sing-along uses them as long as these fields are empty.",
    "Dirección de tu servidor Jellyfin (puerto 8096) y una clave API (Panel > Claves API). Si Jellyfin Now Playing o Playlist Music ya los tienen, Sing-along los usa mientras estos campos estén vacíos."],
  apiKey: ["API-Schlüssel", "API key", "Clave API"],
  jfUser: ["Nur Musik von diesem Benutzer (leer = alle)", "Only music of this user (empty = everyone)", "Solo la música de este usuario (vacío = todos)"],

  playlistTitle: ["Eine Playlist dafür", "A playlist for it", "Una lista para ello"],
  makePlaylist: ["Playlist „Sing-along“ anlegen", "Create the “Sing-along” playlist", "Crear la lista “Sing-along”"],
  no2: ["Nein", "No", "No"],
  yesCreate: ["Ja, anlegen", "Yes, create it for me", "Sí, créala"],
  playlistSeconds: ["Dauer der Szene (Sekunden)", "Scene duration (seconds)", "Duración de la escena (segundos)"],
  playlistHint: ["Die Playlist enthält nur die Szene (Sing-along) und ist eingeschaltet. Läuft keine Musik, zeigt die Szene das an und wartet. Du kannst die Szene auch selbst in jede Playlist aufnehmen.",
    "The playlist contains only the scene (Sing-along) and is switched on. When no music plays, the scene says so and waits. You can also add the scene to any playlist yourself.",
    "La lista solo contiene la escena (Sing-along) y está activada. Si no suena música, la escena lo indica y espera. También puedes añadir la escena a cualquier lista."],

  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or feature requests?", "¿Problemas, preguntas o sugerencias?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre una incidencia en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", " with the plugin name and version.", " con el nombre y la versión del plugin."],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}).", "The plugin is restarting (HTTP {status}).", "El plugin se está reiniciando (HTTP {status})."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  oclock: ["{time} Uhr", "{time}", "{time}"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  loading: ["Lade …", "Loading …", "Cargando …"],
};
const LANGS = ["de", "en", "es"];
const LOCALES = { de: "de-DE", en: "en-GB", es: "es-ES" };
let lang = document.documentElement.lang || "de";

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[0]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? `{${name}}`));
}

function applyLanguage(next) {
  const chosen = LANGS.includes(next) ? next : "de";
  if (chosen === lang && document.documentElement.lang === chosen) return;
  lang = chosen;
  document.documentElement.lang = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  for (const node of document.querySelectorAll("[data-i18n-html]")) node.innerHTML = t(node.dataset.i18nHtml);
  for (const node of document.querySelectorAll("[data-i18n-placeholder]")) node.placeholder = t(node.dataset.i18nPlaceholder);
  if (current) render(current);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) throw new Error(payload.error || t("error", { status: response.status }));
  return payload;
}

function setStatus(text, tone = "", id = "statusNote") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function sticky(id, text, tone, ms = 8000) {
  el(id).dataset.sticky = "1";
  setStatus(text, tone, id);
  clearTimeout(el(id)._timer);
  el(id)._timer = setTimeout(() => { delete el(id).dataset.sticky; refresh(); }, ms);
}

function clock(epoch) {
  if (!epoch) return "—";
  const date = new Date(epoch * 1000);
  const sameDay = date.toDateString() === new Date().toDateString();
  const locale = LOCALES[lang];
  const time = t("oclock", { time: date.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) });
  return sameDay ? time : `${date.toLocaleDateString(locale, { day: "2-digit", month: "2-digit" })} ${time}`;
}

const esc = (text) => String(text).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const mmss = (s) => { s = Math.max(0, Math.round(s || 0)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`; };

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

async function save(changes) {
  try {
    const result = await api("./api/settings", { method: "POST", body: JSON.stringify(changes) });
    if (!el("statusNote").dataset.sticky) setStatus(t("saved"), "ok");
    await refresh();
    return result.changed || [];
  } catch (error) {
    setStatus(error.message, "bad");
    return [];
  }
}

// ------------------------------------------------------------ Stand

function renderPlayers(state) {
  const select = el("MaPlayer");
  if (document.activeElement === select) return;
  const names = state.ma.players || [];
  const want = state.settings.MaPlayer || "";
  const options = [["", t("anyPlayer")]].concat(names.map((n) => [n, n]));
  if (want && !names.includes(want)) options.push([want, want]);
  const html = options.map(([v, label]) => `<option value="${esc(v)}">${esc(label)}</option>`).join("");
  if (select.dataset.html !== html) { select.innerHTML = html; select.dataset.html = html; }
  select.value = want;
}

function render(state) {
  current = state;
  applyTheme(state.theme);
  const s = state.settings;
  applyLanguage(s.Language);
  const tr = state.track;
  el("factTrack").textContent = tr ? `${tr.title}${tr.artist ? " · " + tr.artist : ""}${tr.state === "paused" ? " (" + t("paused") + ")" : ""}` : t("nothing");
  el("factSource").textContent = tr ? `${tr.sourceLabel}${tr.player ? " · " + tr.player : ""}` : "—";
  const lk = (state.lyrics || {}).kind || "idle";
  el("factLyrics").textContent = tr ? t("lyr_" + lk, { n: state.lyrics.count }) : "—";
  el("factScreen").textContent = state.showing ? t("yes") : state.dismissed ? t("hidden") : state.quietNow ? t("quietNow") : t("no");
  el("factVersion").textContent = state.version;
  el("issueLink").href = "https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=" +
    encodeURIComponent(`[Sing-along ${state.version}] `);
  const line = (state.lyrics || {}).line || "";
  el("nowLine").hidden = !tr;
  const quote = { de: ["„", "“"], en: ["“", "”"], es: ["«", "»"] }[lang] || ["“", "”"];
  el("nowLineText").textContent = line ? `${quote[0]}${line}${quote[1]}` : (tr && lk === "synced" ? "♪" : "");
  el("nowLineTime").textContent = tr ? `${mmss(state.position)} / ${mmss(tr.duration)}` : "";
  const m = (state.lyrics || {}).matched || {};
  el("matchedNote").textContent = tr && m.title && (m.title.toLowerCase() !== tr.title.toLowerCase()) ? t("matched", { title: m.title, artist: m.artist }) : "";
  el("againButton").disabled = !tr;

  renderServices(state.services);
  const problem = state.permission || state.note || state.lastError || "";
  if (!el("statusNote").dataset.sticky) setStatus(problem, problem ? "bad" : "");
  setStatus(state.permission || "", state.permission ? "bad" : "", "permissionNote");
  el("cacheText").textContent = t("cacheText", { n: state.cache || 0 });
  el("playlistNote").textContent = state.ownPlaylist || "";
  if (document.activeElement !== el("MakePlaylist")) el("MakePlaylist").value = String(Boolean(s.MakePlaylist));

  if (!el("maNote").dataset.sticky) {
    const err = (state.sources.errors || {}).ma;
    setStatus(err || (state.ma.from && !s.MaUrl ? t("borrowed", { plugin: state.ma.from }) : ""), err ? "bad" : "", "maNote");
  }
  if (!el("jfNote").dataset.sticky) {
    const err = (state.sources.errors || {}).jellyfin;
    setStatus(err || (state.jellyfin.from && !s.JellyfinUrl ? t("borrowed", { plugin: state.jellyfin.from }) : ""), err ? "bad" : "", "jfNote");
  }
  if (!el("spotifyNote").dataset.sticky) {
    const err = (state.sources.errors || {}).spotify;
    setStatus(err || (s.SpotifyClientId ? (state.spotify.signedIn ? t("spotifySignedIn") : t("spotifyNotSignedIn")) : ""),
      err ? "bad" : state.spotify.signedIn ? "ok" : "", "spotifyNote");
  }
  el("spotifyForget").hidden = !state.spotify.signedIn;

  if (!editing) {
    for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS)) {
      if (document.activeElement !== el(name)) el(name).value = s[name] ?? "";
    }
    for (const name of CHECK_FIELDS) el(name).checked = Boolean(s[name]);
    for (const name of SELECT_FIELDS) if (document.activeElement !== el(name)) el(name).value = s[name];
    el("Language").value = lang;
    for (const name of SECRET_FIELDS) {
      if (document.activeElement !== el(name)) el(name).placeholder = state.secretsSet[name] ? t("secretSaved") : t("secretMissing");
    }
  }
  renderPlayers(state);
  const auto = s.ShowMode === "auto";
  for (const id of ["PauseSeconds", "OnlyWithLyrics", "WakeScreen", "QuietEnabled", "QuietFrom", "QuietTo"]) el(id).disabled = !auto;
}

async function refresh() {
  try {
    render(await api("./api/state"));
  } catch (error) {
    setStatus(error.message, "bad");
  }
}

for (const name of NUMBER_FIELDS.concat(TEXT_FIELDS, SECRET_FIELDS, ["SpotifyPaste"])) {
  const input = el(name);
  input.addEventListener("focus", () => { editing = true; });
  input.addEventListener("blur", () => { editing = false; });
}
for (const name of NUMBER_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: Number(e.target.value) }));
for (const name of CHECK_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.checked }));
for (const name of SELECT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of TEXT_FIELDS) el(name).addEventListener("change", (e) => save({ [name]: e.target.value }));
for (const name of SECRET_FIELDS) el(name).addEventListener("change", async (e) => {
  if (!e.target.value.trim()) return;
  await save({ [name]: e.target.value.trim() });
  e.target.value = "";
});
el("MaPlayer").addEventListener("change", (e) => save({ MaPlayer: e.target.value }));
el("Language").addEventListener("change", (e) => {
  // Wert zuerst merken: applyLanguage() rendert neu und setzt dabei die Auswahl
  // aus dem zuletzt geladenen Stand zurück (vor 0.1.3 wurde so wieder "de" gespeichert).
  const chosen = e.target.value;
  if (current && current.settings) current.settings.Language = chosen;
  applyLanguage(chosen);
  save({ Language: chosen });
});
el("MakePlaylist").addEventListener("change", (e) => save({ MakePlaylist: e.target.value === "true" }));

async function action(path, note = "statusNote", body = {}) {
  sticky(note, t("loading"), "busy");
  try {
    const result = await api(path, { method: "POST", body: JSON.stringify(body) });
    sticky(note, result.message || "", "ok");
    return result;
  } catch (error) {
    sticky(note, error.message, "bad");
    return null;
  }
}
el("showButton").addEventListener("click", () => action("./api/show"));
el("hideButton").addEventListener("click", () => action("./api/cancel"));
el("againButton").addEventListener("click", () => action("./api/lyrics/again"));
el("clearButton").addEventListener("click", () => action("./api/lyrics/clear", "cacheNote"));
el("maTest").addEventListener("click", () => action("./api/ma/test", "maNote"));
el("jfTest").addEventListener("click", () => action("./api/jellyfin/test", "jfNote"));
el("spotifyForget").addEventListener("click", () => action("./api/spotify/forget", "spotifyNote"));
el("spotifyLogin").addEventListener("click", async () => {
  // Fenster sofort öffnen (sonst blockt der Browser es), Adresse danach setzen
  const win = window.open("about:blank", "_blank");
  try {
    if (el("SpotifyClientId").value.trim() && el("SpotifyClientId").value.trim() !== (current?.settings.SpotifyClientId || "")) {
      await save({ SpotifyClientId: el("SpotifyClientId").value.trim() });
    }
    const result = await api("./api/spotify/login", { method: "POST", body: "{}" });
    if (win) win.location = result.url; else window.open(result.url, "_blank");
    el("spotifyPasteRow").hidden = false;
    sticky("spotifyNote", t("spotifyOpened"), "busy", 120000);
  } catch (error) {
    if (win) win.close();
    sticky("spotifyNote", error.message, "bad");
  }
});
el("spotifyFinish").addEventListener("click", async () => {
  const result = await action("./api/spotify/finish", "spotifyNote", { pasted: el("SpotifyPaste").value });
  if (result) { el("SpotifyPaste").value = ""; el("spotifyPasteRow").hidden = true; }
});

function renderServices(sv) {
  if (!sv || !sv.rows || !sv.rows.length) return;
  el("servicesList").innerHTML = sv.rows.map((r) => `<li class="svc ${esc(r.state)}"><span class="dot"></span>
    <div><b>${esc(r.name)}</b> <span class="tag">${esc(t("svc_" + r.state))}</span><div class="txt">${esc(r.text)}</div>
    ${r.hint && r.state !== "ok" ? `<div class="hint2">${esc(r.hint)}</div>` : ""}</div></li>`).join("");
  if (el("servicesNote").dataset.sticky) return;
  const time = clock(sv.at);
  setStatus(sv.bad || sv.warn ? t("servicesSome", { bad: sv.bad, warn: sv.warn, time }) : t("servicesAllOk", { time }),
    sv.bad ? "bad" : sv.warn ? "" : "ok", "servicesNote");
}
el("servicesButton").addEventListener("click", async () => {
  const button = el("servicesButton");
  button.disabled = true;
  el("servicesNote").dataset.sticky = "1";
  setStatus(t("servicesWait"), "busy", "servicesNote");
  try {
    const result = await api("./api/services");
    delete el("servicesNote").dataset.sticky;
    renderServices(result.services);
  } catch (error) {
    setStatus(error.message, "bad", "servicesNote");
    delete el("servicesNote").dataset.sticky;
  }
  button.disabled = false;
});

refresh();
setInterval(refresh, 3000);
