// Web Login plugin page. Texts: [de, en, es].
const I18N = {
  eyebrow: ["Plugin-Seite", "Plugin page", "Página del plugin"],
  title: ["Web Login", "Web Login", "Web Login"],
  lede: ["Setzt eine Anmeldung vor die Weboberfläche dieses Rahmens. Der Rahmen selbst, seine Szenen und Geräte, denen du vertraust, laufen ohne Anmeldung weiter.",
         "Puts a login in front of this frame's web page. The frame itself, its scenes and the devices you trust keep working without one.",
         "Pone un inicio de sesión delante de la página web de este marco. El propio marco, sus escenas y los dispositivos de confianza siguen funcionando sin él."],
  language: ["Sprache", "Language", "Idioma"],
  loading: ["Lade …", "Loading …", "Cargando …"],
  stateTitle: ["Schutz", "Protection", "Protección"],
  factLogin: ["Anmeldung auf Port 80", "Login on port 80", "Inicio de sesión en el puerto 80"],
  factFirewall: ["Gesperrte Ports", "Closed ports", "Puertos cerrados"],
  factService: ["Anmeldedienst", "Login service", "Servicio de inicio de sesión"],
  on: ["an", "on", "activado"],
  off: ["aus", "off", "desactivado"],
  none: ["keine", "none", "ninguno"],
  running: ["läuft", "running", "en marcha"],
  stopped: ["läuft nicht", "not running", "detenido"],
  badgeOn: ["Geschützt", "Protected", "Protegido"],
  badgeOff: ["Nicht geschützt", "Not protected", "Sin protección"],
  badgeDrift: ["Wird erneuert", "Being renewed", "Renovándose"],
  hintNoPw: ["Lege zuerst unten ein Passwort fest.", "Set a password below first.", "Primero define una contraseña abajo."],
  hintOff: ["Vor dem Einschalten: Trag Home Assistant und andere Rahmen unten als vertrauenswürdig ein. Nach dem Einschalten fragt die Weboberfläche beim nächsten Laden nach dem Passwort.",
            "Before you switch on: add Home Assistant and other frames below as trusted. After switching on, the web page asks for the password the next time it loads.",
            "Antes de activar: añade Home Assistant y otros marcos abajo como de confianza. Después, la página web pedirá la contraseña la próxima vez que se cargue."],
  hintOn: ["Nach einem DynaFrame-Update wird die Anmeldung automatisch wieder eingesetzt, meist innerhalb einer Minute.",
           "After a DynaFrame update the login is put back automatically, usually within a minute.",
           "Tras una actualización de DynaFrame, el inicio de sesión se vuelve a poner automáticamente, normalmente en un minuto."],
  hintDrift: ["DynaFrame hat seine nginx-Konfiguration erneuert. Die Anmeldung wird gleich wieder eingesetzt.",
              "DynaFrame has renewed its nginx setup. The login is being put back.",
              "DynaFrame ha renovado su configuración de nginx. El inicio de sesión se está volviendo a poner."],
  onButton: ["Schutz einschalten", "Switch protection on", "Activar protección"],
  offButton: ["Schutz ausschalten", "Switch protection off", "Desactivar protección"],
  switchingOn: ["Schalte ein …", "Switching on …", "Activando …"],
  switchingOff: ["Schalte aus …", "Switching off …", "Desactivando …"],
  switchedOn: ["Eingeschaltet. Lade die Seite neu, um dich anzumelden.", "Switched on. Reload the page to sign in.", "Activado. Recarga la página para iniciar sesión."],
  switchedOff: ["Ausgeschaltet.", "Switched off.", "Desactivado."],
  confirmOn: ["Schutz jetzt einschalten? Merk dir das Passwort; ohne es kommst du nur noch per SSH hinein.",
              "Switch the protection on now? Remember the password; without it the only way in is SSH.",
              "¿Activar la protección ahora? Recuerda la contraseña; sin ella solo podrás entrar por SSH."],
  pwTitle: ["Passwort", "Password", "Contraseña"],
  pwSet: ["Ein Passwort ist gesetzt. Ein neues Passwort meldet alle Browser ab.", "A password is set. A new password signs out every browser.", "Hay una contraseña. Una nueva cierra la sesión en todos los navegadores."],
  pwNotSet: ["Noch kein Passwort gesetzt.", "No password set yet.", "Aún no hay contraseña."],
  pwNew: ["Neues Passwort (mindestens 8 Zeichen)", "New password (at least 8 characters)", "Nueva contraseña (mínimo 8 caracteres)"],
  pwRepeat: ["Passwort wiederholen", "Repeat password", "Repetir contraseña"],
  sessionDays: ["Angemeldet bleiben, solange benutzt, bis zu", "Stay signed in while in use, up to", "Mantener la sesión mientras se usa, hasta"],
  sessionHint: ["Wer die Weboberfläche so lange nicht benutzt, muss sich neu anmelden. Solange sie benutzt wird, verlängert sich die Anmeldung von selbst.",
                "Anyone who leaves the web page unused this long has to sign in again. While it is in use, the login renews itself.",
                "Quien no use la página web durante este tiempo tendrá que volver a iniciar sesión. Mientras se usa, la sesión se renueva sola."],
  opt10m: ["10 Minuten", "10 minutes", "10 minutos"],
  opt1h: ["1 Stunde", "1 hour", "1 hora"],
  opt1d: ["1 Tag", "1 day", "1 día"],
  opt7d: ["7 Tage", "7 days", "7 días"],
  opt30d: ["30 Tage", "30 days", "30 días"],
  opt90d: ["90 Tage", "90 days", "90 días"],
  opt365d: ["1 Jahr", "1 year", "1 año"],
  pwButton: ["Passwort speichern", "Save password", "Guardar contraseña"],
  pwMismatch: ["Die beiden Passwörter sind verschieden.", "The two passwords differ.", "Las dos contraseñas no coinciden."],
  pwSaved: ["Passwort gespeichert.", "Password saved.", "Contraseña guardada."],
  logoutAll: ["Alle Browser abmelden", "Sign out all browsers", "Cerrar sesión en todos los navegadores"],
  loggedOut: ["Alle Browser sind abgemeldet.", "Every browser is signed out.", "Se ha cerrado la sesión en todos los navegadores."],
  trustTitle: ["Vertrauenswürdige Geräte", "Trusted devices", "Dispositivos de confianza"],
  trustHint: ["Diese Adressen sehen nie eine Anmeldung und dürfen auch die gesperrten Ports nutzen. Trag Home Assistant ein (die DynaFrame-Integration spricht Port 80 ohne Anmeldung an) und andere Rahmen, mit denen du synchronisierst. Eine IP-Adresse oder ein Netz pro Zeile, zum Beispiel 192.168.178.20 oder 192.168.178.0/24.",
              "These addresses never see the login and may also use the closed ports. Add Home Assistant (the DynaFrame integration talks to port 80 without a login) and other frames you sync with. One IP address or network per line, for example 192.168.178.20 or 192.168.178.0/24.",
              "Estas direcciones nunca ven el inicio de sesión y pueden usar los puertos cerrados. Añade Home Assistant (la integración de DynaFrame usa el puerto 80 sin inicio de sesión) y otros marcos con los que sincronices. Una IP o red por línea, por ejemplo 192.168.178.20 o 192.168.178.0/24."],
  trustButton: ["Geräte speichern", "Save trusted devices", "Guardar dispositivos"],
  saved: ["Gespeichert.", "Saved.", "Guardado."],
  refusedTitle: ["Kürzlich abgewiesen", "Recently turned away", "Rechazados recientemente"],
  refusedHint: ["Geräte, die ohne Anmeldung auf die Weboberfläche wollten. Ist eins davon ein eigenes Gerät, das sich nicht anmelden kann (etwa Home Assistant), vertrau ihm hier.",
                "Devices that reached the web page without being signed in. If one of them is a device of yours that cannot sign in (Home Assistant, say), trust it here.",
                "Dispositivos que llegaron a la página web sin iniciar sesión. Si alguno es tuyo y no puede iniciar sesión (Home Assistant, por ejemplo), confía en él aquí."],
  trustOne: ["Vertrauen", "Trust", "Confiar"],
  refusedRow: ["{count}× · zuletzt {when} · {path}", "{count}× · last {when} · {path}", "{count}× · último {when} · {path}"],
  portsTitle: ["Ports", "Ports", "Puertos"],
  portsHint: ["Die Weboberfläche ist auch direkt erreichbar, an der Anmeldung vorbei: Engine (8001), Weboberfläche (8003) und Renderer (8080). Angekreuzte Ports sind für alle außer dem Rahmen selbst und deinen vertrauenswürdigen Geräten gesperrt. Nicht angekreuzte bleiben offen, damit Plugins, die du später installierst (etwa mit eigener Handy-Seite), weiter funktionieren. SSH, Port 80 und 443 werden nie gesperrt.",
              "The web page is also reachable directly, past the login: Engine (8001), web page (8003) and renderer (8080). Ticked ports are closed to everything but the frame itself and your trusted devices. Ports that are not ticked stay open, so plugins you install later (with their own phone pages, say) keep working. SSH, port 80 and 443 are never closed.",
              "La página web también es accesible directamente, sin inicio de sesión: Engine (8001), página web (8003) y renderizador (8080). Los puertos marcados quedan cerrados para todos menos el propio marco y tus dispositivos de confianza. Los no marcados siguen abiertos, para que los plugins que instales después (con su propia página para el móvil, por ejemplo) sigan funcionando. SSH y los puertos 80 y 443 nunca se cierran."],
  firewallOn: ["Angekreuzte Ports sperren", "Close the ticked ports", "Cerrar los puertos marcados"],
  portsButton: ["Ports speichern", "Save ports", "Guardar puertos"],
  portIdle: ["gerade nicht in Benutzung", "not in use right now", "sin uso ahora"],
  kind_ssh: ["SSH, bleibt immer offen", "SSH, always stays open", "SSH, siempre abierto"],
  kind_web: ["Weboberfläche mit Anmeldung", "Web page with login", "Página web con inicio de sesión"],
  kind_samba: ["Windows-Freigabe (Samba)", "Windows sharing (Samba)", "Compartir de Windows (Samba)"],
  kind_engine: ["Engine, an der Anmeldung vorbei", "Engine, past the login", "Engine, sin inicio de sesión"],
  kind_webui: ["Weboberfläche direkt, an der Anmeldung vorbei", "Web page directly, past the login", "Página web directa, sin inicio de sesión"],
  kind_renderer: ["Renderer, an der Anmeldung vorbei", "Renderer, past the login", "Renderizador, sin inicio de sesión"],
  kind_youtube: ["YouTube Cast (Handy)", "YouTube Cast (phone)", "YouTube Cast (móvil)"],
  kind_photos: ["Photo Cast (Handy)", "Photo Cast (phone)", "Photo Cast (móvil)"],
  httpsTitle: ["HTTPS", "HTTPS", "HTTPS"],
  httpsHint: ["Verschlüsselt die Weboberfläche, das Passwort und die Anmeldung, damit niemand in deinem Netz mitlesen kann. Browser melden sich dann immer über https:// an. Home Assistant, vertrauenswürdige Geräte und NFC-Leser bleiben bei http.",
              "Encrypts the web page, the password and the login, so nobody on your network can read them. Browsers then always sign in over https://. Home Assistant, trusted devices and NFC readers keep using plain http.",
              "Cifra la página web, la contraseña y el inicio de sesión, para que nadie en tu red pueda leerlos. Los navegadores entran siempre por https://. Home Assistant, los dispositivos de confianza y los lectores NFC siguen con http."],
  httpsOn: ["HTTPS verwenden (Port 443)", "Use HTTPS (port 443)", "Usar HTTPS (puerto 443)"],
  httpsButton: ["HTTPS speichern", "Save HTTPS", "Guardar HTTPS"],
  httpsOnBadge: ["Aktiv", "Active", "Activo"],
  httpsOffBadge: ["Aus", "Off", "Desactivado"],
  httpsWaiting: ["Wird aktiv, sobald der Schutz eingeschaltet ist.", "Takes effect once protection is on.", "Se activa cuando la protección esté encendida."],
  certSelf: ["Der Rahmen hat sich ein eigenes Zertifikat ausgestellt. Der Browser warnt beim ersten Besuch, weil es keine bekannte Stelle unterschrieben hat. Vergleiche den Fingerabdruck unten mit dem im Browser und bestätige dann. Auf Dauer kannst du das Zertifikat herunterladen und auf deinen Geräten als vertrauenswürdig installieren, dann kommt keine Warnung mehr.",
             "The frame has issued its own certificate. Browsers warn on the first visit because no known authority signed it. Compare the fingerprint below with the one your browser shows, then accept it. To get rid of the warning for good, download the certificate and install it as trusted on your devices.",
             "El marco ha emitido su propio certificado. Los navegadores avisan en la primera visita porque no lo firma ninguna autoridad conocida. Compara la huella de abajo con la del navegador y acéptalo. Para que no avise más, descarga el certificado e instálalo como de confianza en tus dispositivos."],
  certOwn: ["Dein eigenes Zertifikat ist in Gebrauch.", "Your own certificate is in use.", "Se usa tu propio certificado."],
  certNames: ["Gültig für", "Valid for", "Válido para"],
  certUntil: ["Gültig bis", "Valid until", "Válido hasta"],
  certFp: ["SHA-256-Fingerabdruck", "SHA-256 fingerprint", "Huella SHA-256"],
  certDownload: ["Zertifikat herunterladen", "Download certificate", "Descargar certificado"],
  ownCert: ["Stattdessen ein eigenes Zertifikat verwenden", "Use your own certificate instead", "Usar tu propio certificado"],
  ownCertHint: ["Für ein Zertifikat deiner eigenen Zertifizierungsstelle oder von Let's Encrypt: Zertifikat (mit Zwischenzertifikaten) und den unverschlüsselten privaten Schlüssel einfügen, beides im PEM-Format.",
                "For a certificate from your own certificate authority or Let's Encrypt: paste the certificate (with any intermediate certificates) and its unencrypted private key, both in PEM format.",
                "Para un certificado de tu propia autoridad o de Let's Encrypt: pega el certificado (con los intermedios) y su clave privada sin cifrar, ambos en formato PEM."],
  certPem: ["Zertifikat (PEM)", "Certificate (PEM)", "Certificado (PEM)"],
  keyPem: ["Privater Schlüssel (PEM)", "Private key (PEM)", "Clave privada (PEM)"],
  certSave: ["Dieses Zertifikat verwenden", "Use this certificate", "Usar este certificado"],
  certClear: ["Zurück zum eigenen Zertifikat des Rahmens", "Back to the frame's own certificate", "Volver al certificado del marco"],
  oidcTitle: ["Single Sign-on (OIDC)", "Single sign-on (OIDC)", "Inicio de sesión único (OIDC)"],
  oidcHint: ["Anmeldung über deinen eigenen Identitätsanbieter (Authentik, Authelia, Pocket ID, Keycloak und andere). Leg dort einen Client (eine Anwendung) vom Typ „vertraulich“ mit diesen Weiterleitungs-URIs an und trag seine Daten hier ein.",
             "Sign in with your own identity provider (Authentik, Authelia, Pocket ID, Keycloak and others). Create a client (application) there of type \"confidential\" with these redirect URIs, then enter its details here.",
             "Inicia sesión con tu propio proveedor de identidad (Authentik, Authelia, Pocket ID, Keycloak y otros). Crea allí un cliente (aplicación) de tipo \"confidencial\" con estas URI de redirección y pon sus datos aquí."],
  oidcOn: ["Anmeldung über den Anbieter anbieten", "Offer sign-in with the provider", "Ofrecer inicio de sesión con el proveedor"],
  issuer: ["Issuer-URL", "Issuer URL", "URL del emisor (issuer)"],
  clientId: ["Client-ID", "Client ID", "ID de cliente"],
  clientSecret: ["Client-Secret", "Client secret", "Secreto del cliente"],
  secretKept: ["Client-Secret (gespeichert; leer lassen, um es zu behalten)", "Client secret (saved; leave empty to keep it)", "Secreto del cliente (guardado; déjalo vacío para conservarlo)"],
  buttonLabel: ["Name auf dem Knopf", "Name on the button", "Nombre en el botón"],
  allowedUsers: ["Erlaubte Benutzer (freiwillig, einer pro Zeile)", "Allowed users (optional, one per line)", "Usuarios permitidos (opcional, uno por línea)"],
  allowedGroups: ["Erlaubte Gruppen (freiwillig, eine pro Zeile)", "Allowed groups (optional, one per line)", "Grupos permitidos (opcional, uno por línea)"],
  allowedHint: ["Beide leer lassen, um jeden hereinzulassen, den der Anbieter für diesen Client durchlässt. Benutzer passen über Benutzername, E-Mail oder Subject-ID.",
                "Leave both empty to let in everyone the provider lets through for this client. Users match by user name, e-mail or subject ID.",
                "Déjalos vacíos para dejar pasar a todos los que el proveedor admita para este cliente. Los usuarios coinciden por nombre, correo o ID de sujeto."],
  providerCert: ["Anbieter mit eigenem Zertifikat", "Provider with its own certificate", "Proveedor con certificado propio"],
  providerCertHint: ["Nutzt dein Anbieter ein Zertifikat deiner eigenen Zertifizierungsstelle, füg hier deren Zertifikat ein (PEM).",
                     "If your provider uses a certificate from your own certificate authority, paste that authority's certificate (PEM).",
                     "Si tu proveedor usa un certificado de tu propia autoridad, pega aquí el certificado de esa autoridad (PEM)."],
  insecure: ["Zertifikat des Anbieters nicht prüfen (nicht empfohlen)", "Do not check the provider's certificate (not recommended)", "No comprobar el certificado del proveedor (no recomendado)"],
  passwordLogin: ["Anmeldung mit Passwort weiterhin erlauben", "Also allow signing in with the password", "Permitir también entrar con la contraseña"],
  oidcSave: ["Anmeldung speichern", "Save sign-on", "Guardar inicio de sesión"],
  oidcTest: ["Verbindung testen", "Test connection", "Probar conexión"],
  oidcTestOk: ["Anbieter gefunden: {issuer}{groups}", "Provider found: {issuer}{groups}", "Proveedor encontrado: {issuer}{groups}"],
  oidcGroups: [" (liefert Gruppen)", " (provides groups)", " (ofrece grupos)"],
  oidcHttpWarn: ["Tipp: Schalte HTTPS ein. Die meisten Anbieter erlauben nur https-Weiterleitungen.", "Tip: switch HTTPS on. Most providers only accept https redirects.", "Consejo: activa HTTPS. La mayoría de proveedores solo aceptan redirecciones https."],
  kind_webtls: ["Weboberfläche mit Anmeldung (HTTPS)", "Web page with login (HTTPS)", "Página web con inicio de sesión (HTTPS)"],
  err_badCert: ["Zertifikat und Schlüssel müssen im PEM-Format sein.", "Certificate and key must be in PEM format.", "El certificado y la clave deben estar en formato PEM."],
  err_encryptedKey: ["Der Schlüssel ist verschlüsselt. Bitte den unverschlüsselten Schlüssel einfügen.", "The key is encrypted. Please paste the unencrypted key.", "La clave está cifrada. Pega la clave sin cifrar."],
  err_oidcMissing: ["Issuer-URL und Client-ID fehlen.", "Issuer URL and client ID are missing.", "Faltan la URL del emisor y el ID de cliente."],
  err_oidcIssuer: ["Die Issuer-URL muss mit https:// beginnen.", "The issuer URL must start with https://.", "La URL del emisor debe empezar por https://."],
  err_oidcTest: ["Anbieter nicht erreichbar: {detail}", "Cannot reach the provider: {detail}", "No se puede contactar con el proveedor: {detail}"],
  keysTitle: ["API-Schlüssel", "API keys", "Claves API"],
  keysHint: ["Für Programme, die den Rahmen über HTTP steuern, etwa Home Assistant, Node-RED oder ein Skript. Jedes Programm bekommt einen eigenen Schlüssel und schickt ihn bei jeder Anfrage als Header „Authorization: Bearer SCHLÜSSEL“ (oder „X-DynaFrame-Key: SCHLÜSSEL“) mit. Ein gelöschter Schlüssel gilt sofort nicht mehr.",
             "For programs that control the frame over HTTP, such as Home Assistant, Node-RED or a script. Each program gets its own key and sends it with every request as the header \"Authorization: Bearer KEY\" (or \"X-DynaFrame-Key: KEY\"). A deleted key stops working at once.",
             "Para programas que controlan el marco por HTTP, como Home Assistant, Node-RED o un script. Cada programa recibe su propia clave y la envía en cada petición con la cabecera \"Authorization: Bearer CLAVE\" (o \"X-DynaFrame-Key: CLAVE\"). Una clave borrada deja de valer al instante."],
  keyName: ["Name (z. B. Home Assistant)", "Name (e.g. Home Assistant)", "Nombre (p. ej. Home Assistant)"],
  keyCreate: ["Schlüssel erzeugen", "Create key", "Crear clave"],
  newKeyHint: ["Kopier den Schlüssel jetzt. Er wird nur dieses eine Mal angezeigt; der Rahmen speichert nur einen Fingerabdruck davon.",
               "Copy the key now. It is shown only this once; the frame keeps just a fingerprint of it.",
               "Copia la clave ahora. Solo se muestra esta vez; el marco guarda solo una huella."],
  keyCopy: ["Kopieren", "Copy", "Copiar"],
  keyCopied: ["Kopiert.", "Copied.", "Copiado."],
  keyDelete: ["Löschen", "Delete", "Borrar"],
  keyConfirmDelete: ["Schlüssel „{name}“ löschen? Programme, die ihn nutzen, kommen dann nicht mehr durch.", "Delete the key \"{name}\"? Programs using it can no longer get in.", "¿Borrar la clave \"{name}\"? Los programas que la usan ya no podrán entrar."],
  keyRow: ["angelegt {created} · endet auf …{hint}", "created {created} · ends in …{hint}", "creada {created} · termina en …{hint}"],
  keyUsed: [" · zuletzt benutzt {when} von {ip}", " · last used {when} from {ip}", " · último uso {when} desde {ip}"],
  keyNever: [" · seit dem letzten Neustart nicht benutzt", " · not used since the last restart", " · sin uso desde el último reinicio"],
  keysHttpsOnly: ["Schlüssel nur über HTTPS annehmen (empfohlen: über http könnte sie jeder im Netz mitlesen)",
                  "Accept keys over HTTPS only (recommended: over http anyone on the network could read them)",
                  "Aceptar claves solo por HTTPS (recomendado: por http cualquiera en la red podría leerlas)"],
  protectAutomations: ["Auch /automations/ und /nfc/ schützen (NFC-Leser brauchen dann eine vertrauenswürdige Adresse oder einen Schlüssel)",
                       "Protect /automations/ and /nfc/ too (NFC readers then need a trusted address or a key)",
                       "Proteger también /automations/ y /nfc/ (los lectores NFC necesitarán una dirección de confianza o una clave)"],
  exampleTitle: ["Beispiel:", "Example:", "Ejemplo:"],
  err_keyName: ["Gib dem Schlüssel einen Namen.", "Give the key a name.", "Ponle un nombre a la clave."],
  limitsTitle: ["Was dieses Plugin nicht schützt", "What this plugin does not protect", "Lo que este plugin no protege"],
  limitsIntro: ["Web Login schützt die Weboberfläche und die Ports, die du ankreuzt. Es macht den Rahmen nicht insgesamt sicher. Bitte beachte:",
                "Web Login protects the web page and the ports you tick. It does not make the frame secure as a whole. Please note:",
                "Web Login protege la página web y los puertos que marques. No hace que el marco sea seguro en su conjunto. Ten en cuenta:"],
  limitsSsh: ["SSH (Port 22) wird nie gesperrt. Ob dort ein Passwort reicht, legt die Einrichtung des Rahmens fest. Nutze ein starkes Passwort oder nur SSH-Schlüssel.",
              "SSH (port 22) is never closed. Whether a password is enough there depends on how the frame is set up. Use a strong password or SSH keys only.",
              "SSH (puerto 22) nunca se cierra. Si basta una contraseña depende de la configuración del marco. Usa una contraseña fuerte o solo claves SSH."],
  limitsSmb: ["Die Dateifreigaben (Samba, Ports 139 und 445) bleiben offen, solange du sie nicht ankreuzt. Darüber lassen sich Fotos und Plugins ablegen.",
              "The file shares (Samba, ports 139 and 445) stay open unless you tick them. Photos and plugins can be placed through them.",
              "Las carpetas compartidas (Samba, puertos 139 y 445) quedan abiertas si no las marcas. A través de ellas se pueden dejar fotos y plugins."],
  limitsPlugins: ["Ports anderer Plugins (z. B. YouTube Cast 8090, Photo Cast 8095) bleiben offen, solange du sie nicht ankreuzt.",
                  "Ports of other plugins (e.g. YouTube Cast 8090, Photo Cast 8095) stay open unless you tick them.",
                  "Los puertos de otros plugins (p. ej. YouTube Cast 8090, Photo Cast 8095) quedan abiertos si no los marcas."],
  limitsAuto: ["/nfc/ und /automations/ sind ohne Anmeldung erreichbar, solange „Automationen schützen“ aus ist.",
               "/nfc/ and /automations/ can be reached without signing in while \"protect automations\" is off.",
               "/nfc/ y /automations/ son accesibles sin iniciar sesión mientras \"proteger automatizaciones\" esté desactivado."],
  limitsUdp: ["Die Firewall sperrt nur TCP. UDP-Dienste wie mDNS, SSDP, NetBIOS und die DynaFrame-Suche bleiben erreichbar.",
              "The firewall only closes TCP. UDP services such as mDNS, SSDP, NetBIOS and DynaFrame discovery stay reachable.",
              "El cortafuegos solo cierra TCP. Los servicios UDP como mDNS, SSDP, NetBIOS y la búsqueda de DynaFrame siguen accesibles."],
  limitsHttp: ["Ohne HTTPS gehen Passwort und Anmeldung unverschlüsselt durchs Netz. Vertrauenswürdige Geräte und NFC-Leser sprechen immer über http. Das selbst erstellte Zertifikat führt zu Warnungen im Browser.",
               "Without HTTPS, the password and the login travel unencrypted. Trusted devices and NFC readers always use http. The self-made certificate causes browser warnings.",
               "Sin HTTPS, la contraseña y el inicio de sesión viajan sin cifrar. Los dispositivos de confianza y los lectores NFC siempre usan http. El certificado propio provoca avisos en el navegador."],
  limitsNet: ["Mach den Rahmen nicht aus dem Internet erreichbar (keine Portfreigabe im Router, auch nicht über IPv6). Web Login ist für das eigene Heimnetz gedacht.",
              "Do not make the frame reachable from the internet (no port forwarding in the router, IPv6 included). Web Login is meant for your own home network.",
              "No hagas el marco accesible desde Internet (sin redirección de puertos en el router, tampoco por IPv6). Web Login está pensado para tu propia red doméstica."],
  limitsWarranty: ["Bitte teste vorher selbst ausgiebig, ob dieses Plugin für deine Umgebung geeignet ist und genügend Schutz bietet. Web Login ist ein privates, kostenloses Projekt und wird ohne Gewähr bereitgestellt. Du nutzt es auf eigenes Risiko. Für Schäden, Datenverlust oder unbefugten Zugriff wird keine Haftung übernommen.",
                   "Please test thoroughly yourself first whether this plugin suits your setup and gives enough protection. Web Login is a private, free project provided as is, without any warranty. You use it at your own risk. No liability is accepted for damage, data loss or unauthorised access.",
                   "Antes de usarlo, prueba a fondo si este plugin es adecuado para tu entorno y ofrece suficiente protección. Web Login es un proyecto privado y gratuito que se ofrece tal cual, sin garantía. Lo usas bajo tu propio riesgo. No se asume responsabilidad por daños, pérdida de datos o accesos no autorizados."],
  rescueTitle: ["Ausgesperrt?", "Locked out?", "¿Sin acceso?"],
  rescueHint: ["Passwort vergessen? Melde dich per SSH am Rahmen an und führe diesen Befehl aus. Er schaltet den Schutz ganz aus; deine Einstellungen bleiben, du kannst hier ein neues Passwort setzen und ihn wieder einschalten.",
               "Forgot the password? Sign in to the frame over SSH and run this command. It switches the protection off completely; your settings stay, so you can set a new password here and switch it on again.",
               "¿Olvidaste la contraseña? Entra en el marco por SSH y ejecuta este comando. Desactiva la protección por completo; tus ajustes se conservan, así que puedes poner una nueva contraseña aquí y volver a activarla."],
  rescueHint2: ["Auch Deaktivieren oder Deinstallieren dieses Plugins unter Plugins schaltet den Schutz aus, nach etwa anderthalb Minuten.",
                "Disabling or uninstalling this plugin under Plugins also switches the protection off, after about a minute and a half.",
                "Desactivar o desinstalar este plugin en Plugins también quita la protección, tras un minuto y medio aproximadamente."],
  err_short: ["Das Passwort braucht mindestens 8 Zeichen.", "The password needs at least 8 characters.", "La contraseña necesita al menos 8 caracteres."],
  err_nopassword: ["Lege zuerst ein Passwort fest.", "Set a password first.", "Primero define una contraseña."],
  err_nosudo: ["Der Rahmen erlaubt dem Plugin keine Administratorrechte (sudo fragt nach einem Passwort). Ohne sie geht es nicht.",
               "The frame does not give the plugin administrator rights (sudo asks for a password). It cannot work without them.",
               "El marco no da derechos de administrador al plugin (sudo pide contraseña). Sin ellos no funciona."],
  err_apply: ["Konnte nicht umgesetzt werden; die Weboberfläche bleibt wie sie war.", "Could not be put in place; the web page stays as it was.", "No se pudo aplicar; la página web sigue como estaba."],
  err_badAddress: ["Keine gültige Adresse: {detail}", "Not a valid address: {detail}", "Dirección no válida: {detail}"],
  err_tooWide: ["Zu großes Netz: {detail}", "Network too wide: {detail}", "Red demasiado amplia: {detail}"],
  noAnswer: ["Das Plugin antwortet nicht.", "The plugin does not answer.", "El plugin no responde."],
  restarted: ["Das Plugin startet gerade neu (HTTP {status}). Gleich noch einmal versuchen.", "The plugin is restarting (HTTP {status}). Try again in a moment.", "El plugin se está reiniciando (HTTP {status}). Inténtalo de nuevo en un momento."],
  error: ["Fehler (HTTP {status})", "Error (HTTP {status})", "Error (HTTP {status})"],
  supportAsk: ["Probleme, Fragen oder Wünsche?", "Problems, questions or wishes?", "¿Problemas, preguntas o deseos?"],
  supportLink: ["Schreib ein Issue auf GitHub", "Open an issue on GitHub", "Abre un issue en GitHub"],
  supportTail: [", mit Plugin-Name und Version.", ", with plugin name and version.", ", con el nombre y la versión del plugin."],
};

const LANGS = ["de", "en", "es"];
let lang = "en";
let current = null;

const el = (id) => document.getElementById(id);

function t(key, values = {}) {
  const row = I18N[key];
  const text = row ? (row[LANGS.indexOf(lang)] ?? row[1]) : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""));
}

function applyLanguage(next) {
  lang = LANGS.includes(next) ? next : "en";
  document.documentElement.lang = lang;
  el("Language").value = lang;
  for (const node of document.querySelectorAll("[data-i18n]")) node.textContent = t(node.dataset.i18n);
  if (current) render(current);
}

async function api(path, options = {}) {
  let response;
  try {
    response = await fetch(path, { headers: { Accept: "application/json", "Content-Type": "application/json" }, ...options });
  } catch (_) {
    throw new Error(t("noAnswer"));
  }
  if ([502, 503, 504].includes(response.status)) throw new Error(t("restarted", { status: response.status }));
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.success === false) {
    const key = payload.code ? "err_" + payload.code : "";
    throw new Error(key && I18N[key] ? t(key, { detail: payload.detail || "" }) : payload.error || t("error", { status: response.status }));
  }
  return payload;
}

const post = (path, body) => api(path, { method: "POST", body: JSON.stringify(body || {}) });

function note(id, text, tone = "") {
  const node = el(id);
  node.textContent = text;
  node.className = `status${tone ? " " + tone : ""}`;
}

function make(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function badge(text, tone = "") {
  return make("span", `badge${tone ? " " + tone : ""}`, text);
}

function applyTheme(theme) {
  const id = (theme && theme.id) || "";
  const root = document.documentElement;
  const tag = document.getElementById("frameTheme");
  if (!tag || (root.dataset.theme || "") === id) return;
  tag.textContent = id ? `@import url("/themes/${id}/theme.css") layer(frame-theme);` : "";
  if (id) root.dataset.theme = id;
  else delete root.dataset.theme;
}

function closedPorts(firewallText) {
  const match = /tcp dport \{?\s*([0-9, ]+?)\s*\}? reject/.exec(firewallText || "");
  return match ? match[1].split(",").map((p) => p.trim()).filter(Boolean) : [];
}

function when(seconds) {
  return new Date(seconds * 1000).toLocaleString(lang === "en" ? "en-GB" : lang, { dateStyle: "short", timeStyle: "short" });
}

function render(data) {
  current = data;
  applyTheme(data.theme);
  const s = data.settings;
  const st = data.status || {};
  const loginOn = st.nginx === "login";
  const drift = s.active && !loginOn;

  const head = el("stateBadge");
  head.replaceChildren(s.active ? (drift ? badge(t("badgeDrift"), "warn") : badge(t("badgeOn"), "ok")) : badge(t("badgeOff"), "bad"));
  el("factLogin").textContent = loginOn ? t("on") : t("off");
  const closed = closedPorts(st.firewall);
  el("factFirewall").textContent = closed.length ? closed.join(", ") : t("none");
  el("factService").textContent = data.serviceUp ? t("running") : t("stopped");
  el("stateHint").textContent = !s.passwordSet ? t("hintNoPw") : drift ? t("hintDrift") : s.active ? t("hintOn") : t("hintOff");
  el("onButton").hidden = s.active;
  el("onButton").disabled = !s.passwordSet;
  el("offButton").hidden = !s.active;

  el("pwHint").textContent = s.passwordSet ? t("pwSet") : t("pwNotSet");
  if (document.activeElement !== el("sessionDays")) el("sessionDays").value = String(s.sessionMinutes);
  if (document.activeElement !== el("trusted") && !el("trusted").dataset.dirty) el("trusted").value = (s.trusted || []).join("\n");
  if (!el("firewall").dataset.dirty) el("firewall").checked = s.firewall;

  const refused = data.refused || [];
  el("refusedBox").hidden = refused.length === 0;
  el("refusedList").replaceChildren(...refused.map((row) => {
    const item = make("div", "pick");
    const main = make("div", "pick-main");
    main.append(make("div", "pick-title", row.ip),
      make("div", "pick-sub", t("refusedRow", { count: row.count, when: when(row.last), path: row.path || "/" })),
      make("div", "pick-sub", row.agent || ""));
    const button = make("button", "secondary pick-trust", t("trustOne"));
    button.type = "button";
    button.addEventListener("click", async () => {
      button.disabled = true;
      try {
        await post("./api/trust", { ip: row.ip });
        el("trusted").dataset.dirty = "";
        note("trustNote", t("saved"), "ok");
        await refresh();
      } catch (error) {
        note("trustNote", error.message, "bad");
        button.disabled = false;
      }
    });
    item.append(main, button);
    return item;
  }));

  const list = el("portList");
  if (!list.dataset.dirty) {
    list.replaceChildren(...data.ports.map((row) => {
      const item = make("label", `pick${row.locked ? " locked" : ""}`);
      const box = make("input");
      box.type = "checkbox";
      box.value = row.port;
      box.checked = row.blocked && !row.locked;
      box.disabled = row.locked;
      box.addEventListener("change", () => { list.dataset.dirty = "1"; });
      const main = make("div", "pick-main");
      const title = make("div", "pick-title");
      title.append(make("span", "pick-port", String(row.port)), document.createTextNode(" " + (row.kind ? t("kind_" + row.kind) : row.process || "")));
      main.append(title);
      const sub = [row.kind && row.process ? row.process : "", row.idle ? t("portIdle") : ""].filter(Boolean).join(" · ");
      if (sub) main.append(make("div", "pick-sub", sub));
      item.append(box, main);
      return item;
    }));
  }
  renderHttps(data);
  renderKeys(data);
  renderOidc(data);
  el("rescue").textContent = data.emergency;
  for (const link of document.querySelectorAll("#issueLink")) {
    link.href = `https://github.com/Archonw/Jans-DynaframePro-Store/issues/new?title=${encodeURIComponent(`[Web Login ${data.version}] `)}`;
  }
}

function keep(id) {
  return document.activeElement === el(id) || el(id).dataset.dirty;
}

function renderKeys(data) {
  el("keyList").replaceChildren(...(data.keys || []).map((key) => {
    const item = make("div", "pick");
    const main = make("div", "pick-main");
    let sub = t("keyRow", { created: when(key.created), hint: key.hint || "" });
    sub += key.last ? t("keyUsed", { when: when(key.last), ip: key.ip }) : t("keyNever");
    main.append(make("div", "pick-title", key.name), make("div", "pick-sub", sub));
    const button = make("button", "secondary pick-trust", t("keyDelete"));
    button.type = "button";
    button.addEventListener("click", () => {
      if (!confirm(t("keyConfirmDelete", { name: key.name }))) return;
      run(button, "keysNote", "", async () => { await post("./api/keys/delete", { id: key.id }); });
    });
    item.append(main, button);
    return item;
  }));
  if (!keep("keysHttpsOnly")) el("keysHttpsOnly").checked = data.keysHttpsOnly;
  if (!keep("protectAutomations")) el("protectAutomations").checked = data.protectAutomations;
  const scheme = data.https.enabled ? "https" : "http";
  const host = (data.redirectUris && data.redirectUris[0] || "").split("/")[2] || "FRAME";
  el("keyExample").textContent = `curl ${data.https.enabled ? "-k " : ""}-X POST -H "Authorization: Bearer dfk_..." ${scheme}://${host}/Home/Next`;
}

for (const id of ["keysHttpsOnly", "protectAutomations"]) {
  el(id).addEventListener("change", async () => {
    try {
      await post("./api/access", { [id]: el(id).checked });
      note("keysNote", t("saved"), "ok");
    } catch (error) {
      note("keysNote", error.message, "bad");
    }
    await refresh();
  });
}

el("keyCreate").addEventListener("click", () => run(el("keyCreate"), "keysNote", "", async () => {
  const result = await post("./api/keys/create", { name: el("keyName").value });
  el("newKey").textContent = result.key;
  el("newKeyBox").hidden = false;
  el("keyName").value = "";
  return " ";
}));

el("keyCopy").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(el("newKey").textContent);
  } catch (_) {
    const range = document.createRange();
    range.selectNodeContents(el("newKey"));
    getSelection().removeAllRanges();
    getSelection().addRange(range);
    document.execCommand("copy");
  }
  note("keysNote", t("keyCopied"), "ok");
});

function renderHttps(data) {
  const h = data.https;
  const live = data.status && data.status.https;
  el("httpsBadge").replaceChildren(live ? badge(t("httpsOnBadge"), "ok") : badge(t("httpsOffBadge")));
  if (!keep("httpsOn")) el("httpsOn").checked = h.enabled;
  const cert = data.status && data.status.cert;
  el("certBox").hidden = !(h.enabled && cert);
  if (cert) {
    el("certText").textContent = cert.own ? t("certOwn") : t("certSelf");
    el("certNames").textContent = (cert.names || "").replace(/IP Address:/g, "").replace(/DNS:/g, "");
    el("certUntil").textContent = cert.until || "";
    el("certFp").textContent = cert.sha256 || "";
  }
  if (h.enabled && !data.settings.active) note("httpsNote", t("httpsWaiting"));
}

function renderOidc(data) {
  const o = data.oidc;
  el("oidcBadge").replaceChildren(o.enabled ? badge(t("on"), "ok") : badge(t("off")));
  el("redirectUris").textContent = (data.redirectUris || []).join("\n");
  if (!keep("oidcOn")) el("oidcOn").checked = o.enabled;
  for (const [id, key] of [["issuer", "issuer"], ["clientId", "clientId"], ["oidcLabel", "label"], ["caPem", "caPem"]]) {
    if (!keep(id)) el(id).value = o[key] || "";
  }
  if (!keep("allowedUsers")) el("allowedUsers").value = (o.allowedUsers || []).join("\n");
  if (!keep("allowedGroups")) el("allowedGroups").value = (o.allowedGroups || []).join("\n");
  if (!keep("insecure")) el("insecure").checked = !!o.insecure;
  if (!keep("passwordLogin")) el("passwordLogin").checked = data.passwordLogin;
  el("secretLabel").textContent = o.secretSet ? t("secretKept") : t("clientSecret");
}

for (const id of ["httpsOn", "oidcOn", "issuer", "clientId", "oidcLabel", "caPem", "allowedUsers", "allowedGroups", "insecure", "passwordLogin"]) {
  el(id).addEventListener("input", () => { el(id).dataset.dirty = "1"; });
  el(id).addEventListener("change", () => { el(id).dataset.dirty = "1"; });
}

function clean(ids) {
  for (const id of ids) el(id).dataset.dirty = "";
}

async function refresh() {
  try {
    const data = await api("./api/state");
    if (!current) applyLanguage(data.settings.Language);
    render(data);
    note("statusNote", "");
  } catch (error) {
    note("statusNote", error.message, "bad");
  }
}

async function run(button, noteId, busyKey, work) {
  button.disabled = true;
  if (busyKey) note(noteId, t(busyKey), "busy");
  try {
    const text = await work();
    note(noteId, text || t("saved"), "ok");
  } catch (error) {
    note(noteId, error.message, "bad");
  } finally {
    button.disabled = false;
    await refresh();
  }
}

el("Language").addEventListener("change", async () => {
  applyLanguage(el("Language").value);
  try { await post("./api/settings", { Language: lang }); } catch (_) { /* only the page language */ }
});

el("onButton").addEventListener("click", () => {
  if (!confirm(t("confirmOn"))) return;
  run(el("onButton"), "stateNote", "switchingOn", async () => {
    await post("./api/active", { active: true });
    return t("switchedOn");
  });
});

el("offButton").addEventListener("click", () => run(el("offButton"), "stateNote", "switchingOff", async () => {
  await post("./api/active", { active: false });
  return t("switchedOff");
}));

el("pwButton").addEventListener("click", () => run(el("pwButton"), "pwNote", "", async () => {
  if (el("pw1").value !== el("pw2").value) throw new Error(t("pwMismatch"));
  await post("./api/password", { password: el("pw1").value });
  el("pw1").value = "";
  el("pw2").value = "";
  return t("pwSaved");
}));

el("sessionDays").addEventListener("change", async () => {
  try {
    await post("./api/settings", { sessionMinutes: Number(el("sessionDays").value) });
    note("pwNote", t("saved"), "ok");
  } catch (error) {
    note("pwNote", error.message, "bad");
  }
});

el("logoutAll").addEventListener("click", () => run(el("logoutAll"), "pwNote", "", async () => {
  await post("./api/logout-all", {});
  return t("loggedOut");
}));

el("trusted").addEventListener("input", () => { el("trusted").dataset.dirty = "1"; });
el("trustButton").addEventListener("click", () => run(el("trustButton"), "trustNote", "", async () => {
  const trusted = el("trusted").value.split(/[\s,;]+/).map((v) => v.trim()).filter(Boolean);
  await post("./api/settings", { trusted });
  el("trusted").dataset.dirty = "";
}));

el("firewall").addEventListener("change", () => { el("firewall").dataset.dirty = "1"; });
el("portsButton").addEventListener("click", () => run(el("portsButton"), "portsNote", "", async () => {
  const blockPorts = [...el("portList").querySelectorAll("input:checked")].map((box) => Number(box.value));
  await post("./api/settings", { blockPorts, firewall: el("firewall").checked });
  el("portList").dataset.dirty = "";
  el("firewall").dataset.dirty = "";
}));

el("httpsButton").addEventListener("click", () => run(el("httpsButton"), "httpsNote", "", async () => {
  await post("./api/https", { enabled: el("httpsOn").checked });
  clean(["httpsOn"]);
}));

el("certSave").addEventListener("click", () => run(el("certSave"), "httpsNote", "", async () => {
  await post("./api/https", { cert: el("certPem").value, key: el("keyPem").value });
  el("certPem").value = "";
  el("keyPem").value = "";
}));

el("certClear").addEventListener("click", () => run(el("certClear"), "httpsNote", "", async () => {
  await post("./api/https", { clearCert: true });
}));

el("certDownload").addEventListener("click", () => {
  const cert = current && current.status && current.status.cert;
  if (!cert || !cert.pem) return;
  const link = document.createElement("a");
  link.href = URL.createObjectURL(new Blob([cert.pem], { type: "application/x-x509-ca-cert" }));
  link.download = `${current.frame || "dynaframe"}.crt`;
  document.body.append(link);
  link.click();
  link.remove();
});

function oidcBody() {
  const body = {
    enabled: el("oidcOn").checked, issuer: el("issuer").value, clientId: el("clientId").value,
    label: el("oidcLabel").value, allowedUsers: el("allowedUsers").value, allowedGroups: el("allowedGroups").value,
    caPem: el("caPem").value, insecure: el("insecure").checked, passwordLogin: el("passwordLogin").checked,
  };
  if (el("clientSecret").value) body.clientSecret = el("clientSecret").value;
  return body;
}

el("oidcButton").addEventListener("click", () => run(el("oidcButton"), "oidcNote", "", async () => {
  await post("./api/oidc", oidcBody());
  el("clientSecret").value = "";
  clean(["oidcOn", "issuer", "clientId", "oidcLabel", "caPem", "allowedUsers", "allowedGroups", "insecure", "passwordLogin"]);
  return current && !current.https.enabled && el("oidcOn").checked ? t("oidcHttpWarn") : t("saved");
}));

el("oidcTest").addEventListener("click", () => run(el("oidcTest"), "oidcNote", "", async () => {
  const result = await post("./api/oidc-test", { issuer: el("issuer").value, caPem: el("caPem").value, insecure: el("insecure").checked });
  return t("oidcTestOk", { issuer: result.issuer, groups: result.groups ? t("oidcGroups") : "" });
}));

applyLanguage("en");
refresh();
setInterval(refresh, 15000);
