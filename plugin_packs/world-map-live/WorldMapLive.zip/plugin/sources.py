"""Die drei Datenquellen von World Map Live.

- Flugzeuge: OpenSky Network, REST (/api/states/all). Ohne Konto reichen die
  400 Credits am Tag für etwa alle 16 Minuten die ganze Welt; mit einem
  kostenlosen API-Client (OAuth2, Client-ID und Secret) 4000 Credits, also
  etwa alle 2 Minuten. Dazwischen rechnet die Szene die Flugzeuge mit Kurs
  und Geschwindigkeit weiter.
- Schiffe aus bis zu fünf Quellen, jede einzeln schaltbar; Fleet legt sie
  zusammen (pro MMSI gilt die neueste Meldung), Schiffe bleiben bis zu einer
  Stunde stehen, wenn sie nichts mehr melden:
  - AISStream.io, Websocket, kostenloser API-Key. Das Plugin hört nur kurze
    Fenster lang zu (Standard 45 s alle 10 Minuten), weil der weltweite Strom
    sonst viele GB am Tag wären.
  - Kystverket (Norwegen), offener TCP-Strom roher AIS-Sätze, ohne Anmeldung.
  - Digitraffic (Finnland, Ostsee), REST alle 5 Minuten, ohne Anmeldung.
  - AISHub, REST alle 5 Minuten, nur mit Benutzernamen (wer selbst einen
    Empfänger einspeist).
  - Ein eigener AIS-Empfänger im Heimnetz (z. B. AIS-catcher), TCP.
- ISS: Bahnelemente (OMM/TLE) von CelesTrak, sonst wheretheiss.at, alle
  6 Stunden. Die Szene rechnet Position und Bahn daraus selbst.
- Blitze: Blitzortung.org, Websocket der Live-Karte, ohne Key. Die
  Nachrichten sind LZW-komprimiertes JSON (siehe decode_lzw).

Jede Quelle läuft in einem eigenen Thread und hat einen Status, den die
Plugin-Seite zeigt. Alle Adressen lassen sich über Umgebungsvariablen
umbiegen (für die Tests mit nachgebauten Servern).
"""

import calendar
import json
import math
import os
import random
import threading
import time
from collections import deque

import requests

try:
    import websocket  # Paket websocket-client
except ImportError:  # pragma: no cover - die Plugin-Seite sagt es
    websocket = None

OPENSKY_STATES = os.environ.get("WML_OPENSKY_URL", "https://opensky-network.org/api/states/all")
OPENSKY_TOKEN = os.environ.get(
    "WML_OPENSKY_TOKEN_URL",
    "https://auth.opensky-network.org/auth/realms/opensky-network/protocol/openid-connect/token")
AIS_URL = os.environ.get("WML_AIS_URL", "wss://stream.aisstream.io/v0/stream")
# Kystverket (Norwegen) gibt seinen AIS-Strom offen heraus (NLOD 2.0), ohne Anmeldung.
KYSTVERKET_ADDRESS = os.environ.get("WML_KYSTVERKET", "153.44.253.27:5631")
DIGITRAFFIC_URL = os.environ.get("WML_DIGITRAFFIC_URL", "https://meri.digitraffic.fi/api/ais/v1/locations")
AISHUB_URL = os.environ.get("WML_AISHUB_URL", "https://data.aishub.net/ws.php")
BLITZ_URLS = [u for u in os.environ.get("WML_BLITZ_URLS", "").split(",") if u] or [
    f"wss://ws{n}.blitzortung.org/" for n in (1, 7, 8, 5, 6, 3, 2)]
BLITZ_ORIGIN = "https://map.blitzortung.org"
ISS_URLS = [u for u in os.environ.get("WML_ISS_URLS", "").split(",") if u] or [
    "https://celestrak.org/NORAD/elements/gp.php?CATNR=25544&FORMAT=json",
    "https://api.wheretheiss.at/v1/satellites/25544/tles?format=json"]
USER_AGENT = "DynaFrame-WorldMapLive/1.0 (+https://github.com/Archonw/Jans-DynaframePro-Store)"


def now():
    return time.time()


def in_box(box, lon, lat, margin=0.0):
    """box = (west, south, east, north); None heißt die ganze Welt."""
    if box is None:
        return True
    west, south, east, north = box
    return (south - margin) <= lat <= (north + margin) and (west - margin) <= lon <= (east + margin)


class Source:
    """Gemeinsamer Teil: Status, Thread, Aufwecken."""

    name = "source"

    def __init__(self, log):
        self.log = log
        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.stopped = threading.Event()
        self.enabled = True
        self.box = None
        self.status = {"state": "off", "error": "", "at": 0.0, "next": 0.0, "count": 0}
        self.version = 0
        self.thread = None

    def set_status(self, state, error="", **extra):
        with self.lock:
            self.status.update(state=state, error=error, **extra)

    def start(self):
        if self.thread is None:
            self.thread = threading.Thread(target=self._run, name=f"WorldMapLive-{self.name}", daemon=True)
            self.thread.start()

    def stop(self):
        self.stopped.set()
        self.wake.set()

    def poke(self):
        self.wake.set()

    def sleep(self, seconds):
        """Schläft, bis die Zeit um ist, jemand poke() ruft oder stop()."""
        self.wake.wait(max(0.0, seconds))
        self.wake.clear()
        return not self.stopped.is_set()

    def _run(self):
        while not self.stopped.is_set():
            try:
                pause = self.step()
            except Exception as exc:  # pragma: no cover - darf den Thread nie beenden
                self.log(f"{self.name}: {exc}", "warning")
                self.set_status("error", str(exc))
                pause = 60
            if not self.sleep(pause):
                break

    def step(self):  # pragma: no cover
        raise NotImplementedError


# --------------------------------------------------------------------------
# Flugzeuge: OpenSky Network
# --------------------------------------------------------------------------

class OpenSky(Source):
    name = "planes"
    MAX_AGE = 120          # Positionen, die älter sind, fallen weg
    BUDGET_ANON = 400      # Credits am Tag ohne Konto
    BUDGET_ACCOUNT = 4000  # mit kostenlosem Konto

    def __init__(self, log):
        super().__init__(log)
        self.client_id = ""
        self.client_secret = ""
        self.token = ""
        self.token_until = 0.0
        self.planes = []    # flach: lon, lat, kurs, m/s, je Flugzeug
        self.time = 0
        self.retry_at = 0.0

    def configure(self, enabled, box, client_id, client_secret):
        changed = (enabled, box, client_id, client_secret) != (self.enabled, self.box, self.client_id,
                                                               self.client_secret)
        if client_id != self.client_id or client_secret != self.client_secret:
            self.token, self.token_until = "", 0.0
        self.enabled, self.box, self.client_id, self.client_secret = enabled, box, client_id, client_secret
        if changed:
            self.retry_at = 0.0
            self.poke()

    def credits(self):
        if self.box is None:
            return 4
        west, south, east, north = self.box
        area = (east - west) * (north - south)
        return 1 if area <= 25 else 2 if area <= 100 else 3 if area <= 400 else 4

    def interval(self):
        """So oft, dass das Tageskontingent mit 10 % Reserve reicht."""
        budget = self.BUDGET_ACCOUNT if self.client_id and self.client_secret else self.BUDGET_ANON
        return max(90.0, 86400.0 * self.credits() / (budget * 0.9))

    def headers(self):
        headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
        if not (self.client_id and self.client_secret):
            return headers
        if not self.token or now() > self.token_until - 60:
            response = requests.post(OPENSKY_TOKEN, data={
                "grant_type": "client_credentials", "client_id": self.client_id,
                "client_secret": self.client_secret}, timeout=(10, 20), headers={"User-Agent": USER_AGENT})
            if response.status_code in (400, 401):
                raise PermissionError("login")
            response.raise_for_status()
            body = response.json()
            self.token = body.get("access_token") or ""
            self.token_until = now() + float(body.get("expires_in") or 1800)
            if not self.token:
                raise PermissionError("login")
        headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def step(self):
        if not self.enabled:
            with self.lock:
                self.planes, self.status["count"] = [], 0
                self.version += 1
            self.set_status("off")
            return 3600
        wait = self.retry_at - now()
        if wait > 0:
            return wait
        params = {}
        if self.box is not None:
            west, south, east, north = self.box
            params = {"lamin": south, "lomin": west, "lamax": north, "lomax": east}
        self.set_status("loading", self.status["error"])
        try:
            headers = self.headers()
            response = requests.get(OPENSKY_STATES, params=params, headers=headers, timeout=(10, 60))
        except PermissionError:
            self.set_status("error", "login")
            self.retry_at = now() + 1800
            return 1800
        except requests.RequestException as exc:
            self.set_status("error", "network", detail=str(exc))
            self.retry_at = now() + 120
            return 120
        if response.status_code == 401 and self.token:
            self.token = ""
            self.retry_at = now() + 30
            return 30
        if response.status_code == 429:
            retry = float(response.headers.get("X-Rate-Limit-Retry-After-Seconds") or 900)
            retry = min(max(retry, 60.0), 6 * 3600.0)
            self.retry_at = now() + retry
            self.set_status("error", "limit", next=self.retry_at)
            self.log(f"OpenSky: Tageskontingent erschöpft, nächster Versuch in {round(retry / 60)} Minuten.",
                     "warning")
            return retry
        if response.status_code >= 400:
            self.set_status("error", f"http {response.status_code}")
            self.retry_at = now() + 300
            return 300
        body = response.json() or {}
        stamp = int(body.get("time") or now())
        flat = []
        for row in body.get("states") or []:
            try:
                lon, lat, on_ground = row[5], row[6], row[8]
                if lon is None or lat is None or on_ground:
                    continue
                seen = row[3] or row[4] or stamp
                if stamp - seen > self.MAX_AGE:
                    continue
                speed = float(row[9] or 0.0)
                track = float(row[10] or 0.0)
                # Auf den Zeitpunkt der Antwort vorrechnen.
                lon, lat = advance(lon, lat, track, speed, stamp - seen)
                flat.extend((round(lon, 3), round(lat, 3), int(round(track)) % 360, int(round(speed))))
            except (IndexError, TypeError, ValueError):
                continue
        interval = self.interval()
        with self.lock:
            self.planes, self.time = flat, stamp
            self.version += 1
            self.status.update(state="ok", error="", at=now(), next=now() + interval, count=len(flat) // 4,
                               detail="")
        self.retry_at = now() + interval
        return interval

    def snapshot(self):
        with self.lock:
            return {"ver": self.version, "t": self.time, "data": self.planes}


def advance(lon, lat, track_deg, speed_ms, seconds):
    """Auf der Kugel geradeaus weiter (für kurze Zeiten genau genug)."""
    if not speed_ms or seconds <= 0:
        return lon, lat
    distance = speed_ms * seconds / 6371000.0
    track = math.radians(track_deg)
    lat2 = lat + math.degrees(distance * math.cos(track))
    lat2 = max(-89.9, min(89.9, lat2))
    lon2 = lon + math.degrees(distance * math.sin(track) / max(0.01, math.cos(math.radians(lat))))
    lon2 = ((lon2 + 180.0) % 360.0) - 180.0
    return lon2, lat2


# --------------------------------------------------------------------------
# Schiffe: der gemeinsame Teil
# --------------------------------------------------------------------------

def course_and_speed(cog, heading, sog):
    """Kurs aus COG, sonst Bug-Richtung; Fahrt in Knoten. AIS-Werte für
    "nicht verfügbar" (COG 360, Heading 511, SOG 102.3) werden 0."""
    try:
        sog = float(sog) if sog is not None and float(sog) < 102 else 0.0
    except (TypeError, ValueError):
        sog = 0.0
    try:
        course = float(cog) if cog is not None and float(cog) < 360 else None
    except (TypeError, ValueError):
        course = None
    if course is None:
        try:
            course = float(heading) if heading is not None and float(heading) < 360 else 0.0
        except (TypeError, ValueError):
            course = 0.0
    return course, max(0.0, sog)


class ShipSource(Source):
    """Eine Schiffsquelle. Jede führt ihre eigene Liste (MMSI -> Position);
    Fleet legt alle eingeschalteten zusammen, die neueste Meldung gewinnt."""

    name = "ships"
    KEEP = 3600        # so lange bleibt ein Schiff ohne neue Meldung
    PUBLISH = 20       # alle so viele Sekunden eine neue Version für die Szene
    MAX_SHIPS = 40000

    def __init__(self, log):
        super().__init__(log)
        self.enabled = False
        self.ships = {}     # mmsi -> (lon, lat, kurs, knoten, zeit)

    def add(self, mmsi, lon, lat, cog, heading, sog, seen=None):
        try:
            mmsi, lat, lon = int(mmsi), float(lat), float(lon)
        except (TypeError, ValueError):
            return False
        if mmsi <= 0 or abs(lat) > 90 or abs(lon) > 180 or (abs(lat) < 0.01 and abs(lon) < 0.01):
            return False
        if not in_box(self.box, lon, lat, 1.0):
            return False
        course, knots = course_and_speed(cog, heading, sog)
        seen = min(seen or now(), now())
        with self.lock:
            old = self.ships.get(mmsi)
            if old and old[4] > seen:
                return False
            if len(self.ships) < self.MAX_SHIPS or old:
                self.ships[mmsi] = (lon, lat, course, knots, seen)
        return True

    def clear(self):
        with self.lock:
            self.ships.clear()

    def prune(self):
        limit = now() - self.KEEP
        with self.lock:
            for mmsi in [m for m, s in self.ships.items() if s[4] < limit]:
                del self.ships[mmsi]

    def publish(self):
        with self.lock:
            self.version += 1
            self.status["count"] = len(self.ships)

    def rows(self):
        with self.lock:
            return dict(self.ships)

    def switch(self, enabled, box):
        """Gemeinsamer Teil von configure(): gibt zurück, ob sich etwas änderte."""
        changed = (enabled, box) != (self.enabled, self.box)
        if box != self.box or not enabled:
            self.clear()
        self.enabled, self.box = enabled, box
        return changed

    def off(self):
        self.clear()
        self.publish()
        self.set_status("off")
        return 3600

    def done(self, pause):
        self.prune()
        self.publish()
        with self.lock:
            self.status.update(state="ok", error="", at=now(), next=now() + pause, detail="")
        return pause


# --------------------------------------------------------------------------
# Schiffe 1: AISStream.io (weltweit, kostenloser API-Key)
# --------------------------------------------------------------------------

class AisStream(ShipSource):
    name = "aisstream"

    def __init__(self, log):
        super().__init__(log)
        self.key = ""
        self.listen = 45
        self.period = 600
        self.backoff = 30
        self.restart = threading.Event()

    def configure(self, enabled, box, key, listen, period):
        changed = self.switch(enabled, box) or key != self.key
        self.key = key
        self.listen, self.period = listen, max(period, listen + 30)
        if changed:
            self.backoff = 30
            self.restart.set()
            self.poke()

    def step(self):
        if not self.enabled:
            return self.off()
        if not self.key:
            self.set_status("nokey")
            return 3600
        if websocket is None:
            self.set_status("error", "nolib")
            return 3600
        self.restart.clear()
        started = now()
        error = self.listen_once()
        self.prune()
        self.publish()
        if error == "key":
            self.set_status("error", "key", next=now() + 6 * 3600)
            return 6 * 3600
        if error:
            self.set_status("error", error, next=now() + self.backoff)
            pause, self.backoff = self.backoff, min(self.backoff * 2, 1800)
            return pause
        self.backoff = 30
        return self.done(max(10.0, self.period - (now() - started)))

    def subscription(self):
        if self.box is None:
            boxes = [[[-90, -180], [90, 180]]]
        else:
            west, south, east, north = self.box
            boxes = [[[south - 1, west - 1], [north + 1, east + 1]]]
        return json.dumps({"APIKey": self.key, "BoundingBoxes": boxes,
                           "FilterMessageTypes": ["PositionReport", "StandardClassBPositionReport"]})

    def listen_once(self):
        self.set_status("loading", self.status["error"])
        try:
            ws = websocket.create_connection(AIS_URL, timeout=15, header=[f"User-Agent: {USER_AGENT}"])
        except Exception as exc:
            self.status["detail"] = str(exc)
            return "network"
        received = 0
        last_publish = now()
        try:
            ws.send(self.subscription())
            ws.settimeout(10)
            until = now() + self.listen
            while now() < until and not self.stopped.is_set() and not self.restart.is_set():
                try:
                    raw = ws.recv()
                except websocket.WebSocketTimeoutException:
                    continue
                if not raw:
                    return "closed" if not received else ""
                if isinstance(raw, bytes):
                    raw = raw.decode("utf-8", "replace")
                try:
                    message = json.loads(raw)
                except ValueError:
                    continue
                if not isinstance(message, dict):
                    continue
                if message.get("error"):
                    text = str(message["error"])
                    self.log(f"AISStream: {text}", "warning")
                    return "key" if "key" in text.lower() else "server"
                if self.take(message):
                    received += 1
                if now() - last_publish > self.PUBLISH:
                    self.publish()
                    last_publish = now()
        except websocket.WebSocketConnectionClosedException:
            return "" if received else "closed"
        except Exception as exc:
            self.status["detail"] = str(exc)
            return "network" if not received else ""
        finally:
            try:
                ws.close()
            except Exception:
                pass
        return ""

    def take(self, message):
        meta = message.get("MetaData") or {}
        kind = message.get("MessageType") or ""
        body = (message.get("Message") or {}).get(kind) or {}
        return self.add(meta.get("MMSI") or body.get("UserID"),
                        meta.get("longitude", body.get("Longitude")), meta.get("latitude", body.get("Latitude")),
                        body.get("Cog"), body.get("TrueHeading"), body.get("Sog"))


# --------------------------------------------------------------------------
# Schiffe 2 und 5: rohe AIS-Sätze (NMEA) über TCP - Kystverket, eigener Empfänger
# --------------------------------------------------------------------------

def ais_bits(payload, fill=0):
    """Die 6-Bit-Zeichen eines !AIVDM-Satzes als eine große Zahl."""
    value, count = 0, 0
    for char in payload:
        code = ord(char) - 48
        if code > 40:
            code -= 8
        if not 0 <= code < 64:
            return None, 0
        value = (value << 6) | code
        count += 6
    return value >> fill, count - fill


def ais_field(value, count, start, width, signed=False):
    if start + width > count:
        return None
    field = (value >> (count - start - width)) & ((1 << width) - 1)
    if signed and field & (1 << (width - 1)):
        field -= 1 << width
    return field


# Wo die Felder der Positionsmeldungen liegen: (sog, lon, lat, cog, heading)
AIS_LAYOUT = {
    1: (50, 61, 89, 116, 128), 2: (50, 61, 89, 116, 128), 3: (50, 61, 89, 116, 128),
    18: (46, 57, 85, 112, 124), 19: (46, 57, 85, 112, 124),
}


def decode_ais(payload, fill=0):
    """Positionsmeldung (Typ 1, 2, 3, 18, 19, 27) -> (mmsi, lon, lat, cog, heading, sog) oder None."""
    value, count = ais_bits(payload, fill)
    if value is None or count < 38:
        return None
    kind = ais_field(value, count, 0, 6)
    mmsi = ais_field(value, count, 8, 30)
    if kind in AIS_LAYOUT:
        at_sog, at_lon, at_lat, at_cog, at_head = AIS_LAYOUT[kind]
        lon = ais_field(value, count, at_lon, 28, True)
        lat = ais_field(value, count, at_lat, 27, True)
        sog = ais_field(value, count, at_sog, 10)
        cog = ais_field(value, count, at_cog, 12)
        heading = ais_field(value, count, at_head, 9)
        if None in (lon, lat, sog, cog, heading):
            return None
        return mmsi, lon / 600000.0, lat / 600000.0, cog / 10.0, heading, sog / 10.0
    if kind == 27:   # Langstrecke (Satellit): gröber
        lon = ais_field(value, count, 44, 18, True)
        lat = ais_field(value, count, 62, 17, True)
        sog = ais_field(value, count, 79, 6)
        cog = ais_field(value, count, 85, 9)
        if None in (lon, lat, sog, cog):
            return None
        return mmsi, lon / 600.0, lat / 600.0, (cog if cog < 360 else 360), 511, (sog if sog < 63 else 102.3)
    return None


def parse_nmea(line):
    """'!AIVDM,1,1,,A,<payload>,0*5C' (auch mit Tag-Block davor) -> Positionsmeldung oder None.
    Mehrteilige Sätze sind nie Positionsmeldungen (nur Typ 19 manchmal) und fallen weg."""
    start = line.find("!")
    if start < 0:
        return None
    parts = line[start:].split("*")[0].split(",")
    if len(parts) < 7 or not parts[0][3:6] in ("VDM", "VDO") or parts[1] != "1":
        return None
    try:
        fill = int(parts[6] or 0)
    except ValueError:
        fill = 0
    return decode_ais(parts[5], fill)


class NmeaFeed(ShipSource):
    """Hält eine TCP-Verbindung zu einem AIS-Strom und liest Zeile für Zeile."""

    SILENT = 120       # so lange ohne Satz: neu verbinden

    def __init__(self, log, name, address=""):
        super().__init__(log)
        self.name = name
        self.address = address
        self.backoff = 15
        self.restart = threading.Event()

    def configure(self, enabled, box, address=None):
        changed = self.switch(enabled, box)
        if address is not None and address != self.address:
            self.address, changed = address, True
            self.clear()
        if changed:
            self.backoff = 15
            self.restart.set()
            self.poke()

    def target(self):
        text = self.address.strip()
        for prefix in ("tcp://", "nmea://"):
            if text.lower().startswith(prefix):
                text = text[len(prefix):]
        text = text.rstrip("/")
        host, _, port = text.rpartition(":")
        try:
            port = int(port)
        except ValueError:
            return None
        if not host or not 0 < port < 65536:
            return None
        return host.strip("[]"), port

    def step(self):
        if not self.enabled:
            return self.off()
        target = self.target()
        if target is None:
            self.set_status("nokey")
            return 3600
        self.restart.clear()
        error = self.read(target)
        self.prune()
        self.publish()
        if self.stopped.is_set() or self.restart.is_set():
            return 0
        if error:
            self.set_status("error", error, next=now() + self.backoff)
            pause, self.backoff = self.backoff, min(self.backoff * 2, 900)
            return pause
        self.backoff = 15
        return 5

    def read(self, target):
        import socket
        self.set_status("loading", self.status["error"])
        try:
            sock = socket.create_connection(target, timeout=15)
        except OSError as exc:
            self.status["detail"] = str(exc)
            return "network"
        sock.settimeout(10)
        received, buffer = 0, b""
        last_line = now()
        last_publish = now() - self.PUBLISH + 3     # die ersten Schiffe bald zeigen
        try:
            while not self.stopped.is_set() and not self.restart.is_set():
                try:
                    chunk = sock.recv(65536)
                except socket.timeout:
                    if now() - last_line > self.SILENT:
                        return "silent"
                    continue
                if not chunk:
                    return "" if received else "closed"
                buffer += chunk
                *lines, buffer = buffer.split(b"\n")
                if lines:
                    last_line = now()
                for raw in lines:
                    position = parse_nmea(raw.decode("ascii", "replace").strip())
                    if position and self.add(*position):
                        received += 1
                if len(buffer) > 65536:
                    buffer = b""
                if now() - last_publish > self.PUBLISH:
                    self.prune()
                    self.publish()
                    with self.lock:
                        self.status.update(state="ok", error="", at=now(), next=0.0, detail="")
                    last_publish = now()
        except OSError as exc:
            self.status["detail"] = str(exc)
            return "" if received else "network"
        finally:
            try:
                sock.close()
            except OSError:
                pass
        return ""


# --------------------------------------------------------------------------
# Schiffe 3: Digitraffic (Fintraffic, Ostsee), REST, ohne Anmeldung
# --------------------------------------------------------------------------

class Digitraffic(ShipSource):
    name = "digitraffic"
    EVERY = 300

    def configure(self, enabled, box):
        if self.switch(enabled, box):
            self.poke()

    def step(self):
        if not self.enabled:
            return self.off()
        self.set_status("loading", self.status["error"])
        try:
            response = requests.get(DIGITRAFFIC_URL, timeout=(10, 60), headers={
                "Digitraffic-User": "DynaFrame-WorldMapLive", "Accept-Encoding": "gzip",
                "User-Agent": USER_AGENT})
        except requests.RequestException as exc:
            self.status["detail"] = str(exc)
            self.set_status("error", "network", next=now() + self.EVERY)
            return self.EVERY
        if response.status_code >= 400:
            self.set_status("error", "server", next=now() + self.EVERY, detail=f"HTTP {response.status_code}")
            return self.EVERY
        try:
            features = (response.json() or {}).get("features") or []
        except (ValueError, AttributeError):
            self.set_status("error", "server", next=now() + self.EVERY)
            return self.EVERY
        for feature in features:
            if not isinstance(feature, dict):
                continue
            props = feature.get("properties") or {}
            coords = (feature.get("geometry") or {}).get("coordinates") or [None, None]
            stamp = props.get("timestampExternal")
            seen = stamp / 1000.0 if isinstance(stamp, (int, float)) and stamp > 1e11 else None
            if seen and seen < now() - self.KEEP:
                continue
            self.add(feature.get("mmsi") or props.get("mmsi"), coords[0], coords[1] if len(coords) > 1 else None,
                     props.get("cog"), props.get("heading"), props.get("sog"), seen)
        return self.done(self.EVERY)


# --------------------------------------------------------------------------
# Schiffe 4: AISHub, REST - nur für Leute, die selbst einen Empfänger einspeisen
# --------------------------------------------------------------------------

class AisHub(ShipSource):
    name = "aishub"
    EVERY = 300        # AISHub erlaubt höchstens eine Abfrage pro Minute

    def __init__(self, log):
        super().__init__(log)
        self.user = ""

    def configure(self, enabled, box, user):
        changed = self.switch(enabled, box)
        if user != self.user:
            self.user, changed = user, True
            self.clear()
        if changed:
            self.poke()

    def step(self):
        if not self.enabled:
            return self.off()
        if not self.user:
            self.set_status("nokey")
            return 3600
        self.set_status("loading", self.status["error"])
        params = {"username": self.user, "format": 1, "output": "json", "compress": 0}
        if self.box:
            west, south, east, north = self.box
            params.update(latmin=south - 1, latmax=north + 1, lonmin=west - 1, lonmax=east + 1)
        try:
            response = requests.get(AISHUB_URL, params=params, timeout=(10, 60), headers={"User-Agent": USER_AGENT})
            body = response.json()
        except (requests.RequestException, ValueError) as exc:
            self.status["detail"] = str(exc)
            self.set_status("error", "network", next=now() + self.EVERY)
            return self.EVERY
        head = body[0] if isinstance(body, list) and body and isinstance(body[0], dict) else {}
        if head.get("ERROR"):
            text = str(head.get("ERROR_MESSAGE") or "")
            self.log(f"AISHub: {text}", "warning")
            code = "key" if "user" in text.lower() or "auth" in text.lower() else "server"
            self.set_status("error", code, next=now() + self.EVERY, detail=text)
            return self.EVERY
        rows = body[1] if isinstance(body, list) and len(body) > 1 and isinstance(body[1], list) else []
        for row in rows:
            if isinstance(row, dict):
                self.add(row.get("MMSI"), row.get("LONGITUDE"), row.get("LATITUDE"),
                         row.get("COG"), row.get("HEADING"), row.get("SOG"), aishub_time(row.get("TIME")))
        return self.done(self.EVERY)


def aishub_time(value):
    """'2026-10-24 05:30:12 GMT' oder Unix-Zeit -> Unix-Zeit (None, wenn unklar)."""
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return float(calendar.timegm(time.strptime(str(value).replace(" GMT", "").strip(), "%Y-%m-%d %H:%M:%S")))
    except (TypeError, ValueError):
        return None


# --------------------------------------------------------------------------
# Alle Schiffsquellen zusammen, für die Szene
# --------------------------------------------------------------------------

class Fleet:
    """Legt die Schiffe aller Quellen zusammen. Meldet ein Schiff bei
    mehreren, gilt die neueste Meldung."""

    def __init__(self, sources):
        self.sources = sources
        self.lock = threading.Lock()
        self.cache = {"ver": 0, "t": 0, "data": []}
        self.key = None
        self.count = 0

    def snapshot(self):
        key = tuple(source.version for source in self.sources)
        with self.lock:
            if key == self.key:
                return dict(self.cache)
        merged = {}
        for source in self.sources:
            if not source.enabled:
                continue
            for mmsi, row in source.rows().items():
                old = merged.get(mmsi)
                if old is None or row[4] > old[4]:
                    merged[mmsi] = row
        t = now()
        flat = []
        for lon, lat, course, sog, seen in merged.values():
            age = min(t - seen, 1800)
            if sog >= 0.5:
                lon, lat = advance(lon, lat, course, sog * 0.514444, age)
            flat.extend((round(lon, 3), round(lat, 3), int(round(course)) % 360, round(sog, 1)))
        with self.lock:
            self.key = key
            self.count = len(merged)
            self.cache = {"ver": sum(key), "t": int(t), "data": flat}
            return dict(self.cache)


# --------------------------------------------------------------------------
# Blitze: Blitzortung.org
# --------------------------------------------------------------------------

def decode_lzw(text):
    """Die Nachrichten der Live-Karte von Blitzortung sind LZW-gepackt."""
    if not text:
        return ""
    table = {}
    chars = list(text)
    current = chars[0]
    previous = current
    out = [current]
    code = 256
    for ch in chars[1:]:
        value = ord(ch)
        if value < 256:
            entry = ch
        else:
            entry = table.get(value, previous + current)
        out.append(entry)
        current = entry[0]
        table[code] = previous + current
        code += 1
        previous = entry
    return "".join(out)


class Blitzortung(Source):
    name = "lightning"
    MAX_STRIKES = 30000

    def __init__(self, log):
        super().__init__(log)
        self.minutes = 30
        self.strikes = deque()   # (id, lon, lat, zeit)
        self.next_id = 1
        self.host = random.randrange(len(BLITZ_URLS))
        self.boot = random.randrange(1, 1 << 30)   # erkennt die Szene einen Neustart
        self.backoff = 10
        self.restart = threading.Event()

    def configure(self, enabled, box, minutes):
        changed = (enabled, box) != (self.enabled, self.box)
        self.enabled, self.box, self.minutes = enabled, box, minutes
        if changed:
            with self.lock:
                self.strikes.clear()
                self.version += 1
            self.restart.set()
            self.poke()

    def step(self):
        if not self.enabled:
            self.set_status("off")
            return 3600
        if websocket is None:
            self.set_status("error", "nolib")
            return 3600
        self.restart.clear()
        url = BLITZ_URLS[self.host % len(BLITZ_URLS)]
        error = self.listen(url)
        if self.stopped.is_set() or self.restart.is_set():
            return 0
        # Nächstes Mal den nächsten Server, mit wachsender Pause.
        self.host += 1
        self.set_status("error", error or "closed", next=now() + self.backoff)
        pause, self.backoff = self.backoff, min(self.backoff * 2, 600)
        return pause

    def listen(self, url):
        self.set_status("loading", self.status["error"])
        try:
            ws = websocket.create_connection(url, timeout=15, origin=BLITZ_ORIGIN,
                                             header=[f"User-Agent: {USER_AGENT}"])
            ws.send('{"a":111}')
            ws.settimeout(20)
        except Exception as exc:
            self.status["detail"] = f"{url}: {exc}"
            return "network"
        self.log(f"Blitzortung: verbunden ({url}).")
        silent_since = now()
        try:
            while not self.stopped.is_set() and not self.restart.is_set():
                try:
                    raw = ws.recv()
                except websocket.WebSocketTimeoutException:
                    raw = None
                if raw:
                    if isinstance(raw, bytes):
                        raw = raw.decode("utf-8", "replace")
                    if self.take(raw):
                        silent_since = now()
                        self.backoff = 10
                        with self.lock:
                            if self.status["state"] != "ok":
                                self.status.update(state="ok", error="", detail="")
                            self.status["at"] = now()
                elif raw == "":
                    return "closed"
                # Weltweit blitzt es praktisch immer; 10 Minuten Stille heißt:
                # die Verbindung hängt.
                if now() - silent_since > 600:
                    return "silent"
                self.prune()
        except websocket.WebSocketConnectionClosedException:
            return "closed"
        except Exception as exc:
            self.status["detail"] = str(exc)
            return "network"
        finally:
            try:
                ws.close()
            except Exception:
                pass
        return ""

    def take(self, raw):
        try:
            try:
                data = json.loads(raw)
            except ValueError:
                data = json.loads(decode_lzw(raw))
            lat, lon = float(data["lat"]), float(data["lon"])
        except (KeyError, TypeError, ValueError, IndexError):
            return False
        stamp = data.get("time")
        try:
            stamp = float(stamp) / 1e9 if stamp and float(stamp) > 1e12 else float(stamp or now())
        except (TypeError, ValueError):
            stamp = now()
        if abs(stamp - now()) > 3600:
            stamp = now()
        if not in_box(self.box, lon, lat, 2.0):
            return True   # die Verbindung lebt, der Blitz ist nur woanders
        with self.lock:
            self.strikes.append((self.next_id, round(lon, 3), round(lat, 3), round(stamp, 1)))
            self.next_id += 1
            while len(self.strikes) > self.MAX_STRIKES:
                self.strikes.popleft()
        return True

    def prune(self):
        limit = now() - self.minutes * 60
        with self.lock:
            while self.strikes and self.strikes[0][3] < limit:
                self.strikes.popleft()
            self.status["count"] = len(self.strikes)

    def generation(self):
        return f"{self.boot}-{self.version}"

    def since(self, last_id):
        """Blitze mit id > last_id. Fängt die Szene neu an (0), alle im Fenster."""
        self.prune()
        with self.lock:
            rows = [s for s in self.strikes if s[0] > last_id]
            return {"last": self.next_id - 1, "gen": self.generation(),
                    "data": [v for s in rows for v in s[1:]]}


# --------------------------------------------------------------------------
# ISS: Bahnelemente
# --------------------------------------------------------------------------

def tle_epoch(field):
    """TLE-Epoche "26291.51234567" -> Unix-Zeit."""
    year = int(field[:2])
    year += 2000 if year < 57 else 1900
    day = float(field[2:])
    return calendar.timegm((year, 1, 1, 0, 0, 0, 0, 0, 0)) + (day - 1) * 86400


def parse_tle(line1, line2):
    return {
        "epoch": tle_epoch(line1[18:32].strip()),
        "ndot": float(line1[33:43]),
        "i": float(line2[8:16]), "raan": float(line2[17:25]), "e": float("0." + line2[26:33].strip()),
        "argp": float(line2[34:42]), "M": float(line2[43:51]), "n": float(line2[52:63]),
    }


def parse_omm(row):
    from datetime import datetime, timezone
    stamp = datetime.fromisoformat(row["EPOCH"].replace("Z", "")).replace(tzinfo=timezone.utc).timestamp()
    return {"epoch": stamp, "ndot": float(row.get("MEAN_MOTION_DOT") or 0), "i": float(row["INCLINATION"]),
            "raan": float(row["RA_OF_ASC_NODE"]), "e": float(row["ECCENTRICITY"]),
            "argp": float(row["ARG_OF_PERICENTER"]), "M": float(row["MEAN_ANOMALY"]),
            "n": float(row["MEAN_MOTION"])}


class Iss(Source):
    name = "iss"
    EVERY = 6 * 3600

    def __init__(self, log):
        super().__init__(log)
        self.elements = None

    def configure(self, enabled):
        if enabled != self.enabled:
            self.enabled = enabled
            self.poke()

    def step(self):
        if not self.enabled:
            self.set_status("off")
            return 3600
        for url in ISS_URLS:
            try:
                response = requests.get(url, timeout=(10, 20), headers={"User-Agent": USER_AGENT})
                response.raise_for_status()
                body = response.json()
                if isinstance(body, list):
                    body = body[0]
                elements = parse_omm(body) if "EPOCH" in body else parse_tle(body["line1"], body["line2"])
                if not 15 < elements["n"] < 17:
                    raise ValueError(f"unerwartete Bahn: {elements}")
            except Exception as exc:
                self.status["detail"] = f"{url}: {exc}"
                continue
            with self.lock:
                self.elements = elements
                self.version += 1
                self.status.update(state="ok", error="", at=now(), next=now() + self.EVERY, count=1, detail="")
            return self.EVERY
        # Alte Elemente bleiben ein paar Tage brauchbar.
        self.set_status("error", "network", next=now() + 1800)
        return 1800

    def snapshot(self):
        with self.lock:
            return self.elements
